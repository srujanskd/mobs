package androidx.preference;

import android.R;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p016CoM4.com7;
import p016CoM4.lpt7;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class con extends RecyclerView.com3<com7> implements Preference.nul {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final PreferenceGroup f2667a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<Preference> f2669a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public List<Preference> f8491b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List<nul> f8492c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2668a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Handler f8490a = new Handler(Looper.getMainLooper());

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            con.this.F();
        }
    }

    /* JADX INFO: renamed from: androidx.preference.con$con, reason: collision with other inner class name */
    public class C0043con implements Preference.com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ PreferenceGroup f8494a;

        public C0043con(PreferenceGroup preferenceGroup) {
            this.f8494a = preferenceGroup;
        }

        @Override // androidx.preference.Preference.com1
        public boolean a(Preference preference) {
            this.f8494a.m(Preference.DEFAULT_ORDER);
            con.this.b(preference);
            this.f8494a.e();
            return true;
        }
    }

    public static class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8495a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f2671a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8496b;

        public nul(Preference preference) {
            this.f2671a = preference.getClass().getName();
            this.f8495a = preference.getLayoutResource();
            this.f8496b = preference.getWidgetLayoutResource();
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof nul)) {
                return false;
            }
            nul nulVar = (nul) obj;
            return this.f8495a == nulVar.f8495a && this.f8496b == nulVar.f8496b && TextUtils.equals(this.f2671a, nulVar.f2671a);
        }

        public int hashCode() {
            return ((((527 + this.f8495a) * 31) + this.f8496b) * 31) + this.f2671a.hashCode();
        }
    }

    public con(PreferenceGroup preferenceGroup) {
        this.f2667a = preferenceGroup;
        preferenceGroup.setOnPreferenceChangeInternalListener(this);
        this.f2669a = new ArrayList();
        this.f8491b = new ArrayList();
        this.f8492c = new ArrayList();
        if (preferenceGroup instanceof PreferenceScreen) {
            w(((PreferenceScreen) preferenceGroup).p());
        } else {
            w(true);
        }
        F();
    }

    public final void A(List<Preference> list, PreferenceGroup preferenceGroup) {
        preferenceGroup.o();
        int iG = preferenceGroup.g();
        for (int i2 = 0; i2 < iG; i2++) {
            Preference preferenceF = preferenceGroup.f(i2);
            list.add(preferenceF);
            nul nulVar = new nul(preferenceF);
            if (!this.f8492c.contains(nulVar)) {
                this.f8492c.add(nulVar);
            }
            if (preferenceF instanceof PreferenceGroup) {
                PreferenceGroup preferenceGroup2 = (PreferenceGroup) preferenceF;
                if (preferenceGroup2.h()) {
                    A(list, preferenceGroup2);
                }
            }
            preferenceF.setOnPreferenceChangeInternalListener(this);
        }
    }

    public Preference B(int i2) {
        if (i2 < 0 || i2 >= f()) {
            return null;
        }
        return this.f8491b.get(i2);
    }

    public final boolean C(PreferenceGroup preferenceGroup) {
        return preferenceGroup.d() != Integer.MAX_VALUE;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    /* JADX INFO: renamed from: D, reason: merged with bridge method [inline-methods] */
    public void n(com7 com7Var, int i2) {
        Preference preferenceB = B(i2);
        com7Var.P();
        preferenceB.onBindViewHolder(com7Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    /* JADX INFO: renamed from: E, reason: merged with bridge method [inline-methods] */
    public com7 p(ViewGroup viewGroup, int i2) {
        nul nulVar = this.f8492c.get(i2);
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(viewGroup.getContext());
        TypedArray typedArrayObtainStyledAttributes = viewGroup.getContext().obtainStyledAttributes((AttributeSet) null, lpt7.f528a);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(lpt7.f6203a);
        if (drawable == null) {
            drawable = AUX.aux.b(viewGroup.getContext(), R.drawable.list_selector_background);
        }
        typedArrayObtainStyledAttributes.recycle();
        View viewInflate = layoutInflaterFrom.inflate(nulVar.f8495a, viewGroup, false);
        if (viewInflate.getBackground() == null) {
            y.s0(viewInflate, drawable);
        }
        ViewGroup viewGroup2 = (ViewGroup) viewInflate.findViewById(R.id.widget_frame);
        if (viewGroup2 != null) {
            int i3 = nulVar.f8496b;
            if (i3 != 0) {
                layoutInflaterFrom.inflate(i3, viewGroup2);
            } else {
                viewGroup2.setVisibility(8);
            }
        }
        return new com7(viewInflate);
    }

    public void F() {
        Iterator<Preference> it = this.f2669a.iterator();
        while (it.hasNext()) {
            it.next().setOnPreferenceChangeInternalListener(null);
        }
        ArrayList arrayList = new ArrayList(this.f2669a.size());
        this.f2669a = arrayList;
        A(arrayList, this.f2667a);
        this.f8491b = z(this.f2667a);
        androidx.preference.nul preferenceManager = this.f2667a.getPreferenceManager();
        if (preferenceManager != null) {
            preferenceManager.j();
        }
        k();
        Iterator<Preference> it2 = this.f2669a.iterator();
        while (it2.hasNext()) {
            it2.next().clearWasDetached();
        }
    }

    @Override // androidx.preference.Preference.nul
    public void a(Preference preference) {
        int iIndexOf = this.f8491b.indexOf(preference);
        if (iIndexOf != -1) {
            l(iIndexOf, preference);
        }
    }

    @Override // androidx.preference.Preference.nul
    public void b(Preference preference) {
        this.f8490a.removeCallbacks(this.f2668a);
        this.f8490a.post(this.f2668a);
    }

    @Override // androidx.preference.Preference.nul
    public void c(Preference preference) {
        b(preference);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    public int f() {
        return this.f8491b.size();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    public long g(int i2) {
        if (j()) {
            return B(i2).getId();
        }
        return -1L;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    public int h(int i2) {
        nul nulVar = new nul(B(i2));
        int iIndexOf = this.f8492c.indexOf(nulVar);
        if (iIndexOf != -1) {
            return iIndexOf;
        }
        int size = this.f8492c.size();
        this.f8492c.add(nulVar);
        return size;
    }

    public final androidx.preference.aux y(PreferenceGroup preferenceGroup, List<Preference> list) {
        androidx.preference.aux auxVar = new androidx.preference.aux(preferenceGroup.getContext(), list, preferenceGroup.getId());
        auxVar.setOnPreferenceClickListener(new C0043con(preferenceGroup));
        return auxVar;
    }

    public final List<Preference> z(PreferenceGroup preferenceGroup) {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        int iG = preferenceGroup.g();
        int i2 = 0;
        for (int i3 = 0; i3 < iG; i3++) {
            Preference preferenceF = preferenceGroup.f(i3);
            if (preferenceF.isVisible()) {
                if (!C(preferenceGroup) || i2 < preferenceGroup.d()) {
                    arrayList.add(preferenceF);
                } else {
                    arrayList2.add(preferenceF);
                }
                if (preferenceF instanceof PreferenceGroup) {
                    PreferenceGroup preferenceGroup2 = (PreferenceGroup) preferenceF;
                    if (!preferenceGroup2.h()) {
                        continue;
                    } else {
                        if (C(preferenceGroup) && C(preferenceGroup2)) {
                            throw new IllegalStateException("Nesting an expandable group inside of another expandable group is not supported!");
                        }
                        for (Preference preference : z(preferenceGroup2)) {
                            if (!C(preferenceGroup) || i2 < preferenceGroup.d()) {
                                arrayList.add(preference);
                            } else {
                                arrayList2.add(preference);
                            }
                            i2++;
                        }
                    }
                } else {
                    i2++;
                }
            }
        }
        if (C(preferenceGroup) && i2 > preferenceGroup.d()) {
            arrayList.add(y(preferenceGroup, arrayList2));
        }
        return arrayList;
    }
}
