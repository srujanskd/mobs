package COM6;

import android.animation.TypeEvaluator;
import android.graphics.Matrix;

/* JADX INFO: loaded from: classes.dex */
public class com3 implements TypeEvaluator<Matrix> {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final float[] f65a = new float[9];

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float[] f5708b = new float[9];

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Matrix f5707a = new Matrix();

    public Matrix a(float f2, Matrix matrix, Matrix matrix2) {
        matrix.getValues(this.f65a);
        matrix2.getValues(this.f5708b);
        for (int i2 = 0; i2 < 9; i2++) {
            float[] fArr = this.f5708b;
            float f3 = fArr[i2];
            float f4 = this.f65a[i2];
            fArr[i2] = f4 + ((f3 - f4) * f2);
        }
        this.f5707a.setValues(this.f5708b);
        return this.f5707a;
    }
}
