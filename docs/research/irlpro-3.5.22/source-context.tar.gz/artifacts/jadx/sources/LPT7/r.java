package LPT7;

import java.util.Comparator;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class r implements Comparator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ inet.ipaddr.con f6774a;

    public /* synthetic */ r(inet.ipaddr.con conVar) {
        this.f6774a = conVar;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return this.f6774a.compare((p115lPT6.l3) obj, (p115lPT6.l3) obj2);
    }
}
