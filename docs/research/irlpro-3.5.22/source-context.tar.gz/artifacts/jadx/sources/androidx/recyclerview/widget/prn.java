package androidx.recyclerview.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class prn extends RecyclerView.lpt1 implements RecyclerView.lpt6 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f8718c = {R.attr.state_pressed};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f8719d = new int[0];

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f8720a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f2907a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ValueAnimator f2908a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Drawable f2909a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final StateListDrawable f2910a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RecyclerView.lpt7 f2911a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public RecyclerView f2912a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2913a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f8721b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int f2916b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Drawable f2917b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final StateListDrawable f2918b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final int f2921c;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final int f2922d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f8722e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f8723f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8724g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8725h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8726i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8727j;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f8732o;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8728k = 0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f8729l = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2914a = false;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2919b = false;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f8730m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f8731n = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2915a = new int[2];

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int[] f2920b = new int[2];

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            prn.this.q(500);
        }
    }

    public class con extends RecyclerView.lpt7 {
        public con() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt7
        public void b(RecyclerView recyclerView, int i2, int i3) {
            prn.this.B(recyclerView.computeHorizontalScrollOffset(), recyclerView.computeVerticalScrollOffset());
        }
    }

    public class nul extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8736b = false;

        public nul() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f8736b = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f8736b) {
                this.f8736b = false;
                return;
            }
            if (((Float) prn.this.f2908a.getAnimatedValue()).floatValue() == 0.0f) {
                prn prnVar = prn.this;
                prnVar.f8732o = 0;
                prnVar.y(0);
            } else {
                prn prnVar2 = prn.this;
                prnVar2.f8732o = 2;
                prnVar2.v();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.prn$prn, reason: collision with other inner class name */
    public class C0049prn implements ValueAnimator.AnimatorUpdateListener {
        public C0049prn() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            int iFloatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
            prn.this.f2910a.setAlpha(iFloatValue);
            prn.this.f2909a.setAlpha(iFloatValue);
            prn.this.v();
        }
    }

    public prn(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i2, int i3, int i4) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f2908a = valueAnimatorOfFloat;
        this.f8732o = 0;
        this.f2913a = new aux();
        this.f2911a = new con();
        this.f2910a = stateListDrawable;
        this.f2909a = drawable;
        this.f2918b = stateListDrawable2;
        this.f2917b = drawable2;
        this.f2921c = Math.max(i2, stateListDrawable.getIntrinsicWidth());
        this.f2922d = Math.max(i2, drawable.getIntrinsicWidth());
        this.f8722e = Math.max(i2, stateListDrawable2.getIntrinsicWidth());
        this.f8723f = Math.max(i2, drawable2.getIntrinsicWidth());
        this.f2907a = i3;
        this.f2916b = i4;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        valueAnimatorOfFloat.addListener(new nul());
        valueAnimatorOfFloat.addUpdateListener(new C0049prn());
        j(recyclerView);
    }

    public void A() {
        int i2 = this.f8732o;
        if (i2 != 0) {
            if (i2 != 3) {
                return;
            } else {
                this.f2908a.cancel();
            }
        }
        this.f8732o = 1;
        ValueAnimator valueAnimator = this.f2908a;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        this.f2908a.setDuration(500L);
        this.f2908a.setStartDelay(0L);
        this.f2908a.start();
    }

    public void B(int i2, int i3) {
        int iComputeVerticalScrollRange = this.f2912a.computeVerticalScrollRange();
        int i4 = this.f8729l;
        this.f2914a = iComputeVerticalScrollRange - i4 > 0 && i4 >= this.f2907a;
        int iComputeHorizontalScrollRange = this.f2912a.computeHorizontalScrollRange();
        int i5 = this.f8728k;
        boolean z2 = iComputeHorizontalScrollRange - i5 > 0 && i5 >= this.f2907a;
        this.f2919b = z2;
        boolean z3 = this.f2914a;
        if (!z3 && !z2) {
            if (this.f8730m != 0) {
                y(0);
                return;
            }
            return;
        }
        if (z3) {
            float f2 = i4;
            this.f8725h = (int) ((f2 * (i3 + (f2 / 2.0f))) / iComputeVerticalScrollRange);
            this.f8724g = Math.min(i4, (i4 * i4) / iComputeVerticalScrollRange);
        }
        if (this.f2919b) {
            float f3 = i5;
            this.f8727j = (int) ((f3 * (i2 + (f3 / 2.0f))) / iComputeHorizontalScrollRange);
            this.f8726i = Math.min(i5, (i5 * i5) / iComputeHorizontalScrollRange);
        }
        int i6 = this.f8730m;
        if (i6 == 0 || i6 == 1) {
            y(1);
        }
    }

    public final void C(float f2) {
        int[] iArrP = p();
        float fMax = Math.max(iArrP[0], Math.min(iArrP[1], f2));
        if (Math.abs(this.f8725h - fMax) < 2.0f) {
            return;
        }
        int iX = x(this.f8720a, fMax, iArrP, this.f2912a.computeVerticalScrollRange(), this.f2912a.computeVerticalScrollOffset(), this.f8729l);
        if (iX != 0) {
            this.f2912a.scrollBy(0, iX);
        }
        this.f8720a = fMax;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt6
    public boolean a(RecyclerView recyclerView, MotionEvent motionEvent) {
        int i2 = this.f8730m;
        if (i2 == 1) {
            boolean zU = u(motionEvent.getX(), motionEvent.getY());
            boolean zT = t(motionEvent.getX(), motionEvent.getY());
            if (motionEvent.getAction() != 0) {
                return false;
            }
            if (!zU && !zT) {
                return false;
            }
            if (zT) {
                this.f8731n = 1;
                this.f8721b = (int) motionEvent.getX();
            } else if (zU) {
                this.f8731n = 2;
                this.f8720a = (int) motionEvent.getY();
            }
            y(2);
        } else if (i2 != 2) {
            return false;
        }
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt6
    public void b(boolean z2) {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt6
    public void c(RecyclerView recyclerView, MotionEvent motionEvent) {
        if (this.f8730m == 0) {
            return;
        }
        if (motionEvent.getAction() == 0) {
            boolean zU = u(motionEvent.getX(), motionEvent.getY());
            boolean zT = t(motionEvent.getX(), motionEvent.getY());
            if (zU || zT) {
                if (zT) {
                    this.f8731n = 1;
                    this.f8721b = (int) motionEvent.getX();
                } else if (zU) {
                    this.f8731n = 2;
                    this.f8720a = (int) motionEvent.getY();
                }
                y(2);
                return;
            }
            return;
        }
        if (motionEvent.getAction() == 1 && this.f8730m == 2) {
            this.f8720a = 0.0f;
            this.f8721b = 0.0f;
            y(1);
            this.f8731n = 0;
            return;
        }
        if (motionEvent.getAction() == 2 && this.f8730m == 2) {
            A();
            if (this.f8731n == 1) {
                r(motionEvent.getX());
            }
            if (this.f8731n == 2) {
                C(motionEvent.getY());
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt1
    public void i(Canvas canvas, RecyclerView recyclerView, RecyclerView.e eVar) {
        if (this.f8728k != this.f2912a.getWidth() || this.f8729l != this.f2912a.getHeight()) {
            this.f8728k = this.f2912a.getWidth();
            this.f8729l = this.f2912a.getHeight();
            y(0);
        } else if (this.f8732o != 0) {
            if (this.f2914a) {
                n(canvas);
            }
            if (this.f2919b) {
                m(canvas);
            }
        }
    }

    public void j(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f2912a;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            l();
        }
        this.f2912a = recyclerView;
        if (recyclerView != null) {
            z();
        }
    }

    public final void k() {
        this.f2912a.removeCallbacks(this.f2913a);
    }

    public final void l() {
        this.f2912a.X0(this);
        this.f2912a.Y0(this);
        this.f2912a.Z0(this.f2911a);
        k();
    }

    public final void m(Canvas canvas) {
        int i2 = this.f8729l;
        int i3 = this.f8722e;
        int i4 = i2 - i3;
        int i5 = this.f8727j;
        int i6 = this.f8726i;
        int i7 = i5 - (i6 / 2);
        this.f2918b.setBounds(0, 0, i6, i3);
        this.f2917b.setBounds(0, 0, this.f8728k, this.f8723f);
        canvas.translate(0.0f, i4);
        this.f2917b.draw(canvas);
        canvas.translate(i7, 0.0f);
        this.f2918b.draw(canvas);
        canvas.translate(-i7, -i4);
    }

    public final void n(Canvas canvas) {
        int i2 = this.f8728k;
        int i3 = this.f2921c;
        int i4 = i2 - i3;
        int i5 = this.f8725h;
        int i6 = this.f8724g;
        int i7 = i5 - (i6 / 2);
        this.f2910a.setBounds(0, 0, i3, i6);
        this.f2909a.setBounds(0, 0, this.f2922d, this.f8729l);
        if (!s()) {
            canvas.translate(i4, 0.0f);
            this.f2909a.draw(canvas);
            canvas.translate(0.0f, i7);
            this.f2910a.draw(canvas);
            canvas.translate(-i4, -i7);
            return;
        }
        this.f2909a.draw(canvas);
        canvas.translate(this.f2921c, i7);
        canvas.scale(-1.0f, 1.0f);
        this.f2910a.draw(canvas);
        canvas.scale(1.0f, 1.0f);
        canvas.translate(-this.f2921c, -i7);
    }

    public final int[] o() {
        int[] iArr = this.f2920b;
        int i2 = this.f2916b;
        iArr[0] = i2;
        iArr[1] = this.f8728k - i2;
        return iArr;
    }

    public final int[] p() {
        int[] iArr = this.f2915a;
        int i2 = this.f2916b;
        iArr[0] = i2;
        iArr[1] = this.f8729l - i2;
        return iArr;
    }

    public void q(int i2) {
        int i3 = this.f8732o;
        if (i3 == 1) {
            this.f2908a.cancel();
        } else if (i3 != 2) {
            return;
        }
        this.f8732o = 3;
        ValueAnimator valueAnimator = this.f2908a;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
        this.f2908a.setDuration(i2);
        this.f2908a.start();
    }

    public final void r(float f2) {
        int[] iArrO = o();
        float fMax = Math.max(iArrO[0], Math.min(iArrO[1], f2));
        if (Math.abs(this.f8727j - fMax) < 2.0f) {
            return;
        }
        int iX = x(this.f8721b, fMax, iArrO, this.f2912a.computeHorizontalScrollRange(), this.f2912a.computeHorizontalScrollOffset(), this.f8728k);
        if (iX != 0) {
            this.f2912a.scrollBy(iX, 0);
        }
        this.f8721b = fMax;
    }

    public final boolean s() {
        return y.A(this.f2912a) == 1;
    }

    public boolean t(float f2, float f3) {
        if (f3 >= this.f8729l - this.f8722e) {
            int i2 = this.f8727j;
            int i3 = this.f8726i;
            if (f2 >= i2 - (i3 / 2) && f2 <= i2 + (i3 / 2)) {
                return true;
            }
        }
        return false;
    }

    public boolean u(float f2, float f3) {
        if (!s() ? f2 >= this.f8728k - this.f2921c : f2 <= this.f2921c / 2) {
            int i2 = this.f8725h;
            int i3 = this.f8724g;
            if (f3 >= i2 - (i3 / 2) && f3 <= i2 + (i3 / 2)) {
                return true;
            }
        }
        return false;
    }

    public void v() {
        this.f2912a.invalidate();
    }

    public final void w(int i2) {
        k();
        this.f2912a.postDelayed(this.f2913a, i2);
    }

    public final int x(float f2, float f3, int[] iArr, int i2, int i3, int i4) {
        int i5 = iArr[1] - iArr[0];
        if (i5 == 0) {
            return 0;
        }
        int i6 = i2 - i4;
        int i7 = (int) (((f3 - f2) / i5) * i6);
        int i8 = i3 + i7;
        if (i8 >= i6 || i8 < 0) {
            return 0;
        }
        return i7;
    }

    public void y(int i2) {
        if (i2 == 2 && this.f8730m != 2) {
            this.f2910a.setState(f8718c);
            k();
        }
        if (i2 == 0) {
            v();
        } else {
            A();
        }
        if (this.f8730m == 2 && i2 != 2) {
            this.f2910a.setState(f8719d);
            w(1200);
        } else if (i2 == 1) {
            w(1500);
        }
        this.f8730m = i2;
    }

    public final void z() {
        this.f2912a.h(this);
        this.f2912a.j(this);
        this.f2912a.k(this.f2911a);
    }
}
