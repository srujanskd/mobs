package android.support.v4.app;

import androidx.core.app.RemoteActionCompat;
import p017CoM5.u;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompatParcelizer extends androidx.core.app.RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(u uVar) {
        return androidx.core.app.RemoteActionCompatParcelizer.read(uVar);
    }

    public static void write(RemoteActionCompat remoteActionCompat, u uVar) {
        androidx.core.app.RemoteActionCompatParcelizer.write(remoteActionCompat, uVar);
    }
}
