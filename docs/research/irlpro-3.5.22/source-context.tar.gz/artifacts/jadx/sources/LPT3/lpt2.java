package LPT3;

import java.util.Map;
import p035LPt3.lpt8;
import p139lpt3.a0;
import p139lpt3.c0;
import p139lpt3.g0;

/* JADX INFO: loaded from: classes.dex */
public final class lpt2 implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com6 f6631a = new com6();

    @Override // p139lpt3.g0
    public lpt8 a(String str, a0 a0Var, int i2, int i3, Map<c0, ?> map) {
        if (a0Var == a0.UPC_A) {
            return this.f6631a.a(inet.ipaddr.aux.OCTAL_PREFIX.concat(String.valueOf(str)), a0.EAN_13, i2, i3, map);
        }
        throw new IllegalArgumentException("Can only encode UPC-A, but got ".concat(String.valueOf(a0Var)));
    }
}
