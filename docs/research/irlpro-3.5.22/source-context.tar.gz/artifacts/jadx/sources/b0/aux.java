package b0;

import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.instrumentation.okhttp3.OkHttp3Instrumentation;
import com.newrelic.agent.android.util.Constants;
import f.com8;
import java.io.IOException;
import java.util.List;
import p127lPt9.v;
import v.a;
import v.b;
import v.com9;
import v.e;
import v.f;
import v.g;
import v.h;
import v.lpt1;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class aux implements a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt1 f8787a;

    public aux(lpt1 lpt1Var) {
        com8.e(lpt1Var, "cookieJar");
        this.f8787a = lpt1Var;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // v.a
    public g a(a.aux auxVar) throws IOException {
        h hVarA;
        com8.e(auxVar, "chain");
        e eVarRequest = auxVar.request();
        e.aux auxVarH = eVarRequest.h();
        f fVarA = eVarRequest.a();
        if (fVarA != null) {
            b bVarB = fVarA.b();
            if (bVarB != null) {
                auxVarH.d(Constants.Network.CONTENT_TYPE_HEADER, bVarB.toString());
            }
            long jA = fVarA.a();
            if (jA != -1) {
                auxVarH.d(Constants.Network.CONTENT_LENGTH_HEADER, String.valueOf(jA));
                auxVarH.h("Transfer-Encoding");
            } else {
                auxVarH.d("Transfer-Encoding", "chunked");
                auxVarH.h(Constants.Network.CONTENT_LENGTH_HEADER);
            }
        }
        boolean z2 = false;
        if (eVarRequest.d(Constants.Network.HOST_HEADER) == null) {
            auxVarH.d(Constants.Network.HOST_HEADER, w.com1.R(eVarRequest.i(), false, 1, null));
        }
        if (eVarRequest.d("Connection") == null) {
            auxVarH.d("Connection", "Keep-Alive");
        }
        if (eVarRequest.d("Accept-Encoding") == null && eVarRequest.d("Range") == null) {
            auxVarH.d("Accept-Encoding", Constants.Network.ContentType.GZIP);
            z2 = true;
        }
        List<com9> listA = this.f8787a.a(eVarRequest.i());
        if (!listA.isEmpty()) {
            auxVarH.d("Cookie", b(listA));
        }
        if (eVarRequest.d(Constants.Network.USER_AGENT_HEADER) == null) {
            auxVarH.d(Constants.Network.USER_AGENT_HEADER, "okhttp/4.10.0");
        }
        g gVarB = auxVar.b(!(auxVarH instanceof e.aux) ? auxVarH.b() : OkHttp3Instrumentation.build(auxVarH));
        com1.f(this.f8787a, eVarRequest.i(), gVarB.C());
        g.aux auxVarRequest = (!(gVarB instanceof g.aux) ? gVarB.H() : OkHttp3Instrumentation.newBuilder((g.aux) gVarB)).request(eVarRequest);
        if (z2 && m.lpt1.q(Constants.Network.ContentType.GZIP, g.y(gVarB, Constants.Network.CONTENT_ENCODING_HEADER, null, 2, null), true) && com1.b(gVarB) && (hVarA = gVarB.a()) != null) {
            i0.com4 com4Var = new i0.com4(hVarA.source());
            auxVarRequest.headers(gVarB.C().c().f(Constants.Network.CONTENT_ENCODING_HEADER).f(Constants.Network.CONTENT_LENGTH_HEADER).d());
            OkHttp3Instrumentation.body(auxVarRequest, new com4(g.y(gVarB, Constants.Network.CONTENT_TYPE_HEADER, null, 2, null), -1L, i0.com7.b(com4Var)));
        }
        return auxVarRequest.build();
    }

    public final String b(List<com9> list) {
        StringBuilder sb = new StringBuilder();
        int i2 = 0;
        for (Object obj : list) {
            int i3 = i2 + 1;
            if (i2 < 0) {
                v.m();
            }
            com9 com9Var = (com9) obj;
            if (i2 > 0) {
                sb.append("; ");
            }
            sb.append(com9Var.i());
            sb.append('=');
            sb.append(com9Var.n());
            i2 = i3;
        }
        String string = sb.toString();
        com8.d(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}
