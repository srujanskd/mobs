package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
class Lifecycling$1 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ prn f8370a;

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        this.f8370a.f(com7Var, conVar);
    }
}
