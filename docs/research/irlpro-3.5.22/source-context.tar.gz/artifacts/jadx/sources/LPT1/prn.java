package LPT1;

import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
public interface prn {
    String translateName(Field field);
}
