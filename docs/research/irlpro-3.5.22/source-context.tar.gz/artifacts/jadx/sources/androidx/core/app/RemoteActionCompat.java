package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p017CoM5.w;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompat implements w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public PendingIntent f8168a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public IconCompat f2300a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2301a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2302a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f8169b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2303b;
}
