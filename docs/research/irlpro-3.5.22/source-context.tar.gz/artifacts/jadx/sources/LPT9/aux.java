package LPT9;

import com.newrelic.agent.android.agentdata.HexAttribute;
import f.com8;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import p127lPt9.s;

/* JADX INFO: loaded from: classes.dex */
public class aux {

    /* JADX INFO: renamed from: LPT9.aux$aux, reason: collision with other inner class name */
    public static final class C0015aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final C0015aux f6820a = new C0015aux();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public static final Method f954a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final Method f6821b;

        /* JADX WARN: Code duplicated, block: B:10:0x003b  */
        static {
            Method method;
            Method method2;
            boolean z2;
            Method[] methods = Throwable.class.getMethods();
            com8.d(methods, "throwableMethods");
            int length = methods.length;
            int i2 = 0;
            while (true) {
                method = null;
                if (i2 >= length) {
                    method2 = null;
                    break;
                }
                method2 = methods[i2];
                if (com8.a(method2.getName(), "addSuppressed")) {
                    Class<?>[] parameterTypes = method2.getParameterTypes();
                    com8.d(parameterTypes, "it.parameterTypes");
                    if (com8.a(s.q(parameterTypes), Throwable.class)) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                } else {
                    z2 = false;
                }
                if (z2) {
                    break;
                } else {
                    i2++;
                }
            }
            f954a = method2;
            for (Method method3 : methods) {
                if (com8.a(method3.getName(), "getSuppressed")) {
                    method = method3;
                    break;
                }
            }
            f6821b = method;
        }
    }

    public void a(Throwable th, Throwable th2) throws IllegalAccessException, InvocationTargetException {
        com8.e(th, HexAttribute.HEX_ATTR_CAUSE);
        com8.e(th2, "exception");
        Method method = C0015aux.f954a;
        if (method != null) {
            method.invoke(th, th2);
        }
    }

    public h.nul b() {
        return new h.con();
    }
}
