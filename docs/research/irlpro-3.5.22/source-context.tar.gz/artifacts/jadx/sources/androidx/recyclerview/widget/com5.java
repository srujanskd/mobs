package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public abstract class com5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8669a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f2871a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RecyclerView.lpt2 f2872a;

    public static class aux extends com5 {
        public aux(RecyclerView.lpt2 lpt2Var) {
            super(lpt2Var, null);
        }

        @Override // androidx.recyclerview.widget.com5
        public int d(View view) {
            return ((com5) this).f2872a.T(view) + ((ViewGroup.MarginLayoutParams) ((RecyclerView.lpt3) view.getLayoutParams())).rightMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int e(View view) {
            RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
            return ((com5) this).f2872a.S(view) + ((ViewGroup.MarginLayoutParams) lpt3Var).leftMargin + ((ViewGroup.MarginLayoutParams) lpt3Var).rightMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int f(View view) {
            RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
            return ((com5) this).f2872a.R(view) + ((ViewGroup.MarginLayoutParams) lpt3Var).topMargin + ((ViewGroup.MarginLayoutParams) lpt3Var).bottomMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int g(View view) {
            return ((com5) this).f2872a.Q(view) - ((ViewGroup.MarginLayoutParams) ((RecyclerView.lpt3) view.getLayoutParams())).leftMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int h() {
            return ((com5) this).f2872a.o0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int i() {
            return ((com5) this).f2872a.o0() - ((com5) this).f2872a.f0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int j() {
            return ((com5) this).f2872a.f0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int k() {
            return ((com5) this).f2872a.p0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int l() {
            return ((com5) this).f2872a.X();
        }

        @Override // androidx.recyclerview.widget.com5
        public int m() {
            return ((com5) this).f2872a.e0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int n() {
            return (((com5) this).f2872a.o0() - ((com5) this).f2872a.e0()) - ((com5) this).f2872a.f0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int p(View view) {
            ((com5) this).f2872a.n0(view, true, ((com5) this).f2871a);
            return ((com5) this).f2871a.right;
        }

        @Override // androidx.recyclerview.widget.com5
        public int q(View view) {
            ((com5) this).f2872a.n0(view, true, ((com5) this).f2871a);
            return ((com5) this).f2871a.left;
        }

        @Override // androidx.recyclerview.widget.com5
        public void r(int i2) {
            ((com5) this).f2872a.C0(i2);
        }
    }

    public static class con extends com5 {
        public con(RecyclerView.lpt2 lpt2Var) {
            super(lpt2Var, null);
        }

        @Override // androidx.recyclerview.widget.com5
        public int d(View view) {
            return ((com5) this).f2872a.O(view) + ((ViewGroup.MarginLayoutParams) ((RecyclerView.lpt3) view.getLayoutParams())).bottomMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int e(View view) {
            RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
            return ((com5) this).f2872a.R(view) + ((ViewGroup.MarginLayoutParams) lpt3Var).topMargin + ((ViewGroup.MarginLayoutParams) lpt3Var).bottomMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int f(View view) {
            RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
            return ((com5) this).f2872a.S(view) + ((ViewGroup.MarginLayoutParams) lpt3Var).leftMargin + ((ViewGroup.MarginLayoutParams) lpt3Var).rightMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int g(View view) {
            return ((com5) this).f2872a.U(view) - ((ViewGroup.MarginLayoutParams) ((RecyclerView.lpt3) view.getLayoutParams())).topMargin;
        }

        @Override // androidx.recyclerview.widget.com5
        public int h() {
            return ((com5) this).f2872a.W();
        }

        @Override // androidx.recyclerview.widget.com5
        public int i() {
            return ((com5) this).f2872a.W() - ((com5) this).f2872a.d0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int j() {
            return ((com5) this).f2872a.d0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int k() {
            return ((com5) this).f2872a.X();
        }

        @Override // androidx.recyclerview.widget.com5
        public int l() {
            return ((com5) this).f2872a.p0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int m() {
            return ((com5) this).f2872a.g0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int n() {
            return (((com5) this).f2872a.W() - ((com5) this).f2872a.g0()) - ((com5) this).f2872a.d0();
        }

        @Override // androidx.recyclerview.widget.com5
        public int p(View view) {
            ((com5) this).f2872a.n0(view, true, ((com5) this).f2871a);
            return ((com5) this).f2871a.bottom;
        }

        @Override // androidx.recyclerview.widget.com5
        public int q(View view) {
            ((com5) this).f2872a.n0(view, true, ((com5) this).f2871a);
            return ((com5) this).f2871a.top;
        }

        @Override // androidx.recyclerview.widget.com5
        public void r(int i2) {
            ((com5) this).f2872a.D0(i2);
        }
    }

    public /* synthetic */ com5(RecyclerView.lpt2 lpt2Var, aux auxVar) {
        this(lpt2Var);
    }

    public static com5 a(RecyclerView.lpt2 lpt2Var) {
        return new aux(lpt2Var);
    }

    public static com5 b(RecyclerView.lpt2 lpt2Var, int i2) {
        if (i2 == 0) {
            return a(lpt2Var);
        }
        if (i2 == 1) {
            return c(lpt2Var);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    public static com5 c(RecyclerView.lpt2 lpt2Var) {
        return new con(lpt2Var);
    }

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract int f(View view);

    public abstract int g(View view);

    public abstract int h();

    public abstract int i();

    public abstract int j();

    public abstract int k();

    public abstract int l();

    public abstract int m();

    public abstract int n();

    public int o() {
        if (Integer.MIN_VALUE == this.f8669a) {
            return 0;
        }
        return n() - this.f8669a;
    }

    public abstract int p(View view);

    public abstract int q(View view);

    public abstract void r(int i2);

    public void s() {
        this.f8669a = n();
    }

    public com5(RecyclerView.lpt2 lpt2Var) {
        this.f8669a = Integer.MIN_VALUE;
        this.f2871a = new Rect();
        this.f2872a = lpt2Var;
    }
}
