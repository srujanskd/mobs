package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import p001AuX.com9;
import p001AuX.lpt3;
import p022CoN.q0;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements com6.aux, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7782a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Context f1812a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1813a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public LayoutInflater f1814a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CheckBox f1815a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ImageView f1816a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public LinearLayout f1817a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public RadioButton f1818a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f1819a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f1820a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Drawable f7783b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ImageView f1821b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public TextView f1822b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1823b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ImageView f7784c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1824c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f7785d;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, p001AuX.com3.D);
    }

    private LayoutInflater getInflater() {
        if (this.f1814a == null) {
            this.f1814a = LayoutInflater.from(getContext());
        }
        return this.f1814a;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f1821b;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    public final void a(View view) {
        c(view, -1);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f7784c;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f7784c.getLayoutParams();
        rect.top += this.f7784c.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public void b(com3 com3Var, int i2) {
        this.f1820a = com3Var;
        setVisibility(com3Var.isVisible() ? 0 : 8);
        setTitle(com3Var.k(this));
        setCheckable(com3Var.isCheckable());
        h(com3Var.C(), com3Var.i());
        setIcon(com3Var.getIcon());
        setEnabled(com3Var.isEnabled());
        setSubMenuArrowVisible(com3Var.hasSubMenu());
        setContentDescription(com3Var.getContentDescription());
    }

    public final void c(View view, int i2) {
        LinearLayout linearLayout = this.f1817a;
        if (linearLayout != null) {
            linearLayout.addView(view, i2);
        } else {
            addView(view, i2);
        }
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public boolean d() {
        return false;
    }

    public final void e() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(com9.f5598h, (ViewGroup) this, false);
        this.f1815a = checkBox;
        a(checkBox);
    }

    public final void f() {
        ImageView imageView = (ImageView) getInflater().inflate(com9.f5599i, (ViewGroup) this, false);
        this.f1816a = imageView;
        c(imageView, 0);
    }

    public final void g() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(com9.f5601k, (ViewGroup) this, false);
        this.f1818a = radioButton;
        a(radioButton);
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public com3 getItemData() {
        return this.f1820a;
    }

    public void h(boolean z2, char c2) {
        int i2 = (z2 && this.f1820a.C()) ? 0 : 8;
        if (i2 == 0) {
            this.f1822b.setText(this.f1820a.j());
        }
        if (this.f1822b.getVisibility() != i2) {
            this.f1822b.setVisibility(i2);
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        y.s0(this, this.f1813a);
        TextView textView = (TextView) findViewById(p001AuX.com8.L);
        this.f1819a = textView;
        int i2 = this.f7782a;
        if (i2 != -1) {
            textView.setTextAppearance(this.f1812a, i2);
        }
        this.f1822b = (TextView) findViewById(p001AuX.com8.E);
        ImageView imageView = (ImageView) findViewById(p001AuX.com8.H);
        this.f1821b = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f7783b);
        }
        this.f7784c = (ImageView) findViewById(p001AuX.com8.f5582r);
        this.f1817a = (LinearLayout) findViewById(p001AuX.com8.f5576l);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        if (this.f1816a != null && this.f1823b) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f1816a.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        CompoundButton compoundButton;
        View view;
        if (!z2 && this.f1818a == null && this.f1815a == null) {
            return;
        }
        if (this.f1820a.o()) {
            if (this.f1818a == null) {
                g();
            }
            compoundButton = this.f1818a;
            view = this.f1815a;
        } else {
            if (this.f1815a == null) {
                e();
            }
            compoundButton = this.f1815a;
            view = this.f1818a;
        }
        if (z2) {
            compoundButton.setChecked(this.f1820a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.f1815a;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.f1818a;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if (this.f1820a.o()) {
            if (this.f1818a == null) {
                g();
            }
            compoundButton = this.f1818a;
        } else {
            if (this.f1815a == null) {
                e();
            }
            compoundButton = this.f1815a;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f7785d = z2;
        this.f1823b = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.f7784c;
        if (imageView != null) {
            imageView.setVisibility((this.f1824c || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z2 = this.f1820a.B() || this.f7785d;
        if (z2 || this.f1823b) {
            ImageView imageView = this.f1816a;
            if (imageView == null && drawable == null && !this.f1823b) {
                return;
            }
            if (imageView == null) {
                f();
            }
            if (drawable == null && !this.f1823b) {
                this.f1816a.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.f1816a;
            if (!z2) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.f1816a.getVisibility() != 0) {
                this.f1816a.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f1819a.getVisibility() != 8) {
                this.f1819a.setVisibility(8);
            }
        } else {
            this.f1819a.setText(charSequence);
            if (this.f1819a.getVisibility() != 0) {
                this.f1819a.setVisibility(0);
            }
        }
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet);
        q0 q0VarV = q0.v(getContext(), attributeSet, lpt3.f35w, i2, 0);
        this.f1813a = q0VarV.g(lpt3.y1);
        this.f7782a = q0VarV.n(lpt3.x1, -1);
        this.f1823b = q0VarV.a(lpt3.z1, false);
        this.f1812a = context;
        this.f7783b = q0VarV.g(lpt3.A1);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, p001AuX.com3.A, 0);
        this.f1824c = typedArrayObtainStyledAttributes.hasValue(0);
        q0VarV.w();
        typedArrayObtainStyledAttributes.recycle();
    }
}
