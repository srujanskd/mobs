package COM9;

/* JADX INFO: loaded from: classes.dex */
public class com2 {
    public boolean a() {
        return false;
    }

    public void b(float f2, float f3, float f4, com9 com9Var) {
        com9Var.m(f2, 0.0f);
    }
}
