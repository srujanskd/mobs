package com.google.android.material.floatingactionbutton;

import COM9.lpt1;
import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.util.Property;
import android.view.View;
import android.view.ViewTreeObserver;
import java.util.ArrayList;
import java.util.Iterator;
import p021CoM9.lpt4;
import p075cOM6.c4;
import p075cOM6.x3;
import p078cOM9.lpt7;
import p080cOm1.y;
import p088cOm9.lpt8;
import p101com2.u2;
import p108com9.p;

/* JADX INFO: loaded from: classes.dex */
public class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final TimeInterpolator f9501a = COM6.aux.f5702c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f3539a = {R.attr.state_pressed, R.attr.state_enabled};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f9502b = {R.attr.state_hovered, R.attr.state_focused, R.attr.state_enabled};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f9503c = {R.attr.state_focused, R.attr.state_enabled};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f9504d = {R.attr.state_hovered, R.attr.state_enabled};

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int[] f9505e = {R.attr.state_enabled};

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int[] f9506f = new int[0];

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f3540a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3541a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM6.com4 f3542a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM9.com3 f3543a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM9.com7 f3544a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Animator f3545a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f3549a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewTreeObserver.OnPreDrawListener f3550a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt7 f3551a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final FloatingActionButton f3552a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p f3553a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<Animator.AnimatorListener> f3554a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f3555a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public float f3556b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3557b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public COM6.com4 f3558b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Drawable f3560b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ArrayList<Animator.AnimatorListener> f3561b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public float f3563c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ArrayList<com5> f3565c;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public float f3566d;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3562b = true;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public float f3567e = 1.0f;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f3564c = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f3547a = new Rect();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f3548a = new RectF();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final RectF f3559b = new RectF();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Matrix f3546a = new Matrix();

    /* JADX INFO: renamed from: com.google.android.material.floatingactionbutton.aux$aux, reason: collision with other inner class name */
    public class C0058aux extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ com6 f9507a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9508b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final /* synthetic */ boolean f9509c;

        public C0058aux(boolean z2, com6 com6Var) {
            this.f9509c = z2;
            this.f9507a = com6Var;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f9508b = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            aux.this.f3564c = 0;
            aux.this.f3545a = null;
            if (this.f9508b) {
                return;
            }
            FloatingActionButton floatingActionButton = aux.this.f3552a;
            boolean z2 = this.f9509c;
            floatingActionButton.b(z2 ? 8 : 4, z2);
            com6 com6Var = this.f9507a;
            if (com6Var != null) {
                com6Var.a();
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            aux.this.f3552a.b(0, this.f9509c);
            aux.this.f3564c = 1;
            aux.this.f3545a = animator;
            this.f9508b = false;
        }
    }

    public class com1 implements ViewTreeObserver.OnPreDrawListener {
        public com1() {
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            aux.this.F();
            return true;
        }
    }

    public class com2 extends com8 {
        public com2() {
            super(aux.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com8
        public float a() {
            return 0.0f;
        }
    }

    public class com3 extends com8 {
        public com3() {
            super(aux.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com8
        public float a() {
            aux auxVar = aux.this;
            return auxVar.f3540a + auxVar.f3556b;
        }
    }

    public class com4 extends com8 {
        public com4() {
            super(aux.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com8
        public float a() {
            aux auxVar = aux.this;
            return auxVar.f3540a + auxVar.f3563c;
        }
    }

    public interface com5 {
        void a();

        void b();
    }

    public interface com6 {
        void a();

        void b();
    }

    public class com7 extends com8 {
        public com7() {
            super(aux.this, null);
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com8
        public float a() {
            return aux.this.f3540a;
        }
    }

    public abstract class com8 extends AnimatorListenerAdapter implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f9515a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f9516b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f3570b;

        public com8() {
        }

        public abstract float a();

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            aux.this.d0((int) this.f9516b);
            this.f3570b = false;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            if (!this.f3570b) {
                COM9.com3 com3Var = aux.this.f3543a;
                this.f9515a = com3Var == null ? 0.0f : com3Var.w();
                this.f9516b = a();
                this.f3570b = true;
            }
            aux auxVar = aux.this;
            float f2 = this.f9515a;
            auxVar.d0((int) (f2 + ((this.f9516b - f2) * valueAnimator.getAnimatedFraction())));
        }

        public /* synthetic */ com8(aux auxVar, C0058aux c0058aux) {
            this();
        }
    }

    public class con extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ com6 f9517a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ boolean f9518b;

        public con(boolean z2, com6 com6Var) {
            this.f9518b = z2;
            this.f9517a = com6Var;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            aux.this.f3564c = 0;
            aux.this.f3545a = null;
            com6 com6Var = this.f9517a;
            if (com6Var != null) {
                com6Var.b();
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            aux.this.f3552a.b(0, this.f9518b);
            aux.this.f3564c = 2;
            aux.this.f3545a = animator;
        }
    }

    public class nul extends COM6.com3 {
        public nul() {
        }

        @Override // android.animation.TypeEvaluator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Matrix evaluate(float f2, Matrix matrix, Matrix matrix2) {
            aux.this.f3567e = f2;
            return super.evaluate(f2, matrix, matrix2);
        }
    }

    public class prn implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ float f9520a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Matrix f3572a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ float f9521b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final /* synthetic */ float f9522c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final /* synthetic */ float f9523d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public final /* synthetic */ float f9524e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public final /* synthetic */ float f9525f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public final /* synthetic */ float f9526g;

        public prn(float f2, float f3, float f4, float f5, float f6, float f7, float f8, Matrix matrix) {
            this.f9520a = f2;
            this.f9521b = f3;
            this.f9522c = f4;
            this.f9523d = f5;
            this.f9524e = f6;
            this.f9525f = f7;
            this.f9526g = f8;
            this.f3572a = matrix;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            aux.this.f3552a.setAlpha(COM6.aux.b(this.f9520a, this.f9521b, 0.0f, 0.2f, fFloatValue));
            aux.this.f3552a.setScaleX(COM6.aux.a(this.f9522c, this.f9523d, fFloatValue));
            aux.this.f3552a.setScaleY(COM6.aux.a(this.f9524e, this.f9523d, fFloatValue));
            aux.this.f3567e = COM6.aux.a(this.f9525f, this.f9526g, fFloatValue);
            aux.this.h(COM6.aux.a(this.f9525f, this.f9526g, fFloatValue), this.f3572a);
            aux.this.f3552a.setImageMatrix(this.f3572a);
        }
    }

    public aux(FloatingActionButton floatingActionButton, lpt7 lpt7Var) {
        this.f3552a = floatingActionButton;
        this.f3551a = lpt7Var;
        p pVar = new p();
        this.f3553a = pVar;
        pVar.a(f3539a, k(new com4()));
        pVar.a(f9502b, k(new com3()));
        pVar.a(f9503c, k(new com3()));
        pVar.a(f9504d, k(new com3()));
        pVar.a(f9505e, k(new com7()));
        pVar.a(f9506f, k(new com2()));
        this.f3566d = floatingActionButton.getRotation();
    }

    public void A() {
        throw null;
    }

    public void B() {
        ViewTreeObserver viewTreeObserver = this.f3552a.getViewTreeObserver();
        ViewTreeObserver.OnPreDrawListener onPreDrawListener = this.f3550a;
        if (onPreDrawListener != null) {
            viewTreeObserver.removeOnPreDrawListener(onPreDrawListener);
            this.f3550a = null;
        }
    }

    public void C(int[] iArr) {
        throw null;
    }

    public void D(float f2, float f3, float f4) {
        throw null;
    }

    public void E(Rect rect) {
        u2.g(this.f3560b, "Didn't initialize content background");
        if (!W()) {
            this.f3551a.c(this.f3560b);
        } else {
            this.f3551a.c(new InsetDrawable(this.f3560b, rect.left, rect.top, rect.right, rect.bottom));
        }
    }

    public void F() {
        float rotation = this.f3552a.getRotation();
        if (this.f3566d != rotation) {
            this.f3566d = rotation;
            a0();
        }
    }

    public void G() {
        ArrayList<com5> arrayList = this.f3565c;
        if (arrayList != null) {
            Iterator<com5> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().a();
            }
        }
    }

    public void H() {
        ArrayList<com5> arrayList = this.f3565c;
        if (arrayList != null) {
            Iterator<com5> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().b();
            }
        }
    }

    public boolean I() {
        throw null;
    }

    public void J(ColorStateList colorStateList) {
        COM9.com3 com3Var = this.f3543a;
        if (com3Var != null) {
            com3Var.setTintList(colorStateList);
        }
    }

    public void K(PorterDuff.Mode mode) {
        COM9.com3 com3Var = this.f3543a;
        if (com3Var != null) {
            com3Var.setTintMode(mode);
        }
    }

    public final void L(float f2) {
        if (this.f3540a != f2) {
            this.f3540a = f2;
            D(f2, this.f3556b, this.f3563c);
        }
    }

    public void M(boolean z2) {
        this.f3555a = z2;
    }

    public final void N(COM6.com4 com4Var) {
        this.f3558b = com4Var;
    }

    public final void O(float f2) {
        if (this.f3556b != f2) {
            this.f3556b = f2;
            D(this.f3540a, f2, this.f3563c);
        }
    }

    public final void P(float f2) {
        this.f3567e = f2;
        Matrix matrix = this.f3546a;
        h(f2, matrix);
        this.f3552a.setImageMatrix(matrix);
    }

    public final void Q(int i2) {
        if (this.f3557b != i2) {
            this.f3557b = i2;
            b0();
        }
    }

    public final void R(float f2) {
        if (this.f3563c != f2) {
            this.f3563c = f2;
            D(this.f3540a, this.f3556b, f2);
        }
    }

    public void S(ColorStateList colorStateList) {
        Drawable drawable = this.f3549a;
        if (drawable != null) {
            y.i(drawable, lpt4.d(colorStateList));
        }
    }

    public void T(boolean z2) {
        this.f3562b = z2;
        c0();
    }

    public final void U(COM9.com7 com7Var) {
        this.f3544a = com7Var;
        COM9.com3 com3Var = this.f3543a;
        if (com3Var != null) {
            com3Var.setShapeAppearanceModel(com7Var);
        }
        Object obj = this.f3549a;
        if (obj instanceof lpt1) {
            ((lpt1) obj).setShapeAppearanceModel(com7Var);
        }
    }

    public final void V(COM6.com4 com4Var) {
        this.f3542a = com4Var;
    }

    public boolean W() {
        throw null;
    }

    public final boolean X() {
        return p024Com2.y.S(this.f3552a) && !this.f3552a.isInEditMode();
    }

    public final boolean Y() {
        return !this.f3555a || this.f3552a.getSizeDimension() >= this.f3541a;
    }

    public void Z(com6 com6Var, boolean z2) {
        if (x()) {
            return;
        }
        Animator animator = this.f3545a;
        if (animator != null) {
            animator.cancel();
        }
        boolean z3 = this.f3542a == null;
        if (!X()) {
            this.f3552a.b(0, z2);
            this.f3552a.setAlpha(1.0f);
            this.f3552a.setScaleY(1.0f);
            this.f3552a.setScaleX(1.0f);
            P(1.0f);
            if (com6Var != null) {
                com6Var.b();
                return;
            }
            return;
        }
        if (this.f3552a.getVisibility() != 0) {
            this.f3552a.setAlpha(0.0f);
            this.f3552a.setScaleY(z3 ? 0.4f : 0.0f);
            this.f3552a.setScaleX(z3 ? 0.4f : 0.0f);
            P(z3 ? 0.4f : 0.0f);
        }
        COM6.com4 com4Var = this.f3542a;
        AnimatorSet animatorSetI = com4Var != null ? i(com4Var, 1.0f, 1.0f, 1.0f) : j(1.0f, 1.0f, 1.0f);
        animatorSetI.addListener(new con(z2, com6Var));
        ArrayList<Animator.AnimatorListener> arrayList = this.f3554a;
        if (arrayList != null) {
            Iterator<Animator.AnimatorListener> it = arrayList.iterator();
            while (it.hasNext()) {
                animatorSetI.addListener(it.next());
            }
        }
        animatorSetI.start();
    }

    public void a0() {
        throw null;
    }

    public final void b0() {
        P(this.f3567e);
    }

    public final void c0() {
        Rect rect = this.f3547a;
        r(rect);
        E(rect);
        this.f3551a.a(rect.left, rect.top, rect.right, rect.bottom);
    }

    public void d0(float f2) {
        COM9.com3 com3Var = this.f3543a;
        if (com3Var != null) {
            com3Var.X(f2);
        }
    }

    public void e(Animator.AnimatorListener animatorListener) {
        if (this.f3561b == null) {
            this.f3561b = new ArrayList<>();
        }
        this.f3561b.add(animatorListener);
    }

    public final void e0(ObjectAnimator objectAnimator) {
    }

    public void f(Animator.AnimatorListener animatorListener) {
        if (this.f3554a == null) {
            this.f3554a = new ArrayList<>();
        }
        this.f3554a.add(animatorListener);
    }

    public void g(com5 com5Var) {
        if (this.f3565c == null) {
            this.f3565c = new ArrayList<>();
        }
        this.f3565c.add(com5Var);
    }

    public final void h(float f2, Matrix matrix) {
        matrix.reset();
        Drawable drawable = this.f3552a.getDrawable();
        if (drawable == null || this.f3557b == 0) {
            return;
        }
        RectF rectF = this.f3548a;
        RectF rectF2 = this.f3559b;
        rectF.set(0.0f, 0.0f, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        int i2 = this.f3557b;
        rectF2.set(0.0f, 0.0f, i2, i2);
        matrix.setRectToRect(rectF, rectF2, Matrix.ScaleToFit.CENTER);
        int i3 = this.f3557b;
        matrix.postScale(f2, f2, i3 / 2.0f, i3 / 2.0f);
    }

    public final AnimatorSet i(COM6.com4 com4Var, float f2, float f3, float f4) {
        ArrayList arrayList = new ArrayList();
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this.f3552a, (Property<FloatingActionButton, Float>) View.ALPHA, f2);
        com4Var.e("opacity").a(objectAnimatorOfFloat);
        arrayList.add(objectAnimatorOfFloat);
        ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(this.f3552a, (Property<FloatingActionButton, Float>) View.SCALE_X, f3);
        com4Var.e("scale").a(objectAnimatorOfFloat2);
        e0(objectAnimatorOfFloat2);
        arrayList.add(objectAnimatorOfFloat2);
        ObjectAnimator objectAnimatorOfFloat3 = ObjectAnimator.ofFloat(this.f3552a, (Property<FloatingActionButton, Float>) View.SCALE_Y, f3);
        com4Var.e("scale").a(objectAnimatorOfFloat3);
        e0(objectAnimatorOfFloat3);
        arrayList.add(objectAnimatorOfFloat3);
        h(f4, this.f3546a);
        ObjectAnimator objectAnimatorOfObject = ObjectAnimator.ofObject(this.f3552a, new COM6.com2(), new nul(), new Matrix(this.f3546a));
        com4Var.e("iconScale").a(objectAnimatorOfObject);
        arrayList.add(objectAnimatorOfObject);
        AnimatorSet animatorSet = new AnimatorSet();
        COM6.con.a(animatorSet, arrayList);
        return animatorSet;
    }

    public final AnimatorSet j(float f2, float f3, float f4) {
        AnimatorSet animatorSet = new AnimatorSet();
        ArrayList arrayList = new ArrayList();
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        valueAnimatorOfFloat.addUpdateListener(new prn(this.f3552a.getAlpha(), f2, this.f3552a.getScaleX(), f3, this.f3552a.getScaleY(), this.f3567e, f4, new Matrix(this.f3546a)));
        arrayList.add(valueAnimatorOfFloat);
        COM6.con.a(animatorSet, arrayList);
        animatorSet.setDuration(lpt8.d(this.f3552a.getContext(), x3.A, this.f3552a.getContext().getResources().getInteger(c4.f8905b)));
        animatorSet.setInterpolator(lpt8.e(this.f3552a.getContext(), x3.B, COM6.aux.f5701b));
        return animatorSet;
    }

    public final ValueAnimator k(com8 com8Var) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setInterpolator(f9501a);
        valueAnimator.setDuration(100L);
        valueAnimator.addListener(com8Var);
        valueAnimator.addUpdateListener(com8Var);
        valueAnimator.setFloatValues(0.0f, 1.0f);
        return valueAnimator;
    }

    public final Drawable l() {
        return this.f3560b;
    }

    public float m() {
        throw null;
    }

    public boolean n() {
        return this.f3555a;
    }

    public final COM6.com4 o() {
        return this.f3558b;
    }

    public float p() {
        return this.f3556b;
    }

    public final ViewTreeObserver.OnPreDrawListener q() {
        if (this.f3550a == null) {
            this.f3550a = new com1();
        }
        return this.f3550a;
    }

    public void r(Rect rect) {
        int sizeDimension = this.f3555a ? (this.f3541a - this.f3552a.getSizeDimension()) / 2 : 0;
        float fM = this.f3562b ? m() + this.f3563c : 0.0f;
        int iMax = Math.max(sizeDimension, (int) Math.ceil(fM));
        int iMax2 = Math.max(sizeDimension, (int) Math.ceil(fM * 1.5f));
        rect.set(iMax, iMax2, iMax, iMax2);
    }

    public float s() {
        return this.f3563c;
    }

    public final COM9.com7 t() {
        return this.f3544a;
    }

    public final COM6.com4 u() {
        return this.f3542a;
    }

    public void v(com6 com6Var, boolean z2) {
        if (w()) {
            return;
        }
        Animator animator = this.f3545a;
        if (animator != null) {
            animator.cancel();
        }
        if (!X()) {
            this.f3552a.b(z2 ? 8 : 4, z2);
            if (com6Var != null) {
                com6Var.a();
                return;
            }
            return;
        }
        COM6.com4 com4Var = this.f3558b;
        AnimatorSet animatorSetI = com4Var != null ? i(com4Var, 0.0f, 0.0f, 0.0f) : j(0.0f, 0.4f, 0.4f);
        animatorSetI.addListener(new C0058aux(z2, com6Var));
        ArrayList<Animator.AnimatorListener> arrayList = this.f3561b;
        if (arrayList != null) {
            Iterator<Animator.AnimatorListener> it = arrayList.iterator();
            while (it.hasNext()) {
                animatorSetI.addListener(it.next());
            }
        }
        animatorSetI.start();
    }

    public boolean w() {
        if (this.f3552a.getVisibility() == 0) {
            return this.f3564c == 1;
        }
        return this.f3564c != 2;
    }

    public boolean x() {
        if (this.f3552a.getVisibility() != 0) {
            return this.f3564c == 2;
        }
        return this.f3564c != 1;
    }

    public void y() {
        throw null;
    }

    public void z() {
        COM9.com3 com3Var = this.f3543a;
        if (com3Var != null) {
            COM9.com4.f(this.f3552a, com3Var);
        }
        if (I()) {
            this.f3552a.getViewTreeObserver().addOnPreDrawListener(q());
        }
    }
}
