package androidx.lifecycle;

import android.content.Context;
import java.util.Collections;
import java.util.List;
import p027Com5.y;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements y<COM3.com7> {
    @Override // p027Com5.y
    public List<Class<? extends y<?>>> a() {
        return Collections.emptyList();
    }

    @Override // p027Com5.y
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public COM3.com7 b(Context context) {
        COM3.com5.a(context);
        com4.i(context);
        return com4.h();
    }
}
