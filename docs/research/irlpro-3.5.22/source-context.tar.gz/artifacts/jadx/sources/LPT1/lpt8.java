package LPT1;

import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public interface lpt8 {
    Number a(LPT2.aux auxVar) throws IOException;
}
