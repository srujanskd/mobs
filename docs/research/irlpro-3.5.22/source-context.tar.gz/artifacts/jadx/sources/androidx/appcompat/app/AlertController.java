package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;
import p001AuX.com3;
import p001AuX.com8;
import p001AuX.lpt3;
import p024Com2.y;
import p066aUX.c;

/* JADX INFO: loaded from: classes.dex */
public class AlertController {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7742a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final c f1732a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f1733a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1734a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Handler f1735a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Message f1736a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1738a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Window f1739a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Button f1740a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ImageView f1741a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ListAdapter f1742a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ListView f1743a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f1744a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public NestedScrollView f1745a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f1746a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7743b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Drawable f1748b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Message f1749b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f1750b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Button f1751b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public TextView f1752b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f1753b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1754b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7744c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Drawable f1755c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Message f1756c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Button f1757c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f1758c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7745d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public Drawable f1759d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public CharSequence f1760d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7746e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public CharSequence f1761e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7747f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f7750i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f7751j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f7752k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f7753l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f7754m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f7755n;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1747a = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7748g = 0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f7749h = -1;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f7756o = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnClickListener f1737a = new aux();

    public static class RecycleListView extends ListView {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f7757a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final int f7758b;

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt3.f38z);
            this.f7758b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(lpt3.D1, -1);
            this.f7757a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(lpt3.E1, -1);
        }

        public void a(boolean z2, boolean z3) {
            if (z3 && z2) {
                return;
            }
            setPadding(getPaddingLeft(), z2 ? getPaddingTop() : this.f7757a, getPaddingRight(), z3 ? getPaddingBottom() : this.f7758b);
        }
    }

    public class aux implements View.OnClickListener {
        public aux() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Message messageObtain;
            Message message;
            Message message2;
            Message message3;
            AlertController alertController = AlertController.this;
            if (view == alertController.f1740a && (message3 = alertController.f1736a) != null) {
                messageObtain = Message.obtain(message3);
            } else if (view != alertController.f1751b || (message2 = alertController.f1749b) == null) {
                messageObtain = (view != alertController.f1757c || (message = alertController.f1756c) == null) ? null : Message.obtain(message);
            } else {
                messageObtain = Message.obtain(message2);
            }
            if (messageObtain != null) {
                messageObtain.sendToTarget();
            }
            AlertController alertController2 = AlertController.this;
            alertController2.f1735a.obtainMessage(1, alertController2.f1732a).sendToTarget();
        }
    }

    public static class con {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Context f1762a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public DialogInterface.OnCancelListener f1763a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public DialogInterface.OnClickListener f1764a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public DialogInterface.OnDismissListener f1765a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public DialogInterface.OnKeyListener f1766a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public DialogInterface.OnMultiChoiceClickListener f1767a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Cursor f1768a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Drawable f1769a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final LayoutInflater f1770a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f1771a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public AdapterView.OnItemSelectedListener f1772a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ListAdapter f1773a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public CharSequence f1774a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f1775a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public CharSequence[] f1777a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean[] f1778a;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public DialogInterface.OnClickListener f1779b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public Drawable f1780b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public View f1781b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public CharSequence f1782b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public String f1783b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f7762c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public DialogInterface.OnClickListener f1785c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public Drawable f1786c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public CharSequence f1787c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f1788c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f7763d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public DialogInterface.OnClickListener f1789d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public Drawable f1790d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public CharSequence f1791d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f1792d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f7764e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public CharSequence f1793e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f7765f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f7766g;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7760a = 0;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f7761b = 0;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f1784b = false;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f7767h = -1;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public boolean f1794e = true;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f1776a = true;

        public class aux extends ArrayAdapter<CharSequence> {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ RecycleListView f7768a;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public aux(Context context, int i2, int i3, CharSequence[] charSequenceArr, RecycleListView recycleListView) {
                super(context, i2, i3, charSequenceArr);
                this.f7768a = recycleListView;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i2, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i2, view, viewGroup);
                boolean[] zArr = con.this.f1778a;
                if (zArr != null && zArr[i2]) {
                    this.f7768a.setItemChecked(i2, true);
                }
                return view2;
            }
        }

        /* JADX INFO: renamed from: androidx.appcompat.app.AlertController$con$con, reason: collision with other inner class name */
        public class C0022con extends CursorAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final int f7769a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ RecycleListView f1796a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AlertController f1798a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final int f7770b;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0022con(Context context, Cursor cursor, boolean z2, RecycleListView recycleListView, AlertController alertController) {
                super(context, cursor, z2);
                this.f1796a = recycleListView;
                this.f1798a = alertController;
                Cursor cursor2 = getCursor();
                this.f7769a = cursor2.getColumnIndexOrThrow(con.this.f1775a);
                this.f7770b = cursor2.getColumnIndexOrThrow(con.this.f1783b);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                ((CheckedTextView) view.findViewById(R.id.text1)).setText(cursor.getString(this.f7769a));
                this.f1796a.setItemChecked(cursor.getPosition(), cursor.getInt(this.f7770b) == 1);
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return con.this.f1770a.inflate(this.f1798a.f7753l, viewGroup, false);
            }
        }

        public class nul implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AlertController f1799a;

            public nul(AlertController alertController) {
                this.f1799a = alertController;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
                con.this.f1789d.onClick(this.f1799a.f1732a, i2);
                if (con.this.f1792d) {
                    return;
                }
                this.f1799a.f1732a.dismiss();
            }
        }

        public class prn implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ RecycleListView f7772a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AlertController f1801a;

            public prn(RecycleListView recycleListView, AlertController alertController) {
                this.f7772a = recycleListView;
                this.f1801a = alertController;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
                boolean[] zArr = con.this.f1778a;
                if (zArr != null) {
                    zArr[i2] = this.f7772a.isItemChecked(i2);
                }
                con.this.f1767a.onClick(this.f1801a.f1732a, i2, this.f7772a.isItemChecked(i2));
            }
        }

        public con(Context context) {
            this.f1762a = context;
            this.f1770a = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        public void a(AlertController alertController) {
            View view = this.f1771a;
            if (view != null) {
                alertController.l(view);
            } else {
                CharSequence charSequence = this.f1774a;
                if (charSequence != null) {
                    alertController.q(charSequence);
                }
                Drawable drawable = this.f1769a;
                if (drawable != null) {
                    alertController.n(drawable);
                }
                int i2 = this.f7760a;
                if (i2 != 0) {
                    alertController.m(i2);
                }
                int i3 = this.f7761b;
                if (i3 != 0) {
                    alertController.m(alertController.d(i3));
                }
            }
            CharSequence charSequence2 = this.f1782b;
            if (charSequence2 != null) {
                alertController.o(charSequence2);
            }
            CharSequence charSequence3 = this.f1787c;
            if (charSequence3 != null || this.f1780b != null) {
                alertController.k(-1, charSequence3, this.f1764a, null, this.f1780b);
            }
            CharSequence charSequence4 = this.f1791d;
            if (charSequence4 != null || this.f1786c != null) {
                alertController.k(-2, charSequence4, this.f1779b, null, this.f1786c);
            }
            CharSequence charSequence5 = this.f1793e;
            if (charSequence5 != null || this.f1790d != null) {
                alertController.k(-3, charSequence5, this.f1785c, null, this.f1790d);
            }
            if (this.f1777a != null || this.f1768a != null || this.f1773a != null) {
                b(alertController);
            }
            View view2 = this.f1781b;
            if (view2 != null) {
                if (this.f1784b) {
                    alertController.t(view2, this.f7763d, this.f7764e, this.f7765f, this.f7766g);
                    return;
                } else {
                    alertController.s(view2);
                    return;
                }
            }
            int i4 = this.f7762c;
            if (i4 != 0) {
                alertController.r(i4);
            }
        }

        public final void b(AlertController alertController) {
            ListAdapter prnVar;
            RecycleListView recycleListView = (RecycleListView) this.f1770a.inflate(alertController.f7752k, (ViewGroup) null);
            if (this.f1788c) {
                prnVar = this.f1768a == null ? new aux(this.f1762a, alertController.f7753l, R.id.text1, this.f1777a, recycleListView) : new C0022con(this.f1762a, this.f1768a, false, recycleListView, alertController);
            } else {
                int i2 = this.f1792d ? alertController.f7754m : alertController.f7755n;
                if (this.f1768a != null) {
                    prnVar = new SimpleCursorAdapter(this.f1762a, i2, this.f1768a, new String[]{this.f1775a}, new int[]{R.id.text1});
                } else {
                    prnVar = this.f1773a;
                    if (prnVar == null) {
                        prnVar = new prn(this.f1762a, i2, R.id.text1, this.f1777a);
                    }
                }
            }
            alertController.f1742a = prnVar;
            alertController.f7749h = this.f7767h;
            if (this.f1789d != null) {
                recycleListView.setOnItemClickListener(new nul(alertController));
            } else if (this.f1767a != null) {
                recycleListView.setOnItemClickListener(new prn(recycleListView, alertController));
            }
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f1772a;
            if (onItemSelectedListener != null) {
                recycleListView.setOnItemSelectedListener(onItemSelectedListener);
            }
            if (this.f1792d) {
                recycleListView.setChoiceMode(1);
            } else if (this.f1788c) {
                recycleListView.setChoiceMode(2);
            }
            alertController.f1743a = recycleListView;
        }
    }

    public static final class nul extends Handler {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public WeakReference<DialogInterface> f7773a;

        public nul(DialogInterface dialogInterface) {
            this.f7773a = new WeakReference<>(dialogInterface);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == -3 || i2 == -2 || i2 == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick(this.f7773a.get(), message.what);
            } else {
                if (i2 != 1) {
                    return;
                }
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    public static class prn extends ArrayAdapter<CharSequence> {
        public prn(Context context, int i2, int i3, CharSequence[] charSequenceArr) {
            super(context, i2, i3, charSequenceArr);
        }

        @Override // android.widget.ArrayAdapter, android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, c cVar, Window window) {
        this.f1733a = context;
        this.f1732a = cVar;
        this.f1739a = window;
        this.f1735a = new nul(cVar);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, lpt3.f19g, com3.f5506n, 0);
        this.f7750i = typedArrayObtainStyledAttributes.getResourceId(lpt3.f5667z, 0);
        this.f7751j = typedArrayObtainStyledAttributes.getResourceId(lpt3.B, 0);
        this.f7752k = typedArrayObtainStyledAttributes.getResourceId(lpt3.D, 0);
        this.f7753l = typedArrayObtainStyledAttributes.getResourceId(lpt3.E, 0);
        this.f7754m = typedArrayObtainStyledAttributes.getResourceId(lpt3.G, 0);
        this.f7755n = typedArrayObtainStyledAttributes.getResourceId(lpt3.C, 0);
        this.f1754b = typedArrayObtainStyledAttributes.getBoolean(lpt3.F, true);
        this.f7742a = typedArrayObtainStyledAttributes.getDimensionPixelSize(lpt3.A, 0);
        typedArrayObtainStyledAttributes.recycle();
        cVar.e(1);
    }

    public static boolean a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    public static boolean z(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(com3.f5505m, typedValue, true);
        return typedValue.data != 0;
    }

    public final void b(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    public Button c(int i2) {
        if (i2 == -3) {
            return this.f1757c;
        }
        if (i2 == -2) {
            return this.f1751b;
        }
        if (i2 != -1) {
            return null;
        }
        return this.f1740a;
    }

    public int d(int i2) {
        TypedValue typedValue = new TypedValue();
        this.f1733a.getTheme().resolveAttribute(i2, typedValue, true);
        return typedValue.resourceId;
    }

    public ListView e() {
        return this.f1743a;
    }

    public void f() {
        this.f1732a.setContentView(j());
        y();
    }

    public boolean g(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f1745a;
        return nestedScrollView != null && nestedScrollView.r(keyEvent);
    }

    public boolean h(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f1745a;
        return nestedScrollView != null && nestedScrollView.r(keyEvent);
    }

    public final ViewGroup i(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    public final int j() {
        int i2 = this.f7751j;
        return (i2 != 0 && this.f7756o == 1) ? i2 : this.f7750i;
    }

    public void k(int i2, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.f1735a.obtainMessage(i2, onClickListener);
        }
        if (i2 == -3) {
            this.f1761e = charSequence;
            this.f1756c = message;
            this.f1755c = drawable;
        } else if (i2 == -2) {
            this.f1760d = charSequence;
            this.f1749b = message;
            this.f1748b = drawable;
        } else {
            if (i2 != -1) {
                throw new IllegalArgumentException("Button does not exist");
            }
            this.f1758c = charSequence;
            this.f1736a = message;
            this.f1734a = drawable;
        }
    }

    public void l(View view) {
        this.f1750b = view;
    }

    public void m(int i2) {
        this.f1759d = null;
        this.f7748g = i2;
        ImageView imageView = this.f1741a;
        if (imageView != null) {
            if (i2 == 0) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.f1741a.setImageResource(this.f7748g);
            }
        }
    }

    public void n(Drawable drawable) {
        this.f1759d = drawable;
        this.f7748g = 0;
        ImageView imageView = this.f1741a;
        if (imageView != null) {
            if (drawable == null) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.f1741a.setImageDrawable(drawable);
            }
        }
    }

    public void o(CharSequence charSequence) {
        this.f1753b = charSequence;
        TextView textView = this.f1752b;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public final void p(ViewGroup viewGroup, View view, int i2, int i3) {
        View viewFindViewById = this.f1739a.findViewById(com8.f5585u);
        View viewFindViewById2 = this.f1739a.findViewById(com8.f5584t);
        y.F0(view, i2, i3);
        if (viewFindViewById != null) {
            viewGroup.removeView(viewFindViewById);
        }
        if (viewFindViewById2 != null) {
            viewGroup.removeView(viewFindViewById2);
        }
    }

    public void q(CharSequence charSequence) {
        this.f1746a = charSequence;
        TextView textView = this.f1744a;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void r(int i2) {
        this.f1738a = null;
        this.f7743b = i2;
        this.f1747a = false;
    }

    public void s(View view) {
        this.f1738a = view;
        this.f7743b = 0;
        this.f1747a = false;
    }

    public void t(View view, int i2, int i3, int i4, int i5) {
        this.f1738a = view;
        this.f7743b = 0;
        this.f1747a = true;
        this.f7744c = i2;
        this.f7745d = i3;
        this.f7746e = i4;
        this.f7747f = i5;
    }

    public final void u(ViewGroup viewGroup) {
        int i2;
        Button button = (Button) viewGroup.findViewById(R.id.button1);
        this.f1740a = button;
        button.setOnClickListener(this.f1737a);
        if (TextUtils.isEmpty(this.f1758c) && this.f1734a == null) {
            this.f1740a.setVisibility(8);
            i2 = 0;
        } else {
            this.f1740a.setText(this.f1758c);
            Drawable drawable = this.f1734a;
            if (drawable != null) {
                int i3 = this.f7742a;
                drawable.setBounds(0, 0, i3, i3);
                this.f1740a.setCompoundDrawables(this.f1734a, null, null, null);
            }
            this.f1740a.setVisibility(0);
            i2 = 1;
        }
        Button button2 = (Button) viewGroup.findViewById(R.id.button2);
        this.f1751b = button2;
        button2.setOnClickListener(this.f1737a);
        if (TextUtils.isEmpty(this.f1760d) && this.f1748b == null) {
            this.f1751b.setVisibility(8);
        } else {
            this.f1751b.setText(this.f1760d);
            Drawable drawable2 = this.f1748b;
            if (drawable2 != null) {
                int i4 = this.f7742a;
                drawable2.setBounds(0, 0, i4, i4);
                this.f1751b.setCompoundDrawables(this.f1748b, null, null, null);
            }
            this.f1751b.setVisibility(0);
            i2 |= 2;
        }
        Button button3 = (Button) viewGroup.findViewById(R.id.button3);
        this.f1757c = button3;
        button3.setOnClickListener(this.f1737a);
        if (TextUtils.isEmpty(this.f1761e) && this.f1755c == null) {
            this.f1757c.setVisibility(8);
        } else {
            this.f1757c.setText(this.f1761e);
            Drawable drawable3 = this.f1755c;
            if (drawable3 != null) {
                int i5 = this.f7742a;
                drawable3.setBounds(0, 0, i5, i5);
                this.f1757c.setCompoundDrawables(this.f1755c, null, null, null);
            }
            this.f1757c.setVisibility(0);
            i2 |= 4;
        }
        if (z(this.f1733a)) {
            if (i2 == 1) {
                b(this.f1740a);
            } else if (i2 == 2) {
                b(this.f1751b);
            } else if (i2 == 4) {
                b(this.f1757c);
            }
        }
        if (i2 != 0) {
            return;
        }
        viewGroup.setVisibility(8);
    }

    public final void v(ViewGroup viewGroup) {
        NestedScrollView nestedScrollView = (NestedScrollView) this.f1739a.findViewById(com8.f5586v);
        this.f1745a = nestedScrollView;
        nestedScrollView.setFocusable(false);
        this.f1745a.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroup.findViewById(R.id.message);
        this.f1752b = textView;
        if (textView == null) {
            return;
        }
        CharSequence charSequence = this.f1753b;
        if (charSequence != null) {
            textView.setText(charSequence);
            return;
        }
        textView.setVisibility(8);
        this.f1745a.removeView(this.f1752b);
        if (this.f1743a == null) {
            viewGroup.setVisibility(8);
            return;
        }
        ViewGroup viewGroup2 = (ViewGroup) this.f1745a.getParent();
        int iIndexOfChild = viewGroup2.indexOfChild(this.f1745a);
        viewGroup2.removeViewAt(iIndexOfChild);
        viewGroup2.addView(this.f1743a, iIndexOfChild, new ViewGroup.LayoutParams(-1, -1));
    }

    public final void w(ViewGroup viewGroup) {
        View viewInflate = this.f1738a;
        if (viewInflate == null) {
            viewInflate = this.f7743b != 0 ? LayoutInflater.from(this.f1733a).inflate(this.f7743b, viewGroup, false) : null;
        }
        boolean z2 = viewInflate != null;
        if (!z2 || !a(viewInflate)) {
            this.f1739a.setFlags(inet.ipaddr.format.validate.aux.KEY_SINGLE_WILDCARD, inet.ipaddr.format.validate.aux.KEY_SINGLE_WILDCARD);
        }
        if (!z2) {
            viewGroup.setVisibility(8);
            return;
        }
        FrameLayout frameLayout = (FrameLayout) this.f1739a.findViewById(com8.f5578n);
        frameLayout.addView(viewInflate, new ViewGroup.LayoutParams(-1, -1));
        if (this.f1747a) {
            frameLayout.setPadding(this.f7744c, this.f7745d, this.f7746e, this.f7747f);
        }
        if (this.f1743a != null) {
            ((LinearLayout.LayoutParams) ((androidx.appcompat.widget.con.aux) viewGroup.getLayoutParams())).weight = 0.0f;
        }
    }

    public final void x(ViewGroup viewGroup) {
        if (this.f1750b != null) {
            viewGroup.addView(this.f1750b, 0, new ViewGroup.LayoutParams(-1, -2));
            this.f1739a.findViewById(com8.N).setVisibility(8);
            return;
        }
        this.f1741a = (ImageView) this.f1739a.findViewById(R.id.icon);
        if (!(!TextUtils.isEmpty(this.f1746a)) || !this.f1754b) {
            this.f1739a.findViewById(com8.N).setVisibility(8);
            this.f1741a.setVisibility(8);
            viewGroup.setVisibility(8);
            return;
        }
        TextView textView = (TextView) this.f1739a.findViewById(com8.f5574j);
        this.f1744a = textView;
        textView.setText(this.f1746a);
        int i2 = this.f7748g;
        if (i2 != 0) {
            this.f1741a.setImageResource(i2);
            return;
        }
        Drawable drawable = this.f1759d;
        if (drawable != null) {
            this.f1741a.setImageDrawable(drawable);
        } else {
            this.f1744a.setPadding(this.f1741a.getPaddingLeft(), this.f1741a.getPaddingTop(), this.f1741a.getPaddingRight(), this.f1741a.getPaddingBottom());
            this.f1741a.setVisibility(8);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void y() {
        View viewFindViewById;
        ListAdapter listAdapter;
        View viewFindViewById2;
        View viewFindViewById3 = this.f1739a.findViewById(com8.f5583s);
        int i2 = com8.O;
        View viewFindViewById4 = viewFindViewById3.findViewById(i2);
        int i3 = com8.f5577m;
        View viewFindViewById5 = viewFindViewById3.findViewById(i3);
        int i4 = com8.f5575k;
        View viewFindViewById6 = viewFindViewById3.findViewById(i4);
        ViewGroup viewGroup = (ViewGroup) viewFindViewById3.findViewById(com8.f5579o);
        w(viewGroup);
        View viewFindViewById7 = viewGroup.findViewById(i2);
        View viewFindViewById8 = viewGroup.findViewById(i3);
        View viewFindViewById9 = viewGroup.findViewById(i4);
        ViewGroup viewGroupI = i(viewFindViewById7, viewFindViewById4);
        ViewGroup viewGroupI2 = i(viewFindViewById8, viewFindViewById5);
        ViewGroup viewGroupI3 = i(viewFindViewById9, viewFindViewById6);
        v(viewGroupI2);
        u(viewGroupI3);
        x(viewGroupI);
        boolean z2 = viewGroup.getVisibility() != 8;
        boolean z3 = (viewGroupI == null || viewGroupI.getVisibility() == 8) ? 0 : 1;
        boolean z4 = (viewGroupI3 == null || viewGroupI3.getVisibility() == 8) ? false : true;
        if (!z4 && viewGroupI2 != null && (viewFindViewById2 = viewGroupI2.findViewById(com8.J)) != null) {
            viewFindViewById2.setVisibility(0);
        }
        if (z3 != 0) {
            NestedScrollView nestedScrollView = this.f1745a;
            if (nestedScrollView != null) {
                nestedScrollView.setClipToPadding(true);
            }
            View viewFindViewById10 = (this.f1753b == null && this.f1743a == null) ? null : viewGroupI.findViewById(com8.M);
            if (viewFindViewById10 != null) {
                viewFindViewById10.setVisibility(0);
            }
        } else if (viewGroupI2 != null && (viewFindViewById = viewGroupI2.findViewById(com8.K)) != null) {
            viewFindViewById.setVisibility(0);
        }
        ListView listView = this.f1743a;
        if (listView instanceof RecycleListView) {
            ((RecycleListView) listView).a(z3, z4);
        }
        if (!z2) {
            View view = this.f1743a;
            if (view == null) {
                view = this.f1745a;
            }
            if (view != null) {
                p(viewGroupI2, view, z3 | (z4 ? 2 : 0), 3);
            }
        }
        ListView listView2 = this.f1743a;
        if (listView2 == null || (listAdapter = this.f1742a) == null) {
            return;
        }
        listView2.setAdapter(listAdapter);
        int i5 = this.f7749h;
        if (i5 > -1) {
            listView2.setItemChecked(i5, true);
            listView2.setSelection(i5);
        }
    }
}
