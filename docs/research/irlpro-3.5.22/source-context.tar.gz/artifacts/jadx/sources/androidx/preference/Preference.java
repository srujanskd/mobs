package androidx.preference;

import android.R;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.AbsSavedState;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt2;
import p016CoM4.lpt4;
import p016CoM4.lpt5;
import p016CoM4.lpt7;
import p024Com2.y;
import p081cOm2.e2;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class Preference implements Comparable<Preference> {
    private static final String CLIPBOARD_ID = "Preference";
    public static final int DEFAULT_ORDER = Integer.MAX_VALUE;
    private boolean mAllowDividerAbove;
    private boolean mAllowDividerBelow;
    private boolean mBaseMethodCalled;
    private final View.OnClickListener mClickListener;
    private final Context mContext;
    private boolean mCopyingEnabled;
    private Object mDefaultValue;
    private String mDependencyKey;
    private boolean mDependencyMet;
    private List<Preference> mDependents;
    private boolean mEnabled;
    private Bundle mExtras;
    private String mFragment;
    private boolean mHasId;
    private boolean mHasSingleLineTitleAttr;
    private Drawable mIcon;
    private int mIconResId;
    private boolean mIconSpaceReserved;
    private long mId;
    private Intent mIntent;
    private String mKey;
    private int mLayoutResId;
    private nul mListener;
    private prn mOnChangeListener;
    private com1 mOnClickListener;
    private com2 mOnCopyListener;
    private int mOrder;
    private boolean mParentDependencyMet;
    private PreferenceGroup mParentGroup;
    private boolean mPersistent;
    private p016CoM4.com1 mPreferenceDataStore;
    private androidx.preference.nul mPreferenceManager;
    private boolean mRequiresKey;
    private boolean mSelectable;
    private boolean mShouldDisableView;
    private boolean mSingleLineTitle;
    private CharSequence mSummary;
    private com3 mSummaryProvider;
    private CharSequence mTitle;
    private int mViewId;
    private boolean mVisible;
    private boolean mWasDetached;
    private int mWidgetLayoutResId;

    public class aux implements View.OnClickListener {
        public aux() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Preference.this.performClick(view);
        }
    }

    public interface com1 {
        boolean a(Preference preference);
    }

    public static class com2 implements View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Preference f8446a;

        public com2(Preference preference) {
            this.f8446a = preference;
        }

        @Override // android.view.View.OnCreateContextMenuListener
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
            CharSequence summary = this.f8446a.getSummary();
            if (!this.f8446a.isCopyingEnabled() || TextUtils.isEmpty(summary)) {
                return;
            }
            contextMenu.setHeaderTitle(summary);
            contextMenu.add(0, 0, 0, lpt5.f6197a).setOnMenuItemClickListener(this);
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            ClipboardManager clipboardManager = (ClipboardManager) this.f8446a.getContext().getSystemService("clipboard");
            CharSequence summary = this.f8446a.getSummary();
            clipboardManager.setPrimaryClip(ClipData.newPlainText(Preference.CLIPBOARD_ID, summary));
            Toast.makeText(this.f8446a.getContext(), this.f8446a.getContext().getString(lpt5.f6200d, summary), 0).show();
            return true;
        }
    }

    public interface com3<T extends Preference> {
        CharSequence a(T t2);
    }

    public static class con extends AbsSavedState {
        public static final Parcelable.Creator<con> CREATOR = new aux();

        public class aux implements Parcelable.Creator<con> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public con createFromParcel(Parcel parcel) {
                return new con(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public con[] newArray(int i2) {
                return new con[i2];
            }
        }

        public con(Parcel parcel) {
            super(parcel);
        }

        public con(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public interface nul {
        void a(Preference preference);

        void b(Preference preference);

        void c(Preference preference);
    }

    public interface prn {
        boolean a(Preference preference, Object obj);
    }

    public Preference(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.mOrder = DEFAULT_ORDER;
        this.mViewId = 0;
        this.mEnabled = true;
        this.mSelectable = true;
        this.mPersistent = true;
        this.mDependencyMet = true;
        this.mParentDependencyMet = true;
        this.mVisible = true;
        this.mAllowDividerAbove = true;
        this.mAllowDividerBelow = true;
        this.mSingleLineTitle = true;
        this.mShouldDisableView = true;
        int i4 = lpt4.f6194b;
        this.mLayoutResId = i4;
        this.mClickListener = new aux();
        this.mContext = context;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f534g, i2, i3);
        this.mIconResId = l0.e(typedArrayObtainStyledAttributes, lpt7.f6204a0, lpt7.D, 0);
        this.mKey = l0.f(typedArrayObtainStyledAttributes, lpt7.f6210d0, lpt7.J);
        this.mTitle = l0.g(typedArrayObtainStyledAttributes, lpt7.f6226l0, lpt7.H);
        this.mSummary = l0.g(typedArrayObtainStyledAttributes, lpt7.f6224k0, lpt7.K);
        this.mOrder = l0.d(typedArrayObtainStyledAttributes, lpt7.f6214f0, lpt7.L, DEFAULT_ORDER);
        this.mFragment = l0.f(typedArrayObtainStyledAttributes, lpt7.Z, lpt7.Q);
        this.mLayoutResId = l0.e(typedArrayObtainStyledAttributes, lpt7.f6212e0, lpt7.G, i4);
        this.mWidgetLayoutResId = l0.e(typedArrayObtainStyledAttributes, lpt7.f6228m0, lpt7.M, 0);
        this.mEnabled = l0.b(typedArrayObtainStyledAttributes, lpt7.Y, lpt7.F, true);
        this.mSelectable = l0.b(typedArrayObtainStyledAttributes, lpt7.f6218h0, lpt7.I, true);
        this.mPersistent = l0.b(typedArrayObtainStyledAttributes, lpt7.f6216g0, lpt7.E, true);
        this.mDependencyKey = l0.f(typedArrayObtainStyledAttributes, lpt7.W, lpt7.N);
        int i5 = lpt7.T;
        this.mAllowDividerAbove = l0.b(typedArrayObtainStyledAttributes, i5, i5, this.mSelectable);
        int i6 = lpt7.U;
        this.mAllowDividerBelow = l0.b(typedArrayObtainStyledAttributes, i6, i6, this.mSelectable);
        int i7 = lpt7.V;
        if (typedArrayObtainStyledAttributes.hasValue(i7)) {
            this.mDefaultValue = onGetDefaultValue(typedArrayObtainStyledAttributes, i7);
        } else {
            int i8 = lpt7.O;
            if (typedArrayObtainStyledAttributes.hasValue(i8)) {
                this.mDefaultValue = onGetDefaultValue(typedArrayObtainStyledAttributes, i8);
            }
        }
        this.mShouldDisableView = l0.b(typedArrayObtainStyledAttributes, lpt7.f6220i0, lpt7.P, true);
        int i9 = lpt7.f6222j0;
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(i9);
        this.mHasSingleLineTitleAttr = zHasValue;
        if (zHasValue) {
            this.mSingleLineTitle = l0.b(typedArrayObtainStyledAttributes, i9, lpt7.R, true);
        }
        this.mIconSpaceReserved = l0.b(typedArrayObtainStyledAttributes, lpt7.f6206b0, lpt7.S, false);
        int i10 = lpt7.f6208c0;
        this.mVisible = l0.b(typedArrayObtainStyledAttributes, i10, i10, true);
        int i11 = lpt7.X;
        this.mCopyingEnabled = l0.b(typedArrayObtainStyledAttributes, i11, i11, false);
        typedArrayObtainStyledAttributes.recycle();
    }

    private void dispatchSetInitialValue() {
        getPreferenceDataStore();
        if (shouldPersist() && getSharedPreferences().contains(this.mKey)) {
            onSetInitialValue(true, null);
            return;
        }
        Object obj = this.mDefaultValue;
        if (obj != null) {
            onSetInitialValue(false, obj);
        }
    }

    private void registerDependency() {
        if (TextUtils.isEmpty(this.mDependencyKey)) {
            return;
        }
        Preference preferenceFindPreferenceInHierarchy = findPreferenceInHierarchy(this.mDependencyKey);
        if (preferenceFindPreferenceInHierarchy != null) {
            preferenceFindPreferenceInHierarchy.registerDependent(this);
            return;
        }
        throw new IllegalStateException("Dependency \"" + this.mDependencyKey + "\" not found for preference \"" + this.mKey + "\" (title: \"" + ((Object) this.mTitle) + "\"");
    }

    private void registerDependent(Preference preference) {
        if (this.mDependents == null) {
            this.mDependents = new ArrayList();
        }
        this.mDependents.add(preference);
        preference.onDependencyChanged(this, shouldDisableDependents());
    }

    private void setEnabledStateOnViews(View view, boolean z2) {
        view.setEnabled(z2);
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                setEnabledStateOnViews(viewGroup.getChildAt(childCount), z2);
            }
        }
    }

    private void tryCommit(SharedPreferences.Editor editor) {
        if (this.mPreferenceManager.u()) {
            editor.apply();
        }
    }

    private void unregisterDependency() {
        Preference preferenceFindPreferenceInHierarchy;
        String str = this.mDependencyKey;
        if (str == null || (preferenceFindPreferenceInHierarchy = findPreferenceInHierarchy(str)) == null) {
            return;
        }
        preferenceFindPreferenceInHierarchy.unregisterDependent(this);
    }

    private void unregisterDependent(Preference preference) {
        List<Preference> list = this.mDependents;
        if (list != null) {
            list.remove(preference);
        }
    }

    public void assignParent(PreferenceGroup preferenceGroup) {
        if (preferenceGroup != null && this.mParentGroup != null) {
            throw new IllegalStateException("This preference already has a parent. You must remove the existing parent before assigning a new one.");
        }
        this.mParentGroup = preferenceGroup;
    }

    public boolean callChangeListener(Object obj) {
        prn prnVar = this.mOnChangeListener;
        return prnVar == null || prnVar.a(this, obj);
    }

    public final void clearWasDetached() {
        this.mWasDetached = false;
    }

    public void dispatchRestoreInstanceState(Bundle bundle) {
        Parcelable parcelable;
        if (!hasKey() || (parcelable = bundle.getParcelable(this.mKey)) == null) {
            return;
        }
        this.mBaseMethodCalled = false;
        onRestoreInstanceState(parcelable);
        if (!this.mBaseMethodCalled) {
            throw new IllegalStateException("Derived class did not call super.onRestoreInstanceState()");
        }
    }

    public void dispatchSaveInstanceState(Bundle bundle) {
        if (hasKey()) {
            this.mBaseMethodCalled = false;
            Parcelable parcelableOnSaveInstanceState = onSaveInstanceState();
            if (!this.mBaseMethodCalled) {
                throw new IllegalStateException("Derived class did not call super.onSaveInstanceState()");
            }
            if (parcelableOnSaveInstanceState != null) {
                bundle.putParcelable(this.mKey, parcelableOnSaveInstanceState);
            }
        }
    }

    public <T extends Preference> T findPreferenceInHierarchy(String str) {
        androidx.preference.nul nulVar = this.mPreferenceManager;
        if (nulVar == null) {
            return null;
        }
        return (T) nulVar.b(str);
    }

    public Context getContext() {
        return this.mContext;
    }

    public String getDependency() {
        return this.mDependencyKey;
    }

    public Bundle getExtras() {
        if (this.mExtras == null) {
            this.mExtras = new Bundle();
        }
        return this.mExtras;
    }

    public StringBuilder getFilterableStringBuilder() {
        StringBuilder sb = new StringBuilder();
        CharSequence title = getTitle();
        if (!TextUtils.isEmpty(title)) {
            sb.append(title);
            sb.append(' ');
        }
        CharSequence summary = getSummary();
        if (!TextUtils.isEmpty(summary)) {
            sb.append(summary);
            sb.append(' ');
        }
        if (sb.length() > 0) {
            sb.setLength(sb.length() - 1);
        }
        return sb;
    }

    public String getFragment() {
        return this.mFragment;
    }

    public Drawable getIcon() {
        int i2;
        if (this.mIcon == null && (i2 = this.mIconResId) != 0) {
            this.mIcon = AUX.aux.b(this.mContext, i2);
        }
        return this.mIcon;
    }

    long getId() {
        return this.mId;
    }

    public Intent getIntent() {
        return this.mIntent;
    }

    public String getKey() {
        return this.mKey;
    }

    public final int getLayoutResource() {
        return this.mLayoutResId;
    }

    public prn getOnPreferenceChangeListener() {
        return this.mOnChangeListener;
    }

    public com1 getOnPreferenceClickListener() {
        return this.mOnClickListener;
    }

    public int getOrder() {
        return this.mOrder;
    }

    public PreferenceGroup getParent() {
        return this.mParentGroup;
    }

    public boolean getPersistedBoolean(boolean z2) {
        if (!shouldPersist()) {
            return z2;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m().getBoolean(this.mKey, z2);
    }

    public float getPersistedFloat(float f2) {
        if (!shouldPersist()) {
            return f2;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m().getFloat(this.mKey, f2);
    }

    public int getPersistedInt(int i2) {
        if (!shouldPersist()) {
            return i2;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m().getInt(this.mKey, i2);
    }

    public long getPersistedLong(long j2) {
        if (!shouldPersist()) {
            return j2;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m().getLong(this.mKey, j2);
    }

    public String getPersistedString(String str) {
        if (!shouldPersist()) {
            return str;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m().getString(this.mKey, str);
    }

    public Set<String> getPersistedStringSet(Set<String> set) {
        if (!shouldPersist()) {
            return set;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m().getStringSet(this.mKey, set);
    }

    public p016CoM4.com1 getPreferenceDataStore() {
        androidx.preference.nul nulVar = this.mPreferenceManager;
        if (nulVar != null) {
            nulVar.k();
        }
        return null;
    }

    public androidx.preference.nul getPreferenceManager() {
        return this.mPreferenceManager;
    }

    public SharedPreferences getSharedPreferences() {
        if (this.mPreferenceManager == null) {
            return null;
        }
        getPreferenceDataStore();
        return this.mPreferenceManager.m();
    }

    public boolean getShouldDisableView() {
        return this.mShouldDisableView;
    }

    public CharSequence getSummary() {
        return getSummaryProvider() != null ? getSummaryProvider().a(this) : this.mSummary;
    }

    public final com3 getSummaryProvider() {
        return this.mSummaryProvider;
    }

    public CharSequence getTitle() {
        return this.mTitle;
    }

    public final int getWidgetLayoutResource() {
        return this.mWidgetLayoutResId;
    }

    public boolean hasKey() {
        return !TextUtils.isEmpty(this.mKey);
    }

    public boolean isCopyingEnabled() {
        return this.mCopyingEnabled;
    }

    public boolean isEnabled() {
        return this.mEnabled && this.mDependencyMet && this.mParentDependencyMet;
    }

    public boolean isIconSpaceReserved() {
        return this.mIconSpaceReserved;
    }

    public boolean isPersistent() {
        return this.mPersistent;
    }

    public boolean isSelectable() {
        return this.mSelectable;
    }

    public final boolean isShown() {
        if (!isVisible() || getPreferenceManager() == null) {
            return false;
        }
        if (this == getPreferenceManager().l()) {
            return true;
        }
        PreferenceGroup parent = getParent();
        if (parent == null) {
            return false;
        }
        return parent.isShown();
    }

    public boolean isSingleLineTitle() {
        return this.mSingleLineTitle;
    }

    public final boolean isVisible() {
        return this.mVisible;
    }

    public void notifyChanged() {
        nul nulVar = this.mListener;
        if (nulVar != null) {
            nulVar.a(this);
        }
    }

    public void notifyDependencyChange(boolean z2) {
        List<Preference> list = this.mDependents;
        if (list == null) {
            return;
        }
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            list.get(i2).onDependencyChanged(this, z2);
        }
    }

    public void notifyHierarchyChanged() {
        nul nulVar = this.mListener;
        if (nulVar != null) {
            nulVar.b(this);
        }
    }

    public void onAttached() {
        registerDependency();
    }

    public void onAttachedToHierarchy(androidx.preference.nul nulVar) {
        this.mPreferenceManager = nulVar;
        if (!this.mHasId) {
            this.mId = nulVar.g();
        }
        dispatchSetInitialValue();
    }

    public void onBindViewHolder(com7 com7Var) {
        Integer numValueOf;
        View view = ((RecyclerView.h) com7Var).f2786a;
        view.setOnClickListener(this.mClickListener);
        view.setId(this.mViewId);
        TextView textView = (TextView) com7Var.M(R.id.summary);
        if (textView != null) {
            CharSequence summary = getSummary();
            if (TextUtils.isEmpty(summary)) {
                textView.setVisibility(8);
                numValueOf = null;
            } else {
                textView.setText(summary);
                textView.setVisibility(0);
                numValueOf = Integer.valueOf(textView.getCurrentTextColor());
            }
        } else {
            numValueOf = null;
        }
        TextView textView2 = (TextView) com7Var.M(R.id.title);
        if (textView2 != null) {
            CharSequence title = getTitle();
            if (TextUtils.isEmpty(title)) {
                textView2.setVisibility(8);
            } else {
                textView2.setText(title);
                textView2.setVisibility(0);
                if (this.mHasSingleLineTitleAttr) {
                    textView2.setSingleLine(this.mSingleLineTitle);
                }
                if (!isSelectable() && isEnabled() && numValueOf != null) {
                    textView2.setTextColor(numValueOf.intValue());
                }
            }
        }
        ImageView imageView = (ImageView) com7Var.M(R.id.icon);
        if (imageView != null) {
            int i2 = this.mIconResId;
            if (i2 != 0 || this.mIcon != null) {
                if (this.mIcon == null) {
                    this.mIcon = AUX.aux.b(this.mContext, i2);
                }
                Drawable drawable = this.mIcon;
                if (drawable != null) {
                    imageView.setImageDrawable(drawable);
                }
            }
            if (this.mIcon != null) {
                imageView.setVisibility(0);
            } else {
                imageView.setVisibility(this.mIconSpaceReserved ? 4 : 8);
            }
        }
        View viewM = com7Var.M(lpt2.f6182a);
        if (viewM == null) {
            viewM = com7Var.M(R.id.icon_frame);
        }
        if (viewM != null) {
            if (this.mIcon != null) {
                viewM.setVisibility(0);
            } else {
                viewM.setVisibility(this.mIconSpaceReserved ? 4 : 8);
            }
        }
        if (this.mShouldDisableView) {
            setEnabledStateOnViews(view, isEnabled());
        } else {
            setEnabledStateOnViews(view, true);
        }
        boolean zIsSelectable = isSelectable();
        view.setFocusable(zIsSelectable);
        view.setClickable(zIsSelectable);
        com7Var.Q(this.mAllowDividerAbove);
        com7Var.R(this.mAllowDividerBelow);
        boolean zIsCopyingEnabled = isCopyingEnabled();
        if (zIsCopyingEnabled && this.mOnCopyListener == null) {
            this.mOnCopyListener = new com2(this);
        }
        view.setOnCreateContextMenuListener(zIsCopyingEnabled ? this.mOnCopyListener : null);
        view.setLongClickable(zIsCopyingEnabled);
        if (!zIsCopyingEnabled || zIsSelectable) {
            return;
        }
        y.s0(view, null);
    }

    public void onClick() {
    }

    public void onDependencyChanged(Preference preference, boolean z2) {
        if (this.mDependencyMet == z2) {
            this.mDependencyMet = !z2;
            notifyDependencyChange(shouldDisableDependents());
            notifyChanged();
        }
    }

    public void onDetached() {
        unregisterDependency();
        this.mWasDetached = true;
    }

    public Object onGetDefaultValue(TypedArray typedArray, int i2) {
        return null;
    }

    @Deprecated
    public void onInitializeAccessibilityNodeInfo(e2 e2Var) {
    }

    public void onParentChanged(Preference preference, boolean z2) {
        if (this.mParentDependencyMet == z2) {
            this.mParentDependencyMet = !z2;
            notifyDependencyChange(shouldDisableDependents());
            notifyChanged();
        }
    }

    public void onPrepareForRemoval() {
        unregisterDependency();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        this.mBaseMethodCalled = true;
        if (parcelable != AbsSavedState.EMPTY_STATE && parcelable != null) {
            throw new IllegalArgumentException("Wrong state class -- expecting Preference State");
        }
    }

    public Parcelable onSaveInstanceState() {
        this.mBaseMethodCalled = true;
        return AbsSavedState.EMPTY_STATE;
    }

    public void onSetInitialValue(Object obj) {
    }

    @Deprecated
    public void onSetInitialValue(boolean z2, Object obj) {
        onSetInitialValue(obj);
    }

    public Bundle peekExtras() {
        return this.mExtras;
    }

    public void performClick(View view) {
        performClick();
    }

    public boolean persistBoolean(boolean z2) {
        if (!shouldPersist()) {
            return false;
        }
        if (z2 == getPersistedBoolean(!z2)) {
            return true;
        }
        getPreferenceDataStore();
        SharedPreferences.Editor editorF = this.mPreferenceManager.f();
        editorF.putBoolean(this.mKey, z2);
        tryCommit(editorF);
        return true;
    }

    public boolean persistFloat(float f2) {
        if (!shouldPersist()) {
            return false;
        }
        if (f2 == getPersistedFloat(Float.NaN)) {
            return true;
        }
        getPreferenceDataStore();
        SharedPreferences.Editor editorF = this.mPreferenceManager.f();
        editorF.putFloat(this.mKey, f2);
        tryCommit(editorF);
        return true;
    }

    public boolean persistInt(int i2) {
        if (!shouldPersist()) {
            return false;
        }
        if (i2 == getPersistedInt(~i2)) {
            return true;
        }
        getPreferenceDataStore();
        SharedPreferences.Editor editorF = this.mPreferenceManager.f();
        editorF.putInt(this.mKey, i2);
        tryCommit(editorF);
        return true;
    }

    public boolean persistLong(long j2) {
        if (!shouldPersist()) {
            return false;
        }
        if (j2 == getPersistedLong(~j2)) {
            return true;
        }
        getPreferenceDataStore();
        SharedPreferences.Editor editorF = this.mPreferenceManager.f();
        editorF.putLong(this.mKey, j2);
        tryCommit(editorF);
        return true;
    }

    public boolean persistString(String str) {
        if (!shouldPersist()) {
            return false;
        }
        if (TextUtils.equals(str, getPersistedString(null))) {
            return true;
        }
        getPreferenceDataStore();
        SharedPreferences.Editor editorF = this.mPreferenceManager.f();
        editorF.putString(this.mKey, str);
        tryCommit(editorF);
        return true;
    }

    public boolean persistStringSet(Set<String> set) {
        if (!shouldPersist()) {
            return false;
        }
        if (set.equals(getPersistedStringSet(null))) {
            return true;
        }
        getPreferenceDataStore();
        SharedPreferences.Editor editorF = this.mPreferenceManager.f();
        editorF.putStringSet(this.mKey, set);
        tryCommit(editorF);
        return true;
    }

    public void requireKey() {
        if (TextUtils.isEmpty(this.mKey)) {
            throw new IllegalStateException("Preference does not have a key assigned.");
        }
        this.mRequiresKey = true;
    }

    public void restoreHierarchyState(Bundle bundle) {
        dispatchRestoreInstanceState(bundle);
    }

    public void saveHierarchyState(Bundle bundle) {
        dispatchSaveInstanceState(bundle);
    }

    public void setCopyingEnabled(boolean z2) {
        if (this.mCopyingEnabled != z2) {
            this.mCopyingEnabled = z2;
            notifyChanged();
        }
    }

    public void setDefaultValue(Object obj) {
        this.mDefaultValue = obj;
    }

    public void setDependency(String str) {
        unregisterDependency();
        this.mDependencyKey = str;
        registerDependency();
    }

    public void setEnabled(boolean z2) {
        if (this.mEnabled != z2) {
            this.mEnabled = z2;
            notifyDependencyChange(shouldDisableDependents());
            notifyChanged();
        }
    }

    public void setFragment(String str) {
        this.mFragment = str;
    }

    public void setIcon(Drawable drawable) {
        if (this.mIcon != drawable) {
            this.mIcon = drawable;
            this.mIconResId = 0;
            notifyChanged();
        }
    }

    public void setIconSpaceReserved(boolean z2) {
        if (this.mIconSpaceReserved != z2) {
            this.mIconSpaceReserved = z2;
            notifyChanged();
        }
    }

    public void setIntent(Intent intent) {
        this.mIntent = intent;
    }

    public void setKey(String str) {
        this.mKey = str;
        if (!this.mRequiresKey || hasKey()) {
            return;
        }
        requireKey();
    }

    public void setLayoutResource(int i2) {
        this.mLayoutResId = i2;
    }

    public final void setOnPreferenceChangeInternalListener(nul nulVar) {
        this.mListener = nulVar;
    }

    public void setOnPreferenceChangeListener(prn prnVar) {
        this.mOnChangeListener = prnVar;
    }

    public void setOnPreferenceClickListener(com1 com1Var) {
        this.mOnClickListener = com1Var;
    }

    public void setOrder(int i2) {
        if (i2 != this.mOrder) {
            this.mOrder = i2;
            notifyHierarchyChanged();
        }
    }

    public void setPersistent(boolean z2) {
        this.mPersistent = z2;
    }

    public void setPreferenceDataStore(p016CoM4.com1 com1Var) {
    }

    public void setSelectable(boolean z2) {
        if (this.mSelectable != z2) {
            this.mSelectable = z2;
            notifyChanged();
        }
    }

    public void setShouldDisableView(boolean z2) {
        if (this.mShouldDisableView != z2) {
            this.mShouldDisableView = z2;
            notifyChanged();
        }
    }

    public void setSingleLineTitle(boolean z2) {
        this.mHasSingleLineTitleAttr = true;
        this.mSingleLineTitle = z2;
    }

    public void setSummary(CharSequence charSequence) {
        if (getSummaryProvider() != null) {
            throw new IllegalStateException("Preference already has a SummaryProvider set.");
        }
        if (TextUtils.equals(this.mSummary, charSequence)) {
            return;
        }
        this.mSummary = charSequence;
        notifyChanged();
    }

    public final void setSummaryProvider(com3 com3Var) {
        this.mSummaryProvider = com3Var;
        notifyChanged();
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.equals(charSequence, this.mTitle)) {
            return;
        }
        this.mTitle = charSequence;
        notifyChanged();
    }

    public void setViewId(int i2) {
        this.mViewId = i2;
    }

    public final void setVisible(boolean z2) {
        if (this.mVisible != z2) {
            this.mVisible = z2;
            nul nulVar = this.mListener;
            if (nulVar != null) {
                nulVar.c(this);
            }
        }
    }

    public void setWidgetLayoutResource(int i2) {
        this.mWidgetLayoutResId = i2;
    }

    public boolean shouldDisableDependents() {
        return !isEnabled();
    }

    public boolean shouldPersist() {
        return this.mPreferenceManager != null && isPersistent() && hasKey();
    }

    public String toString() {
        return getFilterableStringBuilder().toString();
    }

    public final boolean wasDetached() {
        return this.mWasDetached;
    }

    @Override // java.lang.Comparable
    public int compareTo(Preference preference) {
        int i2 = this.mOrder;
        int i3 = preference.mOrder;
        if (i2 != i3) {
            return i2 - i3;
        }
        CharSequence charSequence = this.mTitle;
        CharSequence charSequence2 = preference.mTitle;
        if (charSequence == charSequence2) {
            return 0;
        }
        if (charSequence == null) {
            return 1;
        }
        if (charSequence2 == null) {
            return -1;
        }
        return charSequence.toString().compareToIgnoreCase(preference.mTitle.toString());
    }

    public void performClick() {
        androidx.preference.nul.InterfaceC0044nul interfaceC0044nulI;
        if (isEnabled() && isSelectable()) {
            onClick();
            com1 com1Var = this.mOnClickListener;
            if (com1Var == null || !com1Var.a(this)) {
                androidx.preference.nul preferenceManager = getPreferenceManager();
                if ((preferenceManager == null || (interfaceC0044nulI = preferenceManager.i()) == null || !interfaceC0044nulI.i(this)) && this.mIntent != null) {
                    getContext().startActivity(this.mIntent);
                }
            }
        }
    }

    public void setTitle(int i2) {
        setTitle(this.mContext.getString(i2));
    }

    public void onAttachedToHierarchy(androidx.preference.nul nulVar, long j2) {
        this.mId = j2;
        this.mHasId = true;
        try {
            onAttachedToHierarchy(nulVar);
        } finally {
            this.mHasId = false;
        }
    }

    public void setIcon(int i2) {
        setIcon(AUX.aux.b(this.mContext, i2));
        this.mIconResId = i2;
    }

    public void setSummary(int i2) {
        setSummary(this.mContext.getString(i2));
    }

    public Preference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public Preference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6174h, R.attr.preferenceStyle));
    }

    public Preference(Context context) {
        this(context, null);
    }
}
