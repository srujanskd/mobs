package LPT1;

import java.lang.reflect.Type;

/* JADX INFO: loaded from: classes.dex */
public interface com5<T> {
    T a(com6 com6Var, Type type, com4 com4Var) throws lpt1;
}
