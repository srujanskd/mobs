package LPT5;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class con {
    public static <T> T a(List<T> list) {
        return (T) b(list, null);
    }

    public static <T> T b(List<T> list, T t2) {
        return e(list) ? t2 : list.get(0);
    }

    public static <T> T c(List<T> list) {
        return (T) d(list, null);
    }

    public static <T> T d(List<T> list, T t2) {
        return e(list) ? t2 : list.get(list.size() - 1);
    }

    public static <T> boolean e(List<T> list) {
        return list == null || list.isEmpty();
    }
}
