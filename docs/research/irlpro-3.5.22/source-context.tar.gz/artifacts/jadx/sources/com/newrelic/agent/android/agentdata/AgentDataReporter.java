package com.newrelic.agent.android.agentdata;

import com.newrelic.agent.android.AgentConfiguration;
import com.newrelic.agent.android.FeatureFlag;
import com.newrelic.agent.android.harvest.Harvest;
import com.newrelic.agent.android.harvest.HarvestLifecycleAware;
import com.newrelic.agent.android.metric.MetricNames;
import com.newrelic.agent.android.payload.Payload;
import com.newrelic.agent.android.payload.PayloadController;
import com.newrelic.agent.android.payload.PayloadReporter;
import com.newrelic.agent.android.payload.PayloadSender;
import com.newrelic.agent.android.payload.PayloadStore;
import com.newrelic.agent.android.stats.StatsEngine;
import com.newrelic.com.google.flatbuffers.FlatBufferBuilder;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;
import p045LpT4.com2;

/* JADX INFO: loaded from: classes.dex */
public class AgentDataReporter extends PayloadReporter implements HarvestLifecycleAware {
    protected static final AtomicReference<AgentDataReporter> instance = new AtomicReference<>(null);
    private static boolean reportExceptions = false;
    protected final PayloadStore<Payload> payloadStore;
    protected final Callable reportCachedAgentDataCallable;

    public AgentDataReporter(AgentConfiguration agentConfiguration) {
        super(agentConfiguration);
        this.reportCachedAgentDataCallable = new Callable() { // from class: com.newrelic.agent.android.agentdata.AgentDataReporter.1
            @Override // java.util.concurrent.Callable
            public Object call() throws Exception {
                AgentDataReporter.this.reportCachedAgentData();
                return null;
            }
        };
        this.payloadStore = agentConfiguration.getPayloadStore();
        this.isEnabled.set(FeatureFlag.featureEnabled(FeatureFlag.HandledExceptions));
    }

    public static AgentDataReporter getInstance() {
        return instance.get();
    }

    public static AgentDataReporter initialize(AgentConfiguration agentConfiguration) {
        AtomicReference<AgentDataReporter> atomicReference = instance;
        com2.a(atomicReference, null, new AgentDataReporter(agentConfiguration));
        reportExceptions = agentConfiguration.getReportHandledExceptions();
        return atomicReference.get();
    }

    public static boolean isInitialized() {
        return instance.get() != null;
    }

    private boolean isPayloadStale(Payload payload) {
        if (!payload.isStale(this.agentConfiguration.getPayloadTTL())) {
            return false;
        }
        this.payloadStore.delete(payload);
        PayloadReporter.log.info("Payload [" + payload.getUuid() + "] has become stale, and has been removed");
        StatsEngine.get().inc(MetricNames.SUPPORTABILITY_PAYLOAD_REMOVED_STALE);
        return true;
    }

    public static boolean reportAgentData(byte[] bArr) {
        if (!isInitialized()) {
            PayloadReporter.log.error("AgentDataReporter not initialized");
        } else if (reportExceptions) {
            instance.get().storeAndReportAgentData(new Payload(bArr));
            return true;
        }
        return false;
    }

    public static void shutdown() {
        if (isInitialized()) {
            try {
                instance.get().stop();
            } finally {
                instance.set(null);
            }
        }
    }

    private byte[] submitBatchedPayload(final List<Payload> list) {
        if (list.isEmpty()) {
            return null;
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Iterator<Payload> it = list.iterator();
        while (it.hasNext()) {
            try {
                byteArrayOutputStream.write(it.next().getBytes());
            } catch (Exception unused) {
            }
        }
        ByteBuffer byteBufferSlice = new FlatBufferBuilder(ByteBuffer.wrap(byteArrayOutputStream.toByteArray())).dataBuffer().slice();
        byteBufferSlice.get(new byte[byteBufferSlice.remaining()]);
        PayloadController.submitPayload(new AgentDataSender(byteBufferSlice.array(), instance.get().agentConfiguration), new PayloadSender.CompletionHandler() { // from class: com.newrelic.agent.android.agentdata.AgentDataReporter.3
            @Override // com.newrelic.agent.android.payload.PayloadSender.CompletionHandler
            public void onException(PayloadSender payloadSender, Exception exc) {
                PayloadReporter.log.error("AgentDataReporter.submitBatchedPayload(List<Payload>): " + exc);
            }

            @Override // com.newrelic.agent.android.payload.PayloadSender.CompletionHandler
            public void onResponse(PayloadSender payloadSender) {
                if (!payloadSender.isSuccessfulResponse() || AgentDataReporter.this.payloadStore == null) {
                    return;
                }
                Iterator it2 = list.iterator();
                while (it2.hasNext()) {
                    AgentDataReporter.this.payloadStore.delete((Payload) it2.next());
                }
            }
        });
        return null;
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvest() {
        PayloadController.submitCallable(this.reportCachedAgentDataCallable);
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestBefore() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestComplete() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestConnected() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestDisabled() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestDisconnected() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestError() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestFinalize() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestSendFailed() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestStart() {
    }

    @Override // com.newrelic.agent.android.harvest.HarvestLifecycleAware
    public void onHarvestStop() {
    }

    public void reportCachedAgentData() {
        if (!isInitialized()) {
            PayloadReporter.log.error("AgentDataReporter not initialized");
            return;
        }
        PayloadStore<Payload> payloadStore = this.payloadStore;
        if (payloadStore != null) {
            for (Payload payload : payloadStore.fetchAll()) {
                if (!isPayloadStale(payload)) {
                    reportAgentData(payload);
                }
            }
        }
    }

    @Override // com.newrelic.agent.android.payload.PayloadReporter
    public void start() {
        if (!PayloadController.isInitialized()) {
            PayloadReporter.log.error("AgentDataReporter.start(): Must initialize PayloadController first.");
        } else if (isEnabled() && this.isStarted.compareAndSet(false, true)) {
            PayloadController.submitCallable(this.reportCachedAgentDataCallable);
            Harvest.addHarvestListener(this);
        }
    }

    @Override // com.newrelic.agent.android.payload.PayloadReporter
    public void stop() {
        Harvest.removeHarvestListener(this);
    }

    public Future storeAndReportAgentData(Payload payload) {
        if (this.payloadStore != null && payload.isPersisted() && this.payloadStore.store(payload)) {
            payload.setPersisted(false);
        }
        return reportAgentData(payload);
    }

    public Future reportAgentData(Payload payload) {
        return PayloadController.submitPayload(new AgentDataSender(payload, getAgentConfiguration()), new PayloadSender.CompletionHandler() { // from class: com.newrelic.agent.android.agentdata.AgentDataReporter.2
            @Override // com.newrelic.agent.android.payload.PayloadSender.CompletionHandler
            public void onException(PayloadSender payloadSender, Exception exc) {
                PayloadReporter.log.error("AgentDataReporter.reportAgentData(Payload): " + exc);
            }

            @Override // com.newrelic.agent.android.payload.PayloadSender.CompletionHandler
            public void onResponse(PayloadSender payloadSender) {
                PayloadStore<Payload> payloadStore;
                if (!payloadSender.isSuccessfulResponse() || (payloadStore = AgentDataReporter.this.payloadStore) == null) {
                    return;
                }
                payloadStore.delete(payloadSender.getPayload());
            }
        });
    }
}
