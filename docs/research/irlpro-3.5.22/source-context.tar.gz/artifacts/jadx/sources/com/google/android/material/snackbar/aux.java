package com.google.android.material.snackbar;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static aux f9564a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f3608a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public nul f9565b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Object f3609a = new Object();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f3607a = new Handler(Looper.getMainLooper(), new C0059aux());

    /* JADX INFO: renamed from: com.google.android.material.snackbar.aux$aux, reason: collision with other inner class name */
    public class C0059aux implements Handler.Callback {
        public C0059aux() {
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            if (message.what != 0) {
                return false;
            }
            aux.this.d((nul) message.obj);
            return true;
        }
    }

    public interface con {
        void a();

        void b(int i2);
    }

    public static class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9567a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final WeakReference<con> f3610a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f3611a;

        public boolean a(con conVar) {
            return conVar != null && this.f3610a.get() == conVar;
        }
    }

    public static aux c() {
        if (f9564a == null) {
            f9564a = new aux();
        }
        return f9564a;
    }

    public final boolean a(nul nulVar, int i2) {
        con conVar = nulVar.f3610a.get();
        if (conVar == null) {
            return false;
        }
        this.f3607a.removeCallbacksAndMessages(nulVar);
        conVar.b(i2);
        return true;
    }

    public void b(con conVar, int i2) {
        synchronized (this.f3609a) {
            if (f(conVar)) {
                a(this.f3608a, i2);
            } else if (g(conVar)) {
                a(this.f9565b, i2);
            }
        }
    }

    public void d(nul nulVar) {
        synchronized (this.f3609a) {
            if (this.f3608a == nulVar || this.f9565b == nulVar) {
                a(nulVar, 2);
            }
        }
    }

    public boolean e(con conVar) {
        boolean z2;
        synchronized (this.f3609a) {
            z2 = f(conVar) || g(conVar);
        }
        return z2;
    }

    public final boolean f(con conVar) {
        nul nulVar = this.f3608a;
        return nulVar != null && nulVar.a(conVar);
    }

    public final boolean g(con conVar) {
        nul nulVar = this.f9565b;
        return nulVar != null && nulVar.a(conVar);
    }

    public void h(con conVar) {
        synchronized (this.f3609a) {
            if (f(conVar)) {
                this.f3608a = null;
                if (this.f9565b != null) {
                    m();
                }
            }
        }
    }

    public void i(con conVar) {
        synchronized (this.f3609a) {
            if (f(conVar)) {
                l(this.f3608a);
            }
        }
    }

    public void j(con conVar) {
        synchronized (this.f3609a) {
            if (f(conVar)) {
                nul nulVar = this.f3608a;
                if (!nulVar.f3611a) {
                    nulVar.f3611a = true;
                    this.f3607a.removeCallbacksAndMessages(nulVar);
                }
            }
        }
    }

    public void k(con conVar) {
        synchronized (this.f3609a) {
            if (f(conVar)) {
                nul nulVar = this.f3608a;
                if (nulVar.f3611a) {
                    nulVar.f3611a = false;
                    l(nulVar);
                }
            }
        }
    }

    public final void l(nul nulVar) {
        int i2 = nulVar.f9567a;
        if (i2 == -2) {
            return;
        }
        if (i2 <= 0) {
            i2 = i2 == -1 ? 1500 : 2750;
        }
        this.f3607a.removeCallbacksAndMessages(nulVar);
        Handler handler = this.f3607a;
        handler.sendMessageDelayed(Message.obtain(handler, 0, nulVar), i2);
    }

    public final void m() {
        nul nulVar = this.f9565b;
        if (nulVar != null) {
            this.f3608a = nulVar;
            this.f9565b = null;
            con conVar = nulVar.f3610a.get();
            if (conVar != null) {
                conVar.a();
            } else {
                this.f3608a = null;
            }
        }
    }
}
