package com.newrelic.agent.android;

/* JADX INFO: loaded from: classes.dex */
final class NewRelicConfig {
    static final String BUILD_ID = "7aa8bfff-7c4b-4287-8e46-52f642f5848a";
    static final String MAP_PROVIDER = "r8";
    static final Boolean OBFUSCATED = Boolean.TRUE;
    static final String VERSION = "6.5.0";

    public static String getBuildId() {
        return BUILD_ID;
    }
}
