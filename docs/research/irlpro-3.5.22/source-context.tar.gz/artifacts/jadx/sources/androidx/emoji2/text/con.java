package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import androidx.preference.Preference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import p025Com3.a0;
import p025Com3.v;
import p025Com3.w;
import p101com2.u2;
import p147nUl.y;

/* JADX INFO: loaded from: classes.dex */
public class con {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static volatile con f8187a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final Object f2340a = new Object();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f8188b = new Object();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com3 f2343a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final C0033con f2344a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final prn f2345a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Set<com1> f2346a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f2348a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2349a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int f2350b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f2351b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f8189c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final boolean f2352c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ReadWriteLock f2347a = new ReentrantReadWriteLock();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public volatile int f2341a = 3;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f2342a = new Handler(Looper.getMainLooper());

    public static final class aux extends C0033con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public volatile androidx.emoji2.text.com1 f8190a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public volatile androidx.emoji2.text.nul f2353a;

        /* JADX INFO: renamed from: androidx.emoji2.text.con$aux$aux, reason: collision with other inner class name */
        public class C0032aux extends com4 {
            public C0032aux() {
            }

            @Override // androidx.emoji2.text.con.com4
            public void a(Throwable th) {
                ((C0033con) aux.this).f8193a.m(th);
            }

            @Override // androidx.emoji2.text.con.com4
            public void b(androidx.emoji2.text.com1 com1Var) {
                aux.this.d(com1Var);
            }
        }

        public aux(con conVar) {
            super(conVar);
        }

        @Override // androidx.emoji2.text.con.C0033con
        public void a() {
            try {
                ((C0033con) this).f8193a.f2343a.a(new C0032aux());
            } catch (Throwable th) {
                ((C0033con) this).f8193a.m(th);
            }
        }

        @Override // androidx.emoji2.text.con.C0033con
        public CharSequence b(CharSequence charSequence, int i2, int i3, int i4, boolean z2) {
            return this.f2353a.h(charSequence, i2, i3, i4, z2);
        }

        @Override // androidx.emoji2.text.con.C0033con
        public void c(EditorInfo editorInfo) {
            editorInfo.extras.putInt("android.support.text.emoji.emojiCompat_metadataVersion", this.f8190a.e());
            editorInfo.extras.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", ((C0033con) this).f8193a.f2348a);
        }

        public void d(androidx.emoji2.text.com1 com1Var) {
            if (com1Var == null) {
                ((C0033con) this).f8193a.m(new IllegalArgumentException("metadataRepo cannot be null"));
                return;
            }
            this.f8190a = com1Var;
            androidx.emoji2.text.com1 com1Var2 = this.f8190a;
            com5 com5Var = new com5();
            prn prnVar = ((C0033con) this).f8193a.f2345a;
            con conVar = ((C0033con) this).f8193a;
            this.f2353a = new androidx.emoji2.text.nul(com1Var2, com5Var, prnVar, conVar.f2351b, conVar.f2349a);
            ((C0033con) this).f8193a.n();
        }
    }

    public static abstract class com1 {
        public void a(Throwable th) {
        }

        public void b() {
        }
    }

    public static class com2 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f8192a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Throwable f2354a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final List<com1> f2355a;

        public com2(com1 com1Var, int i2) {
            this(Arrays.asList((com1) u2.g(com1Var, "initCallback cannot be null")), i2, null);
        }

        @Override // java.lang.Runnable
        public void run() {
            int size = this.f2355a.size();
            int i2 = 0;
            if (this.f8192a != 1) {
                while (i2 < size) {
                    this.f2355a.get(i2).a(this.f2354a);
                    i2++;
                }
            } else {
                while (i2 < size) {
                    this.f2355a.get(i2).b();
                    i2++;
                }
            }
        }

        public com2(Collection<com1> collection, int i2) {
            this(collection, i2, null);
        }

        public com2(Collection<com1> collection, int i2, Throwable th) {
            u2.g(collection, "initCallbacks cannot be null");
            this.f2355a = new ArrayList(collection);
            this.f8192a = i2;
            this.f2354a = th;
        }
    }

    public interface com3 {
        void a(com4 com4Var);
    }

    public static abstract class com4 {
        public abstract void a(Throwable th);

        public abstract void b(androidx.emoji2.text.com1 com1Var);
    }

    public static class com5 {
        public w a(v vVar) {
            return new a0(vVar);
        }
    }

    /* JADX INFO: renamed from: androidx.emoji2.text.con$con, reason: collision with other inner class name */
    public static class C0033con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final con f8193a;

        public C0033con(con conVar) {
            this.f8193a = conVar;
        }

        public void a() {
            throw null;
        }

        public CharSequence b(CharSequence charSequence, int i2, int i3, int i4, boolean z2) {
            throw null;
        }

        public void c(EditorInfo editorInfo) {
            throw null;
        }
    }

    public static abstract class nul {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com3 f2356a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Set<com1> f2358a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2359a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int[] f2360a;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2361b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8196c;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8194a = -16711936;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8195b = 0;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public prn f2357a = new androidx.emoji2.text.nul.con();

        public nul(com3 com3Var) {
            u2.g(com3Var, "metadataLoader cannot be null.");
            this.f2356a = com3Var;
        }

        public final com3 a() {
            return this.f2356a;
        }

        public nul b(int i2) {
            this.f8195b = i2;
            return this;
        }
    }

    public interface prn {
        boolean a(CharSequence charSequence, int i2, int i3, int i4);
    }

    public con(nul nulVar) {
        this.f2348a = nulVar.f2359a;
        this.f2351b = nulVar.f2361b;
        this.f2349a = nulVar.f2360a;
        this.f2352c = nulVar.f8196c;
        this.f2350b = nulVar.f8194a;
        this.f2343a = nulVar.f2356a;
        this.f8189c = nulVar.f8195b;
        this.f2345a = nulVar.f2357a;
        y yVar = new y();
        this.f2346a = yVar;
        Set<com1> set = nulVar.f2358a;
        if (set != null && !set.isEmpty()) {
            yVar.addAll(nulVar.f2358a);
        }
        this.f2344a = new aux(this);
        l();
    }

    public static con b() {
        con conVar;
        synchronized (f2340a) {
            conVar = f8187a;
            u2.h(conVar != null, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
        }
        return conVar;
    }

    public static boolean e(InputConnection inputConnection, Editable editable, int i2, int i3, boolean z2) {
        return androidx.emoji2.text.nul.c(inputConnection, editable, i2, i3, z2);
    }

    public static boolean f(Editable editable, int i2, KeyEvent keyEvent) {
        return androidx.emoji2.text.nul.d(editable, i2, keyEvent);
    }

    public static con g(nul nulVar) {
        con conVar = f8187a;
        if (conVar == null) {
            synchronized (f2340a) {
                conVar = f8187a;
                if (conVar == null) {
                    conVar = new con(nulVar);
                    f8187a = conVar;
                }
            }
        }
        return conVar;
    }

    public static boolean h() {
        return f8187a != null;
    }

    public int c() {
        return this.f2350b;
    }

    public int d() {
        this.f2347a.readLock().lock();
        try {
            return this.f2341a;
        } finally {
            this.f2347a.readLock().unlock();
        }
    }

    public boolean i() {
        return this.f2352c;
    }

    public final boolean j() {
        return d() == 1;
    }

    public void k() {
        u2.h(this.f8189c == 1, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        if (j()) {
            return;
        }
        this.f2347a.writeLock().lock();
        try {
            if (this.f2341a == 0) {
                this.f2347a.writeLock().unlock();
                return;
            }
            this.f2341a = 0;
            this.f2347a.writeLock().unlock();
            this.f2344a.a();
        } catch (Throwable th) {
            this.f2347a.writeLock().unlock();
            throw th;
        }
    }

    public final void l() {
        this.f2347a.writeLock().lock();
        try {
            if (this.f8189c == 0) {
                this.f2341a = 0;
            }
            this.f2347a.writeLock().unlock();
            if (d() == 0) {
                this.f2344a.a();
            }
        } catch (Throwable th) {
            this.f2347a.writeLock().unlock();
            throw th;
        }
    }

    public void m(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f2347a.writeLock().lock();
        try {
            this.f2341a = 2;
            arrayList.addAll(this.f2346a);
            this.f2346a.clear();
            this.f2347a.writeLock().unlock();
            this.f2342a.post(new com2(arrayList, this.f2341a, th));
        } catch (Throwable th2) {
            this.f2347a.writeLock().unlock();
            throw th2;
        }
    }

    public void n() {
        ArrayList arrayList = new ArrayList();
        this.f2347a.writeLock().lock();
        try {
            this.f2341a = 1;
            arrayList.addAll(this.f2346a);
            this.f2346a.clear();
            this.f2347a.writeLock().unlock();
            this.f2342a.post(new com2(arrayList, this.f2341a));
        } catch (Throwable th) {
            this.f2347a.writeLock().unlock();
            throw th;
        }
    }

    public CharSequence o(CharSequence charSequence) {
        return p(charSequence, 0, charSequence == null ? 0 : charSequence.length());
    }

    public CharSequence p(CharSequence charSequence, int i2, int i3) {
        return q(charSequence, i2, i3, Preference.DEFAULT_ORDER);
    }

    public CharSequence q(CharSequence charSequence, int i2, int i3, int i4) {
        return r(charSequence, i2, i3, i4, 0);
    }

    public CharSequence r(CharSequence charSequence, int i2, int i3, int i4, int i5) {
        boolean z2;
        u2.h(j(), "Not initialized yet");
        u2.d(i2, "start cannot be negative");
        u2.d(i3, "end cannot be negative");
        u2.d(i4, "maxEmojiCount cannot be negative");
        u2.a(i2 <= i3, "start should be <= than end");
        if (charSequence == null) {
            return null;
        }
        u2.a(i2 <= charSequence.length(), "start should be < than charSequence length");
        u2.a(i3 <= charSequence.length(), "end should be < than charSequence length");
        if (charSequence.length() == 0 || i2 == i3) {
            return charSequence;
        }
        if (i5 != 1) {
            z2 = i5 != 2 ? this.f2348a : false;
        } else {
            z2 = true;
        }
        return this.f2344a.b(charSequence, i2, i3, i4, z2);
    }

    public void s(com1 com1Var) {
        u2.g(com1Var, "initCallback cannot be null");
        this.f2347a.writeLock().lock();
        try {
            if (this.f2341a == 1 || this.f2341a == 2) {
                this.f2342a.post(new com2(com1Var, this.f2341a));
            } else {
                this.f2346a.add(com1Var);
            }
        } finally {
            this.f2347a.writeLock().unlock();
        }
    }

    public void t(com1 com1Var) {
        u2.g(com1Var, "initCallback cannot be null");
        this.f2347a.writeLock().lock();
        try {
            this.f2346a.remove(com1Var);
        } finally {
            this.f2347a.writeLock().unlock();
        }
    }

    public void u(EditorInfo editorInfo) {
        if (!j() || editorInfo == null) {
            return;
        }
        if (editorInfo.extras == null) {
            editorInfo.extras = new Bundle();
        }
        this.f2344a.c(editorInfo);
    }
}
