package androidx.viewpager2.adapter;

import COM3.com7;
import androidx.lifecycle.nul;
import androidx.lifecycle.prn;

/* JADX INFO: loaded from: classes.dex */
class FragmentStateAdapter$2 implements prn {
    @Override // androidx.lifecycle.prn
    public void f(com7 com7Var, nul.con conVar) {
        throw null;
    }
}
