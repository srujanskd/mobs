package com.google.android.material.chip;

import COM6.com4;
import COM9.com3;
import android.R;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.text.TextUtils;
import android.util.AttributeSet;
import androidx.preference.Preference;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import p021CoM9.lpt4;
import p023Com1.com9;
import p030Com8.prn;
import p075cOM6.h4;
import p080cOm1.y;
import p096coM7.com8;
import p098coM9.b;
import p098coM9.c;
import p108com9.r;
import p108com9.t;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
public class aux extends com3 implements Drawable.Callback, r.con {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f3413a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com4 f3414a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f3415a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3416a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorFilter f3417a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Paint.FontMetrics f3418a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final PointF f3419a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f3420a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f3421a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextUtils.TruncateAt f3422a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final r f3423a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f3424a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public WeakReference<InterfaceC0056aux> f3425a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f3426a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public float f3427b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3428b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public com4 f3429b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f3430b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Drawable f3431b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f3432b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f9415c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f3433c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ColorStateList f3434c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final Path f3435c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public PorterDuffColorFilter f3436c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Drawable f3437c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f9416d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public int f3438d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public ColorStateList f3439d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final Paint f3440d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final RectF f3441d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public Drawable f3442d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3443d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f9417e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public int f3444e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public ColorStateList f3445e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public final Paint f3446e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f3447e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f9418f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public int f3448f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public ColorStateList f3449f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f3450f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f9419g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public int f3451g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public ColorStateList f3452g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f3453g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f9420h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public int f3454h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public ColorStateList f3455h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f3456h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public float f9421i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public int f3457i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public ColorStateList f3458i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f3459i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f9422j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public int f3460j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f3461j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public float f9423k;

    /* JADX INFO: renamed from: k, reason: collision with other field name */
    public boolean f3462k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public float f9424l;

    /* JADX INFO: renamed from: l, reason: collision with other field name */
    public boolean f3463l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public float f9425m;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f9414b = {R.attr.state_enabled};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ShapeDrawable f9413a = new ShapeDrawable(new OvalShape());

    /* JADX INFO: renamed from: com.google.android.material.chip.aux$aux, reason: collision with other inner class name */
    public interface InterfaceC0056aux {
        void a();
    }

    public aux(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f3427b = -1.0f;
        this.f3440d = new Paint(1);
        this.f3418a = new Paint.FontMetrics();
        this.f3441d = new RectF();
        this.f3419a = new PointF();
        this.f3435c = new Path();
        this.f3457i = 255;
        this.f3420a = PorterDuff.Mode.SRC_IN;
        this.f3425a = new WeakReference<>(null);
        N(context);
        this.f3415a = context;
        r rVar = new r(this);
        this.f3423a = rVar;
        this.f3424a = "";
        rVar.e().density = context.getResources().getDisplayMetrics().density;
        this.f3446e = null;
        int[] iArr = f9414b;
        setState(iArr);
        k2(iArr);
        this.f3462k = true;
        if (lpt4.f551a) {
            f9413a.setTint(-1);
        }
    }

    public static boolean m1(int[] iArr, int i2) {
        if (iArr == null) {
            return false;
        }
        for (int i3 : iArr) {
            if (i3 == i2) {
                return true;
            }
        }
        return false;
    }

    public static boolean q1(ColorStateList colorStateList) {
        return colorStateList != null && colorStateList.isStateful();
    }

    public static boolean r1(Drawable drawable) {
        return drawable != null && drawable.isStateful();
    }

    public static boolean s1(c cVar) {
        return (cVar == null || cVar.i() == null || !cVar.i().isStateful()) ? false : true;
    }

    public static aux u0(Context context, AttributeSet attributeSet, int i2, int i3) {
        aux auxVar = new aux(context, attributeSet, i2, i3);
        auxVar.t1(attributeSet, i2, i3);
        return auxVar;
    }

    public final void A0(Canvas canvas, Rect rect) {
        if (N2()) {
            n0(rect, this.f3441d);
            RectF rectF = this.f3441d;
            float f2 = rectF.left;
            float f3 = rectF.top;
            canvas.translate(f2, f3);
            this.f3431b.setBounds(0, 0, (int) this.f3441d.width(), (int) this.f3441d.height());
            if (lpt4.f551a) {
                this.f3437c.setBounds(this.f3431b.getBounds());
                this.f3437c.jumpToCurrentState();
                this.f3437c.draw(canvas);
            } else {
                this.f3431b.draw(canvas);
            }
            canvas.translate(-f2, -f3);
        }
    }

    public void A1(ColorStateList colorStateList) {
        if (this.f3452g != colorStateList) {
            this.f3452g = colorStateList;
            if (t0()) {
                y.i(this.f3442d, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public void A2(com4 com4Var) {
        this.f3414a = com4Var;
    }

    public final void B0(Canvas canvas, Rect rect) {
        this.f3440d.setColor(this.f3448f);
        this.f3440d.setStyle(Paint.Style.FILL);
        this.f3441d.set(rect);
        if (!this.f3463l) {
            canvas.drawRoundRect(this.f3441d, H0(), H0(), this.f3440d);
        } else {
            h(new RectF(rect), this.f3435c);
            super.q(canvas, this.f3440d, this.f3435c, u());
        }
    }

    public void B1(int i2) {
        A1(AUX.aux.a(this.f3415a, i2));
    }

    public void B2(int i2) {
        A2(com4.c(this.f3415a, i2));
    }

    public final void C0(Canvas canvas, Rect rect) {
        Paint paint = this.f3446e;
        if (paint != null) {
            paint.setColor(com9.j(-16777216, 127));
            canvas.drawRect(rect, this.f3446e);
            if (M2() || L2()) {
                k0(rect, this.f3441d);
                canvas.drawRect(this.f3441d, this.f3446e);
            }
            if (this.f3424a != null) {
                canvas.drawLine(rect.left, rect.exactCenterY(), rect.right, rect.exactCenterY(), this.f3446e);
            }
            if (N2()) {
                n0(rect, this.f3441d);
                canvas.drawRect(this.f3441d, this.f3446e);
            }
            this.f3446e.setColor(com9.j(-65536, 127));
            m0(rect, this.f3441d);
            canvas.drawRect(this.f3441d, this.f3446e);
            this.f3446e.setColor(com9.j(-16711936, 127));
            o0(rect, this.f3441d);
            canvas.drawRect(this.f3441d, this.f3446e);
        }
    }

    public void C1(int i2) {
        D1(this.f3415a.getResources().getBoolean(i2));
    }

    public void C2(CharSequence charSequence) {
        if (charSequence == null) {
            charSequence = "";
        }
        if (TextUtils.equals(this.f3424a, charSequence)) {
            return;
        }
        this.f3424a = charSequence;
        this.f3423a.i(true);
        invalidateSelf();
        u1();
    }

    public final void D0(Canvas canvas, Rect rect) {
        if (this.f3424a != null) {
            Paint.Align alignS0 = s0(rect, this.f3419a);
            q0(rect, this.f3441d);
            if (this.f3423a.d() != null) {
                this.f3423a.e().drawableState = getState();
                this.f3423a.j(this.f3415a);
            }
            this.f3423a.e().setTextAlign(alignS0);
            int iSave = 0;
            boolean z2 = Math.round(this.f3423a.f(g1().toString())) > Math.round(this.f3441d.width());
            if (z2) {
                iSave = canvas.save();
                canvas.clipRect(this.f3441d);
            }
            CharSequence charSequenceEllipsize = this.f3424a;
            if (z2 && this.f3422a != null) {
                charSequenceEllipsize = TextUtils.ellipsize(charSequenceEllipsize, this.f3423a.e(), this.f3441d.width(), this.f3422a);
            }
            CharSequence charSequence = charSequenceEllipsize;
            int length = charSequence.length();
            PointF pointF = this.f3419a;
            canvas.drawText(charSequence, 0, length, pointF.x, pointF.y, this.f3423a.e());
            if (z2) {
                canvas.restoreToCount(iSave);
            }
        }
    }

    public void D1(boolean z2) {
        if (this.f3456h != z2) {
            boolean zL2 = L2();
            this.f3456h = z2;
            boolean zL3 = L2();
            if (zL2 != zL3) {
                if (zL3) {
                    j0(this.f3442d);
                } else {
                    O2(this.f3442d);
                }
                invalidateSelf();
                u1();
            }
        }
    }

    public void D2(c cVar) {
        this.f3423a.h(cVar, this.f3415a);
    }

    public Drawable E0() {
        return this.f3442d;
    }

    public void E1(ColorStateList colorStateList) {
        if (this.f3430b != colorStateList) {
            this.f3430b = colorStateList;
            onStateChange(getState());
        }
    }

    public void E2(int i2) {
        D2(new c(this.f3415a, i2));
    }

    public ColorStateList F0() {
        return this.f3452g;
    }

    public void F1(int i2) {
        E1(AUX.aux.a(this.f3415a, i2));
    }

    public void F2(float f2) {
        if (this.f9422j != f2) {
            this.f9422j = f2;
            invalidateSelf();
            u1();
        }
    }

    public ColorStateList G0() {
        return this.f3430b;
    }

    @Deprecated
    public void G1(float f2) {
        if (this.f3427b != f2) {
            this.f3427b = f2;
            setShapeAppearanceModel(D().w(f2));
        }
    }

    public void G2(int i2) {
        F2(this.f3415a.getResources().getDimension(i2));
    }

    public float H0() {
        return this.f3463l ? G() : this.f3427b;
    }

    @Deprecated
    public void H1(int i2) {
        G1(this.f3415a.getResources().getDimension(i2));
    }

    public void H2(float f2) {
        if (this.f9421i != f2) {
            this.f9421i = f2;
            invalidateSelf();
            u1();
        }
    }

    public float I0() {
        return this.f9425m;
    }

    public void I1(float f2) {
        if (this.f9425m != f2) {
            this.f9425m = f2;
            invalidateSelf();
            u1();
        }
    }

    public void I2(int i2) {
        H2(this.f3415a.getResources().getDimension(i2));
    }

    public Drawable J0() {
        Drawable drawable = this.f3421a;
        if (drawable != null) {
            return y.k(drawable);
        }
        return null;
    }

    public void J1(int i2) {
        I1(this.f3415a.getResources().getDimension(i2));
    }

    public void J2(boolean z2) {
        if (this.f3461j != z2) {
            this.f3461j = z2;
            P2();
            onStateChange(getState());
        }
    }

    public float K0() {
        return this.f9416d;
    }

    public void K1(Drawable drawable) {
        Drawable drawableJ0 = J0();
        if (drawableJ0 != drawable) {
            float fL0 = l0();
            this.f3421a = drawable != null ? y.l(drawable).mutate() : null;
            float fL1 = l0();
            O2(drawableJ0);
            if (M2()) {
                j0(this.f3421a);
            }
            invalidateSelf();
            if (fL0 != fL1) {
                u1();
            }
        }
    }

    public boolean K2() {
        return this.f3462k;
    }

    public ColorStateList L0() {
        return this.f3445e;
    }

    public void L1(int i2) {
        K1(AUX.aux.b(this.f3415a, i2));
    }

    public final boolean L2() {
        return this.f3456h && this.f3442d != null && this.f3459i;
    }

    public float M0() {
        return this.f3413a;
    }

    public void M1(float f2) {
        if (this.f9416d != f2) {
            float fL0 = l0();
            this.f9416d = f2;
            float fL1 = l0();
            invalidateSelf();
            if (fL0 != fL1) {
                u1();
            }
        }
    }

    public final boolean M2() {
        return this.f3443d && this.f3421a != null;
    }

    public float N0() {
        return this.f9418f;
    }

    public void N1(int i2) {
        M1(this.f3415a.getResources().getDimension(i2));
    }

    public final boolean N2() {
        return this.f3450f && this.f3431b != null;
    }

    public ColorStateList O0() {
        return this.f3434c;
    }

    public void O1(ColorStateList colorStateList) {
        this.f3447e = true;
        if (this.f3445e != colorStateList) {
            this.f3445e = colorStateList;
            if (M2()) {
                y.i(this.f3421a, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public final void O2(Drawable drawable) {
        if (drawable != null) {
            drawable.setCallback(null);
        }
    }

    public float P0() {
        return this.f9415c;
    }

    public void P1(int i2) {
        O1(AUX.aux.a(this.f3415a, i2));
    }

    public final void P2() {
        this.f3458i = this.f3461j ? lpt4.d(this.f3439d) : null;
    }

    public Drawable Q0() {
        Drawable drawable = this.f3431b;
        if (drawable != null) {
            return y.k(drawable);
        }
        return null;
    }

    public void Q1(int i2) {
        R1(this.f3415a.getResources().getBoolean(i2));
    }

    @TargetApi(21)
    public final void Q2() {
        this.f3437c = new RippleDrawable(lpt4.d(e1()), this.f3431b, f9413a);
    }

    public CharSequence R0() {
        return this.f3432b;
    }

    public void R1(boolean z2) {
        if (this.f3443d != z2) {
            boolean zM2 = M2();
            this.f3443d = z2;
            boolean zM3 = M2();
            if (zM2 != zM3) {
                if (zM3) {
                    j0(this.f3421a);
                } else {
                    O2(this.f3421a);
                }
                invalidateSelf();
                u1();
            }
        }
    }

    public float S0() {
        return this.f9424l;
    }

    public void S1(float f2) {
        if (this.f3413a != f2) {
            this.f3413a = f2;
            invalidateSelf();
            u1();
        }
    }

    public float T0() {
        return this.f9417e;
    }

    public void T1(int i2) {
        S1(this.f3415a.getResources().getDimension(i2));
    }

    public float U0() {
        return this.f9423k;
    }

    public void U1(float f2) {
        if (this.f9418f != f2) {
            this.f9418f = f2;
            invalidateSelf();
            u1();
        }
    }

    public int[] V0() {
        return this.f3426a;
    }

    public void V1(int i2) {
        U1(this.f3415a.getResources().getDimension(i2));
    }

    public ColorStateList W0() {
        return this.f3449f;
    }

    public void W1(ColorStateList colorStateList) {
        if (this.f3434c != colorStateList) {
            this.f3434c = colorStateList;
            if (this.f3463l) {
                e0(colorStateList);
            }
            onStateChange(getState());
        }
    }

    public void X0(RectF rectF) {
        o0(getBounds(), rectF);
    }

    public void X1(int i2) {
        W1(AUX.aux.a(this.f3415a, i2));
    }

    public final float Y0() {
        Drawable drawable = this.f3459i ? this.f3442d : this.f3421a;
        float fCeil = this.f9416d;
        if (fCeil <= 0.0f && drawable != null) {
            fCeil = (float) Math.ceil(v.b(this.f3415a, 24));
            if (drawable.getIntrinsicHeight() <= fCeil) {
                return drawable.getIntrinsicHeight();
            }
        }
        return fCeil;
    }

    public void Y1(float f2) {
        if (this.f9415c != f2) {
            this.f9415c = f2;
            this.f3440d.setStrokeWidth(f2);
            if (this.f3463l) {
                super.f0(f2);
            }
            invalidateSelf();
        }
    }

    public final float Z0() {
        Drawable drawable = this.f3459i ? this.f3442d : this.f3421a;
        float f2 = this.f9416d;
        return (f2 > 0.0f || drawable == null) ? f2 : drawable.getIntrinsicWidth();
    }

    public void Z1(int i2) {
        Y1(this.f3415a.getResources().getDimension(i2));
    }

    @Override // com9.r.con
    public void a() {
        u1();
        invalidateSelf();
    }

    public TextUtils.TruncateAt a1() {
        return this.f3422a;
    }

    public final void a2(ColorStateList colorStateList) {
        if (this.f3416a != colorStateList) {
            this.f3416a = colorStateList;
            onStateChange(getState());
        }
    }

    public com4 b1() {
        return this.f3429b;
    }

    public void b2(Drawable drawable) {
        Drawable drawableQ0 = Q0();
        if (drawableQ0 != drawable) {
            float fP0 = p0();
            this.f3431b = drawable != null ? y.l(drawable).mutate() : null;
            if (lpt4.f551a) {
                Q2();
            }
            float fP1 = p0();
            O2(drawableQ0);
            if (N2()) {
                j0(this.f3431b);
            }
            invalidateSelf();
            if (fP0 != fP1) {
                u1();
            }
        }
    }

    public float c1() {
        return this.f9420h;
    }

    public void c2(CharSequence charSequence) {
        if (this.f3432b != charSequence) {
            this.f3432b = COM1.aux.c().h(charSequence);
            invalidateSelf();
        }
    }

    public float d1() {
        return this.f9419g;
    }

    public void d2(float f2) {
        if (this.f9424l != f2) {
            this.f9424l = f2;
            invalidateSelf();
            if (N2()) {
                u1();
            }
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        if (bounds.isEmpty() || getAlpha() == 0) {
            return;
        }
        int i2 = this.f3457i;
        int iA = i2 < 255 ? com8.a(canvas, bounds.left, bounds.top, bounds.right, bounds.bottom, i2) : 0;
        z0(canvas, bounds);
        w0(canvas, bounds);
        if (this.f3463l) {
            super.draw(canvas);
        }
        y0(canvas, bounds);
        B0(canvas, bounds);
        x0(canvas, bounds);
        v0(canvas, bounds);
        if (this.f3462k) {
            D0(canvas, bounds);
        }
        A0(canvas, bounds);
        C0(canvas, bounds);
        if (this.f3457i < 255) {
            canvas.restoreToCount(iA);
        }
    }

    public ColorStateList e1() {
        return this.f3439d;
    }

    public void e2(int i2) {
        d2(this.f3415a.getResources().getDimension(i2));
    }

    public com4 f1() {
        return this.f3414a;
    }

    public void f2(int i2) {
        b2(AUX.aux.b(this.f3415a, i2));
    }

    public CharSequence g1() {
        return this.f3424a;
    }

    public void g2(float f2) {
        if (this.f9417e != f2) {
            this.f9417e = f2;
            invalidateSelf();
            if (N2()) {
                u1();
            }
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.f3457i;
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        return this.f3417a;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return (int) this.f3413a;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return Math.min(Math.round(this.f9418f + l0() + this.f9421i + this.f3423a.f(g1().toString()) + this.f9422j + p0() + this.f9425m), this.f3460j);
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    @TargetApi(21)
    public void getOutline(Outline outline) {
        if (this.f3463l) {
            super.getOutline(outline);
            return;
        }
        Rect bounds = getBounds();
        if (bounds.isEmpty()) {
            outline.setRoundRect(0, 0, getIntrinsicWidth(), getIntrinsicHeight(), this.f3427b);
        } else {
            outline.setRoundRect(bounds, this.f3427b);
        }
        outline.setAlpha(getAlpha() / 255.0f);
    }

    public c h1() {
        return this.f3423a.d();
    }

    public void h2(int i2) {
        g2(this.f3415a.getResources().getDimension(i2));
    }

    public float i1() {
        return this.f9422j;
    }

    public void i2(float f2) {
        if (this.f9423k != f2) {
            this.f9423k = f2;
            invalidateSelf();
            if (N2()) {
                u1();
            }
        }
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void invalidateDrawable(Drawable drawable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public boolean isStateful() {
        return q1(this.f3416a) || q1(this.f3430b) || q1(this.f3434c) || (this.f3461j && q1(this.f3458i)) || s1(this.f3423a.d()) || t0() || r1(this.f3421a) || r1(this.f3442d) || q1(this.f3455h);
    }

    public final void j0(Drawable drawable) {
        if (drawable == null) {
            return;
        }
        drawable.setCallback(this);
        y.g(drawable, y.b(this));
        drawable.setLevel(getLevel());
        drawable.setVisible(isVisible(), false);
        if (drawable == this.f3431b) {
            if (drawable.isStateful()) {
                drawable.setState(V0());
            }
            y.i(drawable, this.f3449f);
            return;
        }
        Drawable drawable2 = this.f3421a;
        if (drawable == drawable2 && this.f3447e) {
            y.i(drawable2, this.f3445e);
        }
        if (drawable.isStateful()) {
            drawable.setState(getState());
        }
    }

    public float j1() {
        return this.f9421i;
    }

    public void j2(int i2) {
        i2(this.f3415a.getResources().getDimension(i2));
    }

    public final void k0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (M2() || L2()) {
            float f2 = this.f9418f + this.f9419g;
            float fZ0 = Z0();
            if (y.b(this) == 0) {
                float f3 = rect.left + f2;
                rectF.left = f3;
                rectF.right = f3 + fZ0;
            } else {
                float f4 = rect.right - f2;
                rectF.right = f4;
                rectF.left = f4 - fZ0;
            }
            float fY0 = Y0();
            float fExactCenterY = rect.exactCenterY() - (fY0 / 2.0f);
            rectF.top = fExactCenterY;
            rectF.bottom = fExactCenterY + fY0;
        }
    }

    public final ColorFilter k1() {
        ColorFilter colorFilter = this.f3417a;
        return colorFilter != null ? colorFilter : this.f3436c;
    }

    public boolean k2(int[] iArr) {
        if (Arrays.equals(this.f3426a, iArr)) {
            return false;
        }
        this.f3426a = iArr;
        if (N2()) {
            return v1(getState(), iArr);
        }
        return false;
    }

    public float l0() {
        if (M2() || L2()) {
            return this.f9419g + Z0() + this.f9420h;
        }
        return 0.0f;
    }

    public boolean l1() {
        return this.f3461j;
    }

    public void l2(ColorStateList colorStateList) {
        if (this.f3449f != colorStateList) {
            this.f3449f = colorStateList;
            if (N2()) {
                y.i(this.f3431b, colorStateList);
            }
            onStateChange(getState());
        }
    }

    public final void m0(Rect rect, RectF rectF) {
        rectF.set(rect);
        if (N2()) {
            float f2 = this.f9425m + this.f9424l + this.f9417e + this.f9423k + this.f9422j;
            if (y.b(this) == 0) {
                rectF.right = rect.right - f2;
            } else {
                rectF.left = rect.left + f2;
            }
        }
    }

    public void m2(int i2) {
        l2(AUX.aux.a(this.f3415a, i2));
    }

    public final void n0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (N2()) {
            float f2 = this.f9425m + this.f9424l;
            if (y.b(this) == 0) {
                float f3 = rect.right - f2;
                rectF.right = f3;
                rectF.left = f3 - this.f9417e;
            } else {
                float f4 = rect.left + f2;
                rectF.left = f4;
                rectF.right = f4 + this.f9417e;
            }
            float fExactCenterY = rect.exactCenterY();
            float f5 = this.f9417e;
            float f6 = fExactCenterY - (f5 / 2.0f);
            rectF.top = f6;
            rectF.bottom = f6 + f5;
        }
    }

    public boolean n1() {
        return this.f3453g;
    }

    public void n2(boolean z2) {
        if (this.f3450f != z2) {
            boolean zN2 = N2();
            this.f3450f = z2;
            boolean zN3 = N2();
            if (zN2 != zN3) {
                if (zN3) {
                    j0(this.f3431b);
                } else {
                    O2(this.f3431b);
                }
                invalidateSelf();
                u1();
            }
        }
    }

    public final void o0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (N2()) {
            float f2 = this.f9425m + this.f9424l + this.f9417e + this.f9423k + this.f9422j;
            if (y.b(this) == 0) {
                float f3 = rect.right;
                rectF.right = f3;
                rectF.left = f3 - f2;
            } else {
                int i2 = rect.left;
                rectF.left = i2;
                rectF.right = i2 + f2;
            }
            rectF.top = rect.top;
            rectF.bottom = rect.bottom;
        }
    }

    public boolean o1() {
        return r1(this.f3431b);
    }

    public void o2(InterfaceC0056aux interfaceC0056aux) {
        this.f3425a = new WeakReference<>(interfaceC0056aux);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLayoutDirectionChanged(int i2) {
        boolean zOnLayoutDirectionChanged = super.onLayoutDirectionChanged(i2);
        if (M2()) {
            zOnLayoutDirectionChanged |= y.g(this.f3421a, i2);
        }
        if (L2()) {
            zOnLayoutDirectionChanged |= y.g(this.f3442d, i2);
        }
        if (N2()) {
            zOnLayoutDirectionChanged |= y.g(this.f3431b, i2);
        }
        if (!zOnLayoutDirectionChanged) {
            return true;
        }
        invalidateSelf();
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onLevelChange(int i2) {
        boolean zOnLevelChange = super.onLevelChange(i2);
        if (M2()) {
            zOnLevelChange |= this.f3421a.setLevel(i2);
        }
        if (L2()) {
            zOnLevelChange |= this.f3442d.setLevel(i2);
        }
        if (N2()) {
            zOnLevelChange |= this.f3431b.setLevel(i2);
        }
        if (zOnLevelChange) {
            invalidateSelf();
        }
        return zOnLevelChange;
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        if (this.f3463l) {
            super.onStateChange(iArr);
        }
        return v1(iArr, V0());
    }

    public float p0() {
        if (N2()) {
            return this.f9423k + this.f9417e + this.f9424l;
        }
        return 0.0f;
    }

    public boolean p1() {
        return this.f3450f;
    }

    public void p2(TextUtils.TruncateAt truncateAt) {
        this.f3422a = truncateAt;
    }

    public final void q0(Rect rect, RectF rectF) {
        rectF.setEmpty();
        if (this.f3424a != null) {
            float fL0 = this.f9418f + l0() + this.f9421i;
            float fP0 = this.f9425m + p0() + this.f9422j;
            if (y.b(this) == 0) {
                rectF.left = rect.left + fL0;
                rectF.right = rect.right - fP0;
            } else {
                rectF.left = rect.left + fP0;
                rectF.right = rect.right - fL0;
            }
            rectF.top = rect.top;
            rectF.bottom = rect.bottom;
        }
    }

    public void q2(com4 com4Var) {
        this.f3429b = com4Var;
    }

    public final float r0() {
        this.f3423a.e().getFontMetrics(this.f3418a);
        Paint.FontMetrics fontMetrics = this.f3418a;
        return (fontMetrics.descent + fontMetrics.ascent) / 2.0f;
    }

    public void r2(int i2) {
        q2(com4.c(this.f3415a, i2));
    }

    public Paint.Align s0(Rect rect, PointF pointF) {
        pointF.set(0.0f, 0.0f);
        Paint.Align align = Paint.Align.LEFT;
        if (this.f3424a != null) {
            float fL0 = this.f9418f + l0() + this.f9421i;
            if (y.b(this) == 0) {
                pointF.x = rect.left + fL0;
                align = Paint.Align.LEFT;
            } else {
                pointF.x = rect.right - fL0;
                align = Paint.Align.RIGHT;
            }
            pointF.y = rect.centerY() - r0();
        }
        return align;
    }

    public void s2(float f2) {
        if (this.f9420h != f2) {
            float fL0 = l0();
            this.f9420h = f2;
            float fL1 = l0();
            invalidateSelf();
            if (fL0 != fL1) {
                u1();
            }
        }
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, runnable, j2);
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        if (this.f3457i != i2) {
            this.f3457i = i2;
            invalidateSelf();
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        if (this.f3417a != colorFilter) {
            this.f3417a = colorFilter;
            invalidateSelf();
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        if (this.f3455h != colorStateList) {
            this.f3455h = colorStateList;
            onStateChange(getState());
        }
    }

    @Override // COM9.com3, android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        if (this.f3420a != mode) {
            this.f3420a = mode;
            this.f3436c = p097coM8.lpt4.b(this, this.f3455h, mode);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z2, boolean z3) {
        boolean visible = super.setVisible(z2, z3);
        if (M2()) {
            visible |= this.f3421a.setVisible(z2, z3);
        }
        if (L2()) {
            visible |= this.f3442d.setVisible(z2, z3);
        }
        if (N2()) {
            visible |= this.f3431b.setVisible(z2, z3);
        }
        if (visible) {
            invalidateSelf();
        }
        return visible;
    }

    public final boolean t0() {
        return this.f3456h && this.f3442d != null && this.f3453g;
    }

    public final void t1(AttributeSet attributeSet, int i2, int i3) {
        TypedArray typedArrayH = t.h(this.f3415a, attributeSet, h4.f3182z, i2, i3, new int[0]);
        this.f3463l = typedArrayH.hasValue(h4.u0);
        a2(b.b(this.f3415a, typedArrayH, h4.f8996h0));
        E1(b.b(this.f3415a, typedArrayH, h4.U));
        S1(typedArrayH.getDimension(h4.f8986c0, 0.0f));
        int i4 = h4.V;
        if (typedArrayH.hasValue(i4)) {
            G1(typedArrayH.getDimension(i4, 0.0f));
        }
        W1(b.b(this.f3415a, typedArrayH, h4.f8992f0));
        Y1(typedArrayH.getDimension(h4.f8994g0, 0.0f));
        x2(b.b(this.f3415a, typedArrayH, h4.t0));
        C2(typedArrayH.getText(h4.O));
        c cVarF = b.f(this.f3415a, typedArrayH, h4.K);
        cVarF.l(typedArrayH.getDimension(h4.L, cVarF.j()));
        D2(cVarF);
        int i5 = typedArrayH.getInt(h4.M, 0);
        if (i5 == 1) {
            p2(TextUtils.TruncateAt.START);
        } else if (i5 == 2) {
            p2(TextUtils.TruncateAt.MIDDLE);
        } else if (i5 == 3) {
            p2(TextUtils.TruncateAt.END);
        }
        R1(typedArrayH.getBoolean(h4.f8984b0, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "chipIconVisible") == null) {
            R1(typedArrayH.getBoolean(h4.Y, false));
        }
        K1(b.d(this.f3415a, typedArrayH, h4.X));
        int i6 = h4.f8982a0;
        if (typedArrayH.hasValue(i6)) {
            O1(b.b(this.f3415a, typedArrayH, i6));
        }
        M1(typedArrayH.getDimension(h4.Z, -1.0f));
        n2(typedArrayH.getBoolean(h4.f9010o0, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "closeIconVisible") == null) {
            n2(typedArrayH.getBoolean(h4.f9000j0, false));
        }
        b2(b.d(this.f3415a, typedArrayH, h4.f8998i0));
        l2(b.b(this.f3415a, typedArrayH, h4.f9008n0));
        g2(typedArrayH.getDimension(h4.f9004l0, 0.0f));
        w1(typedArrayH.getBoolean(h4.P, false));
        D1(typedArrayH.getBoolean(h4.T, false));
        if (attributeSet != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconEnabled") != null && attributeSet.getAttributeValue("http://schemas.android.com/apk/res-auto", "checkedIconVisible") == null) {
            D1(typedArrayH.getBoolean(h4.R, false));
        }
        y1(b.d(this.f3415a, typedArrayH, h4.Q));
        int i7 = h4.S;
        if (typedArrayH.hasValue(i7)) {
            A1(b.b(this.f3415a, typedArrayH, i7));
        }
        A2(com4.b(this.f3415a, typedArrayH, h4.v0));
        q2(com4.b(this.f3415a, typedArrayH, h4.q0));
        U1(typedArrayH.getDimension(h4.f8990e0, 0.0f));
        u2(typedArrayH.getDimension(h4.s0, 0.0f));
        s2(typedArrayH.getDimension(h4.r0, 0.0f));
        H2(typedArrayH.getDimension(h4.x0, 0.0f));
        F2(typedArrayH.getDimension(h4.w0, 0.0f));
        i2(typedArrayH.getDimension(h4.f9006m0, 0.0f));
        d2(typedArrayH.getDimension(h4.f9002k0, 0.0f));
        I1(typedArrayH.getDimension(h4.W, 0.0f));
        w2(typedArrayH.getDimensionPixelSize(h4.N, Preference.DEFAULT_ORDER));
        typedArrayH.recycle();
    }

    public void t2(int i2) {
        s2(this.f3415a.getResources().getDimension(i2));
    }

    public void u1() {
        InterfaceC0056aux interfaceC0056aux = this.f3425a.get();
        if (interfaceC0056aux != null) {
            interfaceC0056aux.a();
        }
    }

    public void u2(float f2) {
        if (this.f9419g != f2) {
            float fL0 = l0();
            this.f9419g = f2;
            float fL1 = l0();
            invalidateSelf();
            if (fL0 != fL1) {
                u1();
            }
        }
    }

    @Override // android.graphics.drawable.Drawable.Callback
    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, runnable);
        }
    }

    public final void v0(Canvas canvas, Rect rect) {
        if (L2()) {
            k0(rect, this.f3441d);
            RectF rectF = this.f3441d;
            float f2 = rectF.left;
            float f3 = rectF.top;
            canvas.translate(f2, f3);
            this.f3442d.setBounds(0, 0, (int) this.f3441d.width(), (int) this.f3441d.height());
            this.f3442d.draw(canvas);
            canvas.translate(-f2, -f3);
        }
    }

    public final boolean v1(int[] iArr, int[] iArr2) {
        boolean z2;
        boolean zOnStateChange = super.onStateChange(iArr);
        ColorStateList colorStateList = this.f3416a;
        int iL = l(colorStateList != null ? colorStateList.getColorForState(iArr, this.f3428b) : 0);
        boolean state = true;
        if (this.f3428b != iL) {
            this.f3428b = iL;
            zOnStateChange = true;
        }
        ColorStateList colorStateList2 = this.f3430b;
        int iL2 = l(colorStateList2 != null ? colorStateList2.getColorForState(iArr, this.f3433c) : 0);
        if (this.f3433c != iL2) {
            this.f3433c = iL2;
            zOnStateChange = true;
        }
        int iG = prn.g(iL, iL2);
        if ((this.f3438d != iG) | (x() == null)) {
            this.f3438d = iG;
            Y(ColorStateList.valueOf(iG));
            zOnStateChange = true;
        }
        ColorStateList colorStateList3 = this.f3434c;
        int colorForState = colorStateList3 != null ? colorStateList3.getColorForState(iArr, this.f3444e) : 0;
        if (this.f3444e != colorForState) {
            this.f3444e = colorForState;
            zOnStateChange = true;
        }
        int colorForState2 = (this.f3458i == null || !lpt4.e(iArr)) ? 0 : this.f3458i.getColorForState(iArr, this.f3448f);
        if (this.f3448f != colorForState2) {
            this.f3448f = colorForState2;
            if (this.f3461j) {
                zOnStateChange = true;
            }
        }
        int colorForState3 = (this.f3423a.d() == null || this.f3423a.d().i() == null) ? 0 : this.f3423a.d().i().getColorForState(iArr, this.f3451g);
        if (this.f3451g != colorForState3) {
            this.f3451g = colorForState3;
            zOnStateChange = true;
        }
        boolean z3 = m1(getState(), R.attr.state_checked) && this.f3453g;
        if (this.f3459i == z3 || this.f3442d == null) {
            z2 = false;
        } else {
            float fL0 = l0();
            this.f3459i = z3;
            if (fL0 != l0()) {
                zOnStateChange = true;
                z2 = true;
            } else {
                z2 = false;
                zOnStateChange = true;
            }
        }
        ColorStateList colorStateList4 = this.f3455h;
        int colorForState4 = colorStateList4 != null ? colorStateList4.getColorForState(iArr, this.f3454h) : 0;
        if (this.f3454h != colorForState4) {
            this.f3454h = colorForState4;
            this.f3436c = p097coM8.lpt4.b(this, this.f3455h, this.f3420a);
        } else {
            state = zOnStateChange;
        }
        if (r1(this.f3421a)) {
            state |= this.f3421a.setState(iArr);
        }
        if (r1(this.f3442d)) {
            state |= this.f3442d.setState(iArr);
        }
        if (r1(this.f3431b)) {
            int[] iArr3 = new int[iArr.length + iArr2.length];
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            System.arraycopy(iArr2, 0, iArr3, iArr.length, iArr2.length);
            state |= this.f3431b.setState(iArr3);
        }
        if (lpt4.f551a && r1(this.f3437c)) {
            state |= this.f3437c.setState(iArr2);
        }
        if (state) {
            invalidateSelf();
        }
        if (z2) {
            u1();
        }
        return state;
    }

    public void v2(int i2) {
        u2(this.f3415a.getResources().getDimension(i2));
    }

    public final void w0(Canvas canvas, Rect rect) {
        if (this.f3463l) {
            return;
        }
        this.f3440d.setColor(this.f3433c);
        this.f3440d.setStyle(Paint.Style.FILL);
        this.f3440d.setColorFilter(k1());
        this.f3441d.set(rect);
        canvas.drawRoundRect(this.f3441d, H0(), H0(), this.f3440d);
    }

    public void w1(boolean z2) {
        if (this.f3453g != z2) {
            this.f3453g = z2;
            float fL0 = l0();
            if (!z2 && this.f3459i) {
                this.f3459i = false;
            }
            float fL1 = l0();
            invalidateSelf();
            if (fL0 != fL1) {
                u1();
            }
        }
    }

    public void w2(int i2) {
        this.f3460j = i2;
    }

    public final void x0(Canvas canvas, Rect rect) {
        if (M2()) {
            k0(rect, this.f3441d);
            RectF rectF = this.f3441d;
            float f2 = rectF.left;
            float f3 = rectF.top;
            canvas.translate(f2, f3);
            this.f3421a.setBounds(0, 0, (int) this.f3441d.width(), (int) this.f3441d.height());
            this.f3421a.draw(canvas);
            canvas.translate(-f2, -f3);
        }
    }

    public void x1(int i2) {
        w1(this.f3415a.getResources().getBoolean(i2));
    }

    public void x2(ColorStateList colorStateList) {
        if (this.f3439d != colorStateList) {
            this.f3439d = colorStateList;
            P2();
            onStateChange(getState());
        }
    }

    public final void y0(Canvas canvas, Rect rect) {
        if (this.f9415c <= 0.0f || this.f3463l) {
            return;
        }
        this.f3440d.setColor(this.f3444e);
        this.f3440d.setStyle(Paint.Style.STROKE);
        if (!this.f3463l) {
            this.f3440d.setColorFilter(k1());
        }
        RectF rectF = this.f3441d;
        float f2 = rect.left;
        float f3 = this.f9415c;
        rectF.set(f2 + (f3 / 2.0f), rect.top + (f3 / 2.0f), rect.right - (f3 / 2.0f), rect.bottom - (f3 / 2.0f));
        float f4 = this.f3427b - (this.f9415c / 2.0f);
        canvas.drawRoundRect(this.f3441d, f4, f4, this.f3440d);
    }

    public void y1(Drawable drawable) {
        if (this.f3442d != drawable) {
            float fL0 = l0();
            this.f3442d = drawable;
            float fL1 = l0();
            O2(this.f3442d);
            j0(this.f3442d);
            invalidateSelf();
            if (fL0 != fL1) {
                u1();
            }
        }
    }

    public void y2(int i2) {
        x2(AUX.aux.a(this.f3415a, i2));
    }

    public final void z0(Canvas canvas, Rect rect) {
        if (this.f3463l) {
            return;
        }
        this.f3440d.setColor(this.f3428b);
        this.f3440d.setStyle(Paint.Style.FILL);
        this.f3441d.set(rect);
        canvas.drawRoundRect(this.f3441d, H0(), H0(), this.f3440d);
    }

    public void z1(int i2) {
        y1(AUX.aux.b(this.f3415a, i2));
    }

    public void z2(boolean z2) {
        this.f3462k = z2;
    }
}
