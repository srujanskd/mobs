package LPT6;

import inet.ipaddr.lpt9;
import java.math.BigInteger;
import p125lPt7.oa;

/* JADX INFO: loaded from: classes.dex */
public interface com1 extends com3, oa {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com3, java.lang.Comparable
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsPrefixBlock(int i2) {
        return super.containsPrefixBlock(i2);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsSinglePrefixBlock(int i2) {
        return super.containsSinglePrefixBlock(i2);
    }

    @Override // LPT6.com3
    default int getBitCount() {
        int divisionCount = getDivisionCount();
        int bitCount = 0;
        for (int i2 = 0; i2 < divisionCount; i2++) {
            bitCount += getDivision(i2).getBitCount();
        }
        return bitCount;
    }

    default BigInteger getBlockCount(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException();
        }
        BigInteger bigIntegerMultiply = BigInteger.ONE;
        int divisionCount = getDivisionCount();
        if (i2 >= divisionCount) {
            i2 = divisionCount;
        }
        for (int i3 = 0; i3 < i2; i3++) {
            com2 division = getDivision(i3);
            if (division.isMultiple()) {
                bigIntegerMultiply = bigIntegerMultiply.multiply(division.getCount());
            }
        }
        return bigIntegerMultiply;
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int getByteCount() {
        return super.getByteCount();
    }

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes();

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr);

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr, int i2);

    @Override // LPT6.com3
    default BigInteger getCount() {
        BigInteger bigIntegerMultiply = BigInteger.ONE;
        int divisionCount = getDivisionCount();
        if (divisionCount > 0) {
            for (int i2 = 0; i2 < divisionCount; i2++) {
                com2 division = getDivision(i2);
                if (division.isMultiple()) {
                    bigIntegerMultiply = bigIntegerMultiply.multiply(division.getCount());
                }
            }
        }
        return bigIntegerMultiply;
    }

    @Override // p125lPt7.oa
    com2 getDivision(int i2);

    @Override // p125lPt7.oa
    /* synthetic */ int getDivisionCount();

    String[] getDivisionStrings();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int getMinPrefixLengthForBlock() {
        return super.getMinPrefixLengthForBlock();
    }

    default BigInteger getPrefixCount() {
        Integer prefixLength = getPrefixLength();
        return (prefixLength == null || prefixLength.intValue() >= getBitCount()) ? getCount() : getPrefixCount(prefixLength.intValue());
    }

    Integer getPrefixLength();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default Integer getPrefixLengthForSingleBlock() {
        return super.getPrefixLengthForSingleBlock();
    }

    default int getSequentialBlockIndex() {
        int divisionCount = getDivisionCount();
        if (divisionCount == 0) {
            return 0;
        }
        do {
            divisionCount--;
            if (divisionCount <= 0) {
                break;
            }
        } while (getDivision(divisionCount).isFullRange());
        return divisionCount;
    }

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes();

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr);

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr, int i2);

    @Override // LPT6.com3
    /* synthetic */ BigInteger getUpperValue();

    @Override // LPT6.com3
    /* synthetic */ BigInteger getValue();

    @Override // LPT6.com3
    /* synthetic */ boolean includesMax();

    @Override // LPT6.com3
    /* synthetic */ boolean includesZero();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean isFullRange() {
        return super.isFullRange();
    }

    @Override // LPT6.com3
    /* synthetic */ boolean isMax();

    default int isMore(com1 com1Var) {
        if (!isMultiple()) {
            return com1Var.isMultiple() ? -1 : 0;
        }
        if (com1Var.isMultiple()) {
            return getCount().compareTo(com1Var.getCount());
        }
        return 1;
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean isMultiple() {
        return super.isMultiple();
    }

    boolean isPrefixBlock();

    boolean isPrefixed();

    default boolean isSequential() {
        int divisionCount = getDivisionCount();
        if (divisionCount > 1) {
            for (int i2 = 0; i2 < divisionCount; i2++) {
                if (getDivision(i2).isMultiple()) {
                    for (int i3 = i2 + 1; i3 < divisionCount; i3++) {
                        if (!getDivision(i3).isFullRange()) {
                            return false;
                        }
                    }
                    return true;
                }
            }
        }
        return true;
    }

    boolean isSinglePrefixBlock();

    @Override // LPT6.com3
    /* synthetic */ boolean isZero();

    @Override // LPT6.com3
    default BigInteger getPrefixCount(int i2) {
        if (i2 >= 0 && i2 <= getBitCount()) {
            BigInteger bigIntegerMultiply = BigInteger.ONE;
            if (isMultiple()) {
                int divisionCount = getDivisionCount();
                for (int i3 = 0; i3 < divisionCount; i3++) {
                    com2 division = getDivision(i3);
                    int bitCount = division.getBitCount();
                    if (division.isMultiple()) {
                        bigIntegerMultiply = bigIntegerMultiply.multiply(i2 < bitCount ? division.getPrefixCount(i2) : division.getCount());
                    }
                    if (i2 <= bitCount) {
                        break;
                    }
                    i2 -= bitCount;
                }
            }
            return bigIntegerMultiply;
        }
        throw new lpt9(this, i2);
    }
}
