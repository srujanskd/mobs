package COM4;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class nul {
    public static void a(View view, con conVar) {
        view.setTag(aux.f5698a, conVar);
    }
}
