package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;
import p017CoM5.u;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    public static IconCompat read(u uVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f8171a = uVar.p(iconCompat.f8171a, 1);
        iconCompat.f2309a = uVar.j(iconCompat.f2309a, 2);
        iconCompat.f2306a = uVar.r(iconCompat.f2306a, 3);
        iconCompat.f2310b = uVar.p(iconCompat.f2310b, 4);
        iconCompat.f8172c = uVar.p(iconCompat.f8172c, 5);
        iconCompat.f2304a = (ColorStateList) uVar.r(iconCompat.f2304a, 6);
        iconCompat.f2308a = uVar.t(iconCompat.f2308a, 7);
        iconCompat.f2311b = uVar.t(iconCompat.f2311b, 8);
        iconCompat.l();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, u uVar) {
        uVar.x(true, true);
        iconCompat.m(uVar.f());
        int i2 = iconCompat.f8171a;
        if (-1 != i2) {
            uVar.F(i2, 1);
        }
        byte[] bArr = iconCompat.f2309a;
        if (bArr != null) {
            uVar.B(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f2306a;
        if (parcelable != null) {
            uVar.H(parcelable, 3);
        }
        int i3 = iconCompat.f2310b;
        if (i3 != 0) {
            uVar.F(i3, 4);
        }
        int i4 = iconCompat.f8172c;
        if (i4 != 0) {
            uVar.F(i4, 5);
        }
        ColorStateList colorStateList = iconCompat.f2304a;
        if (colorStateList != null) {
            uVar.H(colorStateList, 6);
        }
        String str = iconCompat.f2308a;
        if (str != null) {
            uVar.J(str, 7);
        }
        String str2 = iconCompat.f2311b;
        if (str2 != null) {
            uVar.J(str2, 8);
        }
    }
}
