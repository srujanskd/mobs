package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class nul extends com9 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static TimeInterpolator f8689a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList<RecyclerView.h> f8690b = new ArrayList<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ArrayList<RecyclerView.h> f8691c = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<com6> f8692d = new ArrayList<>();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList<com5> f8693e = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ArrayList<ArrayList<RecyclerView.h>> f8694f = new ArrayList<>();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList<ArrayList<com6>> f8695g = new ArrayList<>();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ArrayList<ArrayList<com5>> f8696h = new ArrayList<>();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public ArrayList<RecyclerView.h> f8697i = new ArrayList<>();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public ArrayList<RecyclerView.h> f8698j = new ArrayList<>();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ArrayList<RecyclerView.h> f8699k = new ArrayList<>();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public ArrayList<RecyclerView.h> f8700l = new ArrayList<>();

    public class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2885a;

        public aux(ArrayList arrayList) {
            this.f2885a = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            for (com6 com6Var : this.f2885a) {
                nul.this.S(com6Var.f2901a, com6Var.f8711a, com6Var.f8712b, com6Var.f8713c, com6Var.f8714d);
            }
            this.f2885a.clear();
            nul.this.f8695g.remove(this.f2885a);
        }
    }

    public class com1 extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8702a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewPropertyAnimator f2886a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ RecyclerView.h f2887a;

        public com1(RecyclerView.h hVar, View view, ViewPropertyAnimator viewPropertyAnimator) {
            this.f2887a = hVar;
            this.f8702a = view;
            this.f2886a = viewPropertyAnimator;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f8702a.setAlpha(1.0f);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2886a.setListener(null);
            nul.this.A(this.f2887a);
            nul.this.f8697i.remove(this.f2887a);
            nul.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            nul.this.B(this.f2887a);
        }
    }

    public class com2 extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f8703a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f2889a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewPropertyAnimator f2890a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ RecyclerView.h f2891a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f8704b;

        public com2(RecyclerView.h hVar, int i2, View view, int i3, ViewPropertyAnimator viewPropertyAnimator) {
            this.f2891a = hVar;
            this.f8703a = i2;
            this.f2889a = view;
            this.f8704b = i3;
            this.f2890a = viewPropertyAnimator;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            if (this.f8703a != 0) {
                this.f2889a.setTranslationX(0.0f);
            }
            if (this.f8704b != 0) {
                this.f2889a.setTranslationY(0.0f);
            }
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2890a.setListener(null);
            nul.this.E(this.f2891a);
            nul.this.f8698j.remove(this.f2891a);
            nul.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            nul.this.F(this.f2891a);
        }
    }

    public class com3 extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8705a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewPropertyAnimator f2893a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com5 f2894a;

        public com3(com5 com5Var, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.f2894a = com5Var;
            this.f2893a = viewPropertyAnimator;
            this.f8705a = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2893a.setListener(null);
            this.f8705a.setAlpha(1.0f);
            this.f8705a.setTranslationX(0.0f);
            this.f8705a.setTranslationY(0.0f);
            nul.this.C(this.f2894a.f2899a, true);
            nul.this.f8700l.remove(this.f2894a.f2899a);
            nul.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            nul.this.D(this.f2894a.f2899a, true);
        }
    }

    public class com4 extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8706a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewPropertyAnimator f2896a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com5 f2897a;

        public com4(com5 com5Var, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.f2897a = com5Var;
            this.f2896a = viewPropertyAnimator;
            this.f8706a = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2896a.setListener(null);
            this.f8706a.setAlpha(1.0f);
            this.f8706a.setTranslationX(0.0f);
            this.f8706a.setTranslationY(0.0f);
            nul.this.C(this.f2897a.f2900b, false);
            nul.this.f8700l.remove(this.f2897a.f2900b);
            nul.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            nul.this.D(this.f2897a.f2900b, false);
        }
    }

    public static class com6 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8711a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView.h f2901a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8712b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8713c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8714d;

        public com6(RecyclerView.h hVar, int i2, int i3, int i4, int i5) {
            this.f2901a = hVar;
            this.f8711a = i2;
            this.f8712b = i3;
            this.f8713c = i4;
            this.f8714d = i5;
        }
    }

    public class con implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2902a;

        public con(ArrayList arrayList) {
            this.f2902a = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f2902a.iterator();
            while (it.hasNext()) {
                nul.this.R((com5) it.next());
            }
            this.f2902a.clear();
            nul.this.f8696h.remove(this.f2902a);
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.nul$nul, reason: collision with other inner class name */
    public class RunnableC0048nul implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2903a;

        public RunnableC0048nul(ArrayList arrayList) {
            this.f2903a = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            Iterator it = this.f2903a.iterator();
            while (it.hasNext()) {
                nul.this.Q((RecyclerView.h) it.next());
            }
            this.f2903a.clear();
            nul.this.f8694f.remove(this.f2903a);
        }
    }

    public class prn extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8717a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewPropertyAnimator f2904a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ RecyclerView.h f2905a;

        public prn(RecyclerView.h hVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
            this.f2905a = hVar;
            this.f2904a = viewPropertyAnimator;
            this.f8717a = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2904a.setListener(null);
            this.f8717a.setAlpha(1.0f);
            nul.this.G(this.f2905a);
            nul.this.f8699k.remove(this.f2905a);
            nul.this.V();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            nul.this.H(this.f2905a);
        }
    }

    public void Q(RecyclerView.h hVar) {
        View view = hVar.f2786a;
        ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
        this.f8697i.add(hVar);
        viewPropertyAnimatorAnimate.alpha(1.0f).setDuration(l()).setListener(new com1(hVar, view, viewPropertyAnimatorAnimate)).start();
    }

    public void R(com5 com5Var) {
        RecyclerView.h hVar = com5Var.f2899a;
        View view = hVar == null ? null : hVar.f2786a;
        RecyclerView.h hVar2 = com5Var.f2900b;
        View view2 = hVar2 != null ? hVar2.f2786a : null;
        if (view != null) {
            ViewPropertyAnimator duration = view.animate().setDuration(m());
            this.f8700l.add(com5Var.f2899a);
            duration.translationX(com5Var.f8709c - com5Var.f8707a);
            duration.translationY(com5Var.f8710d - com5Var.f8708b);
            duration.alpha(0.0f).setListener(new com3(com5Var, duration, view)).start();
        }
        if (view2 != null) {
            ViewPropertyAnimator viewPropertyAnimatorAnimate = view2.animate();
            this.f8700l.add(com5Var.f2900b);
            viewPropertyAnimatorAnimate.translationX(0.0f).translationY(0.0f).setDuration(m()).alpha(1.0f).setListener(new com4(com5Var, viewPropertyAnimatorAnimate, view2)).start();
        }
    }

    public void S(RecyclerView.h hVar, int i2, int i3, int i4, int i5) {
        View view = hVar.f2786a;
        int i6 = i4 - i2;
        int i7 = i5 - i3;
        if (i6 != 0) {
            view.animate().translationX(0.0f);
        }
        if (i7 != 0) {
            view.animate().translationY(0.0f);
        }
        ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
        this.f8698j.add(hVar);
        viewPropertyAnimatorAnimate.setDuration(n()).setListener(new com2(hVar, i6, view, i7, viewPropertyAnimatorAnimate)).start();
    }

    public final void T(RecyclerView.h hVar) {
        View view = hVar.f2786a;
        ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
        this.f8699k.add(hVar);
        viewPropertyAnimatorAnimate.setDuration(o()).alpha(0.0f).setListener(new prn(hVar, viewPropertyAnimatorAnimate, view)).start();
    }

    public void U(List<RecyclerView.h> list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            list.get(size).f2786a.animate().cancel();
        }
    }

    public void V() {
        if (p()) {
            return;
        }
        i();
    }

    public final void W(List<com5> list, RecyclerView.h hVar) {
        for (int size = list.size() - 1; size >= 0; size--) {
            com5 com5Var = list.get(size);
            if (Y(com5Var, hVar) && com5Var.f2899a == null && com5Var.f2900b == null) {
                list.remove(com5Var);
            }
        }
    }

    public final void X(com5 com5Var) {
        RecyclerView.h hVar = com5Var.f2899a;
        if (hVar != null) {
            Y(com5Var, hVar);
        }
        RecyclerView.h hVar2 = com5Var.f2900b;
        if (hVar2 != null) {
            Y(com5Var, hVar2);
        }
    }

    public final boolean Y(com5 com5Var, RecyclerView.h hVar) {
        boolean z2 = false;
        if (com5Var.f2900b == hVar) {
            com5Var.f2900b = null;
        } else {
            if (com5Var.f2899a != hVar) {
                return false;
            }
            com5Var.f2899a = null;
            z2 = true;
        }
        hVar.f2786a.setAlpha(1.0f);
        hVar.f2786a.setTranslationX(0.0f);
        hVar.f2786a.setTranslationY(0.0f);
        C(hVar, z2);
        return true;
    }

    public final void Z(RecyclerView.h hVar) {
        if (f8689a == null) {
            f8689a = new ValueAnimator().getInterpolator();
        }
        hVar.f2786a.animate().setInterpolator(f8689a);
        j(hVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean g(RecyclerView.h hVar, List<Object> list) {
        return !list.isEmpty() || super.g(hVar, list);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public void j(RecyclerView.h hVar) {
        View view = hVar.f2786a;
        view.animate().cancel();
        int size = this.f8692d.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            if (this.f8692d.get(size).f2901a == hVar) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                E(hVar);
                this.f8692d.remove(size);
            }
        }
        W(this.f8693e, hVar);
        if (this.f8690b.remove(hVar)) {
            view.setAlpha(1.0f);
            G(hVar);
        }
        if (this.f8691c.remove(hVar)) {
            view.setAlpha(1.0f);
            A(hVar);
        }
        for (int size2 = this.f8696h.size() - 1; size2 >= 0; size2--) {
            ArrayList<com5> arrayList = this.f8696h.get(size2);
            W(arrayList, hVar);
            if (arrayList.isEmpty()) {
                this.f8696h.remove(size2);
            }
        }
        for (int size3 = this.f8695g.size() - 1; size3 >= 0; size3--) {
            ArrayList<com6> arrayList2 = this.f8695g.get(size3);
            for (int size4 = arrayList2.size() - 1; size4 >= 0; size4--) {
                if (arrayList2.get(size4).f2901a == hVar) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    E(hVar);
                    arrayList2.remove(size4);
                    if (!arrayList2.isEmpty()) {
                        break;
                    }
                    this.f8695g.remove(size3);
                    break;
                }
            }
        }
        for (int size5 = this.f8694f.size() - 1; size5 >= 0; size5--) {
            ArrayList<RecyclerView.h> arrayList3 = this.f8694f.get(size5);
            if (arrayList3.remove(hVar)) {
                view.setAlpha(1.0f);
                A(hVar);
                if (arrayList3.isEmpty()) {
                    this.f8694f.remove(size5);
                }
            }
        }
        this.f8699k.remove(hVar);
        this.f8697i.remove(hVar);
        this.f8700l.remove(hVar);
        this.f8698j.remove(hVar);
        V();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public void k() {
        int size = this.f8692d.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            com6 com6Var = this.f8692d.get(size);
            View view = com6Var.f2901a.f2786a;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            E(com6Var.f2901a);
            this.f8692d.remove(size);
        }
        for (int size2 = this.f8690b.size() - 1; size2 >= 0; size2--) {
            G(this.f8690b.get(size2));
            this.f8690b.remove(size2);
        }
        int size3 = this.f8691c.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            RecyclerView.h hVar = this.f8691c.get(size3);
            hVar.f2786a.setAlpha(1.0f);
            A(hVar);
            this.f8691c.remove(size3);
        }
        for (int size4 = this.f8693e.size() - 1; size4 >= 0; size4--) {
            X(this.f8693e.get(size4));
        }
        this.f8693e.clear();
        if (p()) {
            for (int size5 = this.f8695g.size() - 1; size5 >= 0; size5--) {
                ArrayList<com6> arrayList = this.f8695g.get(size5);
                for (int size6 = arrayList.size() - 1; size6 >= 0; size6--) {
                    com6 com6Var2 = arrayList.get(size6);
                    View view2 = com6Var2.f2901a.f2786a;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    E(com6Var2.f2901a);
                    arrayList.remove(size6);
                    if (arrayList.isEmpty()) {
                        this.f8695g.remove(arrayList);
                    }
                }
            }
            for (int size7 = this.f8694f.size() - 1; size7 >= 0; size7--) {
                ArrayList<RecyclerView.h> arrayList2 = this.f8694f.get(size7);
                for (int size8 = arrayList2.size() - 1; size8 >= 0; size8--) {
                    RecyclerView.h hVar2 = arrayList2.get(size8);
                    hVar2.f2786a.setAlpha(1.0f);
                    A(hVar2);
                    arrayList2.remove(size8);
                    if (arrayList2.isEmpty()) {
                        this.f8694f.remove(arrayList2);
                    }
                }
            }
            for (int size9 = this.f8696h.size() - 1; size9 >= 0; size9--) {
                ArrayList<com5> arrayList3 = this.f8696h.get(size9);
                for (int size10 = arrayList3.size() - 1; size10 >= 0; size10--) {
                    X(arrayList3.get(size10));
                    if (arrayList3.isEmpty()) {
                        this.f8696h.remove(arrayList3);
                    }
                }
            }
            U(this.f8699k);
            U(this.f8698j);
            U(this.f8697i);
            U(this.f8700l);
            i();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean p() {
        return (this.f8691c.isEmpty() && this.f8693e.isEmpty() && this.f8692d.isEmpty() && this.f8690b.isEmpty() && this.f8698j.isEmpty() && this.f8699k.isEmpty() && this.f8697i.isEmpty() && this.f8700l.isEmpty() && this.f8695g.isEmpty() && this.f8694f.isEmpty() && this.f8696h.isEmpty()) ? false : true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public void u() {
        boolean z2 = !this.f8690b.isEmpty();
        boolean z3 = !this.f8692d.isEmpty();
        boolean z4 = !this.f8693e.isEmpty();
        boolean z5 = !this.f8691c.isEmpty();
        if (z2 || z3 || z5 || z4) {
            Iterator<RecyclerView.h> it = this.f8690b.iterator();
            while (it.hasNext()) {
                T(it.next());
            }
            this.f8690b.clear();
            if (z3) {
                ArrayList<com6> arrayList = new ArrayList<>();
                arrayList.addAll(this.f8692d);
                this.f8695g.add(arrayList);
                this.f8692d.clear();
                aux auxVar = new aux(arrayList);
                if (z2) {
                    y.h0(arrayList.get(0).f2901a.f2786a, auxVar, o());
                } else {
                    auxVar.run();
                }
            }
            if (z4) {
                ArrayList<com5> arrayList2 = new ArrayList<>();
                arrayList2.addAll(this.f8693e);
                this.f8696h.add(arrayList2);
                this.f8693e.clear();
                con conVar = new con(arrayList2);
                if (z2) {
                    y.h0(arrayList2.get(0).f2899a.f2786a, conVar, o());
                } else {
                    conVar.run();
                }
            }
            if (z5) {
                ArrayList<RecyclerView.h> arrayList3 = new ArrayList<>();
                arrayList3.addAll(this.f8691c);
                this.f8694f.add(arrayList3);
                this.f8691c.clear();
                RunnableC0048nul runnableC0048nul = new RunnableC0048nul(arrayList3);
                if (z2 || z3 || z4) {
                    y.h0(arrayList3.get(0).f2786a, runnableC0048nul, (z2 ? o() : 0L) + Math.max(z3 ? n() : 0L, z4 ? m() : 0L));
                } else {
                    runnableC0048nul.run();
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.com9
    public boolean w(RecyclerView.h hVar) {
        Z(hVar);
        hVar.f2786a.setAlpha(0.0f);
        this.f8691c.add(hVar);
        return true;
    }

    @Override // androidx.recyclerview.widget.com9
    public boolean x(RecyclerView.h hVar, RecyclerView.h hVar2, int i2, int i3, int i4, int i5) {
        if (hVar == hVar2) {
            return y(hVar, i2, i3, i4, i5);
        }
        float translationX = hVar.f2786a.getTranslationX();
        float translationY = hVar.f2786a.getTranslationY();
        float alpha = hVar.f2786a.getAlpha();
        Z(hVar);
        int i6 = (int) ((i4 - i2) - translationX);
        int i7 = (int) ((i5 - i3) - translationY);
        hVar.f2786a.setTranslationX(translationX);
        hVar.f2786a.setTranslationY(translationY);
        hVar.f2786a.setAlpha(alpha);
        if (hVar2 != null) {
            Z(hVar2);
            hVar2.f2786a.setTranslationX(-i6);
            hVar2.f2786a.setTranslationY(-i7);
            hVar2.f2786a.setAlpha(0.0f);
        }
        this.f8693e.add(new com5(hVar, hVar2, i2, i3, i4, i5));
        return true;
    }

    @Override // androidx.recyclerview.widget.com9
    public boolean y(RecyclerView.h hVar, int i2, int i3, int i4, int i5) {
        View view = hVar.f2786a;
        int translationX = i2 + ((int) view.getTranslationX());
        int translationY = i3 + ((int) hVar.f2786a.getTranslationY());
        Z(hVar);
        int i6 = i4 - translationX;
        int i7 = i5 - translationY;
        if (i6 == 0 && i7 == 0) {
            E(hVar);
            return false;
        }
        if (i6 != 0) {
            view.setTranslationX(-i6);
        }
        if (i7 != 0) {
            view.setTranslationY(-i7);
        }
        this.f8692d.add(new com6(hVar, translationX, translationY, i4, i5));
        return true;
    }

    @Override // androidx.recyclerview.widget.com9
    public boolean z(RecyclerView.h hVar) {
        Z(hVar);
        this.f8690b.add(hVar);
        return true;
    }

    public static class com5 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8707a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView.h f2899a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8708b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public RecyclerView.h f2900b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8709c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8710d;

        public com5(RecyclerView.h hVar, RecyclerView.h hVar2) {
            this.f2899a = hVar;
            this.f2900b = hVar2;
        }

        public String toString() {
            return "ChangeInfo{oldHolder=" + this.f2899a + ", newHolder=" + this.f2900b + ", fromX=" + this.f8707a + ", fromY=" + this.f8708b + ", toX=" + this.f8709c + ", toY=" + this.f8710d + '}';
        }

        public com5(RecyclerView.h hVar, RecyclerView.h hVar2, int i2, int i3, int i4, int i5) {
            this(hVar, hVar2);
            this.f8707a = i2;
            this.f8708b = i3;
            this.f8709c = i4;
            this.f8710d = i5;
        }
    }
}
