package com.google.android.material.bottomsheet;

import COM9.com3;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import p024Com2.lpt3;
import p024Com2.s;
import p024Com2.t0;
import p024Com2.y;
import p066aUX.c;
import p075cOM6.b4;
import p075cOM6.d4;
import p075cOM6.g4;
import p075cOM6.x3;
import p081cOm2.e2;

/* JADX INFO: loaded from: classes.dex */
public class aux extends c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public FrameLayout f9362a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CoordinatorLayout f3370a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public BottomSheetBehavior.com2 f3371a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public BottomSheetBehavior<FrameLayout> f3372a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public FrameLayout f9363b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public BottomSheetBehavior.com2 f3373b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3374b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f9364c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f9365d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9366e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9367f;

    /* JADX INFO: renamed from: com.google.android.material.bottomsheet.aux$aux, reason: collision with other inner class name */
    public class C0055aux implements s {
        public C0055aux() {
        }

        @Override // p024Com2.s
        public t0 a(View view, t0 t0Var) {
            if (aux.this.f3371a != null) {
                aux.this.f3372a.q0(aux.this.f3371a);
            }
            if (t0Var != null) {
                aux auxVar = aux.this;
                auxVar.f3371a = new com2(auxVar.f9363b, t0Var, null);
                aux.this.f3372a.W(aux.this.f3371a);
            }
            return t0Var;
        }
    }

    public class com1 extends BottomSheetBehavior.com2 {
        public com1() {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void b(View view, float f2) {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void c(View view, int i2) {
            if (i2 == 5) {
                aux.this.cancel();
            }
        }
    }

    public static class com2 extends BottomSheetBehavior.com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final t0 f9370a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final boolean f3375a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final boolean f9371b;

        public /* synthetic */ com2(View view, t0 t0Var, C0055aux c0055aux) {
            this(view, t0Var);
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void a(View view) {
            d(view);
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void b(View view, float f2) {
            d(view);
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void c(View view, int i2) {
            d(view);
        }

        public final void d(View view) {
            if (view.getTop() < this.f9370a.l()) {
                aux.o(view, this.f3375a);
                view.setPadding(view.getPaddingLeft(), this.f9370a.l() - view.getTop(), view.getPaddingRight(), view.getPaddingBottom());
            } else if (view.getTop() != 0) {
                aux.o(view, this.f9371b);
                view.setPadding(view.getPaddingLeft(), 0, view.getPaddingRight(), view.getPaddingBottom());
            }
        }

        public com2(View view, t0 t0Var) {
            this.f9370a = t0Var;
            boolean z2 = (view.getSystemUiVisibility() & 8192) != 0;
            this.f9371b = z2;
            com3 com3VarI0 = BottomSheetBehavior.f0(view).i0();
            ColorStateList colorStateListX = com3VarI0 != null ? com3VarI0.x() : y.r(view);
            if (colorStateListX != null) {
                this.f3375a = p030Com8.prn.f(colorStateListX.getDefaultColor());
            } else if (view.getBackground() instanceof ColorDrawable) {
                this.f3375a = p030Com8.prn.f(((ColorDrawable) view.getBackground()).getColor());
            } else {
                this.f3375a = z2;
            }
        }
    }

    public class con implements View.OnClickListener {
        public con() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            aux auxVar = aux.this;
            if (auxVar.f9364c && auxVar.isShowing() && aux.this.p()) {
                aux.this.cancel();
            }
        }
    }

    public class nul extends lpt3 {
        public nul() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            if (!aux.this.f9364c) {
                e2Var.Y(false);
            } else {
                e2Var.a(inet.ipaddr.format.validate.aux.KEY_RANGE_WILDCARD);
                e2Var.Y(true);
            }
        }

        @Override // p024Com2.lpt3
        public boolean j(View view, int i2, Bundle bundle) {
            if (i2 == 1048576) {
                aux auxVar = aux.this;
                if (auxVar.f9364c) {
                    auxVar.cancel();
                    return true;
                }
            }
            return super.j(view, i2, bundle);
        }
    }

    public class prn implements View.OnTouchListener {
        public prn() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return true;
        }
    }

    public aux(Context context, int i2) {
        super(context, c(context, i2));
        this.f9364c = true;
        this.f9365d = true;
        this.f3373b = new com1();
        e(1);
        this.f9367f = getContext().getTheme().obtainStyledAttributes(new int[]{x3.f9043r}).getBoolean(0, false);
    }

    public static int c(Context context, int i2) {
        if (i2 != 0) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        return context.getTheme().resolveAttribute(x3.f9028c, typedValue, true) ? typedValue.resourceId : g4.f8959d;
    }

    public static void o(View view, boolean z2) {
        int systemUiVisibility = view.getSystemUiVisibility();
        view.setSystemUiVisibility(z2 ? systemUiVisibility | 8192 : systemUiVisibility & (-8193));
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void cancel() {
        BottomSheetBehavior<FrameLayout> bottomSheetBehaviorL = l();
        if (!this.f3374b || bottomSheetBehaviorL.j0() == 5) {
            super.cancel();
        } else {
            bottomSheetBehaviorL.H0(5);
        }
    }

    public final FrameLayout k() {
        if (this.f9362a == null) {
            FrameLayout frameLayout = (FrameLayout) View.inflate(getContext(), d4.f8907a, null);
            this.f9362a = frameLayout;
            this.f3370a = (CoordinatorLayout) frameLayout.findViewById(b4.f8881d);
            FrameLayout frameLayout2 = (FrameLayout) this.f9362a.findViewById(b4.f8882e);
            this.f9363b = frameLayout2;
            BottomSheetBehavior<FrameLayout> bottomSheetBehaviorF0 = BottomSheetBehavior.f0(frameLayout2);
            this.f3372a = bottomSheetBehaviorF0;
            bottomSheetBehaviorF0.W(this.f3373b);
            this.f3372a.A0(this.f9364c);
        }
        return this.f9362a;
    }

    public BottomSheetBehavior<FrameLayout> l() {
        if (this.f3372a == null) {
            k();
        }
        return this.f3372a;
    }

    public boolean m() {
        return this.f3374b;
    }

    public void n() {
        this.f3372a.q0(this.f3373b);
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        if (window != null) {
            boolean z2 = this.f9367f && Color.alpha(window.getNavigationBarColor()) < 255;
            FrameLayout frameLayout = this.f9362a;
            if (frameLayout != null) {
                frameLayout.setFitsSystemWindows(!z2);
            }
            CoordinatorLayout coordinatorLayout = this.f3370a;
            if (coordinatorLayout != null) {
                coordinatorLayout.setFitsSystemWindows(!z2);
            }
            if (z2) {
                window.getDecorView().setSystemUiVisibility(inet.ipaddr.ipv6.nul.com4.COMPRESSION_SINGLE);
            }
        }
    }

    @Override // p066aUX.c, android.app.Dialog
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        if (window != null) {
            window.setStatusBarColor(0);
            window.addFlags(Integer.MIN_VALUE);
            window.setLayout(-1, -1);
        }
    }

    @Override // android.app.Dialog
    public void onStart() {
        super.onStart();
        BottomSheetBehavior<FrameLayout> bottomSheetBehavior = this.f3372a;
        if (bottomSheetBehavior == null || bottomSheetBehavior.j0() != 5) {
            return;
        }
        this.f3372a.H0(4);
    }

    public boolean p() {
        if (!this.f9366e) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(new int[]{R.attr.windowCloseOnTouchOutside});
            this.f9365d = typedArrayObtainStyledAttributes.getBoolean(0, true);
            typedArrayObtainStyledAttributes.recycle();
            this.f9366e = true;
        }
        return this.f9365d;
    }

    public final View q(int i2, View view, ViewGroup.LayoutParams layoutParams) {
        k();
        CoordinatorLayout coordinatorLayout = (CoordinatorLayout) this.f9362a.findViewById(b4.f8881d);
        if (i2 != 0 && view == null) {
            view = getLayoutInflater().inflate(i2, (ViewGroup) coordinatorLayout, false);
        }
        if (this.f9367f) {
            y.B0(this.f9363b, new C0055aux());
        }
        this.f9363b.removeAllViews();
        if (layoutParams == null) {
            this.f9363b.addView(view);
        } else {
            this.f9363b.addView(view, layoutParams);
        }
        coordinatorLayout.findViewById(b4.f8880c0).setOnClickListener(new con());
        y.o0(this.f9363b, new nul());
        this.f9363b.setOnTouchListener(new prn());
        return this.f9362a;
    }

    @Override // android.app.Dialog
    public void setCancelable(boolean z2) {
        super.setCancelable(z2);
        if (this.f9364c != z2) {
            this.f9364c = z2;
            BottomSheetBehavior<FrameLayout> bottomSheetBehavior = this.f3372a;
            if (bottomSheetBehavior != null) {
                bottomSheetBehavior.A0(z2);
            }
        }
    }

    @Override // android.app.Dialog
    public void setCanceledOnTouchOutside(boolean z2) {
        super.setCanceledOnTouchOutside(z2);
        if (z2 && !this.f9364c) {
            this.f9364c = true;
        }
        this.f9365d = z2;
        this.f9366e = true;
    }

    @Override // p066aUX.c, android.app.Dialog
    public void setContentView(int i2) {
        super.setContentView(q(i2, null, null));
    }

    @Override // p066aUX.c, android.app.Dialog
    public void setContentView(View view) {
        super.setContentView(q(0, view, null));
    }

    @Override // p066aUX.c, android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        super.setContentView(q(0, view, layoutParams));
    }
}
