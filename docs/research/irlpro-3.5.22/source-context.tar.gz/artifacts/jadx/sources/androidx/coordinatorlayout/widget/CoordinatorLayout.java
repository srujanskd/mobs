package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import p024Com2.f;
import p024Com2.p;
import p024Com2.q;
import p024Com2.r;
import p024Com2.s;
import p024Com2.t0;
import p024Com2.y;
import p101com2.p2;
import p101com2.r2;
import p101com2.t2;
import p152prN.k0;
import p152prN.l0;

/* JADX INFO: loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements p, q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final r2<Rect> f8151a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final String f2270a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final ThreadLocal<Map<String, Constructor<nul>>> f2271a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final Comparator<View> f2272a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final Class<?>[] f2273a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final r f2274a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public s f2275a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public t0 f2276a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Paint f2277a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2278a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f2279a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewGroup.OnHierarchyChangeListener f2280a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f2281a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<View> f2282a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final k0<View> f2283a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2284a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public View f8152b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final List<View> f2285b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2286b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int[] f2287b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List<View> f8153c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2288c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int[] f2289c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8154d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f8155e;

    public class aux implements s {
        public aux() {
        }

        @Override // p024Com2.s
        public t0 a(View view, t0 t0Var) {
            return CoordinatorLayout.this.W(t0Var);
        }
    }

    public class com1 implements ViewGroup.OnHierarchyChangeListener {
        public com1() {
        }

        @Override // android.view.ViewGroup.OnHierarchyChangeListener
        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2280a;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        @Override // android.view.ViewGroup.OnHierarchyChangeListener
        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.H(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2280a;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    public class com3 implements ViewTreeObserver.OnPreDrawListener {
        public com3() {
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            CoordinatorLayout.this.H(0);
            return true;
        }
    }

    public static class com5 implements Comparator<View> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(View view, View view2) {
            float fL = y.L(view);
            float fL2 = y.L(view2);
            if (fL > fL2) {
                return -1;
            }
            return fL < fL2 ? 1 : 0;
        }
    }

    public interface con {
        nul getBehavior();
    }

    public static abstract class nul<V extends View> {
        public nul() {
        }

        public boolean A(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2, int i3) {
            if (i3 == 0) {
                return z(coordinatorLayout, v2, view, view2, i2);
            }
            return false;
        }

        @Deprecated
        public void B(CoordinatorLayout coordinatorLayout, V v2, View view) {
        }

        public void C(CoordinatorLayout coordinatorLayout, V v2, View view, int i2) {
            if (i2 == 0) {
                B(coordinatorLayout, v2, view);
            }
        }

        public boolean D(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
            return false;
        }

        public boolean a(CoordinatorLayout coordinatorLayout, V v2) {
            return d(coordinatorLayout, v2) > 0.0f;
        }

        public boolean b(CoordinatorLayout coordinatorLayout, V v2, Rect rect) {
            return false;
        }

        public int c(CoordinatorLayout coordinatorLayout, V v2) {
            return -16777216;
        }

        public float d(CoordinatorLayout coordinatorLayout, V v2) {
            return 0.0f;
        }

        public boolean e(CoordinatorLayout coordinatorLayout, V v2, View view) {
            return false;
        }

        public t0 f(CoordinatorLayout coordinatorLayout, V v2, t0 t0Var) {
            return t0Var;
        }

        public void g(com2 com2Var) {
        }

        public boolean h(CoordinatorLayout coordinatorLayout, V v2, View view) {
            return false;
        }

        public void i(CoordinatorLayout coordinatorLayout, V v2, View view) {
        }

        public void j() {
        }

        public boolean k(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
            return false;
        }

        public boolean l(CoordinatorLayout coordinatorLayout, V v2, int i2) {
            return false;
        }

        public boolean m(CoordinatorLayout coordinatorLayout, V v2, int i2, int i3, int i4, int i5) {
            return false;
        }

        public boolean n(CoordinatorLayout coordinatorLayout, V v2, View view, float f2, float f3, boolean z2) {
            return false;
        }

        public boolean o(CoordinatorLayout coordinatorLayout, V v2, View view, float f2, float f3) {
            return false;
        }

        @Deprecated
        public void p(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int[] iArr) {
        }

        public void q(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int[] iArr, int i4) {
            if (i4 == 0) {
                p(coordinatorLayout, v2, view, i2, i3, iArr);
            }
        }

        @Deprecated
        public void r(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int i4, int i5) {
        }

        @Deprecated
        public void s(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int i4, int i5, int i6) {
            if (i6 == 0) {
                r(coordinatorLayout, v2, view, i2, i3, i4, i5);
            }
        }

        public void t(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            iArr[0] = iArr[0] + i4;
            iArr[1] = iArr[1] + i5;
            s(coordinatorLayout, v2, view, i2, i3, i4, i5, i6);
        }

        @Deprecated
        public void u(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2) {
        }

        public void v(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2, int i3) {
            if (i3 == 0) {
                u(coordinatorLayout, v2, view, view2, i2);
            }
        }

        public boolean w(CoordinatorLayout coordinatorLayout, V v2, Rect rect, boolean z2) {
            return false;
        }

        public void x(CoordinatorLayout coordinatorLayout, V v2, Parcelable parcelable) {
        }

        public Parcelable y(CoordinatorLayout coordinatorLayout, V v2) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        @Deprecated
        public boolean z(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2) {
            return false;
        }

        public nul(Context context, AttributeSet attributeSet) {
        }
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Deprecated
    public @interface prn {
        Class<? extends nul> value();
    }

    static {
        Package r0 = CoordinatorLayout.class.getPackage();
        f2270a = r0 != null ? r0.getName() : null;
        f2272a = new com5();
        f2273a = new Class[]{Context.class, AttributeSet.class};
        f2271a = new ThreadLocal<>();
        f8151a = new t2(12);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, p063PRn.prn.f7487a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static nul K(Context context, AttributeSet attributeSet, String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith(".")) {
            str = context.getPackageName() + str;
        } else if (str.indexOf(46) < 0) {
            String str2 = f2270a;
            if (!TextUtils.isEmpty(str2)) {
                str = str2 + '.' + str;
            }
        }
        try {
            ThreadLocal<Map<String, Constructor<nul>>> threadLocal = f2271a;
            Map<String, Constructor<nul>> map = threadLocal.get();
            if (map == null) {
                map = new HashMap<>();
                threadLocal.set(map);
            }
            Constructor<nul> constructor = map.get(str);
            if (constructor == null) {
                constructor = Class.forName(str, false, context.getClassLoader()).getConstructor(f2273a);
                constructor.setAccessible(true);
                map.put(str, constructor);
            }
            return constructor.newInstance(context, attributeSet);
        } catch (Exception e2) {
            throw new RuntimeException("Could not inflate Behavior subclass " + str, e2);
        }
    }

    public static void O(Rect rect) {
        rect.setEmpty();
        f8151a.a(rect);
    }

    public static int R(int i2) {
        if (i2 == 0) {
            return 17;
        }
        return i2;
    }

    public static int S(int i2) {
        if ((i2 & 7) == 0) {
            i2 |= 8388611;
        }
        return (i2 & 112) == 0 ? i2 | 48 : i2;
    }

    public static int T(int i2) {
        if (i2 == 0) {
            return 8388661;
        }
        return i2;
    }

    public static Rect a() {
        Rect rectB = f8151a.b();
        return rectB == null ? new Rect() : rectB;
    }

    public static int c(int i2, int i3, int i4) {
        if (i2 < i3) {
            return i3;
        }
        return i2 > i4 ? i4 : i2;
    }

    public final boolean A(View view) {
        return this.f2283a.j(view);
    }

    public boolean B(View view, int i2, int i3) {
        Rect rectA = a();
        t(view, rectA);
        try {
            return rectA.contains(i2, i3);
        } finally {
            O(rectA);
        }
    }

    public final void C(View view, int i2) {
        com2 com2Var = (com2) view.getLayoutParams();
        Rect rectA = a();
        rectA.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) com2Var).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) com2Var).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) com2Var).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin);
        if (this.f2276a != null && y.x(this) && !y.x(view)) {
            rectA.left += this.f2276a.j();
            rectA.top += this.f2276a.l();
            rectA.right -= this.f2276a.k();
            rectA.bottom -= this.f2276a.i();
        }
        Rect rectA2 = a();
        f.a(S(com2Var.f8158a), view.getMeasuredWidth(), view.getMeasuredHeight(), rectA, rectA2, i2);
        view.layout(rectA2.left, rectA2.top, rectA2.right, rectA2.bottom);
        O(rectA);
        O(rectA2);
    }

    public final void D(View view, View view2, int i2) {
        Rect rectA = a();
        Rect rectA2 = a();
        try {
            t(view2, rectA);
            u(view, i2, rectA, rectA2);
            view.layout(rectA2.left, rectA2.top, rectA2.right, rectA2.bottom);
        } finally {
            O(rectA);
            O(rectA2);
        }
    }

    public final void E(View view, int i2, int i3) {
        com2 com2Var = (com2) view.getLayoutParams();
        int iB = f.b(T(com2Var.f8158a), i3);
        int i4 = iB & 7;
        int i5 = iB & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        if (i3 == 1) {
            i2 = width - i2;
        }
        int iW = w(i2) - measuredWidth;
        if (i4 == 1) {
            iW += measuredWidth / 2;
        } else if (i4 == 5) {
            iW += measuredWidth;
        }
        int i6 = 0;
        if (i5 == 16) {
            i6 = 0 + (measuredHeight / 2);
        } else if (i5 == 80) {
            i6 = measuredHeight + 0;
        }
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) com2Var).leftMargin, Math.min(iW, ((width - getPaddingRight()) - measuredWidth) - ((ViewGroup.MarginLayoutParams) com2Var).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) com2Var).topMargin, Math.min(i6, ((height - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin));
        view.layout(iMax, iMax2, measuredWidth + iMax, measuredHeight + iMax2);
    }

    public final void F(View view, Rect rect, int i2) {
        boolean z2;
        boolean z3;
        int width;
        int i3;
        int i4;
        int i5;
        int height;
        int i6;
        int i7;
        int i8;
        if (y.S(view) && view.getWidth() > 0 && view.getHeight() > 0) {
            com2 com2Var = (com2) view.getLayoutParams();
            nul nulVarF = com2Var.f();
            Rect rectA = a();
            Rect rectA2 = a();
            rectA2.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            if (nulVarF == null || !nulVarF.b(this, view, rectA)) {
                rectA.set(rectA2);
            } else if (!rectA2.contains(rectA)) {
                throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + rectA.toShortString() + " | Bounds:" + rectA2.toShortString());
            }
            O(rectA2);
            if (rectA.isEmpty()) {
                O(rectA);
                return;
            }
            int iB = f.b(com2Var.f8163f, i2);
            boolean z4 = true;
            if ((iB & 48) != 48 || (i7 = (rectA.top - ((ViewGroup.MarginLayoutParams) com2Var).topMargin) - com2Var.f8165h) >= (i8 = rect.top)) {
                z2 = false;
            } else {
                V(view, i8 - i7);
                z2 = true;
            }
            if ((iB & 80) == 80 && (height = ((getHeight() - rectA.bottom) - ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin) + com2Var.f8165h) < (i6 = rect.bottom)) {
                V(view, height - i6);
                z2 = true;
            }
            if (!z2) {
                V(view, 0);
            }
            if ((iB & 3) != 3 || (i4 = (rectA.left - ((ViewGroup.MarginLayoutParams) com2Var).leftMargin) - com2Var.f8164g) >= (i5 = rect.left)) {
                z3 = false;
            } else {
                U(view, i5 - i4);
                z3 = true;
            }
            if ((iB & 5) != 5 || (width = ((getWidth() - rectA.right) - ((ViewGroup.MarginLayoutParams) com2Var).rightMargin) + com2Var.f8164g) >= (i3 = rect.right)) {
                z4 = z3;
            } else {
                U(view, width - i3);
            }
            if (!z4) {
                U(view, 0);
            }
            O(rectA);
        }
    }

    public void G(View view, int i2) {
        nul nulVarF;
        com2 com2Var = (com2) view.getLayoutParams();
        if (com2Var.f2291a != null) {
            Rect rectA = a();
            Rect rectA2 = a();
            Rect rectA3 = a();
            t(com2Var.f2291a, rectA);
            q(view, false, rectA2);
            int measuredWidth = view.getMeasuredWidth();
            int measuredHeight = view.getMeasuredHeight();
            v(view, i2, rectA, rectA3, com2Var, measuredWidth, measuredHeight);
            boolean z2 = (rectA3.left == rectA2.left && rectA3.top == rectA2.top) ? false : true;
            d(com2Var, rectA3, measuredWidth, measuredHeight);
            int i3 = rectA3.left - rectA2.left;
            int i4 = rectA3.top - rectA2.top;
            if (i3 != 0) {
                y.Y(view, i3);
            }
            if (i4 != 0) {
                y.Z(view, i4);
            }
            if (z2 && (nulVarF = com2Var.f()) != null) {
                nulVarF.h(this, view, com2Var.f2291a);
            }
            O(rectA);
            O(rectA2);
            O(rectA3);
        }
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00ca  */
    public final void H(int i2) {
        int i3;
        nul nulVarF;
        boolean zH;
        int iA = y.A(this);
        int size = this.f2282a.size();
        Rect rectA = a();
        Rect rectA2 = a();
        Rect rectA3 = a();
        for (int i4 = 0; i4 < size; i4++) {
            View view = this.f2282a.get(i4);
            com2 com2Var = (com2) view.getLayoutParams();
            if (i2 != 0 || view.getVisibility() != 8) {
                for (int i5 = 0; i5 < i4; i5++) {
                    if (com2Var.f2295b == this.f2282a.get(i5)) {
                        G(view, iA);
                    }
                }
                q(view, true, rectA2);
                if (com2Var.f8162e != 0 && !rectA2.isEmpty()) {
                    int iB = f.b(com2Var.f8162e, iA);
                    int i6 = iB & 112;
                    if (i6 == 48) {
                        rectA.top = Math.max(rectA.top, rectA2.bottom);
                    } else if (i6 == 80) {
                        rectA.bottom = Math.max(rectA.bottom, getHeight() - rectA2.top);
                    }
                    int i7 = iB & 7;
                    if (i7 == 3) {
                        rectA.left = Math.max(rectA.left, rectA2.right);
                    } else if (i7 == 5) {
                        rectA.right = Math.max(rectA.right, getWidth() - rectA2.left);
                    }
                }
                if (com2Var.f8163f != 0 && view.getVisibility() == 0) {
                    F(view, rectA, iA);
                }
                if (i2 != 2) {
                    x(view, rectA3);
                    if (!rectA3.equals(rectA2)) {
                        N(view, rectA2);
                        for (i3 = i4 + 1; i3 < size; i3++) {
                            View view2 = this.f2282a.get(i3);
                            com2 com2Var2 = (com2) view2.getLayoutParams();
                            nulVarF = com2Var2.f();
                            if (nulVarF == null && nulVarF.e(this, view2, view)) {
                                if (i2 == 0 && com2Var2.g()) {
                                    com2Var2.k();
                                } else {
                                    if (i2 != 2) {
                                        zH = nulVarF.h(this, view2, view);
                                    } else {
                                        nulVarF.i(this, view2, view);
                                        zH = true;
                                    }
                                    if (i2 == 1) {
                                        com2Var2.p(zH);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    while (i3 < size) {
                        View view3 = this.f2282a.get(i3);
                        com2 com2Var3 = (com2) view3.getLayoutParams();
                        nulVarF = com2Var3.f();
                        if (nulVarF == null) {
                        }
                    }
                }
            }
        }
        O(rectA);
        O(rectA2);
        O(rectA3);
    }

    public void I(View view, int i2) {
        com2 com2Var = (com2) view.getLayoutParams();
        if (com2Var.a()) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        View view2 = com2Var.f2291a;
        if (view2 != null) {
            D(view, view2, i2);
            return;
        }
        int i3 = com2Var.f8160c;
        if (i3 >= 0) {
            E(view, i3, i2);
        } else {
            C(view, i2);
        }
    }

    public void J(View view, int i2, int i3, int i4, int i5) {
        measureChildWithMargins(view, i2, i3, i4, i5);
    }

    public final boolean L(MotionEvent motionEvent, int i2) {
        int actionMasked = motionEvent.getActionMasked();
        List<View> list = this.f2285b;
        z(list);
        int size = list.size();
        MotionEvent motionEventObtain = null;
        boolean zK = false;
        boolean z2 = false;
        for (int i3 = 0; i3 < size; i3++) {
            View view = list.get(i3);
            com2 com2Var = (com2) view.getLayoutParams();
            nul nulVarF = com2Var.f();
            if (!(zK || z2) || actionMasked == 0) {
                if (!zK && nulVarF != null) {
                    if (i2 == 0) {
                        zK = nulVarF.k(this, view, motionEvent);
                    } else if (i2 == 1) {
                        zK = nulVarF.D(this, view, motionEvent);
                    }
                    if (zK) {
                        this.f2279a = view;
                    }
                }
                boolean zC = com2Var.c();
                boolean zI = com2Var.i(this, view);
                z2 = zI && !zC;
                if (zI && !z2) {
                    break;
                }
            } else if (nulVarF != null) {
                if (motionEventObtain == null) {
                    long jUptimeMillis = SystemClock.uptimeMillis();
                    motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i2 == 0) {
                    nulVarF.k(this, view, motionEventObtain);
                } else if (i2 == 1) {
                    nulVarF.D(this, view, motionEventObtain);
                }
            }
        }
        list.clear();
        return zK;
    }

    public final void M() {
        this.f2282a.clear();
        this.f2283a.c();
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            com2 com2VarY = y(childAt);
            com2VarY.d(this, childAt);
            this.f2283a.b(childAt);
            for (int i3 = 0; i3 < childCount; i3++) {
                if (i3 != i2) {
                    View childAt2 = getChildAt(i3);
                    if (com2VarY.b(this, childAt, childAt2)) {
                        if (!this.f2283a.d(childAt2)) {
                            this.f2283a.b(childAt2);
                        }
                        this.f2283a.a(childAt2, childAt);
                    }
                }
            }
        }
        this.f2282a.addAll(this.f2283a.i());
        Collections.reverse(this.f2282a);
    }

    public void N(View view, Rect rect) {
        ((com2) view.getLayoutParams()).q(rect);
    }

    public void P() {
        if (this.f2288c && this.f2281a != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2281a);
        }
        this.f8154d = false;
    }

    public final void Q(boolean z2) {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            nul nulVarF = ((com2) childAt.getLayoutParams()).f();
            if (nulVarF != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z2) {
                    nulVarF.k(this, childAt, motionEventObtain);
                } else {
                    nulVarF.D(this, childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            ((com2) getChildAt(i3).getLayoutParams()).m();
        }
        this.f2279a = null;
        this.f2286b = false;
    }

    public final void U(View view, int i2) {
        com2 com2Var = (com2) view.getLayoutParams();
        int i3 = com2Var.f8164g;
        if (i3 != i2) {
            y.Y(view, i2 - i3);
            com2Var.f8164g = i2;
        }
    }

    public final void V(View view, int i2) {
        com2 com2Var = (com2) view.getLayoutParams();
        int i3 = com2Var.f8165h;
        if (i3 != i2) {
            y.Z(view, i2 - i3);
            com2Var.f8165h = i2;
        }
    }

    public final t0 W(t0 t0Var) {
        if (p2.a(this.f2276a, t0Var)) {
            return t0Var;
        }
        this.f2276a = t0Var;
        boolean z2 = t0Var != null && t0Var.l() > 0;
        this.f8155e = z2;
        setWillNotDraw(!z2 && getBackground() == null);
        t0 t0VarE = e(t0Var);
        requestLayout();
        return t0VarE;
    }

    public final void X() {
        if (!y.x(this)) {
            y.B0(this, null);
            return;
        }
        if (this.f2275a == null) {
            this.f2275a = new aux();
        }
        y.B0(this, this.f2275a);
        setSystemUiVisibility(1280);
    }

    public void b() {
        if (this.f2288c) {
            if (this.f2281a == null) {
                this.f2281a = new com3();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2281a);
        }
        this.f8154d = true;
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof com2) && super.checkLayoutParams(layoutParams);
    }

    public final void d(com2 com2Var, Rect rect, int i2, int i3) {
        int width = getWidth();
        int height = getHeight();
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) com2Var).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i2) - ((ViewGroup.MarginLayoutParams) com2Var).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) com2Var).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i3) - ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin));
        rect.set(iMax, iMax2, i2 + iMax, i3 + iMax2);
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j2) {
        com2 com2Var = (com2) view.getLayoutParams();
        nul nulVar = com2Var.f2292a;
        if (nulVar != null) {
            float fD = nulVar.d(this, view);
            if (fD > 0.0f) {
                if (this.f2277a == null) {
                    this.f2277a = new Paint();
                }
                this.f2277a.setColor(com2Var.f2292a.c(this, view));
                this.f2277a.setAlpha(c(Math.round(fD * 255.0f), 0, 255));
                int iSave = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect(getPaddingLeft(), getPaddingTop(), getWidth() - getPaddingRight(), getHeight() - getPaddingBottom(), this.f2277a);
                canvas.restoreToCount(iSave);
            }
        }
        return super.drawChild(canvas, view, j2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2278a;
        boolean state = false;
        if (drawable != null && drawable.isStateful()) {
            state = false | drawable.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    public final t0 e(t0 t0Var) {
        nul nulVarF;
        if (t0Var.o()) {
            return t0Var;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (y.x(childAt) && (nulVarF = ((com2) childAt.getLayoutParams()).f()) != null) {
                t0Var = nulVarF.f(this, childAt, t0Var);
                if (t0Var.o()) {
                    break;
                }
            }
        }
        return t0Var;
    }

    public void f(View view) {
        List listG = this.f2283a.g(view);
        if (listG == null || listG.isEmpty()) {
            return;
        }
        for (int i2 = 0; i2 < listG.size(); i2++) {
            View view2 = (View) listG.get(i2);
            nul nulVarF = ((com2) view2.getLayoutParams()).f();
            if (nulVarF != null) {
                nulVarF.h(this, view2, view);
            }
        }
    }

    public void g() {
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            if (A(getChildAt(i2))) {
                z2 = true;
                break;
            }
        }
        if (z2 != this.f8154d) {
            if (z2) {
                b();
            } else {
                P();
            }
        }
    }

    public final List<View> getDependencySortedChildren() {
        M();
        return Collections.unmodifiableList(this.f2282a);
    }

    public final t0 getLastWindowInsets() {
        return this.f2276a;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.f2274a.a();
    }

    public Drawable getStatusBarBackground() {
        return this.f2278a;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public com2 generateDefaultLayoutParams() {
        return new com2(-2, -2);
    }

    @Override // p024Com2.p
    public void i(View view, int i2, int i3, int i4, int i5, int i6) {
        l(view, i2, i3, i4, i5, 0, this.f2287b);
    }

    @Override // p024Com2.p
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        nul nulVarF;
        int childCount = getChildCount();
        boolean z2 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                com2 com2Var = (com2) childAt.getLayoutParams();
                if (com2Var.j(i4) && (nulVarF = com2Var.f()) != null) {
                    int[] iArr2 = this.f2284a;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    nulVarF.q(this, childAt, view, i2, i3, iArr2, i4);
                    int[] iArr3 = this.f2284a;
                    iMax = i2 > 0 ? Math.max(iMax, iArr3[0]) : Math.min(iMax, iArr3[0]);
                    int[] iArr4 = this.f2284a;
                    iMax2 = i3 > 0 ? Math.max(iMax2, iArr4[1]) : Math.min(iMax2, iArr4[1]);
                    z2 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z2) {
            H(1);
        }
    }

    @Override // p024Com2.p
    public void k(View view, int i2) {
        this.f2274a.d(view, i2);
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            com2 com2Var = (com2) childAt.getLayoutParams();
            if (com2Var.j(i2)) {
                nul nulVarF = com2Var.f();
                if (nulVarF != null) {
                    nulVarF.C(this, childAt, view, i2);
                }
                com2Var.l(i2);
                com2Var.k();
            }
        }
        this.f8152b = null;
    }

    @Override // p024Com2.q
    public void l(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        nul nulVarF;
        boolean z2;
        int iMin;
        int childCount = getChildCount();
        boolean z3 = false;
        int iMax = 0;
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                com2 com2Var = (com2) childAt.getLayoutParams();
                if (com2Var.j(i6) && (nulVarF = com2Var.f()) != null) {
                    int[] iArr2 = this.f2284a;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    nulVarF.t(this, childAt, view, i2, i3, i4, i5, i6, iArr2);
                    int[] iArr3 = this.f2284a;
                    iMax = i4 > 0 ? Math.max(iMax, iArr3[0]) : Math.min(iMax, iArr3[0]);
                    if (i5 > 0) {
                        z2 = true;
                        iMin = Math.max(i7, this.f2284a[1]);
                    } else {
                        z2 = true;
                        iMin = Math.min(i7, this.f2284a[1]);
                    }
                    i7 = iMin;
                    z3 = z2;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + i7;
        if (z3) {
            H(1);
        }
    }

    @Override // p024Com2.p
    public void m(View view, View view2, int i2, int i3) {
        nul nulVarF;
        this.f2274a.c(view, view2, i2, i3);
        this.f8152b = view2;
        int childCount = getChildCount();
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            com2 com2Var = (com2) childAt.getLayoutParams();
            if (com2Var.j(i3) && (nulVarF = com2Var.f()) != null) {
                nulVarF.v(this, childAt, view, view2, i2, i3);
            }
        }
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
    public com2 generateLayoutParams(AttributeSet attributeSet) {
        return new com2(getContext(), attributeSet);
    }

    @Override // p024Com2.p
    public boolean o(View view, View view2, int i2, int i3) {
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i4 = 0; i4 < childCount; i4++) {
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                com2 com2Var = (com2) childAt.getLayoutParams();
                nul nulVarF = com2Var.f();
                if (nulVarF != null) {
                    boolean zA = nulVarF.A(this, childAt, view, view2, i2, i3);
                    z2 |= zA;
                    com2Var.r(i3, zA);
                } else {
                    com2Var.r(i3, false);
                }
            }
        }
        return z2;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Q(false);
        if (this.f8154d) {
            if (this.f2281a == null) {
                this.f2281a = new com3();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2281a);
        }
        if (this.f2276a == null && y.x(this)) {
            y.l0(this);
        }
        this.f2288c = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Q(false);
        if (this.f8154d && this.f2281a != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2281a);
        }
        View view = this.f8152b;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f2288c = false;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f8155e || this.f2278a == null) {
            return;
        }
        t0 t0Var = this.f2276a;
        int iL = t0Var != null ? t0Var.l() : 0;
        if (iL > 0) {
            this.f2278a.setBounds(0, 0, getWidth(), iL);
            this.f2278a.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            Q(true);
        }
        boolean zL = L(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            Q(true);
        }
        return zL;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        nul nulVarF;
        int iA = y.A(this);
        int size = this.f2282a.size();
        for (int i6 = 0; i6 < size; i6++) {
            View view = this.f2282a.get(i6);
            if (view.getVisibility() != 8 && ((nulVarF = ((com2) view.getLayoutParams()).f()) == null || !nulVarF.l(this, view, iA))) {
                I(view, iA);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:39:0x00f1  */
    /* JADX WARN: Code duplicated, block: B:42:0x00fb  */
    /* JADX WARN: Code duplicated, block: B:45:0x011d  */
    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        int i4;
        int iMax;
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        nul nulVarF;
        com2 com2Var;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        M();
        g();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int iA = y.A(this);
        boolean z2 = iA == 1;
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        int i11 = paddingLeft + paddingRight;
        int i12 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = getSuggestedMinimumWidth();
        int suggestedMinimumHeight = getSuggestedMinimumHeight();
        boolean z3 = this.f2276a != null && y.x(this);
        int size3 = this.f2282a.size();
        int i13 = suggestedMinimumWidth;
        int i14 = suggestedMinimumHeight;
        int iCombineMeasuredStates = 0;
        int i15 = 0;
        while (i15 < size3) {
            View view = this.f2282a.get(i15);
            if (view.getVisibility() == 8) {
                i9 = i15;
                i6 = size3;
                i7 = paddingLeft;
            } else {
                com2 com2Var2 = (com2) view.getLayoutParams();
                int i16 = com2Var2.f8160c;
                if (i16 < 0 || mode == 0) {
                    i4 = iCombineMeasuredStates;
                } else {
                    int iW = w(i16);
                    int iB = f.b(T(com2Var2.f8158a), iA) & 7;
                    i4 = iCombineMeasuredStates;
                    if ((iB == 3 && !z2) || (iB == 5 && z2)) {
                        iMax = Math.max(0, (size - paddingRight) - iW);
                    } else if ((iB == 5 && !z2) || (iB == 3 && z2)) {
                        iMax = Math.max(0, iW - paddingLeft);
                    }
                    if (z3 || y.x(view)) {
                        iMakeMeasureSpec = i2;
                        iMakeMeasureSpec2 = i3;
                    } else {
                        int iJ = this.f2276a.j() + this.f2276a.k();
                        int iL = this.f2276a.l() + this.f2276a.i();
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size - iJ, mode);
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(size2 - iL, mode2);
                    }
                    nulVarF = com2Var2.f();
                    if (nulVarF != null) {
                        com2Var = com2Var2;
                        i8 = i4;
                        i9 = i15;
                        i5 = i14;
                        i7 = paddingLeft;
                        i10 = i13;
                        i6 = size3;
                        if (!nulVarF.m(this, view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0)) {
                        }
                        com2 com2Var3 = com2Var;
                        int iMax2 = Math.max(i10, i11 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) com2Var3).leftMargin + ((ViewGroup.MarginLayoutParams) com2Var3).rightMargin);
                        int iMax3 = Math.max(i5, i12 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com2Var3).topMargin + ((ViewGroup.MarginLayoutParams) com2Var3).bottomMargin);
                        iCombineMeasuredStates = View.combineMeasuredStates(i8, view.getMeasuredState());
                        i13 = iMax2;
                        i14 = iMax3;
                    } else {
                        com2Var = com2Var2;
                        i5 = i14;
                        i6 = size3;
                        i7 = paddingLeft;
                        i8 = i4;
                        i9 = i15;
                        i10 = i13;
                    }
                    J(view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0);
                    com2 com2Var4 = com2Var;
                    int iMax4 = Math.max(i10, i11 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) com2Var4).leftMargin + ((ViewGroup.MarginLayoutParams) com2Var4).rightMargin);
                    int iMax5 = Math.max(i5, i12 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com2Var4).topMargin + ((ViewGroup.MarginLayoutParams) com2Var4).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(i8, view.getMeasuredState());
                    i13 = iMax4;
                    i14 = iMax5;
                }
                iMax = 0;
                if (z3) {
                    iMakeMeasureSpec = i2;
                    iMakeMeasureSpec2 = i3;
                } else {
                    iMakeMeasureSpec = i2;
                    iMakeMeasureSpec2 = i3;
                }
                nulVarF = com2Var2.f();
                if (nulVarF != null) {
                    com2Var = com2Var2;
                    i8 = i4;
                    i9 = i15;
                    i5 = i14;
                    i7 = paddingLeft;
                    i10 = i13;
                    i6 = size3;
                    if (!nulVarF.m(this, view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0)) {
                    }
                    com2 com2Var5 = com2Var;
                    int iMax6 = Math.max(i10, i11 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) com2Var5).leftMargin + ((ViewGroup.MarginLayoutParams) com2Var5).rightMargin);
                    int iMax7 = Math.max(i5, i12 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com2Var5).topMargin + ((ViewGroup.MarginLayoutParams) com2Var5).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(i8, view.getMeasuredState());
                    i13 = iMax6;
                    i14 = iMax7;
                } else {
                    com2Var = com2Var2;
                    i5 = i14;
                    i6 = size3;
                    i7 = paddingLeft;
                    i8 = i4;
                    i9 = i15;
                    i10 = i13;
                }
                J(view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0);
                com2 com2Var6 = com2Var;
                int iMax8 = Math.max(i10, i11 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) com2Var6).leftMargin + ((ViewGroup.MarginLayoutParams) com2Var6).rightMargin);
                int iMax9 = Math.max(i5, i12 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com2Var6).topMargin + ((ViewGroup.MarginLayoutParams) com2Var6).bottomMargin);
                iCombineMeasuredStates = View.combineMeasuredStates(i8, view.getMeasuredState());
                i13 = iMax8;
                i14 = iMax9;
            }
            i15 = i9 + 1;
            paddingLeft = i7;
            size3 = i6;
        }
        int i17 = iCombineMeasuredStates;
        setMeasuredDimension(View.resolveSizeAndState(i13, i2, (-16777216) & i17), View.resolveSizeAndState(i14, i3, i17 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        nul nulVarF;
        int childCount = getChildCount();
        boolean zN = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() != 8) {
                com2 com2Var = (com2) childAt.getLayoutParams();
                if (com2Var.j(0) && (nulVarF = com2Var.f()) != null) {
                    zN |= nulVarF.n(this, childAt, view, f2, f3, z2);
                }
            }
        }
        if (zN) {
            H(1);
        }
        return zN;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        nul nulVarF;
        int childCount = getChildCount();
        boolean zO = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() != 8) {
                com2 com2Var = (com2) childAt.getLayoutParams();
                if (com2Var.j(0) && (nulVarF = com2Var.f()) != null) {
                    zO |= nulVarF.o(this, childAt, view, f2, f3);
                }
            }
        }
        return zO;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        j(view, i2, i3, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        i(view, i2, i3, i4, i5, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        m(view, view2, i2, 0);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof com4)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        com4 com4Var = (com4) parcelable;
        super.onRestoreInstanceState(com4Var.k());
        SparseArray<Parcelable> sparseArray = com4Var.f8167a;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            int id = childAt.getId();
            nul nulVarF = y(childAt).f();
            if (id != -1 && nulVarF != null && (parcelable2 = sparseArray.get(id)) != null) {
                nulVarF.x(this, childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableY;
        com4 com4Var = new com4(super.onSaveInstanceState());
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            int id = childAt.getId();
            nul nulVarF = ((com2) childAt.getLayoutParams()).f();
            if (id != -1 && nulVarF != null && (parcelableY = nulVarF.y(this, childAt)) != null) {
                sparseArray.append(id, parcelableY);
            }
        }
        com4Var.f8167a = sparseArray;
        return com4Var;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return o(view, view2, i2, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        k(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:11:0x002b A[PHI: r3
      0x002b: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:9:0x0022, B:5:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:14:0x0031  */
    /* JADX WARN: Code duplicated, block: B:15:0x0037 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0039  */
    /* JADX WARN: Code duplicated, block: B:18:0x004c  */
    /* JADX WARN: Code duplicated, block: B:22:0x0054  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zL;
        boolean zD;
        MotionEvent motionEventObtain;
        int actionMasked = motionEvent.getActionMasked();
        if (this.f2279a == null) {
            zL = L(motionEvent, 1);
            if (!zL) {
                zD = false;
            }
            motionEventObtain = null;
            if (this.f2279a == null) {
                zD |= super.onTouchEvent(motionEvent);
            } else if (zL) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                super.onTouchEvent(motionEventObtain);
            }
            if (motionEventObtain != null) {
                motionEventObtain.recycle();
            }
            if (actionMasked != 1 || actionMasked == 3) {
                Q(false);
            }
            return zD;
        }
        zL = false;
        nul nulVarF = ((com2) this.f2279a.getLayoutParams()).f();
        if (nulVarF != null) {
            zD = nulVarF.D(this, this.f2279a, motionEvent);
        } else {
            zD = false;
        }
        motionEventObtain = null;
        if (this.f2279a == null) {
            zD |= super.onTouchEvent(motionEvent);
        } else if (zL) {
            long jUptimeMillis2 = SystemClock.uptimeMillis();
            motionEventObtain = MotionEvent.obtain(jUptimeMillis2, jUptimeMillis2, 3, 0.0f, 0.0f, 0);
            super.onTouchEvent(motionEventObtain);
        }
        if (motionEventObtain != null) {
            motionEventObtain.recycle();
        }
        if (actionMasked != 1) {
            Q(false);
        } else {
            Q(false);
        }
        return zD;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: p, reason: merged with bridge method [inline-methods] */
    public com2 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof com2) {
            return new com2((com2) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new com2((ViewGroup.MarginLayoutParams) layoutParams) : new com2(layoutParams);
    }

    public void q(View view, boolean z2, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z2) {
            t(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public List<View> r(View view) {
        List<View> listH = this.f2283a.h(view);
        this.f8153c.clear();
        if (listH != null) {
            this.f8153c.addAll(listH);
        }
        return this.f8153c;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        nul nulVarF = ((com2) view.getLayoutParams()).f();
        if (nulVarF == null || !nulVarF.w(this, view, rect, z2)) {
            return super.requestChildRectangleOnScreen(view, rect, z2);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z2) {
        super.requestDisallowInterceptTouchEvent(z2);
        if (!z2 || this.f2286b) {
            return;
        }
        Q(false);
        this.f2286b = true;
    }

    public List<View> s(View view) {
        List listG = this.f2283a.g(view);
        this.f8153c.clear();
        if (listG != null) {
            this.f8153c.addAll(listG);
        }
        return this.f8153c;
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z2) {
        super.setFitsSystemWindows(z2);
        X();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f2280a = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f2278a;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f2278a = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f2278a.setState(getDrawableState());
                }
                p080cOm1.y.g(this.f2278a, y.A(this));
                this.f2278a.setVisible(getVisibility() == 0, false);
                this.f2278a.setCallback(this);
            }
            y.f0(this);
        }
    }

    public void setStatusBarBackgroundColor(int i2) {
        setStatusBarBackground(new ColorDrawable(i2));
    }

    public void setStatusBarBackgroundResource(int i2) {
        setStatusBarBackground(i2 != 0 ? PRN.aux.e(getContext(), i2) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        boolean z2 = i2 == 0;
        Drawable drawable = this.f2278a;
        if (drawable == null || drawable.isVisible() == z2) {
            return;
        }
        this.f2278a.setVisible(z2, false);
    }

    public void t(View view, Rect rect) {
        l0.a(this, view, rect);
    }

    public void u(View view, int i2, Rect rect, Rect rect2) {
        com2 com2Var = (com2) view.getLayoutParams();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        v(view, i2, rect, rect2, com2Var, measuredWidth, measuredHeight);
        d(com2Var, rect2, measuredWidth, measuredHeight);
    }

    public final void v(View view, int i2, Rect rect, Rect rect2, com2 com2Var, int i3, int i4) {
        int iWidth;
        int iHeight;
        int iB = f.b(R(com2Var.f8158a), i2);
        int iB2 = f.b(S(com2Var.f8159b), i2);
        int i5 = iB & 7;
        int i6 = iB & 112;
        int i7 = iB2 & 7;
        int i8 = iB2 & 112;
        if (i7 != 1) {
            iWidth = i7 != 5 ? rect.left : rect.right;
        } else {
            iWidth = rect.left + (rect.width() / 2);
        }
        if (i8 != 16) {
            iHeight = i8 != 80 ? rect.top : rect.bottom;
        } else {
            iHeight = rect.top + (rect.height() / 2);
        }
        if (i5 == 1) {
            iWidth -= i3 / 2;
        } else if (i5 != 5) {
            iWidth -= i3;
        }
        if (i6 == 16) {
            iHeight -= i4 / 2;
        } else if (i6 != 80) {
            iHeight -= i4;
        }
        rect2.set(iWidth, iHeight, i3 + iWidth, i4 + iHeight);
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2278a;
    }

    public final int w(int i2) {
        int[] iArr = this.f2289c;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i2);
            return 0;
        }
        if (i2 >= 0 && i2 < iArr.length) {
            return iArr[i2];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i2 + " out of range for " + this);
        return 0;
    }

    public void x(View view, Rect rect) {
        rect.set(((com2) view.getLayoutParams()).h());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public com2 y(View view) {
        com2 com2Var = (com2) view.getLayoutParams();
        if (!com2Var.f2294a) {
            if (view instanceof con) {
                nul behavior = ((con) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                com2Var.o(behavior);
                com2Var.f2294a = true;
            } else {
                prn prnVar = null;
                for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                    prnVar = (prn) superclass.getAnnotation(prn.class);
                    if (prnVar != null) {
                        break;
                    }
                }
                if (prnVar != null) {
                    try {
                        com2Var.o(prnVar.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
                    } catch (Exception e2) {
                        Log.e("CoordinatorLayout", "Default behavior class " + prnVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e2);
                    }
                }
                com2Var.f2294a = true;
            }
        }
        return com2Var;
    }

    public final void z(List<View> list) {
        list.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i2 = childCount - 1; i2 >= 0; i2--) {
            list.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i2) : i2));
        }
        Comparator<View> comparator = f2272a;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2282a = new ArrayList();
        this.f2283a = new k0<>();
        this.f2285b = new ArrayList();
        this.f8153c = new ArrayList();
        this.f2284a = new int[2];
        this.f2287b = new int[2];
        this.f2274a = new r(this);
        TypedArray typedArrayObtainStyledAttributes = i2 == 0 ? context.obtainStyledAttributes(attributeSet, p063PRn.com2.f1468b, 0, p063PRn.com1.f7477a) : context.obtainStyledAttributes(attributeSet, p063PRn.com2.f1468b, i2, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            if (i2 == 0) {
                saveAttributeDataForStyleable(context, p063PRn.com2.f1468b, attributeSet, typedArrayObtainStyledAttributes, 0, p063PRn.com1.f7477a);
            } else {
                saveAttributeDataForStyleable(context, p063PRn.com2.f1468b, attributeSet, typedArrayObtainStyledAttributes, i2, 0);
            }
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(p063PRn.com2.f7478a, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f2289c = resources.getIntArray(resourceId);
            float f2 = resources.getDisplayMetrics().density;
            int length = this.f2289c.length;
            for (int i3 = 0; i3 < length; i3++) {
                int[] iArr = this.f2289c;
                iArr[i3] = (int) (iArr[i3] * f2);
            }
        }
        this.f2278a = typedArrayObtainStyledAttributes.getDrawable(p063PRn.com2.f7479b);
        typedArrayObtainStyledAttributes.recycle();
        X();
        super.setOnHierarchyChangeListener(new com1());
        if (y.y(this) == 0) {
            y.y0(this, 1);
        }
    }

    public static class com4 extends COM2.aux {
        public static final Parcelable.Creator<com4> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public SparseArray<Parcelable> f8167a;

        public static class aux implements Parcelable.ClassLoaderCreator<com4> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com4 createFromParcel(Parcel parcel) {
                return new com4(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com4 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com4(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com4[] newArray(int i2) {
                return new com4[i2];
            }
        }

        public com4(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int i2 = parcel.readInt();
            int[] iArr = new int[i2];
            parcel.readIntArray(iArr);
            Parcelable[] parcelableArray = parcel.readParcelableArray(classLoader);
            this.f8167a = new SparseArray<>(i2);
            for (int i3 = 0; i3 < i2; i3++) {
                this.f8167a.append(iArr[i3], parcelableArray[i3]);
            }
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            SparseArray<Parcelable> sparseArray = this.f8167a;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i3 = 0; i3 < size; i3++) {
                iArr[i3] = this.f8167a.keyAt(i3);
                parcelableArr[i3] = this.f8167a.valueAt(i3);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i2);
        }

        public com4(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public static class com2 extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8158a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Rect f2290a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f2291a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public nul f2292a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Object f2293a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2294a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8159b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public View f2295b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2296b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8160c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2297c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8161d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f2298d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8162e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public boolean f2299e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f8163f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f8164g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f8165h;

        public com2(int i2, int i3) {
            super(i2, i3);
            this.f2294a = false;
            this.f8158a = 0;
            this.f8159b = 0;
            this.f8160c = -1;
            this.f8161d = -1;
            this.f8162e = 0;
            this.f8163f = 0;
            this.f2290a = new Rect();
        }

        public boolean a() {
            return this.f2291a == null && this.f8161d != -1;
        }

        public boolean b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            nul nulVar;
            return view2 == this.f2295b || s(view2, y.A(coordinatorLayout)) || ((nulVar = this.f2292a) != null && nulVar.e(coordinatorLayout, view, view2));
        }

        public boolean c() {
            if (this.f2292a == null) {
                this.f2296b = false;
            }
            return this.f2296b;
        }

        public View d(CoordinatorLayout coordinatorLayout, View view) {
            if (this.f8161d == -1) {
                this.f2295b = null;
                this.f2291a = null;
                return null;
            }
            if (this.f2291a == null || !t(view, coordinatorLayout)) {
                n(view, coordinatorLayout);
            }
            return this.f2291a;
        }

        public int e() {
            return this.f8161d;
        }

        public nul f() {
            return this.f2292a;
        }

        public boolean g() {
            return this.f2299e;
        }

        public Rect h() {
            return this.f2290a;
        }

        public boolean i(CoordinatorLayout coordinatorLayout, View view) {
            boolean z2 = this.f2296b;
            if (z2) {
                return true;
            }
            nul nulVar = this.f2292a;
            boolean zA = (nulVar != null ? nulVar.a(coordinatorLayout, view) : false) | z2;
            this.f2296b = zA;
            return zA;
        }

        public boolean j(int i2) {
            if (i2 == 0) {
                return this.f2297c;
            }
            if (i2 != 1) {
                return false;
            }
            return this.f2298d;
        }

        public void k() {
            this.f2299e = false;
        }

        public void l(int i2) {
            r(i2, false);
        }

        public void m() {
            this.f2296b = false;
        }

        public final void n(View view, CoordinatorLayout coordinatorLayout) {
            View viewFindViewById = coordinatorLayout.findViewById(this.f8161d);
            this.f2291a = viewFindViewById;
            if (viewFindViewById == null) {
                if (coordinatorLayout.isInEditMode()) {
                    this.f2295b = null;
                    this.f2291a = null;
                    return;
                }
                throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + coordinatorLayout.getResources().getResourceName(this.f8161d) + " to anchor view " + view);
            }
            if (viewFindViewById == coordinatorLayout) {
                if (!coordinatorLayout.isInEditMode()) {
                    throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                }
                this.f2295b = null;
                this.f2291a = null;
                return;
            }
            for (ViewParent parent = viewFindViewById.getParent(); parent != coordinatorLayout && parent != null; parent = parent.getParent()) {
                if (parent == view) {
                    if (!coordinatorLayout.isInEditMode()) {
                        throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                    }
                    this.f2295b = null;
                    this.f2291a = null;
                    return;
                }
                if (parent instanceof View) {
                    viewFindViewById = parent;
                }
            }
            this.f2295b = viewFindViewById;
        }

        public void o(nul nulVar) {
            nul nulVar2 = this.f2292a;
            if (nulVar2 != nulVar) {
                if (nulVar2 != null) {
                    nulVar2.j();
                }
                this.f2292a = nulVar;
                this.f2293a = null;
                this.f2294a = true;
                if (nulVar != null) {
                    nulVar.g(this);
                }
            }
        }

        public void p(boolean z2) {
            this.f2299e = z2;
        }

        public void q(Rect rect) {
            this.f2290a.set(rect);
        }

        public void r(int i2, boolean z2) {
            if (i2 == 0) {
                this.f2297c = z2;
            } else {
                if (i2 != 1) {
                    return;
                }
                this.f2298d = z2;
            }
        }

        public final boolean s(View view, int i2) {
            int iB = f.b(((com2) view.getLayoutParams()).f8162e, i2);
            return iB != 0 && (f.b(this.f8163f, i2) & iB) == iB;
        }

        public final boolean t(View view, CoordinatorLayout coordinatorLayout) {
            if (this.f2291a.getId() != this.f8161d) {
                return false;
            }
            View view2 = this.f2291a;
            for (ViewParent parent = view2.getParent(); parent != coordinatorLayout; parent = parent.getParent()) {
                if (parent == null || parent == view) {
                    this.f2295b = null;
                    this.f2291a = null;
                    return false;
                }
                if (parent instanceof View) {
                    view2 = parent;
                }
            }
            this.f2295b = view2;
            return true;
        }

        public com2(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2294a = false;
            this.f8158a = 0;
            this.f8159b = 0;
            this.f8160c = -1;
            this.f8161d = -1;
            this.f8162e = 0;
            this.f8163f = 0;
            this.f2290a = new Rect();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p063PRn.com2.f1469c);
            this.f8158a = typedArrayObtainStyledAttributes.getInteger(p063PRn.com2.f7480c, 0);
            this.f8161d = typedArrayObtainStyledAttributes.getResourceId(p063PRn.com2.f7481d, -1);
            this.f8159b = typedArrayObtainStyledAttributes.getInteger(p063PRn.com2.f7482e, 0);
            this.f8160c = typedArrayObtainStyledAttributes.getInteger(p063PRn.com2.f7486i, -1);
            this.f8162e = typedArrayObtainStyledAttributes.getInt(p063PRn.com2.f7485h, 0);
            this.f8163f = typedArrayObtainStyledAttributes.getInt(p063PRn.com2.f7484g, 0);
            int i2 = p063PRn.com2.f7483f;
            boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(i2);
            this.f2294a = zHasValue;
            if (zHasValue) {
                this.f2292a = CoordinatorLayout.K(context, attributeSet, typedArrayObtainStyledAttributes.getString(i2));
            }
            typedArrayObtainStyledAttributes.recycle();
            nul nulVar = this.f2292a;
            if (nulVar != null) {
                nulVar.g(this);
            }
        }

        public com2(com2 com2Var) {
            super((ViewGroup.MarginLayoutParams) com2Var);
            this.f2294a = false;
            this.f8158a = 0;
            this.f8159b = 0;
            this.f8160c = -1;
            this.f8161d = -1;
            this.f8162e = 0;
            this.f8163f = 0;
            this.f2290a = new Rect();
        }

        public com2(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f2294a = false;
            this.f8158a = 0;
            this.f8159b = 0;
            this.f8160c = -1;
            this.f8161d = -1;
            this.f8162e = 0;
            this.f8163f = 0;
            this.f2290a = new Rect();
        }

        public com2(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2294a = false;
            this.f8158a = 0;
            this.f8159b = 0;
            this.f8160c = -1;
            this.f8161d = -1;
            this.f8162e = 0;
            this.f8163f = 0;
            this.f2290a = new Rect();
        }
    }
}
