package LPT7;

import java.util.function.IntFunction;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class t implements IntFunction {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ inet.ipaddr.ipv6.nul f6784a;

    public /* synthetic */ t(inet.ipaddr.ipv6.nul nulVar) {
        this.f6784a = nulVar;
    }

    @Override // java.util.function.IntFunction
    public final Object apply(int i2) {
        return this.f6784a.getSegment(i2);
    }
}
