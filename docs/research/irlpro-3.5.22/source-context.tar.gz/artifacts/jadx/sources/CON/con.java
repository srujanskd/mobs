package CON;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class con<K, V> implements Iterable<Map.Entry<K, V>> {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul<K, V> f145a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public nul<K, V> f5779b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public WeakHashMap<com2<K, V>, Boolean> f146a = new WeakHashMap<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f5778a = 0;

    public static class aux<K, V> extends com1<K, V> {
        public aux(nul<K, V> nulVar, nul<K, V> nulVar2) {
            super(nulVar, nulVar2);
        }

        @Override // CON.con.com1
        public nul<K, V> b(nul<K, V> nulVar) {
            return nulVar.f5783b;
        }

        @Override // CON.con.com1
        public nul<K, V> c(nul<K, V> nulVar) {
            return nulVar.f5782a;
        }
    }

    public static abstract class com1<K, V> implements Iterator<Map.Entry<K, V>>, com2<K, V> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public nul<K, V> f5780a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public nul<K, V> f5781b;

        public com1(nul<K, V> nulVar, nul<K, V> nulVar2) {
            this.f5780a = nulVar2;
            this.f5781b = nulVar;
        }

        @Override // CON.con.com2
        public void a(nul<K, V> nulVar) {
            if (this.f5780a == nulVar && nulVar == this.f5781b) {
                this.f5781b = null;
                this.f5780a = null;
            }
            nul<K, V> nulVar2 = this.f5780a;
            if (nulVar2 == nulVar) {
                this.f5780a = b(nulVar2);
            }
            if (this.f5781b == nulVar) {
                this.f5781b = e();
            }
        }

        public abstract nul<K, V> b(nul<K, V> nulVar);

        public abstract nul<K, V> c(nul<K, V> nulVar);

        @Override // java.util.Iterator
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public Map.Entry<K, V> next() {
            nul<K, V> nulVar = this.f5781b;
            this.f5781b = e();
            return nulVar;
        }

        public final nul<K, V> e() {
            nul<K, V> nulVar = this.f5781b;
            nul<K, V> nulVar2 = this.f5780a;
            if (nulVar == nulVar2 || nulVar2 == null) {
                return null;
            }
            return c(nulVar);
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            return this.f5781b != null;
        }
    }

    public interface com2<K, V> {
        void a(nul<K, V> nulVar);
    }

    /* JADX INFO: renamed from: CON.con$con, reason: collision with other inner class name */
    public static class C0005con<K, V> extends com1<K, V> {
        public C0005con(nul<K, V> nulVar, nul<K, V> nulVar2) {
            super(nulVar, nulVar2);
        }

        @Override // CON.con.com1
        public nul<K, V> b(nul<K, V> nulVar) {
            return nulVar.f5782a;
        }

        @Override // CON.con.com1
        public nul<K, V> c(nul<K, V> nulVar) {
            return nulVar.f5783b;
        }
    }

    public static class nul<K, V> implements Map.Entry<K, V> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public nul<K, V> f5782a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final K f147a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public nul<K, V> f5783b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final V f148b;

        public nul(K k2, V v2) {
            this.f147a = k2;
            this.f148b = v2;
        }

        @Override // java.util.Map.Entry
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof nul)) {
                return false;
            }
            nul nulVar = (nul) obj;
            return this.f147a.equals(nulVar.f147a) && this.f148b.equals(nulVar.f148b);
        }

        @Override // java.util.Map.Entry
        public K getKey() {
            return this.f147a;
        }

        @Override // java.util.Map.Entry
        public V getValue() {
            return this.f148b;
        }

        @Override // java.util.Map.Entry
        public int hashCode() {
            return this.f147a.hashCode() ^ this.f148b.hashCode();
        }

        @Override // java.util.Map.Entry
        public V setValue(V v2) {
            throw new UnsupportedOperationException("An entry modification is not supported");
        }

        public String toString() {
            return this.f147a + "=" + this.f148b;
        }
    }

    public class prn implements Iterator<Map.Entry<K, V>>, com2<K, V> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public nul<K, V> f5784a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f5785b = true;

        public prn() {
        }

        @Override // CON.con.com2
        public void a(nul<K, V> nulVar) {
            nul<K, V> nulVar2 = this.f5784a;
            if (nulVar == nulVar2) {
                nul<K, V> nulVar3 = nulVar2.f5783b;
                this.f5784a = nulVar3;
                this.f5785b = nulVar3 == null;
            }
        }

        @Override // java.util.Iterator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public Map.Entry<K, V> next() {
            if (this.f5785b) {
                this.f5785b = false;
                this.f5784a = con.this.f145a;
            } else {
                nul<K, V> nulVar = this.f5784a;
                this.f5784a = nulVar != null ? nulVar.f5782a : null;
            }
            return this.f5784a;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            if (this.f5785b) {
                return con.this.f145a != null;
            }
            nul<K, V> nulVar = this.f5784a;
            return (nulVar == null || nulVar.f5782a == null) ? false : true;
        }
    }

    public Map.Entry<K, V> a() {
        return this.f145a;
    }

    public nul<K, V> b(K k2) {
        nul<K, V> nulVar = this.f145a;
        while (nulVar != null && !nulVar.f147a.equals(k2)) {
            nulVar = nulVar.f5782a;
        }
        return nulVar;
    }

    public con<K, V>.prn c() {
        con<K, V>.prn prnVar = new prn();
        this.f146a.put(prnVar, Boolean.FALSE);
        return prnVar;
    }

    public Map.Entry<K, V> d() {
        return this.f5779b;
    }

    public Iterator<Map.Entry<K, V>> descendingIterator() {
        C0005con c0005con = new C0005con(this.f5779b, this.f145a);
        this.f146a.put(c0005con, Boolean.FALSE);
        return c0005con;
    }

    public nul<K, V> e(K k2, V v2) {
        nul<K, V> nulVar = new nul<>(k2, v2);
        this.f5778a++;
        nul<K, V> nulVar2 = this.f5779b;
        if (nulVar2 == null) {
            this.f145a = nulVar;
            this.f5779b = nulVar;
            return nulVar;
        }
        nulVar2.f5782a = nulVar;
        nulVar.f5783b = nulVar2;
        this.f5779b = nulVar;
        return nulVar;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof con)) {
            return false;
        }
        con conVar = (con) obj;
        if (size() != conVar.size()) {
            return false;
        }
        Iterator<Map.Entry<K, V>> it = iterator();
        Iterator<Map.Entry<K, V>> it2 = conVar.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Map.Entry<K, V> next = it.next();
            Map.Entry<K, V> next2 = it2.next();
            if ((next == null && next2 != null) || (next != null && !next.equals(next2))) {
                return false;
            }
        }
        return (it.hasNext() || it2.hasNext()) ? false : true;
    }

    public V f(K k2, V v2) {
        nul<K, V> nulVarB = b(k2);
        if (nulVarB != null) {
            return nulVarB.f148b;
        }
        e(k2, v2);
        return null;
    }

    public V g(K k2) {
        nul<K, V> nulVarB = b(k2);
        if (nulVarB == null) {
            return null;
        }
        this.f5778a--;
        if (!this.f146a.isEmpty()) {
            Iterator<com2<K, V>> it = this.f146a.keySet().iterator();
            while (it.hasNext()) {
                it.next().a(nulVarB);
            }
        }
        nul<K, V> nulVar = nulVarB.f5783b;
        if (nulVar != null) {
            nulVar.f5782a = nulVarB.f5782a;
        } else {
            this.f145a = nulVarB.f5782a;
        }
        nul<K, V> nulVar2 = nulVarB.f5782a;
        if (nulVar2 != null) {
            nulVar2.f5783b = nulVar;
        } else {
            this.f5779b = nulVar;
        }
        nulVarB.f5782a = null;
        nulVarB.f5783b = null;
        return nulVarB.f148b;
    }

    public int hashCode() {
        Iterator<Map.Entry<K, V>> it = iterator();
        int iHashCode = 0;
        while (it.hasNext()) {
            iHashCode += it.next().hashCode();
        }
        return iHashCode;
    }

    @Override // java.lang.Iterable
    public Iterator<Map.Entry<K, V>> iterator() {
        aux auxVar = new aux(this.f145a, this.f5779b);
        this.f146a.put(auxVar, Boolean.FALSE);
        return auxVar;
    }

    public int size() {
        return this.f5778a;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator<Map.Entry<K, V>> it = iterator();
        while (it.hasNext()) {
            sb.append(it.next().toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
