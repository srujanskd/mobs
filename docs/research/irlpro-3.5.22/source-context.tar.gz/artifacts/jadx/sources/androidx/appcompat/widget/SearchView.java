package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import p022CoN.k0;
import p022CoN.q0;
import p022CoN.s0;
import p022CoN.u0;
import p024Com2.y;
import p071cOM2.r1;

/* JADX INFO: loaded from: classes.dex */
public class SearchView extends androidx.appcompat.widget.con implements p012COn.com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final lpt1 f7910a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public SearchableInfo f2007a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Intent f2008a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Rect f2009a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Bundle f2010a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextWatcher f2011a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View.OnClickListener f2012a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View.OnFocusChangeListener f2013a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View.OnKeyListener f2014a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View f2015a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AdapterView.OnItemClickListener f2016a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AdapterView.OnItemSelectedListener f2017a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ImageView f2018a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextView.OnEditorActionListener f2019a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SearchAutoComplete f2020a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt3 f2021a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public r1 f2022a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CharSequence f2023a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2024a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final WeakHashMap<String, Drawable.ConstantState> f2025a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Intent f7911b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Rect f2026b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Drawable f2027b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final View.OnClickListener f2028b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final View f2029b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final ImageView f2030b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f2031b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Runnable f2032b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final View f7912c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final ImageView f2033c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f2034c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int[] f2035c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final View f7913d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final ImageView f2036d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public CharSequence f2037d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2038d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public int[] f2039d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ImageView f7914e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2040e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f7915f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f7916g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f7917h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f7918i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f7919j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f2041j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f7920k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f7921l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f7922m;

    public static class SearchAutoComplete extends p022CoN.lpt1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7923a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public SearchView f2042a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Runnable f2043a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f7924b;

        public class aux implements Runnable {
            public aux() {
            }

            @Override // java.lang.Runnable
            public void run() {
                SearchAutoComplete.this.d();
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, p001AuX.com3.f5508p);
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i2 = configuration.screenWidthDp;
            int i3 = configuration.screenHeightDp;
            if (i2 >= 960 && i3 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i2 < 600) {
                return (i2 < 640 || i3 < 480) ? 160 : 192;
            }
            return 192;
        }

        public void b() {
            if (Build.VERSION.SDK_INT < 29) {
                SearchView.f7910a.c(this);
                return;
            }
            setInputMethodMode(1);
            if (enoughToFilter()) {
                showDropDown();
            }
        }

        public boolean c() {
            return TextUtils.getTrimmedLength(getText()) == 0;
        }

        public void d() {
            if (this.f7924b) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.f7924b = false;
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public boolean enoughToFilter() {
            return this.f7923a <= 0 || super.enoughToFilter();
        }

        @Override // p022CoN.lpt1, android.widget.TextView, android.view.View
        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f7924b) {
                removeCallbacks(this.f2043a);
                post(this.f2043a);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public void onFocusChanged(boolean z2, int i2, Rect rect) {
            super.onFocusChanged(z2, i2, rect);
            this.f2042a.X();
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public boolean onKeyPreIme(int i2, KeyEvent keyEvent) {
            if (i2 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f2042a.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i2, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public void onWindowFocusChanged(boolean z2) {
            super.onWindowFocusChanged(z2);
            if (z2 && this.f2042a.hasFocus() && getVisibility() == 0) {
                this.f7924b = true;
                if (SearchView.K(getContext())) {
                    b();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z2) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z2) {
                this.f7924b = false;
                removeCallbacks(this.f2043a);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f7924b = true;
                    return;
                }
                this.f7924b = false;
                removeCallbacks(this.f2043a);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f2042a = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i2) {
            super.setThreshold(i2);
            this.f7923a = i2;
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i2) {
            super(context, attributeSet, i2);
            this.f2043a = new aux();
            this.f7923a = getThreshold();
        }
    }

    public class aux implements TextWatcher {
        public aux() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            SearchView.this.W(charSequence);
        }
    }

    public class com1 implements View.OnLayoutChangeListener {
        public com1() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
            SearchView.this.z();
        }
    }

    public class com2 implements View.OnClickListener {
        public com2() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.f2018a) {
                searchView.T();
                return;
            }
            if (view == searchView.f2033c) {
                searchView.P();
                return;
            }
            if (view == searchView.f2030b) {
                searchView.U();
            } else if (view == searchView.f2036d) {
                searchView.Y();
            } else if (view == searchView.f2020a) {
                searchView.F();
            }
        }
    }

    public class com3 implements View.OnKeyListener {
        public com3() {
        }

        @Override // android.view.View.OnKeyListener
        public boolean onKey(View view, int i2, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.f2007a == null) {
                return false;
            }
            if (searchView.f2020a.isPopupShowing() && SearchView.this.f2020a.getListSelection() != -1) {
                return SearchView.this.V(view, i2, keyEvent);
            }
            if (SearchView.this.f2020a.c() || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i2 != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.N(0, null, searchView2.f2020a.getText().toString());
            return true;
        }
    }

    public class com4 implements TextView.OnEditorActionListener {
        public com4() {
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
            SearchView.this.U();
            return true;
        }
    }

    public class com5 implements AdapterView.OnItemClickListener {
        public com5() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            SearchView.this.Q(i2, 0, null);
        }
    }

    public class com6 implements AdapterView.OnItemSelectedListener {
        public com6() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            SearchView.this.R(i2);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public interface com7 {
    }

    public interface com8 {
    }

    public interface com9 {
    }

    public class con implements Runnable {
        public con() {
        }

        @Override // java.lang.Runnable
        public void run() {
            SearchView.this.d0();
        }
    }

    public static class lpt1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public Method f7934a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public Method f7935b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public Method f7936c;

        @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
        public lpt1() {
            this.f7934a = null;
            this.f7935b = null;
            this.f7936c = null;
            d();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f7934a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f7935b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                this.f7936c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        public static void d() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }

        public void a(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f7935b;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        public void b(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f7934a;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, new Object[0]);
                } catch (Exception unused) {
                }
            }
        }

        public void c(AutoCompleteTextView autoCompleteTextView) {
            d();
            Method method = this.f7936c;
            if (method != null) {
                try {
                    method.invoke(autoCompleteTextView, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }
    }

    public static class lpt2 extends COM2.aux {
        public static final Parcelable.Creator<lpt2> CREATOR = new aux();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f7937b;

        public class aux implements Parcelable.ClassLoaderCreator<lpt2> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public lpt2 createFromParcel(Parcel parcel) {
                return new lpt2(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public lpt2 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new lpt2(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public lpt2[] newArray(int i2) {
                return new lpt2[i2];
            }
        }

        public lpt2(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "SearchView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " isIconified=" + this.f7937b + "}";
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeValue(Boolean.valueOf(this.f7937b));
        }

        public lpt2(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f7937b = ((Boolean) parcel.readValue(null)).booleanValue();
        }
    }

    public static class lpt3 extends TouchDelegate {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f7938a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Rect f2044a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final View f2045a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2046a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final Rect f7939b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final Rect f7940c;

        public lpt3(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f7938a = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            this.f2044a = new Rect();
            this.f7940c = new Rect();
            this.f7939b = new Rect();
            a(rect, rect2);
            this.f2045a = view;
        }

        public void a(Rect rect, Rect rect2) {
            this.f2044a.set(rect);
            this.f7940c.set(rect);
            Rect rect3 = this.f7940c;
            int i2 = this.f7938a;
            rect3.inset(-i2, -i2);
            this.f7939b.set(rect2);
        }

        /* JADX WARN: Code duplicated, block: B:19:0x003f  */
        @Override // android.view.TouchDelegate
        public boolean onTouchEvent(MotionEvent motionEvent) {
            boolean z2;
            boolean z3;
            int x2 = (int) motionEvent.getX();
            int y2 = (int) motionEvent.getY();
            int action = motionEvent.getAction();
            boolean z4 = true;
            if (action != 0) {
                if (action == 1 || action == 2) {
                    z3 = this.f2046a;
                    if (z3 && !this.f7940c.contains(x2, y2)) {
                        z4 = z3;
                        z2 = false;
                    }
                } else if (action != 3) {
                    z2 = true;
                    z4 = false;
                } else {
                    z3 = this.f2046a;
                    this.f2046a = false;
                }
                z4 = z3;
                z2 = true;
            } else if (this.f2044a.contains(x2, y2)) {
                this.f2046a = true;
                z2 = true;
            } else {
                z2 = true;
                z4 = false;
            }
            if (!z4) {
                return false;
            }
            if (!z2 || this.f7939b.contains(x2, y2)) {
                Rect rect = this.f7939b;
                motionEvent.setLocation(x2 - rect.left, y2 - rect.top);
            } else {
                motionEvent.setLocation(this.f2045a.getWidth() / 2, this.f2045a.getHeight() / 2);
            }
            return this.f2045a.dispatchTouchEvent(motionEvent);
        }
    }

    public class nul implements Runnable {
        public nul() {
        }

        @Override // java.lang.Runnable
        public void run() {
            r1 r1Var = SearchView.this.f2022a;
            if (r1Var instanceof k0) {
                r1Var.b(null);
            }
        }
    }

    public class prn implements View.OnFocusChangeListener {
        public prn() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z2) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.f2013a;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z2);
            }
        }
    }

    static {
        f7910a = Build.VERSION.SDK_INT < 29 ? new lpt1() : null;
    }

    public SearchView(Context context) {
        this(context, null);
    }

    public static boolean K(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(p001AuX.com6.f5534g);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(p001AuX.com6.f5535h);
    }

    private void setQuery(CharSequence charSequence) {
        this.f2020a.setText(charSequence);
        this.f2020a.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    public final Intent A(String str, Uri uri, String str2, String str3, int i2, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f2037d);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f2010a;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i2 != 0) {
            intent.putExtra("action_key", i2);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f2007a.getSearchActivity());
        return intent;
    }

    public final Intent B(Cursor cursor, int i2, String str) {
        int position;
        String strN;
        try {
            String strN2 = k0.n(cursor, "suggest_intent_action");
            if (strN2 == null) {
                strN2 = this.f2007a.getSuggestIntentAction();
            }
            if (strN2 == null) {
                strN2 = "android.intent.action.SEARCH";
            }
            String str2 = strN2;
            String strN3 = k0.n(cursor, "suggest_intent_data");
            if (strN3 == null) {
                strN3 = this.f2007a.getSuggestIntentData();
            }
            if (strN3 != null && (strN = k0.n(cursor, "suggest_intent_data_id")) != null) {
                strN3 = strN3 + "/" + Uri.encode(strN);
            }
            return A(str2, strN3 == null ? null : Uri.parse(strN3), k0.n(cursor, "suggest_intent_extra_data"), k0.n(cursor, "suggest_intent_query"), i2, str);
        } catch (RuntimeException e2) {
            try {
                position = cursor.getPosition();
            } catch (RuntimeException unused) {
                position = -1;
            }
            Log.w("SearchView", "Search suggestions cursor at row " + position + " returned exception.", e2);
            return null;
        }
    }

    public final Intent C(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f2010a;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final Intent D(Intent intent, SearchableInfo searchableInfo) {
        Intent intent2 = new Intent(intent);
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        intent2.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
        return intent2;
    }

    public final void E() {
        this.f2020a.dismissDropDown();
    }

    public void F() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.f2020a.refreshAutoCompleteResults();
            return;
        }
        lpt1 lpt1Var = f7910a;
        lpt1Var.b(this.f2020a);
        lpt1Var.a(this.f2020a);
    }

    public final void G(View view, Rect rect) {
        view.getLocationInWindow(this.f2035c);
        getLocationInWindow(this.f2039d);
        int[] iArr = this.f2035c;
        int i2 = iArr[1];
        int[] iArr2 = this.f2039d;
        int i3 = i2 - iArr2[1];
        int i4 = iArr[0] - iArr2[0];
        rect.set(i4, i3, view.getWidth() + i4, view.getHeight() + i3);
    }

    public final CharSequence H(CharSequence charSequence) {
        if (!this.f2038d || this.f2027b == null) {
            return charSequence;
        }
        int textSize = (int) (((double) this.f2020a.getTextSize()) * 1.25d);
        this.f2027b.setBounds(0, 0, textSize, textSize);
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
        spannableStringBuilder.setSpan(new ImageSpan(this.f2027b), 1, 2, 33);
        spannableStringBuilder.append(charSequence);
        return spannableStringBuilder;
    }

    public final boolean I() {
        Intent intent;
        SearchableInfo searchableInfo = this.f2007a;
        if (searchableInfo == null || !searchableInfo.getVoiceSearchEnabled()) {
            return false;
        }
        if (this.f2007a.getVoiceSearchLaunchWebSearch()) {
            intent = this.f2008a;
        } else {
            intent = this.f2007a.getVoiceSearchLaunchRecognizer() ? this.f7911b : null;
        }
        return (intent == null || getContext().getPackageManager().resolveActivity(intent, 65536) == null) ? false : true;
    }

    public boolean J() {
        return this.f2040e;
    }

    public final boolean L() {
        return (this.f7915f || this.f7918i) && !J();
    }

    public final void M(Intent intent) {
        if (intent == null) {
            return;
        }
        try {
            getContext().startActivity(intent);
        } catch (RuntimeException e2) {
            Log.e("SearchView", "Failed launch activity: " + intent, e2);
        }
    }

    public void N(int i2, String str, String str2) {
        getContext().startActivity(A("android.intent.action.SEARCH", null, null, str2, i2, str));
    }

    public final boolean O(int i2, int i3, String str) {
        Cursor cursorC = this.f2022a.c();
        if (cursorC == null || !cursorC.moveToPosition(i2)) {
            return false;
        }
        M(B(cursorC, i3, str));
        return true;
    }

    public void P() {
        if (!TextUtils.isEmpty(this.f2020a.getText())) {
            this.f2020a.setText("");
            this.f2020a.requestFocus();
            this.f2020a.setImeVisibility(true);
        } else if (this.f2038d) {
            clearFocus();
            i0(true);
        }
    }

    public boolean Q(int i2, int i3, String str) {
        O(i2, 0, null);
        this.f2020a.setImeVisibility(false);
        E();
        return true;
    }

    public boolean R(int i2) {
        a0(i2);
        return true;
    }

    public void S(CharSequence charSequence) {
        setQuery(charSequence);
    }

    public void T() {
        i0(false);
        this.f2020a.requestFocus();
        this.f2020a.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f2012a;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void U() {
        Editable text = this.f2020a.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f2007a != null) {
            N(0, null, text.toString());
        }
        this.f2020a.setImeVisibility(false);
        E();
    }

    public boolean V(View view, int i2, KeyEvent keyEvent) {
        if (this.f2007a != null && this.f2022a != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i2 == 66 || i2 == 84 || i2 == 61) {
                return Q(this.f2020a.getListSelection(), 0, null);
            }
            if (i2 == 21 || i2 == 22) {
                this.f2020a.setSelection(i2 == 21 ? 0 : this.f2020a.length());
                this.f2020a.setListSelection(0);
                this.f2020a.clearListSelection();
                this.f2020a.b();
                return true;
            }
            if (i2 == 19) {
                this.f2020a.getListSelection();
                return false;
            }
        }
        return false;
    }

    public void W(CharSequence charSequence) {
        Editable text = this.f2020a.getText();
        this.f2037d = text;
        boolean z2 = !TextUtils.isEmpty(text);
        h0(z2);
        j0(!z2);
        c0();
        g0();
        this.f2034c = charSequence.toString();
    }

    public void X() {
        i0(J());
        Z();
        if (this.f2020a.hasFocus()) {
            F();
        }
    }

    public void Y() {
        SearchableInfo searchableInfo = this.f2007a;
        if (searchableInfo == null) {
            return;
        }
        try {
            if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                getContext().startActivity(D(this.f2008a, searchableInfo));
            } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                getContext().startActivity(C(this.f7911b, searchableInfo));
            }
        } catch (ActivityNotFoundException unused) {
            Log.w("SearchView", "Could not find voice search activity");
        }
    }

    public final void Z() {
        post(this.f2024a);
    }

    public final void a0(int i2) {
        Editable text = this.f2020a.getText();
        Cursor cursorC = this.f2022a.c();
        if (cursorC == null) {
            return;
        }
        if (!cursorC.moveToPosition(i2)) {
            setQuery(text);
            return;
        }
        CharSequence charSequenceConvertToString = this.f2022a.convertToString(cursorC);
        if (charSequenceConvertToString != null) {
            setQuery(charSequenceConvertToString);
        } else {
            setQuery(text);
        }
    }

    public void b0(CharSequence charSequence, boolean z2) {
        this.f2020a.setText(charSequence);
        if (charSequence != null) {
            SearchAutoComplete searchAutoComplete = this.f2020a;
            searchAutoComplete.setSelection(searchAutoComplete.length());
            this.f2037d = charSequence;
        }
        if (!z2 || TextUtils.isEmpty(charSequence)) {
            return;
        }
        U();
    }

    public final void c0() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f2020a.getText());
        if (!z3 && (!this.f2038d || this.f2041j)) {
            z2 = false;
        }
        this.f2033c.setVisibility(z2 ? 0 : 8);
        Drawable drawable = this.f2033c.getDrawable();
        if (drawable != null) {
            drawable.setState(z3 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void clearFocus() {
        this.f7917h = true;
        super.clearFocus();
        this.f2020a.clearFocus();
        this.f2020a.setImeVisibility(false);
        this.f7917h = false;
    }

    public void d0() {
        int[] iArr = this.f2020a.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f2029b.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f7912c.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public final void e0() {
        CharSequence queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f2020a;
        if (queryHint == null) {
            queryHint = "";
        }
        searchAutoComplete.setHint(H(queryHint));
    }

    public final void f0() {
        this.f2020a.setThreshold(this.f2007a.getSuggestThreshold());
        this.f2020a.setImeOptions(this.f2007a.getImeOptions());
        int inputType = this.f2007a.getInputType();
        if ((inputType & 15) == 1) {
            inputType &= -65537;
            if (this.f2007a.getSuggestAuthority() != null) {
                inputType = inputType | 65536 | inet.ipaddr.format.validate.aux.KEY_STANDARD_RANGE_STR;
            }
        }
        this.f2020a.setInputType(inputType);
        r1 r1Var = this.f2022a;
        if (r1Var != null) {
            r1Var.b(null);
        }
        if (this.f2007a.getSuggestAuthority() != null) {
            k0 k0Var = new k0(getContext(), this, this.f2007a, this.f2025a);
            this.f2022a = k0Var;
            this.f2020a.setAdapter(k0Var);
            ((k0) this.f2022a).w(this.f7916g ? 2 : 1);
        }
    }

    public final void g0() {
        this.f7912c.setVisibility((L() && (this.f2030b.getVisibility() == 0 || this.f2036d.getVisibility() == 0)) ? 0 : 8);
    }

    public int getImeOptions() {
        return this.f2020a.getImeOptions();
    }

    public int getInputType() {
        return this.f2020a.getInputType();
    }

    public int getMaxWidth() {
        return this.f7921l;
    }

    public CharSequence getQuery() {
        return this.f2020a.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f2031b;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f2007a;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f2023a : getContext().getText(this.f2007a.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.f7920k;
    }

    public int getSuggestionRowLayout() {
        return this.f7919j;
    }

    public r1 getSuggestionsAdapter() {
        return this.f2022a;
    }

    public final void h0(boolean z2) {
        this.f2030b.setVisibility((this.f7915f && L() && hasFocus() && (z2 || !this.f7918i)) ? 0 : 8);
    }

    public final void i0(boolean z2) {
        this.f2040e = z2;
        int i2 = z2 ? 0 : 8;
        boolean z3 = !TextUtils.isEmpty(this.f2020a.getText());
        this.f2018a.setVisibility(i2);
        h0(z3);
        this.f2015a.setVisibility(z2 ? 8 : 0);
        this.f7914e.setVisibility((this.f7914e.getDrawable() == null || this.f2038d) ? 8 : 0);
        c0();
        j0(!z3);
        g0();
    }

    public final void j0(boolean z2) {
        int i2 = 8;
        if (this.f7918i && !J() && z2) {
            this.f2030b.setVisibility(8);
            i2 = 0;
        }
        this.f2036d.setVisibility(i2);
    }

    @Override // p012COn.com1
    public void onActionViewCollapsed() {
        b0("", false);
        clearFocus();
        i0(true);
        this.f2020a.setImeOptions(this.f7922m);
        this.f2041j = false;
    }

    @Override // p012COn.com1
    public void onActionViewExpanded() {
        if (this.f2041j) {
            return;
        }
        this.f2041j = true;
        int imeOptions = this.f2020a.getImeOptions();
        this.f7922m = imeOptions;
        this.f2020a.setImeOptions(imeOptions | 33554432);
        this.f2020a.setText("");
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        removeCallbacks(this.f2024a);
        post(this.f2032b);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.con, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (z2) {
            G(this.f2020a, this.f2009a);
            Rect rect = this.f2026b;
            Rect rect2 = this.f2009a;
            rect.set(rect2.left, 0, rect2.right, i5 - i3);
            lpt3 lpt3Var = this.f2021a;
            if (lpt3Var != null) {
                lpt3Var.a(this.f2026b, this.f2009a);
                return;
            }
            lpt3 lpt3Var2 = new lpt3(this.f2026b, this.f2009a, this.f2020a);
            this.f2021a = lpt3Var2;
            setTouchDelegate(lpt3Var2);
        }
    }

    @Override // androidx.appcompat.widget.con, android.view.View
    public void onMeasure(int i2, int i3) {
        int i4;
        if (J()) {
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == Integer.MIN_VALUE) {
            int i5 = this.f7921l;
            size = i5 > 0 ? Math.min(i5, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f7921l;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i4 = this.f7921l) > 0) {
            size = Math.min(i4, size);
        }
        int mode2 = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i3);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof lpt2)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        lpt2 lpt2Var = (lpt2) parcelable;
        super.onRestoreInstanceState(lpt2Var.k());
        i0(lpt2Var.f7937b);
        requestLayout();
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        lpt2 lpt2Var = new lpt2(super.onSaveInstanceState());
        lpt2Var.f7937b = J();
        return lpt2Var;
    }

    @Override // android.view.View
    public void onWindowFocusChanged(boolean z2) {
        super.onWindowFocusChanged(z2);
        Z();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean requestFocus(int i2, Rect rect) {
        if (this.f7917h || !isFocusable()) {
            return false;
        }
        if (J()) {
            return super.requestFocus(i2, rect);
        }
        boolean zRequestFocus = this.f2020a.requestFocus(i2, rect);
        if (zRequestFocus) {
            i0(false);
        }
        return zRequestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.f2010a = bundle;
    }

    public void setIconified(boolean z2) {
        if (z2) {
            P();
        } else {
            T();
        }
    }

    public void setIconifiedByDefault(boolean z2) {
        if (this.f2038d == z2) {
            return;
        }
        this.f2038d = z2;
        i0(z2);
        e0();
    }

    public void setImeOptions(int i2) {
        this.f2020a.setImeOptions(i2);
    }

    public void setInputType(int i2) {
        this.f2020a.setInputType(i2);
    }

    public void setMaxWidth(int i2) {
        this.f7921l = i2;
        requestLayout();
    }

    public void setOnCloseListener(com7 com7Var) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f2013a = onFocusChangeListener;
    }

    public void setOnQueryTextListener(com8 com8Var) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f2012a = onClickListener;
    }

    public void setOnSuggestionListener(com9 com9Var) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f2031b = charSequence;
        e0();
    }

    public void setQueryRefinementEnabled(boolean z2) {
        this.f7916g = z2;
        r1 r1Var = this.f2022a;
        if (r1Var instanceof k0) {
            ((k0) r1Var).w(z2 ? 2 : 1);
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.f2007a = searchableInfo;
        if (searchableInfo != null) {
            f0();
            e0();
        }
        boolean zI = I();
        this.f7918i = zI;
        if (zI) {
            this.f2020a.setPrivateImeOptions("nm");
        }
        i0(J());
    }

    public void setSubmitButtonEnabled(boolean z2) {
        this.f7915f = z2;
        i0(J());
    }

    public void setSuggestionsAdapter(r1 r1Var) {
        this.f2022a = r1Var;
        this.f2020a.setAdapter(r1Var);
    }

    public void z() {
        if (this.f7913d.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.f2029b.getPaddingLeft();
            Rect rect = new Rect();
            boolean zB = u0.b(this);
            int dimensionPixelSize = this.f2038d ? resources.getDimensionPixelSize(p001AuX.com6.f5532e) + resources.getDimensionPixelSize(p001AuX.com6.f5533f) : 0;
            this.f2020a.getDropDownBackground().getPadding(rect);
            this.f2020a.setDropDownHorizontalOffset(zB ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
            this.f2020a.setDropDownWidth((((this.f7913d.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, p001AuX.com3.I);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2009a = new Rect();
        this.f2026b = new Rect();
        this.f2035c = new int[2];
        this.f2039d = new int[2];
        this.f2024a = new con();
        this.f2032b = new nul();
        this.f2025a = new WeakHashMap<>();
        com2 com2Var = new com2();
        this.f2028b = com2Var;
        this.f2014a = new com3();
        com4 com4Var = new com4();
        this.f2019a = com4Var;
        com5 com5Var = new com5();
        this.f2016a = com5Var;
        com6 com6Var = new com6();
        this.f2017a = com6Var;
        this.f2011a = new aux();
        int[] iArr = p001AuX.lpt3.f5A;
        q0 q0VarV = q0.v(context, attributeSet, iArr, i2, 0);
        y.m0(this, context, iArr, attributeSet, q0VarV.r(), i2, 0);
        LayoutInflater.from(context).inflate(q0VarV.n(p001AuX.lpt3.O1, p001AuX.com9.f5608r), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(p001AuX.com8.C);
        this.f2020a = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f2015a = findViewById(p001AuX.com8.f5589y);
        View viewFindViewById = findViewById(p001AuX.com8.B);
        this.f2029b = viewFindViewById;
        View viewFindViewById2 = findViewById(p001AuX.com8.I);
        this.f7912c = viewFindViewById2;
        ImageView imageView = (ImageView) findViewById(p001AuX.com8.f5587w);
        this.f2018a = imageView;
        ImageView imageView2 = (ImageView) findViewById(p001AuX.com8.f5590z);
        this.f2030b = imageView2;
        ImageView imageView3 = (ImageView) findViewById(p001AuX.com8.f5588x);
        this.f2033c = imageView3;
        ImageView imageView4 = (ImageView) findViewById(p001AuX.com8.D);
        this.f2036d = imageView4;
        ImageView imageView5 = (ImageView) findViewById(p001AuX.com8.A);
        this.f7914e = imageView5;
        y.s0(viewFindViewById, q0VarV.g(p001AuX.lpt3.P1));
        y.s0(viewFindViewById2, q0VarV.g(p001AuX.lpt3.T1));
        int i3 = p001AuX.lpt3.S1;
        imageView.setImageDrawable(q0VarV.g(i3));
        imageView2.setImageDrawable(q0VarV.g(p001AuX.lpt3.M1));
        imageView3.setImageDrawable(q0VarV.g(p001AuX.lpt3.J1));
        imageView4.setImageDrawable(q0VarV.g(p001AuX.lpt3.V1));
        imageView5.setImageDrawable(q0VarV.g(i3));
        this.f2027b = q0VarV.g(p001AuX.lpt3.R1);
        s0.a(imageView, getResources().getString(p001AuX.lpt1.f5623n));
        this.f7919j = q0VarV.n(p001AuX.lpt3.U1, p001AuX.com9.f5607q);
        this.f7920k = q0VarV.n(p001AuX.lpt3.K1, 0);
        imageView.setOnClickListener(com2Var);
        imageView3.setOnClickListener(com2Var);
        imageView2.setOnClickListener(com2Var);
        imageView4.setOnClickListener(com2Var);
        searchAutoComplete.setOnClickListener(com2Var);
        searchAutoComplete.addTextChangedListener(this.f2011a);
        searchAutoComplete.setOnEditorActionListener(com4Var);
        searchAutoComplete.setOnItemClickListener(com5Var);
        searchAutoComplete.setOnItemSelectedListener(com6Var);
        searchAutoComplete.setOnKeyListener(this.f2014a);
        searchAutoComplete.setOnFocusChangeListener(new prn());
        setIconifiedByDefault(q0VarV.a(p001AuX.lpt3.N1, true));
        int iF = q0VarV.f(p001AuX.lpt3.G1, -1);
        if (iF != -1) {
            setMaxWidth(iF);
        }
        this.f2023a = q0VarV.p(p001AuX.lpt3.L1);
        this.f2031b = q0VarV.p(p001AuX.lpt3.Q1);
        int iK = q0VarV.k(p001AuX.lpt3.I1, -1);
        if (iK != -1) {
            setImeOptions(iK);
        }
        int iK2 = q0VarV.k(p001AuX.lpt3.H1, -1);
        if (iK2 != -1) {
            setInputType(iK2);
        }
        setFocusable(q0VarV.a(p001AuX.lpt3.F1, true));
        q0VarV.w();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f2008a = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f7911b = intent2;
        intent2.addFlags(268435456);
        View viewFindViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f7913d = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.addOnLayoutChangeListener(new com1());
        }
        i0(this.f2038d);
        e0();
    }
}
