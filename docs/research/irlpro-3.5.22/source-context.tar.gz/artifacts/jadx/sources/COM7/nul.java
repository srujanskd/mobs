package COM7;

/* JADX INFO: loaded from: classes.dex */
public class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int f5718a = 2;
}
