package COM3;

/* JADX INFO: loaded from: classes.dex */
public interface lpt2<T> {
    void a(T t2);
}
