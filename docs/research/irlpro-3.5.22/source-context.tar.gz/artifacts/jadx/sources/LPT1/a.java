package LPT1;

/* JADX INFO: loaded from: classes.dex */
public interface a {
    <T> lpt9<T> a(com1 com1Var, p111lPT2.a<T> aVar);
}
