package com.google.android.material.datepicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.ListAdapter;
import java.util.Calendar;
import java.util.Iterator;
import p024Com2.lpt3;
import p024Com2.y;
import p075cOM6.b4;
import p081cOm2.e2;
import p087cOm8.com3;
import p087cOm8.com4;
import p101com2.q2;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
final class MaterialCalendarGridView extends GridView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Calendar f9444a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f9445b;

    public class aux extends lpt3 {
        public aux() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.V(null);
        }
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public static int d(View view) {
        return view.getLeft() + (view.getWidth() / 2);
    }

    public static boolean e(Long l2, Long l3, Long l4, Long l5) {
        return l2 == null || l3 == null || l4 == null || l5 == null || l4.longValue() > l3.longValue() || l5.longValue() < l2.longValue();
    }

    public final void a(int i2, Rect rect) {
        if (i2 == 33) {
            setSelection(getAdapter().i());
        } else if (i2 == 130) {
            setSelection(getAdapter().b());
        } else {
            super.onFocusChanged(true, i2, rect);
        }
    }

    @Override // android.widget.GridView, android.widget.AdapterView
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public nul getAdapter() {
        return (nul) super.getAdapter();
    }

    public final View c(int i2) {
        return getChildAt(i2 - getFirstVisiblePosition());
    }

    @Override // android.widget.AbsListView, android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getAdapter().notifyDataSetChanged();
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int iA;
        int iD;
        int iA2;
        int iD2;
        int width;
        int i2;
        int right;
        int right2;
        MaterialCalendarGridView materialCalendarGridView = this;
        super.onDraw(canvas);
        nul adapter = getAdapter();
        com4<?> com4Var = adapter.f3514a;
        com3 com3Var = adapter.f3513a;
        int iMax = Math.max(adapter.b(), getFirstVisiblePosition());
        int iMin = Math.min(adapter.i(), getLastVisiblePosition());
        Long item = adapter.getItem(iMax);
        Long item2 = adapter.getItem(iMin);
        Iterator<q2<Long, Long>> it = com4Var.f().iterator();
        while (it.hasNext()) {
            q2<Long, Long> next = it.next();
            Long l2 = next.f10451a;
            if (l2 == null) {
                materialCalendarGridView = this;
            } else if (next.f10452b != null) {
                long jLongValue = l2.longValue();
                long jLongValue2 = next.f10452b.longValue();
                if (!e(item, item2, Long.valueOf(jLongValue), Long.valueOf(jLongValue2))) {
                    boolean zE = v.e(this);
                    if (jLongValue < item.longValue()) {
                        if (adapter.f(iMax)) {
                            right2 = 0;
                        } else {
                            right2 = !zE ? materialCalendarGridView.c(iMax - 1).getRight() : materialCalendarGridView.c(iMax - 1).getLeft();
                        }
                        iD = right2;
                        iA = iMax;
                    } else {
                        materialCalendarGridView.f9444a.setTimeInMillis(jLongValue);
                        iA = adapter.a(materialCalendarGridView.f9444a.get(5));
                        iD = d(materialCalendarGridView.c(iA));
                    }
                    if (jLongValue2 > item2.longValue()) {
                        if (adapter.g(iMin)) {
                            right = getWidth();
                        } else {
                            right = !zE ? materialCalendarGridView.c(iMin).getRight() : materialCalendarGridView.c(iMin).getLeft();
                        }
                        iD2 = right;
                        iA2 = iMin;
                    } else {
                        materialCalendarGridView.f9444a.setTimeInMillis(jLongValue2);
                        iA2 = adapter.a(materialCalendarGridView.f9444a.get(5));
                        iD2 = d(materialCalendarGridView.c(iA2));
                    }
                    int itemId = (int) adapter.getItemId(iA);
                    int i3 = iMax;
                    int i4 = iMin;
                    int itemId2 = (int) adapter.getItemId(iA2);
                    while (itemId <= itemId2) {
                        int numColumns = getNumColumns() * itemId;
                        int numColumns2 = (numColumns + getNumColumns()) - 1;
                        View viewC = materialCalendarGridView.c(numColumns);
                        int top = viewC.getTop() + com3Var.f3217a.c();
                        nul nulVar = adapter;
                        int bottom = viewC.getBottom() - com3Var.f3217a.b();
                        if (zE) {
                            int i5 = iA2 > numColumns2 ? 0 : iD2;
                            width = numColumns > iA ? getWidth() : iD;
                            i2 = i5;
                        } else {
                            i2 = numColumns > iA ? 0 : iD;
                            width = iA2 > numColumns2 ? getWidth() : iD2;
                        }
                        canvas.drawRect(i2, top, width, bottom, com3Var.f9170a);
                        itemId++;
                        materialCalendarGridView = this;
                        it = it;
                        adapter = nulVar;
                    }
                    materialCalendarGridView = this;
                    iMax = i3;
                    iMin = i4;
                }
            }
        }
    }

    @Override // android.widget.GridView, android.widget.AbsListView, android.view.View
    public void onFocusChanged(boolean z2, int i2, Rect rect) {
        if (z2) {
            a(i2, rect);
        } else {
            super.onFocusChanged(false, i2, rect);
        }
    }

    @Override // android.widget.GridView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (!super.onKeyDown(i2, keyEvent)) {
            return false;
        }
        if (getSelectedItemPosition() == -1 || getSelectedItemPosition() >= getAdapter().b()) {
            return true;
        }
        if (19 != i2) {
            return false;
        }
        setSelection(getAdapter().b());
        return true;
    }

    @Override // android.widget.GridView, android.widget.AbsListView, android.view.View
    public void onMeasure(int i2, int i3) {
        if (!this.f9445b) {
            super.onMeasure(i2, i3);
            return;
        }
        super.onMeasure(i2, View.MeasureSpec.makeMeasureSpec(16777215, Integer.MIN_VALUE));
        getLayoutParams().height = getMeasuredHeight();
    }

    @Override // android.widget.GridView, android.widget.AdapterView
    public void setSelection(int i2) {
        if (i2 < getAdapter().b()) {
            super.setSelection(getAdapter().b());
        } else {
            super.setSelection(i2);
        }
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f9444a = p087cOm8.lpt3.i();
        if (MaterialDatePicker.A(getContext())) {
            setNextFocusLeftId(b4.f8875a);
            setNextFocusRightId(b4.f8879c);
        }
        this.f9445b = MaterialDatePicker.B(getContext());
        y.o0(this, new aux());
    }

    @Override // android.widget.AdapterView
    public final void setAdapter(ListAdapter listAdapter) {
        if (!(listAdapter instanceof nul)) {
            throw new IllegalArgumentException(String.format("%1$s must have its Adapter set to a %2$s", MaterialCalendarGridView.class.getCanonicalName(), nul.class.getCanonicalName()));
        }
        super.setAdapter(listAdapter);
    }
}
