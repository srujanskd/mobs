package com.google.android.material.transformation;

import COM6.com4;
import COM6.com5;
import COM6.com6;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import p024Com2.y;
import p031Com9.lpt5;
import p075cOM6.b4;
import p110lPT1.p;
import p110lPT1.q;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f9726a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f3813a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f3814a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f3815a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f9727b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final RectF f3816b;

    public class aux extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f9728a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ View f9729b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ boolean f3818b;

        public aux(boolean z2, View view, View view2) {
            this.f3818b = z2;
            this.f9728a = view;
            this.f9729b = view2;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f3818b) {
                return;
            }
            this.f9728a.setVisibility(4);
            this.f9729b.setAlpha(1.0f);
            this.f9729b.setVisibility(0);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            if (this.f3818b) {
                this.f9728a.setVisibility(0);
                this.f9729b.setAlpha(0.0f);
                this.f9729b.setVisibility(4);
            }
        }
    }

    public static class com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public com4 f9730a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com6 f3819a;
    }

    public class con implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f9731a;

        public con(View view) {
            this.f9731a = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            this.f9731a.invalidate();
        }
    }

    public class nul extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ COM7.prn f9732a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Drawable f3821a;

        public nul(COM7.prn prnVar, Drawable drawable) {
            this.f9732a = prnVar;
            this.f3821a = drawable;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f9732a.setCircularRevealOverlayDrawable(null);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f9732a.setCircularRevealOverlayDrawable(this.f3821a);
        }
    }

    public class prn extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ COM7.prn f9733a;

        public prn(COM7.prn prnVar) {
            this.f9733a = prnVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            COM7.prn.com1 revealInfo = this.f9733a.getRevealInfo();
            revealInfo.f5721c = Float.MAX_VALUE;
            this.f9733a.setRevealInfo(revealInfo);
        }
    }

    public FabTransformationBehavior() {
        this.f3813a = new Rect();
        this.f3814a = new RectF();
        this.f3816b = new RectF();
        this.f3815a = new int[2];
    }

    @Override // com.google.android.material.transformation.ExpandableTransformationBehavior
    public AnimatorSet J(View view, View view2, boolean z2, boolean z3) {
        com1 com1VarE0 = e0(view2.getContext(), z2);
        if (z2) {
            this.f9726a = view.getTranslationX();
            this.f9727b = view.getTranslationY();
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        X(view, view2, z2, z3, com1VarE0, arrayList, arrayList2);
        RectF rectF = this.f3814a;
        c0(view, view2, z2, z3, com1VarE0, arrayList, arrayList2, rectF);
        float fWidth = rectF.width();
        float fHeight = rectF.height();
        W(view, view2, z2, com1VarE0, arrayList);
        Z(view, view2, z2, z3, com1VarE0, arrayList, arrayList2);
        Y(view, view2, z2, z3, com1VarE0, fWidth, fHeight, arrayList, arrayList2);
        V(view, view2, z2, z3, com1VarE0, arrayList, arrayList2);
        U(view, view2, z2, z3, com1VarE0, arrayList, arrayList2);
        AnimatorSet animatorSet = new AnimatorSet();
        COM6.con.a(animatorSet, arrayList);
        animatorSet.addListener(new aux(z2, view2, view));
        int size = arrayList2.size();
        for (int i2 = 0; i2 < size; i2++) {
            animatorSet.addListener(arrayList2.get(i2));
        }
        return animatorSet;
    }

    public final ViewGroup K(View view) {
        View viewFindViewById = view.findViewById(b4.M);
        if (viewFindViewById != null) {
            return f0(viewFindViewById);
        }
        return ((view instanceof q) || (view instanceof p)) ? f0(((ViewGroup) view).getChildAt(0)) : f0(view);
    }

    public final void L(View view, com1 com1Var, com5 com5Var, com5 com5Var2, float f2, float f3, float f4, float f5, RectF rectF) {
        float fS = S(com1Var, com5Var, f2, f4);
        float fS2 = S(com1Var, com5Var2, f3, f5);
        Rect rect = this.f3813a;
        view.getWindowVisibleDisplayFrame(rect);
        RectF rectF2 = this.f3814a;
        rectF2.set(rect);
        RectF rectF3 = this.f3816b;
        T(view, rectF3);
        rectF3.offset(fS, fS2);
        rectF3.intersect(rectF2);
        rectF.set(rectF3);
    }

    public final void M(View view, RectF rectF) {
        T(view, rectF);
        rectF.offset(this.f9726a, this.f9727b);
    }

    public final Pair<com5, com5> N(float f2, float f3, boolean z2, com1 com1Var) {
        com5 com5VarE;
        com5 com5VarE2;
        if (f2 == 0.0f || f3 == 0.0f) {
            com5VarE = com1Var.f9730a.e("translationXLinear");
            com5VarE2 = com1Var.f9730a.e("translationYLinear");
        } else if ((!z2 || f3 >= 0.0f) && (z2 || f3 <= 0.0f)) {
            com5VarE = com1Var.f9730a.e("translationXCurveDownwards");
            com5VarE2 = com1Var.f9730a.e("translationYCurveDownwards");
        } else {
            com5VarE = com1Var.f9730a.e("translationXCurveUpwards");
            com5VarE2 = com1Var.f9730a.e("translationYCurveUpwards");
        }
        return new Pair<>(com5VarE, com5VarE2);
    }

    public final float O(View view, View view2, com6 com6Var) {
        RectF rectF = this.f3814a;
        RectF rectF2 = this.f3816b;
        M(view, rectF);
        T(view2, rectF2);
        rectF2.offset(-Q(view, view2, com6Var), 0.0f);
        return rectF.centerX() - rectF2.left;
    }

    public final float P(View view, View view2, com6 com6Var) {
        RectF rectF = this.f3814a;
        RectF rectF2 = this.f3816b;
        M(view, rectF);
        T(view2, rectF2);
        rectF2.offset(0.0f, -R(view, view2, com6Var));
        return rectF.centerY() - rectF2.top;
    }

    public final float Q(View view, View view2, com6 com6Var) {
        float fCenterX;
        float fCenterX2;
        float f2;
        RectF rectF = this.f3814a;
        RectF rectF2 = this.f3816b;
        M(view, rectF);
        T(view2, rectF2);
        int i2 = com6Var.f69a & 7;
        if (i2 == 1) {
            fCenterX = rectF2.centerX();
            fCenterX2 = rectF.centerX();
        } else {
            if (i2 != 3) {
                if (i2 != 5) {
                    f2 = 0.0f;
                } else {
                    fCenterX = rectF2.right;
                    fCenterX2 = rectF.right;
                }
                return f2 + com6Var.f5713a;
            }
            fCenterX = rectF2.left;
            fCenterX2 = rectF.left;
        }
        f2 = fCenterX - fCenterX2;
        return f2 + com6Var.f5713a;
    }

    public final float R(View view, View view2, com6 com6Var) {
        float fCenterY;
        float fCenterY2;
        float f2;
        RectF rectF = this.f3814a;
        RectF rectF2 = this.f3816b;
        M(view, rectF);
        T(view2, rectF2);
        int i2 = com6Var.f69a & 112;
        if (i2 == 16) {
            fCenterY = rectF2.centerY();
            fCenterY2 = rectF.centerY();
        } else {
            if (i2 != 48) {
                if (i2 != 80) {
                    f2 = 0.0f;
                } else {
                    fCenterY = rectF2.bottom;
                    fCenterY2 = rectF.bottom;
                }
                return f2 + com6Var.f5714b;
            }
            fCenterY = rectF2.top;
            fCenterY2 = rectF.top;
        }
        f2 = fCenterY - fCenterY2;
        return f2 + com6Var.f5714b;
    }

    public final float S(com1 com1Var, com5 com5Var, float f2, float f3) {
        long jC = com5Var.c();
        long jD = com5Var.d();
        com5 com5VarE = com1Var.f9730a.e("expansion");
        return COM6.aux.a(f2, f3, com5Var.e().getInterpolation((((com5VarE.c() + com5VarE.d()) + 17) - jC) / jD));
    }

    public final void T(View view, RectF rectF) {
        rectF.set(0.0f, 0.0f, view.getWidth(), view.getHeight());
        int[] iArr = this.f3815a;
        view.getLocationInWindow(iArr);
        rectF.offsetTo(iArr[0], iArr[1]);
        rectF.offset((int) (-view.getTranslationX()), (int) (-view.getTranslationY()));
    }

    public final void U(View view, View view2, boolean z2, boolean z3, com1 com1Var, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ViewGroup viewGroupK;
        ObjectAnimator objectAnimatorOfFloat;
        if (view2 instanceof ViewGroup) {
            if (((view2 instanceof COM7.prn) && COM7.nul.f5718a == 0) || (viewGroupK = K(view2)) == null) {
                return;
            }
            if (z2) {
                if (!z3) {
                    COM6.prn.f5716a.set(viewGroupK, Float.valueOf(0.0f));
                }
                objectAnimatorOfFloat = ObjectAnimator.ofFloat(viewGroupK, COM6.prn.f5716a, 1.0f);
            } else {
                objectAnimatorOfFloat = ObjectAnimator.ofFloat(viewGroupK, COM6.prn.f5716a, 0.0f);
            }
            com1Var.f9730a.e("contentFade").a(objectAnimatorOfFloat);
            list.add(objectAnimatorOfFloat);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void V(View view, View view2, boolean z2, boolean z3, com1 com1Var, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ObjectAnimator objectAnimatorOfInt;
        if (view2 instanceof COM7.prn) {
            COM7.prn prnVar = (COM7.prn) view2;
            int iD0 = d0(view);
            int i2 = 16777215 & iD0;
            if (z2) {
                if (!z3) {
                    prnVar.setCircularRevealScrimColor(iD0);
                }
                objectAnimatorOfInt = ObjectAnimator.ofInt(prnVar, COM7.prn.C0004prn.f5724a, i2);
            } else {
                objectAnimatorOfInt = ObjectAnimator.ofInt(prnVar, COM7.prn.C0004prn.f5724a, iD0);
            }
            objectAnimatorOfInt.setEvaluator(COM6.nul.b());
            com1Var.f9730a.e("color").a(objectAnimatorOfInt);
            list.add(objectAnimatorOfInt);
        }
    }

    public final void W(View view, View view2, boolean z2, com1 com1Var, List<Animator> list) {
        float fQ = Q(view, view2, com1Var.f3819a);
        float fR = R(view, view2, com1Var.f3819a);
        Pair<com5, com5> pairN = N(fQ, fR, z2, com1Var);
        com5 com5Var = (com5) pairN.first;
        com5 com5Var2 = (com5) pairN.second;
        Property property = View.TRANSLATION_X;
        float[] fArr = new float[1];
        if (!z2) {
            fQ = this.f9726a;
        }
        fArr[0] = fQ;
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) property, fArr);
        Property property2 = View.TRANSLATION_Y;
        float[] fArr2 = new float[1];
        if (!z2) {
            fR = this.f9727b;
        }
        fArr2[0] = fR;
        ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view, (Property<View, Float>) property2, fArr2);
        com5Var.a(objectAnimatorOfFloat);
        com5Var2.a(objectAnimatorOfFloat2);
        list.add(objectAnimatorOfFloat);
        list.add(objectAnimatorOfFloat2);
    }

    @TargetApi(21)
    public final void X(View view, View view2, boolean z2, boolean z3, com1 com1Var, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ObjectAnimator objectAnimatorOfFloat;
        float fV = y.v(view2) - y.v(view);
        if (z2) {
            if (!z3) {
                view2.setTranslationZ(-fV);
            }
            objectAnimatorOfFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Z, 0.0f);
        } else {
            objectAnimatorOfFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Z, -fV);
        }
        com1Var.f9730a.e("elevation").a(objectAnimatorOfFloat);
        list.add(objectAnimatorOfFloat);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void Y(View view, View view2, boolean z2, boolean z3, com1 com1Var, float f2, float f3, List<Animator> list, List<Animator.AnimatorListener> list2) {
        Animator animatorA;
        if (view2 instanceof COM7.prn) {
            COM7.prn prnVar = (COM7.prn) view2;
            float fO = O(view, view2, com1Var.f3819a);
            float fP = P(view, view2, com1Var.f3819a);
            ((FloatingActionButton) view).i(this.f3813a);
            float fWidth = this.f3813a.width() / 2.0f;
            com5 com5VarE = com1Var.f9730a.e("expansion");
            if (z2) {
                if (!z3) {
                    prnVar.setRevealInfo(new COM7.prn.com1(fO, fP, fWidth));
                }
                if (z3) {
                    fWidth = prnVar.getRevealInfo().f5721c;
                }
                animatorA = COM7.aux.a(prnVar, fO, fP, lpt5.b(fO, fP, 0.0f, 0.0f, f2, f3));
                animatorA.addListener(new prn(prnVar));
                b0(view2, com5VarE.c(), (int) fO, (int) fP, fWidth, list);
            } else {
                float f4 = prnVar.getRevealInfo().f5721c;
                Animator animatorA2 = COM7.aux.a(prnVar, fO, fP, fWidth);
                int i2 = (int) fO;
                int i3 = (int) fP;
                b0(view2, com5VarE.c(), i2, i3, f4, list);
                a0(view2, com5VarE.c(), com5VarE.d(), com1Var.f9730a.f(), i2, i3, fWidth, list);
                animatorA = animatorA2;
            }
            com5VarE.a(animatorA);
            list.add(animatorA);
            list2.add(COM7.aux.b(prnVar));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void Z(View view, View view2, boolean z2, boolean z3, com1 com1Var, List<Animator> list, List<Animator.AnimatorListener> list2) {
        ObjectAnimator objectAnimatorOfInt;
        if ((view2 instanceof COM7.prn) && (view instanceof ImageView)) {
            COM7.prn prnVar = (COM7.prn) view2;
            Drawable drawable = ((ImageView) view).getDrawable();
            if (drawable == null) {
                return;
            }
            drawable.mutate();
            if (z2) {
                if (!z3) {
                    drawable.setAlpha(255);
                }
                objectAnimatorOfInt = ObjectAnimator.ofInt(drawable, COM6.com1.f5705a, 0);
            } else {
                objectAnimatorOfInt = ObjectAnimator.ofInt(drawable, COM6.com1.f5705a, 255);
            }
            objectAnimatorOfInt.addUpdateListener(new con(view2));
            com1Var.f9730a.e("iconFade").a(objectAnimatorOfInt);
            list.add(objectAnimatorOfInt);
            list2.add(new nul(prnVar, drawable));
        }
    }

    public final void a0(View view, long j2, long j3, long j4, int i2, int i3, float f2, List<Animator> list) {
        long j5 = j2 + j3;
        if (j5 < j4) {
            Animator animatorCreateCircularReveal = ViewAnimationUtils.createCircularReveal(view, i2, i3, f2, f2);
            animatorCreateCircularReveal.setStartDelay(j5);
            animatorCreateCircularReveal.setDuration(j4 - j5);
            list.add(animatorCreateCircularReveal);
        }
    }

    public final void b0(View view, long j2, int i2, int i3, float f2, List<Animator> list) {
        if (j2 > 0) {
            Animator animatorCreateCircularReveal = ViewAnimationUtils.createCircularReveal(view, i2, i3, f2, f2);
            animatorCreateCircularReveal.setStartDelay(0L);
            animatorCreateCircularReveal.setDuration(j2);
            list.add(animatorCreateCircularReveal);
        }
    }

    public final void c0(View view, View view2, boolean z2, boolean z3, com1 com1Var, List<Animator> list, List<Animator.AnimatorListener> list2, RectF rectF) {
        ObjectAnimator objectAnimatorOfFloat;
        ObjectAnimator objectAnimatorOfFloat2;
        float fQ = Q(view, view2, com1Var.f3819a);
        float fR = R(view, view2, com1Var.f3819a);
        Pair<com5, com5> pairN = N(fQ, fR, z2, com1Var);
        com5 com5Var = (com5) pairN.first;
        com5 com5Var2 = (com5) pairN.second;
        if (z2) {
            if (!z3) {
                view2.setTranslationX(-fQ);
                view2.setTranslationY(-fR);
            }
            objectAnimatorOfFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_X, 0.0f);
            objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Y, 0.0f);
            L(view2, com1Var, com5Var, com5Var2, -fQ, -fR, 0.0f, 0.0f, rectF);
        } else {
            objectAnimatorOfFloat = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_X, -fQ);
            objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view2, (Property<View, Float>) View.TRANSLATION_Y, -fR);
        }
        com5Var.a(objectAnimatorOfFloat);
        com5Var2.a(objectAnimatorOfFloat2);
        list.add(objectAnimatorOfFloat);
        list.add(objectAnimatorOfFloat2);
    }

    public final int d0(View view) {
        ColorStateList colorStateListR = y.r(view);
        if (colorStateListR != null) {
            return colorStateListR.getColorForState(view.getDrawableState(), colorStateListR.getDefaultColor());
        }
        return 0;
    }

    @Override // com.google.android.material.transformation.ExpandableBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean e(CoordinatorLayout coordinatorLayout, View view, View view2) {
        if (view.getVisibility() == 8) {
            throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
        }
        if (!(view2 instanceof FloatingActionButton)) {
            return false;
        }
        int expandedComponentIdHint = ((FloatingActionButton) view2).getExpandedComponentIdHint();
        return expandedComponentIdHint == 0 || expandedComponentIdHint == view.getId();
    }

    public abstract com1 e0(Context context, boolean z2);

    public final ViewGroup f0(View view) {
        if (view instanceof ViewGroup) {
            return (ViewGroup) view;
        }
        return null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void g(CoordinatorLayout.com2 com2Var) {
        if (com2Var.f8163f == 0) {
            com2Var.f8163f = 80;
        }
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3813a = new Rect();
        this.f3814a = new RectF();
        this.f3816b = new RectF();
        this.f3815a = new int[2];
    }
}
