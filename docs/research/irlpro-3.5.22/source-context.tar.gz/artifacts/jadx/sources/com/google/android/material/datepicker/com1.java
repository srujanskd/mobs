package com.google.android.material.datepicker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import p075cOM6.d4;
import p075cOM6.f4;
import p087cOm8.com2;
import p087cOm8.com3;
import p087cOm8.com8;
import p087cOm8.lpt3;

/* JADX INFO: loaded from: classes.dex */
public class com1 extends RecyclerView.com3<con> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MaterialCalendar<?> f9468a;

    public class aux implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9469a;

        public aux(int i2) {
            this.f9469a = i2;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            com1.this.f9468a.E(com1.this.f9468a.v().p(com8.n(this.f9469a, com1.this.f9468a.x().f9180a)));
            com1.this.f9468a.F(MaterialCalendar.com7.DAY);
        }
    }

    public static class con extends RecyclerView.h {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final TextView f9470a;

        public con(TextView textView) {
            super(textView);
            this.f9470a = textView;
        }
    }

    public com1(MaterialCalendar<?> materialCalendar) {
        this.f9468a = materialCalendar;
    }

    public int A(int i2) {
        return i2 - this.f9468a.v().u().f9181b;
    }

    public int B(int i2) {
        return this.f9468a.v().u().f9181b + i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    /* JADX INFO: renamed from: C, reason: merged with bridge method [inline-methods] */
    public void n(con conVar, int i2) {
        int iB = B(i2);
        String string = conVar.f9470a.getContext().getString(f4.f8952w);
        conVar.f9470a.setText(String.format(Locale.getDefault(), "%d", Integer.valueOf(iB)));
        conVar.f9470a.setContentDescription(String.format(string, Integer.valueOf(iB)));
        com3 com3VarW = this.f9468a.w();
        Calendar calendarG = lpt3.g();
        com2 com2Var = calendarG.get(1) == iB ? com3VarW.f9175f : com3VarW.f9173d;
        Iterator<Long> it = this.f9468a.y().c().iterator();
        while (it.hasNext()) {
            calendarG.setTimeInMillis(it.next().longValue());
            if (calendarG.get(1) == iB) {
                com2Var = com3VarW.f9174e;
            }
        }
        com2Var.d(conVar.f9470a);
        conVar.f9470a.setOnClickListener(z(iB));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    /* JADX INFO: renamed from: D, reason: merged with bridge method [inline-methods] */
    public con p(ViewGroup viewGroup, int i2) {
        return new con((TextView) LayoutInflater.from(viewGroup.getContext()).inflate(d4.f8926t, viewGroup, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    public int f() {
        return this.f9468a.v().v();
    }

    public final View.OnClickListener z(int i2) {
        return new aux(i2);
    }
}
