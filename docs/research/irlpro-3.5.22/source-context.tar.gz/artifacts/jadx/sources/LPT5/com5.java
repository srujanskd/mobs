package LPT5;

import android.content.Context;
import app.irlpro.android.R;
import com.newrelic.agent.android.harvest.HarvestTimer;
import com.wmspanel.libstream.lpt5;

/* JADX INFO: loaded from: classes.dex */
public class com5 extends prn {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f6666d;

    public com5(Context context) {
        super(context);
    }

    @Override // LPT5.prn
    public void g(long j2, long j3) {
        long jCurrentTimeMillis = System.currentTimeMillis();
        nul nulVar = (nul) con.c(((prn) this).f884a);
        aux auxVar = (aux) con.c(((prn) this).f889b);
        long jMax = Math.max(auxVar.f6642a, nulVar.f6671a);
        if (nulVar.f6672b == j2 && nulVar.f6673c == j3) {
            if (auxVar.f6643b == ((aux) con.a(((prn) this).f889b)).f6643b || jCurrentTimeMillis - jMax < HarvestTimer.DEFAULT_HARVEST_PERIOD) {
                return;
            }
            e(Math.min(this.f6676c, (auxVar.f6643b * 1415) / 1000));
            return;
        }
        long j4 = jCurrentTimeMillis - auxVar.f6642a;
        ((prn) this).f884a.add(new nul(jCurrentTimeMillis, j2, j3));
        if (auxVar.f6643b <= this.f6666d || j4 < 1500 || m(Math.max(auxVar.f6642a + 1500, jCurrentTimeMillis - 10000)) < 4) {
            return;
        }
        e(Math.max(this.f6666d, (auxVar.f6643b * 1000) / 1414));
    }

    @Override // LPT5.prn
    public String j() {
        return ((prn) this).f879a.getString(R.string.adaptive_bitrate_logarithmic_descend);
    }

    @Override // LPT5.prn
    public void x(int i2) {
        ((prn) this).f888b = i2;
        super.x(i2);
        this.f6666d = i2 / 4;
    }

    @Override // LPT5.prn
    public void z(lpt5 lpt5Var, int i2) {
        this.f6666d = i2 / 4;
        super.z(lpt5Var, i2);
    }
}
