package com.google.android.material.textfield;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Spinner;
import p024Com2.y;
import p033LPt1.d;
import p075cOM6.a4;
import p075cOM6.f4;
import p075cOM6.x3;
import p075cOM6.z3;
import p081cOm2.e2;
import p081cOm2.w1;
import p108com9.s;

/* JADX INFO: loaded from: classes.dex */
public class con extends d {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final boolean f9652c = true;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f9653a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM9.com3 f3725a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3726a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public StateListDrawable f3727a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextWatcher f3728a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnAttachStateChangeListener f3729a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnFocusChangeListener f3730a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public AccessibilityManager f3731a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final w1.con f3732a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout.com1 f3733a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout.com2 f3734a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    @SuppressLint({"ClickableViewAccessibility"})
    public final TextInputLayout.com3 f3735a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f3736a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ValueAnimator f9654b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3737b;

    public class aux extends s {

        /* JADX INFO: renamed from: com.google.android.material.textfield.con$aux$aux, reason: collision with other inner class name */
        public class RunnableC0062aux implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ AutoCompleteTextView f9656a;

            public RunnableC0062aux(AutoCompleteTextView autoCompleteTextView) {
                this.f9656a = autoCompleteTextView;
            }

            @Override // java.lang.Runnable
            public void run() {
                boolean zIsPopupShowing = this.f9656a.isPopupShowing();
                con.this.J(zIsPopupShowing);
                con.this.f3736a = zIsPopupShowing;
            }
        }

        public aux() {
        }

        @Override // p108com9.s, android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            AutoCompleteTextView autoCompleteTextViewC = con.C(((d) con.this).f958a.getEditText());
            if (con.this.f3731a.isTouchExplorationEnabled() && con.H(autoCompleteTextViewC) && !((d) con.this).f957a.hasFocus()) {
                autoCompleteTextViewC.dismissDropDown();
            }
            autoCompleteTextViewC.post(new RunnableC0062aux(autoCompleteTextViewC));
        }
    }

    public class com1 implements View.OnFocusChangeListener {
        public com1() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z2) {
            ((d) con.this).f958a.setEndIconActivated(z2);
            if (z2) {
                return;
            }
            con.this.J(false);
            con.this.f3736a = false;
        }
    }

    public class com2 extends TextInputLayout.com1 {
        public com2(TextInputLayout textInputLayout) {
            super(textInputLayout);
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com1, p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            if (!con.H(((d) con.this).f958a.getEditText())) {
                e2Var.T(Spinner.class.getName());
            }
            if (e2Var.G()) {
                e2Var.e0(null);
            }
        }

        @Override // p024Com2.lpt3
        public void h(View view, AccessibilityEvent accessibilityEvent) {
            super.h(view, accessibilityEvent);
            AutoCompleteTextView autoCompleteTextViewC = con.C(((d) con.this).f958a.getEditText());
            if (accessibilityEvent.getEventType() == 1 && con.this.f3731a.isEnabled() && !con.H(((d) con.this).f958a.getEditText())) {
                con.this.M(autoCompleteTextViewC);
                con.this.N();
            }
        }
    }

    public class com3 implements TextInputLayout.com2 {
        public com3() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com2
        public void a(TextInputLayout textInputLayout) {
            AutoCompleteTextView autoCompleteTextViewC = con.C(textInputLayout.getEditText());
            con.this.K(autoCompleteTextViewC);
            con.this.y(autoCompleteTextViewC);
            con.this.L(autoCompleteTextViewC);
            autoCompleteTextViewC.setThreshold(0);
            autoCompleteTextViewC.removeTextChangedListener(con.this.f3728a);
            autoCompleteTextViewC.addTextChangedListener(con.this.f3728a);
            textInputLayout.setEndIconCheckable(true);
            textInputLayout.setErrorIconDrawable((Drawable) null);
            if (!con.H(autoCompleteTextViewC) && con.this.f3731a.isTouchExplorationEnabled()) {
                y.y0(((d) con.this).f957a, 2);
            }
            textInputLayout.setTextInputAccessibilityDelegate(con.this.f3733a);
            textInputLayout.setEndIconVisible(true);
        }
    }

    public class com4 implements TextInputLayout.com3 {

        public class aux implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ AutoCompleteTextView f9661a;

            public aux(AutoCompleteTextView autoCompleteTextView) {
                this.f9661a = autoCompleteTextView;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.f9661a.removeTextChangedListener(con.this.f3728a);
            }
        }

        public com4() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com3
        public void a(TextInputLayout textInputLayout, int i2) {
            AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) textInputLayout.getEditText();
            if (autoCompleteTextView != null && i2 == 3) {
                autoCompleteTextView.post(new aux(autoCompleteTextView));
                if (autoCompleteTextView.getOnFocusChangeListener() == con.this.f3730a) {
                    autoCompleteTextView.setOnFocusChangeListener(null);
                }
                autoCompleteTextView.setOnTouchListener(null);
                if (con.f9652c) {
                    autoCompleteTextView.setOnDismissListener(null);
                }
            }
            if (i2 == 3) {
                textInputLayout.removeOnAttachStateChangeListener(con.this.f3729a);
                con.this.I();
            }
        }
    }

    public class com5 implements View.OnAttachStateChangeListener {
        public com5() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            con.this.B();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            con.this.I();
        }
    }

    public class com6 implements w1.con {
        public com6() {
        }

        @Override // cOm2.w1.con
        public void onTouchExplorationStateChanged(boolean z2) {
            AutoCompleteTextView autoCompleteTextView;
            TextInputLayout textInputLayout = ((d) con.this).f958a;
            if (textInputLayout == null || (autoCompleteTextView = (AutoCompleteTextView) textInputLayout.getEditText()) == null || con.H(autoCompleteTextView)) {
                return;
            }
            y.y0(((d) con.this).f957a, z2 ? 2 : 1);
        }
    }

    public class com7 implements View.OnClickListener {
        public com7() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            con.this.M((AutoCompleteTextView) ((d) con.this).f958a.getEditText());
        }
    }

    public class com8 implements View.OnTouchListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ AutoCompleteTextView f9665a;

        public com8(AutoCompleteTextView autoCompleteTextView) {
            this.f9665a = autoCompleteTextView;
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == 1) {
                if (con.this.G()) {
                    con.this.f3736a = false;
                }
                con.this.M(this.f9665a);
                con.this.N();
            }
            return false;
        }
    }

    /* JADX INFO: renamed from: com.google.android.material.textfield.con$con, reason: collision with other inner class name */
    public class C0063con implements AutoCompleteTextView.OnDismissListener {
        public C0063con() {
        }

        @Override // android.widget.AutoCompleteTextView.OnDismissListener
        public void onDismiss() {
            con.this.N();
            con.this.J(false);
        }
    }

    public class nul extends AnimatorListenerAdapter {
        public nul() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            con conVar = con.this;
            ((d) conVar).f957a.setChecked(conVar.f3737b);
            con.this.f9654b.start();
        }
    }

    public class prn implements ValueAnimator.AnimatorUpdateListener {
        public prn() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((d) con.this).f957a.setAlpha(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    public con(TextInputLayout textInputLayout, int i2) {
        super(textInputLayout, i2);
        this.f3728a = new aux();
        this.f3730a = new com1();
        this.f3733a = new com2(((d) this).f958a);
        this.f3734a = new com3();
        this.f3735a = new com4();
        this.f3729a = new com5();
        this.f3732a = new com6();
        this.f3736a = false;
        this.f3737b = false;
        this.f9653a = Long.MAX_VALUE;
    }

    public static AutoCompleteTextView C(EditText editText) {
        if (editText instanceof AutoCompleteTextView) {
            return (AutoCompleteTextView) editText;
        }
        throw new RuntimeException("EditText needs to be an AutoCompleteTextView if an Exposed Dropdown Menu is being used.");
    }

    public static boolean H(EditText editText) {
        return editText.getKeyListener() != null;
    }

    public final void A(AutoCompleteTextView autoCompleteTextView, int i2, int[][] iArr, COM9.com3 com3Var) {
        LayerDrawable layerDrawable;
        int iD = p030Com8.prn.d(autoCompleteTextView, x3.f9038m);
        COM9.com3 com3Var2 = new COM9.com3(com3Var.D());
        int iH = p030Com8.prn.h(i2, iD, 0.1f);
        com3Var2.Y(new ColorStateList(iArr, new int[]{iH, 0}));
        if (f9652c) {
            com3Var2.setTint(iD);
            ColorStateList colorStateList = new ColorStateList(iArr, new int[]{iH, iD});
            COM9.com3 com3Var3 = new COM9.com3(com3Var.D());
            com3Var3.setTint(-1);
            layerDrawable = new LayerDrawable(new Drawable[]{new RippleDrawable(colorStateList, com3Var2, com3Var3), com3Var});
        } else {
            layerDrawable = new LayerDrawable(new Drawable[]{com3Var2, com3Var});
        }
        y.s0(autoCompleteTextView, layerDrawable);
    }

    public final void B() {
        TextInputLayout textInputLayout;
        if (this.f3731a == null || (textInputLayout = ((d) this).f958a) == null || !y.R(textInputLayout)) {
            return;
        }
        w1.a(this.f3731a, this.f3732a);
    }

    public final ValueAnimator D(int i2, float... fArr) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(fArr);
        valueAnimatorOfFloat.setInterpolator(COM6.aux.f5700a);
        valueAnimatorOfFloat.setDuration(i2);
        valueAnimatorOfFloat.addUpdateListener(new prn());
        return valueAnimatorOfFloat;
    }

    public final COM9.com3 E(float f2, float f3, float f4, int i2) {
        COM9.com7 com7VarM = COM9.com7.a().A(f2).E(f2).s(f3).w(f3).m();
        COM9.com3 com3VarM = COM9.com3.m(((d) this).f956a, f4);
        com3VarM.setShapeAppearanceModel(com7VarM);
        com3VarM.a0(0, i2, 0, i2);
        return com3VarM;
    }

    public final void F() {
        this.f9654b = D(67, 0.0f, 1.0f);
        ValueAnimator valueAnimatorD = D(50, 1.0f, 0.0f);
        this.f3726a = valueAnimatorD;
        valueAnimatorD.addListener(new nul());
    }

    public final boolean G() {
        long jCurrentTimeMillis = System.currentTimeMillis() - this.f9653a;
        return jCurrentTimeMillis < 0 || jCurrentTimeMillis > 300;
    }

    public final void I() {
        AccessibilityManager accessibilityManager = this.f3731a;
        if (accessibilityManager != null) {
            w1.b(accessibilityManager, this.f3732a);
        }
    }

    public final void J(boolean z2) {
        if (this.f3737b != z2) {
            this.f3737b = z2;
            this.f9654b.cancel();
            this.f3726a.start();
        }
    }

    public final void K(AutoCompleteTextView autoCompleteTextView) {
        if (f9652c) {
            int boxBackgroundMode = ((d) this).f958a.getBoxBackgroundMode();
            if (boxBackgroundMode == 2) {
                autoCompleteTextView.setDropDownBackgroundDrawable(this.f3725a);
            } else if (boxBackgroundMode == 1) {
                autoCompleteTextView.setDropDownBackgroundDrawable(this.f3727a);
            }
        }
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public final void L(AutoCompleteTextView autoCompleteTextView) {
        autoCompleteTextView.setOnTouchListener(new com8(autoCompleteTextView));
        autoCompleteTextView.setOnFocusChangeListener(this.f3730a);
        if (f9652c) {
            autoCompleteTextView.setOnDismissListener(new C0063con());
        }
    }

    public final void M(AutoCompleteTextView autoCompleteTextView) {
        if (autoCompleteTextView == null) {
            return;
        }
        if (G()) {
            this.f3736a = false;
        }
        if (this.f3736a) {
            this.f3736a = false;
            return;
        }
        if (f9652c) {
            J(!this.f3737b);
        } else {
            this.f3737b = !this.f3737b;
            ((d) this).f957a.toggle();
        }
        if (!this.f3737b) {
            autoCompleteTextView.dismissDropDown();
        } else {
            autoCompleteTextView.requestFocus();
            autoCompleteTextView.showDropDown();
        }
    }

    public final void N() {
        this.f3736a = true;
        this.f9653a = System.currentTimeMillis();
    }

    public void O(AutoCompleteTextView autoCompleteTextView) {
        if (!H(autoCompleteTextView) && ((d) this).f958a.getBoxBackgroundMode() == 2 && (autoCompleteTextView.getBackground() instanceof LayerDrawable)) {
            y(autoCompleteTextView);
        }
    }

    @Override // p033LPt1.d
    public void a() {
        float dimensionPixelOffset = ((d) this).f956a.getResources().getDimensionPixelOffset(z3.U);
        float dimensionPixelOffset2 = ((d) this).f956a.getResources().getDimensionPixelOffset(z3.R);
        int dimensionPixelOffset3 = ((d) this).f956a.getResources().getDimensionPixelOffset(z3.S);
        COM9.com3 com3VarE = E(dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset3);
        COM9.com3 com3VarE2 = E(0.0f, dimensionPixelOffset, dimensionPixelOffset2, dimensionPixelOffset3);
        this.f3725a = com3VarE;
        StateListDrawable stateListDrawable = new StateListDrawable();
        this.f3727a = stateListDrawable;
        stateListDrawable.addState(new int[]{R.attr.state_above_anchor}, com3VarE);
        this.f3727a.addState(new int[0], com3VarE2);
        int i2 = ((d) this).f6824a;
        if (i2 == 0) {
            i2 = f9652c ? a4.f8871d : a4.f8872e;
        }
        ((d) this).f958a.setEndIconDrawable(i2);
        TextInputLayout textInputLayout = ((d) this).f958a;
        textInputLayout.setEndIconContentDescription(textInputLayout.getResources().getText(f4.f8936g));
        ((d) this).f958a.setEndIconOnClickListener(new com7());
        ((d) this).f958a.g(this.f3734a);
        ((d) this).f958a.h(this.f3735a);
        F();
        this.f3731a = (AccessibilityManager) ((d) this).f956a.getSystemService("accessibility");
        ((d) this).f958a.addOnAttachStateChangeListener(this.f3729a);
        B();
    }

    @Override // p033LPt1.d
    public boolean b(int i2) {
        return i2 != 0;
    }

    @Override // p033LPt1.d
    public boolean d() {
        return true;
    }

    public final void y(AutoCompleteTextView autoCompleteTextView) {
        if (H(autoCompleteTextView)) {
            return;
        }
        int boxBackgroundMode = ((d) this).f958a.getBoxBackgroundMode();
        COM9.com3 boxBackground = ((d) this).f958a.getBoxBackground();
        int iD = p030Com8.prn.d(autoCompleteTextView, x3.f9034i);
        int[][] iArr = {new int[]{R.attr.state_pressed}, new int[0]};
        if (boxBackgroundMode == 2) {
            A(autoCompleteTextView, iD, iArr, boxBackground);
        } else if (boxBackgroundMode == 1) {
            z(autoCompleteTextView, iD, iArr, boxBackground);
        }
    }

    public final void z(AutoCompleteTextView autoCompleteTextView, int i2, int[][] iArr, COM9.com3 com3Var) {
        int boxBackgroundColor = ((d) this).f958a.getBoxBackgroundColor();
        int[] iArr2 = {p030Com8.prn.h(i2, boxBackgroundColor, 0.1f), boxBackgroundColor};
        if (f9652c) {
            y.s0(autoCompleteTextView, new RippleDrawable(new ColorStateList(iArr, iArr2), com3Var, com3Var));
            return;
        }
        COM9.com3 com3Var2 = new COM9.com3(com3Var.D());
        com3Var2.Y(new ColorStateList(iArr, iArr2));
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{com3Var, com3Var2});
        int iF = y.F(autoCompleteTextView);
        int paddingTop = autoCompleteTextView.getPaddingTop();
        int iE = y.E(autoCompleteTextView);
        int paddingBottom = autoCompleteTextView.getPaddingBottom();
        y.s0(autoCompleteTextView, layerDrawable);
        y.C0(autoCompleteTextView, iF, paddingTop, iE, paddingBottom);
    }
}
