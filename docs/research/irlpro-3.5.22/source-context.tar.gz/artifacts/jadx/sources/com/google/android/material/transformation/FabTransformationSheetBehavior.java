package com.google.android.material.transformation;

import COM6.com4;
import COM6.com6;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.HashMap;
import java.util.Map;
import p024Com2.y;
import p075cOM6.w3;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public class FabTransformationSheetBehavior extends FabTransformationBehavior {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Map<View, Integer> f9738a;

    public FabTransformationSheetBehavior() {
    }

    @Override // com.google.android.material.transformation.ExpandableTransformationBehavior, com.google.android.material.transformation.ExpandableBehavior
    public boolean H(View view, View view2, boolean z2, boolean z3) {
        g0(view2, z2);
        return super.H(view, view2, z2, z3);
    }

    @Override // com.google.android.material.transformation.FabTransformationBehavior
    public FabTransformationBehavior.com1 e0(Context context, boolean z2) {
        int i2 = z2 ? w3.f9025d : w3.f9024c;
        FabTransformationBehavior.com1 com1Var = new FabTransformationBehavior.com1();
        com1Var.f9730a = com4.c(context, i2);
        com1Var.f3819a = new com6(17, 0.0f, 0.0f);
        return com1Var;
    }

    public final void g0(View view, boolean z2) {
        ViewParent parent = view.getParent();
        if (parent instanceof CoordinatorLayout) {
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
            int childCount = coordinatorLayout.getChildCount();
            if (z2) {
                this.f9738a = new HashMap(childCount);
            }
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                boolean z3 = (childAt.getLayoutParams() instanceof CoordinatorLayout.com2) && (((CoordinatorLayout.com2) childAt.getLayoutParams()).f() instanceof FabTransformationScrimBehavior);
                if (childAt != view && !z3) {
                    if (z2) {
                        this.f9738a.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                        y.y0(childAt, 4);
                    } else {
                        Map<View, Integer> map = this.f9738a;
                        if (map != null && map.containsKey(childAt)) {
                            y.y0(childAt, this.f9738a.get(childAt).intValue());
                        }
                    }
                }
            }
            if (z2) {
                return;
            }
            this.f9738a = null;
        }
    }

    public FabTransformationSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }
}
