package LPT5;

import android.content.Context;
import app.irlpro.android.R;

/* JADX INFO: loaded from: classes.dex */
public class com6 extends prn {
    public com6(Context context) {
        super(context);
    }

    @Override // LPT5.prn
    public void g(long j2, long j3) {
        e(this.f6676c);
    }

    @Override // LPT5.prn
    public String j() {
        return ((prn) this).f879a.getString(R.string.adaptive_bitrate_off);
    }
}
