package a0;

import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.instrumentation.okhttp3.OkHttp3Instrumentation;
import com.newrelic.agent.android.util.Constants;
import d0.lpt1;
import f.com8;
import f.com9;
import i0.BufferedSource;
import i0.com7;
import java.io.IOException;
import java.lang.ref.Reference;
import java.net.ConnectException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownServiceException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import p127lPt9.w;
import v.c;
import v.d;
import v.e;
import v.g;
import v.h;
import v.i;
import v.lpt5;
import v.lpt7;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class com2 extends d0.com2.nul implements v.com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f7603a = new aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f1562a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f1563a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com3 f1564a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public d0.com2 f1565a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public BufferedSource f1566a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public i0.nul f1567a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Socket f1568a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<Reference<com1>> f1569a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public d f1570a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final i f1571a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt7 f1572a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1573a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7604b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Socket f1574b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1575b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7605c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7606d;

    public static final class aux {
        public aux() {
        }

        public /* synthetic */ aux(f.com3 com3Var) {
            this();
        }
    }

    public /* synthetic */ class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f7607a;

        static {
            int[] iArr = new int[Proxy.Type.values().length];
            iArr[Proxy.Type.DIRECT.ordinal()] = 1;
            iArr[Proxy.Type.HTTP.ordinal()] = 2;
            f7607a = iArr;
        }
    }

    public static final class nul extends com9 implements e.aux<List<? extends Certificate>> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ v.aux f7608a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ v.com3 f1576a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ lpt7 f1577a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public nul(v.com3 com3Var, lpt7 lpt7Var, v.aux auxVar) {
            super(0);
            this.f1576a = com3Var;
            this.f1577a = lpt7Var;
            this.f7608a = auxVar;
        }

        @Override // e.aux
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final List<Certificate> f() {
            h0.nul nulVarD = this.f1576a.d();
            com8.b(nulVarD);
            return nulVarD.a(this.f1577a.d(), this.f7608a.l().h());
        }
    }

    public static final class prn extends com9 implements e.aux<List<? extends X509Certificate>> {
        public prn() {
            super(0);
        }

        @Override // e.aux
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public final List<X509Certificate> f() {
            lpt7 lpt7Var = com2.this.f1572a;
            com8.b(lpt7Var);
            List<Certificate> listD = lpt7Var.d();
            ArrayList arrayList = new ArrayList(w.n(listD, 10));
            Iterator<T> it = listD.iterator();
            while (it.hasNext()) {
                arrayList.add((X509Certificate) ((Certificate) it.next()));
            }
            return arrayList;
        }
    }

    public com2(com3 com3Var, i iVar) {
        com8.e(com3Var, "connectionPool");
        com8.e(iVar, "route");
        this.f1564a = com3Var;
        this.f1571a = iVar;
        this.f7606d = 1;
        this.f1569a = new ArrayList();
        this.f1563a = Long.MAX_VALUE;
    }

    public final boolean A(List<i> list) {
        if ((list instanceof Collection) && list.isEmpty()) {
            return false;
        }
        for (i iVar : list) {
            if (iVar.b().type() == Proxy.Type.DIRECT && this.f1571a.b().type() == Proxy.Type.DIRECT && com8.a(this.f1571a.d(), iVar.d())) {
                return true;
            }
        }
        return false;
    }

    public final void B(long j2) {
        this.f1563a = j2;
    }

    public final void C(boolean z2) {
        this.f1573a = z2;
    }

    public Socket D() {
        Socket socket = this.f1574b;
        com8.b(socket);
        return socket;
    }

    public final void E(int i2) throws IOException {
        Socket socket = this.f1574b;
        com8.b(socket);
        BufferedSource bufferedSource = this.f1566a;
        com8.b(bufferedSource);
        i0.nul nulVar = this.f1567a;
        com8.b(nulVar);
        socket.setSoTimeout(0);
        d0.com2 com2VarA = new d0.com2.aux(true, z.com1.f5476a).s(socket, this.f1571a.a().l().h(), bufferedSource, nulVar).k(this).l(i2).a();
        this.f1565a = com2VarA;
        this.f7606d = d0.com2.f10592a.a().d();
        d0.com2.y0(com2VarA, false, null, 3, null);
    }

    public final boolean F(lpt9 lpt9Var) {
        lpt7 lpt7Var;
        if (w.com1.f5458a && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + this);
        }
        lpt9 lpt9VarL = this.f1571a.a().l();
        if (lpt9Var.m() != lpt9VarL.m()) {
            return false;
        }
        if (com8.a(lpt9Var.h(), lpt9VarL.h())) {
            return true;
        }
        if (this.f1575b || (lpt7Var = this.f1572a) == null) {
            return false;
        }
        com8.b(lpt7Var);
        return e(lpt9Var, lpt7Var);
    }

    public final synchronized void G(com1 com1Var, IOException iOException) {
        com8.e(com1Var, "call");
        if (iOException instanceof lpt1) {
            if (((lpt1) iOException).f10675a == d0.con.REFUSED_STREAM) {
                int i2 = this.f7605c + 1;
                this.f7605c = i2;
                if (i2 > 1) {
                    this.f1573a = true;
                    this.f1562a++;
                }
            } else if (((lpt1) iOException).f10675a != d0.con.CANCEL || !com1Var.isCanceled()) {
                this.f1573a = true;
                this.f1562a++;
            }
        } else if (!v() || (iOException instanceof d0.aux)) {
            this.f1573a = true;
            if (this.f7604b == 0) {
                if (iOException != null) {
                    g(com1Var.j(), this.f1571a, iOException);
                }
                this.f1562a++;
            }
        }
    }

    @Override // d0.com2.nul
    public synchronized void a(d0.com2 com2Var, d0.com9 com9Var) {
        com8.e(com2Var, "connection");
        com8.e(com9Var, "settings");
        this.f7606d = com9Var.d();
    }

    @Override // d0.com2.nul
    public void b(d0.com5 com5Var) throws IOException {
        com8.e(com5Var, "stream");
        com5Var.d(d0.con.REFUSED_STREAM, null);
    }

    public final void d() {
        Socket socket = this.f1568a;
        if (socket == null) {
            return;
        }
        w.com1.n(socket);
    }

    public final boolean e(lpt9 lpt9Var, lpt7 lpt7Var) {
        List<Certificate> listD = lpt7Var.d();
        return (listD.isEmpty() ^ true) && h0.prn.f10749a.e(lpt9Var.h(), (X509Certificate) listD.get(0));
    }

    /* JADX WARN: Code duplicated, block: B:50:0x0109  */
    /* JADX WARN: Code duplicated, block: B:54:0x0111  */
    /* JADX WARN: Code duplicated, block: B:57:0x013b  */
    /* JADX WARN: Code duplicated, block: B:58:0x0141  */
    /* JADX WARN: Code duplicated, block: B:60:0x0146  */
    /* JADX WARN: Code duplicated, block: B:76:0x014e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:77:0x014e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:78:? A[LOOP:0: B:70:0x009a->B:78:?, LOOP_END, SYNTHETIC] */
    public final void f(int i2, int i3, int i4, int i5, boolean z2, v.com1 com1Var, lpt5 lpt5Var) throws Throwable {
        Socket socket;
        Socket socket2;
        com8.e(com1Var, "call");
        com8.e(lpt5Var, "eventListener");
        if (!(this.f1570a == null)) {
            throw new IllegalStateException("already connected".toString());
        }
        List<v.com8> listB = this.f1571a.a().b();
        a0.con conVar = new a0.con(listB);
        if (this.f1571a.a().k() == null) {
            if (!listB.contains(v.com8.f11846d)) {
                throw new com5(new UnknownServiceException("CLEARTEXT communication not enabled for client"));
            }
            String strH = this.f1571a.a().l().h();
            if (!e0.com6.f10703a.g().i(strH)) {
                throw new com5(new UnknownServiceException("CLEARTEXT communication to " + strH + " not permitted by network security policy"));
            }
        } else if (this.f1571a.a().f().contains(d.H2_PRIOR_KNOWLEDGE)) {
            throw new com5(new UnknownServiceException("H2_PRIOR_KNOWLEDGE cannot be used with HTTPS"));
        }
        com5 com5Var = null;
        while (true) {
            try {
                if (this.f1571a.c()) {
                    j(i2, i3, i4, com1Var, lpt5Var);
                    if (this.f1568a == null) {
                        break;
                    }
                } else {
                    try {
                        h(i2, i3, com1Var, lpt5Var);
                    } catch (IOException e2) {
                        e = e2;
                        socket = this.f1574b;
                        if (socket != null) {
                            w.com1.n(socket);
                        }
                        socket2 = this.f1568a;
                        if (socket2 != null) {
                            w.com1.n(socket2);
                        }
                        this.f1574b = null;
                        this.f1568a = null;
                        this.f1566a = null;
                        this.f1567a = null;
                        this.f1572a = null;
                        this.f1570a = null;
                        this.f1565a = null;
                        this.f7606d = 1;
                        lpt5Var.h(com1Var, this.f1571a.d(), this.f1571a.b(), null, e);
                        if (com5Var == null) {
                            com5Var = new com5(e);
                        } else {
                            com5Var.a(e);
                        }
                        if (z2) {
                            throw com5Var;
                        }
                        if (conVar.b(e)) {
                            throw com5Var;
                        }
                    }
                }
                try {
                    m(conVar, i5, com1Var, lpt5Var);
                    lpt5Var.g(com1Var, this.f1571a.d(), this.f1571a.b(), this.f1570a);
                    break;
                } catch (IOException e3) {
                    e = e3;
                    socket = this.f1574b;
                    if (socket != null) {
                        w.com1.n(socket);
                    }
                    socket2 = this.f1568a;
                    if (socket2 != null) {
                        w.com1.n(socket2);
                    }
                    this.f1574b = null;
                    this.f1568a = null;
                    this.f1566a = null;
                    this.f1567a = null;
                    this.f1572a = null;
                    this.f1570a = null;
                    this.f1565a = null;
                    this.f7606d = 1;
                    lpt5Var.h(com1Var, this.f1571a.d(), this.f1571a.b(), null, e);
                    if (com5Var == null) {
                        com5Var = new com5(e);
                    } else {
                        com5Var.a(e);
                    }
                    if (z2) {
                        throw com5Var;
                    }
                    if (conVar.b(e)) {
                        throw com5Var;
                    }
                }
            } catch (IOException e4) {
                e = e4;
            }
        }
        if (this.f1571a.c() && this.f1568a == null) {
            throw new com5(new ProtocolException("Too many tunnel connections attempted: 21"));
        }
        this.f1563a = System.nanoTime();
    }

    public final void g(c cVar, i iVar, IOException iOException) {
        com8.e(cVar, "client");
        com8.e(iVar, "failedRoute");
        com8.e(iOException, "failure");
        if (iVar.b().type() != Proxy.Type.DIRECT) {
            v.aux auxVarA = iVar.a();
            auxVarA.i().connectFailed(auxVarA.l().r(), iVar.b().address(), iOException);
        }
        cVar.p().b(iVar);
    }

    public final void h(int i2, int i3, v.com1 com1Var, lpt5 lpt5Var) throws IOException {
        Socket socketCreateSocket;
        Proxy proxyB = this.f1571a.b();
        v.aux auxVarA = this.f1571a.a();
        Proxy.Type type = proxyB.type();
        int i4 = type == null ? -1 : con.f7607a[type.ordinal()];
        if (i4 == 1 || i4 == 2) {
            socketCreateSocket = auxVarA.j().createSocket();
            com8.b(socketCreateSocket);
        } else {
            socketCreateSocket = new Socket(proxyB);
        }
        this.f1568a = socketCreateSocket;
        lpt5Var.i(com1Var, this.f1571a.d(), proxyB);
        socketCreateSocket.setSoTimeout(i3);
        try {
            e0.com6.f10703a.g().f(socketCreateSocket, this.f1571a.d(), i2);
            try {
                this.f1566a = com7.b(com7.f(socketCreateSocket));
                this.f1567a = com7.a(com7.d(socketCreateSocket));
            } catch (NullPointerException e2) {
                if (com8.a(e2.getMessage(), "throw with null exception")) {
                    throw new IOException(e2);
                }
            }
        } catch (ConnectException e3) {
            ConnectException connectException = new ConnectException(com8.k("Failed to connect to ", this.f1571a.d()));
            connectException.initCause(e3);
            throw connectException;
        }
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void i(a0.con conVar) throws Throwable {
        v.aux auxVarA = this.f1571a.a();
        SSLSocketFactory sSLSocketFactoryK = auxVarA.k();
        SSLSocket sSLSocket = null;
        try {
            com8.b(sSLSocketFactoryK);
            Socket socketCreateSocket = sSLSocketFactoryK.createSocket(this.f1568a, auxVarA.l().h(), auxVarA.l().m(), true);
            if (socketCreateSocket == null) {
                throw new NullPointerException("null cannot be cast to non-null type javax.net.ssl.SSLSocket");
            }
            SSLSocket sSLSocket2 = (SSLSocket) socketCreateSocket;
            try {
                v.com8 com8VarA = conVar.a(sSLSocket2);
                if (com8VarA.h()) {
                    e0.com6.f10703a.g().e(sSLSocket2, auxVarA.l().h(), auxVarA.f());
                }
                sSLSocket2.startHandshake();
                SSLSession session = sSLSocket2.getSession();
                lpt7.aux auxVar = lpt7.f11892a;
                com8.d(session, "sslSocketSession");
                lpt7 lpt7VarA = auxVar.a(session);
                HostnameVerifier hostnameVerifierE = auxVarA.e();
                com8.b(hostnameVerifierE);
                if (hostnameVerifierE.verify(auxVarA.l().h(), session)) {
                    v.com3 com3VarA = auxVarA.a();
                    com8.b(com3VarA);
                    this.f1572a = new lpt7(lpt7VarA.e(), lpt7VarA.a(), lpt7VarA.c(), new nul(com3VarA, lpt7VarA, auxVarA));
                    com3VarA.b(auxVarA.l().h(), new prn());
                    String strG = com8VarA.h() ? e0.com6.f10703a.g().g(sSLSocket2) : null;
                    this.f1574b = sSLSocket2;
                    this.f1566a = com7.b(com7.f(sSLSocket2));
                    this.f1567a = com7.a(com7.d(sSLSocket2));
                    this.f1570a = strG != null ? d.f11856a.a(strG) : d.HTTP_1_1;
                    e0.com6.f10703a.g().b(sSLSocket2);
                    return;
                }
                List<Certificate> listD = lpt7VarA.d();
                if (!(!listD.isEmpty())) {
                    throw new SSLPeerUnverifiedException("Hostname " + auxVarA.l().h() + " not verified (no certificates)");
                }
                X509Certificate x509Certificate = (X509Certificate) listD.get(0);
                throw new SSLPeerUnverifiedException(m.com3.h("\n              |Hostname " + auxVarA.l().h() + " not verified:\n              |    certificate: " + v.com3.f11795a.a(x509Certificate) + "\n              |    DN: " + ((Object) x509Certificate.getSubjectDN().getName()) + "\n              |    subjectAltNames: " + h0.prn.f10749a.a(x509Certificate) + "\n              ", null, 1, null));
            } catch (Throwable th) {
                th = th;
                sSLSocket = sSLSocket2;
                if (sSLSocket != null) {
                    e0.com6.f10703a.g().b(sSLSocket);
                }
                if (sSLSocket != null) {
                    w.com1.n(sSLSocket);
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    public final void j(int i2, int i3, int i4, v.com1 com1Var, lpt5 lpt5Var) throws IOException {
        e eVarL = l();
        lpt9 lpt9VarI = eVarL.i();
        int i5 = 0;
        while (i5 < 21) {
            i5++;
            h(i2, i3, com1Var, lpt5Var);
            eVarL = k(i3, i4, eVarL, lpt9VarI);
            if (eVarL == null) {
                return;
            }
            Socket socket = this.f1568a;
            if (socket != null) {
                w.com1.n(socket);
            }
            this.f1568a = null;
            this.f1567a = null;
            this.f1566a = null;
            lpt5Var.g(com1Var, this.f1571a.d(), this.f1571a.b(), null);
        }
    }

    public final e k(int i2, int i3, e eVar, lpt9 lpt9Var) throws IOException {
        String str = "CONNECT " + w.com1.Q(lpt9Var, true) + " HTTP/1.1";
        while (true) {
            BufferedSource bufferedSource = this.f1566a;
            com8.b(bufferedSource);
            i0.nul nulVar = this.f1567a;
            com8.b(nulVar);
            c0.con conVar = new c0.con(null, this, bufferedSource, nulVar);
            TimeUnit timeUnit = TimeUnit.MILLISECONDS;
            bufferedSource.timeout().g(i2, timeUnit);
            nulVar.timeout().g(i3, timeUnit);
            conVar.A(eVar.e(), str);
            conVar.a();
            g.aux auxVarG = conVar.g(false);
            com8.b(auxVarG);
            g gVarBuild = auxVarG.request(eVar).build();
            conVar.z(gVarBuild);
            int iL = gVarBuild.l();
            if (iL == 200) {
                if (bufferedSource.b().K() && nulVar.b().K()) {
                    return null;
                }
                throw new IOException("TLS tunnel buffered too many bytes!");
            }
            if (iL != 407) {
                throw new IOException(com8.k("Unexpected response code for CONNECT: ", Integer.valueOf(gVarBuild.l())));
            }
            e eVarA = this.f1571a.a().h().a(this.f1571a, gVarBuild);
            if (eVarA == null) {
                throw new IOException("Failed to authenticate with proxy");
            }
            if (m.lpt1.q("close", g.y(gVarBuild, "Connection", null, 2, null), true)) {
                return eVarA;
            }
            eVar = eVarA;
        }
    }

    public final e l() throws IOException {
        e.aux auxVarD = new e.aux().m(this.f1571a.a().l()).f("CONNECT", null).d(Constants.Network.HOST_HEADER, w.com1.Q(this.f1571a.a().l(), true)).d("Proxy-Connection", "Keep-Alive").d(Constants.Network.USER_AGENT_HEADER, "okhttp/4.10.0");
        e eVarB = !(auxVarD instanceof e.aux) ? auxVarD.b() : OkHttp3Instrumentation.build(auxVarD);
        g.aux auxVarMessage = new g.aux().request(eVarB).protocol(d.HTTP_1_1).code(407).message("Preemptive Authenticate");
        h hVar = w.com1.f5456a;
        e eVarA = this.f1571a.a().h().a(this.f1571a, (!(auxVarMessage instanceof g.aux) ? auxVarMessage.body(hVar) : OkHttp3Instrumentation.body(auxVarMessage, hVar)).sentRequestAtMillis(-1L).receivedResponseAtMillis(-1L).header("Proxy-Authenticate", "OkHttp-Preemptive").build());
        return eVarA == null ? eVarB : eVarA;
    }

    public final void m(a0.con conVar, int i2, v.com1 com1Var, lpt5 lpt5Var) throws Throwable {
        if (this.f1571a.a().k() != null) {
            lpt5Var.B(com1Var);
            i(conVar);
            lpt5Var.A(com1Var, this.f1572a);
            if (this.f1570a == d.HTTP_2) {
                E(i2);
                return;
            }
            return;
        }
        List<d> listF = this.f1571a.a().f();
        d dVar = d.H2_PRIOR_KNOWLEDGE;
        if (!listF.contains(dVar)) {
            this.f1574b = this.f1568a;
            this.f1570a = d.HTTP_1_1;
        } else {
            this.f1574b = this.f1568a;
            this.f1570a = dVar;
            E(i2);
        }
    }

    public final List<Reference<com1>> n() {
        return this.f1569a;
    }

    public final long o() {
        return this.f1563a;
    }

    public final boolean p() {
        return this.f1573a;
    }

    public final int q() {
        return this.f1562a;
    }

    public lpt7 r() {
        return this.f1572a;
    }

    public final synchronized void s() {
        this.f7604b++;
    }

    public final boolean t(v.aux auxVar, List<i> list) {
        com8.e(auxVar, "address");
        if (w.com1.f5458a && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + this);
        }
        if (this.f1569a.size() >= this.f7606d || this.f1573a || !this.f1571a.a().d(auxVar)) {
            return false;
        }
        if (com8.a(auxVar.l().h(), z().a().l().h())) {
            return true;
        }
        if (this.f1565a == null || list == null || !A(list) || auxVar.e() != h0.prn.f10749a || !F(auxVar.l())) {
            return false;
        }
        try {
            v.com3 com3VarA = auxVar.a();
            com8.b(com3VarA);
            String strH = auxVar.l().h();
            lpt7 lpt7VarR = r();
            com8.b(lpt7VarR);
            com3VarA.a(strH, lpt7VarR.d());
            return true;
        } catch (SSLPeerUnverifiedException unused) {
            return false;
        }
    }

    public String toString() {
        v.com5 com5VarA;
        StringBuilder sb = new StringBuilder();
        sb.append("Connection{");
        sb.append(this.f1571a.a().l().h());
        sb.append(':');
        sb.append(this.f1571a.a().l().m());
        sb.append(", proxy=");
        sb.append(this.f1571a.b());
        sb.append(" hostAddress=");
        sb.append(this.f1571a.d());
        sb.append(" cipherSuite=");
        lpt7 lpt7Var = this.f1572a;
        Object obj = "none";
        if (lpt7Var != null && (com5VarA = lpt7Var.a()) != null) {
            obj = com5VarA;
        }
        sb.append(obj);
        sb.append(" protocol=");
        sb.append(this.f1570a);
        sb.append('}');
        return sb.toString();
    }

    public final boolean u(boolean z2) {
        long jO;
        if (w.com1.f5458a && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST NOT hold lock on " + this);
        }
        long jNanoTime = System.nanoTime();
        Socket socket = this.f1568a;
        com8.b(socket);
        Socket socket2 = this.f1574b;
        com8.b(socket2);
        BufferedSource bufferedSource = this.f1566a;
        com8.b(bufferedSource);
        if (socket.isClosed() || socket2.isClosed() || socket2.isInputShutdown() || socket2.isOutputShutdown()) {
            return false;
        }
        d0.com2 com2Var = this.f1565a;
        if (com2Var != null) {
            return com2Var.j0(jNanoTime);
        }
        synchronized (this) {
            jO = jNanoTime - o();
        }
        if (jO < 10000000000L || !z2) {
            return true;
        }
        return w.com1.F(socket2, bufferedSource);
    }

    public final boolean v() {
        return this.f1565a != null;
    }

    public final b0.prn w(c cVar, b0.com3 com3Var) throws SocketException {
        com8.e(cVar, "client");
        com8.e(com3Var, "chain");
        Socket socket = this.f1574b;
        com8.b(socket);
        BufferedSource bufferedSource = this.f1566a;
        com8.b(bufferedSource);
        i0.nul nulVar = this.f1567a;
        com8.b(nulVar);
        d0.com2 com2Var = this.f1565a;
        if (com2Var != null) {
            return new d0.com3(cVar, this, com3Var, com2Var);
        }
        socket.setSoTimeout(com3Var.k());
        i0.c cVarTimeout = bufferedSource.timeout();
        long jH = com3Var.h();
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        cVarTimeout.g(jH, timeUnit);
        nulVar.timeout().g(com3Var.j(), timeUnit);
        return new c0.con(cVar, this, bufferedSource, nulVar);
    }

    public final synchronized void x() {
        this.f1575b = true;
    }

    public final synchronized void y() {
        this.f1573a = true;
    }

    public i z() {
        return this.f1571a;
    }
}
