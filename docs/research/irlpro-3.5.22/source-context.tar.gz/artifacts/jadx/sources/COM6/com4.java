package COM6;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import p147nUl.d0;

/* JADX INFO: loaded from: classes.dex */
public class com4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d0<String, com5> f5709a = new d0<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d0<String, PropertyValuesHolder[]> f5710b = new d0<>();

    public static void a(com4 com4Var, Animator animator) {
        if (animator instanceof ObjectAnimator) {
            ObjectAnimator objectAnimator = (ObjectAnimator) animator;
            com4Var.h(objectAnimator.getPropertyName(), objectAnimator.getValues());
            com4Var.i(objectAnimator.getPropertyName(), com5.b(objectAnimator));
        } else {
            throw new IllegalArgumentException("Animator must be an ObjectAnimator: " + animator);
        }
    }

    public static com4 b(Context context, TypedArray typedArray, int i2) {
        int resourceId;
        if (!typedArray.hasValue(i2) || (resourceId = typedArray.getResourceId(i2, 0)) == 0) {
            return null;
        }
        return c(context, resourceId);
    }

    public static com4 c(Context context, int i2) {
        try {
            Animator animatorLoadAnimator = AnimatorInflater.loadAnimator(context, i2);
            if (animatorLoadAnimator instanceof AnimatorSet) {
                return d(((AnimatorSet) animatorLoadAnimator).getChildAnimations());
            }
            if (animatorLoadAnimator == null) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            arrayList.add(animatorLoadAnimator);
            return d(arrayList);
        } catch (Exception e2) {
            Log.w("MotionSpec", "Can't load animation resource ID #0x" + Integer.toHexString(i2), e2);
            return null;
        }
    }

    public static com4 d(List<Animator> list) {
        com4 com4Var = new com4();
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            a(com4Var, list.get(i2));
        }
        return com4Var;
    }

    public com5 e(String str) {
        if (g(str)) {
            return this.f5709a.get(str);
        }
        throw new IllegalArgumentException();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof com4) {
            return this.f5709a.equals(((com4) obj).f5709a);
        }
        return false;
    }

    public long f() {
        int size = this.f5709a.size();
        long jMax = 0;
        for (int i2 = 0; i2 < size; i2++) {
            com5 com5VarM = this.f5709a.m(i2);
            jMax = Math.max(jMax, com5VarM.c() + com5VarM.d());
        }
        return jMax;
    }

    public boolean g(String str) {
        return this.f5709a.get(str) != null;
    }

    public void h(String str, PropertyValuesHolder[] propertyValuesHolderArr) {
        this.f5710b.put(str, propertyValuesHolderArr);
    }

    public int hashCode() {
        return this.f5709a.hashCode();
    }

    public void i(String str, com5 com5Var) {
        this.f5709a.put(str, com5Var);
    }

    public String toString() {
        return '\n' + getClass().getName() + '{' + Integer.toHexString(System.identityHashCode(this)) + " timings: " + this.f5709a + "}\n";
    }
}
