package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.Arrays;
import p081cOm2.e2;

/* JADX INFO: loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f8501a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SparseIntArray f2682a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f2683a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View[] f2684a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final SparseIntArray f8502b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int[] f2685b;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8503j;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f8504m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f8505n;

    public static final class aux extends nul {
        @Override // androidx.recyclerview.widget.GridLayoutManager.nul
        public int e(int i2, int i3) {
            return i2 % i3;
        }

        @Override // androidx.recyclerview.widget.GridLayoutManager.nul
        public int f(int i2) {
            return 1;
        }
    }

    public static abstract class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final SparseIntArray f8508a = new SparseIntArray();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final SparseIntArray f8509b = new SparseIntArray();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2686a = false;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2687b = false;

        public static int a(SparseIntArray sparseIntArray, int i2) {
            int size = sparseIntArray.size() - 1;
            int i3 = 0;
            while (i3 <= size) {
                int i4 = (i3 + size) >>> 1;
                if (sparseIntArray.keyAt(i4) < i2) {
                    i3 = i4 + 1;
                } else {
                    size = i4 - 1;
                }
            }
            int i5 = i3 - 1;
            if (i5 < 0 || i5 >= sparseIntArray.size()) {
                return -1;
            }
            return sparseIntArray.keyAt(i5);
        }

        public int b(int i2, int i3) {
            if (!this.f2687b) {
                return d(i2, i3);
            }
            int i4 = this.f8509b.get(i2, -1);
            if (i4 != -1) {
                return i4;
            }
            int iD = d(i2, i3);
            this.f8509b.put(i2, iD);
            return iD;
        }

        public int c(int i2, int i3) {
            if (!this.f2686a) {
                return e(i2, i3);
            }
            int i4 = this.f8508a.get(i2, -1);
            if (i4 != -1) {
                return i4;
            }
            int iE = e(i2, i3);
            this.f8508a.put(i2, iE);
            return iE;
        }

        public int d(int i2, int i3) {
            int i4;
            int i5;
            int iC;
            int iA;
            if (!this.f2687b || (iA = a(this.f8509b, i2)) == -1) {
                i4 = 0;
                i5 = 0;
                iC = 0;
            } else {
                i4 = this.f8509b.get(iA);
                i5 = iA + 1;
                iC = c(iA, i3) + f(iA);
                if (iC == i3) {
                    i4++;
                    iC = 0;
                }
            }
            int iF = f(i2);
            while (i5 < i2) {
                int iF2 = f(i5);
                iC += iF2;
                if (iC == i3) {
                    i4++;
                    iC = 0;
                } else if (iC > i3) {
                    i4++;
                    iC = iF2;
                }
                i5++;
            }
            return iC + iF > i3 ? i4 + 1 : i4;
        }

        public abstract int e(int i2, int i3);

        public abstract int f(int i2);

        public void g() {
            this.f8509b.clear();
        }

        public void h() {
            this.f8508a.clear();
        }
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f8504m = false;
        this.f8503j = -1;
        this.f2682a = new SparseIntArray();
        this.f8502b = new SparseIntArray();
        this.f2683a = new aux();
        this.f8501a = new Rect();
        e3(RecyclerView.lpt2.i0(context, attributeSet, i2, i3).f8609b);
    }

    public static int[] Q2(int[] iArr, int i2, int i3) {
        int i4;
        if (iArr == null || iArr.length != i2 + 1 || iArr[iArr.length - 1] != i3) {
            iArr = new int[i2 + 1];
        }
        int i5 = 0;
        iArr[0] = 0;
        int i6 = i3 / i2;
        int i7 = i3 % i2;
        int i8 = 0;
        for (int i9 = 1; i9 <= i2; i9++) {
            i5 += i7;
            if (i5 <= 0 || i2 - i5 >= i7) {
                i4 = i6;
            } else {
                i4 = i6 + 1;
                i5 -= i2;
            }
            i8 += i4;
            iArr[i9] = i8;
        }
        return iArr;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void C1(Rect rect, int i2, int i3) {
        int iN;
        int iN2;
        if (this.f2685b == null) {
            super.C1(rect, i2, i3);
        }
        int iE0 = e0() + f0();
        int iG0 = g0() + d0();
        if (((LinearLayoutManager) this).f8511f == 1) {
            iN2 = RecyclerView.lpt2.n(i3, rect.height() + iG0, b0());
            int[] iArr = this.f2685b;
            iN = RecyclerView.lpt2.n(i2, iArr[iArr.length - 1] + iE0, c0());
        } else {
            iN = RecyclerView.lpt2.n(i2, rect.width() + iE0, c0());
            int[] iArr2 = this.f2685b;
            iN2 = RecyclerView.lpt2.n(i3, iArr2[iArr2.length - 1] + iG0, b0());
        }
        B1(iN, iN2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 D() {
        return ((LinearLayoutManager) this).f8511f == 0 ? new con(-2, -1) : new con(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 E(Context context, AttributeSet attributeSet) {
        return new con(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void E2(boolean z2) {
        if (z2) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.E2(false);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 F(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new con((ViewGroup.MarginLayoutParams) layoutParams) : new con(layoutParams);
    }

    /* JADX WARN: Code duplicated, block: B:79:0x0107  */
    /* JADX WARN: Code duplicated, block: B:81:0x010d  */
    /* JADX WARN: Code duplicated, block: B:82:0x0123  */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x00d6, code lost:
    
        if (r13 == (r2 > r15)) goto L49;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public View J0(View view, int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        int iJ;
        int i3;
        int iJ2;
        View view2;
        View view3;
        int i4;
        int i5;
        boolean z2;
        int i6;
        int i7;
        RecyclerView.lpt9 lpt9Var2 = lpt9Var;
        RecyclerView.e eVar2 = eVar;
        View viewB = B(view);
        View view4 = null;
        if (viewB == null) {
            return null;
        }
        con conVar = (con) viewB.getLayoutParams();
        int i8 = conVar.f8506a;
        int i9 = conVar.f8507b + i8;
        if (super.J0(view, i2, lpt9Var, eVar) == null) {
            return null;
        }
        if ((R1(i2) == 1) != ((LinearLayoutManager) this).f2695i) {
            iJ2 = J() - 1;
            iJ = -1;
            i3 = -1;
        } else {
            iJ = J();
            i3 = 1;
            iJ2 = 0;
        }
        boolean z3 = ((LinearLayoutManager) this).f8511f == 1 && q2();
        int iY2 = Y2(lpt9Var2, eVar2, iJ2);
        int i10 = -1;
        int i11 = -1;
        int iMin = 0;
        int iMin2 = 0;
        int i12 = iJ2;
        View view5 = null;
        while (i12 != iJ) {
            int iY3 = Y2(lpt9Var2, eVar2, i12);
            View viewI = I(i12);
            if (viewI == viewB) {
                break;
            }
            if (!viewI.hasFocusable() || iY3 == iY2) {
                con conVar2 = (con) viewI.getLayoutParams();
                int i13 = conVar2.f8506a;
                view2 = viewB;
                int i14 = conVar2.f8507b + i13;
                if (viewI.hasFocusable() && i13 == i8 && i14 == i9) {
                    return viewI;
                }
                if (!(viewI.hasFocusable() && view4 == null) && (viewI.hasFocusable() || view5 != null)) {
                    view3 = view5;
                    int iMin3 = Math.min(i14, i9) - Math.max(i13, i8);
                    if (!viewI.hasFocusable()) {
                        if (view4 == null) {
                            i4 = iMin;
                            i5 = iJ;
                            z2 = true;
                            if (y0(viewI, false, true)) {
                                i6 = iMin2;
                                if (iMin3 > i6) {
                                    i7 = i11;
                                } else if (iMin3 == i6) {
                                    i7 = i11;
                                    if (z3 == (i13 > i7)) {
                                        z2 = true;
                                    }
                                } else {
                                    i7 = i11;
                                }
                                if (z2) {
                                    if (viewI.hasFocusable()) {
                                        i10 = conVar2.f8506a;
                                        i11 = i7;
                                        iMin2 = i6;
                                        view5 = view3;
                                        view4 = viewI;
                                        iMin = Math.min(i14, i9) - Math.max(i13, i8);
                                    } else {
                                        int i15 = conVar2.f8506a;
                                        iMin2 = Math.min(i14, i9) - Math.max(i13, i8);
                                        i11 = i15;
                                        iMin = i4;
                                        view5 = viewI;
                                    }
                                }
                                i12 += i3;
                                lpt9Var2 = lpt9Var;
                                eVar2 = eVar;
                                viewB = view2;
                                iJ = i5;
                            }
                            z2 = false;
                            if (z2) {
                                if (viewI.hasFocusable()) {
                                    i10 = conVar2.f8506a;
                                    i11 = i7;
                                    iMin2 = i6;
                                    view5 = view3;
                                    view4 = viewI;
                                    iMin = Math.min(i14, i9) - Math.max(i13, i8);
                                } else {
                                    int i16 = conVar2.f8506a;
                                    iMin2 = Math.min(i14, i9) - Math.max(i13, i8);
                                    i11 = i16;
                                    iMin = i4;
                                    view5 = viewI;
                                }
                            }
                            i12 += i3;
                            lpt9Var2 = lpt9Var;
                            eVar2 = eVar;
                            viewB = view2;
                            iJ = i5;
                        }
                        i7 = i11;
                        i6 = iMin2;
                        z2 = false;
                        if (z2) {
                            if (viewI.hasFocusable()) {
                                i10 = conVar2.f8506a;
                                i11 = i7;
                                iMin2 = i6;
                                view5 = view3;
                                view4 = viewI;
                                iMin = Math.min(i14, i9) - Math.max(i13, i8);
                            } else {
                                int i17 = conVar2.f8506a;
                                iMin2 = Math.min(i14, i9) - Math.max(i13, i8);
                                i11 = i17;
                                iMin = i4;
                                view5 = viewI;
                            }
                        }
                        i12 += i3;
                        lpt9Var2 = lpt9Var;
                        eVar2 = eVar;
                        viewB = view2;
                        iJ = i5;
                    } else if (iMin3 <= iMin) {
                        if (iMin3 == iMin) {
                        }
                    }
                    i4 = iMin;
                    i5 = iJ;
                    i7 = i11;
                    i6 = iMin2;
                    z2 = false;
                    if (z2) {
                        if (viewI.hasFocusable()) {
                            i10 = conVar2.f8506a;
                            i11 = i7;
                            iMin2 = i6;
                            view5 = view3;
                            view4 = viewI;
                            iMin = Math.min(i14, i9) - Math.max(i13, i8);
                        } else {
                            int i18 = conVar2.f8506a;
                            iMin2 = Math.min(i14, i9) - Math.max(i13, i8);
                            i11 = i18;
                            iMin = i4;
                            view5 = viewI;
                        }
                    }
                    i12 += i3;
                    lpt9Var2 = lpt9Var;
                    eVar2 = eVar;
                    viewB = view2;
                    iJ = i5;
                } else {
                    view3 = view5;
                }
                i4 = iMin;
                i5 = iJ;
                i7 = i11;
                i6 = iMin2;
                z2 = true;
                if (z2) {
                    if (viewI.hasFocusable()) {
                        i10 = conVar2.f8506a;
                        i11 = i7;
                        iMin2 = i6;
                        view5 = view3;
                        view4 = viewI;
                        iMin = Math.min(i14, i9) - Math.max(i13, i8);
                    } else {
                        int i19 = conVar2.f8506a;
                        iMin2 = Math.min(i14, i9) - Math.max(i13, i8);
                        i11 = i19;
                        iMin = i4;
                        view5 = viewI;
                    }
                }
                i12 += i3;
                lpt9Var2 = lpt9Var;
                eVar2 = eVar;
                viewB = view2;
                iJ = i5;
            } else {
                if (view4 != null) {
                    break;
                }
                view2 = viewB;
                view3 = view5;
                i4 = iMin;
                i5 = iJ;
                i7 = i11;
                i6 = iMin2;
            }
            i11 = i7;
            iMin2 = i6;
            iMin = i4;
            view5 = view3;
            i12 += i3;
            lpt9Var2 = lpt9Var;
            eVar2 = eVar;
            viewB = view2;
            iJ = i5;
        }
        return view4 != null ? view4 : view5;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean L1() {
        return ((LinearLayoutManager) this).f2690a == null && !this.f8504m;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int N(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (((LinearLayoutManager) this).f8511f == 1) {
            return this.f8503j;
        }
        if (eVar.b() < 1) {
            return 0;
        }
        return Y2(lpt9Var, eVar, eVar.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void N1(RecyclerView.e eVar, LinearLayoutManager.nul nulVar, RecyclerView.lpt2.nul nulVar2) {
        int iF = this.f8503j;
        for (int i2 = 0; i2 < this.f8503j && nulVar.c(eVar) && iF > 0; i2++) {
            int i3 = nulVar.f8525c;
            nulVar2.a(i3, Math.max(0, nulVar.f8528f));
            iF -= this.f2683a.f(i3);
            nulVar.f8525c += nulVar.f8526d;
        }
    }

    public final void N2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2, boolean z2) {
        int i3;
        int i4;
        int i5;
        int i6 = 0;
        if (z2) {
            i5 = 1;
            i4 = i2;
            i3 = 0;
        } else {
            i3 = i2 - 1;
            i4 = -1;
            i5 = -1;
        }
        while (i3 != i4) {
            View view = this.f2684a[i3];
            con conVar = (con) view.getLayoutParams();
            int iA3 = a3(lpt9Var, eVar, h0(view));
            conVar.f8507b = iA3;
            conVar.f8506a = i6;
            i6 += iA3;
            i3 += i5;
        }
    }

    public final void O2() {
        int iJ = J();
        for (int i2 = 0; i2 < iJ; i2++) {
            con conVar = (con) I(i2).getLayoutParams();
            int iA = conVar.a();
            this.f2682a.put(iA, conVar.f());
            this.f8502b.put(iA, conVar.e());
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void P0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, View view, e2 e2Var) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof con)) {
            super.O0(view, e2Var);
            return;
        }
        con conVar = (con) layoutParams;
        int iY2 = Y2(lpt9Var, eVar, conVar.a());
        if (((LinearLayoutManager) this).f8511f == 0) {
            e2Var.W(e2.nul.a(conVar.e(), conVar.f(), iY2, 1, false, false));
        } else {
            e2Var.W(e2.nul.a(iY2, 1, conVar.e(), conVar.f(), false, false));
        }
    }

    public final void P2(int i2) {
        this.f2685b = Q2(this.f2685b, this.f8503j, i2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void R0(RecyclerView recyclerView, int i2, int i3) {
        this.f2683a.h();
        this.f2683a.g();
    }

    public final void R2() {
        this.f2682a.clear();
        this.f8502b.clear();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void S0(RecyclerView recyclerView) {
        this.f2683a.h();
        this.f2683a.g();
    }

    public final int S2(RecyclerView.e eVar) {
        if (J() != 0 && eVar.b() != 0) {
            T1();
            boolean zR2 = r2();
            View viewY1 = Y1(!zR2, true);
            View viewX1 = X1(!zR2, true);
            if (viewY1 != null && viewX1 != null) {
                int iB = this.f2683a.b(h0(viewY1), this.f8503j);
                int iB2 = this.f2683a.b(h0(viewX1), this.f8503j);
                int iMax = ((LinearLayoutManager) this).f2695i ? Math.max(0, ((this.f2683a.b(eVar.b() - 1, this.f8503j) + 1) - Math.max(iB, iB2)) - 1) : Math.max(0, Math.min(iB, iB2));
                if (zR2) {
                    return Math.round((iMax * (Math.abs(((LinearLayoutManager) this).f2691a.d(viewX1) - ((LinearLayoutManager) this).f2691a.g(viewY1)) / ((this.f2683a.b(h0(viewX1), this.f8503j) - this.f2683a.b(h0(viewY1), this.f8503j)) + 1))) + (((LinearLayoutManager) this).f2691a.m() - ((LinearLayoutManager) this).f2691a.g(viewY1)));
                }
                return iMax;
            }
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void T0(RecyclerView recyclerView, int i2, int i3, int i4) {
        this.f2683a.h();
        this.f2683a.g();
    }

    public final int T2(RecyclerView.e eVar) {
        if (J() != 0 && eVar.b() != 0) {
            T1();
            View viewY1 = Y1(!r2(), true);
            View viewX1 = X1(!r2(), true);
            if (viewY1 != null && viewX1 != null) {
                if (!r2()) {
                    return this.f2683a.b(eVar.b() - 1, this.f8503j) + 1;
                }
                return (int) (((((LinearLayoutManager) this).f2691a.d(viewX1) - ((LinearLayoutManager) this).f2691a.g(viewY1)) / ((this.f2683a.b(h0(viewX1), this.f8503j) - this.f2683a.b(h0(viewY1), this.f8503j)) + 1)) * (this.f2683a.b(eVar.b() - 1, this.f8503j) + 1));
            }
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void U0(RecyclerView recyclerView, int i2, int i3) {
        this.f2683a.h();
        this.f2683a.g();
    }

    public final void U2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, LinearLayoutManager.aux auxVar, int i2) {
        boolean z2 = i2 == 1;
        int iZ2 = Z2(lpt9Var, eVar, auxVar.f8518a);
        if (z2) {
            while (iZ2 > 0) {
                int i3 = auxVar.f8518a;
                if (i3 <= 0) {
                    return;
                }
                int i4 = i3 - 1;
                auxVar.f8518a = i4;
                iZ2 = Z2(lpt9Var, eVar, i4);
            }
            return;
        }
        int iB = eVar.b() - 1;
        int i5 = auxVar.f8518a;
        while (i5 < iB) {
            int i6 = i5 + 1;
            int iZ3 = Z2(lpt9Var, eVar, i6);
            if (iZ3 <= iZ2) {
                break;
            }
            i5 = i6;
            iZ2 = iZ3;
        }
        auxVar.f8518a = i5;
    }

    public final void V2() {
        View[] viewArr = this.f2684a;
        if (viewArr == null || viewArr.length != this.f8503j) {
            this.f2684a = new View[this.f8503j];
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void W0(RecyclerView recyclerView, int i2, int i3, Object obj) {
        this.f2683a.h();
        this.f2683a.g();
    }

    public int W2(int i2, int i3) {
        if (((LinearLayoutManager) this).f8511f != 1 || !q2()) {
            int[] iArr = this.f2685b;
            return iArr[i3 + i2] - iArr[i2];
        }
        int[] iArr2 = this.f2685b;
        int i4 = this.f8503j;
        return iArr2[i4 - i2] - iArr2[(i4 - i2) - i3];
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public void X0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (eVar.e()) {
            O2();
        }
        super.X0(lpt9Var, eVar);
        R2();
    }

    public int X2() {
        return this.f8503j;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public void Y0(RecyclerView.e eVar) {
        super.Y0(eVar);
        this.f8504m = false;
    }

    public final int Y2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2) {
        if (!eVar.e()) {
            return this.f2683a.b(i2, this.f8503j);
        }
        int iF = lpt9Var.f(i2);
        if (iF != -1) {
            return this.f2683a.b(iF, this.f8503j);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i2);
        return 0;
    }

    public final int Z2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2) {
        if (!eVar.e()) {
            return this.f2683a.c(i2, this.f8503j);
        }
        int i3 = this.f8502b.get(i2, -1);
        if (i3 != -1) {
            return i3;
        }
        int iF = lpt9Var.f(i2);
        if (iF != -1) {
            return this.f2683a.c(iF, this.f8503j);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i2);
        return 0;
    }

    public final int a3(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2) {
        if (!eVar.e()) {
            return this.f2683a.f(i2);
        }
        int i3 = this.f2682a.get(i2, -1);
        if (i3 != -1) {
            return i3;
        }
        int iF = lpt9Var.f(i2);
        if (iF != -1) {
            return this.f2683a.f(iF);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i2);
        return 1;
    }

    public final void b3(float f2, int i2) {
        P2(Math.max(Math.round(f2 * this.f8503j), i2));
    }

    public final void c3(View view, int i2, boolean z2) {
        int iK;
        int iK2;
        con conVar = (con) view.getLayoutParams();
        Rect rect = ((RecyclerView.lpt3) conVar).f8610a;
        int i3 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) conVar).topMargin + ((ViewGroup.MarginLayoutParams) conVar).bottomMargin;
        int i4 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) conVar).leftMargin + ((ViewGroup.MarginLayoutParams) conVar).rightMargin;
        int iW2 = W2(conVar.f8506a, conVar.f8507b);
        if (((LinearLayoutManager) this).f8511f == 1) {
            iK2 = RecyclerView.lpt2.K(iW2, i2, i4, ((ViewGroup.MarginLayoutParams) conVar).width, false);
            iK = RecyclerView.lpt2.K(((LinearLayoutManager) this).f2691a.n(), X(), i3, ((ViewGroup.MarginLayoutParams) conVar).height, true);
        } else {
            int iK3 = RecyclerView.lpt2.K(iW2, i2, i3, ((ViewGroup.MarginLayoutParams) conVar).height, false);
            int iK4 = RecyclerView.lpt2.K(((LinearLayoutManager) this).f2691a.n(), p0(), i4, ((ViewGroup.MarginLayoutParams) conVar).width, true);
            iK = iK3;
            iK2 = iK4;
        }
        d3(view, iK2, iK, z2);
    }

    public final void d3(View view, int i2, int i3, boolean z2) {
        RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
        if (z2 ? H1(view, i2, i3, lpt3Var) : F1(view, i2, i3, lpt3Var)) {
            view.measure(i2, i3);
        }
    }

    public void e3(int i2) {
        if (i2 == this.f8503j) {
            return;
        }
        this.f8504m = true;
        if (i2 >= 1) {
            this.f8503j = i2;
            this.f2683a.h();
            t1();
        } else {
            throw new IllegalArgumentException("Span count should be at least 1. Provided " + i2);
        }
    }

    public final void f3() {
        int iW;
        int iG0;
        if (p2() == 1) {
            iW = o0() - f0();
            iG0 = e0();
        } else {
            iW = W() - d0();
            iG0 = g0();
        }
        P2(iW - iG0);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public View h2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2, int i3, int i4) {
        T1();
        int iM = ((LinearLayoutManager) this).f2691a.m();
        int i5 = ((LinearLayoutManager) this).f2691a.i();
        int i6 = i3 > i2 ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i2 != i3) {
            View viewI = I(i2);
            int iH0 = h0(viewI);
            if (iH0 >= 0 && iH0 < i4 && Z2(lpt9Var, eVar, iH0) == 0) {
                if (((RecyclerView.lpt3) viewI.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = viewI;
                    }
                } else {
                    if (((LinearLayoutManager) this).f2691a.g(viewI) < i5 && ((LinearLayoutManager) this).f2691a.d(viewI) >= iM) {
                        return viewI;
                    }
                    if (view == null) {
                        view = viewI;
                    }
                }
            }
            i2 += i6;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int k0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (((LinearLayoutManager) this).f8511f == 0) {
            return this.f8503j;
        }
        if (eVar.b() < 1) {
            return 0;
        }
        return Y2(lpt9Var, eVar, eVar.b() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean m(RecyclerView.lpt3 lpt3Var) {
        return lpt3Var instanceof con;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public int r(RecyclerView.e eVar) {
        return this.f8505n ? S2(eVar) : super.r(eVar);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public int s(RecyclerView.e eVar) {
        return this.f8505n ? T2(eVar) : super.s(eVar);
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0211  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void s2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, LinearLayoutManager.nul nulVar, LinearLayoutManager.con conVar) {
        int i2;
        int i3;
        int iF;
        int i4;
        int i5;
        int i6;
        int i7;
        int iF2;
        int iF3;
        int i8;
        int i9;
        int iK;
        int iK2;
        View viewD;
        int iL = ((LinearLayoutManager) this).f2691a.l();
        boolean z2 = iL != 1073741824;
        int i10 = J() > 0 ? this.f2685b[this.f8503j] : 0;
        if (z2) {
            f3();
        }
        boolean z3 = nulVar.f8526d == 1;
        int iZ2 = this.f8503j;
        if (!z3) {
            iZ2 = Z2(lpt9Var, eVar, nulVar.f8525c) + a3(lpt9Var, eVar, nulVar.f8525c);
        }
        int i11 = 0;
        while (i11 < this.f8503j && nulVar.c(eVar) && iZ2 > 0) {
            int i12 = nulVar.f8525c;
            int iA3 = a3(lpt9Var, eVar, i12);
            if (iA3 > this.f8503j) {
                throw new IllegalArgumentException("Item at position " + i12 + " requires " + iA3 + " spans but GridLayoutManager has only " + this.f8503j + " spans.");
            }
            iZ2 -= iA3;
            if (iZ2 < 0 || (viewD = nulVar.d(lpt9Var)) == null) {
                break;
            }
            this.f2684a[i11] = viewD;
            i11++;
        }
        if (i11 == 0) {
            conVar.f2699a = true;
            return;
        }
        N2(lpt9Var, eVar, i11, z3);
        float f2 = 0.0f;
        int i13 = 0;
        for (int i14 = 0; i14 < i11; i14++) {
            View view = this.f2684a[i14];
            if (nulVar.f2700a == null) {
                if (z3) {
                    d(view);
                } else {
                    e(view, 0);
                }
            } else if (z3) {
                b(view);
            } else {
                c(view, 0);
            }
            j(view, this.f8501a);
            c3(view, iL, false);
            int iE = ((LinearLayoutManager) this).f2691a.e(view);
            if (iE > i13) {
                i13 = iE;
            }
            float f3 = (((LinearLayoutManager) this).f2691a.f(view) * 1.0f) / ((con) view.getLayoutParams()).f8507b;
            if (f3 > f2) {
                f2 = f3;
            }
        }
        if (z2) {
            b3(f2, i10);
            i13 = 0;
            for (int i15 = 0; i15 < i11; i15++) {
                View view2 = this.f2684a[i15];
                c3(view2, 1073741824, true);
                int iE2 = ((LinearLayoutManager) this).f2691a.e(view2);
                if (iE2 > i13) {
                    i13 = iE2;
                }
            }
        }
        for (int i16 = 0; i16 < i11; i16++) {
            View view3 = this.f2684a[i16];
            if (((LinearLayoutManager) this).f2691a.e(view3) != i13) {
                con conVar2 = (con) view3.getLayoutParams();
                Rect rect = ((RecyclerView.lpt3) conVar2).f8610a;
                int i17 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) conVar2).topMargin + ((ViewGroup.MarginLayoutParams) conVar2).bottomMargin;
                int i18 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) conVar2).leftMargin + ((ViewGroup.MarginLayoutParams) conVar2).rightMargin;
                int iW2 = W2(conVar2.f8506a, conVar2.f8507b);
                if (((LinearLayoutManager) this).f8511f == 1) {
                    iK2 = RecyclerView.lpt2.K(iW2, 1073741824, i18, ((ViewGroup.MarginLayoutParams) conVar2).width, false);
                    iK = View.MeasureSpec.makeMeasureSpec(i13 - i17, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i13 - i18, 1073741824);
                    iK = RecyclerView.lpt2.K(iW2, 1073741824, i17, ((ViewGroup.MarginLayoutParams) conVar2).height, false);
                    iK2 = iMakeMeasureSpec;
                }
                d3(view3, iK2, iK, true);
            }
        }
        conVar.f8520a = i13;
        if (((LinearLayoutManager) this).f8511f == 1) {
            if (nulVar.f8527e == -1) {
                i6 = nulVar.f8523a;
                i9 = i6 - i13;
            } else {
                i9 = nulVar.f8523a;
                i6 = i9 + i13;
            }
            i4 = i9;
            i5 = 0;
            iF = 0;
        } else {
            if (nulVar.f8527e == -1) {
                i3 = nulVar.f8523a;
                i2 = i3 - i13;
            } else {
                i2 = nulVar.f8523a;
                i3 = i2 + i13;
            }
            iF = i2;
            i4 = 0;
            i5 = i3;
            i6 = 0;
        }
        int i19 = 0;
        while (i19 < i11) {
            View view4 = this.f2684a[i19];
            con conVar3 = (con) view4.getLayoutParams();
            if (((LinearLayoutManager) this).f8511f == 1) {
                if (q2()) {
                    int iE0 = e0() + this.f2685b[this.f8503j - conVar3.f8506a];
                    iF = iE0 - ((LinearLayoutManager) this).f2691a.f(view4);
                    iF3 = i6;
                    iF2 = iE0;
                    i7 = i4;
                } else {
                    int iE1 = e0() + this.f2685b[conVar3.f8506a];
                    iF3 = i6;
                    i8 = iE1;
                    i7 = i4;
                    iF2 = ((LinearLayoutManager) this).f2691a.f(view4) + iE1;
                }
                z0(view4, i8, i7, iF2, iF3);
                if (conVar3.c() || conVar3.b()) {
                    conVar.f8521b = true;
                }
                conVar.f8522c |= view4.hasFocusable();
                i19++;
                i6 = iF3;
                i5 = iF2;
                i4 = i7;
                iF = i8;
            } else {
                int iG0 = g0() + this.f2685b[conVar3.f8506a];
                i7 = iG0;
                iF2 = i5;
                iF3 = ((LinearLayoutManager) this).f2691a.f(view4) + iG0;
            }
            i8 = iF;
            z0(view4, i8, i7, iF2, iF3);
            if (conVar3.c()) {
                conVar.f8521b = true;
            } else {
                conVar.f8521b = true;
            }
            conVar.f8522c |= view4.hasFocusable();
            i19++;
            i6 = iF3;
            i5 = iF2;
            i4 = i7;
            iF = i8;
        }
        Arrays.fill(this.f2684a, (Object) null);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public int u(RecyclerView.e eVar) {
        return this.f8505n ? S2(eVar) : super.u(eVar);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void u2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, LinearLayoutManager.aux auxVar, int i2) {
        super.u2(lpt9Var, eVar, auxVar, i2);
        f3();
        if (eVar.b() > 0 && !eVar.e()) {
            U2(lpt9Var, eVar, auxVar, i2);
        }
        V2();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public int v(RecyclerView.e eVar) {
        return this.f8505n ? T2(eVar) : super.v(eVar);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public int w1(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        f3();
        V2();
        return super.w1(i2, lpt9Var, eVar);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.RecyclerView.lpt2
    public int y1(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        f3();
        V2();
        return super.y1(i2, lpt9Var, eVar);
    }

    public static class con extends RecyclerView.lpt3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8506a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8507b;

        public con(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f8506a = -1;
            this.f8507b = 0;
        }

        public int e() {
            return this.f8506a;
        }

        public int f() {
            return this.f8507b;
        }

        public con(int i2, int i3) {
            super(i2, i3);
            this.f8506a = -1;
            this.f8507b = 0;
        }

        public con(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f8506a = -1;
            this.f8507b = 0;
        }

        public con(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f8506a = -1;
            this.f8507b = 0;
        }
    }

    public GridLayoutManager(Context context, int i2, int i3, boolean z2) {
        super(context, i3, z2);
        this.f8504m = false;
        this.f8503j = -1;
        this.f2682a = new SparseIntArray();
        this.f8502b = new SparseIntArray();
        this.f2683a = new aux();
        this.f8501a = new Rect();
        e3(i2);
    }
}
