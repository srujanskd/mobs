package com.newrelic.agent.android.activity.config;

/* JADX INFO: loaded from: classes.dex */
public class ActivityTraceConfiguration {
    private int maxTotalTraceCount;

    public static ActivityTraceConfiguration defaultActivityTraceConfiguration() {
        ActivityTraceConfiguration activityTraceConfiguration = new ActivityTraceConfiguration();
        activityTraceConfiguration.setMaxTotalTraceCount(1);
        return activityTraceConfiguration;
    }

    public int getMaxTotalTraceCount() {
        return this.maxTotalTraceCount;
    }

    public void setMaxTotalTraceCount(int i2) {
        this.maxTotalTraceCount = i2;
    }

    public String toString() {
        return "ActivityTraceConfiguration{maxTotalTraceCount=" + this.maxTotalTraceCount + '}';
    }
}
