package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.Switch;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class SwitchPreference extends TwoStatePreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux f8476a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f8477c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f8478d;

    public class aux implements CompoundButton.OnCheckedChangeListener {
        public aux() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
            if (SwitchPreference.this.callChangeListener(Boolean.valueOf(z2))) {
                SwitchPreference.this.b(z2);
            } else {
                compoundButton.setChecked(!z2);
            }
        }
    }

    public SwitchPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f8476a = new aux();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f541n, i2, i3);
        e(l0.f(typedArrayObtainStyledAttributes, lpt7.I0, lpt7.B0));
        d(l0.f(typedArrayObtainStyledAttributes, lpt7.H0, lpt7.C0));
        i(l0.f(typedArrayObtainStyledAttributes, lpt7.K0, lpt7.E0));
        h(l0.f(typedArrayObtainStyledAttributes, lpt7.J0, lpt7.F0));
        c(l0.b(typedArrayObtainStyledAttributes, lpt7.G0, lpt7.D0, false));
        typedArrayObtainStyledAttributes.recycle();
    }

    public void h(CharSequence charSequence) {
        this.f8478d = charSequence;
        notifyChanged();
    }

    public void i(CharSequence charSequence) {
        this.f8477c = charSequence;
        notifyChanged();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void j(View view) {
        boolean z2 = view instanceof Switch;
        if (z2) {
            ((Switch) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(((TwoStatePreference) this).f2666b);
        }
        if (z2) {
            Switch r4 = (Switch) view;
            r4.setTextOn(this.f8477c);
            r4.setTextOff(this.f8478d);
            r4.setOnCheckedChangeListener(this.f8476a);
        }
    }

    public final void l(View view) {
        if (((AccessibilityManager) getContext().getSystemService("accessibility")).isEnabled()) {
            j(view.findViewById(R.id.switch_widget));
            g(view.findViewById(R.id.summary));
        }
    }

    @Override // androidx.preference.Preference
    public void onBindViewHolder(com7 com7Var) {
        super.onBindViewHolder(com7Var);
        j(com7Var.M(R.id.switch_widget));
        f(com7Var);
    }

    @Override // androidx.preference.Preference
    public void performClick(View view) {
        super.performClick(view);
        l(view);
    }

    public SwitchPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public SwitchPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6178l, R.attr.switchPreferenceStyle));
    }

    public SwitchPreference(Context context) {
        this(context, null);
    }
}
