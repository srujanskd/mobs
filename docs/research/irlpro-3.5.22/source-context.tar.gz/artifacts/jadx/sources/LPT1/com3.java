package LPT1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class com3 extends com6 implements Iterable<com6> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final List<com6> f6580a = new ArrayList();

    public boolean equals(Object obj) {
        return obj == this || ((obj instanceof com3) && ((com3) obj).f6580a.equals(this.f6580a));
    }

    public void h(com6 com6Var) {
        if (com6Var == null) {
            com6Var = com8.f6581a;
        }
        this.f6580a.add(com6Var);
    }

    public int hashCode() {
        return this.f6580a.hashCode();
    }

    @Override // java.lang.Iterable
    public Iterator<com6> iterator() {
        return this.f6580a.iterator();
    }
}
