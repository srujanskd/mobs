package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.view.menu.com1;
import p001AuX.com3;
import p001AuX.com9;
import p001AuX.lpt3;
import p022CoN.com8;
import p022CoN.q0;
import p022CoN.u0;
import p024Com2.n0;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends com8 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public View f7850a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public LinearLayout f1936a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f1937a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f1938a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7851b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f1939b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public TextView f1940b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f1941b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7852c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public View f1942c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7853d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f1943d;

    public class aux implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p012COn.prn f7854a;

        public aux(p012COn.prn prnVar) {
            this.f7854a = prnVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.f7854a.c();
        }
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    @Override // p022CoN.com8
    public /* bridge */ /* synthetic */ n0 f(int i2, long j2) {
        return super.f(i2, j2);
    }

    public void g() {
        if (this.f7850a == null) {
            k();
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // p022CoN.com8
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // p022CoN.com8
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f1941b;
    }

    public CharSequence getTitle() {
        return this.f1938a;
    }

    public void h(p012COn.prn prnVar) {
        View view = this.f7850a;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f7853d, (ViewGroup) this, false);
            this.f7850a = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f7850a);
        }
        View viewFindViewById = this.f7850a.findViewById(p001AuX.com8.f5573i);
        this.f1939b = viewFindViewById;
        viewFindViewById.setOnClickListener(new aux(prnVar));
        com1 com1Var = (com1) prnVar.e();
        androidx.appcompat.widget.aux auxVar = ((com8) this).f566a;
        if (auxVar != null) {
            auxVar.y();
        }
        androidx.appcompat.widget.aux auxVar2 = new androidx.appcompat.widget.aux(getContext());
        ((com8) this).f566a = auxVar2;
        auxVar2.J(true);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        com1Var.c(((com8) this).f566a, ((com8) this).f564a);
        ActionMenuView actionMenuView = (ActionMenuView) ((com8) this).f566a.o(this);
        ((com8) this).f565a = actionMenuView;
        y.s0(actionMenuView, null);
        addView(((com8) this).f565a, layoutParams);
    }

    public final void i() {
        if (this.f1936a == null) {
            LayoutInflater.from(getContext()).inflate(com9.f5591a, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f1936a = linearLayout;
            this.f1937a = (TextView) linearLayout.findViewById(p001AuX.com8.f5569e);
            this.f1940b = (TextView) this.f1936a.findViewById(p001AuX.com8.f5568d);
            if (this.f7851b != 0) {
                this.f1937a.setTextAppearance(getContext(), this.f7851b);
            }
            if (this.f7852c != 0) {
                this.f1940b.setTextAppearance(getContext(), this.f7852c);
            }
        }
        this.f1937a.setText(this.f1938a);
        this.f1940b.setText(this.f1941b);
        boolean z2 = !TextUtils.isEmpty(this.f1938a);
        boolean z3 = !TextUtils.isEmpty(this.f1941b);
        int i2 = 0;
        this.f1940b.setVisibility(z3 ? 0 : 8);
        LinearLayout linearLayout2 = this.f1936a;
        if (!z2 && !z3) {
            i2 = 8;
        }
        linearLayout2.setVisibility(i2);
        if (this.f1936a.getParent() == null) {
            addView(this.f1936a);
        }
    }

    public boolean j() {
        return this.f1943d;
    }

    public void k() {
        removeAllViews();
        this.f1942c = null;
        ((com8) this).f565a = null;
        ((com8) this).f566a = null;
        View view = this.f1939b;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    public boolean l() {
        androidx.appcompat.widget.aux auxVar = ((com8) this).f566a;
        if (auxVar != null) {
            return auxVar.K();
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        androidx.appcompat.widget.aux auxVar = ((com8) this).f566a;
        if (auxVar != null) {
            auxVar.B();
            ((com8) this).f566a.C();
        }
    }

    @Override // p022CoN.com8, android.view.View
    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        boolean zB = u0.b(this);
        int paddingRight = zB ? (i4 - i2) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
        View view = this.f7850a;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f7850a.getLayoutParams();
            int i6 = zB ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i7 = zB ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int iD = com8.d(paddingRight, i6, zB);
            paddingRight = com8.d(iD + e(this.f7850a, iD, paddingTop, paddingTop2, zB), i7, zB);
        }
        int iE = paddingRight;
        LinearLayout linearLayout = this.f1936a;
        if (linearLayout != null && this.f1942c == null && linearLayout.getVisibility() != 8) {
            iE += e(this.f1936a, iE, paddingTop, paddingTop2, zB);
        }
        int i8 = iE;
        View view2 = this.f1942c;
        if (view2 != null) {
            e(view2, i8, paddingTop, paddingTop2, zB);
        }
        int paddingLeft = zB ? getPaddingLeft() : (i4 - i2) - getPaddingRight();
        ActionMenuView actionMenuView = ((com8) this).f565a;
        if (actionMenuView != null) {
            e(actionMenuView, paddingLeft, paddingTop, paddingTop2, !zB);
        }
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        if (View.MeasureSpec.getMode(i2) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode(i3) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int size = View.MeasureSpec.getSize(i2);
        int size2 = ((com8) this).f6292a;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i3);
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingTop;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f7850a;
        if (view != null) {
            int iC = c(view, paddingLeft, iMakeMeasureSpec, 0);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f7850a.getLayoutParams();
            paddingLeft = iC - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = ((com8) this).f565a;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = c(((com8) this).f565a, paddingLeft, iMakeMeasureSpec, 0);
        }
        LinearLayout linearLayout = this.f1936a;
        if (linearLayout != null && this.f1942c == null) {
            if (this.f1943d) {
                this.f1936a.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f1936a.getMeasuredWidth();
                boolean z2 = measuredWidth <= paddingLeft;
                if (z2) {
                    paddingLeft -= measuredWidth;
                }
                this.f1936a.setVisibility(z2 ? 0 : 8);
            } else {
                paddingLeft = c(linearLayout, paddingLeft, iMakeMeasureSpec, 0);
            }
        }
        View view2 = this.f1942c;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i4 = layoutParams.width;
            int i5 = i4 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i4 >= 0) {
                paddingLeft = Math.min(i4, paddingLeft);
            }
            int i6 = layoutParams.height;
            int i7 = i6 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i6 >= 0) {
                iMin = Math.min(i6, iMin);
            }
            this.f1942c.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i5), View.MeasureSpec.makeMeasureSpec(iMin, i7));
        }
        if (((com8) this).f6292a > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingTop;
            if (measuredHeight > i8) {
                i8 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i8);
    }

    @Override // p022CoN.com8, android.view.View
    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    @Override // p022CoN.com8
    public void setContentHeight(int i2) {
        ((com8) this).f6292a = i2;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f1942c;
        if (view2 != null) {
            removeView(view2);
        }
        this.f1942c = view;
        if (view != null && (linearLayout = this.f1936a) != null) {
            removeView(linearLayout);
            this.f1936a = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f1941b = charSequence;
        i();
    }

    public void setTitle(CharSequence charSequence) {
        this.f1938a = charSequence;
        i();
        y.r0(this, charSequence);
    }

    public void setTitleOptional(boolean z2) {
        if (z2 != this.f1943d) {
            requestLayout();
        }
        this.f1943d = z2;
    }

    @Override // p022CoN.com8, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i2) {
        super.setVisibility(i2);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.f5502j);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        q0 q0VarV = q0.v(context, attributeSet, lpt3.f17e, i2, 0);
        y.s0(this, q0VarV.g(lpt3.f5662u));
        this.f7851b = q0VarV.n(lpt3.f5666y, 0);
        this.f7852c = q0VarV.n(lpt3.f5665x, 0);
        ((com8) this).f6292a = q0VarV.m(lpt3.f5664w, 0);
        this.f7853d = q0VarV.n(lpt3.f5663v, com9.f5594d);
        q0VarV.w();
    }
}
