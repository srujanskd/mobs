package com.newrelic.agent.android.agentdata.builder;

import com.newrelic.agent.android.agentdata.HexAttribute;
import com.newrelic.com.google.flatbuffers.FlatBufferBuilder;
import com.newrelic.com.google.gson.GsonBuilder;
import com.newrelic.mobile.fbs.AgentData;
import com.newrelic.mobile.fbs.AgentDataBundle;
import com.newrelic.mobile.fbs.ApplicationInfo;
import com.newrelic.mobile.fbs.BoolSessionAttribute;
import com.newrelic.mobile.fbs.DoubleSessionAttribute;
import com.newrelic.mobile.fbs.LongSessionAttribute;
import com.newrelic.mobile.fbs.StringSessionAttribute;
import com.newrelic.mobile.fbs.hex.Frame;
import com.newrelic.mobile.fbs.hex.HandledException;
import com.newrelic.mobile.fbs.hex.Thread;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class AgentDataBuilder {
    public static Map<String, Object> attributesMapFromAgentData(AgentData agentData) {
        HashMap map = new HashMap();
        for (int i2 = 0; i2 < agentData.stringAttributesLength(); i2++) {
            StringSessionAttribute stringSessionAttributeStringAttributes = agentData.stringAttributes(i2);
            map.put(stringSessionAttributeStringAttributes.name(), stringSessionAttributeStringAttributes.value());
        }
        for (int i3 = 0; i3 < agentData.longAttributesLength(); i3++) {
            LongSessionAttribute longSessionAttributeLongAttributes = agentData.longAttributes(i3);
            map.put(longSessionAttributeLongAttributes.name(), Long.valueOf(longSessionAttributeLongAttributes.value()));
        }
        for (int i4 = 0; i4 < agentData.doubleAttributesLength(); i4++) {
            DoubleSessionAttribute doubleSessionAttributeDoubleAttributes = agentData.doubleAttributes(i4);
            map.put(doubleSessionAttributeDoubleAttributes.name(), Double.valueOf(doubleSessionAttributeDoubleAttributes.value()));
        }
        for (int i5 = 0; i5 < agentData.boolAttributesLength(); i5++) {
            BoolSessionAttribute boolSessionAttributeBoolAttributes = agentData.boolAttributes(i5);
            map.put(boolSessionAttributeBoolAttributes.name(), Boolean.valueOf(boolSessionAttributeBoolAttributes.value()));
        }
        for (int i6 = 0; i6 < agentData.handledExceptionsLength(); i6++) {
            HandledException handledExceptionHandledExceptions = agentData.handledExceptions(i6);
            map.put(HexAttribute.HEX_ATTR_TIMESTAMP_MS, Long.valueOf(handledExceptionHandledExceptions.timestampMs()));
            map.put(HexAttribute.HEX_ATTR_APP_UUID_HI, Long.valueOf(handledExceptionHandledExceptions.appUuidHigh()));
            map.put(HexAttribute.HEX_ATTR_APP_UUID_LO, Long.valueOf(handledExceptionHandledExceptions.appUuidLow()));
            map.put("name", handledExceptionHandledExceptions.name());
            map.put(HexAttribute.HEX_ATTR_CAUSE, handledExceptionHandledExceptions.cause());
            map.put(HexAttribute.HEX_ATTR_MESSAGE, handledExceptionHandledExceptions.message());
            for (int i7 = 0; i7 < handledExceptionHandledExceptions.threadsLength(); i7++) {
                Thread threadCurrentThread = Thread.currentThread();
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                for (int i8 = 0; i8 < handledExceptionHandledExceptions.threads(i7).framesLength(); i8++) {
                    LinkedHashMap linkedHashMap2 = new LinkedHashMap();
                    linkedHashMap2.put(HexAttribute.HEX_ATTR_FILENAME, handledExceptionHandledExceptions.threads(i7).frames(i8).fileName());
                    linkedHashMap2.put(HexAttribute.HEX_ATTR_LINE_NUMBER, Long.valueOf(handledExceptionHandledExceptions.threads(i7).frames(i8).lineNumber()));
                    linkedHashMap2.put(HexAttribute.HEX_ATTR_CLASS_NAME, handledExceptionHandledExceptions.threads(i7).frames(i8).className());
                    linkedHashMap2.put(HexAttribute.HEX_ATTR_METHOD_NAME, handledExceptionHandledExceptions.threads(i7).frames(i8).methodName());
                    linkedHashMap.put("frame " + i8, linkedHashMap2);
                }
                linkedHashMap.put(HexAttribute.HEX_ATTR_THREAD_CRASHED, Boolean.FALSE);
                linkedHashMap.put(HexAttribute.HEX_ATTR_THREAD_STATE, threadCurrentThread.getState().toString());
                linkedHashMap.put(HexAttribute.HEX_ATTR_THREAD_NUMBER, Long.valueOf(threadCurrentThread.getId()));
                linkedHashMap.put(HexAttribute.HEX_ATTR_THREAD_ID, threadCurrentThread.getName());
                linkedHashMap.put(HexAttribute.HEX_ATTR_THREAD_PRI, Integer.valueOf(threadCurrentThread.getPriority()));
                map.put("thread " + i7, linkedHashMap);
            }
        }
        return map;
    }

    public static void computeIfAbsent(String str, Map<String, Integer> map, FlatBufferBuilder flatBufferBuilder) {
        if (str == null || map.containsValue(str)) {
            return;
        }
        map.put(str, Integer.valueOf(flatBufferBuilder.createString(str)));
    }

    public static FlatBufferBuilder startAndFinishAgentData(Map<String, Object> map, Set<Map<String, Object>> set) {
        String str;
        String str2;
        String str3;
        long jLongValue;
        long jLongValue2;
        HashMap map2 = new HashMap();
        FlatBufferBuilder flatBufferBuilder = new FlatBufferBuilder();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            computeIfAbsent(key, map2, flatBufferBuilder);
            if (value instanceof String) {
                computeIfAbsent((String) value, map2, flatBufferBuilder);
            }
        }
        Iterator<Map<String, Object>> it = set.iterator();
        List<Map> list = null;
        while (true) {
            boolean zHasNext = it.hasNext();
            str = HexAttribute.HEX_ATTR_CAUSE;
            str2 = HexAttribute.HEX_ATTR_MESSAGE;
            str3 = "name";
            if (!zHasNext) {
                break;
            }
            Map<String, Object> next = it.next();
            computeIfAbsent((String) next.get("name"), map2, flatBufferBuilder);
            computeIfAbsent((String) next.get(HexAttribute.HEX_ATTR_MESSAGE), map2, flatBufferBuilder);
            computeIfAbsent((String) next.get(HexAttribute.HEX_ATTR_CAUSE), map2, flatBufferBuilder);
            list = (List) next.get(HexAttribute.HEX_ATTR_THREAD);
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (list != null) {
            for (Map map3 : list) {
                HashMap map4 = new HashMap();
                map4.put(HexAttribute.HEX_ATTR_FILENAME, Integer.valueOf(flatBufferBuilder.createString("")));
                for (Map.Entry entry2 : map3.entrySet()) {
                    String str4 = (String) entry2.getKey();
                    Object value2 = entry2.getValue();
                    if (value2 instanceof String) {
                        map4.put(str4, Integer.valueOf(flatBufferBuilder.createString((String) value2)));
                    }
                }
                Frame.startFrame(flatBufferBuilder);
                if (map4.get(HexAttribute.HEX_ATTR_CLASS_NAME) != null) {
                    Frame.addClassName(flatBufferBuilder, ((Integer) map4.get(HexAttribute.HEX_ATTR_CLASS_NAME)).intValue());
                }
                if (map4.get(HexAttribute.HEX_ATTR_METHOD_NAME) != null) {
                    Frame.addMethodName(flatBufferBuilder, ((Integer) map4.get(HexAttribute.HEX_ATTR_METHOD_NAME)).intValue());
                }
                if (map4.get(HexAttribute.HEX_ATTR_FILENAME) != null) {
                    Frame.addFileName(flatBufferBuilder, ((Integer) map4.get(HexAttribute.HEX_ATTR_FILENAME)).intValue());
                }
                if (map3.get(HexAttribute.HEX_ATTR_LINE_NUMBER) != null) {
                    Frame.addLineNumber(flatBufferBuilder, ((Integer) map3.get(HexAttribute.HEX_ATTR_LINE_NUMBER)).intValue());
                }
                arrayList.add(Integer.valueOf(Frame.endFrame(flatBufferBuilder)));
            }
        }
        arrayList2.add(Integer.valueOf(Thread.createThread(flatBufferBuilder, Thread.createFramesVector(flatBufferBuilder, toArray(arrayList)))));
        int iCreateThreadsVector = HandledException.createThreadsVector(flatBufferBuilder, toArray(arrayList2));
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        HashSet hashSet3 = new HashSet();
        HashSet hashSet4 = new HashSet();
        for (Map.Entry<String, Object> entry3 : map.entrySet()) {
            int iIntValue = ((Integer) map2.get(entry3.getKey())).intValue();
            Object value3 = entry3.getValue();
            if (value3 instanceof String) {
                hashSet.add(Integer.valueOf(StringSessionAttribute.createStringSessionAttribute(flatBufferBuilder, iIntValue, ((Integer) map2.get(value3)).intValue())));
            } else if ((value3 instanceof Double) || (value3 instanceof Float)) {
                hashSet2.add(Integer.valueOf(DoubleSessionAttribute.createDoubleSessionAttribute(flatBufferBuilder, iIntValue, ((Number) value3).doubleValue())));
            } else if (value3 instanceof Number) {
                hashSet3.add(Integer.valueOf(LongSessionAttribute.createLongSessionAttribute(flatBufferBuilder, iIntValue, ((Number) value3).longValue())));
            } else if (value3 instanceof Boolean) {
                hashSet4.add(Integer.valueOf(BoolSessionAttribute.createBoolSessionAttribute(flatBufferBuilder, iIntValue, ((Boolean) value3).booleanValue())));
            }
        }
        int iCreateStringAttributesVector = !hashSet.isEmpty() ? AgentData.createStringAttributesVector(flatBufferBuilder, toArray(hashSet)) : -1;
        int iCreateDoubleAttributesVector = !hashSet2.isEmpty() ? AgentData.createDoubleAttributesVector(flatBufferBuilder, toArray(hashSet2)) : -1;
        int iCreateLongAttributesVector = !hashSet3.isEmpty() ? AgentData.createLongAttributesVector(flatBufferBuilder, toArray(hashSet3)) : -1;
        int iCreateBoolAttributesVector = !hashSet4.isEmpty() ? AgentData.createBoolAttributesVector(flatBufferBuilder, toArray(hashSet4)) : -1;
        HashSet hashSet5 = new HashSet();
        if (!set.isEmpty()) {
            Iterator<Map<String, Object>> it2 = set.iterator();
            while (it2.hasNext()) {
                Map<String, Object> next2 = it2.next();
                int iStringIndexMapOffset = stringIndexMapOffset(map2, next2.get(str3));
                int iStringIndexMapOffset2 = stringIndexMapOffset(map2, next2.get(str2));
                int iStringIndexMapOffset3 = stringIndexMapOffset(map2, next2.get(str));
                HashMap map5 = map2;
                String str5 = str;
                String str6 = str2;
                long jLongValue3 = ((Long) (next2.containsKey(HexAttribute.HEX_ATTR_TIMESTAMP_MS) ? next2.get(HexAttribute.HEX_ATTR_TIMESTAMP_MS) : Long.valueOf(System.currentTimeMillis()))).longValue();
                try {
                    jLongValue = ((Long) next2.get(HexAttribute.HEX_ATTR_APP_UUID_HI)).longValue();
                    jLongValue2 = ((Long) next2.get(HexAttribute.HEX_ATTR_APP_UUID_LO)).longValue();
                } catch (ClassCastException unused) {
                    jLongValue = 0;
                    jLongValue2 = 0;
                }
                HandledException.startHandledException(flatBufferBuilder);
                HandledException.addAppUuidHigh(flatBufferBuilder, jLongValue);
                HandledException.addAppUuidLow(flatBufferBuilder, jLongValue2);
                if (-1 != jLongValue3) {
                    HandledException.addTimestampMs(flatBufferBuilder, jLongValue3);
                }
                if (-1 != iStringIndexMapOffset) {
                    HandledException.addName(flatBufferBuilder, iStringIndexMapOffset);
                }
                if (-1 != iStringIndexMapOffset2) {
                    HandledException.addMessage(flatBufferBuilder, iStringIndexMapOffset2);
                }
                if (-1 != iStringIndexMapOffset3) {
                    HandledException.addCause(flatBufferBuilder, iStringIndexMapOffset3);
                }
                HandledException.addThreads(flatBufferBuilder, iCreateThreadsVector);
                hashSet5.add(Integer.valueOf(HandledException.endHandledException(flatBufferBuilder)));
                it2 = it2;
                str3 = str3;
                map2 = map5;
                str2 = str6;
                str = str5;
                iCreateLongAttributesVector = iCreateLongAttributesVector;
            }
        }
        int i2 = iCreateLongAttributesVector;
        int iCreateHandledExceptionsVector = !hashSet5.isEmpty() ? AgentData.createHandledExceptionsVector(flatBufferBuilder, toArray(hashSet5)) : -1;
        ApplicationInfo.startApplicationInfo(flatBufferBuilder);
        ApplicationInfo.addPlatform(flatBufferBuilder, 0);
        int iEndApplicationInfo = ApplicationInfo.endApplicationInfo(flatBufferBuilder);
        AgentData.startAgentData(flatBufferBuilder);
        if (iCreateStringAttributesVector != -1) {
            AgentData.addStringAttributes(flatBufferBuilder, iCreateStringAttributesVector);
        }
        if (iCreateDoubleAttributesVector != -1) {
            AgentData.addDoubleAttributes(flatBufferBuilder, iCreateDoubleAttributesVector);
        }
        if (i2 != -1) {
            AgentData.addLongAttributes(flatBufferBuilder, i2);
        }
        if (iCreateBoolAttributesVector != -1) {
            AgentData.addBoolAttributes(flatBufferBuilder, iCreateBoolAttributesVector);
        }
        if (iCreateHandledExceptionsVector != -1) {
            AgentData.addHandledExceptions(flatBufferBuilder, iCreateHandledExceptionsVector);
        }
        AgentData.addApplicationInfo(flatBufferBuilder, iEndApplicationInfo);
        HashSet hashSet6 = new HashSet();
        hashSet6.add(Integer.valueOf(AgentData.endAgentData(flatBufferBuilder)));
        int iCreateAgentDataVector = AgentDataBundle.createAgentDataVector(flatBufferBuilder, toArray(hashSet6));
        AgentDataBundle.startAgentDataBundle(flatBufferBuilder);
        AgentDataBundle.addAgentData(flatBufferBuilder, iCreateAgentDataVector);
        flatBufferBuilder.finish(AgentDataBundle.endAgentDataBundle(flatBufferBuilder));
        return flatBufferBuilder;
    }

    private static int stringIndexMapOffset(Map<String, Integer> map, Object obj) {
        Integer num;
        Integer num2 = -1;
        if (obj != null && (num = map.get(obj)) != null) {
            num2 = num;
        }
        return num2.intValue();
    }

    private static int[] toArray(Collection<Integer> collection) {
        int[] iArr = new int[collection.size()];
        Iterator<Integer> it = collection.iterator();
        int i2 = 0;
        while (it.hasNext()) {
            iArr[i2] = it.next().intValue();
            i2++;
        }
        return iArr;
    }

    public static String toJsonString(AgentDataBundle agentDataBundle, int i2) {
        return new GsonBuilder().enableComplexMapKeySerialization().serializeNulls().setPrettyPrinting().create().toJson(attributesMapFromAgentData(agentDataBundle.agentData(i2)));
    }
}
