package android.support.v4.graphics.drawable;

import androidx.core.graphics.drawable.IconCompat;
import p017CoM5.u;

/* JADX INFO: loaded from: classes.dex */
public final class IconCompatParcelizer extends androidx.core.graphics.drawable.IconCompatParcelizer {
    public static IconCompat read(u uVar) {
        return androidx.core.graphics.drawable.IconCompatParcelizer.read(uVar);
    }

    public static void write(IconCompat iconCompat, u uVar) {
        androidx.core.graphics.drawable.IconCompatParcelizer.write(iconCompat, uVar);
    }
}
