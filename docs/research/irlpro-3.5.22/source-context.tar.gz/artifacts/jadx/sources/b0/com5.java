package b0;

import f.com8;
import java.net.Proxy;
import v.e;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
public final class com5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final com5 f8797a = new com5();

    public final String a(e eVar, Proxy.Type type) {
        com8.e(eVar, "request");
        com8.e(type, "proxyType");
        StringBuilder sb = new StringBuilder();
        sb.append(eVar.g());
        sb.append(' ');
        com5 com5Var = f8797a;
        if (com5Var.b(eVar, type)) {
            sb.append(eVar.i());
        } else {
            sb.append(com5Var.c(eVar.i()));
        }
        sb.append(" HTTP/1.1");
        String string = sb.toString();
        com8.d(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }

    public final boolean b(e eVar, Proxy.Type type) {
        return !eVar.f() && type == Proxy.Type.HTTP;
    }

    public final String c(lpt9 lpt9Var) {
        com8.e(lpt9Var, "url");
        String strD = lpt9Var.d();
        String strF = lpt9Var.f();
        if (strF == null) {
            return strD;
        }
        return strD + '?' + ((Object) strF);
    }
}
