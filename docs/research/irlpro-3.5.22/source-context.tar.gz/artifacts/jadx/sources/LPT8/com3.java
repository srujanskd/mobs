package LPT8;

import io.objectbox.query.Query;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import p040LPt8.com4;
import p145lpt9.w0;

/* JADX INFO: loaded from: classes.dex */
public class com3<T> implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com4<T> f948a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Query<T> f949a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Set<w0<List<T>>> f951a = new CopyOnWriteArraySet();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Deque<w0<List<T>>> f950a = new ArrayDeque();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile boolean f6814b = false;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final con<T> f6813a = new con<>();

    public static class con<T> implements w0<List<T>> {
        public con() {
        }

        @Override // p145lpt9.w0
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(List<T> list) {
        }
    }

    public com3(Query<T> query, com4<T> com4Var) {
        this.f949a = query;
        this.f948a = com4Var;
    }

    @Override // java.lang.Runnable
    public void run() {
        boolean z2;
        while (true) {
            try {
                ArrayList arrayList = new ArrayList();
                synchronized (this.f950a) {
                    z2 = false;
                    while (true) {
                        w0<List<T>> w0VarPoll = this.f950a.poll();
                        if (w0VarPoll == null) {
                            break;
                        } else if (this.f6813a.equals(w0VarPoll)) {
                            z2 = true;
                        } else {
                            arrayList.add(w0VarPoll);
                        }
                        this.f6814b = false;
                        throw th;
                    }
                    if (!z2 && arrayList.isEmpty()) {
                        this.f6814b = false;
                        this.f6814b = false;
                        return;
                    }
                    this.f6814b = false;
                    throw th;
                }
                List<T> listY = this.f949a.y();
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    ((w0) it.next()).a(listY);
                }
                if (z2) {
                    Iterator<w0<List<T>>> it2 = this.f951a.iterator();
                    while (it2.hasNext()) {
                        it2.next().a(listY);
                    }
                }
            } catch (Throwable th) {
                this.f6814b = false;
                throw th;
            }
        }
    }
}
