package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class com7 implements Parcelable {
    public static final Parcelable.Creator<com7> CREATOR = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8273a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2477a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<com9> f2478a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con[] f2479a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList<String> f8274b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ArrayList<String> f8275c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<Bundle> f8276d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList<com6.com9> f8277e;

    public class aux implements Parcelable.Creator<com7> {
        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public com7 createFromParcel(Parcel parcel) {
            return new com7(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public com7[] newArray(int i2) {
            return new com7[i2];
        }
    }

    public com7() {
        this.f2477a = null;
        this.f8275c = new ArrayList<>();
        this.f8276d = new ArrayList<>();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeTypedList(this.f2478a);
        parcel.writeStringList(this.f8274b);
        parcel.writeTypedArray(this.f2479a, i2);
        parcel.writeInt(this.f8273a);
        parcel.writeString(this.f2477a);
        parcel.writeStringList(this.f8275c);
        parcel.writeTypedList(this.f8276d);
        parcel.writeTypedList(this.f8277e);
    }

    public com7(Parcel parcel) {
        this.f2477a = null;
        this.f8275c = new ArrayList<>();
        this.f8276d = new ArrayList<>();
        this.f2478a = parcel.createTypedArrayList(com9.CREATOR);
        this.f8274b = parcel.createStringArrayList();
        this.f2479a = (con[]) parcel.createTypedArray(con.CREATOR);
        this.f8273a = parcel.readInt();
        this.f2477a = parcel.readString();
        this.f8275c = parcel.createStringArrayList();
        this.f8276d = parcel.createTypedArrayList(Bundle.CREATOR);
        this.f8277e = parcel.createTypedArrayList(com6.com9.CREATOR);
    }
}
