package androidx.recyclerview.widget;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.Map;
import java.util.WeakHashMap;
import p024Com2.y;
import p081cOm2.e2;
import p081cOm2.f2;

/* JADX INFO: loaded from: classes.dex */
public class com7 extends p024Com2.lpt3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final RecyclerView f8673a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final aux f2873a;

    public static class aux extends p024Com2.lpt3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final com7 f8674a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Map<View, p024Com2.lpt3> f2874a = new WeakHashMap();

        public aux(com7 com7Var) {
            this.f8674a = com7Var;
        }

        @Override // p024Com2.lpt3
        public boolean a(View view, AccessibilityEvent accessibilityEvent) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            return lpt3Var != null ? lpt3Var.a(view, accessibilityEvent) : super.a(view, accessibilityEvent);
        }

        @Override // p024Com2.lpt3
        public f2 b(View view) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            return lpt3Var != null ? lpt3Var.b(view) : super.b(view);
        }

        @Override // p024Com2.lpt3
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            if (lpt3Var != null) {
                lpt3Var.f(view, accessibilityEvent);
            } else {
                super.f(view, accessibilityEvent);
            }
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            if (this.f8674a.o() || this.f8674a.f8673a.getLayoutManager() == null) {
                super.g(view, e2Var);
                return;
            }
            this.f8674a.f8673a.getLayoutManager().O0(view, e2Var);
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            if (lpt3Var != null) {
                lpt3Var.g(view, e2Var);
            } else {
                super.g(view, e2Var);
            }
        }

        @Override // p024Com2.lpt3
        public void h(View view, AccessibilityEvent accessibilityEvent) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            if (lpt3Var != null) {
                lpt3Var.h(view, accessibilityEvent);
            } else {
                super.h(view, accessibilityEvent);
            }
        }

        @Override // p024Com2.lpt3
        public boolean i(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(viewGroup);
            return lpt3Var != null ? lpt3Var.i(viewGroup, view, accessibilityEvent) : super.i(viewGroup, view, accessibilityEvent);
        }

        @Override // p024Com2.lpt3
        public boolean j(View view, int i2, Bundle bundle) {
            if (this.f8674a.o() || this.f8674a.f8673a.getLayoutManager() == null) {
                return super.j(view, i2, bundle);
            }
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            if (lpt3Var != null) {
                if (lpt3Var.j(view, i2, bundle)) {
                    return true;
                }
            } else if (super.j(view, i2, bundle)) {
                return true;
            }
            return this.f8674a.f8673a.getLayoutManager().i1(view, i2, bundle);
        }

        @Override // p024Com2.lpt3
        public void l(View view, int i2) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            if (lpt3Var != null) {
                lpt3Var.l(view, i2);
            } else {
                super.l(view, i2);
            }
        }

        @Override // p024Com2.lpt3
        public void m(View view, AccessibilityEvent accessibilityEvent) {
            p024Com2.lpt3 lpt3Var = this.f2874a.get(view);
            if (lpt3Var != null) {
                lpt3Var.m(view, accessibilityEvent);
            } else {
                super.m(view, accessibilityEvent);
            }
        }

        public p024Com2.lpt3 n(View view) {
            return this.f2874a.remove(view);
        }

        public void o(View view) {
            p024Com2.lpt3 lpt3VarK = y.k(view);
            if (lpt3VarK == null || lpt3VarK == this) {
                return;
            }
            this.f2874a.put(view, lpt3VarK);
        }
    }

    public com7(RecyclerView recyclerView) {
        this.f8673a = recyclerView;
        p024Com2.lpt3 lpt3VarN = n();
        if (lpt3VarN == null || !(lpt3VarN instanceof aux)) {
            this.f2873a = new aux(this);
        } else {
            this.f2873a = (aux) lpt3VarN;
        }
    }

    @Override // p024Com2.lpt3
    public void f(View view, AccessibilityEvent accessibilityEvent) {
        super.f(view, accessibilityEvent);
        if (!(view instanceof RecyclerView) || o()) {
            return;
        }
        RecyclerView recyclerView = (RecyclerView) view;
        if (recyclerView.getLayoutManager() != null) {
            recyclerView.getLayoutManager().K0(accessibilityEvent);
        }
    }

    @Override // p024Com2.lpt3
    public void g(View view, e2 e2Var) {
        super.g(view, e2Var);
        if (o() || this.f8673a.getLayoutManager() == null) {
            return;
        }
        this.f8673a.getLayoutManager().N0(e2Var);
    }

    @Override // p024Com2.lpt3
    public boolean j(View view, int i2, Bundle bundle) {
        if (super.j(view, i2, bundle)) {
            return true;
        }
        if (o() || this.f8673a.getLayoutManager() == null) {
            return false;
        }
        return this.f8673a.getLayoutManager().g1(i2, bundle);
    }

    public p024Com2.lpt3 n() {
        return this.f2873a;
    }

    public boolean o() {
        return this.f8673a.m0();
    }
}
