package LPT9;

import f.com8;
import m.lpt2;

/* JADX INFO: loaded from: classes.dex */
public final class con {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f6822a;

    /* JADX WARN: Code duplicated, block: B:34:0x00b7 A[Catch: ClassCastException -> 0x00bc, ClassNotFoundException -> 0x00f2, TRY_ENTER, TryCatch #4 {ClassCastException -> 0x00bc, blocks: (B:34:0x00b7, B:37:0x00be, B:38:0x00c3), top: B:64:0x00b5, outer: #2 }] */
    /* JADX WARN: Code duplicated, block: B:37:0x00be A[Catch: ClassCastException -> 0x00bc, ClassNotFoundException -> 0x00f2, TryCatch #4 {ClassCastException -> 0x00bc, blocks: (B:34:0x00b7, B:37:0x00be, B:38:0x00c3), top: B:64:0x00b5, outer: #2 }] */
    /* JADX WARN: Code duplicated, block: B:63:0x00ac A[EXC_TOP_SPLITTER, SYNTHETIC] */
    static {
        aux auxVar;
        Object objNewInstance;
        int iA = a();
        if (iA >= 65544 || iA < 65536) {
            try {
                Object objNewInstance2 = b.aux.class.newInstance();
                com8.d(objNewInstance2, "forName(\"kotlin.internal…entations\").newInstance()");
                try {
                    try {
                        if (objNewInstance2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                        }
                        auxVar = (aux) objNewInstance2;
                    } catch (ClassCastException e2) {
                        ClassLoader classLoader = objNewInstance2.getClass().getClassLoader();
                        ClassLoader classLoader2 = aux.class.getClassLoader();
                        if (com8.a(classLoader, classLoader2)) {
                            throw e2;
                        }
                        throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader + ", base type classloader: " + classLoader2, e2);
                    }
                } catch (ClassNotFoundException unused) {
                    if (iA < 65543) {
                        try {
                            try {
                                objNewInstance = a.aux.class.newInstance();
                                com8.d(objNewInstance, "forName(\"kotlin.internal…entations\").newInstance()");
                                try {
                                    if (objNewInstance == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                                    }
                                    auxVar = (aux) objNewInstance;
                                } catch (ClassCastException e3) {
                                    ClassLoader classLoader3 = objNewInstance.getClass().getClassLoader();
                                    ClassLoader classLoader4 = aux.class.getClassLoader();
                                    if (com8.a(classLoader3, classLoader4)) {
                                        throw e3;
                                    }
                                    throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader3 + ", base type classloader: " + classLoader4, e3);
                                }
                            } catch (ClassNotFoundException unused2) {
                                Object objNewInstance3 = Class.forName("kotlin.internal.JRE7PlatformImplementations").newInstance();
                                com8.d(objNewInstance3, "forName(\"kotlin.internal…entations\").newInstance()");
                                try {
                                    if (objNewInstance3 == null) {
                                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                                    }
                                    auxVar = (aux) objNewInstance3;
                                } catch (ClassCastException e4) {
                                    ClassLoader classLoader5 = objNewInstance3.getClass().getClassLoader();
                                    ClassLoader classLoader6 = aux.class.getClassLoader();
                                    if (com8.a(classLoader5, classLoader6)) {
                                        throw e4;
                                    }
                                    throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader5 + ", base type classloader: " + classLoader6, e4);
                                }
                            }
                        } catch (ClassNotFoundException unused3) {
                            auxVar = new aux();
                        }
                    } else {
                        objNewInstance = a.aux.class.newInstance();
                        com8.d(objNewInstance, "forName(\"kotlin.internal…entations\").newInstance()");
                        if (objNewInstance == null) {
                            throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                        }
                        auxVar = (aux) objNewInstance;
                    }
                }
            } catch (ClassNotFoundException unused4) {
                Object objNewInstance4 = Class.forName("kotlin.internal.JRE8PlatformImplementations").newInstance();
                com8.d(objNewInstance4, "forName(\"kotlin.internal…entations\").newInstance()");
                try {
                    if (objNewInstance4 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                    }
                    auxVar = (aux) objNewInstance4;
                } catch (ClassCastException e5) {
                    ClassLoader classLoader7 = objNewInstance4.getClass().getClassLoader();
                    ClassLoader classLoader8 = aux.class.getClassLoader();
                    if (com8.a(classLoader7, classLoader8)) {
                        throw e5;
                    }
                    throw new ClassNotFoundException("Instance class was loaded from a different classloader: " + classLoader7 + ", base type classloader: " + classLoader8, e5);
                }
            }
        } else if (iA < 65543 || iA < 65536) {
            objNewInstance = a.aux.class.newInstance();
            com8.d(objNewInstance, "forName(\"kotlin.internal…entations\").newInstance()");
            if (objNewInstance == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
            }
            auxVar = (aux) objNewInstance;
        } else {
            auxVar = new aux();
        }
        f6822a = auxVar;
    }

    public static final int a() {
        String property = System.getProperty("java.specification.version");
        if (property == null) {
            return 65542;
        }
        int iR = lpt2.R(property, '.', 0, false, 6, null);
        if (iR < 0) {
            try {
                return Integer.parseInt(property) * 65536;
            } catch (NumberFormatException unused) {
                return 65542;
            }
        }
        int i2 = iR + 1;
        int iR2 = lpt2.R(property, '.', i2, false, 4, null);
        if (iR2 < 0) {
            iR2 = property.length();
        }
        String strSubstring = property.substring(0, iR);
        com8.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        String strSubstring2 = property.substring(i2, iR2);
        com8.d(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
        try {
            return (Integer.parseInt(strSubstring) * 65536) + Integer.parseInt(strSubstring2);
        } catch (NumberFormatException unused2) {
            return 65542;
        }
    }
}
