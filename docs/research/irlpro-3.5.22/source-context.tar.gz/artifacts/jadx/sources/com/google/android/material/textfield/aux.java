package com.google.android.material.textfield;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import p033LPt1.d;
import p075cOM6.a4;
import p075cOM6.f4;

/* JADX INFO: loaded from: classes.dex */
public class aux extends d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AnimatorSet f9641a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3719a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextWatcher f3720a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnFocusChangeListener f3721a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout.com2 f3722a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout.com3 f3723a;

    /* JADX INFO: renamed from: com.google.android.material.textfield.aux$aux, reason: collision with other inner class name */
    public class C0060aux implements TextWatcher {
        public C0060aux() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (((d) aux.this).f958a.getSuffixText() != null) {
                return;
            }
            aux auxVar = aux.this;
            auxVar.i(auxVar.m());
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }
    }

    public class com1 implements View.OnClickListener {
        public com1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Editable text = ((d) aux.this).f958a.getEditText().getText();
            if (text != null) {
                text.clear();
            }
            ((d) aux.this).f958a.U();
        }
    }

    public class com2 extends AnimatorListenerAdapter {
        public com2() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            ((d) aux.this).f958a.setEndIconVisible(true);
        }
    }

    public class com3 extends AnimatorListenerAdapter {
        public com3() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ((d) aux.this).f958a.setEndIconVisible(false);
        }
    }

    public class com4 implements ValueAnimator.AnimatorUpdateListener {
        public com4() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((d) aux.this).f957a.setAlpha(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    public class com5 implements ValueAnimator.AnimatorUpdateListener {
        public com5() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            ((d) aux.this).f957a.setScaleX(fFloatValue);
            ((d) aux.this).f957a.setScaleY(fFloatValue);
        }
    }

    public class con implements View.OnFocusChangeListener {
        public con() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z2) {
            aux auxVar = aux.this;
            auxVar.i(auxVar.m());
        }
    }

    public class nul implements TextInputLayout.com2 {
        public nul() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com2
        public void a(TextInputLayout textInputLayout) {
            EditText editText = textInputLayout.getEditText();
            textInputLayout.setEndIconVisible(aux.this.m());
            editText.setOnFocusChangeListener(aux.this.f3721a);
            aux auxVar = aux.this;
            ((d) auxVar).f957a.setOnFocusChangeListener(auxVar.f3721a);
            editText.removeTextChangedListener(aux.this.f3720a);
            editText.addTextChangedListener(aux.this.f3720a);
        }
    }

    public class prn implements TextInputLayout.com3 {

        /* JADX INFO: renamed from: com.google.android.material.textfield.aux$prn$aux, reason: collision with other inner class name */
        public class RunnableC0061aux implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ EditText f9651a;

            public RunnableC0061aux(EditText editText) {
                this.f9651a = editText;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.f9651a.removeTextChangedListener(aux.this.f3720a);
                aux.this.i(true);
            }
        }

        public prn() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com3
        public void a(TextInputLayout textInputLayout, int i2) {
            EditText editText = textInputLayout.getEditText();
            if (editText == null || i2 != 2) {
                return;
            }
            editText.post(new RunnableC0061aux(editText));
            if (editText.getOnFocusChangeListener() == aux.this.f3721a) {
                editText.setOnFocusChangeListener(null);
            }
            if (((d) aux.this).f957a.getOnFocusChangeListener() == aux.this.f3721a) {
                ((d) aux.this).f957a.setOnFocusChangeListener(null);
            }
        }
    }

    public aux(TextInputLayout textInputLayout, int i2) {
        super(textInputLayout, i2);
        this.f3720a = new C0060aux();
        this.f3721a = new con();
        this.f3722a = new nul();
        this.f3723a = new prn();
    }

    @Override // p033LPt1.d
    public void a() {
        TextInputLayout textInputLayout = ((d) this).f958a;
        int i2 = ((d) this).f6824a;
        if (i2 == 0) {
            i2 = a4.f8873f;
        }
        textInputLayout.setEndIconDrawable(i2);
        TextInputLayout textInputLayout2 = ((d) this).f958a;
        textInputLayout2.setEndIconContentDescription(textInputLayout2.getResources().getText(f4.f8934e));
        ((d) this).f958a.setEndIconCheckable(false);
        ((d) this).f958a.setEndIconOnClickListener(new com1());
        ((d) this).f958a.g(this.f3722a);
        ((d) this).f958a.h(this.f3723a);
        l();
    }

    @Override // p033LPt1.d
    public void c(boolean z2) {
        if (((d) this).f958a.getSuffixText() == null) {
            return;
        }
        i(z2);
    }

    public final void i(boolean z2) {
        boolean z3 = ((d) this).f958a.K() == z2;
        if (z2 && !this.f9641a.isRunning()) {
            this.f3719a.cancel();
            this.f9641a.start();
            if (z3) {
                this.f9641a.end();
                return;
            }
            return;
        }
        if (z2) {
            return;
        }
        this.f9641a.cancel();
        this.f3719a.start();
        if (z3) {
            this.f3719a.end();
        }
    }

    public final ValueAnimator j(float... fArr) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(fArr);
        valueAnimatorOfFloat.setInterpolator(COM6.aux.f5700a);
        valueAnimatorOfFloat.setDuration(100L);
        valueAnimatorOfFloat.addUpdateListener(new com4());
        return valueAnimatorOfFloat;
    }

    public final ValueAnimator k() {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.8f, 1.0f);
        valueAnimatorOfFloat.setInterpolator(COM6.aux.f5703d);
        valueAnimatorOfFloat.setDuration(150L);
        valueAnimatorOfFloat.addUpdateListener(new com5());
        return valueAnimatorOfFloat;
    }

    public final void l() {
        ValueAnimator valueAnimatorK = k();
        ValueAnimator valueAnimatorJ = j(0.0f, 1.0f);
        AnimatorSet animatorSet = new AnimatorSet();
        this.f9641a = animatorSet;
        animatorSet.playTogether(valueAnimatorK, valueAnimatorJ);
        this.f9641a.addListener(new com2());
        ValueAnimator valueAnimatorJ2 = j(1.0f, 0.0f);
        this.f3719a = valueAnimatorJ2;
        valueAnimatorJ2.addListener(new com3());
    }

    public final boolean m() {
        EditText editText = ((d) this).f958a.getEditText();
        return editText != null && (editText.hasFocus() || ((d) this).f957a.hasFocus()) && editText.getText().length() > 0;
    }
}
