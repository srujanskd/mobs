package COM4;

import COM3.com7;
import androidx.savedstate.SavedStateRegistry;

/* JADX INFO: loaded from: classes.dex */
public interface con extends com7 {
    SavedStateRegistry getSavedStateRegistry();
}
