package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.List;
import p024Com2.y;
import p077cOM8.com1;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public abstract class ExpandableBehavior extends CoordinatorLayout.nul<View> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9722a;

    public class aux implements ViewTreeObserver.OnPreDrawListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9723a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f3810a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com1 f3811a;

        public aux(View view, int i2, com1 com1Var) {
            this.f3810a = view;
            this.f9723a = i2;
            this.f3811a = com1Var;
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            this.f3810a.getViewTreeObserver().removeOnPreDrawListener(this);
            if (ExpandableBehavior.this.f9722a == this.f9723a) {
                ExpandableBehavior expandableBehavior = ExpandableBehavior.this;
                com1 com1Var = this.f3811a;
                expandableBehavior.H((View) com1Var, this.f3810a, com1Var.a(), false);
            }
            return false;
        }
    }

    public ExpandableBehavior() {
        this.f9722a = 0;
    }

    public final boolean F(boolean z2) {
        if (!z2) {
            return this.f9722a == 1;
        }
        int i2 = this.f9722a;
        return i2 == 0 || i2 == 2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public com1 G(CoordinatorLayout coordinatorLayout, View view) {
        List<View> listR = coordinatorLayout.r(view);
        int size = listR.size();
        for (int i2 = 0; i2 < size; i2++) {
            View view2 = listR.get(i2);
            if (e(coordinatorLayout, view, view2)) {
                return (com1) view2;
            }
        }
        return null;
    }

    public abstract boolean H(View view, View view2, boolean z2, boolean z3);

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public abstract boolean e(CoordinatorLayout coordinatorLayout, View view, View view2);

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean h(CoordinatorLayout coordinatorLayout, View view, View view2) {
        com1 com1Var = (com1) view2;
        if (!F(com1Var.a())) {
            return false;
        }
        this.f9722a = com1Var.a() ? 1 : 2;
        return H((View) com1Var, view, com1Var.a(), true);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean l(CoordinatorLayout coordinatorLayout, View view, int i2) {
        com1 com1VarG;
        if (y.S(view) || (com1VarG = G(coordinatorLayout, view)) == null || !F(com1VarG.a())) {
            return false;
        }
        int i3 = com1VarG.a() ? 1 : 2;
        this.f9722a = i3;
        view.getViewTreeObserver().addOnPreDrawListener(new aux(view, i3, com1VarG));
        return false;
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f9722a = 0;
    }
}
