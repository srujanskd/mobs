package androidx.core.widget;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.preference.Preference;
import com.newrelic.agent.android.analytics.AnalyticsEvent;
import java.util.ArrayList;
import p024Com2.lpt3;
import p024Com2.m;
import p024Com2.n;
import p024Com2.o;
import p024Com2.q;
import p024Com2.r;
import p024Com2.y;
import p064PrN.com3;
import p081cOm2.e2;
import p081cOm2.g2;

/* JADX INFO: loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements q, n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f8173a = new aux();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f8174c = {R.attr.fillViewport};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f2312a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2313a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f2314a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final o f2315a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final r f2316a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f2317a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public VelocityTracker f2318a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f2319a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public EdgeEffect f2320a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public OverScroller f2321a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f2322a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f2323a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2324a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8175b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public EdgeEffect f2325b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2326b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int[] f2327b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f2328c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2329c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8176d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2330d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f8177e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2331e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8178f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f2332f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8179g;

    public static class aux extends lpt3 {
        @Override // p024Com2.lpt3
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            g2.a(accessibilityEvent, nestedScrollView.getScrollX());
            g2.b(accessibilityEvent, nestedScrollView.getScrollRange());
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            int scrollRange;
            super.g(view, e2Var);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            e2Var.T(ScrollView.class.getName());
            if (!nestedScrollView.isEnabled() || (scrollRange = nestedScrollView.getScrollRange()) <= 0) {
                return;
            }
            e2Var.p0(true);
            if (nestedScrollView.getScrollY() > 0) {
                e2Var.b(e2.aux.f9110n);
                e2Var.b(e2.aux.f9121y);
            }
            if (nestedScrollView.getScrollY() < scrollRange) {
                e2Var.b(e2.aux.f9109m);
                e2Var.b(e2.aux.A);
            }
        }

        @Override // p024Com2.lpt3
        public boolean j(View view, int i2, Bundle bundle) {
            if (super.j(view, i2, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            int height = nestedScrollView.getHeight();
            Rect rect = new Rect();
            if (nestedScrollView.getMatrix().isIdentity() && nestedScrollView.getGlobalVisibleRect(rect)) {
                height = rect.height();
            }
            if (i2 != 4096) {
                if (i2 == 8192 || i2 == 16908344) {
                    int iMax = Math.max(nestedScrollView.getScrollY() - ((height - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (iMax == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.Q(0, iMax, true);
                    return true;
                }
                if (i2 != 16908346) {
                    return false;
                }
            }
            int iMin = Math.min(nestedScrollView.getScrollY() + ((height - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
            if (iMin == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.Q(0, iMin, true);
            return true;
        }
    }

    public static class con {
        public static boolean a(ViewGroup viewGroup) {
            return viewGroup.getClipToPadding();
        }
    }

    public interface nul {
        void a(NestedScrollView nestedScrollView, int i2, int i3, int i4, int i5);
    }

    public static class prn extends View.BaseSavedState {
        public static final Parcelable.Creator<prn> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8180a;

        public class aux implements Parcelable.Creator<prn> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public prn createFromParcel(Parcel parcel) {
                return new prn(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public prn[] newArray(int i2) {
                return new prn[i2];
            }
        }

        public prn(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "HorizontalScrollView.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " scrollPosition=" + this.f8180a + "}";
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f8180a);
        }

        public prn(Parcel parcel) {
            super(parcel);
            this.f8180a = parcel.readInt();
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.f7490c);
    }

    public static boolean B(View view, View view2) {
        if (view == view2) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && B((View) parent, view2);
    }

    public static int e(int i2, int i3, int i4) {
        if (i3 >= i4 || i2 < 0) {
            return 0;
        }
        return i3 + i2 > i4 ? i4 - i3 : i2;
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f2312a == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f2312a = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f2312a;
    }

    public final boolean A(View view) {
        return !C(view, 0, getHeight());
    }

    public final boolean C(View view, int i2, int i3) {
        view.getDrawingRect(this.f2317a);
        offsetDescendantRectToMyCoords(view, this.f2317a);
        return this.f2317a.bottom + i2 >= getScrollY() && this.f2317a.top - i2 <= getScrollY() + i3;
    }

    public final void D(int i2, int i3, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i2);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f2315a.e(0, scrollY2, 0, i2 - scrollY2, null, i3, iArr);
    }

    public final void E(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f8177e) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.f2313a = (int) motionEvent.getY(i2);
            this.f8177e = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.f2318a;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public boolean F(int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, boolean z2) {
        boolean z3;
        boolean z4;
        int overScrollMode = getOverScrollMode();
        boolean z5 = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean z6 = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean z7 = overScrollMode == 0 || (overScrollMode == 1 && z5);
        boolean z8 = overScrollMode == 0 || (overScrollMode == 1 && z6);
        int i10 = i4 + i2;
        int i11 = !z7 ? 0 : i8;
        int i12 = i5 + i3;
        int i13 = !z8 ? 0 : i9;
        int i14 = -i11;
        int i15 = i11 + i6;
        int i16 = -i13;
        int i17 = i13 + i7;
        if (i10 > i15) {
            i10 = i15;
            z3 = true;
        } else if (i10 < i14) {
            z3 = true;
            i10 = i14;
        } else {
            z3 = false;
        }
        if (i12 > i17) {
            i12 = i17;
            z4 = true;
        } else if (i12 < i16) {
            z4 = true;
            i12 = i16;
        } else {
            z4 = false;
        }
        if (z4 && !v(1)) {
            this.f2321a.springBack(i10, i12, 0, 0, 0, getScrollRange());
        }
        onOverScrolled(i10, i12, z3, z4);
        return z3 || z4;
    }

    public boolean G(int i2) {
        boolean z2 = i2 == 130;
        int height = getHeight();
        if (z2) {
            this.f2317a.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
                Rect rect = this.f2317a;
                if (rect.top + height > bottom) {
                    rect.top = bottom - height;
                }
            }
        } else {
            this.f2317a.top = getScrollY() - height;
            Rect rect2 = this.f2317a;
            if (rect2.top < 0) {
                rect2.top = 0;
            }
        }
        Rect rect3 = this.f2317a;
        int i3 = rect3.top;
        int i4 = height + i3;
        rect3.bottom = i4;
        return K(i2, i3, i4);
    }

    public final void H() {
        VelocityTracker velocityTracker = this.f2318a;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f2318a = null;
        }
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0060  */
    public final int I(int i2, float f2) {
        float fD;
        int iRound;
        float width = f2 / getWidth();
        float height = i2 / getHeight();
        float f3 = 0.0f;
        if (p014CoM2.com3.b(this.f2320a) == 0.0f) {
            if (p014CoM2.com3.b(this.f2325b) != 0.0f) {
                fD = p014CoM2.com3.d(this.f2325b, height, 1.0f - width);
                if (p014CoM2.com3.b(this.f2325b) == 0.0f) {
                    this.f2325b.onRelease();
                }
            }
            iRound = Math.round(f3 * getHeight());
            if (iRound != 0) {
                invalidate();
            }
            return iRound;
        }
        fD = -p014CoM2.com3.d(this.f2320a, -height, width);
        if (p014CoM2.com3.b(this.f2320a) == 0.0f) {
            this.f2320a.onRelease();
        }
        f3 = fD;
        iRound = Math.round(f3 * getHeight());
        if (iRound != 0) {
            invalidate();
        }
        return iRound;
    }

    public final void J(boolean z2) {
        if (z2) {
            R(2, 1);
        } else {
            T(1);
        }
        this.f8179g = getScrollY();
        y.f0(this);
    }

    public final boolean K(int i2, int i3, int i4) {
        int height = getHeight();
        int scrollY = getScrollY();
        int i5 = height + scrollY;
        boolean z2 = false;
        boolean z3 = i2 == 33;
        View viewS = s(z3, i3, i4);
        if (viewS == null) {
            viewS = this;
        }
        if (i3 < scrollY || i4 > i5) {
            n(z3 ? i3 - scrollY : i4 - i5);
            z2 = true;
        }
        if (viewS != findFocus()) {
            viewS.requestFocus(i2);
        }
        return z2;
    }

    public final void L(View view) {
        view.getDrawingRect(this.f2317a);
        offsetDescendantRectToMyCoords(view, this.f2317a);
        int iF = f(this.f2317a);
        if (iF != 0) {
            scrollBy(0, iF);
        }
    }

    public final boolean M(Rect rect, boolean z2) {
        int iF = f(rect);
        boolean z3 = iF != 0;
        if (z3) {
            if (z2) {
                scrollBy(0, iF);
            } else {
                N(0, iF);
            }
        }
        return z3;
    }

    public final void N(int i2, int i3) {
        O(i2, i3, AnalyticsEvent.EVENT_TYPE_LIMIT, false);
    }

    public final void O(int i2, int i3, int i4, boolean z2) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f2314a > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            this.f2321a.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i3 + scrollY, Math.max(0, height - height2))) - scrollY, i4);
            J(z2);
        } else {
            if (!this.f2321a.isFinished()) {
                a();
            }
            scrollBy(i2, i3);
        }
        this.f2314a = AnimationUtils.currentAnimationTimeMillis();
    }

    public void P(int i2, int i3, int i4, boolean z2) {
        O(i2 - getScrollX(), i3 - getScrollY(), i4, z2);
    }

    public void Q(int i2, int i3, boolean z2) {
        P(i2, i3, AnalyticsEvent.EVENT_TYPE_LIMIT, z2);
    }

    public boolean R(int i2, int i3) {
        return this.f2315a.p(i2, i3);
    }

    public final boolean S(MotionEvent motionEvent) {
        boolean z2;
        if (p014CoM2.com3.b(this.f2320a) != 0.0f) {
            p014CoM2.com3.d(this.f2320a, 0.0f, motionEvent.getX() / getWidth());
            z2 = true;
        } else {
            z2 = false;
        }
        if (p014CoM2.com3.b(this.f2325b) == 0.0f) {
            return z2;
        }
        p014CoM2.com3.d(this.f2325b, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public void T(int i2) {
        this.f2315a.r(i2);
    }

    public final void a() {
        this.f2321a.abortAnimation();
        T(1);
    }

    @Override // android.view.ViewGroup
    public void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    public boolean b(int i2) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i2);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !C(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i2 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i2 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getScrollY() + getHeight()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i2 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            n(maxScrollAmount);
        } else {
            viewFindNextFocus.getDrawingRect(this.f2317a);
            offsetDescendantRectToMyCoords(viewFindNextFocus, this.f2317a);
            n(f(this.f2317a));
            viewFindNextFocus.requestFocus(i2);
        }
        if (viewFindFocus == null || !viewFindFocus.isFocused() || !A(viewFindFocus)) {
            return true;
        }
        int descendantFocusability = getDescendantFocusability();
        setDescendantFocusability(inet.ipaddr.format.validate.aux.KEY_SINGLE_WILDCARD);
        requestFocus();
        setDescendantFocusability(descendantFocusability);
        return true;
    }

    public final boolean c() {
        int overScrollMode = getOverScrollMode();
        if (overScrollMode != 0) {
            return overScrollMode == 1 && getScrollRange() > 0;
        }
        return true;
    }

    @Override // android.view.View
    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    @Override // android.view.View
    public void computeScroll() {
        if (this.f2321a.isFinished()) {
            return;
        }
        this.f2321a.computeScrollOffset();
        int currY = this.f2321a.getCurrY();
        int i2 = currY - this.f8179g;
        this.f8179g = currY;
        int[] iArr = this.f2327b;
        boolean z2 = false;
        iArr[1] = 0;
        g(0, i2, iArr, null, 1);
        int i3 = i2 - this.f2327b[1];
        int scrollRange = getScrollRange();
        if (i3 != 0) {
            int scrollY = getScrollY();
            F(0, i3, getScrollX(), scrollY, 0, scrollRange, 0, 0, false);
            int scrollY2 = getScrollY() - scrollY;
            int i4 = i3 - scrollY2;
            int[] iArr2 = this.f2327b;
            iArr2[1] = 0;
            h(0, scrollY2, 0, i4, this.f2324a, 1, iArr2);
            i3 = i4 - this.f2327b[1];
        }
        if (i3 != 0) {
            int overScrollMode = getOverScrollMode();
            if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                z2 = true;
            }
            if (z2) {
                if (i3 < 0) {
                    if (this.f2320a.isFinished()) {
                        this.f2320a.onAbsorb((int) this.f2321a.getCurrVelocity());
                    }
                } else if (this.f2325b.isFinished()) {
                    this.f2325b.onAbsorb((int) this.f2321a.getCurrVelocity());
                }
            }
            a();
        }
        if (this.f2321a.isFinished()) {
            T(1);
        } else {
            y.f0(this);
        }
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? bottom + (scrollY - iMax) : bottom;
    }

    public final boolean d() {
        if (getChildCount() <= 0) {
            return false;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || r(keyEvent);
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return this.f2315a.a(f2, f3, z2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return this.f2315a.b(f2, f3);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return g(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.f2315a.f(i2, i3, i4, i5, iArr);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        int paddingLeft2 = 0;
        if (!this.f2320a.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (con.a(this)) {
                width -= getPaddingLeft() + getPaddingRight();
                paddingLeft = getPaddingLeft() + 0;
            } else {
                paddingLeft = 0;
            }
            if (con.a(this)) {
                height -= getPaddingTop() + getPaddingBottom();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            this.f2320a.setSize(width, height);
            if (this.f2320a.draw(canvas)) {
                y.f0(this);
            }
            canvas.restoreToCount(iSave);
        }
        if (this.f2325b.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (con.a(this)) {
            width2 -= getPaddingLeft() + getPaddingRight();
            paddingLeft2 = 0 + getPaddingLeft();
        }
        if (con.a(this)) {
            height2 -= getPaddingTop() + getPaddingBottom();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        this.f2325b.setSize(width2, height2);
        if (this.f2325b.draw(canvas)) {
            y.f0(this);
        }
        canvas.restoreToCount(iSave2);
    }

    public int f(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i2 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i3 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i2 - verticalFadingEdgeLength : i2;
        int i4 = rect.bottom;
        if (i4 > i3 && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i3) + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i2);
        }
        if (rect.top >= scrollY || i4 >= i3) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i3 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    public boolean g(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return this.f2315a.d(i2, i3, iArr, iArr2, i4);
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.f2316a.a();
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public void h(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        this.f2315a.e(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return v(0);
    }

    @Override // p024Com2.p
    public void i(View view, int i2, int i3, int i4, int i5, int i6) {
        D(i5, i6, null);
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return this.f2315a.l();
    }

    @Override // p024Com2.p
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        g(i2, i3, iArr, null, i4);
    }

    @Override // p024Com2.p
    public void k(View view, int i2) {
        this.f2316a.d(view, i2);
        T(i2);
    }

    @Override // p024Com2.q
    public void l(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        D(i5, i6, iArr);
    }

    @Override // p024Com2.p
    public void m(View view, View view2, int i2, int i3) {
        this.f2316a.c(view, view2, i2, i3);
        R(2, i3);
    }

    @Override // android.view.ViewGroup
    public void measureChild(View view, int i2, int i3) {
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight(), view.getLayoutParams().width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public void measureChildWithMargins(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i2) {
        if (i2 != 0) {
            if (this.f2332f) {
                N(0, i2);
            } else {
                scrollBy(0, i2);
            }
        }
    }

    @Override // p024Com2.p
    public boolean o(View view, View view2, int i2, int i3) {
        return (i2 & 2) != 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2329c = false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float axisValue;
        boolean z2;
        int i2 = 0;
        if (motionEvent.getAction() == 8 && !this.f2330d) {
            if (m.a(motionEvent, 2)) {
                axisValue = motionEvent.getAxisValue(9);
            } else {
                axisValue = m.a(motionEvent, inet.ipaddr.format.validate.aux.KEY_INFERRED_UPPER_BOUNDARY) ? motionEvent.getAxisValue(26) : 0.0f;
            }
            if (axisValue != 0.0f) {
                int verticalScrollFactorCompat = (int) (axisValue * getVerticalScrollFactorCompat());
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int i3 = scrollY - verticalScrollFactorCompat;
                if (i3 < 0) {
                    if (c() && !m.a(motionEvent, 8194)) {
                        p014CoM2.com3.d(this.f2320a, (-i3) / getHeight(), 0.5f);
                        this.f2320a.onRelease();
                        invalidate();
                        z2 = 1;
                    } else {
                        z2 = 0;
                    }
                } else if (i3 > scrollRange) {
                    if (c() && !m.a(motionEvent, 8194)) {
                        p014CoM2.com3.d(this.f2325b, (i3 - scrollRange) / getHeight(), 0.5f);
                        this.f2325b.onRelease();
                        invalidate();
                        i2 = 1;
                    }
                    z2 = i2;
                    i2 = scrollRange;
                } else {
                    z2 = 0;
                    i2 = i3;
                }
                if (i2 == scrollY) {
                    return z2;
                }
                super.scrollTo(getScrollX(), i2);
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:31:0x007e  */
    /* JADX WARN: Code duplicated, block: B:33:0x009c  */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        boolean z2 = true;
        if (action == 2 && this.f2330d) {
            return true;
        }
        int i2 = action & 255;
        if (i2 == 0) {
            int y2 = (int) motionEvent.getY();
            if (w((int) motionEvent.getX(), y2)) {
                this.f2313a = y2;
                this.f8177e = motionEvent.getPointerId(0);
                x();
                this.f2318a.addMovement(motionEvent);
                this.f2321a.computeScrollOffset();
                if (!S(motionEvent) && this.f2321a.isFinished()) {
                    z2 = false;
                }
                this.f2330d = z2;
                R(2, 0);
            } else {
                if (!S(motionEvent) && this.f2321a.isFinished()) {
                    z2 = false;
                }
                this.f2330d = z2;
                H();
            }
        } else if (i2 == 1) {
            this.f2330d = false;
            this.f8177e = -1;
            H();
            if (this.f2321a.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                y.f0(this);
            }
            T(0);
        } else if (i2 == 2) {
            int i3 = this.f8177e;
            if (i3 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i3);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i3 + " in onInterceptTouchEvent");
                } else {
                    int y3 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y3 - this.f2313a) > this.f8175b && (2 & getNestedScrollAxes()) == 0) {
                        this.f2330d = true;
                        this.f2313a = y3;
                        z();
                        this.f2318a.addMovement(motionEvent);
                        this.f8178f = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i2 == 3) {
            this.f2330d = false;
            this.f8177e = -1;
            H();
            if (this.f2321a.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                y.f0(this);
            }
            T(0);
        } else if (i2 == 6) {
            E(motionEvent);
        }
        return this.f2330d;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        int measuredHeight = 0;
        this.f2326b = false;
        View view = this.f2319a;
        if (view != null && B(view, this)) {
            L(this.f2319a);
        }
        this.f2319a = null;
        if (!this.f2329c) {
            if (this.f2323a != null) {
                scrollTo(getScrollX(), this.f2323a.f8180a);
                this.f2323a = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int iE = e(scrollY, paddingTop, measuredHeight);
            if (iE != scrollY) {
                scrollTo(getScrollX(), iE);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f2329c = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f2331e && View.MeasureSpec.getMode(i3) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (z2) {
            return false;
        }
        dispatchNestedFling(0.0f, f3, true);
        t((int) f3);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return dispatchNestedPreFling(f2, f3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        j(view, i2, i3, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        D(i5, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        m(view, view2, i2, 0);
    }

    @Override // android.view.View
    public void onOverScrolled(int i2, int i3, boolean z2, boolean z3) {
        super.scrollTo(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (i2 == 2) {
            i2 = 130;
        } else if (i2 == 1) {
            i2 = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i2) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i2);
        if (viewFindNextFocus == null || A(viewFindNextFocus)) {
            return false;
        }
        return viewFindNextFocus.requestFocus(i2, rect);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof prn)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        prn prnVar = (prn) parcelable;
        super.onRestoreInstanceState(prnVar.getSuperState());
        this.f2323a = prnVar;
        requestLayout();
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        prn prnVar = new prn(super.onSaveInstanceState());
        prnVar.f8180a = getScrollY();
        return prnVar;
    }

    @Override // android.view.View
    public void onScrollChanged(int i2, int i3, int i4, int i5) {
        super.onScrollChanged(i2, i3, i4, i5);
        nul nulVar = this.f2322a;
        if (nulVar != null) {
            nulVar.a(this, i2, i3, i4, i5);
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !C(viewFindFocus, 0, i5)) {
            return;
        }
        viewFindFocus.getDrawingRect(this.f2317a);
        offsetDescendantRectToMyCoords(viewFindFocus, this.f2317a);
        n(f(this.f2317a));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        return o(view, view2, i2, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        k(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:76:0x01d3  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        z();
        int actionMasked = motionEvent.getActionMasked();
        boolean z2 = false;
        if (actionMasked == 0) {
            this.f8178f = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.offsetLocation(0.0f, this.f8178f);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f2318a;
                velocityTracker.computeCurrentVelocity(1000, this.f8176d);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f8177e);
                if (Math.abs(yVelocity) >= this.f2328c) {
                    if (!p(yVelocity)) {
                        int i2 = -yVelocity;
                        float f2 = i2;
                        if (!dispatchNestedPreFling(0.0f, f2)) {
                            dispatchNestedFling(0.0f, f2, true);
                            t(i2);
                        }
                    }
                } else if (this.f2321a.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    y.f0(this);
                }
                this.f8177e = -1;
                q();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f8177e);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f8177e + " in onTouchEvent");
                } else {
                    int y2 = (int) motionEvent.getY(iFindPointerIndex);
                    int i3 = this.f2313a - y2;
                    int I = i3 - I(i3, motionEvent.getX(iFindPointerIndex));
                    if (!this.f2330d && Math.abs(I) > this.f8175b) {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f2330d = true;
                        I = I > 0 ? I - this.f8175b : I + this.f8175b;
                    }
                    int i4 = I;
                    if (this.f2330d) {
                        if (g(0, i4, this.f2327b, this.f2324a, 0)) {
                            i4 -= this.f2327b[1];
                            this.f8178f += this.f2324a[1];
                        }
                        int i5 = i4;
                        this.f2313a = y2 - this.f2324a[1];
                        int scrollY = getScrollY();
                        int scrollRange = getScrollRange();
                        int overScrollMode = getOverScrollMode();
                        boolean z3 = overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0);
                        boolean z4 = F(0, i5, 0, getScrollY(), 0, scrollRange, 0, 0, true) && !v(0);
                        int scrollY2 = getScrollY() - scrollY;
                        int[] iArr = this.f2327b;
                        iArr[1] = 0;
                        h(0, scrollY2, 0, i5 - scrollY2, this.f2324a, 0, iArr);
                        int i6 = this.f2313a;
                        int i7 = this.f2324a[1];
                        this.f2313a = i6 - i7;
                        this.f8178f += i7;
                        if (z3) {
                            int i8 = i5 - this.f2327b[1];
                            int i9 = scrollY + i8;
                            if (i9 < 0) {
                                p014CoM2.com3.d(this.f2320a, (-i8) / getHeight(), motionEvent.getX(iFindPointerIndex) / getWidth());
                                if (!this.f2325b.isFinished()) {
                                    this.f2325b.onRelease();
                                }
                            } else if (i9 > scrollRange) {
                                p014CoM2.com3.d(this.f2325b, i8 / getHeight(), 1.0f - (motionEvent.getX(iFindPointerIndex) / getWidth()));
                                if (!this.f2320a.isFinished()) {
                                    this.f2320a.onRelease();
                                }
                            }
                            if (this.f2320a.isFinished() && this.f2325b.isFinished()) {
                                z2 = z4;
                            } else {
                                y.f0(this);
                            }
                        } else {
                            z2 = z4;
                        }
                        if (z2) {
                            this.f2318a.clear();
                        }
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f2330d && getChildCount() > 0 && this.f2321a.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    y.f0(this);
                }
                this.f8177e = -1;
                q();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.f2313a = (int) motionEvent.getY(actionIndex);
                this.f8177e = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                E(motionEvent);
                this.f2313a = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f8177e));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.f2330d && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f2321a.isFinished()) {
                a();
            }
            this.f2313a = (int) motionEvent.getY();
            this.f8177e = motionEvent.getPointerId(0);
            R(2, 0);
        }
        VelocityTracker velocityTracker2 = this.f2318a;
        if (velocityTracker2 != null) {
            velocityTracker2.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final boolean p(int i2) {
        if (p014CoM2.com3.b(this.f2320a) != 0.0f) {
            this.f2320a.onAbsorb(i2);
        } else {
            if (p014CoM2.com3.b(this.f2325b) == 0.0f) {
                return false;
            }
            this.f2325b.onAbsorb(-i2);
        }
        return true;
    }

    public final void q() {
        this.f2330d = false;
        H();
        T(0);
        this.f2320a.onRelease();
        this.f2325b.onRelease();
    }

    public boolean r(KeyEvent keyEvent) {
        this.f2317a.setEmpty();
        if (!d()) {
            if (!isFocused() || keyEvent.getKeyCode() == 4) {
                return false;
            }
            View viewFindFocus = findFocus();
            if (viewFindFocus == this) {
                viewFindFocus = null;
            }
            View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
            return (viewFindNextFocus == null || viewFindNextFocus == this || !viewFindNextFocus.requestFocus(130)) ? false : true;
        }
        if (keyEvent.getAction() != 0) {
            return false;
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyCode == 19) {
            return !keyEvent.isAltPressed() ? b(33) : u(33);
        }
        if (keyCode == 20) {
            return !keyEvent.isAltPressed() ? b(130) : u(130);
        }
        if (keyCode != 62) {
            return false;
        }
        G(keyEvent.isShiftPressed() ? 33 : 130);
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        if (this.f2326b) {
            this.f2319a = view2;
        } else {
            L(view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        return M(rect, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z2) {
        if (z2) {
            H();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        this.f2326b = true;
        super.requestLayout();
    }

    /* JADX WARN: Code duplicated, block: B:29:0x004f  */
    public final View s(boolean z2, int i2, int i3) {
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i4 = 0; i4 < size; i4++) {
            View view2 = focusables.get(i4);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i2 < bottom && top < i3) {
                boolean z4 = i2 < top && bottom < i3;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4 && z5) {
                            view = view2;
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (z5) {
                        view = view2;
                    }
                }
            }
        }
        return view;
    }

    @Override // android.view.View
    public void scrollTo(int i2, int i3) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int iE = e(i2, width, width2);
            int iE2 = e(i3, height, height2);
            if (iE == getScrollX() && iE2 == getScrollY()) {
                return;
            }
            super.scrollTo(iE, iE2);
        }
    }

    public void setFillViewport(boolean z2) {
        if (z2 != this.f2331e) {
            this.f2331e = z2;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        this.f2315a.m(z2);
    }

    public void setOnScrollChangeListener(nul nulVar) {
        this.f2322a = nulVar;
    }

    public void setSmoothScrollingEnabled(boolean z2) {
        this.f2332f = z2;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return R(i2, 0);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        T(0);
    }

    public void t(int i2) {
        if (getChildCount() > 0) {
            this.f2321a.fling(getScrollX(), getScrollY(), 0, i2, 0, 0, Integer.MIN_VALUE, Preference.DEFAULT_ORDER, 0, 0);
            J(true);
        }
    }

    public boolean u(int i2) {
        int childCount;
        boolean z2 = i2 == 130;
        int height = getHeight();
        Rect rect = this.f2317a;
        rect.top = 0;
        rect.bottom = height;
        if (z2 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f2317a.bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin + getPaddingBottom();
            Rect rect2 = this.f2317a;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f2317a;
        return K(i2, rect3.top, rect3.bottom);
    }

    public boolean v(int i2) {
        return this.f2315a.k(i2);
    }

    public final boolean w(int i2, int i3) {
        if (getChildCount() <= 0) {
            return false;
        }
        int scrollY = getScrollY();
        View childAt = getChildAt(0);
        return i3 >= childAt.getTop() - scrollY && i3 < childAt.getBottom() - scrollY && i2 >= childAt.getLeft() && i2 < childAt.getRight();
    }

    public final void x() {
        VelocityTracker velocityTracker = this.f2318a;
        if (velocityTracker == null) {
            this.f2318a = VelocityTracker.obtain();
        } else {
            velocityTracker.clear();
        }
    }

    public final void y() {
        this.f2321a = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(inet.ipaddr.format.validate.aux.KEY_STANDARD_STR);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f8175b = viewConfiguration.getScaledTouchSlop();
        this.f2328c = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f8176d = viewConfiguration.getScaledMaximumFlingVelocity();
    }

    public final void z() {
        if (this.f2318a == null) {
            this.f2318a = VelocityTracker.obtain();
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2317a = new Rect();
        this.f2326b = true;
        this.f2329c = false;
        this.f2319a = null;
        this.f2330d = false;
        this.f2332f = true;
        this.f8177e = -1;
        this.f2324a = new int[2];
        this.f2327b = new int[2];
        this.f2320a = p014CoM2.com3.a(context, attributeSet);
        this.f2325b = p014CoM2.com3.a(context, attributeSet);
        y();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f8174c, i2, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f2316a = new r(this);
        this.f2315a = new o(this);
        setNestedScrollingEnabled(true);
        y.o0(this, f8173a);
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2) {
        if (getChildCount() <= 0) {
            super.addView(view, i2);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i2, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }
}
