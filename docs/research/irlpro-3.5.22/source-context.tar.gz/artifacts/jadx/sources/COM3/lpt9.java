package COM3;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class lpt9 {
    public static void a(View view, lpt7 lpt7Var) {
        view.setTag(p026Com4.lpt8.f6503a, lpt7Var);
    }
}
