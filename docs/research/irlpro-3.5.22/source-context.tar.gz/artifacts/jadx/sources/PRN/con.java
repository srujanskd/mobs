package PRN;

import android.content.LocusId;

/* JADX INFO: loaded from: classes.dex */
public final class con {
    public LocusId a() {
        throw null;
    }
}
