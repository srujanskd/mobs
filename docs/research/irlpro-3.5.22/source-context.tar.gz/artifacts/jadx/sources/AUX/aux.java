package AUX;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import p022CoN.h0;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"RestrictedAPI"})
public final class aux {
    public static ColorStateList a(Context context, int i2) {
        return PRN.aux.d(context, i2);
    }

    public static Drawable b(Context context, int i2) {
        return h0.g().i(context, i2);
    }
}
