package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import p014CoM2.lpt1;
import p022CoN.a;
import p022CoN.l;
import p022CoN.l0;
import p022CoN.lpt2;
import p022CoN.lpt9;
import p022CoN.m;
import p022CoN.n0;
import p023Com1.lpt5;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatTextView extends TextView implements p014CoM2.prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final l f7896a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt2 f1999a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt9 f2000a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final m f2001a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Future<COM1.nul> f2002a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f7897b;

    public AppCompatTextView(Context context) {
        this(context, null);
    }

    private lpt9 getEmojiTextViewHelper() {
        if (this.f2000a == null) {
            this.f2000a = new lpt9(this);
        }
        return this.f2000a;
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            lpt2Var.b();
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.b();
        }
    }

    public final void e() {
        Future<COM1.nul> future = this.f2002a;
        if (future != null) {
            try {
                this.f2002a = null;
                lpt1.m(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeMaxTextSize();
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            return mVar.e();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeMinTextSize();
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            return mVar.f();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeStepGranularity();
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            return mVar.g();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        m mVar = this.f2001a;
        return mVar != null ? mVar.h() : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            return mVar.i();
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return lpt1.p(super.getCustomSelectionActionModeCallback());
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return lpt1.b(this);
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return lpt1.c(this);
    }

    public ColorStateList getSupportBackgroundTintList() {
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            return lpt2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            return lpt2Var.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f2001a.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f2001a.k();
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        e();
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        return super.getTextClassifier();
    }

    public COM1.nul.aux getTextMetricsParamsCompat() {
        return lpt1.f(this);
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f2001a.r(this, inputConnectionOnCreateInputConnection, editorInfo);
        return a.a(inputConnectionOnCreateInputConnection, editorInfo, this);
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.o(z2, i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i2, int i3) {
        e();
        super.onMeasure(i2, i3);
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        m mVar = this.f2001a;
        if (mVar == null || p014CoM2.prn.f6142a || !mVar.l()) {
            return;
        }
        this.f2001a.c();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) throws IllegalArgumentException {
        if (p014CoM2.prn.f6142a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.t(i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) throws IllegalArgumentException {
        if (p014CoM2.prn.f6142a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.u(iArr, i2);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (p014CoM2.prn.f6142a) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.v(i2);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            lpt2Var.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            lpt2Var.g(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(lpt1.q(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().e(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i2) {
        super.setFirstBaselineToTopHeight(i2);
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i2) {
        super.setLastBaselineToBottomHeight(i2);
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i2) {
        lpt1.l(this, i2);
    }

    public void setPrecomputedText(COM1.nul nulVar) {
        lpt1.m(this, nulVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            lpt2Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        lpt2 lpt2Var = this.f1999a;
        if (lpt2Var != null) {
            lpt2Var.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f2001a.w(colorStateList);
        this.f2001a.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f2001a.x(mode);
        this.f2001a.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.q(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        super.setTextClassifier(textClassifier);
    }

    public void setTextFuture(Future<COM1.nul> future) {
        this.f2002a = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(COM1.nul.aux auxVar) {
        lpt1.o(this, auxVar);
    }

    @Override // android.widget.TextView
    public void setTextSize(int i2, float f2) {
        if (p014CoM2.prn.f6142a) {
            super.setTextSize(i2, f2);
            return;
        }
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.A(i2, f2);
        }
    }

    @Override // android.widget.TextView
    public void setTypeface(Typeface typeface, int i2) {
        if (this.f7897b) {
            return;
        }
        Typeface typefaceA = (typeface == null || i2 <= 0) ? null : lpt5.a(getContext(), typeface, i2);
        this.f7897b = true;
        if (typefaceA != null) {
            typeface = typefaceA;
        }
        try {
            super.setTypeface(typeface, i2);
        } finally {
            this.f7897b = false;
        }
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet, int i2) {
        super(n0.b(context), attributeSet, i2);
        this.f7897b = false;
        l0.a(this, getContext());
        lpt2 lpt2Var = new lpt2(this);
        this.f1999a = lpt2Var;
        lpt2Var.e(attributeSet, i2);
        m mVar = new m(this);
        this.f2001a = mVar;
        mVar.m(attributeSet, i2);
        mVar.b();
        this.f7896a = new l(this);
        getEmojiTextViewHelper().c(attributeSet, i2);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i2 != 0 ? AUX.aux.b(context, i2) : null, i3 != 0 ? AUX.aux.b(context, i3) : null, i4 != 0 ? AUX.aux.b(context, i4) : null, i5 != 0 ? AUX.aux.b(context, i5) : null);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.p();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i2 != 0 ? AUX.aux.b(context, i2) : null, i3 != 0 ? AUX.aux.b(context, i3) : null, i4 != 0 ? AUX.aux.b(context, i4) : null, i5 != 0 ? AUX.aux.b(context, i5) : null);
        m mVar = this.f2001a;
        if (mVar != null) {
            mVar.p();
        }
    }
}
