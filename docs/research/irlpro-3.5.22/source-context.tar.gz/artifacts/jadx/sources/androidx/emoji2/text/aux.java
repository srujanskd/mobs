package androidx.emoji2.text;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import p070cOM1.u;
import p101com2.u2;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: androidx.emoji2.text.aux$aux, reason: collision with other inner class name */
    public static class C0031aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final con f8184a;

        public C0031aux(con conVar) {
            this.f8184a = conVar == null ? e() : conVar;
        }

        public static con e() {
            return new prn();
        }

        public final androidx.emoji2.text.con.nul a(Context context, u uVar) {
            if (uVar == null) {
                return null;
            }
            return new androidx.emoji2.text.prn(context, uVar);
        }

        public final List<List<byte[]>> b(Signature[] signatureArr) {
            ArrayList arrayList = new ArrayList();
            for (Signature signature : signatureArr) {
                arrayList.add(signature.toByteArray());
            }
            return Collections.singletonList(arrayList);
        }

        public androidx.emoji2.text.con.nul c(Context context) {
            return a(context, h(context));
        }

        public final u d(ProviderInfo providerInfo, PackageManager packageManager) throws PackageManager.NameNotFoundException {
            String str = providerInfo.authority;
            String str2 = providerInfo.packageName;
            return new u(str, str2, "emojicompat-emoji-font", b(this.f8184a.b(packageManager, str2)));
        }

        public final boolean f(ProviderInfo providerInfo) {
            ApplicationInfo applicationInfo;
            return (providerInfo == null || (applicationInfo = providerInfo.applicationInfo) == null || (applicationInfo.flags & 1) != 1) ? false : true;
        }

        public final ProviderInfo g(PackageManager packageManager) {
            Iterator<ResolveInfo> it = this.f8184a.c(packageManager, new Intent("androidx.content.action.LOAD_EMOJI_FONT"), 0).iterator();
            while (it.hasNext()) {
                ProviderInfo providerInfoA = this.f8184a.a(it.next());
                if (f(providerInfoA)) {
                    return providerInfoA;
                }
            }
            return null;
        }

        public u h(Context context) {
            PackageManager packageManager = context.getPackageManager();
            u2.g(packageManager, "Package manager required to locate emoji font provider");
            ProviderInfo providerInfoG = g(packageManager);
            if (providerInfoG == null) {
                return null;
            }
            try {
                return d(providerInfoG, packageManager);
            } catch (PackageManager.NameNotFoundException e2) {
                Log.wtf("emoji2.text.DefaultEmojiConfig", e2);
                return null;
            }
        }
    }

    public static class con {
        public ProviderInfo a(ResolveInfo resolveInfo) {
            throw null;
        }

        public Signature[] b(PackageManager packageManager, String str) throws PackageManager.NameNotFoundException {
            throw null;
        }

        public List<ResolveInfo> c(PackageManager packageManager, Intent intent, int i2) {
            throw null;
        }
    }

    public static class nul extends con {
        @Override // androidx.emoji2.text.aux.con
        public ProviderInfo a(ResolveInfo resolveInfo) {
            return resolveInfo.providerInfo;
        }

        @Override // androidx.emoji2.text.aux.con
        public List<ResolveInfo> c(PackageManager packageManager, Intent intent, int i2) {
            return packageManager.queryIntentContentProviders(intent, i2);
        }
    }

    public static class prn extends nul {
        @Override // androidx.emoji2.text.aux.con
        public Signature[] b(PackageManager packageManager, String str) throws PackageManager.NameNotFoundException {
            return packageManager.getPackageInfo(str, 64).signatures;
        }
    }

    public static androidx.emoji2.text.prn a(Context context) {
        return (androidx.emoji2.text.prn) new C0031aux(null).c(context);
    }
}
