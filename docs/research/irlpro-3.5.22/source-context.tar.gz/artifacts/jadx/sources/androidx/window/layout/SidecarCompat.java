package androidx.window.layout;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.window.sidecar.SidecarDeviceState;
import androidx.window.sidecar.SidecarDisplayFeature;
import androidx.window.sidecar.SidecarInterface;
import androidx.window.sidecar.SidecarProvider;
import androidx.window.sidecar.SidecarWindowLayoutInfo;
import f.com3;
import f.com8;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;
import p028Com6.d3;
import p028Com6.j3;
import p028Com6.s3;
import p059Lpt9.a;
import p105com6.w4;
import p127lPt9.v;

/* JADX INFO: loaded from: classes.dex */
public final class SidecarCompat implements d3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f8777a = new aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public d3.aux f2974a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final j3 f2975a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SidecarInterface f2976a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<IBinder, Activity> f2977a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Map<Activity, ComponentCallbacks> f8778b;

    public static final class DistinctSidecarElementCallback implements SidecarInterface.SidecarCallback {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final j3 f8779a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public SidecarDeviceState f2978a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final SidecarInterface.SidecarCallback f2979a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final WeakHashMap<IBinder, SidecarWindowLayoutInfo> f2980a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final ReentrantLock f2981a;

        public DistinctSidecarElementCallback(j3 j3Var, SidecarInterface.SidecarCallback sidecarCallback) {
            com8.e(j3Var, "sidecarAdapter");
            com8.e(sidecarCallback, "callbackInterface");
            this.f8779a = j3Var;
            this.f2979a = sidecarCallback;
            this.f2981a = new ReentrantLock();
            this.f2980a = new WeakHashMap<>();
        }

        public void onDeviceStateChanged(SidecarDeviceState sidecarDeviceState) {
            com8.e(sidecarDeviceState, "newDeviceState");
            ReentrantLock reentrantLock = this.f2981a;
            reentrantLock.lock();
            try {
                if (this.f8779a.a(this.f2978a, sidecarDeviceState)) {
                    return;
                }
                this.f2978a = sidecarDeviceState;
                this.f2979a.onDeviceStateChanged(sidecarDeviceState);
                a aVar = a.f7353a;
            } finally {
                reentrantLock.unlock();
            }
        }

        public void onWindowLayoutChanged(IBinder iBinder, SidecarWindowLayoutInfo sidecarWindowLayoutInfo) {
            com8.e(iBinder, "token");
            com8.e(sidecarWindowLayoutInfo, "newLayout");
            synchronized (this.f2981a) {
                if (this.f8779a.d(this.f2980a.get(iBinder), sidecarWindowLayoutInfo)) {
                    return;
                }
                this.f2980a.put(iBinder, sidecarWindowLayoutInfo);
                this.f2979a.onWindowLayoutChanged(iBinder, sidecarWindowLayoutInfo);
            }
        }
    }

    public final class TranslatingCallback implements SidecarInterface.SidecarCallback {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ SidecarCompat f8780a;

        public TranslatingCallback(SidecarCompat sidecarCompat) {
            com8.e(sidecarCompat, "this$0");
            this.f8780a = sidecarCompat;
        }

        @SuppressLint({"SyntheticAccessor"})
        public void onDeviceStateChanged(SidecarDeviceState sidecarDeviceState) {
            SidecarInterface sidecarInterfaceG;
            com8.e(sidecarDeviceState, "newDeviceState");
            Collection<Activity> collectionValues = this.f8780a.f2977a.values();
            SidecarCompat sidecarCompat = this.f8780a;
            for (Activity activity : collectionValues) {
                IBinder iBinderA = SidecarCompat.f8777a.a(activity);
                SidecarWindowLayoutInfo windowLayoutInfo = null;
                if (iBinderA != null && (sidecarInterfaceG = sidecarCompat.g()) != null) {
                    windowLayoutInfo = sidecarInterfaceG.getWindowLayoutInfo(iBinderA);
                }
                d3.aux auxVar = sidecarCompat.f2974a;
                if (auxVar != null) {
                    auxVar.a(activity, sidecarCompat.f2975a.e(windowLayoutInfo, sidecarDeviceState));
                }
            }
        }

        @SuppressLint({"SyntheticAccessor"})
        public void onWindowLayoutChanged(IBinder iBinder, SidecarWindowLayoutInfo sidecarWindowLayoutInfo) {
            com8.e(iBinder, "windowToken");
            com8.e(sidecarWindowLayoutInfo, "newLayout");
            Activity activity = (Activity) this.f8780a.f2977a.get(iBinder);
            if (activity == null) {
                Log.w("SidecarCompat", "Unable to resolve activity from window token. Missing a call to #onWindowLayoutChangeListenerAdded()?");
                return;
            }
            j3 j3Var = this.f8780a.f2975a;
            SidecarInterface sidecarInterfaceG = this.f8780a.g();
            SidecarDeviceState deviceState = sidecarInterfaceG == null ? null : sidecarInterfaceG.getDeviceState();
            if (deviceState == null) {
                deviceState = new SidecarDeviceState();
            }
            s3 s3VarE = j3Var.e(sidecarWindowLayoutInfo, deviceState);
            d3.aux auxVar = this.f8780a.f2974a;
            if (auxVar == null) {
                return;
            }
            auxVar.a(activity, s3VarE);
        }
    }

    public static final class aux {
        public aux() {
        }

        public /* synthetic */ aux(com3 com3Var) {
            this();
        }

        public final IBinder a(Activity activity) {
            Window window;
            WindowManager.LayoutParams attributes;
            if (activity == null || (window = activity.getWindow()) == null || (attributes = window.getAttributes()) == null) {
                return null;
            }
            return attributes.token;
        }

        public final SidecarInterface b(Context context) {
            com8.e(context, "context");
            return SidecarProvider.getSidecarImpl(context.getApplicationContext());
        }

        public final w4 c() {
            try {
                String apiVersion = SidecarProvider.getApiVersion();
                if (TextUtils.isEmpty(apiVersion)) {
                    return null;
                }
                return w4.f10506a.b(apiVersion);
            } catch (NoClassDefFoundError | UnsupportedOperationException unused) {
                return null;
            }
        }
    }

    public static final class con implements d3.aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final d3.aux f8781a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final WeakHashMap<Activity, s3> f2982a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final ReentrantLock f2983a;

        public con(d3.aux auxVar) {
            com8.e(auxVar, "callbackInterface");
            this.f8781a = auxVar;
            this.f2983a = new ReentrantLock();
            this.f2982a = new WeakHashMap<>();
        }

        @Override // Com6.d3.aux
        public void a(Activity activity, s3 s3Var) {
            com8.e(activity, "activity");
            com8.e(s3Var, "newLayout");
            ReentrantLock reentrantLock = this.f2983a;
            reentrantLock.lock();
            try {
                if (com8.a(s3Var, this.f2982a.get(activity))) {
                    reentrantLock.unlock();
                    return;
                }
                this.f2982a.put(activity, s3Var);
                reentrantLock.unlock();
                this.f8781a.a(activity, s3Var);
            } catch (Throwable th) {
                reentrantLock.unlock();
                throw th;
            }
        }
    }

    public static final class nul implements View.OnAttachStateChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final SidecarCompat f8782a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final WeakReference<Activity> f2984a;

        public nul(SidecarCompat sidecarCompat, Activity activity) {
            com8.e(sidecarCompat, "sidecarCompat");
            com8.e(activity, "activity");
            this.f8782a = sidecarCompat;
            this.f2984a = new WeakReference<>(activity);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            com8.e(view, "view");
            view.removeOnAttachStateChangeListener(this);
            Activity activity = this.f2984a.get();
            IBinder iBinderA = SidecarCompat.f8777a.a(activity);
            if (activity == null || iBinderA == null) {
                return;
            }
            this.f8782a.i(iBinderA, activity);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            com8.e(view, "view");
        }
    }

    public static final class prn implements ComponentCallbacks {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Activity f8783a;

        public prn(Activity activity) {
            this.f8783a = activity;
        }

        @Override // android.content.ComponentCallbacks
        public void onConfigurationChanged(Configuration configuration) {
            com8.e(configuration, "newConfig");
            d3.aux auxVar = SidecarCompat.this.f2974a;
            if (auxVar == null) {
                return;
            }
            Activity activity = this.f8783a;
            auxVar.a(activity, SidecarCompat.this.h(activity));
        }

        @Override // android.content.ComponentCallbacks
        public void onLowMemory() {
        }
    }

    public SidecarCompat(SidecarInterface sidecarInterface, j3 j3Var) {
        com8.e(j3Var, "sidecarAdapter");
        this.f2976a = sidecarInterface;
        this.f2975a = j3Var;
        this.f2977a = new LinkedHashMap();
        this.f8778b = new LinkedHashMap();
    }

    @Override // p028Com6.d3
    public void a(Activity activity) {
        SidecarInterface sidecarInterface;
        com8.e(activity, "activity");
        IBinder iBinderA = f8777a.a(activity);
        if (iBinderA == null) {
            return;
        }
        SidecarInterface sidecarInterface2 = this.f2976a;
        if (sidecarInterface2 != null) {
            sidecarInterface2.onWindowLayoutChangeListenerRemoved(iBinderA);
        }
        k(activity);
        boolean z2 = this.f2977a.size() == 1;
        this.f2977a.remove(iBinderA);
        if (!z2 || (sidecarInterface = this.f2976a) == null) {
            return;
        }
        sidecarInterface.onDeviceStateListenersChanged(true);
    }

    @Override // p028Com6.d3
    public void b(d3.aux auxVar) {
        com8.e(auxVar, "extensionCallback");
        this.f2974a = new con(auxVar);
        SidecarInterface sidecarInterface = this.f2976a;
        if (sidecarInterface == null) {
            return;
        }
        sidecarInterface.setSidecarCallback(new DistinctSidecarElementCallback(this.f2975a, new TranslatingCallback(this)));
    }

    @Override // p028Com6.d3
    public void c(Activity activity) {
        com8.e(activity, "activity");
        IBinder iBinderA = f8777a.a(activity);
        if (iBinderA != null) {
            i(iBinderA, activity);
        } else {
            activity.getWindow().getDecorView().addOnAttachStateChangeListener(new nul(this, activity));
        }
    }

    public final SidecarInterface g() {
        return this.f2976a;
    }

    public final s3 h(Activity activity) {
        com8.e(activity, "activity");
        IBinder iBinderA = f8777a.a(activity);
        if (iBinderA == null) {
            return new s3(v.f());
        }
        SidecarInterface sidecarInterface = this.f2976a;
        SidecarWindowLayoutInfo windowLayoutInfo = sidecarInterface == null ? null : sidecarInterface.getWindowLayoutInfo(iBinderA);
        j3 j3Var = this.f2975a;
        SidecarInterface sidecarInterface2 = this.f2976a;
        SidecarDeviceState deviceState = sidecarInterface2 != null ? sidecarInterface2.getDeviceState() : null;
        if (deviceState == null) {
            deviceState = new SidecarDeviceState();
        }
        return j3Var.e(windowLayoutInfo, deviceState);
    }

    public final void i(IBinder iBinder, Activity activity) {
        SidecarInterface sidecarInterface;
        com8.e(iBinder, "windowToken");
        com8.e(activity, "activity");
        this.f2977a.put(iBinder, activity);
        SidecarInterface sidecarInterface2 = this.f2976a;
        if (sidecarInterface2 != null) {
            sidecarInterface2.onWindowLayoutChangeListenerAdded(iBinder);
        }
        if (this.f2977a.size() == 1 && (sidecarInterface = this.f2976a) != null) {
            sidecarInterface.onDeviceStateListenersChanged(false);
        }
        d3.aux auxVar = this.f2974a;
        if (auxVar != null) {
            auxVar.a(activity, h(activity));
        }
        j(activity);
    }

    public final void j(Activity activity) {
        if (this.f8778b.get(activity) == null) {
            prn prnVar = new prn(activity);
            this.f8778b.put(activity, prnVar);
            activity.registerComponentCallbacks(prnVar);
        }
    }

    public final void k(Activity activity) {
        activity.unregisterComponentCallbacks(this.f8778b.get(activity));
        this.f8778b.remove(activity);
    }

    @SuppressLint({"BanUncheckedReflection"})
    public boolean l() {
        Class<?> cls;
        Class<?> cls2;
        Class<?> cls3;
        Class<?> cls4;
        try {
            SidecarInterface sidecarInterface = this.f2976a;
            Class<?> returnType = null;
            Method method = (sidecarInterface == null || (cls = sidecarInterface.getClass()) == null) ? null : cls.getMethod("setSidecarCallback", SidecarInterface.SidecarCallback.class);
            Class<?> returnType2 = method == null ? null : method.getReturnType();
            if (!com8.a(returnType2, Void.TYPE)) {
                throw new NoSuchMethodException(com8.k("Illegal return type for 'setSidecarCallback': ", returnType2));
            }
            SidecarInterface sidecarInterface2 = this.f2976a;
            if (sidecarInterface2 != null) {
                sidecarInterface2.getDeviceState();
            }
            SidecarInterface sidecarInterface3 = this.f2976a;
            if (sidecarInterface3 != null) {
                sidecarInterface3.onDeviceStateListenersChanged(true);
            }
            SidecarInterface sidecarInterface4 = this.f2976a;
            Method method2 = (sidecarInterface4 == null || (cls2 = sidecarInterface4.getClass()) == null) ? null : cls2.getMethod("getWindowLayoutInfo", IBinder.class);
            Class<?> returnType3 = method2 == null ? null : method2.getReturnType();
            if (!com8.a(returnType3, SidecarWindowLayoutInfo.class)) {
                throw new NoSuchMethodException(com8.k("Illegal return type for 'getWindowLayoutInfo': ", returnType3));
            }
            SidecarInterface sidecarInterface5 = this.f2976a;
            Method method3 = (sidecarInterface5 == null || (cls3 = sidecarInterface5.getClass()) == null) ? null : cls3.getMethod("onWindowLayoutChangeListenerAdded", IBinder.class);
            Class<?> returnType4 = method3 == null ? null : method3.getReturnType();
            if (!com8.a(returnType4, Void.TYPE)) {
                throw new NoSuchMethodException(com8.k("Illegal return type for 'onWindowLayoutChangeListenerAdded': ", returnType4));
            }
            SidecarInterface sidecarInterface6 = this.f2976a;
            Method method4 = (sidecarInterface6 == null || (cls4 = sidecarInterface6.getClass()) == null) ? null : cls4.getMethod("onWindowLayoutChangeListenerRemoved", IBinder.class);
            if (method4 != null) {
                returnType = method4.getReturnType();
            }
            if (!com8.a(returnType, Void.TYPE)) {
                throw new NoSuchMethodException(com8.k("Illegal return type for 'onWindowLayoutChangeListenerRemoved': ", returnType));
            }
            SidecarDeviceState sidecarDeviceState = new SidecarDeviceState();
            try {
                sidecarDeviceState.posture = 3;
            } catch (NoSuchFieldError unused) {
                SidecarDeviceState.class.getMethod("setPosture", Integer.TYPE).invoke(sidecarDeviceState, 3);
                Object objInvoke = SidecarDeviceState.class.getMethod("getPosture", new Class[0]).invoke(sidecarDeviceState, new Object[0]);
                if (objInvoke == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
                }
                if (((Integer) objInvoke).intValue() != 3) {
                    throw new Exception("Invalid device posture getter/setter");
                }
            }
            SidecarDisplayFeature sidecarDisplayFeature = new SidecarDisplayFeature();
            Rect rect = sidecarDisplayFeature.getRect();
            com8.d(rect, "displayFeature.rect");
            sidecarDisplayFeature.setRect(rect);
            sidecarDisplayFeature.getType();
            sidecarDisplayFeature.setType(1);
            SidecarWindowLayoutInfo sidecarWindowLayoutInfo = new SidecarWindowLayoutInfo();
            try {
                List list = sidecarWindowLayoutInfo.displayFeatures;
            } catch (NoSuchFieldError unused2) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(sidecarDisplayFeature);
                SidecarWindowLayoutInfo.class.getMethod("setDisplayFeatures", List.class).invoke(sidecarWindowLayoutInfo, arrayList);
                Object objInvoke2 = SidecarWindowLayoutInfo.class.getMethod("getDisplayFeatures", new Class[0]).invoke(sidecarWindowLayoutInfo, new Object[0]);
                if (objInvoke2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.collections.List<androidx.window.sidecar.SidecarDisplayFeature>");
                }
                if (!com8.a(arrayList, (List) objInvoke2)) {
                    throw new Exception("Invalid display feature getter/setter");
                }
            }
            return true;
        } catch (Throwable unused3) {
            return false;
        }
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public SidecarCompat(Context context) {
        this(f8777a.b(context), new j3(null, 1, null));
        com8.e(context, "context");
    }
}
