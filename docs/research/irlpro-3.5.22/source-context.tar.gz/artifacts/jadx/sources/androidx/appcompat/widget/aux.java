package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.com4;
import androidx.appcompat.view.menu.com5;
import androidx.appcompat.view.menu.com6;
import androidx.appcompat.view.menu.com8;
import java.util.ArrayList;
import p001AuX.com3;
import p001AuX.com9;
import p022CoN.a0;
import p022CoN.c;
import p022CoN.s0;
import p024Com2.lpt4;
import p080cOm1.y;
import p099coN.h1;

/* JADX INFO: loaded from: classes.dex */
public class aux extends androidx.appcompat.view.menu.aux implements lpt4.aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Drawable f7978a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SparseBooleanArray f2113a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public C0025aux f2114a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f2115a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com2 f2116a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f2117a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f2118a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f2119a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f7979b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f7980c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7981d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2120d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7982e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2121e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7983f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f2122f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7984g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f2123g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f7985h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f2124h;

    /* JADX INFO: renamed from: androidx.appcompat.widget.aux$aux, reason: collision with other inner class name */
    public class C0025aux extends com4 {
        public C0025aux(Context context, com8 com8Var, View view) {
            super(context, com8Var, view, false, com3.f5504l);
            if (!((androidx.appcompat.view.menu.com3) com8Var.getItem()).n()) {
                View view2 = aux.this.f2119a;
                f(view2 == null ? (View) ((androidx.appcompat.view.menu.aux) aux.this).f1829a : view2);
            }
            j(aux.this.f2116a);
        }

        @Override // androidx.appcompat.view.menu.com4
        public void e() {
            aux auxVar = aux.this;
            auxVar.f2114a = null;
            auxVar.f7985h = 0;
            super.e();
        }
    }

    public class com1 extends com4 {
        public com1(Context context, androidx.appcompat.view.menu.com1 com1Var, View view, boolean z2) {
            super(context, com1Var, view, z2, com3.f5504l);
            h(8388613);
            j(aux.this.f2116a);
        }

        @Override // androidx.appcompat.view.menu.com4
        public void e() {
            if (((androidx.appcompat.view.menu.aux) aux.this).f1827a != null) {
                ((androidx.appcompat.view.menu.aux) aux.this).f1827a.close();
            }
            aux.this.f2115a = null;
            super.e();
        }
    }

    public class com2 implements com5.aux {
        public com2() {
        }

        @Override // androidx.appcompat.view.menu.com5.aux
        public void c(androidx.appcompat.view.menu.com1 com1Var, boolean z2) {
            if (com1Var instanceof com8) {
                com1Var.D().e(false);
            }
            com5.aux auxVarM = aux.this.m();
            if (auxVarM != null) {
                auxVarM.c(com1Var, z2);
            }
        }

        @Override // androidx.appcompat.view.menu.com5.aux
        public boolean d(androidx.appcompat.view.menu.com1 com1Var) {
            if (com1Var == ((androidx.appcompat.view.menu.aux) aux.this).f1827a) {
                return false;
            }
            aux.this.f7985h = ((com8) com1Var).getItem().getItemId();
            com5.aux auxVarM = aux.this.m();
            if (auxVarM != null) {
                return auxVarM.d(com1Var);
            }
            return false;
        }
    }

    public class con extends ActionMenuItemView.con {
        public con() {
        }

        @Override // androidx.appcompat.view.menu.ActionMenuItemView.con
        public h1 a() {
            C0025aux c0025aux = aux.this.f2114a;
            if (c0025aux != null) {
                return c0025aux.c();
            }
            return null;
        }
    }

    public class nul implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public com1 f7990a;

        public nul(com1 com1Var) {
            this.f7990a = com1Var;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((androidx.appcompat.view.menu.aux) aux.this).f1827a != null) {
                ((androidx.appcompat.view.menu.aux) aux.this).f1827a.d();
            }
            View view = (View) ((androidx.appcompat.view.menu.aux) aux.this).f1829a;
            if (view != null && view.getWindowToken() != null && this.f7990a.m()) {
                aux.this.f2115a = this.f7990a;
            }
            aux.this.f2118a = null;
        }
    }

    public class prn extends c implements ActionMenuView.aux {

        /* JADX INFO: renamed from: androidx.appcompat.widget.aux$prn$aux, reason: collision with other inner class name */
        public class C0026aux extends a0 {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ aux f2126a;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            public C0026aux(View view, aux auxVar) {
                super(view);
                this.f2126a = auxVar;
            }

            @Override // p022CoN.a0
            public h1 b() {
                com1 com1Var = aux.this.f2115a;
                if (com1Var == null) {
                    return null;
                }
                return com1Var.c();
            }

            @Override // p022CoN.a0
            public boolean c() {
                aux.this.K();
                return true;
            }

            @Override // p022CoN.a0
            public boolean d() {
                aux auxVar = aux.this;
                if (auxVar.f2118a != null) {
                    return false;
                }
                auxVar.B();
                return true;
            }
        }

        public prn(Context context) {
            super(context, null, com3.f5503k);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            s0.a(this, getContentDescription());
            setOnTouchListener(new C0026aux(this, aux.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.aux
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.aux
        public boolean c() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            aux.this.K();
            return true;
        }

        @Override // android.widget.ImageView
        public boolean setFrame(int i2, int i3, int i4, int i5) {
            boolean frame = super.setFrame(i2, i3, i4, i5);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int iMax = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                y.f(background, paddingLeft - iMax, paddingTop - iMax, paddingLeft + iMax, paddingTop + iMax);
            }
            return frame;
        }
    }

    public aux(Context context) {
        super(context, com9.f5593c, com9.f5592b);
        this.f2113a = new SparseBooleanArray();
        this.f2116a = new com2();
    }

    public Drawable A() {
        prn prnVar = this.f2119a;
        if (prnVar != null) {
            return prnVar.getDrawable();
        }
        if (this.f7979b) {
            return this.f7978a;
        }
        return null;
    }

    public boolean B() {
        Object obj;
        nul nulVar = this.f2118a;
        if (nulVar != null && (obj = ((androidx.appcompat.view.menu.aux) this).f1829a) != null) {
            ((View) obj).removeCallbacks(nulVar);
            this.f2118a = null;
            return true;
        }
        com1 com1Var = this.f2115a;
        if (com1Var == null) {
            return false;
        }
        com1Var.b();
        return true;
    }

    public boolean C() {
        C0025aux c0025aux = this.f2114a;
        if (c0025aux == null) {
            return false;
        }
        c0025aux.b();
        return true;
    }

    public boolean D() {
        return this.f2118a != null || E();
    }

    public boolean E() {
        com1 com1Var = this.f2115a;
        return com1Var != null && com1Var.d();
    }

    public void F(Configuration configuration) {
        if (!this.f2121e) {
            this.f7983f = p012COn.nul.b(((androidx.appcompat.view.menu.aux) this).f1830b).d();
        }
        androidx.appcompat.view.menu.com1 com1Var = ((androidx.appcompat.view.menu.aux) this).f1827a;
        if (com1Var != null) {
            com1Var.K(true);
        }
    }

    public void G(boolean z2) {
        this.f2124h = z2;
    }

    public void H(ActionMenuView actionMenuView) {
        ((androidx.appcompat.view.menu.aux) this).f1829a = actionMenuView;
        actionMenuView.c(((androidx.appcompat.view.menu.aux) this).f1827a);
    }

    public void I(Drawable drawable) {
        prn prnVar = this.f2119a;
        if (prnVar != null) {
            prnVar.setImageDrawable(drawable);
        } else {
            this.f7979b = true;
            this.f7978a = drawable;
        }
    }

    public void J(boolean z2) {
        this.f7980c = z2;
        this.f2120d = true;
    }

    public boolean K() {
        androidx.appcompat.view.menu.com1 com1Var;
        if (!this.f7980c || E() || (com1Var = ((androidx.appcompat.view.menu.aux) this).f1827a) == null || ((androidx.appcompat.view.menu.aux) this).f1829a == null || this.f2118a != null || com1Var.z().isEmpty()) {
            return false;
        }
        nul nulVar = new nul(new com1(((androidx.appcompat.view.menu.aux) this).f1830b, ((androidx.appcompat.view.menu.aux) this).f1827a, this.f2119a, true));
        this.f2118a = nulVar;
        ((View) ((androidx.appcompat.view.menu.aux) this).f1829a).post(nulVar);
        return true;
    }

    @Override // androidx.appcompat.view.menu.aux
    public void b(androidx.appcompat.view.menu.com3 com3Var, com6.aux auxVar) {
        auxVar.b(com3Var, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) auxVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) ((androidx.appcompat.view.menu.aux) this).f1829a);
        if (this.f2117a == null) {
            this.f2117a = new con();
        }
        actionMenuItemView.setPopupCallback(this.f2117a);
    }

    @Override // androidx.appcompat.view.menu.aux, androidx.appcompat.view.menu.com5
    public void c(androidx.appcompat.view.menu.com1 com1Var, boolean z2) {
        y();
        super.c(com1Var, z2);
    }

    @Override // androidx.appcompat.view.menu.aux, androidx.appcompat.view.menu.com5
    public void e(boolean z2) {
        super.e(z2);
        ((View) ((androidx.appcompat.view.menu.aux) this).f1829a).requestLayout();
        androidx.appcompat.view.menu.com1 com1Var = ((androidx.appcompat.view.menu.aux) this).f1827a;
        boolean z3 = false;
        if (com1Var != null) {
            ArrayList<androidx.appcompat.view.menu.com3> arrayListS = com1Var.s();
            int size = arrayListS.size();
            for (int i2 = 0; i2 < size; i2++) {
                lpt4 lpt4VarC = arrayListS.get(i2).c();
                if (lpt4VarC != null) {
                    lpt4VarC.i(this);
                }
            }
        }
        androidx.appcompat.view.menu.com1 com1Var2 = ((androidx.appcompat.view.menu.aux) this).f1827a;
        ArrayList<androidx.appcompat.view.menu.com3> arrayListZ = com1Var2 != null ? com1Var2.z() : null;
        if (this.f7980c && arrayListZ != null) {
            int size2 = arrayListZ.size();
            if (size2 == 1) {
                z3 = !arrayListZ.get(0).isActionViewExpanded();
            } else if (size2 > 0) {
                z3 = true;
            }
        }
        if (z3) {
            if (this.f2119a == null) {
                this.f2119a = new prn(((androidx.appcompat.view.menu.aux) this).f1825a);
            }
            ViewGroup viewGroup = (ViewGroup) this.f2119a.getParent();
            if (viewGroup != ((androidx.appcompat.view.menu.aux) this).f1829a) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f2119a);
                }
                ActionMenuView actionMenuView = (ActionMenuView) ((androidx.appcompat.view.menu.aux) this).f1829a;
                actionMenuView.addView(this.f2119a, actionMenuView.D());
            }
        } else {
            prn prnVar = this.f2119a;
            if (prnVar != null) {
                Object parent = prnVar.getParent();
                Object obj = ((androidx.appcompat.view.menu.aux) this).f1829a;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.f2119a);
                }
            }
        }
        ((ActionMenuView) ((androidx.appcompat.view.menu.aux) this).f1829a).setOverflowReserved(this.f7980c);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [androidx.appcompat.widget.aux] */
    /* JADX WARN: Type inference failed for: r0v10 */
    /* JADX WARN: Type inference failed for: r0v11 */
    /* JADX WARN: Type inference failed for: r0v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v7 */
    /* JADX WARN: Type inference failed for: r0v8 */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r15v1, types: [androidx.appcompat.view.menu.com3] */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1, types: [int] */
    /* JADX WARN: Type inference failed for: r3v12 */
    @Override // androidx.appcompat.view.menu.com5
    public boolean f() {
        ArrayList<androidx.appcompat.view.menu.com3> arrayListE;
        int size;
        int i2;
        int iJ;
        ?? r0;
        aux auxVar = this;
        androidx.appcompat.view.menu.com1 com1Var = ((androidx.appcompat.view.menu.aux) auxVar).f1827a;
        View view = null;
        ?? r3 = 0;
        if (com1Var != null) {
            arrayListE = com1Var.E();
            size = arrayListE.size();
        } else {
            arrayListE = null;
            size = 0;
        }
        int i3 = auxVar.f7983f;
        int i4 = auxVar.f7982e;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) ((androidx.appcompat.view.menu.aux) auxVar).f1829a;
        boolean z2 = false;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < size; i7++) {
            androidx.appcompat.view.menu.com3 com3Var = arrayListE.get(i7);
            if (com3Var.q()) {
                i5++;
            } else if (com3Var.p()) {
                i6++;
            } else {
                z2 = true;
            }
            if (auxVar.f2124h && com3Var.isActionViewExpanded()) {
                i3 = 0;
            }
        }
        if (auxVar.f7980c && (z2 || i6 + i5 > i3)) {
            i3--;
        }
        int i8 = i3 - i5;
        SparseBooleanArray sparseBooleanArray = auxVar.f2113a;
        sparseBooleanArray.clear();
        if (auxVar.f2122f) {
            int i9 = auxVar.f7984g;
            iJ = i4 / i9;
            i2 = i9 + ((i4 % i9) / iJ);
        } else {
            i2 = 0;
            iJ = 0;
        }
        int i10 = 0;
        int i11 = 0;
        ?? r1 = auxVar;
        while (i10 < size) {
            androidx.appcompat.view.menu.com3 com3Var2 = arrayListE.get(i10);
            if (com3Var2.q()) {
                View viewN = r1.n(com3Var2, view, viewGroup);
                if (r1.f2122f) {
                    iJ -= ActionMenuView.J(viewN, i2, iJ, iMakeMeasureSpec, r3);
                } else {
                    viewN.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                }
                int measuredWidth = viewN.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                int groupId = com3Var2.getGroupId();
                if (groupId != 0) {
                    sparseBooleanArray.put(groupId, true);
                }
                com3Var2.w(true);
                r0 = r3;
            } else if (com3Var2.p()) {
                int groupId2 = com3Var2.getGroupId();
                boolean z3 = sparseBooleanArray.get(groupId2);
                boolean z4 = (i8 > 0 || z3) && i4 > 0 && (!r1.f2122f || iJ > 0);
                boolean z5 = z4;
                if (z4) {
                    View viewN2 = r1.n(com3Var2, null, viewGroup);
                    if (r1.f2122f) {
                        int iJ2 = ActionMenuView.J(viewN2, i2, iJ, iMakeMeasureSpec, 0);
                        iJ -= iJ2;
                        if (iJ2 == 0) {
                            z5 = false;
                        }
                    } else {
                        viewN2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                    }
                    boolean z6 = z5;
                    int measuredWidth2 = viewN2.getMeasuredWidth();
                    i4 -= measuredWidth2;
                    if (i11 == 0) {
                        i11 = measuredWidth2;
                    }
                    z4 = z6 & (!r1.f2122f ? i4 + i11 <= 0 : i4 < 0);
                }
                if (z4 && groupId2 != 0) {
                    sparseBooleanArray.put(groupId2, true);
                } else if (z3) {
                    sparseBooleanArray.put(groupId2, false);
                    for (int i12 = 0; i12 < i10; i12++) {
                        androidx.appcompat.view.menu.com3 com3Var3 = arrayListE.get(i12);
                        if (com3Var3.getGroupId() == groupId2) {
                            if (com3Var3.n()) {
                                i8++;
                            }
                            com3Var3.w(false);
                        }
                    }
                }
                if (z4) {
                    i8--;
                }
                com3Var2.w(z4);
                r0 = 0;
            } else {
                r0 = r3;
                com3Var2.w(r0);
            }
            i10++;
            r3 = r0;
            size = size;
            view = null;
            r1 = this;
        }
        return true;
    }

    @Override // androidx.appcompat.view.menu.aux, androidx.appcompat.view.menu.com5
    public void i(Context context, androidx.appcompat.view.menu.com1 com1Var) {
        super.i(context, com1Var);
        Resources resources = context.getResources();
        p012COn.nul nulVarB = p012COn.nul.b(context);
        if (!this.f2120d) {
            this.f7980c = nulVarB.h();
        }
        if (!this.f2123g) {
            this.f7981d = nulVarB.c();
        }
        if (!this.f2121e) {
            this.f7983f = nulVarB.d();
        }
        int measuredWidth = this.f7981d;
        if (this.f7980c) {
            if (this.f2119a == null) {
                prn prnVar = new prn(((androidx.appcompat.view.menu.aux) this).f1825a);
                this.f2119a = prnVar;
                if (this.f7979b) {
                    prnVar.setImageDrawable(this.f7978a);
                    this.f7978a = null;
                    this.f7979b = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f2119a.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.f2119a.getMeasuredWidth();
        } else {
            this.f2119a = null;
        }
        this.f7982e = measuredWidth;
        this.f7984g = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // androidx.appcompat.view.menu.aux, androidx.appcompat.view.menu.com5
    public boolean j(com8 com8Var) {
        boolean z2 = false;
        if (!com8Var.hasVisibleItems()) {
            return false;
        }
        com8 com8Var2 = com8Var;
        while (com8Var2.e0() != ((androidx.appcompat.view.menu.aux) this).f1827a) {
            com8Var2 = (com8) com8Var2.e0();
        }
        View viewZ = z(com8Var2.getItem());
        if (viewZ == null) {
            return false;
        }
        this.f7985h = com8Var.getItem().getItemId();
        int size = com8Var.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = com8Var.getItem(i2);
            if (item.isVisible() && item.getIcon() != null) {
                z2 = true;
                break;
            }
        }
        C0025aux c0025aux = new C0025aux(((androidx.appcompat.view.menu.aux) this).f1830b, com8Var, viewZ);
        this.f2114a = c0025aux;
        c0025aux.g(z2);
        this.f2114a.k();
        super.j(com8Var);
        return true;
    }

    @Override // androidx.appcompat.view.menu.aux
    public boolean l(ViewGroup viewGroup, int i2) {
        if (viewGroup.getChildAt(i2) == this.f2119a) {
            return false;
        }
        return super.l(viewGroup, i2);
    }

    @Override // androidx.appcompat.view.menu.aux
    public View n(androidx.appcompat.view.menu.com3 com3Var, View view, ViewGroup viewGroup) {
        View actionView = com3Var.getActionView();
        if (actionView == null || com3Var.l()) {
            actionView = super.n(com3Var, view, viewGroup);
        }
        actionView.setVisibility(com3Var.isActionViewExpanded() ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    @Override // androidx.appcompat.view.menu.aux
    public com6 o(ViewGroup viewGroup) {
        com6 com6Var = ((androidx.appcompat.view.menu.aux) this).f1829a;
        com6 com6VarO = super.o(viewGroup);
        if (com6Var != com6VarO) {
            ((ActionMenuView) com6VarO).setPresenter(this);
        }
        return com6VarO;
    }

    @Override // androidx.appcompat.view.menu.aux
    public boolean q(int i2, androidx.appcompat.view.menu.com3 com3Var) {
        return com3Var.n();
    }

    public boolean y() {
        return B() | C();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View z(MenuItem menuItem) {
        ViewGroup viewGroup = (ViewGroup) ((androidx.appcompat.view.menu.aux) this).f1829a;
        if (viewGroup == null) {
            return null;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if ((childAt instanceof com6.aux) && ((com6.aux) childAt).getItemData() == menuItem) {
                return childAt;
            }
        }
        return null;
    }
}
