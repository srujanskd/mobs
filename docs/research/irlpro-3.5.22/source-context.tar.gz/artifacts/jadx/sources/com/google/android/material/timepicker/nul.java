package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.Resources;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.button.MaterialButtonToggleGroup;
import java.util.Locale;
import p042LpT1.j;
import p042LpT1.m;
import p042LpT1.n;
import p075cOM6.b4;
import p075cOM6.f4;
import p081cOm2.e2;
import p108com9.s;

/* JADX INFO: loaded from: classes.dex */
public class nul implements TimePickerView.com3, n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f9714a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final EditText f3801a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinearLayout f3802a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public MaterialButtonToggleGroup f3803a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ChipTextInputComboView f3804a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com.google.android.material.timepicker.con f3805a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final EditText f3806b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final ChipTextInputComboView f3807b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextWatcher f3800a = new aux();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final TextWatcher f9715b = new con();

    public class aux extends s {
        public aux() {
        }

        @Override // p108com9.s, android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            try {
                if (TextUtils.isEmpty(editable)) {
                    nul.this.f9714a.s(0);
                } else {
                    nul.this.f9714a.s(Integer.parseInt(editable.toString()));
                }
            } catch (NumberFormatException unused) {
            }
        }
    }

    public class com1 extends j {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ m f9717a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public com1(Context context, int i2, m mVar) {
            super(context, i2);
            this.f9717a = mVar;
        }

        @Override // p042LpT1.j, p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.X(view.getResources().getString(f4.f8941l, String.valueOf(this.f9717a.f7039c)));
        }
    }

    public class com2 implements MaterialButtonToggleGroup.prn {
        public com2() {
        }

        @Override // com.google.android.material.button.MaterialButtonToggleGroup.prn
        public void a(MaterialButtonToggleGroup materialButtonToggleGroup, int i2, boolean z2) {
            nul.this.f9714a.t(i2 == b4.f8891n ? 1 : 0);
        }
    }

    public class con extends s {
        public con() {
        }

        @Override // p108com9.s, android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            try {
                if (TextUtils.isEmpty(editable)) {
                    nul.this.f9714a.r(0);
                } else {
                    nul.this.f9714a.r(Integer.parseInt(editable.toString()));
                }
            } catch (NumberFormatException unused) {
            }
        }
    }

    /* JADX INFO: renamed from: com.google.android.material.timepicker.nul$nul, reason: collision with other inner class name */
    public class ViewOnClickListenerC0066nul implements View.OnClickListener {
        public ViewOnClickListenerC0066nul() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            nul.this.c(((Integer) view.getTag(b4.S)).intValue());
        }
    }

    public class prn extends j {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ m f9721a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public prn(Context context, int i2, m mVar) {
            super(context, i2);
            this.f9721a = mVar;
        }

        @Override // p042LpT1.j, p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.X(view.getResources().getString(f4.f8939j, String.valueOf(this.f9721a.n())));
        }
    }

    public nul(LinearLayout linearLayout, m mVar) {
        this.f3802a = linearLayout;
        this.f9714a = mVar;
        Resources resources = linearLayout.getResources();
        ChipTextInputComboView chipTextInputComboView = (ChipTextInputComboView) linearLayout.findViewById(b4.f8896s);
        this.f3804a = chipTextInputComboView;
        ChipTextInputComboView chipTextInputComboView2 = (ChipTextInputComboView) linearLayout.findViewById(b4.f8893p);
        this.f3807b = chipTextInputComboView2;
        int i2 = b4.f8895r;
        TextView textView = (TextView) chipTextInputComboView.findViewById(i2);
        TextView textView2 = (TextView) chipTextInputComboView2.findViewById(i2);
        textView.setText(resources.getString(f4.f8944o));
        textView2.setText(resources.getString(f4.f8943n));
        int i3 = b4.S;
        chipTextInputComboView.setTag(i3, 12);
        chipTextInputComboView2.setTag(i3, 10);
        if (mVar.f7037a == 0) {
            k();
        }
        ViewOnClickListenerC0066nul viewOnClickListenerC0066nul = new ViewOnClickListenerC0066nul();
        chipTextInputComboView2.setOnClickListener(viewOnClickListenerC0066nul);
        chipTextInputComboView.setOnClickListener(viewOnClickListenerC0066nul);
        chipTextInputComboView2.c(mVar.o());
        chipTextInputComboView.c(mVar.p());
        this.f3801a = chipTextInputComboView2.e().getEditText();
        this.f3806b = chipTextInputComboView.e().getEditText();
        this.f3805a = new com.google.android.material.timepicker.con(chipTextInputComboView2, chipTextInputComboView, mVar);
        chipTextInputComboView2.f(new prn(linearLayout.getContext(), f4.f8938i, mVar));
        chipTextInputComboView.f(new com1(linearLayout.getContext(), f4.f8940k, mVar));
        g();
    }

    @Override // p042LpT1.n
    public void a() {
        this.f3802a.setVisibility(0);
    }

    @Override // p042LpT1.n
    public void b() {
        View focusedChild = this.f3802a.getFocusedChild();
        if (focusedChild == null) {
            this.f3802a.setVisibility(8);
            return;
        }
        InputMethodManager inputMethodManager = (InputMethodManager) PRN.aux.g(this.f3802a.getContext(), InputMethodManager.class);
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(focusedChild.getWindowToken(), 0);
        }
        this.f3802a.setVisibility(8);
    }

    @Override // com.google.android.material.timepicker.TimePickerView.com3
    public void c(int i2) {
        this.f9714a.f7040d = i2;
        this.f3804a.setChecked(i2 == 12);
        this.f3807b.setChecked(i2 == 10);
        l();
    }

    public final void e() {
        this.f3801a.addTextChangedListener(this.f9715b);
        this.f3806b.addTextChangedListener(this.f3800a);
    }

    public void f() {
        this.f3804a.setChecked(false);
        this.f3807b.setChecked(false);
    }

    public void g() {
        e();
        j(this.f9714a);
        this.f3805a.a();
    }

    public final void h() {
        this.f3801a.removeTextChangedListener(this.f9715b);
        this.f3806b.removeTextChangedListener(this.f3800a);
    }

    public void i() {
        this.f3804a.setChecked(this.f9714a.f7040d == 12);
        this.f3807b.setChecked(this.f9714a.f7040d == 10);
    }

    @Override // p042LpT1.n
    public void invalidate() {
        j(this.f9714a);
    }

    public final void j(m mVar) {
        h();
        Locale locale = this.f3802a.getResources().getConfiguration().locale;
        String str = String.format(locale, "%02d", Integer.valueOf(mVar.f7039c));
        String str2 = String.format(locale, "%02d", Integer.valueOf(mVar.n()));
        this.f3804a.g(str);
        this.f3807b.g(str2);
        e();
        l();
    }

    public final void k() {
        MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) this.f3802a.findViewById(b4.f8892o);
        this.f3803a = materialButtonToggleGroup;
        materialButtonToggleGroup.b(new com2());
        this.f3803a.setVisibility(0);
        l();
    }

    public final void l() {
        MaterialButtonToggleGroup materialButtonToggleGroup = this.f3803a;
        if (materialButtonToggleGroup == null) {
            return;
        }
        materialButtonToggleGroup.e(this.f9714a.f7041e == 0 ? b4.f8890m : b4.f8891n);
    }
}
