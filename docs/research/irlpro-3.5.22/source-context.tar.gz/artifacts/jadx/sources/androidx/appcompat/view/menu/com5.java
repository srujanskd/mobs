package androidx.appcompat.view.menu;

import android.content.Context;

/* JADX INFO: loaded from: classes.dex */
public interface com5 {

    public interface aux {
        void c(com1 com1Var, boolean z2);

        boolean d(com1 com1Var);
    }

    void c(com1 com1Var, boolean z2);

    void e(boolean z2);

    boolean f();

    void g(aux auxVar);

    boolean h(com1 com1Var, com3 com3Var);

    void i(Context context, com1 com1Var);

    boolean j(com8 com8Var);

    boolean k(com1 com1Var, com3 com3Var);
}
