package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.charset.Charset;
import p101com2.p2;
import p101com2.u2;

/* JADX INFO: loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final PorterDuff.Mode f8170b = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8171a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f2304a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f2305a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Parcelable f2306a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Object f2307a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2308a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public byte[] f2309a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f2310b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public String f2311b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8172c;

    public static class aux {
        public static IconCompat a(Object obj) {
            u2.f(obj);
            int iD = d(obj);
            if (iD == 2) {
                return IconCompat.f(null, c(obj), b(obj));
            }
            if (iD == 4) {
                return IconCompat.d(e(obj));
            }
            if (iD == 6) {
                return IconCompat.b(e(obj));
            }
            IconCompat iconCompat = new IconCompat(-1);
            iconCompat.f2307a = obj;
            return iconCompat;
        }

        public static int b(Object obj) {
            return nul.a(obj);
        }

        public static String c(Object obj) {
            return nul.b(obj);
        }

        public static int d(Object obj) {
            return nul.c(obj);
        }

        public static Uri e(Object obj) {
            return nul.d(obj);
        }

        public static Drawable f(Icon icon, Context context) {
            return icon.loadDrawable(context);
        }

        public static Icon g(IconCompat iconCompat, Context context) {
            Icon iconCreateWithBitmap;
            switch (iconCompat.f8171a) {
                case -1:
                    return (Icon) iconCompat.f2307a;
                case 0:
                default:
                    throw new IllegalArgumentException("Unknown type");
                case 1:
                    iconCreateWithBitmap = Icon.createWithBitmap((Bitmap) iconCompat.f2307a);
                    break;
                case 2:
                    iconCreateWithBitmap = Icon.createWithResource(iconCompat.h(), iconCompat.f2310b);
                    break;
                case 3:
                    iconCreateWithBitmap = Icon.createWithData((byte[]) iconCompat.f2307a, iconCompat.f2310b, iconCompat.f8172c);
                    break;
                case 4:
                    iconCreateWithBitmap = Icon.createWithContentUri((String) iconCompat.f2307a);
                    break;
                case 5:
                    iconCreateWithBitmap = con.b((Bitmap) iconCompat.f2307a);
                    break;
                case 6:
                    if (Build.VERSION.SDK_INT >= 30) {
                        iconCreateWithBitmap = prn.a(iconCompat.j());
                    } else {
                        if (context == null) {
                            throw new IllegalArgumentException("Context is required to resolve the file uri of the icon: " + iconCompat.j());
                        }
                        InputStream inputStreamK = iconCompat.k(context);
                        if (inputStreamK == null) {
                            throw new IllegalStateException("Cannot load adaptive icon from uri: " + iconCompat.j());
                        }
                        iconCreateWithBitmap = con.b(BitmapFactory.decodeStream(inputStreamK));
                    }
                    break;
            }
            ColorStateList colorStateList = iconCompat.f2304a;
            if (colorStateList != null) {
                iconCreateWithBitmap.setTintList(colorStateList);
            }
            PorterDuff.Mode mode = iconCompat.f2305a;
            if (mode != IconCompat.f8170b) {
                iconCreateWithBitmap.setTintMode(mode);
            }
            return iconCreateWithBitmap;
        }
    }

    public static class con {
        public static Drawable a(Drawable drawable, Drawable drawable2) {
            return new AdaptiveIconDrawable(drawable, drawable2);
        }

        public static Icon b(Bitmap bitmap) {
            return Icon.createWithAdaptiveBitmap(bitmap);
        }
    }

    public static class nul {
        public static int a(Object obj) {
            return ((Icon) obj).getResId();
        }

        public static String b(Object obj) {
            return ((Icon) obj).getResPackage();
        }

        public static int c(Object obj) {
            return ((Icon) obj).getType();
        }

        public static Uri d(Object obj) {
            return ((Icon) obj).getUri();
        }
    }

    public static class prn {
        public static Icon a(Uri uri) {
            return Icon.createWithAdaptiveBitmapContentUri(uri);
        }
    }

    public IconCompat() {
        this.f8171a = -1;
        this.f2309a = null;
        this.f2306a = null;
        this.f2310b = 0;
        this.f8172c = 0;
        this.f2304a = null;
        this.f2305a = f8170b;
        this.f2308a = null;
    }

    public static IconCompat a(Icon icon) {
        return aux.a(icon);
    }

    public static IconCompat b(Uri uri) {
        p2.c(uri);
        return c(uri.toString());
    }

    public static IconCompat c(String str) {
        p2.c(str);
        IconCompat iconCompat = new IconCompat(6);
        iconCompat.f2307a = str;
        return iconCompat;
    }

    public static IconCompat d(Uri uri) {
        p2.c(uri);
        return e(uri.toString());
    }

    public static IconCompat e(String str) {
        p2.c(str);
        IconCompat iconCompat = new IconCompat(4);
        iconCompat.f2307a = str;
        return iconCompat;
    }

    public static IconCompat f(Resources resources, String str, int i2) {
        p2.c(str);
        if (i2 == 0) {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f2310b = i2;
        if (resources != null) {
            try {
                iconCompat.f2307a = resources.getResourceName(i2);
            } catch (Resources.NotFoundException unused) {
                throw new IllegalArgumentException("Icon resource cannot be found");
            }
        } else {
            iconCompat.f2307a = str;
        }
        iconCompat.f2311b = str;
        return iconCompat;
    }

    public static String p(int i2) {
        switch (i2) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case 4:
                return "URI";
            case 5:
                return "BITMAP_MASKABLE";
            case 6:
                return "URI_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    public int g() {
        int i2 = this.f8171a;
        if (i2 == -1) {
            return aux.b(this.f2307a);
        }
        if (i2 == 2) {
            return this.f2310b;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public String h() {
        int i2 = this.f8171a;
        if (i2 == -1) {
            return aux.c(this.f2307a);
        }
        if (i2 == 2) {
            String str = this.f2311b;
            return (str == null || TextUtils.isEmpty(str)) ? ((String) this.f2307a).split(":", -1)[0] : this.f2311b;
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    public int i() {
        int i2 = this.f8171a;
        return i2 == -1 ? aux.d(this.f2307a) : i2;
    }

    public Uri j() {
        int i2 = this.f8171a;
        if (i2 == -1) {
            return aux.e(this.f2307a);
        }
        if (i2 == 4 || i2 == 6) {
            return Uri.parse((String) this.f2307a);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public InputStream k(Context context) {
        Uri uriJ = j();
        String scheme = uriJ.getScheme();
        if ("content".equals(scheme) || "file".equals(scheme)) {
            try {
                return context.getContentResolver().openInputStream(uriJ);
            } catch (Exception e2) {
                Log.w("IconCompat", "Unable to load image from URI: " + uriJ, e2);
                return null;
            }
        }
        try {
            return new FileInputStream(new File((String) this.f2307a));
        } catch (FileNotFoundException e3) {
            Log.w("IconCompat", "Unable to load image from path: " + uriJ, e3);
            return null;
        }
    }

    public void l() {
        this.f2305a = PorterDuff.Mode.valueOf(this.f2308a);
        switch (this.f8171a) {
            case -1:
                Parcelable parcelable = this.f2306a;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                this.f2307a = parcelable;
                return;
            case 0:
            default:
                return;
            case 1:
            case 5:
                Parcelable parcelable2 = this.f2306a;
                if (parcelable2 != null) {
                    this.f2307a = parcelable2;
                    return;
                }
                byte[] bArr = this.f2309a;
                this.f2307a = bArr;
                this.f8171a = 3;
                this.f2310b = 0;
                this.f8172c = bArr.length;
                return;
            case 2:
            case 4:
            case 6:
                String str = new String(this.f2309a, Charset.forName("UTF-16"));
                this.f2307a = str;
                if (this.f8171a == 2 && this.f2311b == null) {
                    this.f2311b = str.split(":", -1)[0];
                    return;
                }
                return;
            case 3:
                this.f2307a = this.f2309a;
                return;
        }
    }

    public void m(boolean z2) {
        this.f2308a = this.f2305a.name();
        switch (this.f8171a) {
            case -1:
                if (z2) {
                    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
                }
                this.f2306a = (Parcelable) this.f2307a;
                return;
            case 0:
            default:
                return;
            case 1:
            case 5:
                if (!z2) {
                    this.f2306a = (Parcelable) this.f2307a;
                    return;
                }
                Bitmap bitmap = (Bitmap) this.f2307a;
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                this.f2309a = byteArrayOutputStream.toByteArray();
                return;
            case 2:
                this.f2309a = ((String) this.f2307a).getBytes(Charset.forName("UTF-16"));
                return;
            case 3:
                this.f2309a = (byte[]) this.f2307a;
                return;
            case 4:
            case 6:
                this.f2309a = this.f2307a.toString().getBytes(Charset.forName("UTF-16"));
                return;
        }
    }

    @Deprecated
    public Icon n() {
        return o(null);
    }

    public Icon o(Context context) {
        return aux.g(this, context);
    }

    public String toString() {
        if (this.f8171a == -1) {
            return String.valueOf(this.f2307a);
        }
        StringBuilder sb = new StringBuilder("Icon(typ=");
        sb.append(p(this.f8171a));
        switch (this.f8171a) {
            case 1:
            case 5:
                sb.append(" size=");
                sb.append(((Bitmap) this.f2307a).getWidth());
                sb.append("x");
                sb.append(((Bitmap) this.f2307a).getHeight());
                break;
            case 2:
                sb.append(" pkg=");
                sb.append(this.f2311b);
                sb.append(" id=");
                sb.append(String.format("0x%08x", Integer.valueOf(g())));
                break;
            case 3:
                sb.append(" len=");
                sb.append(this.f2310b);
                if (this.f8172c != 0) {
                    sb.append(" off=");
                    sb.append(this.f8172c);
                }
                break;
            case 4:
            case 6:
                sb.append(" uri=");
                sb.append(this.f2307a);
                break;
        }
        if (this.f2304a != null) {
            sb.append(" tint=");
            sb.append(this.f2304a);
        }
        if (this.f2305a != f8170b) {
            sb.append(" mode=");
            sb.append(this.f2305a);
        }
        sb.append(")");
        return sb.toString();
    }

    public IconCompat(int i2) {
        this.f2309a = null;
        this.f2306a = null;
        this.f2310b = 0;
        this.f8172c = 0;
        this.f2304a = null;
        this.f2305a = f8170b;
        this.f2308a = null;
        this.f8171a = i2;
    }
}
