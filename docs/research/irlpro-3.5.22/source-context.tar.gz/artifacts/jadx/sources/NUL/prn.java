package NUL;

/* JADX INFO: loaded from: classes.dex */
public interface prn {
    void a(prn prnVar);
}
