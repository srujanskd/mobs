package LPT7;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class j3 implements inet.ipaddr.com9.com3 {
    @Override // inet.ipaddr.com9.com3
    public final Object apply(Object obj, int i2) {
        return ((inet.ipaddr.ipv6.aux) obj).getSegment(i2);
    }
}
