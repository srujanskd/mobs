package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;
import p001AuX.com3;
import p022CoN.b;
import p022CoN.l0;
import p022CoN.lpt2;
import p022CoN.n0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatImageButton extends ImageButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f7880a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt2 f1983a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f7881b;

    public AppCompatImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.C);
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            lpt2Var.b();
        }
        b bVar = this.f7880a;
        if (bVar != null) {
            bVar.c();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            return lpt2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            return lpt2Var.d();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        b bVar = this.f7880a;
        if (bVar != null) {
            return bVar.d();
        }
        return null;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        b bVar = this.f7880a;
        if (bVar != null) {
            return bVar.e();
        }
        return null;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return this.f7880a.f() && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            lpt2Var.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            lpt2Var.g(i2);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        b bVar = this.f7880a;
        if (bVar != null) {
            bVar.c();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        b bVar = this.f7880a;
        if (bVar != null && drawable != null && !this.f7881b) {
            bVar.h(drawable);
        }
        super.setImageDrawable(drawable);
        b bVar2 = this.f7880a;
        if (bVar2 != null) {
            bVar2.c();
            if (this.f7881b) {
                return;
            }
            this.f7880a.b();
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f7881b = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        this.f7880a.i(i2);
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        b bVar = this.f7880a;
        if (bVar != null) {
            bVar.c();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            lpt2Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        lpt2 lpt2Var = this.f1983a;
        if (lpt2Var != null) {
            lpt2Var.j(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        b bVar = this.f7880a;
        if (bVar != null) {
            bVar.j(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        b bVar = this.f7880a;
        if (bVar != null) {
            bVar.k(mode);
        }
    }

    public AppCompatImageButton(Context context, AttributeSet attributeSet, int i2) {
        super(n0.b(context), attributeSet, i2);
        this.f7881b = false;
        l0.a(this, getContext());
        lpt2 lpt2Var = new lpt2(this);
        this.f1983a = lpt2Var;
        lpt2Var.e(attributeSet, i2);
        b bVar = new b(this);
        this.f7880a = bVar;
        bVar.g(attributeSet, i2);
    }
}
