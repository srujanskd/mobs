package com.google.android.material.datepicker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.Collection;
import java.util.Iterator;
import p075cOM6.d4;
import p087cOm8.com2;
import p087cOm8.com3;
import p087cOm8.com4;
import p087cOm8.com5;
import p087cOm8.com8;
import p087cOm8.lpt3;

/* JADX INFO: loaded from: classes.dex */
public class nul extends BaseAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int f9472a = lpt3.i().getMaximum(4);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f3513a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com4<?> f3514a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com8 f3515a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final aux f3516a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Collection<Long> f3517a;

    public nul(com8 com8Var, com4<?> com4Var, aux auxVar) {
        this.f3515a = com8Var;
        this.f3514a = com4Var;
        this.f3516a = auxVar;
        this.f3517a = com4Var.c();
    }

    public int a(int i2) {
        return b() + (i2 - 1);
    }

    public int b() {
        return this.f3515a.q();
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Long getItem(int i2) {
        if (i2 < this.f3515a.q() || i2 > i()) {
            return null;
        }
        return Long.valueOf(this.f3515a.r(j(i2)));
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0075  */
    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public TextView getView(int i2, View view, ViewGroup viewGroup) {
        e(viewGroup.getContext());
        TextView textView = (TextView) view;
        if (view == null) {
            textView = (TextView) LayoutInflater.from(viewGroup.getContext()).inflate(d4.f8921o, viewGroup, false);
        }
        int iB = i2 - b();
        if (iB >= 0) {
            com8 com8Var = this.f3515a;
            if (iB >= com8Var.f9183d) {
                textView.setVisibility(8);
                textView.setEnabled(false);
            } else {
                int i3 = iB + 1;
                textView.setTag(com8Var);
                textView.setText(String.format(textView.getResources().getConfiguration().locale, "%d", Integer.valueOf(i3)));
                long jR = this.f3515a.r(i3);
                if (this.f3515a.f9181b == com8.p().f9181b) {
                    textView.setContentDescription(com5.a(jR));
                } else {
                    textView.setContentDescription(com5.d(jR));
                }
                textView.setVisibility(0);
                textView.setEnabled(true);
            }
        } else {
            textView.setVisibility(8);
            textView.setEnabled(false);
        }
        Long item = getItem(i2);
        if (item == null) {
            return textView;
        }
        k(textView, item.longValue());
        return textView;
    }

    public final void e(Context context) {
        if (this.f3513a == null) {
            this.f3513a = new com3(context);
        }
    }

    public boolean f(int i2) {
        return i2 % this.f3515a.f9182c == 0;
    }

    public boolean g(int i2) {
        return (i2 + 1) % this.f3515a.f9182c == 0;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.f3515a.f9183d + b();
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        return i2 / this.f3515a.f9182c;
    }

    public final boolean h(long j2) {
        Iterator<Long> it = this.f3514a.c().iterator();
        while (it.hasNext()) {
            if (lpt3.a(j2) == lpt3.a(it.next().longValue())) {
                return true;
            }
        }
        return false;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return true;
    }

    public int i() {
        return (this.f3515a.q() + this.f3515a.f9183d) - 1;
    }

    public int j(int i2) {
        return (i2 - this.f3515a.q()) + 1;
    }

    public final void k(TextView textView, long j2) {
        com2 com2Var;
        if (textView == null) {
            return;
        }
        if (this.f3516a.q().d(j2)) {
            textView.setEnabled(true);
            if (h(j2)) {
                com2Var = this.f3513a.f9171b;
            } else {
                com2Var = lpt3.g().getTimeInMillis() == j2 ? this.f3513a.f9172c : this.f3513a.f3217a;
            }
        } else {
            textView.setEnabled(false);
            com2Var = this.f3513a.f9176g;
        }
        com2Var.d(textView);
    }

    public final void l(MaterialCalendarGridView materialCalendarGridView, long j2) {
        if (com8.o(j2).equals(this.f3515a)) {
            k((TextView) materialCalendarGridView.getChildAt(materialCalendarGridView.getAdapter().a(this.f3515a.s(j2)) - materialCalendarGridView.getFirstVisiblePosition()), j2);
        }
    }

    public void m(MaterialCalendarGridView materialCalendarGridView) {
        Iterator<Long> it = this.f3517a.iterator();
        while (it.hasNext()) {
            l(materialCalendarGridView, it.next().longValue());
        }
        com4<?> com4Var = this.f3514a;
        if (com4Var != null) {
            Iterator<Long> it2 = com4Var.c().iterator();
            while (it2.hasNext()) {
                l(materialCalendarGridView, it2.next().longValue());
            }
            this.f3517a = this.f3514a.c();
        }
    }

    public boolean n(int i2) {
        return i2 >= b() && i2 <= i();
    }
}
