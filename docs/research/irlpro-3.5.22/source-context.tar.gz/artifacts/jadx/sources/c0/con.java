package c0;

import androidx.preference.Preference;
import b0.com5;
import b0.com7;
import f.com8;
import i0.BufferedSource;
import i0.b;
import i0.lpt9;
import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;
import m.lpt1;
import m.lpt2;
import v.c;
import v.e;
import v.g;
import v.lpt8;

/* JADX INFO: loaded from: classes.dex */
public final class con implements b0.prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final prn f8803a = new prn(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3002a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final a0.com2 f3003a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final c0.aux f3004a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final BufferedSource f3005a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final i0.nul f3006a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final c f3007a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt8 f3008a;

    public abstract class aux implements b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ con f8804a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final i0.com3 f3009a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8805b;

        public aux(con conVar) {
            com8.e(conVar, "this$0");
            this.f8804a = conVar;
            this.f3009a = new i0.com3(conVar.f3005a.timeout());
        }

        @Override // i0.b
        public long A(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "sink");
            try {
                return this.f8804a.f3005a.A(conVar, j2);
            } catch (IOException e2) {
                this.f8804a.b().y();
                c();
                throw e2;
            }
        }

        public final boolean a() {
            return this.f8805b;
        }

        public final void c() {
            if (this.f8804a.f3002a == 6) {
                return;
            }
            if (this.f8804a.f3002a != 5) {
                throw new IllegalStateException(com8.k("state: ", Integer.valueOf(this.f8804a.f3002a)));
            }
            this.f8804a.r(this.f3009a);
            this.f8804a.f3002a = 6;
        }

        public final void d(boolean z2) {
            this.f8805b = z2;
        }

        @Override // i0.b
        public i0.c timeout() {
            return this.f3009a;
        }
    }

    public final class com1 extends aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public long f8806a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ con f8807b;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public com1(con conVar, long j2) {
            super(conVar);
            com8.e(conVar, "this$0");
            this.f8807b = conVar;
            this.f8806a = j2;
            if (j2 == 0) {
                c();
            }
        }

        @Override // c0.con.aux, i0.b
        public long A(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "sink");
            if (!(j2 >= 0)) {
                throw new IllegalArgumentException(com8.k("byteCount < 0: ", Long.valueOf(j2)).toString());
            }
            if (!(!a())) {
                throw new IllegalStateException("closed".toString());
            }
            long j3 = this.f8806a;
            if (j3 == 0) {
                return -1L;
            }
            long jA = super.A(conVar, Math.min(j3, j2));
            if (jA == -1) {
                this.f8807b.b().y();
                ProtocolException protocolException = new ProtocolException("unexpected end of stream");
                c();
                throw protocolException;
            }
            long j4 = this.f8806a - jA;
            this.f8806a = j4;
            if (j4 == 0) {
                c();
            }
            return jA;
        }

        @Override // i0.b, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (a()) {
                return;
            }
            if (this.f8806a != 0 && !w.com1.s(this, 100, TimeUnit.MILLISECONDS)) {
                this.f8807b.b().y();
                c();
            }
            d(true);
        }
    }

    public final class com2 implements lpt9 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ con f8808a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final i0.com3 f3010a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8809b;

        public com2(con conVar) {
            com8.e(conVar, "this$0");
            this.f8808a = conVar;
            this.f3010a = new i0.com3(conVar.f3006a.timeout());
        }

        @Override // i0.lpt9, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.f8809b) {
                return;
            }
            this.f8809b = true;
            this.f8808a.r(this.f3010a);
            this.f8808a.f3002a = 3;
        }

        @Override // i0.lpt9
        public void e(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "source");
            if (!(!this.f8809b)) {
                throw new IllegalStateException("closed".toString());
            }
            w.com1.l(conVar.size(), 0L, j2);
            this.f8808a.f3006a.e(conVar, j2);
        }

        @Override // i0.lpt9, java.io.Flushable
        public void flush() throws IOException {
            if (this.f8809b) {
                return;
            }
            this.f8808a.f3006a.flush();
        }

        @Override // i0.lpt9
        public i0.c timeout() {
            return this.f3010a;
        }
    }

    public final class com3 extends aux {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ con f8810b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8811c;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public com3(con conVar) {
            super(conVar);
            com8.e(conVar, "this$0");
            this.f8810b = conVar;
        }

        @Override // c0.con.aux, i0.b
        public long A(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "sink");
            if (!(j2 >= 0)) {
                throw new IllegalArgumentException(com8.k("byteCount < 0: ", Long.valueOf(j2)).toString());
            }
            if (!(!a())) {
                throw new IllegalStateException("closed".toString());
            }
            if (this.f8811c) {
                return -1L;
            }
            long jA = super.A(conVar, j2);
            if (jA != -1) {
                return jA;
            }
            this.f8811c = true;
            c();
            return -1L;
        }

        @Override // i0.b, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (a()) {
                return;
            }
            if (!this.f8811c) {
                c();
            }
            d(true);
        }
    }

    /* JADX INFO: renamed from: c0.con$con, reason: collision with other inner class name */
    public final class C0053con implements lpt9 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ con f8812a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final i0.com3 f3011a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8813b;

        public C0053con(con conVar) {
            com8.e(conVar, "this$0");
            this.f8812a = conVar;
            this.f3011a = new i0.com3(conVar.f3006a.timeout());
        }

        @Override // i0.lpt9, java.io.Closeable, java.lang.AutoCloseable
        public synchronized void close() {
            if (this.f8813b) {
                return;
            }
            this.f8813b = true;
            this.f8812a.f3006a.g("0\r\n\r\n");
            this.f8812a.r(this.f3011a);
            this.f8812a.f3002a = 3;
        }

        @Override // i0.lpt9
        public void e(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "source");
            if (!(!this.f8813b)) {
                throw new IllegalStateException("closed".toString());
            }
            if (j2 == 0) {
                return;
            }
            this.f8812a.f3006a.q(j2);
            this.f8812a.f3006a.g("\r\n");
            this.f8812a.f3006a.e(conVar, j2);
            this.f8812a.f3006a.g("\r\n");
        }

        @Override // i0.lpt9, java.io.Flushable
        public synchronized void flush() {
            if (this.f8813b) {
                return;
            }
            this.f8812a.f3006a.flush();
        }

        @Override // i0.lpt9
        public i0.c timeout() {
            return this.f3011a;
        }
    }

    public final class nul extends aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public long f8814a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final v.lpt9 f3012a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ con f8815b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8816c;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public nul(con conVar, v.lpt9 lpt9Var) {
            super(conVar);
            com8.e(conVar, "this$0");
            com8.e(lpt9Var, "url");
            this.f8815b = conVar;
            this.f3012a = lpt9Var;
            this.f8814a = -1L;
            this.f8816c = true;
        }

        @Override // c0.con.aux, i0.b
        public long A(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "sink");
            if (!(j2 >= 0)) {
                throw new IllegalArgumentException(com8.k("byteCount < 0: ", Long.valueOf(j2)).toString());
            }
            if (!(!a())) {
                throw new IllegalStateException("closed".toString());
            }
            if (!this.f8816c) {
                return -1L;
            }
            long j3 = this.f8814a;
            if (j3 == 0 || j3 == -1) {
                f();
                if (!this.f8816c) {
                    return -1L;
                }
            }
            long jA = super.A(conVar, Math.min(j2, this.f8814a));
            if (jA != -1) {
                this.f8814a -= jA;
                return jA;
            }
            this.f8815b.b().y();
            ProtocolException protocolException = new ProtocolException("unexpected end of stream");
            c();
            throw protocolException;
        }

        @Override // i0.b, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (a()) {
                return;
            }
            if (this.f8816c && !w.com1.s(this, 100, TimeUnit.MILLISECONDS)) {
                this.f8815b.b().y();
                c();
            }
            d(true);
        }

        public final void f() throws IOException {
            if (this.f8814a != -1) {
                this.f8815b.f3005a.P();
            }
            try {
                this.f8814a = this.f8815b.f3005a.Q();
                String string = lpt2.B0(this.f8815b.f3005a.P()).toString();
                if (this.f8814a >= 0) {
                    if (!(string.length() > 0) || lpt1.C(string, ";", false, 2, null)) {
                        if (this.f8814a == 0) {
                            this.f8816c = false;
                            con conVar = this.f8815b;
                            conVar.f3008a = conVar.f3004a.a();
                            c cVar = this.f8815b.f3007a;
                            com8.b(cVar);
                            v.lpt1 lpt1VarJ = cVar.j();
                            v.lpt9 lpt9Var = this.f3012a;
                            lpt8 lpt8Var = this.f8815b.f3008a;
                            com8.b(lpt8Var);
                            b0.com1.f(lpt1VarJ, lpt9Var, lpt8Var);
                            c();
                            return;
                        }
                        return;
                    }
                }
                throw new ProtocolException("expected chunk size and optional extensions but was \"" + this.f8814a + string + '\"');
            } catch (NumberFormatException e2) {
                throw new ProtocolException(e2.getMessage());
            }
        }
    }

    public static final class prn {
        public prn() {
        }

        public /* synthetic */ prn(f.com3 com3Var) {
            this();
        }
    }

    public con(c cVar, a0.com2 com2Var, BufferedSource bufferedSource, i0.nul nulVar) {
        com8.e(com2Var, "connection");
        com8.e(bufferedSource, "source");
        com8.e(nulVar, "sink");
        this.f3007a = cVar;
        this.f3003a = com2Var;
        this.f3005a = bufferedSource;
        this.f3006a = nulVar;
        this.f3004a = new c0.aux(bufferedSource);
    }

    public final void A(lpt8 lpt8Var, String str) {
        com8.e(lpt8Var, "headers");
        com8.e(str, "requestLine");
        int i2 = this.f3002a;
        if (!(i2 == 0)) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        this.f3006a.g(str).g("\r\n");
        int size = lpt8Var.size();
        for (int i3 = 0; i3 < size; i3++) {
            this.f3006a.g(lpt8Var.b(i3)).g(": ").g(lpt8Var.d(i3)).g("\r\n");
        }
        this.f3006a.g("\r\n");
        this.f3002a = 1;
    }

    @Override // b0.prn
    public void a() {
        this.f3006a.flush();
    }

    @Override // b0.prn
    public a0.com2 b() {
        return this.f3003a;
    }

    @Override // b0.prn
    public lpt9 c(e eVar, long j2) throws ProtocolException {
        com8.e(eVar, "request");
        if (eVar.a() != null && eVar.a().c()) {
            throw new ProtocolException("Duplex connections are not supported for HTTP/1");
        }
        if (s(eVar)) {
            return u();
        }
        if (j2 != -1) {
            return x();
        }
        throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
    }

    @Override // b0.prn
    public void cancel() {
        b().d();
    }

    @Override // b0.prn
    public void d(e eVar) {
        com8.e(eVar, "request");
        com5 com5Var = com5.f8797a;
        Proxy.Type type = b().z().b().type();
        com8.d(type, "connection.route().proxy.type()");
        A(eVar.e(), com5Var.a(eVar, type));
    }

    @Override // b0.prn
    public long e(g gVar) {
        com8.e(gVar, "response");
        if (!b0.com1.b(gVar)) {
            return 0L;
        }
        if (t(gVar)) {
            return -1L;
        }
        return w.com1.v(gVar);
    }

    @Override // b0.prn
    public void f() throws IOException {
        this.f3006a.flush();
    }

    @Override // b0.prn
    public g.aux g(boolean z2) {
        int i2 = this.f3002a;
        boolean z3 = true;
        if (i2 != 1 && i2 != 3) {
            z3 = false;
        }
        if (!z3) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        try {
            com7 com7VarA = com7.f8799a.a(this.f3004a.b());
            g.aux auxVarHeaders = new g.aux().protocol(com7VarA.f2997a).code(com7VarA.f2995a).message(com7VarA.f2996a).headers(this.f3004a.a());
            if (z2 && com7VarA.f2995a == 100) {
                return null;
            }
            if (com7VarA.f2995a == 100) {
                this.f3002a = 3;
                return auxVarHeaders;
            }
            this.f3002a = 4;
            return auxVarHeaders;
        } catch (EOFException e2) {
            throw new IOException(com8.k("unexpected end of stream on ", b().z().a().l().o()), e2);
        }
    }

    @Override // b0.prn
    public b h(g gVar) {
        com8.e(gVar, "response");
        if (!b0.com1.b(gVar)) {
            return w(0L);
        }
        if (t(gVar)) {
            return v(gVar.V().i());
        }
        long jV = w.com1.v(gVar);
        return jV != -1 ? w(jV) : y();
    }

    public final void r(i0.com3 com3Var) {
        i0.c cVarI = com3Var.i();
        com3Var.j(i0.c.f4389a);
        cVarI.a();
        cVarI.b();
    }

    public final boolean s(e eVar) {
        return lpt1.q("chunked", eVar.d("Transfer-Encoding"), true);
    }

    public final boolean t(g gVar) {
        return lpt1.q("chunked", g.y(gVar, "Transfer-Encoding", null, 2, null), true);
    }

    public final lpt9 u() {
        int i2 = this.f3002a;
        if (!(i2 == 1)) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        this.f3002a = 2;
        return new C0053con(this);
    }

    public final b v(v.lpt9 lpt9Var) {
        int i2 = this.f3002a;
        if (!(i2 == 4)) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        this.f3002a = 5;
        return new nul(this, lpt9Var);
    }

    public final b w(long j2) {
        int i2 = this.f3002a;
        if (!(i2 == 4)) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        this.f3002a = 5;
        return new com1(this, j2);
    }

    public final lpt9 x() {
        int i2 = this.f3002a;
        if (!(i2 == 1)) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        this.f3002a = 2;
        return new com2(this);
    }

    public final b y() {
        int i2 = this.f3002a;
        if (!(i2 == 4)) {
            throw new IllegalStateException(com8.k("state: ", Integer.valueOf(i2)).toString());
        }
        this.f3002a = 5;
        b().y();
        return new com3(this);
    }

    public final void z(g gVar) {
        com8.e(gVar, "response");
        long jV = w.com1.v(gVar);
        if (jV == -1) {
            return;
        }
        b bVarW = w(jV);
        w.com1.L(bVarW, Preference.DEFAULT_ORDER, TimeUnit.MILLISECONDS);
        bVarW.close();
    }
}
