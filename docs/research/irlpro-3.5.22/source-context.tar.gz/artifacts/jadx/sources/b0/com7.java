package b0;

import com.newrelic.agent.android.agentdata.HexAttribute;
import f.com8;
import java.io.IOException;
import java.net.ProtocolException;
import m.lpt1;
import v.d;

/* JADX INFO: loaded from: classes.dex */
public final class com7 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f8799a = new aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f2995a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final String f2996a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final d f2997a;

    public static final class aux {
        public aux() {
        }

        public /* synthetic */ aux(f.com3 com3Var) {
            this();
        }

        public final com7 a(String str) throws IOException {
            d dVar;
            int i2;
            String strSubstring;
            com8.e(str, "statusLine");
            if (lpt1.C(str, "HTTP/1.", false, 2, null)) {
                i2 = 9;
                if (str.length() < 9 || str.charAt(8) != ' ') {
                    throw new ProtocolException(com8.k("Unexpected status line: ", str));
                }
                int iCharAt = str.charAt(7) - '0';
                if (iCharAt == 0) {
                    dVar = d.HTTP_1_0;
                } else {
                    if (iCharAt != 1) {
                        throw new ProtocolException(com8.k("Unexpected status line: ", str));
                    }
                    dVar = d.HTTP_1_1;
                }
            } else {
                if (!lpt1.C(str, "ICY ", false, 2, null)) {
                    throw new ProtocolException(com8.k("Unexpected status line: ", str));
                }
                dVar = d.HTTP_1_0;
                i2 = 4;
            }
            int i3 = i2 + 3;
            if (str.length() < i3) {
                throw new ProtocolException(com8.k("Unexpected status line: ", str));
            }
            try {
                String strSubstring2 = str.substring(i2, i3);
                com8.d(strSubstring2, "this as java.lang.String…ing(startIndex, endIndex)");
                int i4 = Integer.parseInt(strSubstring2);
                if (str.length() <= i3) {
                    strSubstring = "";
                } else {
                    if (str.charAt(i3) != ' ') {
                        throw new ProtocolException(com8.k("Unexpected status line: ", str));
                    }
                    strSubstring = str.substring(i2 + 4);
                    com8.d(strSubstring, "this as java.lang.String).substring(startIndex)");
                }
                return new com7(dVar, i4, strSubstring);
            } catch (NumberFormatException unused) {
                throw new ProtocolException(com8.k("Unexpected status line: ", str));
            }
        }
    }

    public com7(d dVar, int i2, String str) {
        com8.e(dVar, "protocol");
        com8.e(str, HexAttribute.HEX_ATTR_MESSAGE);
        this.f2997a = dVar;
        this.f2995a = i2;
        this.f2996a = str;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (this.f2997a == d.HTTP_1_0) {
            sb.append("HTTP/1.0");
        } else {
            sb.append("HTTP/1.1");
        }
        sb.append(' ');
        sb.append(this.f2995a);
        sb.append(' ');
        sb.append(this.f2996a);
        String string = sb.toString();
        com8.d(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }
}
