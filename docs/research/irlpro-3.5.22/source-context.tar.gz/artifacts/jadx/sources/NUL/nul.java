package NUL;

import java.util.ArrayList;
import java.util.Iterator;
import p146nUL.o;
import p146nUL.p;
import p146nUL.q;

/* JADX INFO: loaded from: classes.dex */
public class nul extends lpt3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList<lpt3> f7414a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7415c;

    public nul(p pVar, int i2) {
        super(pVar);
        this.f7414a = new ArrayList<>();
        ((lpt3) this).f7408b = i2;
        q();
    }

    /* JADX WARN: Code duplicated, block: B:113:0x01be  */
    /* JADX WARN: Code duplicated, block: B:294:0x00f4 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:62:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:64:0x00e6  */
    /* JADX WARN: Code duplicated, block: B:65:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:67:0x00ec A[ADDED_TO_REGION] */
    @Override // NUL.lpt3, NUL.prn
    public void a(prn prnVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        float f2;
        boolean z2;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        float f3;
        if (((lpt3) this).f1380a.f1362c && ((lpt3) this).f1387b.f1362c) {
            p pVarI = ((lpt3) this).f1385a.I();
            boolean zL1 = pVarI instanceof q ? ((q) pVarI).L1() : false;
            int i15 = ((lpt3) this).f1387b.f7365b - ((lpt3) this).f1380a.f7365b;
            int size = this.f7414a.size();
            int i16 = 0;
            while (true) {
                i2 = -1;
                i3 = 8;
                if (i16 >= size) {
                    i16 = -1;
                    break;
                } else if (this.f7414a.get(i16).f1385a.T() != 8) {
                    break;
                } else {
                    i16++;
                }
            }
            int i17 = size - 1;
            for (int i18 = i17; i18 >= 0; i18--) {
                if (this.f7414a.get(i18).f1385a.T() != 8) {
                    i2 = i18;
                    break;
                }
            }
            int i19 = 0;
            while (true) {
                if (i19 >= 2) {
                    i4 = 0;
                    i5 = 0;
                    i6 = 0;
                    f2 = 0.0f;
                    break;
                }
                int i20 = 0;
                i5 = 0;
                i6 = 0;
                int i21 = 0;
                f2 = 0.0f;
                while (i20 < size) {
                    lpt3 lpt3Var = this.f7414a.get(i20);
                    if (lpt3Var.f1385a.T() != i3) {
                        i21++;
                        if (i20 > 0 && i20 >= i16) {
                            i5 += lpt3Var.f1380a.f7364a;
                        }
                        com3 com3Var = lpt3Var.f1381a;
                        int i22 = ((com2) com3Var).f7365b;
                        boolean z3 = lpt3Var.f1384a != p.con.MATCH_CONSTRAINT;
                        if (z3) {
                            int i23 = ((lpt3) this).f7408b;
                            if (i23 == 0 && !((com2) ((lpt3) lpt3Var.f1385a.f4937a).f1381a).f1362c) {
                                return;
                            }
                            if (i23 == 1 && !((com2) ((lpt3) lpt3Var.f1385a.f4938a).f1381a).f1362c) {
                                return;
                            } else {
                                i13 = i22;
                            }
                        } else {
                            i13 = i22;
                            if (lpt3Var.f7407a == 1 && i19 == 0) {
                                i14 = com3Var.f7375d;
                                i6++;
                            } else {
                                if (((com2) com3Var).f1362c) {
                                    i14 = i13;
                                }
                                if (z3) {
                                    i5 += i14;
                                } else {
                                    i6++;
                                    f3 = lpt3Var.f1385a.f4947a[((lpt3) this).f7408b];
                                    if (f3 >= 0.0f) {
                                        f2 += f3;
                                    }
                                }
                                if (i20 >= i17 && i20 < i2) {
                                    i5 += -lpt3Var.f1387b.f7364a;
                                }
                            }
                            z3 = true;
                            if (z3) {
                                i6++;
                                f3 = lpt3Var.f1385a.f4947a[((lpt3) this).f7408b];
                                if (f3 >= 0.0f) {
                                    f2 += f3;
                                }
                            } else {
                                i5 += i14;
                            }
                            if (i20 >= i17) {
                            }
                        }
                        i14 = i13;
                        if (z3) {
                            i6++;
                            f3 = lpt3Var.f1385a.f4947a[((lpt3) this).f7408b];
                            if (f3 >= 0.0f) {
                                f2 += f3;
                            }
                        } else {
                            i5 += i14;
                        }
                        if (i20 >= i17) {
                        }
                    }
                    i20++;
                    i3 = 8;
                }
                if (i5 < i15 || i6 == 0) {
                    i4 = i21;
                    break;
                } else {
                    i19++;
                    i3 = 8;
                }
            }
            int i24 = ((lpt3) this).f1380a.f7365b;
            if (zL1) {
                i24 = ((lpt3) this).f1387b.f7365b;
            }
            if (i5 > i15) {
                i24 = zL1 ? i24 + ((int) (((i5 - i15) / 2.0f) + 0.5f)) : i24 - ((int) (((i5 - i15) / 2.0f) + 0.5f));
            }
            if (i6 > 0) {
                float f4 = i15 - i5;
                int i25 = (int) ((f4 / i6) + 0.5f);
                int i26 = 0;
                int i27 = 0;
                while (i26 < size) {
                    lpt3 lpt3Var2 = this.f7414a.get(i26);
                    int i28 = i25;
                    int i29 = i5;
                    if (lpt3Var2.f1385a.T() != 8 && lpt3Var2.f1384a == p.con.MATCH_CONSTRAINT) {
                        com3 com3Var2 = lpt3Var2.f1381a;
                        if (((com2) com3Var2).f1362c) {
                            zL1 = zL1;
                            i24 = i24;
                            f4 = f4;
                        } else {
                            int i30 = f2 > 0.0f ? (int) (((lpt3Var2.f1385a.f4947a[((lpt3) this).f7408b] * f4) / f2) + 0.5f) : i28;
                            if (((lpt3) this).f7408b == 0) {
                                p pVar = lpt3Var2.f1385a;
                                i12 = pVar.f11503i;
                                i11 = pVar.f4980h;
                            } else {
                                p pVar2 = lpt3Var2.f1385a;
                                int i31 = pVar2.f11505k;
                                i11 = pVar2.f11504j;
                                i12 = i31;
                            }
                            int iMax = Math.max(i11, lpt3Var2.f7407a == 1 ? Math.min(i30, com3Var2.f7375d) : i30);
                            if (i12 > 0) {
                                iMax = Math.min(i12, iMax);
                            }
                            if (iMax != i30) {
                                i27++;
                                i30 = iMax;
                            }
                            lpt3Var2.f1381a.d(i30);
                        }
                    } else {
                        zL1 = zL1;
                        i24 = i24;
                        f4 = f4;
                    }
                    i26++;
                    i25 = i28;
                    i5 = i29;
                    i24 = i24;
                    f4 = f4;
                    zL1 = zL1;
                    i4 = i4;
                }
                z2 = zL1;
                i7 = i4;
                i8 = i24;
                int i32 = i5;
                if (i27 > 0) {
                    i6 -= i27;
                    int i33 = 0;
                    for (int i34 = 0; i34 < size; i34++) {
                        lpt3 lpt3Var3 = this.f7414a.get(i34);
                        if (lpt3Var3.f1385a.T() != 8) {
                            if (i34 > 0 && i34 >= i16) {
                                i33 += lpt3Var3.f1380a.f7364a;
                            }
                            i33 += ((com2) lpt3Var3.f1381a).f7365b;
                            if (i34 < i17 && i34 < i2) {
                                i33 += -lpt3Var3.f1387b.f7364a;
                            }
                        }
                    }
                    i5 = i33;
                } else {
                    i5 = i32;
                }
                i10 = 2;
                if (this.f7415c == 2 && i27 == 0) {
                    i9 = 0;
                    this.f7415c = 0;
                } else {
                    i9 = 0;
                }
            } else {
                z2 = zL1;
                i7 = i4;
                i8 = i24;
                i9 = 0;
                i10 = 2;
            }
            if (i5 > i15) {
                this.f7415c = i10;
            }
            if (i7 > 0 && i6 == 0 && i16 == i2) {
                this.f7415c = i10;
            }
            int i35 = this.f7415c;
            if (i35 == 1) {
                int i36 = i7;
                int i37 = i36 > 1 ? (i15 - i5) / (i36 - 1) : i36 == 1 ? (i15 - i5) / 2 : i9;
                if (i6 > 0) {
                    i37 = i9;
                }
                int i38 = i8;
                for (int i39 = i9; i39 < size; i39++) {
                    lpt3 lpt3Var4 = this.f7414a.get(z2 ? size - (i39 + 1) : i39);
                    if (lpt3Var4.f1385a.T() == 8) {
                        lpt3Var4.f1380a.d(i38);
                        lpt3Var4.f1387b.d(i38);
                    } else {
                        if (i39 > 0) {
                            i38 = z2 ? i38 - i37 : i38 + i37;
                        }
                        if (i39 > 0 && i39 >= i16) {
                            i38 = z2 ? i38 - lpt3Var4.f1380a.f7364a : i38 + lpt3Var4.f1380a.f7364a;
                        }
                        if (z2) {
                            lpt3Var4.f1387b.d(i38);
                        } else {
                            lpt3Var4.f1380a.d(i38);
                        }
                        com3 com3Var3 = lpt3Var4.f1381a;
                        int i40 = ((com2) com3Var3).f7365b;
                        if (lpt3Var4.f1384a == p.con.MATCH_CONSTRAINT && lpt3Var4.f7407a == 1) {
                            i40 = com3Var3.f7375d;
                        }
                        i38 = z2 ? i38 - i40 : i38 + i40;
                        if (z2) {
                            lpt3Var4.f1380a.d(i38);
                        } else {
                            lpt3Var4.f1387b.d(i38);
                        }
                        lpt3Var4.f1386a = true;
                        if (i39 < i17 && i39 < i2) {
                            i38 = z2 ? i38 - (-lpt3Var4.f1387b.f7364a) : i38 + (-lpt3Var4.f1387b.f7364a);
                        }
                    }
                }
                return;
            }
            int i41 = i7;
            if (i35 == 0) {
                int i42 = (i15 - i5) / (i41 + 1);
                if (i6 > 0) {
                    i42 = i9;
                }
                int i43 = i8;
                for (int i44 = i9; i44 < size; i44++) {
                    lpt3 lpt3Var5 = this.f7414a.get(z2 ? size - (i44 + 1) : i44);
                    if (lpt3Var5.f1385a.T() == 8) {
                        lpt3Var5.f1380a.d(i43);
                        lpt3Var5.f1387b.d(i43);
                    } else {
                        int i45 = z2 ? i43 - i42 : i43 + i42;
                        if (i44 > 0 && i44 >= i16) {
                            i45 = z2 ? i45 - lpt3Var5.f1380a.f7364a : i45 + lpt3Var5.f1380a.f7364a;
                        }
                        if (z2) {
                            lpt3Var5.f1387b.d(i45);
                        } else {
                            lpt3Var5.f1380a.d(i45);
                        }
                        com3 com3Var4 = lpt3Var5.f1381a;
                        int iMin = ((com2) com3Var4).f7365b;
                        if (lpt3Var5.f1384a == p.con.MATCH_CONSTRAINT && lpt3Var5.f7407a == 1) {
                            iMin = Math.min(iMin, com3Var4.f7375d);
                        }
                        i43 = z2 ? i45 - iMin : i45 + iMin;
                        if (z2) {
                            lpt3Var5.f1380a.d(i43);
                        } else {
                            lpt3Var5.f1387b.d(i43);
                        }
                        if (i44 < i17 && i44 < i2) {
                            i43 = z2 ? i43 - (-lpt3Var5.f1387b.f7364a) : i43 + (-lpt3Var5.f1387b.f7364a);
                        }
                    }
                }
                return;
            }
            if (i35 == 2) {
                float fW = ((lpt3) this).f7408b == 0 ? ((lpt3) this).f1385a.w() : ((lpt3) this).f1385a.P();
                if (z2) {
                    fW = 1.0f - fW;
                }
                int i46 = (int) (((i15 - i5) * fW) + 0.5f);
                if (i46 < 0 || i6 > 0) {
                    i46 = i9;
                }
                int i47 = z2 ? i8 - i46 : i8 + i46;
                for (int i48 = i9; i48 < size; i48++) {
                    lpt3 lpt3Var6 = this.f7414a.get(z2 ? size - (i48 + 1) : i48);
                    if (lpt3Var6.f1385a.T() == 8) {
                        lpt3Var6.f1380a.d(i47);
                        lpt3Var6.f1387b.d(i47);
                    } else {
                        if (i48 > 0 && i48 >= i16) {
                            i47 = z2 ? i47 - lpt3Var6.f1380a.f7364a : i47 + lpt3Var6.f1380a.f7364a;
                        }
                        if (z2) {
                            lpt3Var6.f1387b.d(i47);
                        } else {
                            lpt3Var6.f1380a.d(i47);
                        }
                        com3 com3Var5 = lpt3Var6.f1381a;
                        int i49 = ((com2) com3Var5).f7365b;
                        if (lpt3Var6.f1384a == p.con.MATCH_CONSTRAINT && lpt3Var6.f7407a == 1) {
                            i49 = com3Var5.f7375d;
                        }
                        i47 = z2 ? i47 - i49 : i47 + i49;
                        if (z2) {
                            lpt3Var6.f1380a.d(i47);
                        } else {
                            lpt3Var6.f1387b.d(i47);
                        }
                        if (i48 < i17 && i48 < i2) {
                            i47 = z2 ? i47 - (-lpt3Var6.f1387b.f7364a) : i47 + (-lpt3Var6.f1387b.f7364a);
                        }
                    }
                }
            }
        }
    }

    @Override // NUL.lpt3
    public void d() {
        Iterator<lpt3> it = this.f7414a.iterator();
        while (it.hasNext()) {
            it.next().d();
        }
        int size = this.f7414a.size();
        if (size < 1) {
            return;
        }
        p pVar = this.f7414a.get(0).f1385a;
        p pVar2 = this.f7414a.get(size - 1).f1385a;
        if (((lpt3) this).f7408b == 0) {
            o oVar = pVar.f4944a;
            o oVar2 = pVar2.f4965c;
            com2 com2VarI = i(oVar, 0);
            int iE = oVar.e();
            p pVarR = r();
            if (pVarR != null) {
                iE = pVarR.f4944a.e();
            }
            if (com2VarI != null) {
                b(((lpt3) this).f1380a, com2VarI, iE);
            }
            com2 com2VarI2 = i(oVar2, 0);
            int iE2 = oVar2.e();
            p pVarS = s();
            if (pVarS != null) {
                iE2 = pVarS.f4965c.e();
            }
            if (com2VarI2 != null) {
                b(((lpt3) this).f1387b, com2VarI2, -iE2);
            }
        } else {
            o oVar3 = pVar.f4957b;
            o oVar4 = pVar2.f4969d;
            com2 com2VarI3 = i(oVar3, 1);
            int iE3 = oVar3.e();
            p pVarR2 = r();
            if (pVarR2 != null) {
                iE3 = pVarR2.f4957b.e();
            }
            if (com2VarI3 != null) {
                b(((lpt3) this).f1380a, com2VarI3, iE3);
            }
            com2 com2VarI4 = i(oVar4, 1);
            int iE4 = oVar4.e();
            p pVarS2 = s();
            if (pVarS2 != null) {
                iE4 = pVarS2.f4969d.e();
            }
            if (com2VarI4 != null) {
                b(((lpt3) this).f1387b, com2VarI4, -iE4);
            }
        }
        ((lpt3) this).f1380a.f1357a = this;
        ((lpt3) this).f1387b.f1357a = this;
    }

    @Override // NUL.lpt3
    public void e() {
        for (int i2 = 0; i2 < this.f7414a.size(); i2++) {
            this.f7414a.get(i2).e();
        }
    }

    @Override // NUL.lpt3
    public void f() {
        ((lpt3) this).f1382a = null;
        Iterator<lpt3> it = this.f7414a.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
    }

    @Override // NUL.lpt3
    public long j() {
        int size = this.f7414a.size();
        long j2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            lpt3 lpt3Var = this.f7414a.get(i2);
            j2 = j2 + ((long) lpt3Var.f1380a.f7364a) + lpt3Var.j() + ((long) lpt3Var.f1387b.f7364a);
        }
        return j2;
    }

    @Override // NUL.lpt3
    public boolean m() {
        int size = this.f7414a.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!this.f7414a.get(i2).m()) {
                return false;
            }
        }
        return true;
    }

    public final void q() {
        p pVar;
        p pVar2 = ((lpt3) this).f1385a;
        p pVarJ = pVar2.J(((lpt3) this).f7408b);
        while (true) {
            p pVar3 = pVarJ;
            pVar = pVar2;
            pVar2 = pVar3;
            if (pVar2 == null) {
                break;
            } else {
                pVarJ = pVar2.J(((lpt3) this).f7408b);
            }
        }
        ((lpt3) this).f1385a = pVar;
        this.f7414a.add(pVar.L(((lpt3) this).f7408b));
        p pVarH = pVar.H(((lpt3) this).f7408b);
        while (pVarH != null) {
            this.f7414a.add(pVarH.L(((lpt3) this).f7408b));
            pVarH = pVarH.H(((lpt3) this).f7408b);
        }
        for (lpt3 lpt3Var : this.f7414a) {
            int i2 = ((lpt3) this).f7408b;
            if (i2 == 0) {
                lpt3Var.f1385a.f4939a = this;
            } else if (i2 == 1) {
                lpt3Var.f1385a.f4955b = this;
            }
        }
        if ((((lpt3) this).f7408b == 0 && ((q) ((lpt3) this).f1385a.I()).L1()) && this.f7414a.size() > 1) {
            ArrayList<lpt3> arrayList = this.f7414a;
            ((lpt3) this).f1385a = arrayList.get(arrayList.size() - 1).f1385a;
        }
        this.f7415c = ((lpt3) this).f7408b == 0 ? ((lpt3) this).f1385a.x() : ((lpt3) this).f1385a.Q();
    }

    public final p r() {
        for (int i2 = 0; i2 < this.f7414a.size(); i2++) {
            lpt3 lpt3Var = this.f7414a.get(i2);
            if (lpt3Var.f1385a.T() != 8) {
                return lpt3Var.f1385a;
            }
        }
        return null;
    }

    public final p s() {
        for (int size = this.f7414a.size() - 1; size >= 0; size--) {
            lpt3 lpt3Var = this.f7414a.get(size);
            if (lpt3Var.f1385a.T() != 8) {
                return lpt3Var.f1385a;
            }
        }
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("ChainRun ");
        sb.append(((lpt3) this).f7408b == 0 ? "horizontal : " : "vertical : ");
        for (lpt3 lpt3Var : this.f7414a) {
            sb.append("<");
            sb.append(lpt3Var);
            sb.append("> ");
        }
        return sb.toString();
    }
}
