package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public abstract class com9 extends RecyclerView.com8 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f8675a = true;

    public final void A(RecyclerView.h hVar) {
        I(hVar);
        h(hVar);
    }

    public final void B(RecyclerView.h hVar) {
        J(hVar);
    }

    public final void C(RecyclerView.h hVar, boolean z2) {
        K(hVar, z2);
        h(hVar);
    }

    public final void D(RecyclerView.h hVar, boolean z2) {
        L(hVar, z2);
    }

    public final void E(RecyclerView.h hVar) {
        M(hVar);
        h(hVar);
    }

    public final void F(RecyclerView.h hVar) {
        N(hVar);
    }

    public final void G(RecyclerView.h hVar) {
        O(hVar);
        h(hVar);
    }

    public final void H(RecyclerView.h hVar) {
        P(hVar);
    }

    public void I(RecyclerView.h hVar) {
    }

    public void J(RecyclerView.h hVar) {
    }

    public void K(RecyclerView.h hVar, boolean z2) {
    }

    public void L(RecyclerView.h hVar, boolean z2) {
    }

    public void M(RecyclerView.h hVar) {
    }

    public void N(RecyclerView.h hVar) {
    }

    public void O(RecyclerView.h hVar) {
    }

    public void P(RecyclerView.h hVar) {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean a(RecyclerView.h hVar, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2) {
        int i2;
        int i3;
        return (nulVar == null || ((i2 = nulVar.f8566a) == (i3 = nulVar2.f8566a) && nulVar.f8567b == nulVar2.f8567b)) ? w(hVar) : y(hVar, i2, nulVar.f8567b, i3, nulVar2.f8567b);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean b(RecyclerView.h hVar, RecyclerView.h hVar2, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2) {
        int i2;
        int i3;
        int i4 = nulVar.f8566a;
        int i5 = nulVar.f8567b;
        if (hVar2.J()) {
            int i6 = nulVar.f8566a;
            i3 = nulVar.f8567b;
            i2 = i6;
        } else {
            i2 = nulVar2.f8566a;
            i3 = nulVar2.f8567b;
        }
        return x(hVar, hVar2, i4, i5, i2, i3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean c(RecyclerView.h hVar, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2) {
        int i2 = nulVar.f8566a;
        int i3 = nulVar.f8567b;
        View view = hVar.f2786a;
        int left = nulVar2 == null ? view.getLeft() : nulVar2.f8566a;
        int top = nulVar2 == null ? view.getTop() : nulVar2.f8567b;
        if (hVar.v() || (i2 == left && i3 == top)) {
            return z(hVar);
        }
        view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
        return y(hVar, i2, i3, left, top);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean d(RecyclerView.h hVar, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2) {
        int i2 = nulVar.f8566a;
        int i3 = nulVar2.f8566a;
        if (i2 != i3 || nulVar.f8567b != nulVar2.f8567b) {
            return y(hVar, i2, nulVar.f8567b, i3, nulVar2.f8567b);
        }
        E(hVar);
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com8
    public boolean f(RecyclerView.h hVar) {
        return !this.f8675a || hVar.t();
    }

    public abstract boolean w(RecyclerView.h hVar);

    public abstract boolean x(RecyclerView.h hVar, RecyclerView.h hVar2, int i2, int i3, int i4, int i5);

    public abstract boolean y(RecyclerView.h hVar, int i2, int i3, int i4, int i5);

    public abstract boolean z(RecyclerView.h hVar);
}
