package com.newrelic.agent.android.analytics;

/* JADX INFO: loaded from: classes.dex */
public interface EventListener {
    boolean onEventAdded(AnalyticsEvent analyticsEvent);

    boolean onEventEvicted(AnalyticsEvent analyticsEvent);

    void onEventFlush();

    boolean onEventOverflow(AnalyticsEvent analyticsEvent);

    void onEventQueueSizeExceeded(int i2);

    void onEventQueueTimeExceeded(int i2);

    void onShutdown();

    void onStart(EventManager eventManager);
}
