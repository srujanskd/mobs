package androidx.fragment.app;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
class FragmentManager$6 implements androidx.lifecycle.prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ com6 f8227a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final /* synthetic */ androidx.lifecycle.nul f2409a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final /* synthetic */ String f2410a;

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, androidx.lifecycle.nul.con conVar) {
        if (conVar == androidx.lifecycle.nul.con.ON_START && ((Bundle) this.f8227a.f2450a.get(this.f2410a)) != null) {
            throw null;
        }
        if (conVar == androidx.lifecycle.nul.con.ON_DESTROY) {
            this.f2409a.c(this);
            this.f8227a.f2458b.remove(this.f2410a);
        }
    }
}
