package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
class SingleGeneratedAdapterObserver implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final con f8385a;

    public SingleGeneratedAdapterObserver(con conVar) {
        this.f8385a = conVar;
    }

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        this.f8385a.a(com7Var, conVar, false, null);
        this.f8385a.a(com7Var, conVar, true, null);
    }
}
