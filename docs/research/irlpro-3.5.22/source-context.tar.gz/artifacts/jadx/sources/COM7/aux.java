package COM7;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: COM7.aux$aux, reason: collision with other inner class name */
    public class C0003aux extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ prn f5717a;

        public C0003aux(prn prnVar) {
            this.f5717a = prnVar;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f5717a.a();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f5717a.b();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static Animator a(prn prnVar, float f2, float f3, float f4) {
        ObjectAnimator objectAnimatorOfObject = ObjectAnimator.ofObject(prnVar, (Property<prn, V>) prn.nul.f5723a, (TypeEvaluator) prn.con.f5722a, (Object[]) new prn.com1[]{new prn.com1(f2, f3, f4)});
        prn.com1 revealInfo = prnVar.getRevealInfo();
        if (revealInfo == null) {
            throw new IllegalStateException("Caller must set a non-null RevealInfo before calling this.");
        }
        Animator animatorCreateCircularReveal = ViewAnimationUtils.createCircularReveal((View) prnVar, (int) f2, (int) f3, revealInfo.f5721c, f4);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(objectAnimatorOfObject, animatorCreateCircularReveal);
        return animatorSet;
    }

    public static Animator.AnimatorListener b(prn prnVar) {
        return new C0003aux(prnVar);
    }
}
