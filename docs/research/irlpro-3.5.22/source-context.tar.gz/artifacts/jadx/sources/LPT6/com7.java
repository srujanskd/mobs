package LPT6;

import inet.ipaddr.lpt3;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.stream.Stream;
import p039LPt7.i4;
import p039LPt7.j4;
import p115lPT6.j3;

/* JADX INFO: loaded from: classes.dex */
public interface com7 extends nul {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.nul, LPT6.com3, java.lang.Comparable
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    boolean contains(inet.ipaddr.com6 com6Var);

    boolean contains(lpt3 lpt3Var);

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsPrefixBlock(int i2) {
        return super.containsPrefixBlock(i2);
    }

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsSinglePrefixBlock(int i2) {
        return super.containsSinglePrefixBlock(i2);
    }

    inet.ipaddr.com6 coverWithPrefixBlock();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ int getBitCount();

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default int getByteCount() {
        return super.getByteCount();
    }

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ byte[] getBytes();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr);

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr, int i2);

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getCount() {
        return super.getCount();
    }

    @Override // LPT6.nul
    Iterable<? extends inet.ipaddr.com6> getIterable();

    @Override // LPT6.nul
    inet.ipaddr.com6 getLower();

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default int getMinPrefixLengthForBlock() {
        return super.getMinPrefixLengthForBlock();
    }

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getPrefixCount(int i2) {
        return super.getPrefixCount(i2);
    }

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default Integer getPrefixLengthForSingleBlock() {
        return super.getPrefixLengthForSingleBlock();
    }

    @Override // LPT6.nul
    inet.ipaddr.com6 getUpper();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ byte[] getUpperBytes();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr);

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr, int i2);

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ BigInteger getUpperValue();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ BigInteger getValue();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ boolean includesMax();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ boolean includesZero();

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default boolean isFullRange() {
        return super.isFullRange();
    }

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ boolean isMax();

    @Override // LPT6.nul, LPT6.com3
    /* bridge */ /* synthetic */ default boolean isMultiple() {
        return super.isMultiple();
    }

    boolean isSequential();

    @Override // LPT6.nul, LPT6.com3
    /* synthetic */ boolean isZero();

    @Override // LPT6.nul
    Iterator<? extends inet.ipaddr.com6> iterator();

    Iterator<? extends inet.ipaddr.com6> prefixBlockIterator(int i2);

    i4<? extends com7, ? extends inet.ipaddr.com6> prefixBlockSpliterator(int i2);

    Stream<? extends inet.ipaddr.com6> prefixBlockStream(int i2);

    Iterator<? extends com7> prefixIterator(int i2);

    j4<? extends com7> prefixSpliterator(int i2);

    Stream<? extends com7> prefixStream(int i2);

    inet.ipaddr.com6[] spanWithPrefixBlocks();

    inet.ipaddr.com6[] spanWithSequentialBlocks();

    @Override // LPT6.nul
    i4<? extends com7, ? extends inet.ipaddr.com6> spliterator();

    @Override // LPT6.nul
    /* synthetic */ Stream<? extends j3> stream();

    String toCanonicalString();

    String toNormalizedString();

    lpt3 toSequentialRange();
}
