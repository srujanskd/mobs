package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class Guideline extends View {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f8067b;

    public Guideline(Context context) {
        super(context);
        this.f8067b = true;
        super.setVisibility(8);
    }

    @Override // android.view.View
    @SuppressLint({"MissingSuperCall"})
    public void draw(Canvas canvas) {
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        setMeasuredDimension(0, 0);
    }

    public void setFilterRedundantCalls(boolean z2) {
        this.f8067b = z2;
    }

    public void setGuidelineBegin(int i2) {
        ConstraintLayout.con conVar = (ConstraintLayout.con) getLayoutParams();
        if (this.f8067b && conVar.f2171a == i2) {
            return;
        }
        conVar.f2171a = i2;
        setLayoutParams(conVar);
    }

    public void setGuidelineEnd(int i2) {
        ConstraintLayout.con conVar = (ConstraintLayout.con) getLayoutParams();
        if (this.f8067b && conVar.f2175b == i2) {
            return;
        }
        conVar.f2175b = i2;
        setLayoutParams(conVar);
    }

    public void setGuidelinePercent(float f2) {
        ConstraintLayout.con conVar = (ConstraintLayout.con) getLayoutParams();
        if (this.f8067b && conVar.f8034a == f2) {
            return;
        }
        conVar.f8034a = f2;
        setLayoutParams(conVar);
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
    }

    public Guideline(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f8067b = true;
        super.setVisibility(8);
    }
}
