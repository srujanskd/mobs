package COM9;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import p075cOM6.h4;

/* JADX INFO: loaded from: classes.dex */
public class com7 {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final COM9.nul f5740e = new com5(0.5f);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public com2 f5741a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM9.nul f110a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f111a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public com2 f5742b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public COM9.nul f112b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public prn f113b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public com2 f5743c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public COM9.nul f114c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public prn f115c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public com2 f5744d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public COM9.nul f116d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public prn f117d;

    public interface nul {
        COM9.nul a(COM9.nul nulVar);
    }

    public static con a() {
        return new con();
    }

    public static con b(Context context, int i2, int i3) {
        return c(context, i2, i3, 0);
    }

    public static con c(Context context, int i2, int i3, int i4) {
        return d(context, i2, i3, new COM9.aux(i4));
    }

    public static con d(Context context, int i2, int i3, COM9.nul nulVar) {
        if (i3 != 0) {
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, i2);
            i2 = i3;
            context = contextThemeWrapper;
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(i2, h4.f3121e1);
        try {
            int i4 = typedArrayObtainStyledAttributes.getInt(h4.f2, 0);
            int i5 = typedArrayObtainStyledAttributes.getInt(h4.i2, i4);
            int i6 = typedArrayObtainStyledAttributes.getInt(h4.j2, i4);
            int i7 = typedArrayObtainStyledAttributes.getInt(h4.h2, i4);
            int i8 = typedArrayObtainStyledAttributes.getInt(h4.g2, i4);
            COM9.nul nulVarM = m(typedArrayObtainStyledAttributes, h4.k2, nulVar);
            COM9.nul nulVarM2 = m(typedArrayObtainStyledAttributes, h4.n2, nulVarM);
            COM9.nul nulVarM3 = m(typedArrayObtainStyledAttributes, h4.o2, nulVarM);
            COM9.nul nulVarM4 = m(typedArrayObtainStyledAttributes, h4.m2, nulVarM);
            return new con().y(i5, nulVarM2).C(i6, nulVarM3).u(i7, nulVarM4).q(i8, m(typedArrayObtainStyledAttributes, h4.l2, nulVarM));
        } finally {
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public static con e(Context context, AttributeSet attributeSet, int i2, int i3) {
        return f(context, attributeSet, i2, i3, 0);
    }

    public static con f(Context context, AttributeSet attributeSet, int i2, int i3, int i4) {
        return g(context, attributeSet, i2, i3, new COM9.aux(i4));
    }

    public static con g(Context context, AttributeSet attributeSet, int i2, int i3, COM9.nul nulVar) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3051A0, i2, i3);
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(h4.O1, 0);
        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(h4.P1, 0);
        typedArrayObtainStyledAttributes.recycle();
        return d(context, resourceId, resourceId2, nulVar);
    }

    public static COM9.nul m(TypedArray typedArray, int i2, COM9.nul nulVar) {
        TypedValue typedValuePeekValue = typedArray.peekValue(i2);
        if (typedValuePeekValue == null) {
            return nulVar;
        }
        int i3 = typedValuePeekValue.type;
        if (i3 == 5) {
            return new COM9.aux(TypedValue.complexToDimensionPixelSize(typedValuePeekValue.data, typedArray.getResources().getDisplayMetrics()));
        }
        return i3 == 6 ? new com5(typedValuePeekValue.getFraction(1.0f, 1.0f)) : nulVar;
    }

    public com2 h() {
        return this.f5743c;
    }

    public prn i() {
        return this.f117d;
    }

    public COM9.nul j() {
        return this.f116d;
    }

    public prn k() {
        return this.f115c;
    }

    public COM9.nul l() {
        return this.f114c;
    }

    public com2 n() {
        return this.f5744d;
    }

    public com2 o() {
        return this.f5742b;
    }

    public com2 p() {
        return this.f5741a;
    }

    public prn q() {
        return this.f111a;
    }

    public COM9.nul r() {
        return this.f110a;
    }

    public prn s() {
        return this.f113b;
    }

    public COM9.nul t() {
        return this.f112b;
    }

    public boolean u(RectF rectF) {
        boolean z2 = this.f5744d.getClass().equals(com2.class) && this.f5742b.getClass().equals(com2.class) && this.f5741a.getClass().equals(com2.class) && this.f5743c.getClass().equals(com2.class);
        float fA = this.f110a.a(rectF);
        return z2 && ((this.f112b.a(rectF) > fA ? 1 : (this.f112b.a(rectF) == fA ? 0 : -1)) == 0 && (this.f116d.a(rectF) > fA ? 1 : (this.f116d.a(rectF) == fA ? 0 : -1)) == 0 && (this.f114c.a(rectF) > fA ? 1 : (this.f114c.a(rectF) == fA ? 0 : -1)) == 0) && ((this.f113b instanceof com6) && (this.f111a instanceof com6) && (this.f115c instanceof com6) && (this.f117d instanceof com6));
    }

    public con v() {
        return new con(this);
    }

    public com7 w(float f2) {
        return v().o(f2).m();
    }

    public com7 x(COM9.nul nulVar) {
        return v().p(nulVar).m();
    }

    public com7 y(nul nulVar) {
        return v().B(nulVar.a(r())).F(nulVar.a(t())).t(nulVar.a(j())).x(nulVar.a(l())).m();
    }

    public com7(con conVar) {
        this.f111a = conVar.f119a;
        this.f113b = conVar.f121b;
        this.f115c = conVar.f123c;
        this.f117d = conVar.f125d;
        this.f110a = conVar.f118a;
        this.f112b = conVar.f120b;
        this.f114c = conVar.f122c;
        this.f116d = conVar.f124d;
        this.f5741a = conVar.f5745a;
        this.f5742b = conVar.f5746b;
        this.f5743c = conVar.f5747c;
        this.f5744d = conVar.f5748d;
    }

    public static final class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public com2 f5745a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public COM9.nul f118a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public prn f119a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public com2 f5746b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public COM9.nul f120b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public prn f121b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public com2 f5747c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public COM9.nul f122c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public prn f123c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public com2 f5748d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public COM9.nul f124d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public prn f125d;

        public con() {
            this.f119a = com4.b();
            this.f121b = com4.b();
            this.f123c = com4.b();
            this.f125d = com4.b();
            this.f118a = new COM9.aux(0.0f);
            this.f120b = new COM9.aux(0.0f);
            this.f122c = new COM9.aux(0.0f);
            this.f124d = new COM9.aux(0.0f);
            this.f5745a = com4.c();
            this.f5746b = com4.c();
            this.f5747c = com4.c();
            this.f5748d = com4.c();
        }

        public static float n(prn prnVar) {
            if (prnVar instanceof com6) {
                return ((com6) prnVar).f5739a;
            }
            if (prnVar instanceof com1) {
                return ((com1) prnVar).f5726a;
            }
            return -1.0f;
        }

        public con A(float f2) {
            this.f118a = new COM9.aux(f2);
            return this;
        }

        public con B(COM9.nul nulVar) {
            this.f118a = nulVar;
            return this;
        }

        public con C(int i2, COM9.nul nulVar) {
            return D(com4.a(i2)).F(nulVar);
        }

        public con D(prn prnVar) {
            this.f121b = prnVar;
            float fN = n(prnVar);
            if (fN != -1.0f) {
                E(fN);
            }
            return this;
        }

        public con E(float f2) {
            this.f120b = new COM9.aux(f2);
            return this;
        }

        public con F(COM9.nul nulVar) {
            this.f120b = nulVar;
            return this;
        }

        public com7 m() {
            return new com7(this);
        }

        public con o(float f2) {
            return A(f2).E(f2).w(f2).s(f2);
        }

        public con p(COM9.nul nulVar) {
            return B(nulVar).F(nulVar).x(nulVar).t(nulVar);
        }

        public con q(int i2, COM9.nul nulVar) {
            return r(com4.a(i2)).t(nulVar);
        }

        public con r(prn prnVar) {
            this.f125d = prnVar;
            float fN = n(prnVar);
            if (fN != -1.0f) {
                s(fN);
            }
            return this;
        }

        public con s(float f2) {
            this.f124d = new COM9.aux(f2);
            return this;
        }

        public con t(COM9.nul nulVar) {
            this.f124d = nulVar;
            return this;
        }

        public con u(int i2, COM9.nul nulVar) {
            return v(com4.a(i2)).x(nulVar);
        }

        public con v(prn prnVar) {
            this.f123c = prnVar;
            float fN = n(prnVar);
            if (fN != -1.0f) {
                w(fN);
            }
            return this;
        }

        public con w(float f2) {
            this.f122c = new COM9.aux(f2);
            return this;
        }

        public con x(COM9.nul nulVar) {
            this.f122c = nulVar;
            return this;
        }

        public con y(int i2, COM9.nul nulVar) {
            return z(com4.a(i2)).B(nulVar);
        }

        public con z(prn prnVar) {
            this.f119a = prnVar;
            float fN = n(prnVar);
            if (fN != -1.0f) {
                A(fN);
            }
            return this;
        }

        public con(com7 com7Var) {
            this.f119a = com4.b();
            this.f121b = com4.b();
            this.f123c = com4.b();
            this.f125d = com4.b();
            this.f118a = new COM9.aux(0.0f);
            this.f120b = new COM9.aux(0.0f);
            this.f122c = new COM9.aux(0.0f);
            this.f124d = new COM9.aux(0.0f);
            this.f5745a = com4.c();
            this.f5746b = com4.c();
            this.f5747c = com4.c();
            this.f5748d = com4.c();
            this.f119a = com7Var.f111a;
            this.f121b = com7Var.f113b;
            this.f123c = com7Var.f115c;
            this.f125d = com7Var.f117d;
            this.f118a = com7Var.f110a;
            this.f120b = com7Var.f112b;
            this.f122c = com7Var.f114c;
            this.f124d = com7Var.f116d;
            this.f5745a = com7Var.f5741a;
            this.f5746b = com7Var.f5742b;
            this.f5747c = com7Var.f5743c;
            this.f5748d = com7Var.f5744d;
        }
    }

    public com7() {
        this.f111a = com4.b();
        this.f113b = com4.b();
        this.f115c = com4.b();
        this.f117d = com4.b();
        this.f110a = new COM9.aux(0.0f);
        this.f112b = new COM9.aux(0.0f);
        this.f114c = new COM9.aux(0.0f);
        this.f116d = new COM9.aux(0.0f);
        this.f5741a = com4.c();
        this.f5742b = com4.c();
        this.f5743c = com4.c();
        this.f5744d = com4.c();
    }
}
