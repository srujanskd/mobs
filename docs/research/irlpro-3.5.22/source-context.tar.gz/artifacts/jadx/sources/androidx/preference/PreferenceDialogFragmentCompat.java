package androidx.preference;

import COM3.com7;
import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.TextView;
import androidx.fragment.app.DialogFragment;

/* JADX INFO: loaded from: classes.dex */
public abstract class PreferenceDialogFragmentCompat extends DialogFragment implements DialogInterface.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8447a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public BitmapDrawable f2641a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public DialogPreference f2642a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2643a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8448b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f2644b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f8449c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f8450d;

    public static class aux {
        public static void a(Window window) {
            window.getDecorView().getWindowInsetsController().show(WindowInsets.Type.ime());
        }
    }

    public DialogPreference j() {
        if (this.f2642a == null) {
            this.f2642a = (DialogPreference) ((DialogPreference.aux) getTargetFragment()).a(requireArguments().getString("key"));
        }
        return this.f2642a;
    }

    public boolean k() {
        return false;
    }

    public void l(View view) {
        int i2;
        View viewFindViewById = view.findViewById(R.id.message);
        if (viewFindViewById != null) {
            CharSequence charSequence = this.f8450d;
            if (TextUtils.isEmpty(charSequence)) {
                i2 = 8;
            } else {
                if (viewFindViewById instanceof TextView) {
                    ((TextView) viewFindViewById).setText(charSequence);
                }
                i2 = 0;
            }
            if (viewFindViewById.getVisibility() != i2) {
                viewFindViewById.setVisibility(i2);
            }
        }
    }

    public View m(Context context) {
        int i2 = this.f8447a;
        if (i2 == 0) {
            return null;
        }
        return getLayoutInflater().inflate(i2, (ViewGroup) null);
    }

    public abstract void n(boolean z2);

    public void o(androidx.appcompat.app.aux.C0023aux c0023aux) {
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i2) {
        this.f8448b = i2;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        com7 targetFragment = getTargetFragment();
        if (!(targetFragment instanceof DialogPreference.aux)) {
            throw new IllegalStateException("Target fragment must implement TargetFragment interface");
        }
        DialogPreference.aux auxVar = (DialogPreference.aux) targetFragment;
        String string = requireArguments().getString("key");
        if (bundle != null) {
            this.f2643a = bundle.getCharSequence("PreferenceDialogFragment.title");
            this.f2644b = bundle.getCharSequence("PreferenceDialogFragment.positiveText");
            this.f8449c = bundle.getCharSequence("PreferenceDialogFragment.negativeText");
            this.f8450d = bundle.getCharSequence("PreferenceDialogFragment.message");
            this.f8447a = bundle.getInt("PreferenceDialogFragment.layout", 0);
            Bitmap bitmap = (Bitmap) bundle.getParcelable("PreferenceDialogFragment.icon");
            if (bitmap != null) {
                this.f2641a = new BitmapDrawable(getResources(), bitmap);
                return;
            }
            return;
        }
        DialogPreference dialogPreference = (DialogPreference) auxVar.a(string);
        this.f2642a = dialogPreference;
        this.f2643a = dialogPreference.getDialogTitle();
        this.f2644b = this.f2642a.getPositiveButtonText();
        this.f8449c = this.f2642a.getNegativeButtonText();
        this.f8450d = this.f2642a.getDialogMessage();
        this.f8447a = this.f2642a.getDialogLayoutResource();
        Drawable dialogIcon = this.f2642a.getDialogIcon();
        if (dialogIcon == null || (dialogIcon instanceof BitmapDrawable)) {
            this.f2641a = (BitmapDrawable) dialogIcon;
            return;
        }
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(dialogIcon.getIntrinsicWidth(), dialogIcon.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        dialogIcon.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        dialogIcon.draw(canvas);
        this.f2641a = new BitmapDrawable(getResources(), bitmapCreateBitmap);
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        this.f8448b = -2;
        androidx.appcompat.app.aux.C0023aux c0023auxK = new androidx.appcompat.app.aux.C0023aux(requireContext()).s(this.f2643a).f(this.f2641a).o(this.f2644b, this).k(this.f8449c, this);
        View viewM = m(requireContext());
        if (viewM != null) {
            l(viewM);
            c0023auxK.t(viewM);
        } else {
            c0023auxK.h(this.f8450d);
        }
        o(c0023auxK);
        androidx.appcompat.app.aux auxVarA = c0023auxK.a();
        if (k()) {
            p(auxVarA);
        }
        return auxVarA;
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        super.onDismiss(dialogInterface);
        n(this.f8448b == -1);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putCharSequence("PreferenceDialogFragment.title", this.f2643a);
        bundle.putCharSequence("PreferenceDialogFragment.positiveText", this.f2644b);
        bundle.putCharSequence("PreferenceDialogFragment.negativeText", this.f8449c);
        bundle.putCharSequence("PreferenceDialogFragment.message", this.f8450d);
        bundle.putInt("PreferenceDialogFragment.layout", this.f8447a);
        BitmapDrawable bitmapDrawable = this.f2641a;
        if (bitmapDrawable != null) {
            bundle.putParcelable("PreferenceDialogFragment.icon", bitmapDrawable.getBitmap());
        }
    }

    public final void p(Dialog dialog) {
        Window window = dialog.getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            aux.a(window);
        } else {
            q();
        }
    }

    public void q() {
    }
}
