package NUL;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import p146nUL.o;
import p146nUL.p;
import p146nUL.q;
import p146nUL.r;
import p146nUL.t;
import p146nUL.w;

/* JADX INFO: loaded from: classes.dex */
public class com1 {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public q f1350a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public q f1352b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1351a = true;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1353b = true;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<lpt3> f1349a = new ArrayList<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList<com9> f7362b = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con.InterfaceC0018con f1348a = null;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public con.aux f7361a = new con.aux();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ArrayList<com9> f7363c = new ArrayList<>();

    public com1(q qVar) {
        this.f1350a = qVar;
        this.f1352b = qVar;
    }

    public final void a(com2 com2Var, int i2, int i3, com2 com2Var2, ArrayList<com9> arrayList, com9 com9Var) {
        lpt3 lpt3Var = com2Var.f1356a;
        if (lpt3Var.f1382a == null) {
            q qVar = this.f1350a;
            if (lpt3Var == ((p) qVar).f4937a || lpt3Var == ((p) qVar).f4938a) {
                return;
            }
            if (com9Var == null) {
                com9Var = new com9(lpt3Var, i3);
                arrayList.add(com9Var);
            }
            lpt3Var.f1382a = com9Var;
            com9Var.a(lpt3Var);
            for (prn prnVar : lpt3Var.f1380a.f1358a) {
                if (prnVar instanceof com2) {
                    a((com2) prnVar, i2, 0, com2Var2, arrayList, com9Var);
                }
            }
            for (prn prnVar2 : lpt3Var.f1387b.f1358a) {
                if (prnVar2 instanceof com2) {
                    a((com2) prnVar2, i2, 1, com2Var2, arrayList, com9Var);
                }
            }
            if (i2 == 1 && (lpt3Var instanceof lpt1)) {
                for (prn prnVar3 : ((lpt1) lpt3Var).f7395c.f1358a) {
                    if (prnVar3 instanceof com2) {
                        a((com2) prnVar3, i2, 2, com2Var2, arrayList, com9Var);
                    }
                }
            }
            for (com2 com2Var3 : lpt3Var.f1380a.f1360b) {
                if (com2Var3 == com2Var2) {
                    com9Var.f1367a = true;
                }
                a(com2Var3, i2, 0, com2Var2, arrayList, com9Var);
            }
            for (com2 com2Var4 : lpt3Var.f1387b.f1360b) {
                if (com2Var4 == com2Var2) {
                    com9Var.f1367a = true;
                }
                a(com2Var4, i2, 1, com2Var2, arrayList, com9Var);
            }
            if (i2 == 1 && (lpt3Var instanceof lpt1)) {
                Iterator<com2> it = ((lpt1) lpt3Var).f7395c.f1360b.iterator();
                while (it.hasNext()) {
                    a(it.next(), i2, 2, com2Var2, arrayList, com9Var);
                }
            }
        }
    }

    public final boolean b(q qVar) {
        int iU;
        p.con conVar;
        int iV;
        p.con conVar2;
        p.con conVar3;
        p.con conVar4;
        for (p pVar : ((w) qVar).f11546b) {
            p.con[] conVarArr = pVar.f4951a;
            p.con conVar5 = conVarArr[0];
            p.con conVar6 = conVarArr[1];
            if (pVar.T() == 8) {
                pVar.f4946a = true;
            } else {
                if (pVar.f11496a < 1.0f && conVar5 == p.con.MATCH_CONSTRAINT) {
                    pVar.f4974f = 2;
                }
                if (pVar.f11497b < 1.0f && conVar6 == p.con.MATCH_CONSTRAINT) {
                    pVar.f4977g = 2;
                }
                if (pVar.t() > 0.0f) {
                    p.con conVar7 = p.con.MATCH_CONSTRAINT;
                    if (conVar5 == conVar7 && (conVar6 == p.con.WRAP_CONTENT || conVar6 == p.con.FIXED)) {
                        pVar.f4974f = 3;
                    } else if (conVar6 == conVar7 && (conVar5 == p.con.WRAP_CONTENT || conVar5 == p.con.FIXED)) {
                        pVar.f4977g = 3;
                    } else if (conVar5 == conVar7 && conVar6 == conVar7) {
                        if (pVar.f4974f == 0) {
                            pVar.f4974f = 3;
                        }
                        if (pVar.f4977g == 0) {
                            pVar.f4977g = 3;
                        }
                    }
                }
                p.con conVar8 = p.con.MATCH_CONSTRAINT;
                if (conVar5 == conVar8 && pVar.f4974f == 1 && (pVar.f4944a.f4932a == null || pVar.f4965c.f4932a == null)) {
                    conVar5 = p.con.WRAP_CONTENT;
                }
                p.con conVar9 = conVar5;
                if (conVar6 == conVar8 && pVar.f4977g == 1 && (pVar.f4957b.f4932a == null || pVar.f4969d.f4932a == null)) {
                    conVar6 = p.con.WRAP_CONTENT;
                }
                p.con conVar10 = conVar6;
                com8 com8Var = pVar.f4937a;
                ((lpt3) com8Var).f1384a = conVar9;
                int i2 = pVar.f4974f;
                ((lpt3) com8Var).f7407a = i2;
                lpt1 lpt1Var = pVar.f4938a;
                ((lpt3) lpt1Var).f1384a = conVar10;
                int i3 = pVar.f4977g;
                ((lpt3) lpt1Var).f7407a = i3;
                p.con conVar11 = p.con.MATCH_PARENT;
                if ((conVar9 == conVar11 || conVar9 == p.con.FIXED || conVar9 == p.con.WRAP_CONTENT) && (conVar10 == conVar11 || conVar10 == p.con.FIXED || conVar10 == p.con.WRAP_CONTENT)) {
                    int iU2 = pVar.U();
                    if (conVar9 == conVar11) {
                        iU = (qVar.U() - pVar.f4944a.f11483b) - pVar.f4965c.f11483b;
                        conVar = p.con.FIXED;
                    } else {
                        iU = iU2;
                        conVar = conVar9;
                    }
                    int iV2 = pVar.v();
                    if (conVar10 == conVar11) {
                        iV = (qVar.v() - pVar.f4957b.f11483b) - pVar.f4969d.f11483b;
                        conVar2 = p.con.FIXED;
                    } else {
                        iV = iV2;
                        conVar2 = conVar10;
                    }
                    l(pVar, conVar, iU, conVar2, iV);
                    ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                    ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                    pVar.f4946a = true;
                } else {
                    if (conVar9 == conVar8 && (conVar10 == (conVar4 = p.con.WRAP_CONTENT) || conVar10 == p.con.FIXED)) {
                        if (i2 == 3) {
                            if (conVar10 == conVar4) {
                                l(pVar, conVar4, 0, conVar4, 0);
                            }
                            int iV3 = pVar.v();
                            int i4 = (int) ((iV3 * pVar.f11500e) + 0.5f);
                            p.con conVar12 = p.con.FIXED;
                            l(pVar, conVar12, i4, conVar12, iV3);
                            ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                            ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                            pVar.f4946a = true;
                        } else if (i2 == 1) {
                            l(pVar, conVar4, 0, conVar10, 0);
                            ((lpt3) pVar.f4937a).f1381a.f7375d = pVar.U();
                        } else if (i2 == 2) {
                            p.con conVar13 = ((p) qVar).f4951a[0];
                            p.con conVar14 = p.con.FIXED;
                            if (conVar13 == conVar14 || conVar13 == conVar11) {
                                l(pVar, conVar14, (int) ((pVar.f11496a * qVar.U()) + 0.5f), conVar10, pVar.v());
                                ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                                ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                                pVar.f4946a = true;
                            }
                        } else {
                            o[] oVarArr = pVar.f4950a;
                            if (oVarArr[0].f4932a == null || oVarArr[1].f4932a == null) {
                                l(pVar, conVar4, 0, conVar10, 0);
                                ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                                ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                                pVar.f4946a = true;
                            }
                        }
                    }
                    if (conVar10 == conVar8 && (conVar9 == (conVar3 = p.con.WRAP_CONTENT) || conVar9 == p.con.FIXED)) {
                        if (i3 == 3) {
                            if (conVar9 == conVar3) {
                                l(pVar, conVar3, 0, conVar3, 0);
                            }
                            int iU3 = pVar.U();
                            float f2 = pVar.f11500e;
                            if (pVar.u() == -1) {
                                f2 = 1.0f / f2;
                            }
                            p.con conVar15 = p.con.FIXED;
                            l(pVar, conVar15, iU3, conVar15, (int) ((iU3 * f2) + 0.5f));
                            ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                            ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                            pVar.f4946a = true;
                        } else if (i3 == 1) {
                            l(pVar, conVar9, 0, conVar3, 0);
                            ((lpt3) pVar.f4938a).f1381a.f7375d = pVar.v();
                        } else if (i3 == 2) {
                            p.con conVar16 = ((p) qVar).f4951a[1];
                            p.con conVar17 = p.con.FIXED;
                            if (conVar16 == conVar17 || conVar16 == conVar11) {
                                l(pVar, conVar9, pVar.U(), conVar17, (int) ((pVar.f11497b * qVar.v()) + 0.5f));
                                ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                                ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                                pVar.f4946a = true;
                            }
                        } else {
                            o[] oVarArr2 = pVar.f4950a;
                            if (oVarArr2[2].f4932a == null || oVarArr2[3].f4932a == null) {
                                l(pVar, conVar3, 0, conVar10, 0);
                                ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                                ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                                pVar.f4946a = true;
                            }
                        }
                    }
                    if (conVar9 == conVar8 && conVar10 == conVar8) {
                        if (i2 == 1 || i3 == 1) {
                            p.con conVar18 = p.con.WRAP_CONTENT;
                            l(pVar, conVar18, 0, conVar18, 0);
                            ((lpt3) pVar.f4937a).f1381a.f7375d = pVar.U();
                            ((lpt3) pVar.f4938a).f1381a.f7375d = pVar.v();
                        } else if (i3 == 2 && i2 == 2) {
                            p.con[] conVarArr2 = ((p) qVar).f4951a;
                            p.con conVar19 = conVarArr2[0];
                            p.con conVar20 = p.con.FIXED;
                            if (conVar19 == conVar20 && conVarArr2[1] == conVar20) {
                                l(pVar, conVar20, (int) ((pVar.f11496a * qVar.U()) + 0.5f), conVar20, (int) ((pVar.f11497b * qVar.v()) + 0.5f));
                                ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                                ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                                pVar.f4946a = true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public void c() {
        d(this.f1349a);
        this.f7363c.clear();
        com9.f7380d = 0;
        i(((p) this.f1350a).f4937a, 0, this.f7363c);
        i(((p) this.f1350a).f4938a, 1, this.f7363c);
        this.f1351a = false;
    }

    public void d(ArrayList<lpt3> arrayList) {
        arrayList.clear();
        ((p) this.f1352b).f4937a.f();
        ((p) this.f1352b).f4938a.f();
        arrayList.add(((p) this.f1352b).f4937a);
        arrayList.add(((p) this.f1352b).f4938a);
        HashSet hashSet = null;
        for (p pVar : ((w) this.f1352b).f11546b) {
            if (pVar instanceof r) {
                arrayList.add(new com6(pVar));
            } else {
                if (pVar.g0()) {
                    if (pVar.f4939a == null) {
                        pVar.f4939a = new nul(pVar, 0);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(pVar.f4939a);
                } else {
                    arrayList.add(pVar.f4937a);
                }
                if (pVar.i0()) {
                    if (pVar.f4955b == null) {
                        pVar.f4955b = new nul(pVar, 1);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(pVar.f4955b);
                } else {
                    arrayList.add(pVar.f4938a);
                }
                if (pVar instanceof t) {
                    arrayList.add(new com7(pVar));
                }
            }
        }
        if (hashSet != null) {
            arrayList.addAll(hashSet);
        }
        Iterator<lpt3> it = arrayList.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
        for (lpt3 lpt3Var : arrayList) {
            if (lpt3Var.f1385a != this.f1352b) {
                lpt3Var.d();
            }
        }
    }

    public final int e(q qVar, int i2) {
        int size = this.f7363c.size();
        long jMax = 0;
        for (int i3 = 0; i3 < size; i3++) {
            jMax = Math.max(jMax, this.f7363c.get(i3).b(qVar, i2));
        }
        return (int) jMax;
    }

    public boolean f(boolean z2) {
        boolean z3;
        boolean z4 = true;
        boolean z5 = z2 & true;
        if (this.f1351a || this.f1353b) {
            for (p pVar : ((w) this.f1350a).f11546b) {
                pVar.l();
                pVar.f4946a = false;
                pVar.f4937a.r();
                pVar.f4938a.q();
            }
            this.f1350a.l();
            q qVar = this.f1350a;
            ((p) qVar).f4946a = false;
            ((p) qVar).f4937a.r();
            ((p) this.f1350a).f4938a.q();
            this.f1353b = false;
        }
        if (b(this.f1352b)) {
            return false;
        }
        this.f1350a.j1(0);
        this.f1350a.k1(0);
        p.con conVarS = this.f1350a.s(0);
        p.con conVarS2 = this.f1350a.s(1);
        if (this.f1351a) {
            c();
        }
        int iV = this.f1350a.V();
        int iW = this.f1350a.W();
        ((lpt3) ((p) this.f1350a).f4937a).f1380a.d(iV);
        ((lpt3) ((p) this.f1350a).f4938a).f1380a.d(iW);
        m();
        p.con conVar = p.con.WRAP_CONTENT;
        if (conVarS == conVar || conVarS2 == conVar) {
            if (z5) {
                Iterator<lpt3> it = this.f1349a.iterator();
                while (it.hasNext()) {
                    if (!it.next().m()) {
                        z5 = false;
                        break;
                    }
                }
            }
            if (z5 && conVarS == p.con.WRAP_CONTENT) {
                this.f1350a.M0(p.con.FIXED);
                q qVar2 = this.f1350a;
                qVar2.h1(e(qVar2, 0));
                q qVar3 = this.f1350a;
                ((lpt3) ((p) qVar3).f4937a).f1381a.d(qVar3.U());
            }
            if (z5 && conVarS2 == p.con.WRAP_CONTENT) {
                this.f1350a.d1(p.con.FIXED);
                q qVar4 = this.f1350a;
                qVar4.I0(e(qVar4, 1));
                q qVar5 = this.f1350a;
                ((lpt3) ((p) qVar5).f4938a).f1381a.d(qVar5.v());
            }
        }
        q qVar6 = this.f1350a;
        p.con conVar2 = ((p) qVar6).f4951a[0];
        p.con conVar3 = p.con.FIXED;
        if (conVar2 == conVar3 || conVar2 == p.con.MATCH_PARENT) {
            int iU = qVar6.U() + iV;
            ((lpt3) ((p) this.f1350a).f4937a).f1387b.d(iU);
            ((lpt3) ((p) this.f1350a).f4937a).f1381a.d(iU - iV);
            m();
            q qVar7 = this.f1350a;
            p.con conVar4 = ((p) qVar7).f4951a[1];
            if (conVar4 == conVar3 || conVar4 == p.con.MATCH_PARENT) {
                int iV2 = qVar7.v() + iW;
                ((lpt3) ((p) this.f1350a).f4938a).f1387b.d(iV2);
                ((lpt3) ((p) this.f1350a).f4938a).f1381a.d(iV2 - iW);
            }
            m();
            z3 = true;
        } else {
            z3 = false;
        }
        for (lpt3 lpt3Var : this.f1349a) {
            if (lpt3Var.f1385a != this.f1350a || lpt3Var.f1386a) {
                lpt3Var.e();
            }
        }
        for (lpt3 lpt3Var2 : this.f1349a) {
            if (z3 || lpt3Var2.f1385a != this.f1350a) {
                if (!lpt3Var2.f1380a.f1362c || ((!lpt3Var2.f1387b.f1362c && !(lpt3Var2 instanceof com6)) || (!((com2) lpt3Var2.f1381a).f1362c && !(lpt3Var2 instanceof nul) && !(lpt3Var2 instanceof com6)))) {
                    z4 = false;
                    break;
                }
            }
        }
        this.f1350a.M0(conVarS);
        this.f1350a.d1(conVarS2);
        return z4;
    }

    public boolean g(boolean z2) {
        if (this.f1351a) {
            for (p pVar : ((w) this.f1350a).f11546b) {
                pVar.l();
                pVar.f4946a = false;
                com8 com8Var = pVar.f4937a;
                ((com2) ((lpt3) com8Var).f1381a).f1362c = false;
                ((lpt3) com8Var).f1386a = false;
                com8Var.r();
                lpt1 lpt1Var = pVar.f4938a;
                ((com2) ((lpt3) lpt1Var).f1381a).f1362c = false;
                ((lpt3) lpt1Var).f1386a = false;
                lpt1Var.q();
            }
            this.f1350a.l();
            q qVar = this.f1350a;
            ((p) qVar).f4946a = false;
            com8 com8Var2 = ((p) qVar).f4937a;
            ((com2) ((lpt3) com8Var2).f1381a).f1362c = false;
            ((lpt3) com8Var2).f1386a = false;
            com8Var2.r();
            lpt1 lpt1Var2 = ((p) this.f1350a).f4938a;
            ((com2) ((lpt3) lpt1Var2).f1381a).f1362c = false;
            ((lpt3) lpt1Var2).f1386a = false;
            lpt1Var2.q();
            c();
        }
        if (b(this.f1352b)) {
            return false;
        }
        this.f1350a.j1(0);
        this.f1350a.k1(0);
        ((lpt3) ((p) this.f1350a).f4937a).f1380a.d(0);
        ((lpt3) ((p) this.f1350a).f4938a).f1380a.d(0);
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:35:0x00c1  */
    public boolean h(boolean z2, int i2) {
        boolean z3;
        p.con conVar;
        boolean z4 = true;
        boolean z5 = z2 & true;
        p.con conVarS = this.f1350a.s(0);
        p.con conVarS2 = this.f1350a.s(1);
        int iV = this.f1350a.V();
        int iW = this.f1350a.W();
        if (z5 && (conVarS == (conVar = p.con.WRAP_CONTENT) || conVarS2 == conVar)) {
            for (lpt3 lpt3Var : this.f1349a) {
                if (lpt3Var.f7408b == i2 && !lpt3Var.m()) {
                    z5 = false;
                    break;
                }
            }
            if (i2 == 0) {
                if (z5 && conVarS == p.con.WRAP_CONTENT) {
                    this.f1350a.M0(p.con.FIXED);
                    q qVar = this.f1350a;
                    qVar.h1(e(qVar, 0));
                    q qVar2 = this.f1350a;
                    ((lpt3) ((p) qVar2).f4937a).f1381a.d(qVar2.U());
                }
            } else if (z5 && conVarS2 == p.con.WRAP_CONTENT) {
                this.f1350a.d1(p.con.FIXED);
                q qVar3 = this.f1350a;
                qVar3.I0(e(qVar3, 1));
                q qVar4 = this.f1350a;
                ((lpt3) ((p) qVar4).f4938a).f1381a.d(qVar4.v());
            }
        }
        if (i2 == 0) {
            q qVar5 = this.f1350a;
            p.con conVar2 = ((p) qVar5).f4951a[0];
            if (conVar2 == p.con.FIXED || conVar2 == p.con.MATCH_PARENT) {
                int iU = qVar5.U() + iV;
                ((lpt3) ((p) this.f1350a).f4937a).f1387b.d(iU);
                ((lpt3) ((p) this.f1350a).f4937a).f1381a.d(iU - iV);
                z3 = true;
            } else {
                z3 = false;
            }
        } else {
            q qVar6 = this.f1350a;
            p.con conVar3 = ((p) qVar6).f4951a[1];
            if (conVar3 == p.con.FIXED || conVar3 == p.con.MATCH_PARENT) {
                int iV2 = qVar6.v() + iW;
                ((lpt3) ((p) this.f1350a).f4938a).f1387b.d(iV2);
                ((lpt3) ((p) this.f1350a).f4938a).f1381a.d(iV2 - iW);
                z3 = true;
            } else {
                z3 = false;
            }
        }
        m();
        for (lpt3 lpt3Var2 : this.f1349a) {
            if (lpt3Var2.f7408b == i2 && (lpt3Var2.f1385a != this.f1350a || lpt3Var2.f1386a)) {
                lpt3Var2.e();
            }
        }
        for (lpt3 lpt3Var3 : this.f1349a) {
            if (lpt3Var3.f7408b == i2 && (z3 || lpt3Var3.f1385a != this.f1350a)) {
                if (!lpt3Var3.f1380a.f1362c || !lpt3Var3.f1387b.f1362c || (!(lpt3Var3 instanceof nul) && !((com2) lpt3Var3.f1381a).f1362c)) {
                    z4 = false;
                    break;
                }
            }
        }
        this.f1350a.M0(conVarS);
        this.f1350a.d1(conVarS2);
        return z4;
    }

    public final void i(lpt3 lpt3Var, int i2, ArrayList<com9> arrayList) {
        for (prn prnVar : lpt3Var.f1380a.f1358a) {
            if (prnVar instanceof com2) {
                a((com2) prnVar, i2, 0, lpt3Var.f1387b, arrayList, null);
            } else if (prnVar instanceof lpt3) {
                a(((lpt3) prnVar).f1380a, i2, 0, lpt3Var.f1387b, arrayList, null);
            }
        }
        for (prn prnVar2 : lpt3Var.f1387b.f1358a) {
            if (prnVar2 instanceof com2) {
                a((com2) prnVar2, i2, 1, lpt3Var.f1380a, arrayList, null);
            } else if (prnVar2 instanceof lpt3) {
                a(((lpt3) prnVar2).f1387b, i2, 1, lpt3Var.f1380a, arrayList, null);
            }
        }
        if (i2 == 1) {
            for (prn prnVar3 : ((lpt1) lpt3Var).f7395c.f1358a) {
                if (prnVar3 instanceof com2) {
                    a((com2) prnVar3, i2, 2, null, arrayList, null);
                }
            }
        }
    }

    public void j() {
        this.f1351a = true;
    }

    public void k() {
        this.f1353b = true;
    }

    public final void l(p pVar, p.con conVar, int i2, p.con conVar2, int i3) {
        con.aux auxVar = this.f7361a;
        auxVar.f1371a = conVar;
        auxVar.f1373b = conVar2;
        auxVar.f7388a = i2;
        auxVar.f7389b = i3;
        this.f1348a.b(pVar, auxVar);
        pVar.h1(this.f7361a.f7390c);
        pVar.I0(this.f7361a.f7391d);
        pVar.H0(this.f7361a.f1372a);
        pVar.x0(this.f7361a.f7392e);
    }

    public void m() {
        com3 com3Var;
        for (p pVar : ((w) this.f1350a).f11546b) {
            if (!pVar.f4946a) {
                p.con[] conVarArr = pVar.f4951a;
                boolean z2 = false;
                p.con conVar = conVarArr[0];
                p.con conVar2 = conVarArr[1];
                int i2 = pVar.f4974f;
                int i3 = pVar.f4977g;
                p.con conVar3 = p.con.WRAP_CONTENT;
                boolean z3 = conVar == conVar3 || (conVar == p.con.MATCH_CONSTRAINT && i2 == 1);
                if (conVar2 == conVar3 || (conVar2 == p.con.MATCH_CONSTRAINT && i3 == 1)) {
                    z2 = true;
                }
                com3 com3Var2 = ((lpt3) pVar.f4937a).f1381a;
                boolean z4 = ((com2) com3Var2).f1362c;
                com3 com3Var3 = ((lpt3) pVar.f4938a).f1381a;
                boolean z5 = ((com2) com3Var3).f1362c;
                if (z4 && z5) {
                    p.con conVar4 = p.con.FIXED;
                    l(pVar, conVar4, ((com2) com3Var2).f7365b, conVar4, ((com2) com3Var3).f7365b);
                    pVar.f4946a = true;
                } else if (z4 && z2) {
                    l(pVar, p.con.FIXED, ((com2) com3Var2).f7365b, conVar3, ((com2) com3Var3).f7365b);
                    if (conVar2 == p.con.MATCH_CONSTRAINT) {
                        ((lpt3) pVar.f4938a).f1381a.f7375d = pVar.v();
                    } else {
                        ((lpt3) pVar.f4938a).f1381a.d(pVar.v());
                        pVar.f4946a = true;
                    }
                } else if (z5 && z3) {
                    l(pVar, conVar3, ((com2) com3Var2).f7365b, p.con.FIXED, ((com2) com3Var3).f7365b);
                    if (conVar == p.con.MATCH_CONSTRAINT) {
                        ((lpt3) pVar.f4937a).f1381a.f7375d = pVar.U();
                    } else {
                        ((lpt3) pVar.f4937a).f1381a.d(pVar.U());
                        pVar.f4946a = true;
                    }
                }
                if (pVar.f4946a && (com3Var = pVar.f4938a.f7394b) != null) {
                    com3Var.d(pVar.n());
                }
            }
        }
    }

    public void n(con.InterfaceC0018con interfaceC0018con) {
        this.f1348a = interfaceC0018con;
    }
}
