package com.google.android.material.textfield;

import COM9.com7;
import android.R;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatTextView;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import p007COm5.lpt2;
import p014CoM2.lpt1;
import p022CoN.lpt7;
import p022CoN.q0;
import p022CoN.w;
import p024Com2.lpt3;
import p024Com2.y;
import p033LPt1.c;
import p033LPt1.d;
import p033LPt1.e;
import p033LPt1.f;
import p033LPt1.h;
import p033LPt1.i;
import p075cOM6.b4;
import p075cOM6.d4;
import p075cOM6.f4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.y3;
import p075cOM6.z3;
import p081cOm2.e2;
import p098coM9.b;
import p108com9.j;
import p108com9.t;
import p108com9.v;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
public class TextInputLayout extends LinearLayout {
    public static final int B = g4.f8966k;
    public int A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9606a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM9.com3 f3662a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com7 f3663a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p007COm5.com1 f3664a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final f f3665a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final i f3666a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3667a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3668a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f3669a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f3670a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f3671a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Typeface f3672a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f3673a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SparseArray<d> f3674a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View.OnLongClickListener f3675a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public EditText f3676a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final FrameLayout f3677a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinearLayout f3678a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f3679a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CheckableImageButton f3680a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p108com9.i f3681a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f3682a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinkedHashSet<com2> f3683a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f9607b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public COM9.com3 f3684b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public p007COm5.com1 f3685b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f3686b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public PorterDuff.Mode f3687b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Rect f3688b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Drawable f3689b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View.OnLongClickListener f3690b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final FrameLayout f3691b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public TextView f3692b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final CheckableImageButton f3693b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f3694b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final LinkedHashSet<com3> f3695b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3696b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9608c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public COM9.com3 f3697c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ColorStateList f3698c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Drawable f3699c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final TextView f3700c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f3701c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3702c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9609d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public ColorStateList f3703d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public CharSequence f3704d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3705d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9610e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public ColorStateList f3706e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f3707e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f9611f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public ColorStateList f3708f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f3709f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f9612g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public ColorStateList f3710g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f3711g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f9613h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public ColorStateList f3712h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f3713h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f9614i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f3714i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f9615j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f3715j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f9616k;

    /* JADX INFO: renamed from: k, reason: collision with other field name */
    public boolean f3716k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f9617l;

    /* JADX INFO: renamed from: l, reason: collision with other field name */
    public boolean f3717l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f9618m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f9619n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f9620o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f9621p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f9622q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f9623r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f9624s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f9625t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f9626u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f9627v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f9628w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f9629x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f9630y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f9631z;

    public class aux implements TextWatcher {
        public aux() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            TextInputLayout textInputLayout = TextInputLayout.this;
            textInputLayout.w0(!textInputLayout.f3717l);
            TextInputLayout textInputLayout2 = TextInputLayout.this;
            if (textInputLayout2.f3696b) {
                textInputLayout2.m0(editable.length());
            }
            if (TextInputLayout.this.f3705d) {
                TextInputLayout.this.A0(editable.length());
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        }
    }

    public static class com1 extends lpt3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final TextInputLayout f9633a;

        public com1(TextInputLayout textInputLayout) {
            this.f9633a = textInputLayout;
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            EditText editText = this.f9633a.getEditText();
            CharSequence text = editText != null ? editText.getText() : null;
            CharSequence hint = this.f9633a.getHint();
            CharSequence error = this.f9633a.getError();
            CharSequence placeholderText = this.f9633a.getPlaceholderText();
            int counterMaxLength = this.f9633a.getCounterMaxLength();
            CharSequence counterOverflowDescription = this.f9633a.getCounterOverflowDescription();
            boolean z2 = !TextUtils.isEmpty(text);
            boolean z3 = !TextUtils.isEmpty(hint);
            boolean z4 = !this.f9633a.N();
            boolean z5 = !TextUtils.isEmpty(error);
            boolean z6 = z5 || !TextUtils.isEmpty(counterOverflowDescription);
            String string = z3 ? hint.toString() : "";
            this.f9633a.f3666a.v(e2Var);
            if (z2) {
                e2Var.v0(text);
            } else if (!TextUtils.isEmpty(string)) {
                e2Var.v0(string);
                if (z4 && placeholderText != null) {
                    e2Var.v0(string + ", " + ((Object) placeholderText));
                }
            } else if (placeholderText != null) {
                e2Var.v0(placeholderText);
            }
            if (!TextUtils.isEmpty(string)) {
                e2Var.e0(string);
                e2Var.r0(!z2);
            }
            if (text == null || text.length() != counterMaxLength) {
                counterMaxLength = -1;
            }
            e2Var.h0(counterMaxLength);
            if (z6) {
                if (!z5) {
                    error = counterOverflowDescription;
                }
                e2Var.a0(error);
            }
            View viewS = this.f9633a.f3665a.s();
            if (viewS != null) {
                e2Var.f0(viewS);
            }
        }
    }

    public interface com2 {
        void a(TextInputLayout textInputLayout);
    }

    public interface com3 {
        void a(TextInputLayout textInputLayout, int i2);
    }

    public static class com4 extends COM2.aux {
        public static final Parcelable.Creator<com4> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public CharSequence f9634a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public CharSequence f9635b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f3718b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public CharSequence f9636c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public CharSequence f9637d;

        public class aux implements Parcelable.ClassLoaderCreator<com4> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com4 createFromParcel(Parcel parcel) {
                return new com4(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com4 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com4(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com4[] newArray(int i2) {
                return new com4[i2];
            }
        }

        public com4(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "TextInputLayout.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " error=" + ((Object) this.f9634a) + " hint=" + ((Object) this.f9635b) + " helperText=" + ((Object) this.f9636c) + " placeholderText=" + ((Object) this.f9637d) + "}";
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            TextUtils.writeToParcel(this.f9634a, parcel, i2);
            parcel.writeInt(this.f3718b ? 1 : 0);
            TextUtils.writeToParcel(this.f9635b, parcel, i2);
            TextUtils.writeToParcel(this.f9636c, parcel, i2);
            TextUtils.writeToParcel(this.f9637d, parcel, i2);
        }

        public com4(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f9634a = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f3718b = parcel.readInt() == 1;
            this.f9635b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f9636c = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f9637d = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        }
    }

    public class con implements Runnable {
        public con() {
        }

        @Override // java.lang.Runnable
        public void run() {
            TextInputLayout.this.f3680a.performClick();
            TextInputLayout.this.f3680a.jumpDrawablesToCurrentState();
        }
    }

    public class nul implements Runnable {
        public nul() {
        }

        @Override // java.lang.Runnable
        public void run() {
            TextInputLayout.this.f3676a.requestLayout();
        }
    }

    public class prn implements ValueAnimator.AnimatorUpdateListener {
        public prn() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TextInputLayout.this.f3681a.d0(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    public TextInputLayout(Context context) {
        this(context, null);
    }

    public static void T(ViewGroup viewGroup, boolean z2) {
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            childAt.setEnabled(z2);
            if (childAt instanceof ViewGroup) {
                T((ViewGroup) childAt, z2);
            }
        }
    }

    public static void a0(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        boolean zN = y.N(checkableImageButton);
        boolean z2 = onLongClickListener != null;
        boolean z3 = zN || z2;
        checkableImageButton.setFocusable(z3);
        checkableImageButton.setClickable(zN);
        checkableImageButton.setPressable(zN);
        checkableImageButton.setLongClickable(z2);
        y.y0(checkableImageButton, z3 ? 1 : 2);
    }

    public static void b0(CheckableImageButton checkableImageButton, View.OnClickListener onClickListener, View.OnLongClickListener onLongClickListener) {
        checkableImageButton.setOnClickListener(onClickListener);
        a0(checkableImageButton, onLongClickListener);
    }

    public static void c0(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        a0(checkableImageButton, onLongClickListener);
    }

    private d getEndIconDelegate() {
        d dVar = this.f3674a.get(this.f9623r);
        return dVar != null ? dVar : this.f3674a.get(0);
    }

    private CheckableImageButton getEndIconToUpdateDummyDrawable() {
        if (this.f3693b.getVisibility() == 0) {
            return this.f3693b;
        }
        if (I() && K()) {
            return this.f3680a;
        }
        return null;
    }

    public static void n0(Context context, TextView textView, int i2, int i3, boolean z2) {
        textView.setContentDescription(context.getString(z2 ? f4.f8932c : f4.f8931b, Integer.valueOf(i2), Integer.valueOf(i3)));
    }

    private void setEditText(EditText editText) {
        if (this.f3676a != null) {
            throw new IllegalArgumentException("We already have an EditText, can only have one");
        }
        if (this.f9623r != 3 && !(editText instanceof TextInputEditText)) {
            Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead.");
        }
        this.f3676a = editText;
        int i2 = this.f9606a;
        if (i2 != -1) {
            setMinEms(i2);
        } else {
            setMinWidth(this.f9608c);
        }
        int i3 = this.f9607b;
        if (i3 != -1) {
            setMaxEms(i3);
        } else {
            setMaxWidth(this.f9609d);
        }
        Q();
        setTextInputAccessibilityDelegate(new com1(this));
        this.f3681a.j0(this.f3676a.getTypeface());
        this.f3681a.b0(this.f3676a.getTextSize());
        this.f3681a.X(this.f3676a.getLetterSpacing());
        int gravity = this.f3676a.getGravity();
        this.f3681a.S((gravity & (-113)) | 48);
        this.f3681a.a0(gravity);
        this.f3676a.addTextChangedListener(new aux());
        if (this.f3708f == null) {
            this.f3708f = this.f3676a.getHintTextColors();
        }
        if (this.f3707e) {
            if (TextUtils.isEmpty(this.f3704d)) {
                CharSequence hint = this.f3676a.getHint();
                this.f3682a = hint;
                setHint(hint);
                this.f3676a.setHint((CharSequence) null);
            }
            this.f3709f = true;
        }
        if (this.f3679a != null) {
            m0(this.f3676a.getText().length());
        }
        r0();
        this.f3665a.f();
        this.f3666a.bringToFront();
        this.f3678a.bringToFront();
        this.f3691b.bringToFront();
        this.f3693b.bringToFront();
        B();
        C0();
        if (!isEnabled()) {
            editText.setEnabled(false);
        }
        x0(false, true);
    }

    private void setHintInternal(CharSequence charSequence) {
        if (TextUtils.equals(charSequence, this.f3704d)) {
            return;
        }
        this.f3704d = charSequence;
        this.f3681a.h0(charSequence);
        if (this.f3713h) {
            return;
        }
        R();
    }

    private void setPlaceholderTextEnabled(boolean z2) {
        if (this.f3705d == z2) {
            return;
        }
        if (z2) {
            i();
        } else {
            X();
            this.f3692b = null;
        }
        this.f3705d = z2;
    }

    public final boolean A() {
        return this.f3707e && !TextUtils.isEmpty(this.f3704d) && (this.f3662a instanceof c);
    }

    public final void A0(int i2) {
        if (i2 != 0 || this.f3713h) {
            J();
        } else {
            h0();
        }
    }

    public final void B() {
        Iterator<com2> it = this.f3683a.iterator();
        while (it.hasNext()) {
            it.next().a(this);
        }
    }

    public final void B0(boolean z2, boolean z3) {
        int defaultColor = this.f3712h.getDefaultColor();
        int colorForState = this.f3712h.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, defaultColor);
        int colorForState2 = this.f3712h.getColorForState(new int[]{R.attr.state_activated, R.attr.state_enabled}, defaultColor);
        if (z2) {
            this.f9620o = colorForState2;
        } else if (z3) {
            this.f9620o = colorForState;
        } else {
            this.f9620o = defaultColor;
        }
    }

    public final void C(int i2) {
        Iterator<com3> it = this.f3695b.iterator();
        while (it.hasNext()) {
            it.next().a(this, i2);
        }
    }

    public final void C0() {
        if (this.f3676a == null) {
            return;
        }
        y.C0(this.f3700c, getContext().getResources().getDimensionPixelSize(z3.f9081x), this.f3676a.getPaddingTop(), (K() || L()) ? 0 : y.E(this.f3676a), this.f3676a.getPaddingBottom());
    }

    public final void D(Canvas canvas) {
        COM9.com3 com3Var;
        if (this.f3697c == null || (com3Var = this.f3684b) == null) {
            return;
        }
        com3Var.draw(canvas);
        if (this.f3676a.isFocused()) {
            Rect bounds = this.f3697c.getBounds();
            Rect bounds2 = this.f3684b.getBounds();
            float fX = this.f3681a.x();
            int iCenterX = bounds2.centerX();
            bounds.left = COM6.aux.c(iCenterX, bounds2.left, fX);
            bounds.right = COM6.aux.c(iCenterX, bounds2.right, fX);
            this.f3697c.draw(canvas);
        }
    }

    public final void D0() {
        int visibility = this.f3700c.getVisibility();
        int i2 = (this.f3701c == null || N()) ? 8 : 0;
        if (visibility != i2) {
            getEndIconDelegate().c(i2 == 0);
        }
        t0();
        this.f3700c.setVisibility(i2);
        q0();
    }

    public final void E(Canvas canvas) {
        if (this.f3707e) {
            this.f3681a.l(canvas);
        }
    }

    public void E0() {
        TextView textView;
        EditText editText;
        EditText editText2;
        if (this.f3662a == null || this.f9615j == 0) {
            return;
        }
        boolean z2 = false;
        boolean z3 = isFocused() || ((editText2 = this.f3676a) != null && editText2.hasFocus());
        if (isHovered() || ((editText = this.f3676a) != null && editText.isHovered())) {
            z2 = true;
        }
        if (!isEnabled()) {
            this.f9620o = this.A;
        } else if (this.f3665a.l()) {
            if (this.f3712h != null) {
                B0(z3, z2);
            } else {
                this.f9620o = this.f3665a.p();
            }
        } else if (!this.f3702c || (textView = this.f3679a) == null) {
            if (z3) {
                this.f9620o = this.f9627v;
            } else if (z2) {
                this.f9620o = this.f9626u;
            } else {
                this.f9620o = this.f9625t;
            }
        } else if (this.f3712h != null) {
            B0(z3, z2);
        } else {
            this.f9620o = textView.getCurrentTextColor();
        }
        u0();
        V();
        W();
        U();
        if (getEndIconDelegate().d()) {
            i0(this.f3665a.l());
        }
        if (this.f9615j == 2) {
            int i2 = this.f9617l;
            if (z3 && isEnabled()) {
                this.f9617l = this.f9619n;
            } else {
                this.f9617l = this.f9618m;
            }
            if (this.f9617l != i2) {
                S();
            }
        }
        if (this.f9615j == 1) {
            if (!isEnabled()) {
                this.f9621p = this.f9629x;
            } else if (z2 && !z3) {
                this.f9621p = this.f9631z;
            } else if (z3) {
                this.f9621p = this.f9630y;
            } else {
                this.f9621p = this.f9628w;
            }
        }
        l();
    }

    public final void F(boolean z2) {
        ValueAnimator valueAnimator = this.f3667a;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.f3667a.cancel();
        }
        if (z2 && this.f3715j) {
            k(0.0f);
        } else {
            this.f3681a.d0(0.0f);
        }
        if (A() && ((c) this.f3662a).j0()) {
            x();
        }
        this.f3713h = true;
        J();
        this.f3666a.i(true);
        D0();
    }

    public final int G(int i2, boolean z2) {
        int compoundPaddingLeft = i2 + this.f3676a.getCompoundPaddingLeft();
        return (getPrefixText() == null || z2) ? compoundPaddingLeft : (compoundPaddingLeft - getPrefixTextView().getMeasuredWidth()) + getPrefixTextView().getPaddingLeft();
    }

    public final int H(int i2, boolean z2) {
        int compoundPaddingRight = i2 - this.f3676a.getCompoundPaddingRight();
        return (getPrefixText() == null || !z2) ? compoundPaddingRight : compoundPaddingRight + (getPrefixTextView().getMeasuredWidth() - getPrefixTextView().getPaddingRight());
    }

    public final boolean I() {
        return this.f9623r != 0;
    }

    public final void J() {
        TextView textView = this.f3692b;
        if (textView == null || !this.f3705d) {
            return;
        }
        textView.setText((CharSequence) null);
        lpt2.a(this.f3677a, this.f3685b);
        this.f3692b.setVisibility(4);
    }

    public boolean K() {
        return this.f3691b.getVisibility() == 0 && this.f3680a.getVisibility() == 0;
    }

    public final boolean L() {
        return this.f3693b.getVisibility() == 0;
    }

    public boolean M() {
        return this.f3665a.A();
    }

    public final boolean N() {
        return this.f3713h;
    }

    public boolean O() {
        return this.f3709f;
    }

    public final boolean P() {
        return this.f9615j == 1 && this.f3676a.getMinLines() <= 1;
    }

    public final void Q() {
        o();
        Z();
        E0();
        j0();
        j();
        if (this.f9615j != 0) {
            v0();
        }
    }

    public final void R() {
        if (A()) {
            RectF rectF = this.f3671a;
            this.f3681a.o(rectF, this.f3676a.getWidth(), this.f3676a.getGravity());
            n(rectF);
            rectF.offset(-getPaddingLeft(), ((-getPaddingTop()) - (rectF.height() / 2.0f)) + this.f9617l);
            ((c) this.f3662a).m0(rectF);
        }
    }

    public final void S() {
        if (!A() || this.f3713h) {
            return;
        }
        x();
        R();
    }

    public void U() {
        e.c(this, this.f3680a, this.f3703d);
    }

    public void V() {
        e.c(this, this.f3693b, this.f3706e);
    }

    public void W() {
        this.f3666a.j();
    }

    public final void X() {
        TextView textView = this.f3692b;
        if (textView != null) {
            textView.setVisibility(8);
        }
    }

    public void Y(float f2, float f3, float f4, float f5) {
        boolean zE = v.e(this);
        this.f3711g = zE;
        float f6 = zE ? f3 : f2;
        if (!zE) {
            f2 = f3;
        }
        float f7 = zE ? f5 : f4;
        if (!zE) {
            f4 = f5;
        }
        COM9.com3 com3Var = this.f3662a;
        if (com3Var != null && com3Var.G() == f6 && this.f3662a.H() == f2 && this.f3662a.s() == f7 && this.f3662a.t() == f4) {
            return;
        }
        this.f3663a = this.f3663a.v().A(f6).E(f2).s(f7).w(f4).m();
        l();
    }

    public final void Z() {
        if (g0()) {
            y.s0(this.f3676a, this.f3662a);
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!(view instanceof EditText)) {
            super.addView(view, i2, layoutParams);
            return;
        }
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
        layoutParams2.gravity = (layoutParams2.gravity & (-113)) | 16;
        this.f3677a.addView(view, layoutParams2);
        this.f3677a.setLayoutParams(layoutParams);
        v0();
        setEditText((EditText) view);
    }

    public void d0(TextView textView, int i2) {
        boolean z2 = true;
        try {
            lpt1.n(textView, i2);
            if (textView.getTextColors().getDefaultColor() != -65281) {
                z2 = false;
            }
        } catch (Exception unused) {
        }
        if (z2) {
            lpt1.n(textView, g4.f8956a);
            textView.setTextColor(PRN.aux.c(getContext(), y3.f9052a));
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    @TargetApi(26)
    public void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i2) {
        EditText editText = this.f3676a;
        if (editText == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i2);
            return;
        }
        if (this.f3682a != null) {
            boolean z2 = this.f3709f;
            this.f3709f = false;
            CharSequence hint = editText.getHint();
            this.f3676a.setHint(this.f3682a);
            try {
                super.dispatchProvideAutofillStructure(viewStructure, i2);
                return;
            } finally {
                this.f3676a.setHint(hint);
                this.f3709f = z2;
            }
        }
        viewStructure.setAutofillId(getAutofillId());
        onProvideAutofillStructure(viewStructure, i2);
        onProvideAutofillVirtualStructure(viewStructure, i2);
        viewStructure.setChildCount(this.f3677a.getChildCount());
        for (int i3 = 0; i3 < this.f3677a.getChildCount(); i3++) {
            View childAt = this.f3677a.getChildAt(i3);
            ViewStructure viewStructureNewChild = viewStructure.newChild(i3);
            childAt.dispatchProvideAutofillStructure(viewStructureNewChild, i2);
            if (childAt == this.f3676a) {
                viewStructureNewChild.setHint(getHint());
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        this.f3717l = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.f3717l = false;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        E(canvas);
        D(canvas);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        if (this.f3716k) {
            return;
        }
        this.f3716k = true;
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        p108com9.i iVar = this.f3681a;
        boolean zG0 = iVar != null ? iVar.g0(drawableState) | false : false;
        if (this.f3676a != null) {
            w0(y.S(this) && isEnabled());
        }
        r0();
        E0();
        if (zG0) {
            invalidate();
        }
        this.f3716k = false;
    }

    public final boolean e0() {
        return (this.f3693b.getVisibility() == 0 || ((I() && K()) || this.f3701c != null)) && this.f3678a.getMeasuredWidth() > 0;
    }

    public final boolean f0() {
        return (getStartIconDrawable() != null || (getPrefixText() != null && getPrefixTextView().getVisibility() == 0)) && this.f3666a.getMeasuredWidth() > 0;
    }

    public void g(com2 com2Var) {
        this.f3683a.add(com2Var);
        if (this.f3676a != null) {
            com2Var.a(this);
        }
    }

    public final boolean g0() {
        EditText editText = this.f3676a;
        return (editText == null || this.f3662a == null || editText.getBackground() != null || this.f9615j == 0) ? false : true;
    }

    @Override // android.widget.LinearLayout, android.view.View
    public int getBaseline() {
        EditText editText = this.f3676a;
        return editText != null ? editText.getBaseline() + getPaddingTop() + u() : super.getBaseline();
    }

    public COM9.com3 getBoxBackground() {
        int i2 = this.f9615j;
        if (i2 == 1 || i2 == 2) {
            return this.f3662a;
        }
        throw new IllegalStateException();
    }

    public int getBoxBackgroundColor() {
        return this.f9621p;
    }

    public int getBoxBackgroundMode() {
        return this.f9615j;
    }

    public int getBoxCollapsedPaddingTop() {
        return this.f9616k;
    }

    public float getBoxCornerRadiusBottomEnd() {
        return v.e(this) ? this.f3663a.j().a(this.f3671a) : this.f3663a.l().a(this.f3671a);
    }

    public float getBoxCornerRadiusBottomStart() {
        return v.e(this) ? this.f3663a.l().a(this.f3671a) : this.f3663a.j().a(this.f3671a);
    }

    public float getBoxCornerRadiusTopEnd() {
        return v.e(this) ? this.f3663a.r().a(this.f3671a) : this.f3663a.t().a(this.f3671a);
    }

    public float getBoxCornerRadiusTopStart() {
        return v.e(this) ? this.f3663a.t().a(this.f3671a) : this.f3663a.r().a(this.f3671a);
    }

    public int getBoxStrokeColor() {
        return this.f9627v;
    }

    public ColorStateList getBoxStrokeErrorColor() {
        return this.f3712h;
    }

    public int getBoxStrokeWidth() {
        return this.f9618m;
    }

    public int getBoxStrokeWidthFocused() {
        return this.f9619n;
    }

    public int getCounterMaxLength() {
        return this.f9610e;
    }

    public CharSequence getCounterOverflowDescription() {
        TextView textView;
        if (this.f3696b && this.f3702c && (textView = this.f3679a) != null) {
            return textView.getContentDescription();
        }
        return null;
    }

    public ColorStateList getCounterOverflowTextColor() {
        return this.f3686b;
    }

    public ColorStateList getCounterTextColor() {
        return this.f3686b;
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.f3708f;
    }

    public EditText getEditText() {
        return this.f3676a;
    }

    public CharSequence getEndIconContentDescription() {
        return this.f3680a.getContentDescription();
    }

    public Drawable getEndIconDrawable() {
        return this.f3680a.getDrawable();
    }

    public int getEndIconMode() {
        return this.f9623r;
    }

    public CheckableImageButton getEndIconView() {
        return this.f3680a;
    }

    public CharSequence getError() {
        if (this.f3665a.z()) {
            return this.f3665a.o();
        }
        return null;
    }

    public CharSequence getErrorContentDescription() {
        return this.f3665a.n();
    }

    public int getErrorCurrentTextColors() {
        return this.f3665a.p();
    }

    public Drawable getErrorIconDrawable() {
        return this.f3693b.getDrawable();
    }

    public final int getErrorTextCurrentColor() {
        return this.f3665a.p();
    }

    public CharSequence getHelperText() {
        if (this.f3665a.A()) {
            return this.f3665a.r();
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        return this.f3665a.t();
    }

    public CharSequence getHint() {
        if (this.f3707e) {
            return this.f3704d;
        }
        return null;
    }

    public final float getHintCollapsedTextHeight() {
        return this.f3681a.q();
    }

    public final int getHintCurrentCollapsedTextColor() {
        return this.f3681a.t();
    }

    public ColorStateList getHintTextColor() {
        return this.f3710g;
    }

    public int getMaxEms() {
        return this.f9607b;
    }

    public int getMaxWidth() {
        return this.f9609d;
    }

    public int getMinEms() {
        return this.f9606a;
    }

    public int getMinWidth() {
        return this.f9608c;
    }

    @Deprecated
    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.f3680a.getContentDescription();
    }

    @Deprecated
    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.f3680a.getDrawable();
    }

    public CharSequence getPlaceholderText() {
        if (this.f3705d) {
            return this.f3694b;
        }
        return null;
    }

    public int getPlaceholderTextAppearance() {
        return this.f9613h;
    }

    public ColorStateList getPlaceholderTextColor() {
        return this.f3668a;
    }

    public CharSequence getPrefixText() {
        return this.f3666a.a();
    }

    public ColorStateList getPrefixTextColor() {
        return this.f3666a.b();
    }

    public TextView getPrefixTextView() {
        return this.f3666a.c();
    }

    public CharSequence getStartIconContentDescription() {
        return this.f3666a.d();
    }

    public Drawable getStartIconDrawable() {
        return this.f3666a.e();
    }

    public CharSequence getSuffixText() {
        return this.f3701c;
    }

    public ColorStateList getSuffixTextColor() {
        return this.f3700c.getTextColors();
    }

    public TextView getSuffixTextView() {
        return this.f3700c;
    }

    public Typeface getTypeface() {
        return this.f3672a;
    }

    public void h(com3 com3Var) {
        this.f3695b.add(com3Var);
    }

    public final void h0() {
        if (this.f3692b == null || !this.f3705d || TextUtils.isEmpty(this.f3694b)) {
            return;
        }
        this.f3692b.setText(this.f3694b);
        lpt2.a(this.f3677a, this.f3664a);
        this.f3692b.setVisibility(0);
        this.f3692b.bringToFront();
        announceForAccessibility(this.f3694b);
    }

    public final void i() {
        TextView textView = this.f3692b;
        if (textView != null) {
            this.f3677a.addView(textView);
            this.f3692b.setVisibility(0);
        }
    }

    public final void i0(boolean z2) {
        if (!z2 || getEndIconDrawable() == null) {
            e.a(this, this.f3680a, this.f3703d, this.f3669a);
            return;
        }
        Drawable drawableMutate = p080cOm1.y.l(getEndIconDrawable()).mutate();
        p080cOm1.y.h(drawableMutate, this.f3665a.p());
        this.f3680a.setImageDrawable(drawableMutate);
    }

    public final void j() {
        if (this.f3676a == null || this.f9615j != 1) {
            return;
        }
        if (b.h(getContext())) {
            EditText editText = this.f3676a;
            y.C0(editText, y.F(editText), getResources().getDimensionPixelSize(z3.f9075r), y.E(this.f3676a), getResources().getDimensionPixelSize(z3.f9074q));
        } else if (b.g(getContext())) {
            EditText editText2 = this.f3676a;
            y.C0(editText2, y.F(editText2), getResources().getDimensionPixelSize(z3.f9073p), y.E(this.f3676a), getResources().getDimensionPixelSize(z3.f9072o));
        }
    }

    public final void j0() {
        if (this.f9615j == 1) {
            if (b.h(getContext())) {
                this.f9616k = getResources().getDimensionPixelSize(z3.f9077t);
            } else if (b.g(getContext())) {
                this.f9616k = getResources().getDimensionPixelSize(z3.f9076s);
            }
        }
    }

    public void k(float f2) {
        if (this.f3681a.x() == f2) {
            return;
        }
        if (this.f3667a == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f3667a = valueAnimator;
            valueAnimator.setInterpolator(COM6.aux.f5701b);
            this.f3667a.setDuration(167L);
            this.f3667a.addUpdateListener(new prn());
        }
        this.f3667a.setFloatValues(this.f3681a.x(), f2);
        this.f3667a.start();
    }

    public final void k0(Rect rect) {
        COM9.com3 com3Var = this.f3684b;
        if (com3Var != null) {
            int i2 = rect.bottom;
            com3Var.setBounds(rect.left, i2 - this.f9618m, rect.right, i2);
        }
        COM9.com3 com3Var2 = this.f3697c;
        if (com3Var2 != null) {
            int i3 = rect.bottom;
            com3Var2.setBounds(rect.left, i3 - this.f9619n, rect.right, i3);
        }
    }

    public final void l() {
        COM9.com3 com3Var = this.f3662a;
        if (com3Var == null) {
            return;
        }
        com7 com7VarD = com3Var.D();
        com7 com7Var = this.f3663a;
        if (com7VarD != com7Var) {
            this.f3662a.setShapeAppearanceModel(com7Var);
            p0();
        }
        if (v()) {
            this.f3662a.c0(this.f9617l, this.f9620o);
        }
        int iP = p();
        this.f9621p = iP;
        this.f3662a.Y(ColorStateList.valueOf(iP));
        if (this.f9623r == 3) {
            this.f3676a.getBackground().invalidateSelf();
        }
        m();
        invalidate();
    }

    public final void l0() {
        if (this.f3679a != null) {
            EditText editText = this.f3676a;
            m0(editText == null ? 0 : editText.getText().length());
        }
    }

    public final void m() {
        if (this.f3684b == null || this.f3697c == null) {
            return;
        }
        if (w()) {
            this.f3684b.Y(this.f3676a.isFocused() ? ColorStateList.valueOf(this.f9625t) : ColorStateList.valueOf(this.f9620o));
            this.f3697c.Y(ColorStateList.valueOf(this.f9620o));
        }
        invalidate();
    }

    public void m0(int i2) {
        boolean z2 = this.f3702c;
        int i3 = this.f9610e;
        if (i3 == -1) {
            this.f3679a.setText(String.valueOf(i2));
            this.f3679a.setContentDescription(null);
            this.f3702c = false;
        } else {
            this.f3702c = i2 > i3;
            n0(getContext(), this.f3679a, i2, this.f9610e, this.f3702c);
            if (z2 != this.f3702c) {
                o0();
            }
            this.f3679a.setText(COM1.aux.c().j(getContext().getString(f4.f8933d, Integer.valueOf(i2), Integer.valueOf(this.f9610e))));
        }
        if (this.f3676a == null || z2 == this.f3702c) {
            return;
        }
        w0(false);
        E0();
        r0();
    }

    public final void n(RectF rectF) {
        float f2 = rectF.left;
        int i2 = this.f9614i;
        rectF.left = f2 - i2;
        rectF.right += i2;
    }

    public final void o() {
        int i2 = this.f9615j;
        if (i2 == 0) {
            this.f3662a = null;
            this.f3684b = null;
            this.f3697c = null;
            return;
        }
        if (i2 == 1) {
            this.f3662a = new COM9.com3(this.f3663a);
            this.f3684b = new COM9.com3();
            this.f3697c = new COM9.com3();
        } else {
            if (i2 != 2) {
                throw new IllegalArgumentException(this.f9615j + " is illegal; only @BoxBackgroundMode constants are supported.");
            }
            if (!this.f3707e || (this.f3662a instanceof c)) {
                this.f3662a = new COM9.com3(this.f3663a);
            } else {
                this.f3662a = new c(this.f3663a);
            }
            this.f3684b = null;
            this.f3697c = null;
        }
    }

    public final void o0() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        TextView textView = this.f3679a;
        if (textView != null) {
            d0(textView, this.f3702c ? this.f9611f : this.f9612g);
            if (!this.f3702c && (colorStateList2 = this.f3686b) != null) {
                this.f3679a.setTextColor(colorStateList2);
            }
            if (!this.f3702c || (colorStateList = this.f3698c) == null) {
                return;
            }
            this.f3679a.setTextColor(colorStateList);
        }
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f3681a.H(configuration);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        EditText editText = this.f3676a;
        if (editText != null) {
            Rect rect = this.f3670a;
            j.a(this, editText, rect);
            k0(rect);
            if (this.f3707e) {
                this.f3681a.b0(this.f3676a.getTextSize());
                int gravity = this.f3676a.getGravity();
                this.f3681a.S((gravity & (-113)) | 48);
                this.f3681a.a0(gravity);
                this.f3681a.O(q(rect));
                this.f3681a.W(t(rect));
                this.f3681a.K();
                if (!A() || this.f3713h) {
                    return;
                }
                R();
            }
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        boolean zS0 = s0();
        boolean zQ0 = q0();
        if (zS0 || zQ0) {
            this.f3676a.post(new nul());
        }
        y0();
        C0();
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof com4)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        com4 com4Var = (com4) parcelable;
        super.onRestoreInstanceState(com4Var.k());
        setError(com4Var.f9634a);
        if (com4Var.f3718b) {
            this.f3680a.post(new con());
        }
        setHint(com4Var.f9635b);
        setHelperText(com4Var.f9636c);
        setPlaceholderText(com4Var.f9637d);
        requestLayout();
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        boolean z2 = false;
        boolean z3 = i2 == 1;
        boolean z4 = this.f3711g;
        if (z3 != z4) {
            if (z3 && !z4) {
                z2 = true;
            }
            float fA = this.f3663a.r().a(this.f3671a);
            float fA2 = this.f3663a.t().a(this.f3671a);
            float fA3 = this.f3663a.j().a(this.f3671a);
            float fA4 = this.f3663a.l().a(this.f3671a);
            float f2 = z2 ? fA : fA2;
            if (z2) {
                fA = fA2;
            }
            float f3 = z2 ? fA3 : fA4;
            if (z2) {
                fA3 = fA4;
            }
            Y(f2, fA, f3, fA3);
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        com4 com4Var = new com4(super.onSaveInstanceState());
        if (this.f3665a.l()) {
            com4Var.f9634a = getError();
        }
        com4Var.f3718b = I() && this.f3680a.isChecked();
        com4Var.f9635b = getHint();
        com4Var.f9636c = getHelperText();
        com4Var.f9637d = getPlaceholderText();
        return com4Var;
    }

    public final int p() {
        return this.f9615j == 1 ? p030Com8.prn.g(p030Com8.prn.e(this, x3.f9038m, 0), this.f9621p) : this.f9621p;
    }

    public final void p0() {
        if (this.f9623r == 3 && this.f9615j == 2) {
            ((com.google.android.material.textfield.con) this.f3674a.get(3)).O((AutoCompleteTextView) this.f3676a);
        }
    }

    public final Rect q(Rect rect) {
        if (this.f3676a == null) {
            throw new IllegalStateException();
        }
        Rect rect2 = this.f3688b;
        boolean zE = v.e(this);
        rect2.bottom = rect.bottom;
        int i2 = this.f9615j;
        if (i2 == 1) {
            rect2.left = G(rect.left, zE);
            rect2.top = rect.top + this.f9616k;
            rect2.right = H(rect.right, zE);
            return rect2;
        }
        if (i2 != 2) {
            rect2.left = G(rect.left, zE);
            rect2.top = getPaddingTop();
            rect2.right = H(rect.right, zE);
            return rect2;
        }
        rect2.left = rect.left + this.f3676a.getPaddingLeft();
        rect2.top = rect.top - u();
        rect2.right = rect.right - this.f3676a.getPaddingRight();
        return rect2;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0062  */
    public boolean q0() {
        boolean z2;
        if (this.f3676a == null) {
            return false;
        }
        boolean z3 = true;
        if (f0()) {
            int measuredWidth = this.f3666a.getMeasuredWidth() - this.f3676a.getPaddingLeft();
            if (this.f3673a == null || this.f9622q != measuredWidth) {
                ColorDrawable colorDrawable = new ColorDrawable();
                this.f3673a = colorDrawable;
                this.f9622q = measuredWidth;
                colorDrawable.setBounds(0, 0, measuredWidth, 1);
            }
            Drawable[] drawableArrA = lpt1.a(this.f3676a);
            Drawable drawable = drawableArrA[0];
            Drawable drawable2 = this.f3673a;
            if (drawable != drawable2) {
                lpt1.i(this.f3676a, drawable2, drawableArrA[1], drawableArrA[2], drawableArrA[3]);
                z2 = true;
            } else {
                z2 = false;
            }
        } else if (this.f3673a != null) {
            Drawable[] drawableArrA2 = lpt1.a(this.f3676a);
            lpt1.i(this.f3676a, null, drawableArrA2[1], drawableArrA2[2], drawableArrA2[3]);
            this.f3673a = null;
            z2 = true;
        } else {
            z2 = false;
        }
        if (e0()) {
            int measuredWidth2 = this.f3700c.getMeasuredWidth() - this.f3676a.getPaddingRight();
            CheckableImageButton endIconToUpdateDummyDrawable = getEndIconToUpdateDummyDrawable();
            if (endIconToUpdateDummyDrawable != null) {
                measuredWidth2 = measuredWidth2 + endIconToUpdateDummyDrawable.getMeasuredWidth() + p024Com2.i.b((ViewGroup.MarginLayoutParams) endIconToUpdateDummyDrawable.getLayoutParams());
            }
            Drawable[] drawableArrA3 = lpt1.a(this.f3676a);
            Drawable drawable3 = this.f3689b;
            if (drawable3 == null || this.f9624s == measuredWidth2) {
                if (drawable3 == null) {
                    ColorDrawable colorDrawable2 = new ColorDrawable();
                    this.f3689b = colorDrawable2;
                    this.f9624s = measuredWidth2;
                    colorDrawable2.setBounds(0, 0, measuredWidth2, 1);
                }
                Drawable drawable4 = drawableArrA3[2];
                Drawable drawable5 = this.f3689b;
                if (drawable4 != drawable5) {
                    this.f3699c = drawable4;
                    lpt1.i(this.f3676a, drawableArrA3[0], drawableArrA3[1], drawable5, drawableArrA3[3]);
                } else {
                    z3 = z2;
                }
            } else {
                this.f9624s = measuredWidth2;
                drawable3.setBounds(0, 0, measuredWidth2, 1);
                lpt1.i(this.f3676a, drawableArrA3[0], drawableArrA3[1], this.f3689b, drawableArrA3[3]);
            }
        } else {
            if (this.f3689b == null) {
                return z2;
            }
            Drawable[] drawableArrA4 = lpt1.a(this.f3676a);
            if (drawableArrA4[2] == this.f3689b) {
                lpt1.i(this.f3676a, drawableArrA4[0], drawableArrA4[1], this.f3699c, drawableArrA4[3]);
            } else {
                z3 = z2;
            }
            this.f3689b = null;
        }
        return z3;
    }

    public final int r(Rect rect, Rect rect2, float f2) {
        return P() ? (int) (rect2.top + f2) : rect.bottom - this.f3676a.getCompoundPaddingBottom();
    }

    public void r0() {
        Drawable background;
        TextView textView;
        EditText editText = this.f3676a;
        if (editText == null || this.f9615j != 0 || (background = editText.getBackground()) == null) {
            return;
        }
        if (w.a(background)) {
            background = background.mutate();
        }
        if (this.f3665a.l()) {
            background.setColorFilter(lpt7.e(this.f3665a.p(), PorterDuff.Mode.SRC_IN));
        } else if (this.f3702c && (textView = this.f3679a) != null) {
            background.setColorFilter(lpt7.e(textView.getCurrentTextColor(), PorterDuff.Mode.SRC_IN));
        } else {
            p080cOm1.y.a(background);
            this.f3676a.refreshDrawableState();
        }
    }

    public final int s(Rect rect, float f2) {
        return P() ? (int) (rect.centerY() - (f2 / 2.0f)) : rect.top + this.f3676a.getCompoundPaddingTop();
    }

    public final boolean s0() {
        int iMax;
        if (this.f3676a == null || this.f3676a.getMeasuredHeight() >= (iMax = Math.max(this.f3678a.getMeasuredHeight(), this.f3666a.getMeasuredHeight()))) {
            return false;
        }
        this.f3676a.setMinimumHeight(iMax);
        return true;
    }

    public void setBoxBackgroundColor(int i2) {
        if (this.f9621p != i2) {
            this.f9621p = i2;
            this.f9628w = i2;
            this.f9630y = i2;
            this.f9631z = i2;
            l();
        }
    }

    public void setBoxBackgroundColorResource(int i2) {
        setBoxBackgroundColor(PRN.aux.c(getContext(), i2));
    }

    public void setBoxBackgroundColorStateList(ColorStateList colorStateList) {
        int defaultColor = colorStateList.getDefaultColor();
        this.f9628w = defaultColor;
        this.f9621p = defaultColor;
        this.f9629x = colorStateList.getColorForState(new int[]{-16842910}, -1);
        this.f9630y = colorStateList.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
        this.f9631z = colorStateList.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
        l();
    }

    public void setBoxBackgroundMode(int i2) {
        if (i2 == this.f9615j) {
            return;
        }
        this.f9615j = i2;
        if (this.f3676a != null) {
            Q();
        }
    }

    public void setBoxCollapsedPaddingTop(int i2) {
        this.f9616k = i2;
    }

    public void setBoxStrokeColor(int i2) {
        if (this.f9627v != i2) {
            this.f9627v = i2;
            E0();
        }
    }

    public void setBoxStrokeColorStateList(ColorStateList colorStateList) {
        if (colorStateList.isStateful()) {
            this.f9625t = colorStateList.getDefaultColor();
            this.A = colorStateList.getColorForState(new int[]{-16842910}, -1);
            this.f9626u = colorStateList.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
            this.f9627v = colorStateList.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
        } else if (this.f9627v != colorStateList.getDefaultColor()) {
            this.f9627v = colorStateList.getDefaultColor();
        }
        E0();
    }

    public void setBoxStrokeErrorColor(ColorStateList colorStateList) {
        if (this.f3712h != colorStateList) {
            this.f3712h = colorStateList;
            E0();
        }
    }

    public void setBoxStrokeWidth(int i2) {
        this.f9618m = i2;
        E0();
    }

    public void setBoxStrokeWidthFocused(int i2) {
        this.f9619n = i2;
        E0();
    }

    public void setBoxStrokeWidthFocusedResource(int i2) {
        setBoxStrokeWidthFocused(getResources().getDimensionPixelSize(i2));
    }

    public void setBoxStrokeWidthResource(int i2) {
        setBoxStrokeWidth(getResources().getDimensionPixelSize(i2));
    }

    public void setCounterEnabled(boolean z2) {
        if (this.f3696b != z2) {
            if (z2) {
                AppCompatTextView appCompatTextView = new AppCompatTextView(getContext());
                this.f3679a = appCompatTextView;
                appCompatTextView.setId(b4.W);
                Typeface typeface = this.f3672a;
                if (typeface != null) {
                    this.f3679a.setTypeface(typeface);
                }
                this.f3679a.setMaxLines(1);
                this.f3665a.e(this.f3679a, 2);
                p024Com2.i.d((ViewGroup.MarginLayoutParams) this.f3679a.getLayoutParams(), getResources().getDimensionPixelOffset(z3.Z));
                o0();
                l0();
            } else {
                this.f3665a.B(this.f3679a, 2);
                this.f3679a = null;
            }
            this.f3696b = z2;
        }
    }

    public void setCounterMaxLength(int i2) {
        if (this.f9610e != i2) {
            if (i2 > 0) {
                this.f9610e = i2;
            } else {
                this.f9610e = -1;
            }
            if (this.f3696b) {
                l0();
            }
        }
    }

    public void setCounterOverflowTextAppearance(int i2) {
        if (this.f9611f != i2) {
            this.f9611f = i2;
            o0();
        }
    }

    public void setCounterOverflowTextColor(ColorStateList colorStateList) {
        if (this.f3698c != colorStateList) {
            this.f3698c = colorStateList;
            o0();
        }
    }

    public void setCounterTextAppearance(int i2) {
        if (this.f9612g != i2) {
            this.f9612g = i2;
            o0();
        }
    }

    public void setCounterTextColor(ColorStateList colorStateList) {
        if (this.f3686b != colorStateList) {
            this.f3686b = colorStateList;
            o0();
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.f3708f = colorStateList;
        this.f3710g = colorStateList;
        if (this.f3676a != null) {
            w0(false);
        }
    }

    @Override // android.view.View
    public void setEnabled(boolean z2) {
        T(this, z2);
        super.setEnabled(z2);
    }

    public void setEndIconActivated(boolean z2) {
        this.f3680a.setActivated(z2);
    }

    public void setEndIconCheckable(boolean z2) {
        this.f3680a.setCheckable(z2);
    }

    public void setEndIconContentDescription(int i2) {
        setEndIconContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setEndIconDrawable(int i2) {
        setEndIconDrawable(i2 != 0 ? AUX.aux.b(getContext(), i2) : null);
    }

    public void setEndIconMode(int i2) {
        int i3 = this.f9623r;
        if (i3 == i2) {
            return;
        }
        this.f9623r = i2;
        C(i3);
        setEndIconVisible(i2 != 0);
        if (getEndIconDelegate().b(this.f9615j)) {
            getEndIconDelegate().a();
            e.a(this, this.f3680a, this.f3703d, this.f3669a);
            return;
        }
        throw new IllegalStateException("The current box background mode " + this.f9615j + " is not supported by the end icon mode " + i2);
    }

    public void setEndIconOnClickListener(View.OnClickListener onClickListener) {
        b0(this.f3680a, onClickListener, this.f3675a);
    }

    public void setEndIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f3675a = onLongClickListener;
        c0(this.f3680a, onLongClickListener);
    }

    public void setEndIconTintList(ColorStateList colorStateList) {
        if (this.f3703d != colorStateList) {
            this.f3703d = colorStateList;
            e.a(this, this.f3680a, colorStateList, this.f3669a);
        }
    }

    public void setEndIconTintMode(PorterDuff.Mode mode) {
        if (this.f3669a != mode) {
            this.f3669a = mode;
            e.a(this, this.f3680a, this.f3703d, mode);
        }
    }

    public void setEndIconVisible(boolean z2) {
        if (K() != z2) {
            this.f3680a.setVisibility(z2 ? 0 : 8);
            t0();
            C0();
            q0();
        }
    }

    public void setError(CharSequence charSequence) {
        if (!this.f3665a.z()) {
            if (TextUtils.isEmpty(charSequence)) {
                return;
            } else {
                setErrorEnabled(true);
            }
        }
        if (TextUtils.isEmpty(charSequence)) {
            this.f3665a.v();
        } else {
            this.f3665a.O(charSequence);
        }
    }

    public void setErrorContentDescription(CharSequence charSequence) {
        this.f3665a.D(charSequence);
    }

    public void setErrorEnabled(boolean z2) {
        this.f3665a.E(z2);
    }

    public void setErrorIconDrawable(int i2) {
        setErrorIconDrawable(i2 != 0 ? AUX.aux.b(getContext(), i2) : null);
        V();
    }

    public void setErrorIconOnClickListener(View.OnClickListener onClickListener) {
        b0(this.f3693b, onClickListener, this.f3690b);
    }

    public void setErrorIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f3690b = onLongClickListener;
        c0(this.f3693b, onLongClickListener);
    }

    public void setErrorIconTintList(ColorStateList colorStateList) {
        if (this.f3706e != colorStateList) {
            this.f3706e = colorStateList;
            e.a(this, this.f3693b, colorStateList, this.f3687b);
        }
    }

    public void setErrorIconTintMode(PorterDuff.Mode mode) {
        if (this.f3687b != mode) {
            this.f3687b = mode;
            e.a(this, this.f3693b, this.f3706e, mode);
        }
    }

    public void setErrorTextAppearance(int i2) {
        this.f3665a.F(i2);
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        this.f3665a.G(colorStateList);
    }

    public void setExpandedHintEnabled(boolean z2) {
        if (this.f3714i != z2) {
            this.f3714i = z2;
            w0(false);
        }
    }

    public void setHelperText(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            if (M()) {
                setHelperTextEnabled(false);
            }
        } else {
            if (!M()) {
                setHelperTextEnabled(true);
            }
            this.f3665a.P(charSequence);
        }
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        this.f3665a.J(colorStateList);
    }

    public void setHelperTextEnabled(boolean z2) {
        this.f3665a.I(z2);
    }

    public void setHelperTextTextAppearance(int i2) {
        this.f3665a.H(i2);
    }

    public void setHint(CharSequence charSequence) {
        if (this.f3707e) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z2) {
        this.f3715j = z2;
    }

    public void setHintEnabled(boolean z2) {
        if (z2 != this.f3707e) {
            this.f3707e = z2;
            if (z2) {
                CharSequence hint = this.f3676a.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.f3704d)) {
                        setHint(hint);
                    }
                    this.f3676a.setHint((CharSequence) null);
                }
                this.f3709f = true;
            } else {
                this.f3709f = false;
                if (!TextUtils.isEmpty(this.f3704d) && TextUtils.isEmpty(this.f3676a.getHint())) {
                    this.f3676a.setHint(this.f3704d);
                }
                setHintInternal(null);
            }
            if (this.f3676a != null) {
                v0();
            }
        }
    }

    public void setHintTextAppearance(int i2) {
        this.f3681a.P(i2);
        this.f3710g = this.f3681a.p();
        if (this.f3676a != null) {
            w0(false);
            v0();
        }
    }

    public void setHintTextColor(ColorStateList colorStateList) {
        if (this.f3710g != colorStateList) {
            if (this.f3708f == null) {
                this.f3681a.R(colorStateList);
            }
            this.f3710g = colorStateList;
            if (this.f3676a != null) {
                w0(false);
            }
        }
    }

    public void setMaxEms(int i2) {
        this.f9607b = i2;
        EditText editText = this.f3676a;
        if (editText == null || i2 == -1) {
            return;
        }
        editText.setMaxEms(i2);
    }

    public void setMaxWidth(int i2) {
        this.f9609d = i2;
        EditText editText = this.f3676a;
        if (editText == null || i2 == -1) {
            return;
        }
        editText.setMaxWidth(i2);
    }

    public void setMaxWidthResource(int i2) {
        setMaxWidth(getContext().getResources().getDimensionPixelSize(i2));
    }

    public void setMinEms(int i2) {
        this.f9606a = i2;
        EditText editText = this.f3676a;
        if (editText == null || i2 == -1) {
            return;
        }
        editText.setMinEms(i2);
    }

    public void setMinWidth(int i2) {
        this.f9608c = i2;
        EditText editText = this.f3676a;
        if (editText == null || i2 == -1) {
            return;
        }
        editText.setMinWidth(i2);
    }

    public void setMinWidthResource(int i2) {
        setMinWidth(getContext().getResources().getDimensionPixelSize(i2));
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(int i2) {
        setPasswordVisibilityToggleContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(int i2) {
        setPasswordVisibilityToggleDrawable(i2 != 0 ? AUX.aux.b(getContext(), i2) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleEnabled(boolean z2) {
        if (z2 && this.f9623r != 1) {
            setEndIconMode(1);
        } else {
            if (z2) {
                return;
            }
            setEndIconMode(0);
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        this.f3703d = colorStateList;
        e.a(this, this.f3680a, colorStateList, this.f3669a);
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        this.f3669a = mode;
        e.a(this, this.f3680a, this.f3703d, mode);
    }

    public void setPlaceholderText(CharSequence charSequence) {
        if (this.f3692b == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext());
            this.f3692b = appCompatTextView;
            appCompatTextView.setId(b4.Z);
            y.y0(this.f3692b, 2);
            p007COm5.com1 com1VarZ = z();
            this.f3664a = com1VarZ;
            com1VarZ.Y(67L);
            this.f3685b = z();
            setPlaceholderTextAppearance(this.f9613h);
            setPlaceholderTextColor(this.f3668a);
        }
        if (TextUtils.isEmpty(charSequence)) {
            setPlaceholderTextEnabled(false);
        } else {
            if (!this.f3705d) {
                setPlaceholderTextEnabled(true);
            }
            this.f3694b = charSequence;
        }
        z0();
    }

    public void setPlaceholderTextAppearance(int i2) {
        this.f9613h = i2;
        TextView textView = this.f3692b;
        if (textView != null) {
            lpt1.n(textView, i2);
        }
    }

    public void setPlaceholderTextColor(ColorStateList colorStateList) {
        if (this.f3668a != colorStateList) {
            this.f3668a = colorStateList;
            TextView textView = this.f3692b;
            if (textView == null || colorStateList == null) {
                return;
            }
            textView.setTextColor(colorStateList);
        }
    }

    public void setPrefixText(CharSequence charSequence) {
        this.f3666a.k(charSequence);
    }

    public void setPrefixTextAppearance(int i2) {
        this.f3666a.l(i2);
    }

    public void setPrefixTextColor(ColorStateList colorStateList) {
        this.f3666a.m(colorStateList);
    }

    public void setStartIconCheckable(boolean z2) {
        this.f3666a.n(z2);
    }

    public void setStartIconContentDescription(int i2) {
        setStartIconContentDescription(i2 != 0 ? getResources().getText(i2) : null);
    }

    public void setStartIconDrawable(int i2) {
        setStartIconDrawable(i2 != 0 ? AUX.aux.b(getContext(), i2) : null);
    }

    public void setStartIconOnClickListener(View.OnClickListener onClickListener) {
        this.f3666a.q(onClickListener);
    }

    public void setStartIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f3666a.r(onLongClickListener);
    }

    public void setStartIconTintList(ColorStateList colorStateList) {
        this.f3666a.s(colorStateList);
    }

    public void setStartIconTintMode(PorterDuff.Mode mode) {
        this.f3666a.t(mode);
    }

    public void setStartIconVisible(boolean z2) {
        this.f3666a.u(z2);
    }

    public void setSuffixText(CharSequence charSequence) {
        this.f3701c = TextUtils.isEmpty(charSequence) ? null : charSequence;
        this.f3700c.setText(charSequence);
        D0();
    }

    public void setSuffixTextAppearance(int i2) {
        lpt1.n(this.f3700c, i2);
    }

    public void setSuffixTextColor(ColorStateList colorStateList) {
        this.f3700c.setTextColor(colorStateList);
    }

    public void setTextInputAccessibilityDelegate(com1 com1Var) {
        EditText editText = this.f3676a;
        if (editText != null) {
            y.o0(editText, com1Var);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.f3672a) {
            this.f3672a = typeface;
            this.f3681a.j0(typeface);
            this.f3665a.L(typeface);
            TextView textView = this.f3679a;
            if (textView != null) {
                textView.setTypeface(typeface);
            }
        }
    }

    public final Rect t(Rect rect) {
        if (this.f3676a == null) {
            throw new IllegalStateException();
        }
        Rect rect2 = this.f3688b;
        float fW = this.f3681a.w();
        rect2.left = rect.left + this.f3676a.getCompoundPaddingLeft();
        rect2.top = s(rect, fW);
        rect2.right = rect.right - this.f3676a.getCompoundPaddingRight();
        rect2.bottom = r(rect, rect2, fW);
        return rect2;
    }

    public final void t0() {
        this.f3691b.setVisibility((this.f3680a.getVisibility() != 0 || L()) ? 8 : 0);
        this.f3678a.setVisibility(K() || L() || ((this.f3701c == null || N()) ? '\b' : (char) 0) == 0 ? 0 : 8);
    }

    public final int u() {
        float fQ;
        if (!this.f3707e) {
            return 0;
        }
        int i2 = this.f9615j;
        if (i2 == 0) {
            fQ = this.f3681a.q();
        } else {
            if (i2 != 2) {
                return 0;
            }
            fQ = this.f3681a.q() / 2.0f;
        }
        return (int) fQ;
    }

    public final void u0() {
        this.f3693b.setVisibility(getErrorIconDrawable() != null && this.f3665a.z() && this.f3665a.l() ? 0 : 8);
        t0();
        C0();
        if (I()) {
            return;
        }
        q0();
    }

    public final boolean v() {
        return this.f9615j == 2 && w();
    }

    public final void v0() {
        if (this.f9615j != 1) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f3677a.getLayoutParams();
            int iU = u();
            if (iU != layoutParams.topMargin) {
                layoutParams.topMargin = iU;
                this.f3677a.requestLayout();
            }
        }
    }

    public final boolean w() {
        return this.f9617l > -1 && this.f9620o != 0;
    }

    public void w0(boolean z2) {
        x0(z2, false);
    }

    public final void x() {
        if (A()) {
            ((c) this.f3662a).k0();
        }
    }

    public final void x0(boolean z2, boolean z3) {
        ColorStateList colorStateList;
        TextView textView;
        boolean zIsEnabled = isEnabled();
        EditText editText = this.f3676a;
        boolean z4 = (editText == null || TextUtils.isEmpty(editText.getText())) ? false : true;
        EditText editText2 = this.f3676a;
        boolean z5 = editText2 != null && editText2.hasFocus();
        boolean zL = this.f3665a.l();
        ColorStateList colorStateList2 = this.f3708f;
        if (colorStateList2 != null) {
            this.f3681a.R(colorStateList2);
            this.f3681a.Z(this.f3708f);
        }
        if (!zIsEnabled) {
            ColorStateList colorStateList3 = this.f3708f;
            int colorForState = colorStateList3 != null ? colorStateList3.getColorForState(new int[]{-16842910}, this.A) : this.A;
            this.f3681a.R(ColorStateList.valueOf(colorForState));
            this.f3681a.Z(ColorStateList.valueOf(colorForState));
        } else if (zL) {
            this.f3681a.R(this.f3665a.q());
        } else if (this.f3702c && (textView = this.f3679a) != null) {
            this.f3681a.R(textView.getTextColors());
        } else if (z5 && (colorStateList = this.f3710g) != null) {
            this.f3681a.R(colorStateList);
        }
        if (z4 || !this.f3714i || (isEnabled() && z5)) {
            if (z3 || this.f3713h) {
                y(z2);
                return;
            }
            return;
        }
        if (z3 || !this.f3713h) {
            F(z2);
        }
    }

    public final void y(boolean z2) {
        ValueAnimator valueAnimator = this.f3667a;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.f3667a.cancel();
        }
        if (z2 && this.f3715j) {
            k(1.0f);
        } else {
            this.f3681a.d0(1.0f);
        }
        this.f3713h = false;
        if (A()) {
            R();
        }
        z0();
        this.f3666a.i(false);
        D0();
    }

    public final void y0() {
        EditText editText;
        if (this.f3692b == null || (editText = this.f3676a) == null) {
            return;
        }
        this.f3692b.setGravity(editText.getGravity());
        this.f3692b.setPadding(this.f3676a.getCompoundPaddingLeft(), this.f3676a.getCompoundPaddingTop(), this.f3676a.getCompoundPaddingRight(), this.f3676a.getCompoundPaddingBottom());
    }

    public final p007COm5.com1 z() {
        p007COm5.com1 com1Var = new p007COm5.com1();
        com1Var.T(87L);
        com1Var.V(COM6.aux.f5700a);
        return com1Var;
    }

    public final void z0() {
        EditText editText = this.f3676a;
        A0(editText == null ? 0 : editText.getText().length());
    }

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.M);
    }

    public void setEndIconContentDescription(CharSequence charSequence) {
        if (getEndIconContentDescription() != charSequence) {
            this.f3680a.setContentDescription(charSequence);
        }
    }

    public void setEndIconDrawable(Drawable drawable) {
        this.f3680a.setImageDrawable(drawable);
        if (drawable != null) {
            e.a(this, this.f3680a, this.f3703d, this.f3669a);
            U();
        }
    }

    public void setStartIconContentDescription(CharSequence charSequence) {
        this.f3666a.o(charSequence);
    }

    public void setStartIconDrawable(Drawable drawable) {
        this.f3666a.p(drawable);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v108 */
    /* JADX WARN: Type inference failed for: r3v49 */
    /* JADX WARN: Type inference failed for: r3v50, types: [boolean, int] */
    public TextInputLayout(Context context, AttributeSet attributeSet, int i2) {
        int i3;
        ?? r3;
        int i4 = B;
        super(u.c(context, attributeSet, i2, i4), attributeSet, i2);
        this.f9606a = -1;
        this.f9607b = -1;
        this.f9608c = -1;
        this.f9609d = -1;
        this.f3665a = new f(this);
        this.f3670a = new Rect();
        this.f3688b = new Rect();
        this.f3671a = new RectF();
        this.f3683a = new LinkedHashSet<>();
        this.f9623r = 0;
        SparseArray<d> sparseArray = new SparseArray<>();
        this.f3674a = sparseArray;
        this.f3695b = new LinkedHashSet<>();
        p108com9.i iVar = new p108com9.i(this);
        this.f3681a = iVar;
        Context context2 = getContext();
        setOrientation(1);
        setWillNotDraw(false);
        setAddStatesFromChildren(true);
        FrameLayout frameLayout = new FrameLayout(context2);
        this.f3677a = frameLayout;
        FrameLayout frameLayout2 = new FrameLayout(context2);
        this.f3691b = frameLayout2;
        LinearLayout linearLayout = new LinearLayout(context2);
        this.f3678a = linearLayout;
        AppCompatTextView appCompatTextView = new AppCompatTextView(context2);
        this.f3700c = appCompatTextView;
        linearLayout.setVisibility(8);
        frameLayout2.setVisibility(8);
        appCompatTextView.setVisibility(8);
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context2);
        int i5 = d4.f8911e;
        CheckableImageButton checkableImageButton = (CheckableImageButton) layoutInflaterFrom.inflate(i5, (ViewGroup) linearLayout, false);
        this.f3693b = checkableImageButton;
        CheckableImageButton checkableImageButton2 = (CheckableImageButton) layoutInflaterFrom.inflate(i5, (ViewGroup) frameLayout2, false);
        this.f3680a = checkableImageButton2;
        frameLayout.setAddStatesFromChildren(true);
        linearLayout.setOrientation(0);
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -1, 8388613));
        frameLayout2.setLayoutParams(new FrameLayout.LayoutParams(-2, -1));
        TimeInterpolator timeInterpolator = COM6.aux.f5700a;
        iVar.i0(timeInterpolator);
        iVar.f0(timeInterpolator);
        iVar.S(8388659);
        int[] iArr = h4.f3169u1;
        int i6 = h4.H3;
        int i7 = h4.F3;
        int i8 = h4.U3;
        int i9 = h4.Z3;
        int i10 = h4.d4;
        q0 q0VarI = t.i(context2, attributeSet, iArr, i2, i4, i6, i7, i8, i9, i10);
        i iVar2 = new i(this, q0VarI);
        this.f3666a = iVar2;
        this.f3707e = q0VarI.a(h4.c4, true);
        setHint(q0VarI.p(h4.p3));
        this.f3715j = q0VarI.a(h4.b4, true);
        this.f3714i = q0VarI.a(h4.W3, true);
        int i11 = h4.r3;
        if (q0VarI.s(i11)) {
            i3 = -1;
            setMinEms(q0VarI.k(i11, -1));
        } else {
            i3 = -1;
            int i12 = h4.o3;
            if (q0VarI.s(i12)) {
                setMinWidth(q0VarI.f(i12, -1));
            }
        }
        int i13 = h4.q3;
        if (q0VarI.s(i13)) {
            setMaxEms(q0VarI.k(i13, i3));
        } else {
            int i14 = h4.n3;
            if (q0VarI.s(i14)) {
                setMaxWidth(q0VarI.f(i14, i3));
            }
        }
        this.f3663a = com7.e(context2, attributeSet, i2, i4).m();
        this.f9614i = context2.getResources().getDimensionPixelOffset(z3.W);
        this.f9616k = q0VarI.e(h4.u3, 0);
        this.f9618m = q0VarI.f(h4.B3, context2.getResources().getDimensionPixelSize(z3.X));
        this.f9619n = q0VarI.f(h4.C3, context2.getResources().getDimensionPixelSize(z3.Y));
        this.f9617l = this.f9618m;
        float fD = q0VarI.d(h4.y3, -1.0f);
        float fD2 = q0VarI.d(h4.x3, -1.0f);
        float fD3 = q0VarI.d(h4.v3, -1.0f);
        float fD4 = q0VarI.d(h4.w3, -1.0f);
        com7.con conVarV = this.f3663a.v();
        if (fD >= 0.0f) {
            conVarV.A(fD);
        }
        if (fD2 >= 0.0f) {
            conVarV.E(fD2);
        }
        if (fD3 >= 0.0f) {
            conVarV.w(fD3);
        }
        if (fD4 >= 0.0f) {
            conVarV.s(fD4);
        }
        this.f3663a = conVarV.m();
        ColorStateList colorStateListA = b.a(context2, q0VarI, h4.s3);
        if (colorStateListA != null) {
            int defaultColor = colorStateListA.getDefaultColor();
            this.f9628w = defaultColor;
            this.f9621p = defaultColor;
            if (colorStateListA.isStateful()) {
                this.f9629x = colorStateListA.getColorForState(new int[]{-16842910}, -1);
                this.f9630y = colorStateListA.getColorForState(new int[]{R.attr.state_focused, R.attr.state_enabled}, -1);
                this.f9631z = colorStateListA.getColorForState(new int[]{R.attr.state_hovered, R.attr.state_enabled}, -1);
            } else {
                this.f9630y = this.f9628w;
                ColorStateList colorStateListA2 = AUX.aux.a(context2, y3.f9054c);
                this.f9629x = colorStateListA2.getColorForState(new int[]{-16842910}, -1);
                this.f9631z = colorStateListA2.getColorForState(new int[]{R.attr.state_hovered}, -1);
            }
        } else {
            this.f9621p = 0;
            this.f9628w = 0;
            this.f9629x = 0;
            this.f9630y = 0;
            this.f9631z = 0;
        }
        int i15 = h4.m3;
        if (q0VarI.s(i15)) {
            ColorStateList colorStateListC = q0VarI.c(i15);
            this.f3710g = colorStateListC;
            this.f3708f = colorStateListC;
        }
        int i16 = h4.z3;
        ColorStateList colorStateListA3 = b.a(context2, q0VarI, i16);
        this.f9627v = q0VarI.b(i16, 0);
        this.f9625t = PRN.aux.c(context2, y3.f9055d);
        this.A = PRN.aux.c(context2, y3.f9056e);
        this.f9626u = PRN.aux.c(context2, y3.f9057f);
        if (colorStateListA3 != null) {
            setBoxStrokeColorStateList(colorStateListA3);
        }
        int i17 = h4.A3;
        if (q0VarI.s(i17)) {
            setBoxStrokeErrorColor(b.a(context2, q0VarI, i17));
        }
        if (q0VarI.n(i10, -1) != -1) {
            r3 = 0;
            setHintTextAppearance(q0VarI.n(i10, 0));
        } else {
            r3 = 0;
        }
        int iN = q0VarI.n(i8, r3);
        CharSequence charSequenceP = q0VarI.p(h4.P3);
        boolean zA = q0VarI.a(h4.Q3, r3);
        checkableImageButton.setId(b4.V);
        if (b.g(context2)) {
            p024Com2.i.d((ViewGroup.MarginLayoutParams) checkableImageButton.getLayoutParams(), r3);
        }
        int i18 = h4.S3;
        if (q0VarI.s(i18)) {
            this.f3706e = b.a(context2, q0VarI, i18);
        }
        int i19 = h4.T3;
        if (q0VarI.s(i19)) {
            this.f3687b = v.f(q0VarI.k(i19, -1), null);
        }
        int i20 = h4.R3;
        if (q0VarI.s(i20)) {
            setErrorIconDrawable(q0VarI.g(i20));
        }
        checkableImageButton.setContentDescription(getResources().getText(f4.f8935f));
        y.y0(checkableImageButton, 2);
        checkableImageButton.setClickable(false);
        checkableImageButton.setPressable(false);
        checkableImageButton.setFocusable(false);
        int iN2 = q0VarI.n(i9, 0);
        boolean zA2 = q0VarI.a(h4.Y3, false);
        CharSequence charSequenceP2 = q0VarI.p(h4.X3);
        int iN3 = q0VarI.n(h4.l4, 0);
        CharSequence charSequenceP3 = q0VarI.p(h4.k4);
        int iN4 = q0VarI.n(h4.w4, 0);
        CharSequence charSequenceP4 = q0VarI.p(h4.v4);
        boolean zA3 = q0VarI.a(h4.D3, false);
        setCounterMaxLength(q0VarI.k(h4.E3, -1));
        this.f9612g = q0VarI.n(i6, 0);
        this.f9611f = q0VarI.n(i7, 0);
        setBoxBackgroundMode(q0VarI.k(h4.t3, 0));
        if (b.g(context2)) {
            p024Com2.i.d((ViewGroup.MarginLayoutParams) checkableImageButton2.getLayoutParams(), 0);
        }
        int iN5 = q0VarI.n(h4.L3, 0);
        sparseArray.append(-1, new p033LPt1.b(this, iN5));
        sparseArray.append(0, new h(this));
        sparseArray.append(1, new com.google.android.material.textfield.nul(this, iN5 == 0 ? q0VarI.n(h4.g4, 0) : iN5));
        sparseArray.append(2, new com.google.android.material.textfield.aux(this, iN5));
        sparseArray.append(3, new com.google.android.material.textfield.con(this, iN5));
        int i21 = h4.h4;
        if (!q0VarI.s(i21)) {
            int i22 = h4.N3;
            if (q0VarI.s(i22)) {
                this.f3703d = b.a(context2, q0VarI, i22);
            }
            int i23 = h4.O3;
            if (q0VarI.s(i23)) {
                this.f3669a = v.f(q0VarI.k(i23, -1), null);
            }
        }
        int i24 = h4.M3;
        if (q0VarI.s(i24)) {
            setEndIconMode(q0VarI.k(i24, 0));
            int i25 = h4.K3;
            if (q0VarI.s(i25)) {
                setEndIconContentDescription(q0VarI.p(i25));
            }
            setEndIconCheckable(q0VarI.a(h4.J3, true));
        } else if (q0VarI.s(i21)) {
            int i26 = h4.i4;
            if (q0VarI.s(i26)) {
                this.f3703d = b.a(context2, q0VarI, i26);
            }
            int i27 = h4.j4;
            if (q0VarI.s(i27)) {
                this.f3669a = v.f(q0VarI.k(i27, -1), null);
            }
            setEndIconMode(q0VarI.a(i21, false) ? 1 : 0);
            setEndIconContentDescription(q0VarI.p(h4.f4));
        }
        appCompatTextView.setId(b4.f8878b0);
        appCompatTextView.setLayoutParams(new FrameLayout.LayoutParams(-2, -2, 80));
        y.q0(appCompatTextView, 1);
        setErrorContentDescription(charSequenceP);
        setCounterOverflowTextAppearance(this.f9611f);
        setHelperTextTextAppearance(iN2);
        setErrorTextAppearance(iN);
        setCounterTextAppearance(this.f9612g);
        setPlaceholderText(charSequenceP3);
        setPlaceholderTextAppearance(iN3);
        setSuffixTextAppearance(iN4);
        int i28 = h4.V3;
        if (q0VarI.s(i28)) {
            setErrorTextColor(q0VarI.c(i28));
        }
        int i29 = h4.a4;
        if (q0VarI.s(i29)) {
            setHelperTextColor(q0VarI.c(i29));
        }
        int i30 = h4.e4;
        if (q0VarI.s(i30)) {
            setHintTextColor(q0VarI.c(i30));
        }
        int i31 = h4.I3;
        if (q0VarI.s(i31)) {
            setCounterTextColor(q0VarI.c(i31));
        }
        int i32 = h4.G3;
        if (q0VarI.s(i32)) {
            setCounterOverflowTextColor(q0VarI.c(i32));
        }
        int i33 = h4.m4;
        if (q0VarI.s(i33)) {
            setPlaceholderTextColor(q0VarI.c(i33));
        }
        int i34 = h4.x4;
        if (q0VarI.s(i34)) {
            setSuffixTextColor(q0VarI.c(i34));
        }
        setEnabled(q0VarI.a(h4.l3, true));
        q0VarI.w();
        y.y0(this, 2);
        y.z0(this, 1);
        frameLayout2.addView(checkableImageButton2);
        linearLayout.addView(appCompatTextView);
        linearLayout.addView(checkableImageButton);
        linearLayout.addView(frameLayout2);
        frameLayout.addView(iVar2);
        frameLayout.addView(linearLayout);
        addView(frameLayout);
        setHelperTextEnabled(zA2);
        setErrorEnabled(zA);
        setCounterEnabled(zA3);
        setHelperText(charSequenceP2);
        setSuffixText(charSequenceP4);
    }

    public void setErrorIconDrawable(Drawable drawable) {
        this.f3693b.setImageDrawable(drawable);
        u0();
        e.a(this, this.f3693b, this.f3706e, this.f3687b);
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.f3680a.setContentDescription(charSequence);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.f3680a.setImageDrawable(drawable);
    }

    public void setHint(int i2) {
        setHint(i2 != 0 ? getResources().getText(i2) : null);
    }
}
