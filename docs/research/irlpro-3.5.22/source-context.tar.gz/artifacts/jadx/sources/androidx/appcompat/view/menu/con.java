package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p001AuX.com9;
import p022CoN.e0;
import p022CoN.g0;
import p024Com2.f;
import p024Com2.y;
import p099coN.f1;

/* JADX INFO: loaded from: classes.dex */
public final class con extends f1 implements View.OnKeyListener, PopupWindow.OnDismissListener {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final int f7825i = com9.f5595e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7826a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f1898a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f1899a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1901a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewTreeObserver f1903a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PopupWindow.OnDismissListener f1904a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1905a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7827b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f1907b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f1909b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f7828c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1910c;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f1911d;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f1913f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7832g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f1914g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f7833h;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<com1> f1906a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final List<prn> f1908b = new ArrayList();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ViewTreeObserver.OnGlobalLayoutListener f1902a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnAttachStateChangeListener f1900a = new ViewOnAttachStateChangeListenerC0024con();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final e0 f1897a = new nul();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7829d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7830e = 0;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f1912e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7831f = D();

    public class aux implements ViewTreeObserver.OnGlobalLayoutListener {
        public aux() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!con.this.b() || con.this.f1908b.size() <= 0 || con.this.f1908b.get(0).f1918a.B()) {
                return;
            }
            View view = con.this.f1907b;
            if (view == null || !view.isShown()) {
                con.this.dismiss();
                return;
            }
            Iterator<prn> it = con.this.f1908b.iterator();
            while (it.hasNext()) {
                it.next().f1918a.a();
            }
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.view.menu.con$con, reason: collision with other inner class name */
    public class ViewOnAttachStateChangeListenerC0024con implements View.OnAttachStateChangeListener {
        public ViewOnAttachStateChangeListenerC0024con() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = con.this.f1903a;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    con.this.f1903a = view.getViewTreeObserver();
                }
                con conVar = con.this;
                conVar.f1903a.removeGlobalOnLayoutListener(conVar.f1902a);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public class nul implements e0 {

        public class aux implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ MenuItem f7837a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ com1 f1915a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ prn f1917a;

            public aux(prn prnVar, MenuItem menuItem, com1 com1Var) {
                this.f1917a = prnVar;
                this.f7837a = menuItem;
                this.f1915a = com1Var;
            }

            @Override // java.lang.Runnable
            public void run() {
                prn prnVar = this.f1917a;
                if (prnVar != null) {
                    con.this.f1914g = true;
                    prnVar.f1919a.e(false);
                    con.this.f1914g = false;
                }
                if (this.f7837a.isEnabled() && this.f7837a.hasSubMenu()) {
                    this.f1915a.L(this.f7837a, 4);
                }
            }
        }

        public nul() {
        }

        @Override // p022CoN.e0
        public void n(com1 com1Var, MenuItem menuItem) {
            con.this.f1899a.removeCallbacksAndMessages(com1Var);
        }

        @Override // p022CoN.e0
        public void p(com1 com1Var, MenuItem menuItem) {
            con.this.f1899a.removeCallbacksAndMessages(null);
            int size = con.this.f1908b.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    i2 = -1;
                    break;
                } else if (com1Var == con.this.f1908b.get(i2).f1919a) {
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 == -1) {
                return;
            }
            int i3 = i2 + 1;
            con.this.f1899a.postAtTime(new aux(i3 < con.this.f1908b.size() ? con.this.f1908b.get(i3) : null, menuItem, com1Var), com1Var, SystemClock.uptimeMillis() + 200);
        }
    }

    public static class prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f7838a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final g0 f1918a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com1 f1919a;

        public prn(g0 g0Var, com1 com1Var, int i2) {
            this.f1918a = g0Var;
            this.f1919a = com1Var;
            this.f7838a = i2;
        }

        public ListView a() {
            return this.f1918a.d();
        }
    }

    public con(Context context, View view, int i2, int i3, boolean z2) {
        this.f1898a = context;
        this.f1901a = view;
        this.f7827b = i2;
        this.f7828c = i3;
        this.f1909b = z2;
        Resources resources = context.getResources();
        this.f7826a = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(p001AuX.com6.f5531d));
        this.f1899a = new Handler();
    }

    public final int A(com1 com1Var) {
        int size = this.f1908b.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (com1Var == this.f1908b.get(i2).f1919a) {
                return i2;
            }
        }
        return -1;
    }

    public final MenuItem B(com1 com1Var, com1 com1Var2) {
        int size = com1Var.size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = com1Var.getItem(i2);
            if (item.hasSubMenu() && com1Var2 == item.getSubMenu()) {
                return item;
            }
        }
        return null;
    }

    public final View C(prn prnVar, com1 com1Var) {
        androidx.appcompat.view.menu.prn prnVar2;
        int headersCount;
        int firstVisiblePosition;
        MenuItem menuItemB = B(prnVar.f1919a, com1Var);
        if (menuItemB == null) {
            return null;
        }
        ListView listViewA = prnVar.a();
        ListAdapter adapter = listViewA.getAdapter();
        int i2 = 0;
        if (adapter instanceof HeaderViewListAdapter) {
            HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
            headersCount = headerViewListAdapter.getHeadersCount();
            prnVar2 = (androidx.appcompat.view.menu.prn) headerViewListAdapter.getWrappedAdapter();
        } else {
            prnVar2 = (androidx.appcompat.view.menu.prn) adapter;
            headersCount = 0;
        }
        int count = prnVar2.getCount();
        while (true) {
            if (i2 >= count) {
                i2 = -1;
                break;
            }
            if (menuItemB == prnVar2.getItem(i2)) {
                break;
            }
            i2++;
        }
        if (i2 != -1 && (firstVisiblePosition = (i2 + headersCount) - listViewA.getFirstVisiblePosition()) >= 0 && firstVisiblePosition < listViewA.getChildCount()) {
            return listViewA.getChildAt(firstVisiblePosition);
        }
        return null;
    }

    public final int D() {
        return y.A(this.f1901a) == 1 ? 0 : 1;
    }

    public final int E(int i2) {
        List<prn> list = this.f1908b;
        ListView listViewA = list.get(list.size() - 1).a();
        int[] iArr = new int[2];
        listViewA.getLocationOnScreen(iArr);
        Rect rect = new Rect();
        this.f1907b.getWindowVisibleDisplayFrame(rect);
        if (this.f7831f == 1) {
            return (iArr[0] + listViewA.getWidth()) + i2 > rect.right ? 0 : 1;
        }
        return iArr[0] - i2 < 0 ? 1 : 0;
    }

    public final void F(com1 com1Var) {
        prn prnVar;
        View viewC;
        int i2;
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.f1898a);
        androidx.appcompat.view.menu.prn prnVar2 = new androidx.appcompat.view.menu.prn(com1Var, layoutInflaterFrom, this.f1909b, f7825i);
        if (!b() && this.f1912e) {
            prnVar2.d(true);
        } else if (b()) {
            prnVar2.d(f1.x(com1Var));
        }
        int iO = f1.o(prnVar2, null, this.f1898a, this.f7826a);
        g0 g0VarZ = z();
        g0VarZ.g(prnVar2);
        g0VarZ.F(iO);
        g0VarZ.G(this.f7830e);
        if (this.f1908b.size() > 0) {
            List<prn> list = this.f1908b;
            prnVar = list.get(list.size() - 1);
            viewC = C(prnVar, com1Var);
        } else {
            prnVar = null;
            viewC = null;
        }
        if (viewC != null) {
            g0VarZ.U(false);
            g0VarZ.R(null);
            int iE = E(iO);
            boolean z2 = iE == 1;
            this.f7831f = iE;
            g0VarZ.D(viewC);
            if ((this.f7830e & 5) == 5) {
                if (z2) {
                    i2 = iO + 0;
                } else {
                    iO = viewC.getWidth();
                    i2 = 0 - iO;
                }
            } else if (z2) {
                iO = viewC.getWidth();
                i2 = iO + 0;
            } else {
                i2 = 0 - iO;
            }
            g0VarZ.e(i2);
            g0VarZ.M(true);
            g0VarZ.o(0);
        } else {
            if (this.f1910c) {
                g0VarZ.e(this.f7832g);
            }
            if (this.f1911d) {
                g0VarZ.o(this.f7833h);
            }
            g0VarZ.H(n());
        }
        this.f1908b.add(new prn(g0VarZ, com1Var, this.f7831f));
        g0VarZ.a();
        ListView listViewD = g0VarZ.d();
        listViewD.setOnKeyListener(this);
        if (prnVar == null && this.f1913f && com1Var.x() != null) {
            FrameLayout frameLayout = (FrameLayout) layoutInflaterFrom.inflate(com9.f5602l, (ViewGroup) listViewD, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            frameLayout.setEnabled(false);
            textView.setText(com1Var.x());
            listViewD.addHeaderView(frameLayout, null, false);
            g0VarZ.a();
        }
    }

    @Override // p099coN.h1
    public void a() {
        if (b()) {
            return;
        }
        Iterator<com1> it = this.f1906a.iterator();
        while (it.hasNext()) {
            F(it.next());
        }
        this.f1906a.clear();
        View view = this.f1901a;
        this.f1907b = view;
        if (view != null) {
            boolean z2 = this.f1903a == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.f1903a = viewTreeObserver;
            if (z2) {
                viewTreeObserver.addOnGlobalLayoutListener(this.f1902a);
            }
            this.f1907b.addOnAttachStateChangeListener(this.f1900a);
        }
    }

    @Override // p099coN.h1
    public boolean b() {
        return this.f1908b.size() > 0 && this.f1908b.get(0).f1918a.b();
    }

    @Override // androidx.appcompat.view.menu.com5
    public void c(com1 com1Var, boolean z2) {
        int iA = A(com1Var);
        if (iA < 0) {
            return;
        }
        int i2 = iA + 1;
        if (i2 < this.f1908b.size()) {
            this.f1908b.get(i2).f1919a.e(false);
        }
        prn prnVarRemove = this.f1908b.remove(iA);
        prnVarRemove.f1919a.O(this);
        if (this.f1914g) {
            prnVarRemove.f1918a.S(null);
            prnVarRemove.f1918a.E(0);
        }
        prnVarRemove.f1918a.dismiss();
        int size = this.f1908b.size();
        if (size > 0) {
            this.f7831f = this.f1908b.get(size - 1).f7838a;
        } else {
            this.f7831f = D();
        }
        if (size != 0) {
            if (z2) {
                this.f1908b.get(0).f1919a.e(false);
                return;
            }
            return;
        }
        dismiss();
        com5.aux auxVar = this.f1905a;
        if (auxVar != null) {
            auxVar.c(com1Var, true);
        }
        ViewTreeObserver viewTreeObserver = this.f1903a;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.f1903a.removeGlobalOnLayoutListener(this.f1902a);
            }
            this.f1903a = null;
        }
        this.f1907b.removeOnAttachStateChangeListener(this.f1900a);
        this.f1904a.onDismiss();
    }

    @Override // p099coN.h1
    public ListView d() {
        if (this.f1908b.isEmpty()) {
            return null;
        }
        List<prn> list = this.f1908b;
        return list.get(list.size() - 1).a();
    }

    @Override // p099coN.h1
    public void dismiss() {
        int size = this.f1908b.size();
        if (size > 0) {
            prn[] prnVarArr = (prn[]) this.f1908b.toArray(new prn[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                prn prnVar = prnVarArr[i2];
                if (prnVar.f1918a.b()) {
                    prnVar.f1918a.dismiss();
                }
            }
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public void e(boolean z2) {
        Iterator<prn> it = this.f1908b.iterator();
        while (it.hasNext()) {
            f1.y(it.next().a().getAdapter()).notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean f() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.com5
    public void g(com5.aux auxVar) {
        this.f1905a = auxVar;
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean j(com8 com8Var) {
        for (prn prnVar : this.f1908b) {
            if (com8Var == prnVar.f1919a) {
                prnVar.a().requestFocus();
                return true;
            }
        }
        if (!com8Var.hasVisibleItems()) {
            return false;
        }
        l(com8Var);
        com5.aux auxVar = this.f1905a;
        if (auxVar != null) {
            auxVar.d(com8Var);
        }
        return true;
    }

    @Override // p099coN.f1
    public void l(com1 com1Var) {
        com1Var.c(this, this.f1898a);
        if (b()) {
            F(com1Var);
        } else {
            this.f1906a.add(com1Var);
        }
    }

    @Override // p099coN.f1
    public boolean m() {
        return false;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        prn prnVar;
        int size = this.f1908b.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                prnVar = null;
                break;
            }
            prnVar = this.f1908b.get(i2);
            if (!prnVar.f1918a.b()) {
                break;
            } else {
                i2++;
            }
        }
        if (prnVar != null) {
            prnVar.f1919a.e(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // p099coN.f1
    public void p(View view) {
        if (this.f1901a != view) {
            this.f1901a = view;
            this.f7830e = f.b(this.f7829d, y.A(view));
        }
    }

    @Override // p099coN.f1
    public void r(boolean z2) {
        this.f1912e = z2;
    }

    @Override // p099coN.f1
    public void s(int i2) {
        if (this.f7829d != i2) {
            this.f7829d = i2;
            this.f7830e = f.b(i2, y.A(this.f1901a));
        }
    }

    @Override // p099coN.f1
    public void t(int i2) {
        this.f1910c = true;
        this.f7832g = i2;
    }

    @Override // p099coN.f1
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.f1904a = onDismissListener;
    }

    @Override // p099coN.f1
    public void v(boolean z2) {
        this.f1913f = z2;
    }

    @Override // p099coN.f1
    public void w(int i2) {
        this.f1911d = true;
        this.f7833h = i2;
    }

    public final g0 z() {
        g0 g0Var = new g0(this.f1898a, null, this.f7827b, this.f7828c);
        g0Var.T(this.f1897a);
        g0Var.L(this);
        g0Var.K(this);
        g0Var.D(this.f1901a);
        g0Var.G(this.f7830e);
        g0Var.J(true);
        g0Var.I(2);
        return g0Var;
    }
}
