package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;
import p016CoM4.com7;

/* JADX INFO: loaded from: classes.dex */
public abstract class TwoStatePreference extends Preference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CharSequence f8484a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f8485b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2666b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f8486c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8487d;

    public TwoStatePreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
    }

    public boolean a() {
        return this.f2666b;
    }

    public void b(boolean z2) {
        boolean z3 = this.f2666b != z2;
        if (z3 || !this.f8486c) {
            this.f2666b = z2;
            this.f8486c = true;
            persistBoolean(z2);
            if (z3) {
                notifyDependencyChange(shouldDisableDependents());
                notifyChanged();
            }
        }
    }

    public void c(boolean z2) {
        this.f8487d = z2;
    }

    public void d(CharSequence charSequence) {
        this.f8485b = charSequence;
        if (a()) {
            return;
        }
        notifyChanged();
    }

    public void e(CharSequence charSequence) {
        this.f8484a = charSequence;
        if (a()) {
            notifyChanged();
        }
    }

    public void f(com7 com7Var) {
        g(com7Var.M(R.id.summary));
    }

    /* JADX WARN: Code duplicated, block: B:18:0x0030  */
    /* JADX WARN: Code duplicated, block: B:20:0x003a  */
    /* JADX WARN: Code duplicated, block: B:23:0x0041  */
    /* JADX WARN: Code duplicated, block: B:26:0x0049  */
    /* JADX WARN: Code duplicated, block: B:28:? A[RETURN, SYNTHETIC] */
    public void g(View view) {
        boolean z2;
        int i2;
        CharSequence summary;
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            if (!this.f2666b || TextUtils.isEmpty(this.f8484a)) {
                if (this.f2666b || TextUtils.isEmpty(this.f8485b)) {
                    z2 = true;
                } else {
                    textView.setText(this.f8485b);
                }
                if (z2) {
                    summary = getSummary();
                    if (!TextUtils.isEmpty(summary)) {
                        textView.setText(summary);
                        z2 = false;
                    }
                }
                i2 = z2 ? 8 : 0;
                if (i2 != textView.getVisibility()) {
                    textView.setVisibility(i2);
                }
            }
            textView.setText(this.f8484a);
            z2 = false;
            if (z2) {
                summary = getSummary();
                if (!TextUtils.isEmpty(summary)) {
                    textView.setText(summary);
                    z2 = false;
                }
            }
            if (z2) {
            }
            if (i2 != textView.getVisibility()) {
                textView.setVisibility(i2);
            }
        }
    }

    @Override // androidx.preference.Preference
    public void onClick() {
        super.onClick();
        boolean z2 = !a();
        if (callChangeListener(Boolean.valueOf(z2))) {
            b(z2);
        }
    }

    @Override // androidx.preference.Preference
    public Object onGetDefaultValue(TypedArray typedArray, int i2) {
        return Boolean.valueOf(typedArray.getBoolean(i2, false));
    }

    @Override // androidx.preference.Preference
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(aux.class)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        aux auxVar = (aux) parcelable;
        super.onRestoreInstanceState(auxVar.getSuperState());
        b(auxVar.f8488b);
    }

    @Override // androidx.preference.Preference
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState = super.onSaveInstanceState();
        if (isPersistent()) {
            return parcelableOnSaveInstanceState;
        }
        aux auxVar = new aux(parcelableOnSaveInstanceState);
        auxVar.f8488b = a();
        return auxVar;
    }

    @Override // androidx.preference.Preference
    public void onSetInitialValue(Object obj) {
        if (obj == null) {
            obj = Boolean.FALSE;
        }
        b(getPersistedBoolean(((Boolean) obj).booleanValue()));
    }

    @Override // androidx.preference.Preference
    public boolean shouldDisableDependents() {
        boolean z2;
        if (this.f8487d) {
            z2 = this.f2666b;
        } else {
            z2 = !this.f2666b;
        }
        return z2 || super.shouldDisableDependents();
    }

    public static class aux extends Preference.con {
        public static final Parcelable.Creator<aux> CREATOR = new C0042aux();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8488b;

        /* JADX INFO: renamed from: androidx.preference.TwoStatePreference$aux$aux, reason: collision with other inner class name */
        public class C0042aux implements Parcelable.Creator<aux> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public aux createFromParcel(Parcel parcel) {
                return new aux(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public aux[] newArray(int i2) {
                return new aux[i2];
            }
        }

        public aux(Parcel parcel) {
            super(parcel);
            this.f8488b = parcel.readInt() == 1;
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f8488b ? 1 : 0);
        }

        public aux(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public TwoStatePreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public TwoStatePreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TwoStatePreference(Context context) {
        this(context, null);
    }
}
