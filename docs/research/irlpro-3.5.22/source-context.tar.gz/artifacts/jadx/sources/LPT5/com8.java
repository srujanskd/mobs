package LPT5;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class com8 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f6669a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f874a = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<Long> f875a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f6670b;

    public com8(int i2) {
        this.f6670b = i2;
        this.f875a = new ArrayList(i2);
    }

    public double a() {
        if (this.f875a.isEmpty()) {
            return 0.0d;
        }
        Long lValueOf = 0L;
        Iterator<Long> it = this.f875a.iterator();
        while (it.hasNext()) {
            lValueOf = Long.valueOf(lValueOf.longValue() + it.next().longValue());
        }
        return lValueOf.doubleValue() / ((double) this.f875a.size());
    }

    public void b(long j2) {
        long j3 = this.f874a;
        long j4 = j2 > j3 ? j2 - j3 : 0L;
        if (this.f875a.size() < this.f6670b) {
            this.f875a.add(Long.valueOf(j4));
        } else {
            this.f875a.set(this.f6669a, Long.valueOf(j4));
        }
        this.f6669a = (this.f6669a + 1) % this.f6670b;
        this.f874a = j2;
    }
}
