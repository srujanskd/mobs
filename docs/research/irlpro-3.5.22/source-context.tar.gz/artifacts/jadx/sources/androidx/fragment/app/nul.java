package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import p015CoM3.n;
import p024Com2.k0;
import p024Com2.v;
import p024Com2.y;
import p101com2.u2;
import p147nUl.x;

/* JADX INFO: loaded from: classes.dex */
public class nul extends lpt5 {

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8340a;

        static {
            int[] iArr = new int[lpt5.com1.nul.values().length];
            f8340a = iArr;
            try {
                iArr[lpt5.com1.nul.GONE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8340a[lpt5.com1.nul.INVISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8340a[lpt5.com1.nul.REMOVED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f8340a[lpt5.com1.nul.VISIBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public class com1 implements Animation.AnimationListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8341a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewGroup f2563a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com7 f2564a;

        public class aux implements Runnable {
            public aux() {
            }

            @Override // java.lang.Runnable
            public void run() {
                com1 com1Var = com1.this;
                com1Var.f2563a.endViewTransition(com1Var.f8341a);
                com1.this.f2564a.a();
            }
        }

        public com1(ViewGroup viewGroup, View view, com7 com7Var) {
            this.f2563a = viewGroup;
            this.f8341a = view;
            this.f2564a = com7Var;
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            this.f2563a.post(new aux());
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    public class com2 implements CoM1.com7.con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8343a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewGroup f2566a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com7 f2567a;

        public com2(View view, ViewGroup viewGroup, com7 com7Var) {
            this.f8343a = view;
            this.f2566a = viewGroup;
            this.f2567a = com7Var;
        }

        @Override // CoM1.com7.con
        public void onCancel() {
            this.f8343a.clearAnimation();
            this.f2566a.endViewTransition(this.f8343a);
            this.f2567a.a();
        }
    }

    public class com3 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ lpt5.com1 f8344a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ x f2570a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ lpt5.com1 f8345b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ boolean f2571b;

        public com3(lpt5.com1 com1Var, lpt5.com1 com1Var2, boolean z2, x xVar) {
            this.f8344a = com1Var;
            this.f8345b = com1Var2;
            this.f2571b = z2;
            this.f2570a = xVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            lpt4.f(this.f8344a.f(), this.f8345b.f(), this.f2571b, this.f2570a, false);
        }
    }

    public class com4 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ n f8346a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Rect f2572a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f2573a;

        public com4(n nVar, View view, Rect rect) {
            this.f8346a = nVar;
            this.f2573a = view;
            this.f2572a = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f8346a.k(this.f2573a, this.f2572a);
        }
    }

    public class com5 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2575a;

        public com5(ArrayList arrayList) {
            this.f2575a = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            lpt4.A(this.f2575a, 4);
        }
    }

    public class com6 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ com9 f8348a;

        public com6(com9 com9Var) {
            this.f8348a = com9Var;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f8348a.a();
        }
    }

    public static class com7 extends com8 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public androidx.fragment.app.com1.prn f8349a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2577a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8350b;

        public com7(lpt5.com1 com1Var, p013CoM1.com7 com7Var, boolean z2) {
            super(com1Var, com7Var);
            this.f8350b = false;
            this.f2577a = z2;
        }

        public androidx.fragment.app.com1.prn e(Context context) {
            if (this.f8350b) {
                return this.f8349a;
            }
            androidx.fragment.app.com1.prn prnVarC = androidx.fragment.app.com1.c(context, b().f(), b().e() == lpt5.com1.nul.VISIBLE, this.f2577a);
            this.f8349a = prnVarC;
            this.f8350b = true;
            return prnVarC;
        }
    }

    public static class com8 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final p013CoM1.com7 f8351a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final lpt5.com1 f2578a;

        public com8(lpt5.com1 com1Var, p013CoM1.com7 com7Var) {
            this.f2578a = com1Var;
            this.f8351a = com7Var;
        }

        public void a() {
            this.f2578a.d(this.f8351a);
        }

        public lpt5.com1 b() {
            return this.f2578a;
        }

        public p013CoM1.com7 c() {
            return this.f8351a;
        }

        public boolean d() {
            lpt5.com1.nul nulVar;
            lpt5.com1.nul nulVarD = lpt5.com1.nul.d(this.f2578a.f().mView);
            lpt5.com1.nul nulVarE = this.f2578a.e();
            return nulVarD == nulVarE || !(nulVarD == (nulVar = lpt5.com1.nul.VISIBLE) || nulVarE == nulVar);
        }
    }

    public static class com9 extends com8 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Object f8352a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final boolean f2579a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final Object f8353b;

        public com9(lpt5.com1 com1Var, p013CoM1.com7 com7Var, boolean z2, boolean z3) {
            super(com1Var, com7Var);
            if (com1Var.e() == lpt5.com1.nul.VISIBLE) {
                this.f8352a = z2 ? com1Var.f().getReenterTransition() : com1Var.f().getEnterTransition();
                this.f2579a = z2 ? com1Var.f().getAllowReturnTransitionOverlap() : com1Var.f().getAllowEnterTransitionOverlap();
            } else {
                this.f8352a = z2 ? com1Var.f().getReturnTransition() : com1Var.f().getExitTransition();
                this.f2579a = true;
            }
            if (!z3) {
                this.f8353b = null;
            } else if (z2) {
                this.f8353b = com1Var.f().getSharedElementReturnTransition();
            } else {
                this.f8353b = com1Var.f().getSharedElementEnterTransition();
            }
        }

        public n e() {
            n nVarF = f(this.f8352a);
            n nVarF2 = f(this.f8353b);
            if (nVarF == null || nVarF2 == null || nVarF == nVarF2) {
                return nVarF != null ? nVarF : nVarF2;
            }
            throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + b().f() + " returned Transition " + this.f8352a + " which uses a different Transition  type than its shared element transition " + this.f8353b);
        }

        public final n f(Object obj) {
            if (obj == null) {
                return null;
            }
            n nVar = lpt4.f8309a;
            if (nVar != null && nVar.e(obj)) {
                return nVar;
            }
            n nVar2 = lpt4.f8310b;
            if (nVar2 != null && nVar2.e(obj)) {
                return nVar2;
            }
            throw new IllegalArgumentException("Transition " + obj + " for fragment " + b().f() + " is not a valid framework Transition or AndroidX Transition");
        }

        public Object g() {
            return this.f8353b;
        }

        public Object h() {
            return this.f8352a;
        }

        public boolean i() {
            return this.f8353b != null;
        }

        public boolean j() {
            return this.f2579a;
        }
    }

    public class con implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ lpt5.com1 f8354a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ List f2581a;

        public con(List list, lpt5.com1 com1Var) {
            this.f2581a = list;
            this.f8354a = com1Var;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.f2581a.contains(this.f8354a)) {
                this.f2581a.remove(this.f8354a);
                nul.this.s(this.f8354a);
            }
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.nul$nul, reason: collision with other inner class name */
    public class C0037nul extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8355a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewGroup f2582a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ lpt5.com1 f2583a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com7 f2584a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ boolean f8356b;

        public C0037nul(ViewGroup viewGroup, View view, boolean z2, lpt5.com1 com1Var, com7 com7Var) {
            this.f2582a = viewGroup;
            this.f8355a = view;
            this.f8356b = z2;
            this.f2583a = com1Var;
            this.f2584a = com7Var;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2582a.endViewTransition(this.f8355a);
            if (this.f8356b) {
                this.f2583a.e().a(this.f8355a);
            }
            this.f2584a.a();
        }
    }

    public class prn implements CoM1.com7.con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Animator f8357a;

        public prn(Animator animator) {
            this.f8357a = animator;
        }

        @Override // CoM1.com7.con
        public void onCancel() {
            this.f8357a.end();
        }
    }

    public nul(ViewGroup viewGroup) {
        super(viewGroup);
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0085  */
    @Override // androidx.fragment.app.lpt5
    public void f(List<lpt5.com1> list, boolean z2) {
        lpt5.com1 com1Var = null;
        lpt5.com1 com1Var2 = null;
        for (lpt5.com1 com1Var3 : list) {
            lpt5.com1.nul nulVarD = lpt5.com1.nul.d(com1Var3.f().mView);
            int i2 = aux.f8340a[com1Var3.e().ordinal()];
            if (i2 == 1 || i2 == 2 || i2 == 3) {
                if (nulVarD == lpt5.com1.nul.VISIBLE && com1Var == null) {
                    com1Var = com1Var3;
                }
            } else if (i2 == 4 && nulVarD != lpt5.com1.nul.VISIBLE) {
                com1Var2 = com1Var3;
            }
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList(list);
        for (lpt5.com1 com1Var4 : list) {
            p013CoM1.com7 com7Var = new p013CoM1.com7();
            com1Var4.j(com7Var);
            arrayList.add(new com7(com1Var4, com7Var, z2));
            p013CoM1.com7 com7Var2 = new p013CoM1.com7();
            com1Var4.j(com7Var2);
            boolean z3 = false;
            if (z2) {
                if (com1Var4 == com1Var) {
                    z3 = true;
                }
            } else if (com1Var4 == com1Var2) {
                z3 = true;
            }
            arrayList2.add(new com9(com1Var4, com7Var2, z2, z3));
            com1Var4.a(new con(arrayList3, com1Var4));
        }
        Map<lpt5.com1, Boolean> mapX = x(arrayList2, arrayList3, z2, com1Var, com1Var2);
        w(arrayList, arrayList3, mapX.containsValue(Boolean.TRUE), mapX);
        Iterator<lpt5.com1> it = arrayList3.iterator();
        while (it.hasNext()) {
            s(it.next());
        }
        arrayList3.clear();
    }

    public void s(lpt5.com1 com1Var) {
        com1Var.e().a(com1Var.f().mView);
    }

    public void t(ArrayList<View> arrayList, View view) {
        if (!(view instanceof ViewGroup)) {
            if (arrayList.contains(view)) {
                return;
            }
            arrayList.add(view);
            return;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        if (k0.a(viewGroup)) {
            if (arrayList.contains(view)) {
                return;
            }
            arrayList.add(viewGroup);
            return;
        }
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = viewGroup.getChildAt(i2);
            if (childAt.getVisibility() == 0) {
                t(arrayList, childAt);
            }
        }
    }

    public void u(Map<String, View> map, View view) {
        String strJ = y.J(view);
        if (strJ != null) {
            map.put(strJ, view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = viewGroup.getChildAt(i2);
                if (childAt.getVisibility() == 0) {
                    u(map, childAt);
                }
            }
        }
    }

    public void v(x<String, View> xVar, Collection<String> collection) {
        Iterator<Map.Entry<String, View>> it = xVar.entrySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(y.J(it.next().getValue()))) {
                it.remove();
            }
        }
    }

    public final void w(List<com7> list, List<lpt5.com1> list2, boolean z2, Map<lpt5.com1, Boolean> map) {
        ViewGroup viewGroupM = m();
        Context context = viewGroupM.getContext();
        ArrayList<com7> arrayList = new ArrayList();
        boolean z3 = false;
        for (com7 com7Var : list) {
            if (com7Var.d()) {
                com7Var.a();
            } else {
                androidx.fragment.app.com1.prn prnVarE = com7Var.e(context);
                if (prnVarE == null) {
                    com7Var.a();
                } else {
                    Animator animator = prnVarE.f8244a;
                    if (animator == null) {
                        arrayList.add(com7Var);
                    } else {
                        lpt5.com1 com1VarB = com7Var.b();
                        Fragment fragmentF = com1VarB.f();
                        if (Boolean.TRUE.equals(map.get(com1VarB))) {
                            if (androidx.fragment.app.com6.H0(2)) {
                                Log.v("FragmentManager", "Ignoring Animator set on " + fragmentF + " as this Fragment was involved in a Transition.");
                            }
                            com7Var.a();
                        } else {
                            boolean z4 = com1VarB.e() == lpt5.com1.nul.GONE;
                            if (z4) {
                                list2.remove(com1VarB);
                            }
                            View view = fragmentF.mView;
                            viewGroupM.startViewTransition(view);
                            animator.addListener(new C0037nul(viewGroupM, view, z4, com1VarB, com7Var));
                            animator.setTarget(view);
                            animator.start();
                            com7Var.c().c(new prn(animator));
                            z3 = true;
                        }
                    }
                }
            }
        }
        for (com7 com7Var2 : arrayList) {
            lpt5.com1 com1VarB2 = com7Var2.b();
            Fragment fragmentF2 = com1VarB2.f();
            if (z2) {
                if (androidx.fragment.app.com6.H0(2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragmentF2 + " as Animations cannot run alongside Transitions.");
                }
                com7Var2.a();
            } else if (z3) {
                if (androidx.fragment.app.com6.H0(2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + fragmentF2 + " as Animations cannot run alongside Animators.");
                }
                com7Var2.a();
            } else {
                View view2 = fragmentF2.mView;
                Animation animation = (Animation) u2.f(((androidx.fragment.app.com1.prn) u2.f(com7Var2.e(context))).f2427a);
                if (com1VarB2.e() != lpt5.com1.nul.REMOVED) {
                    view2.startAnimation(animation);
                    com7Var2.a();
                } else {
                    viewGroupM.startViewTransition(view2);
                    androidx.fragment.app.com1.RunnableC0035com1 runnableC0035com1 = new androidx.fragment.app.com1.RunnableC0035com1(animation, viewGroupM, view2);
                    runnableC0035com1.setAnimationListener(new com1(viewGroupM, view2, com7Var2));
                    view2.startAnimation(runnableC0035com1);
                }
                com7Var2.c().c(new com2(view2, viewGroupM, com7Var2));
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final Map<lpt5.com1, Boolean> x(List<com9> list, List<lpt5.com1> list2, boolean z2, lpt5.com1 com1Var, lpt5.com1 com1Var2) {
        View view;
        Object obj;
        ArrayList<View> arrayList;
        Object obj2;
        ArrayList<View> arrayList2;
        lpt5.com1 com1Var3;
        lpt5.com1 com1Var4;
        View view2;
        Object objN;
        ArrayList<View> arrayList3;
        lpt5.com1 com1Var5;
        lpt5.com1 com1Var6;
        View view3;
        lpt5.com1 com1Var7 = com1Var;
        lpt5.com1 com1Var8 = com1Var2;
        HashMap map = new HashMap();
        n nVar = null;
        for (com9 com9Var : list) {
            if (!com9Var.d()) {
                n nVarE = com9Var.e();
                if (nVar == null) {
                    nVar = nVarE;
                } else if (nVarE != null && nVar != nVarE) {
                    throw new IllegalArgumentException("Mixing framework transitions and AndroidX transitions is not allowed. Fragment " + com9Var.b().f() + " returned Transition " + com9Var.h() + " which uses a different Transition  type than other Fragments.");
                }
            }
        }
        if (nVar == null) {
            for (com9 com9Var2 : list) {
                map.put(com9Var2.b(), Boolean.FALSE);
                com9Var2.a();
            }
            return map;
        }
        View view4 = new View(m().getContext());
        Rect rect = new Rect();
        ArrayList<View> arrayList4 = new ArrayList<>();
        ArrayList<View> arrayList5 = new ArrayList<>();
        x xVar = new x();
        Object obj3 = null;
        View view5 = null;
        boolean z3 = false;
        for (com9 com9Var3 : list) {
            if (!com9Var3.i() || com1Var7 == null || com1Var8 == null) {
                arrayList3 = arrayList5;
                com1Var5 = com1Var7;
                com1Var6 = com1Var8;
                view5 = view5;
            } else {
                Object objB = nVar.B(nVar.g(com9Var3.g()));
                ArrayList<String> sharedElementSourceNames = com1Var2.f().getSharedElementSourceNames();
                ArrayList<String> sharedElementSourceNames2 = com1Var.f().getSharedElementSourceNames();
                ArrayList<String> sharedElementTargetNames = com1Var.f().getSharedElementTargetNames();
                View view6 = view5;
                int i2 = 0;
                while (i2 < sharedElementTargetNames.size()) {
                    int iIndexOf = sharedElementSourceNames.indexOf(sharedElementTargetNames.get(i2));
                    ArrayList<String> arrayList6 = sharedElementTargetNames;
                    if (iIndexOf != -1) {
                        sharedElementSourceNames.set(iIndexOf, sharedElementSourceNames2.get(i2));
                    }
                    i2++;
                    sharedElementTargetNames = arrayList6;
                }
                ArrayList<String> sharedElementTargetNames2 = com1Var2.f().getSharedElementTargetNames();
                if (z2 == 0) {
                    com1Var.f().getExitTransitionCallback();
                    com1Var2.f().getEnterTransitionCallback();
                } else {
                    com1Var.f().getEnterTransitionCallback();
                    com1Var2.f().getExitTransitionCallback();
                }
                int i3 = 0;
                for (int size = sharedElementSourceNames.size(); i3 < size; size = size) {
                    xVar.put(sharedElementSourceNames.get(i3), sharedElementTargetNames2.get(i3));
                    i3++;
                }
                x<String, View> xVar2 = new x<>();
                u(xVar2, com1Var.f().mView);
                xVar2.o(sharedElementSourceNames);
                xVar.o(xVar2.keySet());
                x<String, View> xVar3 = new x<>();
                u(xVar3, com1Var2.f().mView);
                xVar3.o(sharedElementTargetNames2);
                xVar3.o(xVar.values());
                lpt4.x(xVar, xVar3);
                v(xVar2, xVar.keySet());
                v(xVar3, xVar.values());
                if (xVar.isEmpty()) {
                    arrayList4.clear();
                    arrayList5.clear();
                    arrayList3 = arrayList5;
                    com1Var5 = com1Var7;
                    view5 = view6;
                    obj3 = null;
                    com1Var6 = com1Var8;
                } else {
                    lpt4.f(com1Var2.f(), com1Var.f(), z2, xVar2, true);
                    ArrayList<View> arrayList7 = arrayList5;
                    v.a(m(), new com3(com1Var2, com1Var, z2, xVar3));
                    arrayList4.addAll(xVar2.values());
                    if (sharedElementSourceNames.isEmpty()) {
                        view5 = view6;
                    } else {
                        View view7 = (View) xVar2.get(sharedElementSourceNames.get(0));
                        nVar.v(objB, view7);
                        view5 = view7;
                    }
                    arrayList3 = arrayList7;
                    arrayList3.addAll(xVar3.values());
                    if (!sharedElementTargetNames2.isEmpty() && (view3 = (View) xVar3.get(sharedElementTargetNames2.get(0))) != null) {
                        v.a(m(), new com4(nVar, view3, rect));
                        z3 = true;
                    }
                    nVar.z(objB, view4, arrayList4);
                    nVar.t(objB, null, null, null, null, objB, arrayList3);
                    Boolean bool = Boolean.TRUE;
                    com1Var5 = com1Var;
                    map.put(com1Var5, bool);
                    com1Var6 = com1Var2;
                    map.put(com1Var6, bool);
                    obj3 = objB;
                }
            }
            com1Var7 = com1Var5;
            arrayList4 = arrayList4;
            rect = rect;
            view4 = view4;
            com1Var8 = com1Var6;
            xVar = xVar;
            arrayList5 = arrayList3;
            nVar = nVar;
        }
        View view8 = view5;
        x xVar4 = xVar;
        ArrayList<View> arrayList8 = arrayList5;
        lpt5.com1 com1Var9 = com1Var7;
        ArrayList<View> arrayList9 = arrayList4;
        Rect rect2 = rect;
        View view9 = view4;
        n nVar2 = nVar;
        boolean z4 = false;
        lpt5.com1 com1Var10 = com1Var8;
        ArrayList arrayList10 = new ArrayList();
        Object obj4 = null;
        Object objN2 = null;
        for (com9 com9Var4 : list) {
            if (com9Var4.d()) {
                map.put(com9Var4.b(), Boolean.FALSE);
                com9Var4.a();
            } else {
                Object objG = nVar2.g(com9Var4.h());
                lpt5.com1 com1VarB = com9Var4.b();
                boolean z5 = (obj3 == null || !(com1VarB == com1Var9 || com1VarB == com1Var10)) ? z4 : true;
                if (objG == null) {
                    if (!z5) {
                        map.put(com1VarB, Boolean.FALSE);
                        com9Var4.a();
                    }
                    arrayList2 = arrayList8;
                    arrayList = arrayList9;
                    view = view9;
                    objN = obj4;
                    com1Var3 = com1Var10;
                    view2 = view8;
                } else {
                    ArrayList<View> arrayList11 = new ArrayList<>();
                    Object obj5 = obj4;
                    t(arrayList11, com1VarB.f().mView);
                    if (z5) {
                        if (com1VarB == com1Var9) {
                            arrayList11.removeAll(arrayList9);
                        } else {
                            arrayList11.removeAll(arrayList8);
                        }
                    }
                    if (arrayList11.isEmpty()) {
                        nVar2.a(objG, view9);
                        arrayList2 = arrayList8;
                        arrayList = arrayList9;
                        view = view9;
                        com1Var4 = com1VarB;
                        obj2 = objN2;
                        com1Var3 = com1Var10;
                        obj = obj5;
                    } else {
                        nVar2.b(objG, arrayList11);
                        view = view9;
                        obj = obj5;
                        arrayList = arrayList9;
                        obj2 = objN2;
                        arrayList2 = arrayList8;
                        com1Var3 = com1Var10;
                        nVar2.t(objG, objG, arrayList11, null, null, null, null);
                        if (com1VarB.e() == lpt5.com1.nul.GONE) {
                            com1Var4 = com1VarB;
                            list2.remove(com1Var4);
                            ArrayList<View> arrayList12 = new ArrayList<>(arrayList11);
                            arrayList12.remove(com1Var4.f().mView);
                            nVar2.r(objG, com1Var4.f().mView, arrayList12);
                            v.a(m(), new com5(arrayList11));
                        } else {
                            com1Var4 = com1VarB;
                        }
                    }
                    if (com1Var4.e() == lpt5.com1.nul.VISIBLE) {
                        arrayList10.addAll(arrayList11);
                        if (z3) {
                            nVar2.u(objG, rect2);
                        }
                        view2 = view8;
                    } else {
                        view2 = view8;
                        nVar2.v(objG, view2);
                    }
                    map.put(com1Var4, Boolean.TRUE);
                    if (com9Var4.j()) {
                        objN2 = nVar2.n(obj2, objG, null);
                        objN = obj;
                    } else {
                        objN = nVar2.n(obj, objG, null);
                        objN2 = obj2;
                    }
                }
                com1Var10 = com1Var3;
                obj4 = objN;
                view8 = view2;
                view9 = view;
                arrayList9 = arrayList;
                arrayList8 = arrayList2;
                z4 = false;
            }
        }
        ArrayList<View> arrayList13 = arrayList8;
        ArrayList<View> arrayList14 = arrayList9;
        lpt5.com1 com1Var11 = com1Var10;
        Object objM = nVar2.m(objN2, obj4, obj3);
        for (com9 com9Var5 : list) {
            if (!com9Var5.d()) {
                Object objH = com9Var5.h();
                lpt5.com1 com1VarB2 = com9Var5.b();
                boolean z6 = obj3 != null && (com1VarB2 == com1Var9 || com1VarB2 == com1Var11);
                if (objH != null || z6) {
                    if (y.S(m())) {
                        nVar2.w(com9Var5.b().f(), objM, com9Var5.c(), new com6(com9Var5));
                    } else {
                        if (androidx.fragment.app.com6.H0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Container " + m() + " has not been laid out. Completing operation " + com1VarB2);
                        }
                        com9Var5.a();
                    }
                }
            }
        }
        if (!y.S(m())) {
            return map;
        }
        lpt4.A(arrayList10, 4);
        ArrayList<String> arrayListO = nVar2.o(arrayList13);
        nVar2.c(m(), objM);
        nVar2.y(m(), arrayList14, arrayList13, arrayListO, xVar4);
        lpt4.A(arrayList10, 0);
        nVar2.A(obj3, arrayList14, arrayList13);
        return map;
    }
}
