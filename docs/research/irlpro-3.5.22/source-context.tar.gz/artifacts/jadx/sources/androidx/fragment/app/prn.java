package androidx.fragment.app;

import COM3.lpt7;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.savedstate.SavedStateRegistry;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import p002Aux.lpt6;
import p015CoM3.j;
import p015CoM3.l;
import p015CoM3.o;
import p083cOm4.c;
import p150pRN.lpt9;

/* JADX INFO: loaded from: classes.dex */
public class prn extends ComponentActivity implements lpt9.nul {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f8359b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2587c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f8358a = j.b(new nul());

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final androidx.lifecycle.com1 f8360c = new androidx.lifecycle.com1(this);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8361d = true;

    public class aux implements SavedStateRegistry.con {
        public aux() {
        }

        @Override // androidx.savedstate.SavedStateRegistry.con
        public Bundle a() {
            Bundle bundle = new Bundle();
            prn.this.S();
            prn.this.f8360c.h(androidx.lifecycle.nul.con.ON_STOP);
            Parcelable parcelableX = prn.this.f8358a.x();
            if (parcelableX != null) {
                bundle.putParcelable("android:support:fragments", parcelableX);
            }
            return bundle;
        }
    }

    public class con implements p067aUx.j {
        public con() {
        }

        @Override // p067aUx.j
        public void a(Context context) {
            prn.this.f8358a.a(null);
            Bundle bundleA = prn.this.getSavedStateRegistry().a("android:support:fragments");
            if (bundleA != null) {
                prn.this.f8358a.w(bundleA.getParcelable("android:support:fragments"));
            }
        }
    }

    public class nul extends com3<prn> implements lpt7, lpt6, p000AUx.com1, l {
        public nul() {
            super(prn.this);
        }

        @Override // p000AUx.com1
        public ActivityResultRegistry E() {
            return prn.this.E();
        }

        @Override // p002Aux.lpt6
        public OnBackPressedDispatcher G() {
            return prn.this.G();
        }

        @Override // p015CoM3.l
        public void a(com6 com6Var, Fragment fragment) {
            prn.this.U(fragment);
        }

        @Override // androidx.fragment.app.com3, p015CoM3.i
        public View c(int i2) {
            return prn.this.findViewById(i2);
        }

        @Override // androidx.fragment.app.com3, p015CoM3.i
        public boolean d() {
            Window window = prn.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        @Override // COM3.com7
        public androidx.lifecycle.nul getLifecycle() {
            return prn.this.f8360c;
        }

        @Override // COM3.lpt7
        public COM3.lpt6 getViewModelStore() {
            return prn.this.getViewModelStore();
        }

        @Override // androidx.fragment.app.com3
        public LayoutInflater i() {
            return prn.this.getLayoutInflater().cloneInContext(prn.this);
        }

        @Override // androidx.fragment.app.com3
        public boolean k(Fragment fragment) {
            return !prn.this.isFinishing();
        }

        @Override // androidx.fragment.app.com3
        public boolean l(String str) {
            return lpt9.m(prn.this, str);
        }

        @Override // androidx.fragment.app.com3
        public void o() {
            prn.this.X();
        }

        @Override // androidx.fragment.app.com3
        /* JADX INFO: renamed from: p, reason: merged with bridge method [inline-methods] */
        public prn h() {
            return prn.this;
        }
    }

    public prn() {
        R();
    }

    public static boolean T(com6 com6Var, androidx.lifecycle.nul.EnumC0039nul enumC0039nul) {
        boolean zT = false;
        for (Fragment fragment : com6Var.u0()) {
            if (fragment != null) {
                if (fragment.getHost() != null) {
                    zT |= T(fragment.getChildFragmentManager(), enumC0039nul);
                }
                o oVar = fragment.mViewLifecycleOwner;
                if (oVar != null && oVar.getLifecycle().b().a(androidx.lifecycle.nul.EnumC0039nul.STARTED)) {
                    fragment.mViewLifecycleOwner.f(enumC0039nul);
                    zT = true;
                }
                if (fragment.mLifecycleRegistry.b().a(androidx.lifecycle.nul.EnumC0039nul.STARTED)) {
                    fragment.mLifecycleRegistry.o(enumC0039nul);
                    zT = true;
                }
            }
        }
        return zT;
    }

    public final View P(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f8358a.v(view, str, context, attributeSet);
    }

    public com6 Q() {
        return this.f8358a.t();
    }

    public final void R() {
        getSavedStateRegistry().d("android:support:fragments", new aux());
        J(new con());
    }

    public void S() {
        while (T(Q(), androidx.lifecycle.nul.EnumC0039nul.CREATED)) {
        }
    }

    @Deprecated
    public void U(Fragment fragment) {
    }

    @Deprecated
    public boolean V(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    public void W() {
        this.f8360c.h(androidx.lifecycle.nul.con.ON_RESUME);
        this.f8358a.p();
    }

    @Deprecated
    public void X() {
        invalidateOptionsMenu();
    }

    @Override // android.app.Activity
    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f8359b);
        printWriter.print(" mResumed=");
        printWriter.print(this.f2587c);
        printWriter.print(" mStopped=");
        printWriter.print(this.f8361d);
        if (getApplication() != null) {
            c.b(this).a(str2, fileDescriptor, printWriter, strArr);
        }
        this.f8358a.t().X(str, fileDescriptor, printWriter, strArr);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i2, int i3, Intent intent) {
        this.f8358a.u();
        super.onActivityResult(i2, i3, intent);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.f8358a.u();
        super.onConfigurationChanged(configuration);
        this.f8358a.d(configuration);
    }

    @Override // androidx.activity.ComponentActivity, p150pRN.d, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f8360c.h(androidx.lifecycle.nul.con.ON_CREATE);
        this.f8358a.f();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onCreatePanelMenu(int i2, Menu menu) {
        return i2 == 0 ? super.onCreatePanelMenu(i2, menu) | this.f8358a.g(menu, getMenuInflater()) : super.onCreatePanelMenu(i2, menu);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewP = P(view, str, context, attributeSet);
        return viewP == null ? super.onCreateView(view, str, context, attributeSet) : viewP;
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        this.f8358a.h();
        this.f8360c.h(androidx.lifecycle.nul.con.ON_DESTROY);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        this.f8358a.i();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 0) {
            return this.f8358a.k(menuItem);
        }
        if (i2 != 6) {
            return false;
        }
        return this.f8358a.e(menuItem);
    }

    @Override // android.app.Activity
    public void onMultiWindowModeChanged(boolean z2) {
        this.f8358a.j(z2);
    }

    @Override // android.app.Activity
    public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent intent) {
        this.f8358a.u();
        super.onNewIntent(intent);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i2, Menu menu) {
        if (i2 == 0) {
            this.f8358a.l(menu);
        }
        super.onPanelClosed(i2, menu);
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.f2587c = false;
        this.f8358a.m();
        this.f8360c.h(androidx.lifecycle.nul.con.ON_PAUSE);
    }

    @Override // android.app.Activity
    public void onPictureInPictureModeChanged(boolean z2) {
        this.f8358a.n(z2);
    }

    @Override // android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        W();
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onPreparePanel(int i2, View view, Menu menu) {
        return i2 == 0 ? V(view, menu) | this.f8358a.o(menu) : super.onPreparePanel(i2, view, menu);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        this.f8358a.u();
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    @Override // android.app.Activity
    public void onResume() {
        this.f8358a.u();
        super.onResume();
        this.f2587c = true;
        this.f8358a.s();
    }

    @Override // android.app.Activity
    public void onStart() {
        this.f8358a.u();
        super.onStart();
        this.f8361d = false;
        if (!this.f8359b) {
            this.f8359b = true;
            this.f8358a.c();
        }
        this.f8358a.s();
        this.f8360c.h(androidx.lifecycle.nul.con.ON_START);
        this.f8358a.q();
    }

    @Override // android.app.Activity
    public void onStateNotSaved() {
        this.f8358a.u();
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        this.f8361d = true;
        S();
        this.f8358a.r();
        this.f8360c.h(androidx.lifecycle.nul.con.ON_STOP);
    }

    @Override // pRN.lpt9.nul
    @Deprecated
    public final void p(int i2) {
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewP = P(null, str, context, attributeSet);
        return viewP == null ? super.onCreateView(str, context, attributeSet) : viewP;
    }
}
