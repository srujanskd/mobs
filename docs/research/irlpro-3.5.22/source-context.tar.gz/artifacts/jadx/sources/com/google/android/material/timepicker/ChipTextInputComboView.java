package com.google.android.material.timepicker;

import android.content.Context;
import android.content.res.Configuration;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.TextInputLayout;
import java.util.Arrays;
import p024Com2.lpt3;
import p024Com2.y;
import p042LpT1.m;
import p075cOM6.b4;
import p075cOM6.d4;
import p108com9.s;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
class ChipTextInputComboView extends FrameLayout implements Checkable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TextWatcher f9675a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final EditText f3744a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f3745a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Chip f3746a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout f3747a;

    public class con extends s {
        public con() {
        }

        @Override // p108com9.s, android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            if (TextUtils.isEmpty(editable)) {
                ChipTextInputComboView.this.f3746a.setText(ChipTextInputComboView.this.d("00"));
            } else {
                ChipTextInputComboView.this.f3746a.setText(ChipTextInputComboView.this.d(editable));
            }
        }
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public void c(InputFilter inputFilter) {
        InputFilter[] filters = this.f3744a.getFilters();
        InputFilter[] inputFilterArr = (InputFilter[]) Arrays.copyOf(filters, filters.length + 1);
        inputFilterArr[filters.length] = inputFilter;
        this.f3744a.setFilters(inputFilterArr);
    }

    public final String d(CharSequence charSequence) {
        return m.k(getResources(), charSequence);
    }

    public TextInputLayout e() {
        return this.f3747a;
    }

    public void f(lpt3 lpt3Var) {
        y.o0(this.f3746a, lpt3Var);
    }

    public void g(CharSequence charSequence) {
        this.f3746a.setText(d(charSequence));
        if (TextUtils.isEmpty(this.f3744a.getText())) {
            return;
        }
        this.f3744a.removeTextChangedListener(this.f9675a);
        this.f3744a.setText((CharSequence) null);
        this.f3744a.addTextChangedListener(this.f9675a);
    }

    public final void h() {
        this.f3744a.setImeHintLocales(getContext().getResources().getConfiguration().getLocales());
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.f3746a.isChecked();
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        h();
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z2) {
        this.f3746a.setChecked(z2);
        this.f3744a.setVisibility(z2 ? 0 : 4);
        this.f3746a.setVisibility(z2 ? 8 : 0);
        if (isChecked()) {
            v.h(this.f3744a);
            if (TextUtils.isEmpty(this.f3744a.getText())) {
                return;
            }
            EditText editText = this.f3744a;
            editText.setSelection(editText.getText().length());
        }
    }

    @Override // android.view.View
    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.f3746a.setOnClickListener(onClickListener);
    }

    @Override // android.view.View
    public void setTag(int i2, Object obj) {
        this.f3746a.setTag(i2, obj);
    }

    @Override // android.widget.Checkable
    public void toggle() {
        this.f3746a.toggle();
    }

    public ChipTextInputComboView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        Chip chip = (Chip) layoutInflaterFrom.inflate(d4.f8916j, (ViewGroup) this, false);
        this.f3746a = chip;
        chip.setAccessibilityClassName("android.view.View");
        TextInputLayout textInputLayout = (TextInputLayout) layoutInflaterFrom.inflate(d4.f8917k, (ViewGroup) this, false);
        this.f3747a = textInputLayout;
        EditText editText = textInputLayout.getEditText();
        this.f3744a = editText;
        editText.setVisibility(4);
        con conVar = new con();
        this.f9675a = conVar;
        editText.addTextChangedListener(conVar);
        h();
        addView(chip);
        addView(textInputLayout);
        this.f3745a = (TextView) findViewById(b4.f8895r);
        editText.setSaveEnabled(false);
        editText.setLongClickable(false);
    }
}
