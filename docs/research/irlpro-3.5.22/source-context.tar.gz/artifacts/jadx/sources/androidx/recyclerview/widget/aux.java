package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.List;
import p101com2.r2;
import p101com2.s2;

/* JADX INFO: loaded from: classes.dex */
public class aux implements com4.aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8645a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final InterfaceC0046aux f2850a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com4 f2851a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public r2<con> f2852a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Runnable f2853a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<con> f2854a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f2855a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList<con> f8646b;

    /* JADX INFO: renamed from: androidx.recyclerview.widget.aux$aux, reason: collision with other inner class name */
    public interface InterfaceC0046aux {
        void a(int i2, int i3);

        void b(int i2, int i3, Object obj);

        void c(con conVar);

        RecyclerView.h d(int i2);

        void e(con conVar);

        void f(int i2, int i3);

        void g(int i2, int i3);

        void h(int i2, int i3);
    }

    public static class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8647a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Object f2856a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8648b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8649c;

        public con(int i2, int i3, int i4, Object obj) {
            this.f8647a = i2;
            this.f8648b = i3;
            this.f8649c = i4;
            this.f2856a = obj;
        }

        public String a() {
            int i2 = this.f8647a;
            if (i2 == 1) {
                return "add";
            }
            if (i2 == 2) {
                return "rm";
            }
            if (i2 != 4) {
                return i2 != 8 ? "??" : "mv";
            }
            return "up";
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            con conVar = (con) obj;
            int i2 = this.f8647a;
            if (i2 != conVar.f8647a) {
                return false;
            }
            if (i2 == 8 && Math.abs(this.f8649c - this.f8648b) == 1 && this.f8649c == conVar.f8648b && this.f8648b == conVar.f8649c) {
                return true;
            }
            if (this.f8649c != conVar.f8649c || this.f8648b != conVar.f8648b) {
                return false;
            }
            Object obj2 = this.f2856a;
            if (obj2 != null) {
                if (!obj2.equals(conVar.f2856a)) {
                    return false;
                }
            } else if (conVar.f2856a != null) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (((this.f8647a * 31) + this.f8648b) * 31) + this.f8649c;
        }

        public String toString() {
            return Integer.toHexString(System.identityHashCode(this)) + "[" + a() + ",s:" + this.f8648b + "c:" + this.f8649c + ",p:" + this.f2856a + "]";
        }
    }

    public aux(InterfaceC0046aux interfaceC0046aux) {
        this(interfaceC0046aux, false);
    }

    @Override // androidx.recyclerview.widget.com4.aux
    public con a(int i2, int i3, int i4, Object obj) {
        con conVarB = this.f2852a.b();
        if (conVarB == null) {
            return new con(i2, i3, i4, obj);
        }
        conVarB.f8647a = i2;
        conVarB.f8648b = i3;
        conVarB.f8649c = i4;
        conVarB.f2856a = obj;
        return conVarB;
    }

    @Override // androidx.recyclerview.widget.com4.aux
    public void b(con conVar) {
        if (this.f2855a) {
            return;
        }
        conVar.f2856a = null;
        this.f2852a.a(conVar);
    }

    public final void c(con conVar) {
        s(conVar);
    }

    public final void d(con conVar) {
        s(conVar);
    }

    public int e(int i2) {
        int size = this.f2854a.size();
        for (int i3 = 0; i3 < size; i3++) {
            con conVar = this.f2854a.get(i3);
            int i4 = conVar.f8647a;
            if (i4 != 1) {
                if (i4 == 2) {
                    int i5 = conVar.f8648b;
                    if (i5 <= i2) {
                        int i6 = conVar.f8649c;
                        if (i5 + i6 > i2) {
                            return -1;
                        }
                        i2 -= i6;
                    } else {
                        continue;
                    }
                } else if (i4 == 8) {
                    int i7 = conVar.f8648b;
                    if (i7 == i2) {
                        i2 = conVar.f8649c;
                    } else {
                        if (i7 < i2) {
                            i2--;
                        }
                        if (conVar.f8649c <= i2) {
                            i2++;
                        }
                    }
                }
            } else if (conVar.f8648b <= i2) {
                i2 += conVar.f8649c;
            }
        }
        return i2;
    }

    public final void f(con conVar) {
        boolean z2;
        byte b2;
        int i2 = conVar.f8648b;
        int i3 = conVar.f8649c + i2;
        byte b3 = -1;
        int i4 = i2;
        int i5 = 0;
        while (i4 < i3) {
            if (this.f2850a.d(i4) != null || h(i4)) {
                if (b3 == 0) {
                    k(a(2, i2, i5, null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                b2 = 1;
            } else {
                if (b3 == 1) {
                    s(a(2, i2, i5, null));
                    z2 = true;
                } else {
                    z2 = false;
                }
                b2 = 0;
            }
            if (z2) {
                i4 -= i5;
                i3 -= i5;
                i5 = 1;
            } else {
                i5++;
            }
            i4++;
            b3 = b2;
        }
        if (i5 != conVar.f8649c) {
            b(conVar);
            conVar = a(2, i2, i5, null);
        }
        if (b3 == 0) {
            k(conVar);
        } else {
            s(conVar);
        }
    }

    public final void g(con conVar) {
        int i2 = conVar.f8648b;
        int i3 = conVar.f8649c + i2;
        int i4 = 0;
        byte b2 = -1;
        int i5 = i2;
        while (i2 < i3) {
            if (this.f2850a.d(i2) != null || h(i2)) {
                if (b2 == 0) {
                    k(a(4, i5, i4, conVar.f2856a));
                    i5 = i2;
                    i4 = 0;
                }
                b2 = 1;
            } else {
                if (b2 == 1) {
                    s(a(4, i5, i4, conVar.f2856a));
                    i5 = i2;
                    i4 = 0;
                }
                b2 = 0;
            }
            i4++;
            i2++;
        }
        if (i4 != conVar.f8649c) {
            Object obj = conVar.f2856a;
            b(conVar);
            conVar = a(4, i5, i4, obj);
        }
        if (b2 == 0) {
            k(conVar);
        } else {
            s(conVar);
        }
    }

    public final boolean h(int i2) {
        int size = this.f8646b.size();
        for (int i3 = 0; i3 < size; i3++) {
            con conVar = this.f8646b.get(i3);
            int i4 = conVar.f8647a;
            if (i4 == 8) {
                if (n(conVar.f8649c, i3 + 1) == i2) {
                    return true;
                }
            } else if (i4 == 1) {
                int i5 = conVar.f8648b;
                int i6 = conVar.f8649c + i5;
                while (i5 < i6) {
                    if (n(i5, i3 + 1) == i2) {
                        return true;
                    }
                    i5++;
                }
            } else {
                continue;
            }
        }
        return false;
    }

    public void i() {
        int size = this.f8646b.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2850a.c(this.f8646b.get(i2));
        }
        u(this.f8646b);
        this.f8645a = 0;
    }

    public void j() {
        i();
        int size = this.f2854a.size();
        for (int i2 = 0; i2 < size; i2++) {
            con conVar = this.f2854a.get(i2);
            int i3 = conVar.f8647a;
            if (i3 == 1) {
                this.f2850a.c(conVar);
                this.f2850a.h(conVar.f8648b, conVar.f8649c);
            } else if (i3 == 2) {
                this.f2850a.c(conVar);
                this.f2850a.a(conVar.f8648b, conVar.f8649c);
            } else if (i3 == 4) {
                this.f2850a.c(conVar);
                this.f2850a.b(conVar.f8648b, conVar.f8649c, conVar.f2856a);
            } else if (i3 == 8) {
                this.f2850a.c(conVar);
                this.f2850a.g(conVar.f8648b, conVar.f8649c);
            }
            Runnable runnable = this.f2853a;
            if (runnable != null) {
                runnable.run();
            }
        }
        u(this.f2854a);
        this.f8645a = 0;
    }

    public final void k(con conVar) {
        int i2;
        int i3 = conVar.f8647a;
        if (i3 == 1 || i3 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int iW = w(conVar.f8648b, i3);
        int i4 = conVar.f8648b;
        int i5 = conVar.f8647a;
        if (i5 == 2) {
            i2 = 0;
        } else {
            if (i5 != 4) {
                throw new IllegalArgumentException("op should be remove or update." + conVar);
            }
            i2 = 1;
        }
        int i6 = 1;
        for (int i7 = 1; i7 < conVar.f8649c; i7++) {
            int iW2 = w(conVar.f8648b + (i2 * i7), conVar.f8647a);
            int i8 = conVar.f8647a;
            if (i8 == 2 ? iW2 == iW : i8 == 4 && iW2 == iW + 1) {
                i6++;
            } else {
                con conVarA = a(i8, iW, i6, conVar.f2856a);
                l(conVarA, i4);
                b(conVarA);
                if (conVar.f8647a == 4) {
                    i4 += i6;
                }
                i6 = 1;
                iW = iW2;
            }
        }
        Object obj = conVar.f2856a;
        b(conVar);
        if (i6 > 0) {
            con conVarA2 = a(conVar.f8647a, iW, i6, obj);
            l(conVarA2, i4);
            b(conVarA2);
        }
    }

    public void l(con conVar, int i2) {
        this.f2850a.e(conVar);
        int i3 = conVar.f8647a;
        if (i3 == 2) {
            this.f2850a.a(i2, conVar.f8649c);
        } else {
            if (i3 != 4) {
                throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
            }
            this.f2850a.b(i2, conVar.f8649c, conVar.f2856a);
        }
    }

    public int m(int i2) {
        return n(i2, 0);
    }

    public int n(int i2, int i3) {
        int size = this.f8646b.size();
        while (i3 < size) {
            con conVar = this.f8646b.get(i3);
            int i4 = conVar.f8647a;
            if (i4 == 8) {
                int i5 = conVar.f8648b;
                if (i5 == i2) {
                    i2 = conVar.f8649c;
                } else {
                    if (i5 < i2) {
                        i2--;
                    }
                    if (conVar.f8649c <= i2) {
                        i2++;
                    }
                }
            } else {
                int i6 = conVar.f8648b;
                if (i6 > i2) {
                    continue;
                } else if (i4 == 2) {
                    int i7 = conVar.f8649c;
                    if (i2 < i6 + i7) {
                        return -1;
                    }
                    i2 -= i7;
                } else if (i4 == 1) {
                    i2 += conVar.f8649c;
                }
            }
            i3++;
        }
        return i2;
    }

    public boolean o(int i2) {
        return (i2 & this.f8645a) != 0;
    }

    public boolean p() {
        return this.f2854a.size() > 0;
    }

    public boolean q() {
        return (this.f8646b.isEmpty() || this.f2854a.isEmpty()) ? false : true;
    }

    public boolean r(int i2, int i3, Object obj) {
        if (i3 < 1) {
            return false;
        }
        this.f2854a.add(a(4, i2, i3, obj));
        this.f8645a |= 4;
        return this.f2854a.size() == 1;
    }

    public final void s(con conVar) {
        this.f8646b.add(conVar);
        int i2 = conVar.f8647a;
        if (i2 == 1) {
            this.f2850a.h(conVar.f8648b, conVar.f8649c);
            return;
        }
        if (i2 == 2) {
            this.f2850a.f(conVar.f8648b, conVar.f8649c);
            return;
        }
        if (i2 == 4) {
            this.f2850a.b(conVar.f8648b, conVar.f8649c, conVar.f2856a);
        } else {
            if (i2 == 8) {
                this.f2850a.g(conVar.f8648b, conVar.f8649c);
                return;
            }
            throw new IllegalArgumentException("Unknown update op type for " + conVar);
        }
    }

    public void t() {
        this.f2851a.b(this.f2854a);
        int size = this.f2854a.size();
        for (int i2 = 0; i2 < size; i2++) {
            con conVar = this.f2854a.get(i2);
            int i3 = conVar.f8647a;
            if (i3 == 1) {
                c(conVar);
            } else if (i3 == 2) {
                f(conVar);
            } else if (i3 == 4) {
                g(conVar);
            } else if (i3 == 8) {
                d(conVar);
            }
            Runnable runnable = this.f2853a;
            if (runnable != null) {
                runnable.run();
            }
        }
        this.f2854a.clear();
    }

    public void u(List<con> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            b(list.get(i2));
        }
        list.clear();
    }

    public void v() {
        u(this.f2854a);
        u(this.f8646b);
        this.f8645a = 0;
    }

    public final int w(int i2, int i3) {
        int i4;
        int i5;
        for (int size = this.f8646b.size() - 1; size >= 0; size--) {
            con conVar = this.f8646b.get(size);
            int i6 = conVar.f8647a;
            if (i6 == 8) {
                int i7 = conVar.f8648b;
                int i8 = conVar.f8649c;
                if (i7 < i8) {
                    i5 = i7;
                    i4 = i8;
                } else {
                    i4 = i7;
                    i5 = i8;
                }
                if (i2 < i5 || i2 > i4) {
                    if (i2 < i7) {
                        if (i3 == 1) {
                            conVar.f8648b = i7 + 1;
                            conVar.f8649c = i8 + 1;
                        } else if (i3 == 2) {
                            conVar.f8648b = i7 - 1;
                            conVar.f8649c = i8 - 1;
                        }
                    }
                } else if (i5 == i7) {
                    if (i3 == 1) {
                        conVar.f8649c = i8 + 1;
                    } else if (i3 == 2) {
                        conVar.f8649c = i8 - 1;
                    }
                    i2++;
                } else {
                    if (i3 == 1) {
                        conVar.f8648b = i7 + 1;
                    } else if (i3 == 2) {
                        conVar.f8648b = i7 - 1;
                    }
                    i2--;
                }
            } else {
                int i9 = conVar.f8648b;
                if (i9 <= i2) {
                    if (i6 == 1) {
                        i2 -= conVar.f8649c;
                    } else if (i6 == 2) {
                        i2 += conVar.f8649c;
                    }
                } else if (i3 == 1) {
                    conVar.f8648b = i9 + 1;
                } else if (i3 == 2) {
                    conVar.f8648b = i9 - 1;
                }
            }
        }
        for (int size2 = this.f8646b.size() - 1; size2 >= 0; size2--) {
            con conVar2 = this.f8646b.get(size2);
            if (conVar2.f8647a == 8) {
                int i10 = conVar2.f8649c;
                if (i10 == conVar2.f8648b || i10 < 0) {
                    this.f8646b.remove(size2);
                    b(conVar2);
                }
            } else if (conVar2.f8649c <= 0) {
                this.f8646b.remove(size2);
                b(conVar2);
            }
        }
        return i2;
    }

    public aux(InterfaceC0046aux interfaceC0046aux, boolean z2) {
        this.f2852a = new s2(30);
        this.f2854a = new ArrayList<>();
        this.f8646b = new ArrayList<>();
        this.f8645a = 0;
        this.f2850a = interfaceC0046aux;
        this.f2855a = z2;
        this.f2851a = new com4(this);
    }
}
