package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p017CoM5.u;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(u uVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f2300a = (IconCompat) uVar.v(remoteActionCompat.f2300a, 1);
        remoteActionCompat.f2301a = uVar.l(remoteActionCompat.f2301a, 2);
        remoteActionCompat.f8169b = uVar.l(remoteActionCompat.f8169b, 3);
        remoteActionCompat.f8168a = (PendingIntent) uVar.r(remoteActionCompat.f8168a, 4);
        remoteActionCompat.f2302a = uVar.h(remoteActionCompat.f2302a, 5);
        remoteActionCompat.f2303b = uVar.h(remoteActionCompat.f2303b, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, u uVar) {
        uVar.x(false, false);
        uVar.M(remoteActionCompat.f2300a, 1);
        uVar.D(remoteActionCompat.f2301a, 2);
        uVar.D(remoteActionCompat.f8169b, 3);
        uVar.H(remoteActionCompat.f8168a, 4);
        uVar.z(remoteActionCompat.f2302a, 5);
        uVar.z(remoteActionCompat.f2303b, 6);
    }
}
