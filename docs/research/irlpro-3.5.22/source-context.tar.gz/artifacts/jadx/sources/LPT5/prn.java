package LPT5;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.wmspanel.libstream.lpt5;
import com.wmspanel.streamer.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import p037LPt5.lpt7;
import p037LPt5.lpt9;
import p055Lpt5.i2;
import p055Lpt5.q2;
import p133lpT6.o5;
import p133lpT6.u5;

/* JADX INFO: loaded from: classes.dex */
public abstract class prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public double f6674a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f876a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f877a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public i2 f878a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f879a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt5 f882a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Timer f886a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f888b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f6676c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<nul> f884a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final List<LPT5.aux> f889b = new ArrayList();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<Integer, com7> f885a = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt5.com3 f881a = new lpt5.com3(30, 30);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public double f6675b = 30.0d;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Map<Integer, Connection> f890b = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f887a = false;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f891b = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f883a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f880a = new Handler(Looper.getMainLooper());

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            prn prnVar = prn.this;
            if (prnVar.f882a == null || prnVar.f890b.size() == 0) {
                return;
            }
            Iterator<Map.Entry<Integer, Connection>> it = prn.this.f890b.entrySet().iterator();
            long j2 = 0;
            long j3 = 0;
            while (it.hasNext()) {
                Integer key = it.next().getKey();
                com7 com7Var = prn.this.f885a.get(key);
                if (com7Var != null) {
                    lpt9 tcpStats = prn.this.f882a.getTcpStats(key.intValue());
                    if (tcpStats != null) {
                        j2 += tcpStats.audioFramesSkipped;
                        j3 += tcpStats.videoFramesSkipped;
                    }
                    lpt7 srtStats = prn.this.f882a.getSrtStats(key.intValue());
                    if (srtStats != null) {
                        j3 += (long) srtStats.pktSndDrop;
                        com7Var.d(srtStats, prn.this.i());
                    }
                    p037LPt5.lpt5 ristStats = prn.this.f882a.getRistStats(key.intValue());
                    if (ristStats != null && ristStats.sent > 100) {
                        double d2 = ristStats.quality;
                        if (d2 < 90.0d) {
                            j3 = (long) (j3 + (90.0d - d2));
                        }
                    }
                }
            }
            prn.this.g(j2, j3);
        }
    }

    public class con extends TimerTask {
        public con() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            prn.this.f880a.post(prn.this.f883a);
        }
    }

    public prn(Context context) {
        this.f879a = context;
    }

    public static prn r(Context context, int i2, i2 i2Var) {
        prn com5Var;
        switch (u5.a(context)) {
            case 1:
                com5Var = new com5(context);
                break;
            case 2:
                com5Var = new com4(context);
                break;
            case 3:
                com5Var = new com1(context);
                break;
            case 4:
                com5Var = new com2(context);
                break;
            case 5:
                com5Var = new com6(context);
                break;
            case 6:
                com5Var = new com3(context);
                break;
            default:
                Iterator<Connection> it = u5.d().iterator();
                if (it.hasNext()) {
                    Connection next = it.next();
                    com5Var = (q2.isSrt(Uri.parse(next.url).getScheme()) || next.g()) ? new com2(context) : new com5(context);
                } else {
                    com5Var = null;
                }
                if (com5Var == null) {
                    com5Var = new com6(context);
                }
                break;
        }
        com5Var.f876a = i2;
        com5Var.w(i2Var);
        return com5Var;
    }

    public void A() {
        d();
        int i2 = this.f6676c;
        if (i2 > 0) {
            B(i2);
        }
        this.f888b = 0;
        this.f882a = null;
        this.f890b.clear();
        this.f885a.clear();
    }

    public void B(long j2) {
        i2 i2Var = this.f878a;
        if (i2Var == null || i2Var.fpsRanges.size() == 0) {
            return;
        }
        double d2 = (j2 * 1.0d) / ((double) this.f6676c);
        double dMax = this.f6675b;
        if (d2 < 0.5d) {
            dMax = Math.max(15.0d, Math.floor(((dMax * d2) * 2.0d) / 5.0d) * 5.0d);
        }
        if (Math.abs(dMax - this.f6674a) < 1.0d) {
            return;
        }
        this.f6674a = dMax;
        lpt5.com3 com3VarFindNearestFpsRange = this.f878a.findNearestFpsRange(Math.round(dMax), false);
        if (com3VarFindNearestFpsRange == null) {
            com3VarFindNearestFpsRange = new lpt5.com3(0, 0);
        }
        int i2 = com3VarFindNearestFpsRange.fpsMax;
        lpt5.com3 com3Var = this.f881a;
        if (i2 == com3Var.fpsMax && com3VarFindNearestFpsRange.fpsMin == com3Var.fpsMin) {
            return;
        }
        this.f882a.changeFpsRange(com3VarFindNearestFpsRange);
        this.f881a = com3VarFindNearestFpsRange;
    }

    public void c(int i2, Connection connection) {
        this.f885a.put(Integer.valueOf(i2), new com7(5));
        this.f890b.put(Integer.valueOf(i2), connection);
    }

    public final void d() {
        Timer timer = this.f886a;
        if (timer != null) {
            timer.cancel();
            this.f886a = null;
        }
        this.f880a.removeCallbacksAndMessages(null);
    }

    public void e(long j2) {
        if (this.f882a == null) {
            return;
        }
        this.f889b.add(new LPT5.aux(System.currentTimeMillis(), j2));
        if (u5.b(this.f879a)) {
            B(j2);
        }
        int i2 = (int) j2;
        this.f882a.changeBitRate(i2);
        this.f888b = i2;
    }

    public void f(long j2) {
        this.f882a.changeBitRate((int) j2);
    }

    public abstract void g(long j2, long j3);

    public long h() {
        return 1000L;
    }

    public long i() {
        return 500L;
    }

    public abstract String j();

    public String k() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<Integer, Connection> entry : this.f890b.entrySet()) {
            Integer key = entry.getKey();
            Connection value = entry.getValue();
            sb.append("Connection ");
            sb.append(value.name);
            sb.append("\n");
            lpt9 tcpStats = this.f882a.getTcpStats(key.intValue());
            if (tcpStats != null) {
                sb.append(" - TCP\n");
                sb.append(" - bytesSent: ");
                sb.append(tcpStats.bytesSent);
                sb.append("\n");
                sb.append(" - audioFramesSent: ");
                sb.append(tcpStats.audioFramesSent);
                sb.append("\n");
                sb.append(" - audioFramesSkipped: ");
                sb.append(tcpStats.audioFramesSkipped);
                sb.append("\n");
                sb.append(" - videoFramesSent: ");
                sb.append(tcpStats.videoFramesSent);
                sb.append("\n");
                sb.append(" - videoFramesSkipped: ");
                sb.append(tcpStats.videoFramesSkipped);
                sb.append("\n");
            }
            lpt7 srtStats = this.f882a.getSrtStats(key.intValue());
            if (srtStats != null) {
                sb.append(" - SRT\n");
                sb.append(" - msRTT: ");
                sb.append(srtStats.msRTT);
                sb.append(" ms\n");
                sb.append(" - sendRate: ");
                sb.append(Math.round(srtStats.mbpsSendRate * 1000.0d));
                sb.append(" kbps\n");
                sb.append(" - byteSent: ");
                sb.append(srtStats.byteSent);
                sb.append(" bytes\n");
                sb.append(" - byteRetrans: ");
                sb.append(srtStats.byteRetrans);
                sb.append(" bytes\n");
                sb.append(" - byteSentUnique: ");
                sb.append(srtStats.byteSentUnique);
                sb.append(" bytes\n");
                sb.append(" - byteSndDrop: ");
                sb.append(srtStats.byteSndDrop);
                sb.append(" bytes\n");
                sb.append(" - Estimated Max BW: ");
                sb.append(Math.round(srtStats.mbpsBandwidth * 1000.0d));
                sb.append(" kbps\n");
                sb.append(" - BW Limit: ");
                sb.append(Math.round(srtStats.mbpsMaxBW * 1000.0d));
                sb.append(" kbps\n");
                sb.append(" - In flight packets: ");
                sb.append(srtStats.pktFlightSize);
                sb.append(" pkts\n");
                sb.append(" - UnACKed packets: ");
                sb.append(srtStats.pktSndBuf);
                sb.append(" pkts\n");
                com7 com7Var = this.f885a.get(key);
                if (com7Var != null) {
                    sb.append(" - history required: ");
                    sb.append(Math.round((com7Var.c() / 1000.0d) * 8.0d));
                    sb.append(" kbps\n");
                    sb.append(" - history real: ");
                    sb.append(Math.round((com7Var.b() / 1000.0d) * 8.0d));
                    sb.append(" kbps\n");
                }
            }
            p037LPt5.lpt5 ristStats = this.f882a.getRistStats(key.intValue());
            if (ristStats != null) {
                sb.append(" - RIST\n");
                sb.append(" - bandwidth: ");
                sb.append(ristStats.bandwidth);
                sb.append(" \n");
                sb.append(" - sent: ");
                sb.append(ristStats.sent);
                sb.append(" pkts\n");
                sb.append(" - retransmitted: ");
                sb.append(ristStats.retransmitted);
                sb.append(" pkts\n");
                sb.append(" - quality: ");
                sb.append(ristStats.quality);
                sb.append("\n");
                sb.append(" - rtt: ");
                sb.append(ristStats.rtt);
                sb.append("\n");
            }
            sb.append("--\n\n");
        }
        return sb.toString();
    }

    public void l(Map<String, Object> map) {
        Iterator<Map.Entry<Integer, Connection>> it = this.f890b.entrySet().iterator();
        int i2 = 0;
        while (it.hasNext()) {
            Integer key = it.next().getKey();
            lpt9 tcpStats = this.f882a.getTcpStats(key.intValue());
            if (tcpStats != null) {
                map.put("conn" + i2 + "_TCP_bytesSent", Long.valueOf(tcpStats.bytesSent));
                map.put("conn" + i2 + "_TCP_audioFramesSent", Long.valueOf(tcpStats.audioFramesSent));
                map.put("conn" + i2 + "_TCP_audioFramesSkipped", Long.valueOf(tcpStats.audioFramesSkipped));
                map.put("conn" + i2 + "_TCP_videoFramesSent", Long.valueOf(tcpStats.videoFramesSent));
                map.put("conn" + i2 + "_TCP_videoFramesSkipped", Long.valueOf(tcpStats.videoFramesSkipped));
            }
            lpt7 srtStats = this.f882a.getSrtStats(key.intValue());
            if (srtStats != null) {
                map.put("conn" + i2 + "_SRT_msRTT", Double.valueOf(srtStats.msRTT));
                map.put("conn" + i2 + "_SRT_sendRate", Long.valueOf(Math.round(srtStats.mbpsSendRate * 1000.0d)));
                map.put("conn" + i2 + "_SRT_byteSent", Long.valueOf(srtStats.byteSent));
                map.put("conn" + i2 + "_SRT_byteRetrans", Long.valueOf(srtStats.byteRetrans));
                map.put("conn" + i2 + "_SRT_byteSentUnique", Long.valueOf(srtStats.byteSentUnique));
                map.put("conn" + i2 + "_SRT_byteSndDrop", Long.valueOf(srtStats.byteSndDrop));
                map.put("conn" + i2 + "_SRT_estBW", Long.valueOf(Math.round(srtStats.mbpsBandwidth * 1000.0d)));
                map.put("conn" + i2 + "_SRT_estBWLimit", Long.valueOf(Math.round(srtStats.mbpsMaxBW * 1000.0d)));
                map.put("conn" + i2 + "_SRT_pktFlightSize", Integer.valueOf(srtStats.pktFlightSize));
                map.put("conn" + i2 + "_SRT_pktSndBuf", Integer.valueOf(srtStats.pktSndBuf));
            }
            p037LPt5.lpt5 ristStats = this.f882a.getRistStats(key.intValue());
            if (ristStats != null) {
                map.put("conn" + i2 + "_RIST_bandwidth", Integer.valueOf(ristStats.bandwidth));
                map.put("conn" + i2 + "_RIST_sent", Long.valueOf(ristStats.sent));
                map.put("conn" + i2 + "_RIST_retransmitted", Long.valueOf(ristStats.retransmitted));
                map.put("conn" + i2 + "_RIST_quality", Double.valueOf(ristStats.quality));
                map.put("conn" + i2 + "_RIST_rtt", Integer.valueOf(ristStats.rtt));
            }
            i2++;
        }
    }

    public long m(long j2) {
        nul nulVar = (nul) LPT5.con.c(this.f884a);
        for (int size = this.f884a.size() - 1; size >= 0; size--) {
            if (this.f884a.get(size).f6671a < j2) {
                nul nulVar2 = this.f884a.get(size);
                return (nulVar.f6673c - nulVar2.f6673c) + (nulVar.f6672b - nulVar2.f6672b);
            }
        }
        return 0L;
    }

    public double n() {
        return (((double) this.f888b) * 1.0d) / ((double) this.f6676c);
    }

    public int o() {
        return this.f888b / 1000;
    }

    public int p() {
        return this.f6676c / 1000;
    }

    public int q() {
        return this.f876a / 1000;
    }

    public void s() {
        Log.i("StreamConditioner", "Pausing to flip camera");
        d();
        this.f877a = System.currentTimeMillis();
    }

    public void t(int i2) {
        this.f890b.remove(Integer.valueOf(i2));
        this.f885a.remove(Integer.valueOf(i2));
    }

    public void u() {
        if (this.f888b == 0) {
            return;
        }
        lpt5.com3 com3VarC = o5.c(this.f879a);
        if (com3VarC != null) {
            this.f6675b = ((double) com3VarC.fpsMax) * 1.0d;
            this.f881a = com3VarC;
        } else {
            this.f6675b = 30.0d;
            this.f881a = new lpt5.com3(30, 30);
        }
        this.f6674a = this.f6675b;
        v();
        e(this.f888b);
    }

    public final void v() {
        if (h() == 0 || i() == 0) {
            return;
        }
        d();
        Timer timer = new Timer();
        this.f886a = timer;
        timer.schedule(new con(), h(), i());
    }

    public void w(i2 i2Var) {
        if (i2Var != null) {
            this.f878a = i2Var;
        }
    }

    public void x(int i2) {
        s();
        this.f6676c = i2;
        u();
    }

    public void y(lpt5 lpt5Var) {
        z(lpt5Var, this.f876a);
    }

    public void z(lpt5 lpt5Var, int i2) {
        this.f882a = lpt5Var;
        long jCurrentTimeMillis = System.currentTimeMillis();
        this.f884a.clear();
        this.f884a.add(new nul(jCurrentTimeMillis, 0L, 0L));
        this.f889b.clear();
        this.f889b.add(new LPT5.aux(jCurrentTimeMillis, i2));
        this.f6676c = this.f876a;
        this.f888b = i2;
        lpt5.com3 com3VarC = o5.c(this.f879a);
        if (com3VarC != null) {
            this.f6675b = ((double) com3VarC.fpsMax) * 1.0d;
        }
        this.f6674a = this.f6675b;
        v();
    }
}
