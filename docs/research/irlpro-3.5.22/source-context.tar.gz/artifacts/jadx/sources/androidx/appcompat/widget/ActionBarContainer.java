package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.preference.Preference;
import p001AuX.com8;
import p001AuX.lpt3;
import p022CoN.com9;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7846a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1930a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1931a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Drawable f7847b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f1932b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1933b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Drawable f7848c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public View f1934c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1935c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f7849d;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        y.s0(this, new com9(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt3.f13a);
        this.f1930a = typedArrayObtainStyledAttributes.getDrawable(lpt3.f5627a);
        this.f7847b = typedArrayObtainStyledAttributes.getDrawable(lpt3.f5631c);
        this.f7846a = typedArrayObtainStyledAttributes.getDimensionPixelSize(lpt3.f5643i, -1);
        boolean z2 = true;
        if (getId() == com8.G) {
            this.f1935c = true;
            this.f7848c = typedArrayObtainStyledAttributes.getDrawable(lpt3.f5629b);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f1935c ? this.f1930a != null || this.f7847b != null : this.f7848c != null) {
            z2 = false;
        }
        setWillNotDraw(z2);
    }

    public final int a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    public final boolean b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f1930a;
        if (drawable != null && drawable.isStateful()) {
            this.f1930a.setState(getDrawableState());
        }
        Drawable drawable2 = this.f7847b;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f7847b.setState(getDrawableState());
        }
        Drawable drawable3 = this.f7848c;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f7848c.setState(getDrawableState());
    }

    public View getTabContainer() {
        return this.f1931a;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1930a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f7847b;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f7848c;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f1932b = findViewById(com8.f5565a);
        this.f1934c = findViewById(com8.f5570f);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f1933b || super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0048 A[PHI: r0
      0x0048: PHI (r0v8 boolean) = (r0v1 boolean), (r0v1 boolean), (r0v0 boolean) binds: [B:31:0x00a5, B:33:0x00a9, B:15:0x0039] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        Drawable drawable;
        super.onLayout(z2, i2, i3, i4, i5);
        View view = this.f1931a;
        boolean z3 = true;
        boolean z4 = false;
        boolean z5 = (view == null || view.getVisibility() == 8) ? false : true;
        if (view != null && view.getVisibility() != 8) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
            int measuredHeight2 = measuredHeight - view.getMeasuredHeight();
            int i6 = layoutParams.bottomMargin;
            view.layout(i2, measuredHeight2 - i6, i4, measuredHeight - i6);
        }
        if (this.f1935c) {
            Drawable drawable2 = this.f7848c;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z3 = z4;
            }
        } else {
            if (this.f1930a != null) {
                if (this.f1932b.getVisibility() == 0) {
                    this.f1930a.setBounds(this.f1932b.getLeft(), this.f1932b.getTop(), this.f1932b.getRight(), this.f1932b.getBottom());
                } else {
                    View view2 = this.f1934c;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.f1930a.setBounds(0, 0, 0, 0);
                    } else {
                        this.f1930a.setBounds(this.f1934c.getLeft(), this.f1934c.getTop(), this.f1934c.getRight(), this.f1934c.getBottom());
                    }
                }
                z4 = true;
            }
            this.f7849d = z5;
            if (!z5 || (drawable = this.f7847b) == null) {
                z3 = z4;
            } else {
                drawable.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
        }
        if (z3) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        int iA;
        int i4;
        if (this.f1932b == null && View.MeasureSpec.getMode(i3) == Integer.MIN_VALUE && (i4 = this.f7846a) >= 0) {
            i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i4, View.MeasureSpec.getSize(i3)), Integer.MIN_VALUE);
        }
        super.onMeasure(i2, i3);
        if (this.f1932b == null) {
            return;
        }
        int mode = View.MeasureSpec.getMode(i3);
        View view = this.f1931a;
        if (view == null || view.getVisibility() == 8 || mode == 1073741824) {
            return;
        }
        if (b(this.f1932b)) {
            iA = !b(this.f1934c) ? a(this.f1934c) : 0;
        } else {
            iA = a(this.f1932b);
        }
        setMeasuredDimension(getMeasuredWidth(), Math.min(iA + a(this.f1931a), mode == Integer.MIN_VALUE ? View.MeasureSpec.getSize(i3) : Preference.DEFAULT_ORDER));
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f1930a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f1930a);
        }
        this.f1930a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f1932b;
            if (view != null) {
                this.f1930a.setBounds(view.getLeft(), this.f1932b.getTop(), this.f1932b.getRight(), this.f1932b.getBottom());
            }
        }
        boolean z2 = true;
        if (!this.f1935c ? this.f1930a != null || this.f7847b != null : this.f7848c != null) {
            z2 = false;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f7848c;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f7848c);
        }
        this.f7848c = drawable;
        boolean z2 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f1935c && (drawable2 = this.f7848c) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f1935c ? !(this.f1930a != null || this.f7847b != null) : this.f7848c == null) {
            z2 = true;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f7847b;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f7847b);
        }
        this.f7847b = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f7849d && (drawable2 = this.f7847b) != null) {
                drawable2.setBounds(this.f1931a.getLeft(), this.f1931a.getTop(), this.f1931a.getRight(), this.f1931a.getBottom());
            }
        }
        boolean z2 = true;
        if (!this.f1935c ? this.f1930a != null || this.f7847b != null : this.f7848c != null) {
            z2 = false;
        }
        setWillNotDraw(z2);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(nul nulVar) {
        View view = this.f1931a;
        if (view != null) {
            removeView(view);
        }
        this.f1931a = nulVar;
        if (nulVar != null) {
            addView(nulVar);
            ViewGroup.LayoutParams layoutParams = nulVar.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            nulVar.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z2) {
        this.f1933b = z2;
        setDescendantFocusability(z2 ? 393216 : inet.ipaddr.format.validate.aux.KEY_STANDARD_STR);
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        boolean z2 = i2 == 0;
        Drawable drawable = this.f1930a;
        if (drawable != null) {
            drawable.setVisible(z2, false);
        }
        Drawable drawable2 = this.f7847b;
        if (drawable2 != null) {
            drawable2.setVisible(z2, false);
        }
        Drawable drawable3 = this.f7848c;
        if (drawable3 != null) {
            drawable3.setVisible(z2, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i2) {
        if (i2 != 0) {
            return super.startActionModeForChild(view, callback, i2);
        }
        return null;
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f1930a && !this.f1935c) || (drawable == this.f7847b && this.f7849d) || ((drawable == this.f7848c && this.f1935c) || super.verifyDrawable(drawable));
    }
}
