package LPT1;

import java.lang.reflect.Type;

/* JADX INFO: loaded from: classes.dex */
public interface com2<T> {
    T createInstance(Type type);
}
