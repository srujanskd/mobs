package com.google.android.material.tabs;

import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
public class aux {
    public static RectF a(TabLayout tabLayout, View view) {
        if (view == null) {
            return new RectF();
        }
        return (tabLayout.A() || !(view instanceof TabLayout.com5)) ? new RectF(view.getLeft(), view.getTop(), view.getRight(), view.getBottom()) : b((TabLayout.com5) view, 24);
    }

    public static RectF b(TabLayout.com5 com5Var, int i2) {
        int contentWidth = com5Var.getContentWidth();
        int contentHeight = com5Var.getContentHeight();
        int iB = (int) v.b(com5Var.getContext(), i2);
        if (contentWidth < iB) {
            contentWidth = iB;
        }
        int left = (com5Var.getLeft() + com5Var.getRight()) / 2;
        int top = (com5Var.getTop() + com5Var.getBottom()) / 2;
        int i3 = contentWidth / 2;
        return new RectF(left - i3, top - (contentHeight / 2), i3 + left, top + (left / 2));
    }

    public void c(TabLayout tabLayout, View view, Drawable drawable) {
        RectF rectFA = a(tabLayout, view);
        drawable.setBounds((int) rectFA.left, drawable.getBounds().top, (int) rectFA.right, drawable.getBounds().bottom);
    }

    public void d(TabLayout tabLayout, View view, View view2, float f2, Drawable drawable) {
        RectF rectFA = a(tabLayout, view);
        RectF rectFA2 = a(tabLayout, view2);
        drawable.setBounds(COM6.aux.c((int) rectFA.left, (int) rectFA2.left, f2), drawable.getBounds().top, COM6.aux.c((int) rectFA.right, (int) rectFA2.right, f2), drawable.getBounds().bottom);
    }
}
