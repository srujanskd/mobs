package LPT1;

/* JADX INFO: loaded from: classes.dex */
public final class com7 extends lpt1 {
    public com7(String str) {
        super(str);
    }

    public com7(String str, Throwable th) {
        super(str, th);
    }

    public com7(Throwable th) {
        super(th);
    }
}
