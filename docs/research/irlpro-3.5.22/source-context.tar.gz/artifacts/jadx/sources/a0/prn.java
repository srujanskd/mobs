package a0;

import d0.lpt1;
import f.com8;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import p059Lpt9.a;
import v.c;
import v.i;
import v.lpt5;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
public final class prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7629a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com1 f1601a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com3 f1602a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com6.con f1603a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com6 f1604a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final v.aux f1605a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public i f1606a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt5 f1607a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7630b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7631c;

    public prn(com3 com3Var, v.aux auxVar, com1 com1Var, lpt5 lpt5Var) {
        com8.e(com3Var, "connectionPool");
        com8.e(auxVar, "address");
        com8.e(com1Var, "call");
        com8.e(lpt5Var, "eventListener");
        this.f1602a = com3Var;
        this.f1605a = auxVar;
        this.f1601a = com1Var;
        this.f1607a = lpt5Var;
    }

    public final b0.prn a(c cVar, b0.com3 com3Var) {
        com8.e(cVar, "client");
        com8.e(com3Var, "chain");
        try {
            return c(com3Var.f(), com3Var.h(), com3Var.j(), cVar.u(), cVar.A(), !com8.a(com3Var.i().g(), "GET")).w(cVar, com3Var);
        } catch (com5 e2) {
            h(e2.d());
            throw e2;
        } catch (IOException e3) {
            h(e3);
            throw new com5(e3);
        }
    }

    /* JADX WARN: Code duplicated, block: B:59:0x0137  */
    /* JADX WARN: Code duplicated, block: B:61:0x0151  */
    /* JADX WARN: Code duplicated, block: B:78:0x0152 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    public final com2 b(int i2, int i3, int i4, int i5, boolean z2) throws IOException {
        List<i> listA;
        com2 com2Var;
        Socket socketU;
        if (this.f1601a.isCanceled()) {
            throw new IOException("Canceled");
        }
        com2 com2VarK = this.f1601a.k();
        if (com2VarK != null) {
            synchronized (com2VarK) {
                socketU = (com2VarK.p() || !g(com2VarK.z().a().l())) ? this.f1601a.u() : null;
                a aVar = a.f7353a;
            }
            if (this.f1601a.k() != null) {
                if (socketU == null) {
                    return com2VarK;
                }
                throw new IllegalStateException("Check failed.".toString());
            }
            if (socketU != null) {
                w.com1.n(socketU);
            }
            this.f1607a.k(this.f1601a, com2VarK);
        }
        this.f7629a = 0;
        this.f7630b = 0;
        this.f7631c = 0;
        if (this.f1602a.a(this.f1605a, this.f1601a, null, false)) {
            com2 com2VarK2 = this.f1601a.k();
            com8.b(com2VarK2);
            this.f1607a.j(this.f1601a, com2VarK2);
            return com2VarK2;
        }
        i iVarC = this.f1606a;
        try {
            if (iVarC == null) {
                com6.con conVar = this.f1603a;
                if (conVar != null) {
                    com8.b(conVar);
                    if (conVar.b()) {
                        com6.con conVar2 = this.f1603a;
                        com8.b(conVar2);
                        iVarC = conVar2.c();
                    }
                    com2Var = new com2(this.f1602a, iVarC);
                    this.f1601a.w(com2Var);
                    com2Var.f(i2, i3, i4, i5, z2, this.f1601a, this.f1607a);
                    this.f1601a.w(null);
                    this.f1601a.j().p().a(com2Var.z());
                    if (this.f1602a.a(this.f1605a, this.f1601a, listA, true)) {
                        com2 com2VarK3 = this.f1601a.k();
                        com8.b(com2VarK3);
                        this.f1606a = iVarC;
                        w.com1.n(com2Var.D());
                        this.f1607a.j(this.f1601a, com2VarK3);
                        return com2VarK3;
                    }
                    synchronized (com2Var) {
                        this.f1602a.e(com2Var);
                        this.f1601a.c(com2Var);
                        a aVar2 = a.f7353a;
                    }
                    this.f1607a.j(this.f1601a, com2Var);
                    return com2Var;
                }
                com6 com6Var = this.f1604a;
                if (com6Var == null) {
                    com6Var = new com6(this.f1605a, this.f1601a.j().p(), this.f1601a, this.f1607a);
                    this.f1604a = com6Var;
                }
                com6.con conVarC = com6Var.c();
                this.f1603a = conVarC;
                listA = conVarC.a();
                if (this.f1601a.isCanceled()) {
                    throw new IOException("Canceled");
                }
                if (this.f1602a.a(this.f1605a, this.f1601a, listA, false)) {
                    com2 com2VarK4 = this.f1601a.k();
                    com8.b(com2VarK4);
                    this.f1607a.j(this.f1601a, com2VarK4);
                    return com2VarK4;
                }
                iVarC = conVarC.c();
                com2Var = new com2(this.f1602a, iVarC);
                this.f1601a.w(com2Var);
                com2Var.f(i2, i3, i4, i5, z2, this.f1601a, this.f1607a);
                this.f1601a.w(null);
                this.f1601a.j().p().a(com2Var.z());
                if (this.f1602a.a(this.f1605a, this.f1601a, listA, true)) {
                    com2 com2VarK5 = this.f1601a.k();
                    com8.b(com2VarK5);
                    this.f1606a = iVarC;
                    w.com1.n(com2Var.D());
                    this.f1607a.j(this.f1601a, com2VarK5);
                    return com2VarK5;
                }
                synchronized (com2Var) {
                    this.f1602a.e(com2Var);
                    this.f1601a.c(com2Var);
                    a aVar3 = a.f7353a;
                    this.f1607a.j(this.f1601a, com2Var);
                    return com2Var;
                }
            }
            com8.b(iVarC);
            this.f1606a = null;
            com2Var.f(i2, i3, i4, i5, z2, this.f1601a, this.f1607a);
            this.f1601a.w(null);
            this.f1601a.j().p().a(com2Var.z());
            if (this.f1602a.a(this.f1605a, this.f1601a, listA, true)) {
                com2 com2VarK6 = this.f1601a.k();
                com8.b(com2VarK6);
                this.f1606a = iVarC;
                w.com1.n(com2Var.D());
                this.f1607a.j(this.f1601a, com2VarK6);
                return com2VarK6;
            }
            synchronized (com2Var) {
                this.f1602a.e(com2Var);
                this.f1601a.c(com2Var);
                a aVar4 = a.f7353a;
                this.f1607a.j(this.f1601a, com2Var);
                return com2Var;
            }
        } catch (Throwable th) {
            this.f1601a.w(null);
            throw th;
        }
        listA = null;
        com2Var = new com2(this.f1602a, iVarC);
        this.f1601a.w(com2Var);
    }

    public final com2 c(int i2, int i3, int i4, int i5, boolean z2, boolean z3) throws IOException {
        while (true) {
            com2 com2VarB = b(i2, i3, i4, i5, z2);
            if (com2VarB.u(z3)) {
                return com2VarB;
            }
            com2VarB.y();
            if (this.f1606a == null) {
                com6.con conVar = this.f1603a;
                if (conVar == null ? true : conVar.b()) {
                    continue;
                } else {
                    com6 com6Var = this.f1604a;
                    if (!(com6Var != null ? com6Var.a() : true)) {
                        throw new IOException("exhausted all routes");
                    }
                }
            }
        }
    }

    public final v.aux d() {
        return this.f1605a;
    }

    public final boolean e() {
        com6 com6Var;
        boolean z2 = false;
        if (this.f7629a == 0 && this.f7630b == 0 && this.f7631c == 0) {
            return false;
        }
        if (this.f1606a != null) {
            return true;
        }
        i iVarF = f();
        if (iVarF != null) {
            this.f1606a = iVarF;
            return true;
        }
        com6.con conVar = this.f1603a;
        if (conVar != null && conVar.b()) {
            z2 = true;
        }
        if (z2 || (com6Var = this.f1604a) == null) {
            return true;
        }
        return com6Var.a();
    }

    public final i f() {
        com2 com2VarK;
        if (this.f7629a > 1 || this.f7630b > 1 || this.f7631c > 0 || (com2VarK = this.f1601a.k()) == null) {
            return null;
        }
        synchronized (com2VarK) {
            if (com2VarK.q() != 0) {
                return null;
            }
            if (w.com1.j(com2VarK.z().a().l(), d().l())) {
                return com2VarK.z();
            }
            return null;
        }
    }

    public final boolean g(lpt9 lpt9Var) {
        com8.e(lpt9Var, "url");
        lpt9 lpt9VarL = this.f1605a.l();
        return lpt9Var.m() == lpt9VarL.m() && com8.a(lpt9Var.h(), lpt9VarL.h());
    }

    public final void h(IOException iOException) {
        com8.e(iOException, "e");
        this.f1606a = null;
        if ((iOException instanceof lpt1) && ((lpt1) iOException).f10675a == d0.con.REFUSED_STREAM) {
            this.f7629a++;
        } else if (iOException instanceof d0.aux) {
            this.f7630b++;
        } else {
            this.f7631c++;
        }
    }
}
