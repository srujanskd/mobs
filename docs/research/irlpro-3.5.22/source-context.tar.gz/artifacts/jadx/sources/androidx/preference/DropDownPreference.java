package androidx.preference;

import android.R;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import androidx.recyclerview.widget.RecyclerView;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt2;

/* JADX INFO: loaded from: classes.dex */
public class DropDownPreference extends ListPreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f8423a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AdapterView.OnItemSelectedListener f2629a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayAdapter f2630a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Spinner f2631a;

    public class aux implements AdapterView.OnItemSelectedListener {
        public aux() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
            if (i2 >= 0) {
                String string = DropDownPreference.this.d()[i2].toString();
                if (string.equals(DropDownPreference.this.e()) || !DropDownPreference.this.callChangeListener(string)) {
                    return;
                }
                DropDownPreference.this.l(string);
            }
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public DropDownPreference(Context context) {
        this(context, null);
    }

    @Override // androidx.preference.ListPreference
    public void h(CharSequence[] charSequenceArr) {
        super.h(charSequenceArr);
        p();
    }

    @Override // androidx.preference.ListPreference
    public void m(int i2) {
        l(d()[i2].toString());
    }

    public ArrayAdapter n() {
        return new ArrayAdapter(this.f8423a, R.layout.simple_spinner_dropdown_item);
    }

    @Override // androidx.preference.Preference
    public void notifyChanged() {
        super.notifyChanged();
        ArrayAdapter arrayAdapter = this.f2630a;
        if (arrayAdapter != null) {
            arrayAdapter.notifyDataSetChanged();
        }
    }

    public final int o(String str) {
        CharSequence[] charSequenceArrD = d();
        if (str == null || charSequenceArrD == null) {
            return -1;
        }
        for (int length = charSequenceArrD.length - 1; length >= 0; length--) {
            if (TextUtils.equals(charSequenceArrD[length].toString(), str)) {
                return length;
            }
        }
        return -1;
    }

    @Override // androidx.preference.Preference
    public void onBindViewHolder(com7 com7Var) {
        Spinner spinner = (Spinner) ((RecyclerView.h) com7Var).f2786a.findViewById(lpt2.f6189h);
        this.f2631a = spinner;
        spinner.setAdapter((SpinnerAdapter) this.f2630a);
        this.f2631a.setOnItemSelectedListener(this.f2629a);
        this.f2631a.setSelection(o(e()));
        super.onBindViewHolder(com7Var);
    }

    @Override // androidx.preference.DialogPreference, androidx.preference.Preference
    public void onClick() {
        this.f2631a.performClick();
    }

    public final void p() {
        this.f2630a.clear();
        if (b() != null) {
            for (CharSequence charSequence : b()) {
                this.f2630a.add(charSequence.toString());
            }
        }
    }

    public DropDownPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com8.f6169c);
    }

    public DropDownPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public DropDownPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f2629a = new aux();
        this.f8423a = context;
        this.f2630a = n();
        p();
    }
}
