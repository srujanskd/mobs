package androidx.activity;

import COM3.com7;
import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.nul;
import androidx.lifecycle.prn;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
final class ImmLeaksCleaner implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int f7726a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static Field f1711a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static Field f7727b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Field f7728c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Activity f1712a;

    public static void h() {
        try {
            f7726a = 2;
            Field declaredField = InputMethodManager.class.getDeclaredField("mServedView");
            f7727b = declaredField;
            declaredField.setAccessible(true);
            Field declaredField2 = InputMethodManager.class.getDeclaredField("mNextServedView");
            f7728c = declaredField2;
            declaredField2.setAccessible(true);
            Field declaredField3 = InputMethodManager.class.getDeclaredField("mH");
            f1711a = declaredField3;
            declaredField3.setAccessible(true);
            f7726a = 1;
        } catch (NoSuchFieldException unused) {
        }
    }

    @Override // androidx.lifecycle.prn
    public void f(com7 com7Var, nul.con conVar) {
        if (conVar != nul.con.ON_DESTROY) {
            return;
        }
        if (f7726a == 0) {
            h();
        }
        if (f7726a == 1) {
            InputMethodManager inputMethodManager = (InputMethodManager) this.f1712a.getSystemService("input_method");
            try {
                Object obj = f1711a.get(inputMethodManager);
                if (obj == null) {
                    return;
                }
                synchronized (obj) {
                    try {
                        try {
                            View view = (View) f7727b.get(inputMethodManager);
                            if (view == null) {
                                return;
                            }
                            if (view.isAttachedToWindow()) {
                                return;
                            }
                            try {
                                f7728c.set(inputMethodManager, null);
                                inputMethodManager.isActive();
                            } catch (IllegalAccessException unused) {
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                    } catch (ClassCastException unused2) {
                    } catch (IllegalAccessException unused3) {
                    }
                }
            } catch (IllegalAccessException unused4) {
            }
        }
    }
}
