package androidx.viewpager.widget;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import com.newrelic.agent.android.analytics.AnalyticsAttribute;
import com.newrelic.agent.android.analytics.EventManagerImpl;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import p024Com2.lpt3;
import p024Com2.s;
import p024Com2.t0;
import p024Com2.y;
import p081cOm2.e2;

/* JADX INFO: loaded from: classes.dex */
public class ViewPager extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f2930a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2931a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM5.aux f2932a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f2933a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2934a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Parcelable f2935a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public VelocityTracker f2936a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public EdgeEffect f2937a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Scroller f2938a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com2 f2939a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com6 f2940a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com7 f2941a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ClassLoader f2942a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2943a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<com2> f2944a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<com6> f2945a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f8746b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f2946b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public EdgeEffect f2947b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public com6 f2948b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ArrayList<View> f2949b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public List<com5> f2950b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2951b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f8747c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f2952c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2953c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f8748d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public int f2954d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2955d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f8749e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public int f2956e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2957e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f8750f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public int f2958f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f2959f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8751g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f2960g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8752h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f2961h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8753i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f2962i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8754j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f2963j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8755k;

    /* JADX INFO: renamed from: k, reason: collision with other field name */
    public boolean f2964k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f8756l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f8757m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f8758n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f8759o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f8760p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f8761q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f8762r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f8763s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f8764t;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f2929a = {R.attr.layout_gravity};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final Comparator<com2> f2928a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Interpolator f8745a = new con();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final com9 f2927a = new com9();

    public static class aux implements Comparator<com2> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(com2 com2Var, com2 com2Var2) {
            return com2Var.f2965a - com2Var2.f2965a;
        }
    }

    @Target({ElementType.TYPE})
    @Inherited
    @Retention(RetentionPolicy.RUNTIME)
    public @interface com1 {
    }

    public static class com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f8765a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2965a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Object f2966a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2967a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f8766b;
    }

    public class com4 extends lpt3 {
        public com4() {
        }

        @Override // p024Com2.lpt3
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            COM5.aux auxVar;
            super.f(view, accessibilityEvent);
            accessibilityEvent.setClassName(ViewPager.class.getName());
            accessibilityEvent.setScrollable(n());
            if (accessibilityEvent.getEventType() != 4096 || (auxVar = ViewPager.this.f2932a) == null) {
                return;
            }
            accessibilityEvent.setItemCount(auxVar.c());
            accessibilityEvent.setFromIndex(ViewPager.this.f2946b);
            accessibilityEvent.setToIndex(ViewPager.this.f2946b);
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.T(ViewPager.class.getName());
            e2Var.p0(n());
            if (ViewPager.this.canScrollHorizontally(1)) {
                e2Var.a(AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                e2Var.a(8192);
            }
        }

        @Override // p024Com2.lpt3
        public boolean j(View view, int i2, Bundle bundle) {
            if (super.j(view, i2, bundle)) {
                return true;
            }
            if (i2 == 4096) {
                if (!ViewPager.this.canScrollHorizontally(1)) {
                    return false;
                }
                ViewPager viewPager = ViewPager.this;
                viewPager.setCurrentItem(viewPager.f2946b + 1);
                return true;
            }
            if (i2 != 8192 || !ViewPager.this.canScrollHorizontally(-1)) {
                return false;
            }
            ViewPager viewPager2 = ViewPager.this;
            viewPager2.setCurrentItem(viewPager2.f2946b - 1);
            return true;
        }

        public final boolean n() {
            COM5.aux auxVar = ViewPager.this.f2932a;
            return auxVar != null && auxVar.c() > 1;
        }
    }

    public interface com5 {
        void a(ViewPager viewPager, COM5.aux auxVar, COM5.aux auxVar2);
    }

    public interface com6 {
        void a(int i2, float f2, int i3);

        void b(int i2);

        void c(int i2);
    }

    public class com7 extends DataSetObserver {
        public com7() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            ViewPager.this.h();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            ViewPager.this.h();
        }
    }

    public static class com8 extends COM2.aux {
        public static final Parcelable.Creator<com8> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8772a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ClassLoader f2971a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public Parcelable f8773b;

        public static class aux implements Parcelable.ClassLoaderCreator<com8> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com8 createFromParcel(Parcel parcel) {
                return new com8(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com8 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com8(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com8[] newArray(int i2) {
                return new com8[i2];
            }
        }

        public com8(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.f8772a + "}";
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f8772a);
            parcel.writeParcelable(this.f8773b, i2);
        }

        public com8(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? getClass().getClassLoader() : classLoader;
            this.f8772a = parcel.readInt();
            this.f8773b = parcel.readParcelable(classLoader);
            this.f2971a = classLoader;
        }
    }

    public static class com9 implements Comparator<View> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(View view, View view2) {
            com3 com3Var = (com3) view.getLayoutParams();
            com3 com3Var2 = (com3) view2.getLayoutParams();
            boolean z2 = com3Var.f2969a;
            if (z2 != com3Var2.f2969a) {
                return z2 ? 1 : -1;
            }
            return com3Var.f8768b - com3Var2.f8768b;
        }
    }

    public static class con implements Interpolator {
        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            float f3 = f2 - 1.0f;
            return (f3 * f3 * f3 * f3 * f3) + 1.0f;
        }
    }

    public class nul implements Runnable {
        public nul() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ViewPager.this.setScrollState(0);
            ViewPager.this.D();
        }
    }

    public class prn implements s {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Rect f8775a = new Rect();

        public prn() {
        }

        @Override // p024Com2.s
        public t0 a(View view, t0 t0Var) {
            t0 t0VarA0 = y.a0(view, t0Var);
            if (t0VarA0.o()) {
                return t0VarA0;
            }
            Rect rect = this.f8775a;
            rect.left = t0VarA0.j();
            rect.top = t0VarA0.l();
            rect.right = t0VarA0.k();
            rect.bottom = t0VarA0.i();
            int childCount = ViewPager.this.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                t0 t0VarG = y.g(ViewPager.this.getChildAt(i2), t0VarA0);
                rect.left = Math.min(t0VarG.j(), rect.left);
                rect.top = Math.min(t0VarG.l(), rect.top);
                rect.right = Math.min(t0VarG.k(), rect.right);
                rect.bottom = Math.min(t0VarG.i(), rect.bottom);
            }
            return t0VarA0.p(rect.left, rect.top, rect.right, rect.bottom);
        }
    }

    public ViewPager(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2944a = new ArrayList<>();
        this.f2939a = new com2();
        this.f2933a = new Rect();
        this.f2952c = -1;
        this.f2935a = null;
        this.f2942a = null;
        this.f2930a = -3.4028235E38f;
        this.f8746b = Float.MAX_VALUE;
        this.f8753i = 1;
        this.f8757m = -1;
        this.f2962i = true;
        this.f2963j = false;
        this.f2943a = new nul();
        this.f8764t = 0;
        u();
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private void setScrollingCacheEnabled(boolean z2) {
        if (this.f2955d != z2) {
            this.f2955d = z2;
        }
    }

    public static boolean v(View view) {
        return view.getClass().getAnnotation(com1.class) != null;
    }

    public boolean A() {
        COM5.aux auxVar = this.f2932a;
        if (auxVar == null || this.f2946b >= auxVar.c() - 1) {
            return false;
        }
        M(this.f2946b + 1, true);
        return true;
    }

    public final boolean B(int i2) {
        if (this.f2944a.size() == 0) {
            if (this.f2962i) {
                return false;
            }
            this.f2964k = false;
            x(0, 0.0f, 0);
            if (this.f2964k) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        com2 com2VarS = s();
        int clientWidth = getClientWidth();
        int i3 = this.f2954d;
        int i4 = clientWidth + i3;
        float f2 = clientWidth;
        int i5 = com2VarS.f2965a;
        float f3 = ((i2 / f2) - com2VarS.f8766b) / (com2VarS.f8765a + (i3 / f2));
        this.f2964k = false;
        x(i5, f3, (int) (i4 * f3));
        if (this.f2964k) {
            return true;
        }
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    }

    public final boolean C(float f2) {
        boolean z2;
        boolean z3;
        float f3 = this.f8747c - f2;
        this.f8747c = f2;
        float scrollX = getScrollX() + f3;
        float clientWidth = getClientWidth();
        float f4 = this.f2930a * clientWidth;
        float f5 = this.f8746b * clientWidth;
        boolean z4 = false;
        com2 com2Var = this.f2944a.get(0);
        ArrayList<com2> arrayList = this.f2944a;
        com2 com2Var2 = arrayList.get(arrayList.size() - 1);
        if (com2Var.f2965a != 0) {
            f4 = com2Var.f8766b * clientWidth;
            z2 = false;
        } else {
            z2 = true;
        }
        if (com2Var2.f2965a != this.f2932a.c() - 1) {
            f5 = com2Var2.f8766b * clientWidth;
            z3 = false;
        } else {
            z3 = true;
        }
        if (scrollX < f4) {
            if (z2) {
                this.f2937a.onPull(Math.abs(f4 - scrollX) / clientWidth);
                z4 = true;
            }
            scrollX = f4;
        } else if (scrollX > f5) {
            if (z3) {
                this.f2947b.onPull(Math.abs(scrollX - f5) / clientWidth);
                z4 = true;
            }
            scrollX = f5;
        }
        int i2 = (int) scrollX;
        this.f8747c += scrollX - i2;
        scrollTo(i2, getScrollY());
        B(i2);
        return z4;
    }

    public void D() {
        E(this.f2946b);
    }

    /* JADX WARN: Code duplicated, block: B:64:0x00f7 A[PHI: r7 r10 r15
      0x00f7: PHI (r7v6 int) = (r7v5 int), (r7v4 int), (r7v9 int) binds: [B:62:0x00ec, B:59:0x00d6, B:53:0x00c0] A[DONT_GENERATE, DONT_INLINE]
      0x00f7: PHI (r10v9 int) = (r10v1 int), (r10v8 int), (r10v12 int) binds: [B:62:0x00ec, B:59:0x00d6, B:53:0x00c0] A[DONT_GENERATE, DONT_INLINE]
      0x00f7: PHI (r15v7 float) = (r15v5 float), (r15v6 float), (r15v4 float) binds: [B:62:0x00ec, B:59:0x00d6, B:53:0x00c0] A[DONT_GENERATE, DONT_INLINE]] */
    public void E(int i2) {
        com2 com2VarT;
        String hexString;
        com2 com2VarA;
        com2 com2VarR;
        com2 com2Var;
        int i3 = this.f2946b;
        if (i3 != i2) {
            com2VarT = t(i3);
            this.f2946b = i2;
        } else {
            com2VarT = null;
        }
        if (this.f2932a == null) {
            Q();
            return;
        }
        if (this.f2957e) {
            Q();
            return;
        }
        if (getWindowToken() == null) {
            return;
        }
        this.f2932a.o(this);
        int i4 = this.f8753i;
        int iMax = Math.max(0, this.f2946b - i4);
        int iC = this.f2932a.c();
        int iMin = Math.min(iC - 1, this.f2946b + i4);
        if (iC != this.f2931a) {
            try {
                hexString = getResources().getResourceName(getId());
            } catch (Resources.NotFoundException unused) {
                hexString = Integer.toHexString(getId());
            }
            throw new IllegalStateException("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: " + this.f2931a + ", found: " + iC + " Pager id: " + hexString + " Pager class: " + getClass() + " Problematic adapter: " + this.f2932a.getClass());
        }
        int i5 = 0;
        while (true) {
            if (i5 < this.f2944a.size()) {
                com2VarA = this.f2944a.get(i5);
                int i6 = com2VarA.f2965a;
                int i7 = this.f2946b;
                if (i6 >= i7) {
                    if (i6 != i7) {
                        break;
                    } else {
                        break;
                    }
                }
                i5++;
            }
            com2VarA = null;
            break;
        }
        if (com2VarA == null && iC > 0) {
            com2VarA = a(this.f2946b, i5);
        }
        if (com2VarA != null) {
            int i8 = i5 - 1;
            com2 com2Var2 = i8 >= 0 ? this.f2944a.get(i8) : null;
            int clientWidth = getClientWidth();
            float paddingLeft = clientWidth <= 0 ? 0.0f : (2.0f - com2VarA.f8765a) + (getPaddingLeft() / clientWidth);
            float f2 = 0.0f;
            for (int i9 = this.f2946b - 1; i9 >= 0; i9--) {
                if (f2 < paddingLeft || i9 >= iMax) {
                    if (com2Var2 == null || i9 != com2Var2.f2965a) {
                        f2 += a(i9, i8 + 1).f8765a;
                        i5++;
                        if (i8 >= 0) {
                            com2Var = this.f2944a.get(i8);
                        } else {
                            com2Var = null;
                        }
                    } else {
                        f2 += com2Var2.f8765a;
                        i8--;
                        if (i8 >= 0) {
                            com2Var = this.f2944a.get(i8);
                        } else {
                            com2Var = null;
                        }
                    }
                    com2Var2 = com2Var;
                } else {
                    if (com2Var2 == null) {
                        break;
                    }
                    if (i9 == com2Var2.f2965a && !com2Var2.f2967a) {
                        this.f2944a.remove(i8);
                        this.f2932a.a(this, i9, com2Var2.f2966a);
                        i8--;
                        i5--;
                        if (i8 >= 0) {
                            com2Var = this.f2944a.get(i8);
                        } else {
                            com2Var = null;
                        }
                        com2Var2 = com2Var;
                    }
                }
            }
            float f3 = com2VarA.f8765a;
            int i10 = i5 + 1;
            if (f3 < 2.0f) {
                com2 com2Var3 = i10 < this.f2944a.size() ? this.f2944a.get(i10) : null;
                float paddingRight = clientWidth <= 0 ? 0.0f : (getPaddingRight() / clientWidth) + 2.0f;
                int i11 = this.f2946b;
                while (true) {
                    i11++;
                    if (i11 >= iC) {
                        break;
                    }
                    if (f3 >= paddingRight && i11 > iMin) {
                        if (com2Var3 == null) {
                            break;
                        }
                        if (i11 == com2Var3.f2965a && !com2Var3.f2967a) {
                            this.f2944a.remove(i10);
                            this.f2932a.a(this, i11, com2Var3.f2966a);
                            if (i10 < this.f2944a.size()) {
                                com2Var3 = this.f2944a.get(i10);
                            }
                        }
                    } else if (com2Var3 == null || i11 != com2Var3.f2965a) {
                        com2 com2VarA2 = a(i11, i10);
                        i10++;
                        f3 += com2VarA2.f8765a;
                        com2Var3 = i10 < this.f2944a.size() ? this.f2944a.get(i10) : null;
                    } else {
                        f3 += com2Var3.f8765a;
                        i10++;
                        if (i10 < this.f2944a.size()) {
                            com2Var3 = this.f2944a.get(i10);
                        }
                    }
                }
            }
            e(com2VarA, i5, com2VarT);
            this.f2932a.m(this, this.f2946b, com2VarA.f2966a);
        }
        this.f2932a.b(this);
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            com3 com3Var = (com3) childAt.getLayoutParams();
            com3Var.f8769c = i12;
            if (!com3Var.f2969a && com3Var.f8767a == 0.0f && (com2VarR = r(childAt)) != null) {
                com3Var.f8767a = com2VarR.f8765a;
                com3Var.f8768b = com2VarR.f2965a;
            }
        }
        Q();
        if (hasFocus()) {
            View viewFindFocus = findFocus();
            com2 com2VarQ = viewFindFocus != null ? q(viewFindFocus) : null;
            if (com2VarQ == null || com2VarQ.f2965a != this.f2946b) {
                for (int i13 = 0; i13 < getChildCount(); i13++) {
                    View childAt2 = getChildAt(i13);
                    com2 com2VarR2 = r(childAt2);
                    if (com2VarR2 != null && com2VarR2.f2965a == this.f2946b && childAt2.requestFocus(2)) {
                        return;
                    }
                }
            }
        }
    }

    public final void F(int i2, int i3, int i4, int i5) {
        if (i3 > 0 && !this.f2944a.isEmpty()) {
            if (!this.f2938a.isFinished()) {
                this.f2938a.setFinalX(getCurrentItem() * getClientWidth());
                return;
            } else {
                scrollTo((int) ((getScrollX() / (((i3 - getPaddingLeft()) - getPaddingRight()) + i5)) * (((i2 - getPaddingLeft()) - getPaddingRight()) + i4)), getScrollY());
                return;
            }
        }
        com2 com2VarT = t(this.f2946b);
        int iMin = (int) ((com2VarT != null ? Math.min(com2VarT.f8766b, this.f8746b) : 0.0f) * ((i2 - getPaddingLeft()) - getPaddingRight()));
        if (iMin != getScrollX()) {
            g(false);
            scrollTo(iMin, getScrollY());
        }
    }

    public final void G() {
        int i2 = 0;
        while (i2 < getChildCount()) {
            if (!((com3) getChildAt(i2).getLayoutParams()).f2969a) {
                removeViewAt(i2);
                i2--;
            }
            i2++;
        }
    }

    public void H(com5 com5Var) {
        List<com5> list = this.f2950b;
        if (list != null) {
            list.remove(com5Var);
        }
    }

    public void I(com6 com6Var) {
        List<com6> list = this.f2945a;
        if (list != null) {
            list.remove(com6Var);
        }
    }

    public final void J(boolean z2) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z2);
        }
    }

    public final boolean K() {
        this.f8757m = -1;
        n();
        this.f2937a.onRelease();
        this.f2947b.onRelease();
        return this.f2937a.isFinished() || this.f2947b.isFinished();
    }

    public final void L(int i2, boolean z2, int i3, boolean z3) {
        com2 com2VarT = t(i2);
        int clientWidth = com2VarT != null ? (int) (getClientWidth() * Math.max(this.f2930a, Math.min(com2VarT.f8766b, this.f8746b))) : 0;
        if (z2) {
            P(clientWidth, 0, i3);
            if (z3) {
                k(i2);
                return;
            }
            return;
        }
        if (z3) {
            k(i2);
        }
        g(false);
        scrollTo(clientWidth, 0);
        B(clientWidth);
    }

    public void M(int i2, boolean z2) {
        this.f2957e = false;
        N(i2, z2, false);
    }

    public void N(int i2, boolean z2, boolean z3) {
        O(i2, z2, z3, 0);
    }

    public void O(int i2, boolean z2, boolean z3, int i3) {
        COM5.aux auxVar = this.f2932a;
        if (auxVar == null || auxVar.c() <= 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (!z3 && this.f2946b == i2 && this.f2944a.size() != 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        if (i2 < 0) {
            i2 = 0;
        } else if (i2 >= this.f2932a.c()) {
            i2 = this.f2932a.c() - 1;
        }
        int i4 = this.f8753i;
        int i5 = this.f2946b;
        if (i2 > i5 + i4 || i2 < i5 - i4) {
            for (int i6 = 0; i6 < this.f2944a.size(); i6++) {
                this.f2944a.get(i6).f2967a = true;
            }
        }
        boolean z4 = this.f2946b != i2;
        if (!this.f2962i) {
            E(i2);
            L(i2, z2, i3, z4);
        } else {
            this.f2946b = i2;
            if (z4) {
                k(i2);
            }
            requestLayout();
        }
    }

    public void P(int i2, int i3, int i4) {
        int scrollX;
        int iAbs;
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        Scroller scroller = this.f2938a;
        if ((scroller == null || scroller.isFinished()) ? false : true) {
            scrollX = this.f2951b ? this.f2938a.getCurrX() : this.f2938a.getStartX();
            this.f2938a.abortAnimation();
            setScrollingCacheEnabled(false);
        } else {
            scrollX = getScrollX();
        }
        int i5 = scrollX;
        int scrollY = getScrollY();
        int i6 = i2 - i5;
        int i7 = i3 - scrollY;
        if (i6 == 0 && i7 == 0) {
            g(false);
            D();
            setScrollState(0);
            return;
        }
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int clientWidth = getClientWidth();
        int i8 = clientWidth / 2;
        float f2 = clientWidth;
        float f3 = i8;
        float fM = f3 + (m(Math.min(1.0f, (Math.abs(i6) * 1.0f) / f2)) * f3);
        int iAbs2 = Math.abs(i4);
        if (iAbs2 > 0) {
            iAbs = Math.round(Math.abs(fM / iAbs2) * 1000.0f) * 4;
        } else {
            iAbs = (int) (((Math.abs(i6) / ((f2 * this.f2932a.f(this.f2946b)) + this.f2954d)) + 1.0f) * 100.0f);
        }
        int iMin = Math.min(iAbs, EventManagerImpl.DEFAULT_MAX_EVENT_BUFFER_TIME);
        this.f2951b = false;
        this.f2938a.startScroll(i5, scrollY, i6, i7, iMin);
        y.f0(this);
    }

    public final void Q() {
        if (this.f8763s != 0) {
            ArrayList<View> arrayList = this.f2949b;
            if (arrayList == null) {
                this.f2949b = new ArrayList<>();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                this.f2949b.add(getChildAt(i2));
            }
            Collections.sort(this.f2949b, f2927a);
        }
    }

    public com2 a(int i2, int i3) {
        com2 com2Var = new com2();
        com2Var.f2965a = i2;
        com2Var.f2966a = this.f2932a.g(this, i2);
        com2Var.f8765a = this.f2932a.f(i2);
        if (i3 < 0 || i3 >= this.f2944a.size()) {
            this.f2944a.add(com2Var);
        } else {
            this.f2944a.add(i3, com2Var);
        }
        return com2Var;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        com2 com2VarR;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i4 = 0; i4 < getChildCount(); i4++) {
                View childAt = getChildAt(i4);
                if (childAt.getVisibility() == 0 && (com2VarR = r(childAt)) != null && com2VarR.f2965a == this.f2946b) {
                    childAt.addFocusables(arrayList, i2, i3);
                }
            }
        }
        if ((descendantFocusability != 262144 || size == arrayList.size()) && isFocusable()) {
            if ((i3 & 1) == 1 && isInTouchMode() && !isFocusableInTouchMode()) {
                return;
            }
            arrayList.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addTouchables(ArrayList<View> arrayList) {
        com2 com2VarR;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (com2VarR = r(childAt)) != null && com2VarR.f2965a == this.f2946b) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        com3 com3Var = (com3) layoutParams;
        boolean zV = com3Var.f2969a | v(view);
        com3Var.f2969a = zV;
        if (!this.f2953c) {
            super.addView(view, i2, layoutParams);
        } else {
            if (zV) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            com3Var.f2970b = true;
            addViewInLayout(view, i2, layoutParams);
        }
    }

    public void b(com5 com5Var) {
        if (this.f2950b == null) {
            this.f2950b = new ArrayList();
        }
        this.f2950b.add(com5Var);
    }

    public void c(com6 com6Var) {
        if (this.f2945a == null) {
            this.f2945a = new ArrayList();
        }
        this.f2945a.add(com6Var);
    }

    @Override // android.view.View
    public boolean canScrollHorizontally(int i2) {
        if (this.f2932a == null) {
            return false;
        }
        int clientWidth = getClientWidth();
        int scrollX = getScrollX();
        if (i2 < 0) {
            return scrollX > ((int) (((float) clientWidth) * this.f2930a));
        }
        return i2 > 0 && scrollX < ((int) (((float) clientWidth) * this.f8746b));
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof com3) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void computeScroll() {
        this.f2951b = true;
        if (this.f2938a.isFinished() || !this.f2938a.computeScrollOffset()) {
            g(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.f2938a.getCurrX();
        int currY = this.f2938a.getCurrY();
        if (scrollX != currX || scrollY != currY) {
            scrollTo(currX, currY);
            if (!B(currX)) {
                this.f2938a.abortAnimation();
                scrollTo(0, currY);
            }
        }
        y.f0(this);
    }

    public boolean d(int i2) {
        boolean z2;
        boolean zRequestFocus;
        View viewFindFocus = findFocus();
        boolean z3 = false;
        if (viewFindFocus == this) {
            viewFindFocus = null;
        } else if (viewFindFocus != null) {
            ViewParent parent = viewFindFocus.getParent();
            while (true) {
                if (!(parent instanceof ViewGroup)) {
                    z2 = false;
                    break;
                }
                if (parent == this) {
                    z2 = true;
                    break;
                }
                parent = parent.getParent();
            }
            if (!z2) {
                StringBuilder sb = new StringBuilder();
                sb.append(viewFindFocus.getClass().getSimpleName());
                for (ViewParent parent2 = viewFindFocus.getParent(); parent2 instanceof ViewGroup; parent2 = parent2.getParent()) {
                    sb.append(" => ");
                    sb.append(parent2.getClass().getSimpleName());
                }
                Log.e("ViewPager", "arrowScroll tried to find focus based on non-child current focused view " + sb.toString());
                viewFindFocus = null;
            }
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i2);
        if (viewFindNextFocus != null && viewFindNextFocus != viewFindFocus) {
            if (i2 == 17) {
                zRequestFocus = (viewFindFocus == null || p(this.f2933a, viewFindNextFocus).left < p(this.f2933a, viewFindFocus).left) ? viewFindNextFocus.requestFocus() : z();
            } else if (i2 == 66) {
                zRequestFocus = (viewFindFocus == null || p(this.f2933a, viewFindNextFocus).left > p(this.f2933a, viewFindFocus).left) ? viewFindNextFocus.requestFocus() : A();
            }
            z3 = zRequestFocus;
        } else if (i2 == 17 || i2 == 1) {
            z3 = z();
        } else if (i2 == 66 || i2 == 2) {
            z3 = A();
        }
        if (z3) {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(i2));
        }
        return z3;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || o(keyEvent);
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        com2 com2VarR;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (childAt.getVisibility() == 0 && (com2VarR = r(childAt)) != null && com2VarR.f2965a == this.f2946b && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        COM5.aux auxVar;
        super.draw(canvas);
        int overScrollMode = getOverScrollMode();
        boolean zDraw = false;
        if (overScrollMode == 0 || (overScrollMode == 1 && (auxVar = this.f2932a) != null && auxVar.c() > 1)) {
            if (!this.f2937a.isFinished()) {
                int iSave = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((-height) + getPaddingTop(), this.f2930a * width);
                this.f2937a.setSize(height, width);
                zDraw = false | this.f2937a.draw(canvas);
                canvas.restoreToCount(iSave);
            }
            if (!this.f2947b.isFinished()) {
                int iSave2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate(-getPaddingTop(), (-(this.f8746b + 1.0f)) * width2);
                this.f2947b.setSize(height2, width2);
                zDraw |= this.f2947b.draw(canvas);
                canvas.restoreToCount(iSave2);
            }
        } else {
            this.f2937a.finish();
            this.f2947b.finish();
        }
        if (zDraw) {
            y.f0(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f2934a;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        drawable.setState(getDrawableState());
    }

    public final void e(com2 com2Var, int i2, com2 com2Var2) {
        int i3;
        int i4;
        com2 com2Var3;
        com2 com2Var4;
        int iC = this.f2932a.c();
        int clientWidth = getClientWidth();
        float f2 = clientWidth > 0 ? this.f2954d / clientWidth : 0.0f;
        if (com2Var2 != null) {
            int i5 = com2Var2.f2965a;
            int i6 = com2Var.f2965a;
            if (i5 < i6) {
                float f3 = com2Var2.f8766b + com2Var2.f8765a + f2;
                int i7 = i5 + 1;
                int i8 = 0;
                while (i7 <= com2Var.f2965a && i8 < this.f2944a.size()) {
                    com2 com2Var5 = this.f2944a.get(i8);
                    while (true) {
                        com2Var4 = com2Var5;
                        if (i7 <= com2Var4.f2965a || i8 >= this.f2944a.size() - 1) {
                            break;
                        }
                        i8++;
                        com2Var5 = this.f2944a.get(i8);
                    }
                    while (i7 < com2Var4.f2965a) {
                        f3 += this.f2932a.f(i7) + f2;
                        i7++;
                    }
                    com2Var4.f8766b = f3;
                    f3 += com2Var4.f8765a + f2;
                    i7++;
                }
            } else if (i5 > i6) {
                int size = this.f2944a.size() - 1;
                float f4 = com2Var2.f8766b;
                while (true) {
                    i5--;
                    if (i5 < com2Var.f2965a || size < 0) {
                        break;
                    }
                    com2 com2Var6 = this.f2944a.get(size);
                    while (true) {
                        com2Var3 = com2Var6;
                        if (i5 >= com2Var3.f2965a || size <= 0) {
                            break;
                        }
                        size--;
                        com2Var6 = this.f2944a.get(size);
                    }
                    while (i5 > com2Var3.f2965a) {
                        f4 -= this.f2932a.f(i5) + f2;
                        i5--;
                    }
                    f4 -= com2Var3.f8765a + f2;
                    com2Var3.f8766b = f4;
                }
            }
        }
        int size2 = this.f2944a.size();
        float f5 = com2Var.f8766b;
        int i9 = com2Var.f2965a;
        int i10 = i9 - 1;
        this.f2930a = i9 == 0 ? f5 : -3.4028235E38f;
        int i11 = iC - 1;
        this.f8746b = i9 == i11 ? (com2Var.f8765a + f5) - 1.0f : Float.MAX_VALUE;
        int i12 = i2 - 1;
        while (i12 >= 0) {
            com2 com2Var7 = this.f2944a.get(i12);
            while (true) {
                i4 = com2Var7.f2965a;
                if (i10 <= i4) {
                    break;
                }
                f5 -= this.f2932a.f(i10) + f2;
                i10--;
            }
            f5 -= com2Var7.f8765a + f2;
            com2Var7.f8766b = f5;
            if (i4 == 0) {
                this.f2930a = f5;
            }
            i12--;
            i10--;
        }
        float f6 = com2Var.f8766b + com2Var.f8765a + f2;
        int i13 = com2Var.f2965a + 1;
        int i14 = i2 + 1;
        while (i14 < size2) {
            com2 com2Var8 = this.f2944a.get(i14);
            while (true) {
                i3 = com2Var8.f2965a;
                if (i13 >= i3) {
                    break;
                }
                f6 += this.f2932a.f(i13) + f2;
                i13++;
            }
            if (i3 == i11) {
                this.f8746b = (com2Var8.f8765a + f6) - 1.0f;
            }
            com2Var8.f8766b = f6;
            f6 += com2Var8.f8765a + f2;
            i14++;
            i13++;
        }
        this.f2963j = false;
    }

    public boolean f(View view, boolean z2, int i2, int i3, int i4) {
        int i5;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i6 = i3 + scrollX;
                if (i6 >= childAt.getLeft() && i6 < childAt.getRight() && (i5 = i4 + scrollY) >= childAt.getTop() && i5 < childAt.getBottom() && f(childAt, true, i2, i6 - childAt.getLeft(), i5 - childAt.getTop())) {
                    return true;
                }
            }
        }
        return z2 && view.canScrollHorizontally(-i2);
    }

    public final void g(boolean z2) {
        boolean z3 = this.f8764t == 2;
        if (z3) {
            setScrollingCacheEnabled(false);
            if (!this.f2938a.isFinished()) {
                this.f2938a.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.f2938a.getCurrX();
                int currY = this.f2938a.getCurrY();
                if (scrollX != currX || scrollY != currY) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        B(currX);
                    }
                }
            }
        }
        this.f2957e = false;
        for (int i2 = 0; i2 < this.f2944a.size(); i2++) {
            com2 com2Var = this.f2944a.get(i2);
            if (com2Var.f2967a) {
                com2Var.f2967a = false;
                z3 = true;
            }
        }
        if (z3) {
            if (z2) {
                y.g0(this, this.f2943a);
            } else {
                this.f2943a.run();
            }
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new com3();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public COM5.aux getAdapter() {
        return this.f2932a;
    }

    @Override // android.view.ViewGroup
    public int getChildDrawingOrder(int i2, int i3) {
        if (this.f8763s == 2) {
            i3 = (i2 - 1) - i3;
        }
        return ((com3) this.f2949b.get(i3).getLayoutParams()).f8769c;
    }

    public int getCurrentItem() {
        return this.f2946b;
    }

    public int getOffscreenPageLimit() {
        return this.f8753i;
    }

    public int getPageMargin() {
        return this.f2954d;
    }

    public void h() {
        int iC = this.f2932a.c();
        this.f2931a = iC;
        boolean z2 = this.f2944a.size() < (this.f8753i * 2) + 1 && this.f2944a.size() < iC;
        int iMax = this.f2946b;
        int i2 = 0;
        boolean z3 = false;
        while (i2 < this.f2944a.size()) {
            com2 com2Var = this.f2944a.get(i2);
            int iD = this.f2932a.d(com2Var.f2966a);
            if (iD != -1) {
                if (iD == -2) {
                    this.f2944a.remove(i2);
                    i2--;
                    if (!z3) {
                        this.f2932a.o(this);
                        z3 = true;
                    }
                    this.f2932a.a(this, com2Var.f2965a, com2Var.f2966a);
                    int i3 = this.f2946b;
                    if (i3 == com2Var.f2965a) {
                        iMax = Math.max(0, Math.min(i3, iC - 1));
                    }
                } else {
                    int i4 = com2Var.f2965a;
                    if (i4 != iD) {
                        if (i4 == this.f2946b) {
                            iMax = iD;
                        }
                        com2Var.f2965a = iD;
                    }
                }
                z2 = true;
            }
            i2++;
        }
        if (z3) {
            this.f2932a.b(this);
        }
        Collections.sort(this.f2944a, f2928a);
        if (z2) {
            int childCount = getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                com3 com3Var = (com3) getChildAt(i5).getLayoutParams();
                if (!com3Var.f2969a) {
                    com3Var.f8767a = 0.0f;
                }
            }
            N(iMax, false, true);
            requestLayout();
        }
    }

    public final int i(int i2, float f2, int i3, int i4) {
        if (Math.abs(i4) <= this.f8760p || Math.abs(i3) <= this.f8758n) {
            i2 += (int) (f2 + (i2 >= this.f2946b ? 0.4f : 0.6f));
        } else if (i3 <= 0) {
            i2++;
        }
        if (this.f2944a.size() <= 0) {
            return i2;
        }
        com2 com2Var = this.f2944a.get(0);
        ArrayList<com2> arrayList = this.f2944a;
        return Math.max(com2Var.f2965a, Math.min(i2, arrayList.get(arrayList.size() - 1).f2965a));
    }

    public final void j(int i2, float f2, int i3) {
        com6 com6Var = this.f2940a;
        if (com6Var != null) {
            com6Var.a(i2, f2, i3);
        }
        List<com6> list = this.f2945a;
        if (list != null) {
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                com6 com6Var2 = this.f2945a.get(i4);
                if (com6Var2 != null) {
                    com6Var2.a(i2, f2, i3);
                }
            }
        }
        com6 com6Var3 = this.f2948b;
        if (com6Var3 != null) {
            com6Var3.a(i2, f2, i3);
        }
    }

    public final void k(int i2) {
        com6 com6Var = this.f2940a;
        if (com6Var != null) {
            com6Var.c(i2);
        }
        List<com6> list = this.f2945a;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                com6 com6Var2 = this.f2945a.get(i3);
                if (com6Var2 != null) {
                    com6Var2.c(i2);
                }
            }
        }
        com6 com6Var3 = this.f2948b;
        if (com6Var3 != null) {
            com6Var3.c(i2);
        }
    }

    public final void l(int i2) {
        com6 com6Var = this.f2940a;
        if (com6Var != null) {
            com6Var.b(i2);
        }
        List<com6> list = this.f2945a;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                com6 com6Var2 = this.f2945a.get(i3);
                if (com6Var2 != null) {
                    com6Var2.b(i2);
                }
            }
        }
        com6 com6Var3 = this.f2948b;
        if (com6Var3 != null) {
            com6Var3.b(i2);
        }
    }

    public float m(float f2) {
        return (float) Math.sin((f2 - 0.5f) * 0.47123894f);
    }

    public final void n() {
        this.f2959f = false;
        this.f2960g = false;
        VelocityTracker velocityTracker = this.f2936a;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f2936a = null;
        }
    }

    public boolean o(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode == 21) {
                return keyEvent.hasModifiers(2) ? z() : d(17);
            }
            if (keyCode == 22) {
                return keyEvent.hasModifiers(2) ? A() : d(66);
            }
            if (keyCode == 61) {
                if (keyEvent.hasNoModifiers()) {
                    return d(2);
                }
                if (keyEvent.hasModifiers(1)) {
                    return d(1);
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2962i = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        removeCallbacks(this.f2943a);
        Scroller scroller = this.f2938a;
        if (scroller != null && !scroller.isFinished()) {
            this.f2938a.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        int i2;
        float f2;
        super.onDraw(canvas);
        if (this.f2954d <= 0 || this.f2934a == null || this.f2944a.size() <= 0 || this.f2932a == null) {
            return;
        }
        int scrollX = getScrollX();
        int width = getWidth();
        float f3 = width;
        float f4 = this.f2954d / f3;
        int i3 = 0;
        com2 com2Var = this.f2944a.get(0);
        float f5 = com2Var.f8766b;
        int size = this.f2944a.size();
        int i4 = com2Var.f2965a;
        int i5 = this.f2944a.get(size - 1).f2965a;
        while (i4 < i5) {
            while (true) {
                i2 = com2Var.f2965a;
                if (i4 <= i2 || i3 >= size) {
                    break;
                }
                i3++;
                com2Var = this.f2944a.get(i3);
            }
            if (i4 == i2) {
                float f6 = com2Var.f8766b;
                float f7 = com2Var.f8765a;
                f2 = (f6 + f7) * f3;
                f5 = f6 + f7 + f4;
            } else {
                float f8 = this.f2932a.f(i4);
                f2 = (f5 + f8) * f3;
                f5 += f8 + f4;
            }
            if (this.f2954d + f2 > scrollX) {
                this.f2934a.setBounds(Math.round(f2), this.f2956e, Math.round(this.f2954d + f2), this.f2958f);
                this.f2934a.draw(canvas);
            }
            if (f2 > scrollX + width) {
                return;
            }
            i4++;
            f4 = f4;
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            K();
            return false;
        }
        if (action != 0) {
            if (this.f2959f) {
                return true;
            }
            if (this.f2960g) {
                return false;
            }
        }
        if (action == 0) {
            float x2 = motionEvent.getX();
            this.f8749e = x2;
            this.f8747c = x2;
            float y2 = motionEvent.getY();
            this.f8750f = y2;
            this.f8748d = y2;
            this.f8757m = motionEvent.getPointerId(0);
            this.f2960g = false;
            this.f2951b = true;
            this.f2938a.computeScrollOffset();
            if (this.f8764t != 2 || Math.abs(this.f2938a.getFinalX() - this.f2938a.getCurrX()) <= this.f8761q) {
                g(false);
                this.f2959f = false;
            } else {
                this.f2938a.abortAnimation();
                this.f2957e = false;
                D();
                this.f2959f = true;
                J(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i2 = this.f8757m;
            if (i2 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i2);
                float x3 = motionEvent.getX(iFindPointerIndex);
                float f2 = x3 - this.f8747c;
                float fAbs = Math.abs(f2);
                float y3 = motionEvent.getY(iFindPointerIndex);
                float fAbs2 = Math.abs(y3 - this.f8750f);
                if (f2 != 0.0f && !w(this.f8747c, f2) && f(this, false, (int) f2, (int) x3, (int) y3)) {
                    this.f8747c = x3;
                    this.f8748d = y3;
                    this.f2960g = true;
                    return false;
                }
                int i3 = this.f8756l;
                if (fAbs > i3 && fAbs * 0.5f > fAbs2) {
                    this.f2959f = true;
                    J(true);
                    setScrollState(1);
                    float f3 = this.f8749e;
                    float f4 = this.f8756l;
                    this.f8747c = f2 > 0.0f ? f3 + f4 : f3 - f4;
                    this.f8748d = y3;
                    setScrollingCacheEnabled(true);
                } else if (fAbs2 > i3) {
                    this.f2960g = true;
                }
                if (this.f2959f && C(x3)) {
                    y.f0(this);
                }
            }
        } else if (action == 6) {
            y(motionEvent);
        }
        if (this.f2936a == null) {
            this.f2936a = VelocityTracker.obtain();
        }
        this.f2936a.addMovement(motionEvent);
        return this.f2959f;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0071  */
    /* JADX WARN: Code duplicated, block: B:24:0x0075  */
    /* JADX WARN: Code duplicated, block: B:26:0x0079  */
    /* JADX WARN: Code duplicated, block: B:27:0x007b  */
    /* JADX WARN: Code duplicated, block: B:28:0x0088  */
    /* JADX WARN: Code duplicated, block: B:29:0x008e  */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        boolean z3;
        com2 com2VarR;
        int iMax;
        int measuredWidth;
        int iMax2;
        int measuredHeight;
        int childCount = getChildCount();
        int i6 = i4 - i2;
        int i7 = i5 - i3;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            View childAt = getChildAt(i9);
            if (childAt.getVisibility() != 8) {
                com3 com3Var = (com3) childAt.getLayoutParams();
                if (com3Var.f2969a) {
                    int i10 = com3Var.f2968a;
                    int i11 = i10 & 7;
                    int i12 = i10 & 112;
                    if (i11 != 1) {
                        if (i11 == 3) {
                            measuredWidth = childAt.getMeasuredWidth() + paddingLeft;
                        } else if (i11 != 5) {
                            measuredWidth = paddingLeft;
                        } else {
                            iMax = (i6 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        if (i12 != 16) {
                            if (i12 != 48) {
                                measuredHeight = childAt.getMeasuredHeight() + paddingTop;
                            } else if (i12 != 80) {
                                measuredHeight = paddingTop;
                            } else {
                                iMax2 = (i7 - paddingBottom) - childAt.getMeasuredHeight();
                                paddingBottom += childAt.getMeasuredHeight();
                            }
                            int i13 = paddingLeft + scrollX;
                            childAt.layout(i13, paddingTop, childAt.getMeasuredWidth() + i13, paddingTop + childAt.getMeasuredHeight());
                            i8++;
                            paddingTop = measuredHeight;
                            paddingLeft = measuredWidth;
                        } else {
                            iMax2 = Math.max((i7 - childAt.getMeasuredHeight()) / 2, paddingTop);
                        }
                        int i14 = iMax2;
                        measuredHeight = paddingTop;
                        paddingTop = i14;
                        int i15 = paddingLeft + scrollX;
                        childAt.layout(i15, paddingTop, childAt.getMeasuredWidth() + i15, paddingTop + childAt.getMeasuredHeight());
                        i8++;
                        paddingTop = measuredHeight;
                        paddingLeft = measuredWidth;
                    } else {
                        iMax = Math.max((i6 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    int i16 = iMax;
                    measuredWidth = paddingLeft;
                    paddingLeft = i16;
                    if (i12 != 16) {
                        if (i12 != 48) {
                            measuredHeight = childAt.getMeasuredHeight() + paddingTop;
                        } else if (i12 != 80) {
                            measuredHeight = paddingTop;
                        } else {
                            iMax2 = (i7 - paddingBottom) - childAt.getMeasuredHeight();
                            paddingBottom += childAt.getMeasuredHeight();
                        }
                        int i17 = paddingLeft + scrollX;
                        childAt.layout(i17, paddingTop, childAt.getMeasuredWidth() + i17, paddingTop + childAt.getMeasuredHeight());
                        i8++;
                        paddingTop = measuredHeight;
                        paddingLeft = measuredWidth;
                    } else {
                        iMax2 = Math.max((i7 - childAt.getMeasuredHeight()) / 2, paddingTop);
                    }
                    int i18 = iMax2;
                    measuredHeight = paddingTop;
                    paddingTop = i18;
                    int i19 = paddingLeft + scrollX;
                    childAt.layout(i19, paddingTop, childAt.getMeasuredWidth() + i19, paddingTop + childAt.getMeasuredHeight());
                    i8++;
                    paddingTop = measuredHeight;
                    paddingLeft = measuredWidth;
                }
            }
        }
        int i20 = (i6 - paddingLeft) - paddingRight;
        for (int i21 = 0; i21 < childCount; i21++) {
            View childAt2 = getChildAt(i21);
            if (childAt2.getVisibility() != 8) {
                com3 com3Var2 = (com3) childAt2.getLayoutParams();
                if (!com3Var2.f2969a && (com2VarR = r(childAt2)) != null) {
                    float f2 = i20;
                    int i22 = ((int) (com2VarR.f8766b * f2)) + paddingLeft;
                    if (com3Var2.f2970b) {
                        com3Var2.f2970b = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (f2 * com3Var2.f8767a), 1073741824), View.MeasureSpec.makeMeasureSpec((i7 - paddingTop) - paddingBottom, 1073741824));
                    }
                    childAt2.layout(i22, paddingTop, childAt2.getMeasuredWidth() + i22, childAt2.getMeasuredHeight() + paddingTop);
                }
            }
        }
        this.f2956e = paddingTop;
        this.f2958f = i7 - paddingBottom;
        this.f8762r = i8;
        if (this.f2962i) {
            z3 = false;
            L(this.f2946b, false, 0, false);
        } else {
            z3 = false;
        }
        this.f2962i = z3;
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        com3 com3Var;
        com3 com3Var2;
        int i4;
        setMeasuredDimension(View.getDefaultSize(0, i2), View.getDefaultSize(0, i3));
        int measuredWidth = getMeasuredWidth();
        this.f8755k = Math.min(measuredWidth / 10, this.f8754j);
        int paddingLeft = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int childCount = getChildCount();
        int i5 = 0;
        while (true) {
            boolean z2 = true;
            int i6 = 1073741824;
            if (i5 >= childCount) {
                break;
            }
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8 && (com3Var2 = (com3) childAt.getLayoutParams()) != null && com3Var2.f2969a) {
                int i7 = com3Var2.f2968a;
                int i8 = i7 & 7;
                int i9 = i7 & 112;
                boolean z3 = i9 == 48 || i9 == 80;
                if (i8 != 3 && i8 != 5) {
                    z2 = false;
                }
                int i10 = Integer.MIN_VALUE;
                if (z3) {
                    i4 = Integer.MIN_VALUE;
                    i10 = 1073741824;
                } else {
                    i4 = z2 ? 1073741824 : Integer.MIN_VALUE;
                }
                int i11 = ((ViewGroup.LayoutParams) com3Var2).width;
                if (i11 != -2) {
                    if (i11 == -1) {
                        i11 = paddingLeft;
                    }
                    i10 = 1073741824;
                } else {
                    i11 = paddingLeft;
                }
                int i12 = ((ViewGroup.LayoutParams) com3Var2).height;
                if (i12 == -2) {
                    i12 = measuredHeight;
                    i6 = i4;
                } else if (i12 == -1) {
                    i12 = measuredHeight;
                }
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i11, i10), View.MeasureSpec.makeMeasureSpec(i12, i6));
                if (z3) {
                    measuredHeight -= childAt.getMeasuredHeight();
                } else if (z2) {
                    paddingLeft -= childAt.getMeasuredWidth();
                }
            }
            i5++;
        }
        this.f8751g = View.MeasureSpec.makeMeasureSpec(paddingLeft, 1073741824);
        this.f8752h = View.MeasureSpec.makeMeasureSpec(measuredHeight, 1073741824);
        this.f2953c = true;
        D();
        this.f2953c = false;
        int childCount2 = getChildCount();
        for (int i13 = 0; i13 < childCount2; i13++) {
            View childAt2 = getChildAt(i13);
            if (childAt2.getVisibility() != 8 && ((com3Var = (com3) childAt2.getLayoutParams()) == null || !com3Var.f2969a)) {
                childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (paddingLeft * com3Var.f8767a), 1073741824), this.f8752h);
            }
        }
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        int i3;
        int i4;
        int i5;
        com2 com2VarR;
        int childCount = getChildCount();
        if ((i2 & 2) != 0) {
            i4 = childCount;
            i3 = 0;
            i5 = 1;
        } else {
            i3 = childCount - 1;
            i4 = -1;
            i5 = -1;
        }
        while (i3 != i4) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (com2VarR = r(childAt)) != null && com2VarR.f2965a == this.f2946b && childAt.requestFocus(i2, rect)) {
                return true;
            }
            i3 += i5;
        }
        return false;
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof com8)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        com8 com8Var = (com8) parcelable;
        super.onRestoreInstanceState(com8Var.k());
        COM5.aux auxVar = this.f2932a;
        if (auxVar != null) {
            auxVar.k(com8Var.f8773b, com8Var.f2971a);
            N(com8Var.f8772a, false, true);
        } else {
            this.f2952c = com8Var.f8772a;
            this.f2935a = com8Var.f8773b;
            this.f2942a = com8Var.f2971a;
        }
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        com8 com8Var = new com8(super.onSaveInstanceState());
        com8Var.f8772a = this.f2946b;
        COM5.aux auxVar = this.f2932a;
        if (auxVar != null) {
            com8Var.f8773b = auxVar.l();
        }
        return com8Var;
    }

    @Override // android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 != i4) {
            int i6 = this.f2954d;
            F(i2, i4, i6, i6);
        }
    }

    /* JADX WARN: Code duplicated, block: B:53:0x00dc  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        COM5.aux auxVar;
        if (this.f2961h) {
            return true;
        }
        boolean zK = false;
        if ((motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() != 0) || (auxVar = this.f2932a) == null || auxVar.c() == 0) {
            return false;
        }
        if (this.f2936a == null) {
            this.f2936a = VelocityTracker.obtain();
        }
        this.f2936a.addMovement(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            this.f2938a.abortAnimation();
            this.f2957e = false;
            D();
            float x2 = motionEvent.getX();
            this.f8749e = x2;
            this.f8747c = x2;
            float y2 = motionEvent.getY();
            this.f8750f = y2;
            this.f8748d = y2;
            this.f8757m = motionEvent.getPointerId(0);
        } else if (action != 1) {
            if (action != 2) {
                if (action != 3) {
                    if (action == 5) {
                        int actionIndex = motionEvent.getActionIndex();
                        this.f8747c = motionEvent.getX(actionIndex);
                        this.f8757m = motionEvent.getPointerId(actionIndex);
                    } else if (action == 6) {
                        y(motionEvent);
                        this.f8747c = motionEvent.getX(motionEvent.findPointerIndex(this.f8757m));
                    }
                } else if (this.f2959f) {
                    L(this.f2946b, true, 0, false);
                    zK = K();
                }
            } else if (!this.f2959f) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f8757m);
                if (iFindPointerIndex == -1) {
                    zK = K();
                } else {
                    float x3 = motionEvent.getX(iFindPointerIndex);
                    float fAbs = Math.abs(x3 - this.f8747c);
                    float y3 = motionEvent.getY(iFindPointerIndex);
                    float fAbs2 = Math.abs(y3 - this.f8748d);
                    if (fAbs > this.f8756l && fAbs > fAbs2) {
                        this.f2959f = true;
                        J(true);
                        float f2 = this.f8749e;
                        this.f8747c = x3 - f2 > 0.0f ? f2 + this.f8756l : f2 - this.f8756l;
                        this.f8748d = y3;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                    if (this.f2959f) {
                        zK = false | C(motionEvent.getX(motionEvent.findPointerIndex(this.f8757m)));
                    }
                }
            } else if (this.f2959f) {
                zK = false | C(motionEvent.getX(motionEvent.findPointerIndex(this.f8757m)));
            }
        } else if (this.f2959f) {
            VelocityTracker velocityTracker = this.f2936a;
            velocityTracker.computeCurrentVelocity(1000, this.f8759o);
            int xVelocity = (int) velocityTracker.getXVelocity(this.f8757m);
            this.f2957e = true;
            int clientWidth = getClientWidth();
            int scrollX = getScrollX();
            com2 com2VarS = s();
            float f3 = clientWidth;
            O(i(com2VarS.f2965a, ((scrollX / f3) - com2VarS.f8766b) / (com2VarS.f8765a + (this.f2954d / f3)), xVelocity, (int) (motionEvent.getX(motionEvent.findPointerIndex(this.f8757m)) - this.f8749e)), true, true, xVelocity);
            zK = K();
        }
        if (zK) {
            y.f0(this);
        }
        return true;
    }

    public final Rect p(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left += viewGroup.getLeft();
            rect.right += viewGroup.getRight();
            rect.top += viewGroup.getTop();
            rect.bottom += viewGroup.getBottom();
            parent = viewGroup.getParent();
        }
        return rect;
    }

    public com2 q(View view) {
        while (true) {
            Object parent = view.getParent();
            if (parent == this) {
                return r(view);
            }
            if (parent == null || !(parent instanceof View)) {
                return null;
            }
            view = (View) parent;
        }
    }

    public com2 r(View view) {
        for (int i2 = 0; i2 < this.f2944a.size(); i2++) {
            com2 com2Var = this.f2944a.get(i2);
            if (this.f2932a.h(view, com2Var.f2966a)) {
                return com2Var;
            }
        }
        return null;
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        if (this.f2953c) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    public final com2 s() {
        int i2;
        int clientWidth = getClientWidth();
        float f2 = 0.0f;
        float scrollX = clientWidth > 0 ? getScrollX() / clientWidth : 0.0f;
        float f3 = clientWidth > 0 ? this.f2954d / clientWidth : 0.0f;
        int i3 = 0;
        boolean z2 = true;
        com2 com2Var = null;
        int i4 = -1;
        float f4 = 0.0f;
        while (i3 < this.f2944a.size()) {
            com2 com2Var2 = this.f2944a.get(i3);
            if (!z2 && com2Var2.f2965a != (i2 = i4 + 1)) {
                com2Var2 = this.f2939a;
                com2Var2.f8766b = f2 + f4 + f3;
                com2Var2.f2965a = i2;
                com2Var2.f8765a = this.f2932a.f(i2);
                i3--;
            }
            com2 com2Var3 = com2Var2;
            f2 = com2Var3.f8766b;
            float f5 = com2Var3.f8765a + f2 + f3;
            if (!z2 && scrollX < f2) {
                return com2Var;
            }
            if (scrollX < f5 || i3 == this.f2944a.size() - 1) {
                return com2Var3;
            }
            int i5 = com2Var3.f2965a;
            float f6 = com2Var3.f8765a;
            i3++;
            z2 = false;
            i4 = i5;
            f4 = f6;
            com2Var = com2Var3;
        }
        return com2Var;
    }

    public void setAdapter(COM5.aux auxVar) {
        COM5.aux auxVar2 = this.f2932a;
        if (auxVar2 != null) {
            auxVar2.n(null);
            this.f2932a.o(this);
            for (int i2 = 0; i2 < this.f2944a.size(); i2++) {
                com2 com2Var = this.f2944a.get(i2);
                this.f2932a.a(this, com2Var.f2965a, com2Var.f2966a);
            }
            this.f2932a.b(this);
            this.f2944a.clear();
            G();
            this.f2946b = 0;
            scrollTo(0, 0);
        }
        COM5.aux auxVar3 = this.f2932a;
        this.f2932a = auxVar;
        this.f2931a = 0;
        if (auxVar != null) {
            if (this.f2941a == null) {
                this.f2941a = new com7();
            }
            this.f2932a.n(this.f2941a);
            this.f2957e = false;
            boolean z2 = this.f2962i;
            this.f2962i = true;
            this.f2931a = this.f2932a.c();
            if (this.f2952c >= 0) {
                this.f2932a.k(this.f2935a, this.f2942a);
                N(this.f2952c, false, true);
                this.f2952c = -1;
                this.f2935a = null;
                this.f2942a = null;
            } else if (z2) {
                requestLayout();
            } else {
                D();
            }
        }
        List<com5> list = this.f2950b;
        if (list == null || list.isEmpty()) {
            return;
        }
        int size = this.f2950b.size();
        for (int i3 = 0; i3 < size; i3++) {
            this.f2950b.get(i3).a(this, auxVar3, auxVar);
        }
    }

    public void setCurrentItem(int i2) {
        this.f2957e = false;
        N(i2, !this.f2962i, false);
    }

    public void setOffscreenPageLimit(int i2) {
        if (i2 < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i2 + " too small; defaulting to 1");
            i2 = 1;
        }
        if (i2 != this.f8753i) {
            this.f8753i = i2;
            D();
        }
    }

    @Deprecated
    public void setOnPageChangeListener(com6 com6Var) {
        this.f2940a = com6Var;
    }

    public void setPageMargin(int i2) {
        int i3 = this.f2954d;
        this.f2954d = i2;
        int width = getWidth();
        F(width, width, i2, i3);
        requestLayout();
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.f2934a = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setScrollState(int i2) {
        if (this.f8764t == i2) {
            return;
        }
        this.f8764t = i2;
        l(i2);
    }

    public com2 t(int i2) {
        for (int i3 = 0; i3 < this.f2944a.size(); i3++) {
            com2 com2Var = this.f2944a.get(i3);
            if (com2Var.f2965a == i2) {
                return com2Var;
            }
        }
        return null;
    }

    public void u() {
        setWillNotDraw(false);
        setDescendantFocusability(inet.ipaddr.format.validate.aux.KEY_STANDARD_STR);
        setFocusable(true);
        Context context = getContext();
        this.f2938a = new Scroller(context, f8745a);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.f8756l = viewConfiguration.getScaledPagingTouchSlop();
        this.f8758n = (int) (400.0f * f2);
        this.f8759o = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f2937a = new EdgeEffect(context);
        this.f2947b = new EdgeEffect(context);
        this.f8760p = (int) (25.0f * f2);
        this.f8761q = (int) (2.0f * f2);
        this.f8754j = (int) (f2 * 16.0f);
        y.o0(this, new com4());
        if (y.y(this) == 0) {
            y.y0(this, 1);
        }
        y.B0(this, new prn());
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2934a;
    }

    public final boolean w(float f2, float f3) {
        return (f2 < ((float) this.f8755k) && f3 > 0.0f) || (f2 > ((float) (getWidth() - this.f8755k)) && f3 < 0.0f);
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0063  */
    public void x(int i2, float f2, int i3) {
        int iMax;
        int width;
        int left;
        if (this.f8762r > 0) {
            int scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width2 = getWidth();
            int childCount = getChildCount();
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt = getChildAt(i4);
                com3 com3Var = (com3) childAt.getLayoutParams();
                if (com3Var.f2969a) {
                    int i5 = com3Var.f2968a & 7;
                    if (i5 != 1) {
                        if (i5 == 3) {
                            width = childAt.getWidth() + paddingLeft;
                        } else if (i5 != 5) {
                            width = paddingLeft;
                        } else {
                            iMax = (width2 - paddingRight) - childAt.getMeasuredWidth();
                            paddingRight += childAt.getMeasuredWidth();
                        }
                        left = (paddingLeft + scrollX) - childAt.getLeft();
                        if (left != 0) {
                            childAt.offsetLeftAndRight(left);
                        }
                        paddingLeft = width;
                    } else {
                        iMax = Math.max((width2 - childAt.getMeasuredWidth()) / 2, paddingLeft);
                    }
                    int i6 = iMax;
                    width = paddingLeft;
                    paddingLeft = i6;
                    left = (paddingLeft + scrollX) - childAt.getLeft();
                    if (left != 0) {
                        childAt.offsetLeftAndRight(left);
                    }
                    paddingLeft = width;
                }
            }
        }
        j(i2, f2, i3);
        this.f2964k = true;
    }

    public final void y(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f8757m) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.f8747c = motionEvent.getX(i2);
            this.f8757m = motionEvent.getPointerId(i2);
            VelocityTracker velocityTracker = this.f2936a;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    public boolean z() {
        int i2 = this.f2946b;
        if (i2 <= 0) {
            return false;
        }
        M(i2 - 1, true);
        return true;
    }

    public static class com3 extends ViewGroup.LayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f8767a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2968a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2969a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8768b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2970b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8769c;

        public com3() {
            super(-1, -1);
            this.f8767a = 0.0f;
        }

        public com3(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f8767a = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, ViewPager.f2929a);
            this.f2968a = typedArrayObtainStyledAttributes.getInteger(0, 48);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new com3(getContext(), attributeSet);
    }

    public void setPageMarginDrawable(int i2) {
        setPageMarginDrawable(PRN.aux.e(getContext(), i2));
    }
}
