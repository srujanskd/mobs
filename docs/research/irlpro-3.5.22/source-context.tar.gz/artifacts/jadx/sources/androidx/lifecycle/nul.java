package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public abstract class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AtomicReference<Object> f8409a = new AtomicReference<>();

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8410a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final /* synthetic */ int[] f8411b;

        static {
            int[] iArr = new int[con.values().length];
            f8411b = iArr;
            try {
                iArr[con.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8411b[con.ON_STOP.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8411b[con.ON_START.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f8411b[con.ON_PAUSE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f8411b[con.ON_RESUME.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f8411b[con.ON_DESTROY.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f8411b[con.ON_ANY.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            int[] iArr2 = new int[EnumC0039nul.values().length];
            f8410a = iArr2;
            try {
                iArr2[EnumC0039nul.CREATED.ordinal()] = 1;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f8410a[EnumC0039nul.STARTED.ordinal()] = 2;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                f8410a[EnumC0039nul.RESUMED.ordinal()] = 3;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                f8410a[EnumC0039nul.DESTROYED.ordinal()] = 4;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                f8410a[EnumC0039nul.INITIALIZED.ordinal()] = 5;
            } catch (NoSuchFieldError unused12) {
            }
        }
    }

    public enum con {
        ON_CREATE,
        ON_START,
        ON_RESUME,
        ON_PAUSE,
        ON_STOP,
        ON_DESTROY,
        ON_ANY;

        public static con a(EnumC0039nul enumC0039nul) {
            int i2 = aux.f8410a[enumC0039nul.ordinal()];
            if (i2 == 1) {
                return ON_DESTROY;
            }
            if (i2 == 2) {
                return ON_STOP;
            }
            if (i2 != 3) {
                return null;
            }
            return ON_PAUSE;
        }

        public static con d(EnumC0039nul enumC0039nul) {
            int i2 = aux.f8410a[enumC0039nul.ordinal()];
            if (i2 == 1) {
                return ON_START;
            }
            if (i2 == 2) {
                return ON_RESUME;
            }
            if (i2 != 5) {
                return null;
            }
            return ON_CREATE;
        }

        public static con e(EnumC0039nul enumC0039nul) {
            int i2 = aux.f8410a[enumC0039nul.ordinal()];
            if (i2 == 1) {
                return ON_CREATE;
            }
            if (i2 == 2) {
                return ON_START;
            }
            if (i2 != 3) {
                return null;
            }
            return ON_RESUME;
        }

        public EnumC0039nul c() {
            switch (aux.f8411b[ordinal()]) {
                case 1:
                case 2:
                    return EnumC0039nul.CREATED;
                case 3:
                case 4:
                    return EnumC0039nul.STARTED;
                case 5:
                    return EnumC0039nul.RESUMED;
                case 6:
                    return EnumC0039nul.DESTROYED;
                default:
                    throw new IllegalArgumentException(this + " has no target state");
            }
        }
    }

    /* JADX INFO: renamed from: androidx.lifecycle.nul$nul, reason: collision with other inner class name */
    public enum EnumC0039nul {
        DESTROYED,
        INITIALIZED,
        CREATED,
        STARTED,
        RESUMED;

        public boolean a(EnumC0039nul enumC0039nul) {
            return compareTo(enumC0039nul) >= 0;
        }
    }

    public abstract void a(COM3.com6 com6Var);

    public abstract EnumC0039nul b();

    public abstract void c(COM3.com6 com6Var);
}
