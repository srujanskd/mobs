package CON;

import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class aux<K, V> extends con<K, V> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public HashMap<K, con.nul<K, V>> f5777a = new HashMap<>();

    @Override // CON.con
    public con.nul<K, V> b(K k2) {
        return this.f5777a.get(k2);
    }

    public boolean contains(K k2) {
        return this.f5777a.containsKey(k2);
    }

    @Override // CON.con
    public V f(K k2, V v2) {
        con.nul<K, V> nulVarB = b(k2);
        if (nulVarB != null) {
            return nulVarB.f148b;
        }
        this.f5777a.put(k2, e(k2, v2));
        return null;
    }

    @Override // CON.con
    public V g(K k2) {
        V v2 = (V) super.g(k2);
        this.f5777a.remove(k2);
        return v2;
    }

    public Map.Entry<K, V> h(K k2) {
        if (contains(k2)) {
            return this.f5777a.get(k2).f5783b;
        }
        return null;
    }
}
