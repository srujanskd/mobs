package COM2;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public abstract class aux implements Parcelable {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Parcelable f59a;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f5689a = new C0002aux();
    public static final Parcelable.Creator<aux> CREATOR = new con();

    /* JADX INFO: renamed from: COM2.aux$aux, reason: collision with other inner class name */
    public class C0002aux extends aux {
        public C0002aux() {
            super((C0002aux) null);
        }
    }

    public class con implements Parcelable.ClassLoaderCreator<aux> {
        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public aux createFromParcel(Parcel parcel) {
            return createFromParcel(parcel, null);
        }

        @Override // android.os.Parcelable.ClassLoaderCreator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public aux createFromParcel(Parcel parcel, ClassLoader classLoader) {
            if (parcel.readParcelable(classLoader) == null) {
                return aux.f5689a;
            }
            throw new IllegalStateException("superState must be null");
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public aux[] newArray(int i2) {
            return new aux[i2];
        }
    }

    public /* synthetic */ aux(C0002aux c0002aux) {
        this();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final Parcelable k() {
        return this.f59a;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeParcelable(this.f59a, i2);
    }

    public aux() {
        this.f59a = null;
    }

    public aux(Parcelable parcelable) {
        if (parcelable != null) {
            this.f59a = parcelable == f5689a ? null : parcelable;
            return;
        }
        throw new IllegalArgumentException("superState must not be null");
    }

    public aux(Parcel parcel, ClassLoader classLoader) {
        Parcelable parcelable = parcel.readParcelable(classLoader);
        this.f59a = parcelable == null ? f5689a : parcelable;
    }
}
