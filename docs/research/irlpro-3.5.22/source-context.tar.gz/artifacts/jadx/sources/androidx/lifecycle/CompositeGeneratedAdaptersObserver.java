package androidx.lifecycle;

import COM3.com9;

/* JADX INFO: loaded from: classes.dex */
class CompositeGeneratedAdaptersObserver implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final con[] f8365a;

    public CompositeGeneratedAdaptersObserver(con[] conVarArr) {
        this.f8365a = conVarArr;
    }

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        com9 com9Var = new com9();
        for (con conVar2 : this.f8365a) {
            conVar2.a(com7Var, conVar, false, com9Var);
        }
        for (con conVar3 : this.f8365a) {
            conVar3.a(com7Var, conVar, true, com9Var);
        }
    }
}
