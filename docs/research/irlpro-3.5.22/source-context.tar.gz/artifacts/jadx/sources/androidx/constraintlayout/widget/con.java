package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.newrelic.agent.android.distributedtracing.DistributedTracing;
import java.util.Arrays;
import java.util.HashMap;
import p146nUL.p;
import p146nUL.s;
import p151pRn.g0;
import p151pRn.h0;

/* JADX INFO: loaded from: classes.dex */
public abstract class con extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8081a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Context f2208a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2209a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public HashMap<Integer, String> f2210a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public s f2211a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f2212a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View[] f2213a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f8082b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2214b;

    public con(Context context) {
        super(context);
        this.f2212a = new int[32];
        this.f2214b = false;
        this.f2213a = null;
        this.f2210a = new HashMap<>();
        this.f2208a = context;
        m(null);
    }

    public final void d(String str) {
        if (str == null || str.length() == 0 || this.f2208a == null) {
            return;
        }
        String strTrim = str.trim();
        if (getParent() instanceof ConstraintLayout) {
        }
        int iK = k(strTrim);
        if (iK != 0) {
            this.f2210a.put(Integer.valueOf(iK), strTrim);
            e(iK);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + strTrim + "\"");
    }

    public final void e(int i2) {
        if (i2 == getId()) {
            return;
        }
        int i3 = this.f8081a + 1;
        int[] iArr = this.f2212a;
        if (i3 > iArr.length) {
            this.f2212a = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f2212a;
        int i4 = this.f8081a;
        iArr2[i4] = i2;
        this.f8081a = i4 + 1;
    }

    public final void f(String str) {
        if (str == null || str.length() == 0 || this.f2208a == null) {
            return;
        }
        String strTrim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.con) && strTrim.equals(((ConstraintLayout.con) layoutParams).f2176b)) {
                if (childAt.getId() == -1) {
                    Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                } else {
                    e(childAt.getId());
                }
            }
        }
    }

    public void g() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        h((ConstraintLayout) parent);
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f2212a, this.f8081a);
    }

    public void h(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i2 = 0; i2 < this.f8081a; i2++) {
            View viewN = constraintLayout.n(this.f2212a[i2]);
            if (viewN != null) {
                viewN.setVisibility(visibility);
                if (elevation > 0.0f) {
                    viewN.setTranslationZ(viewN.getTranslationZ() + elevation);
                }
            }
        }
    }

    public void i(ConstraintLayout constraintLayout) {
    }

    public final int j(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String resourceEntryName;
        if (str == null || constraintLayout == null || (resources = this.f2208a.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            if (childAt.getId() != -1) {
                try {
                    resourceEntryName = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                    resourceEntryName = null;
                }
                if (str.equals(resourceEntryName)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    public final int k(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int iJ = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object objG = constraintLayout.g(0, str);
            if (objG instanceof Integer) {
                iJ = ((Integer) objG).intValue();
            }
        }
        if (iJ == 0 && constraintLayout != null) {
            iJ = j(constraintLayout, str);
        }
        if (iJ == 0) {
            try {
                iJ = g0.class.getField(str).getInt(null);
            } catch (Exception unused) {
            }
        }
        return iJ == 0 ? this.f2208a.getResources().getIdentifier(str, DistributedTracing.NR_ID_ATTRIBUTE, this.f2208a.getPackageName()) : iJ;
    }

    public View[] l(ConstraintLayout constraintLayout) {
        View[] viewArr = this.f2213a;
        if (viewArr == null || viewArr.length != this.f8081a) {
            this.f2213a = new View[this.f8081a];
        }
        for (int i2 = 0; i2 < this.f8081a; i2++) {
            this.f2213a[i2] = constraintLayout.n(this.f2212a[i2]);
        }
        return this.f2213a;
    }

    public void m(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, h0.f5224u);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                if (index == h0.e1) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.f2209a = string;
                    setIds(string);
                } else if (index == h0.f1) {
                    String string2 = typedArrayObtainStyledAttributes.getString(index);
                    this.f8082b = string2;
                    setReferenceTags(string2);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void n(p pVar, boolean z2) {
    }

    public void o(ConstraintLayout constraintLayout) {
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f2209a;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f8082b;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        if (this.f2214b) {
            super.onMeasure(i2, i3);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void p(ConstraintLayout constraintLayout) {
    }

    public void q(ConstraintLayout constraintLayout) {
    }

    public void r(ConstraintLayout constraintLayout) {
        String str;
        int iJ;
        if (isInEditMode()) {
            setIds(this.f2209a);
        }
        s sVar = this.f2211a;
        if (sVar == null) {
            return;
        }
        sVar.a();
        for (int i2 = 0; i2 < this.f8081a; i2++) {
            int i3 = this.f2212a[i2];
            View viewN = constraintLayout.n(i3);
            if (viewN == null && (iJ = j(constraintLayout, (str = this.f2210a.get(Integer.valueOf(i3))))) != 0) {
                this.f2212a[i2] = iJ;
                this.f2210a.put(Integer.valueOf(iJ), str);
                viewN = constraintLayout.n(iJ);
            }
            if (viewN != null) {
                this.f2211a.c(constraintLayout.p(viewN));
            }
        }
        this.f2211a.b(constraintLayout.f2167a);
    }

    public void s() {
        if (this.f2211a == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.con) {
            ((ConstraintLayout.con) layoutParams).f2173a = (p) this.f2211a;
        }
    }

    public void setIds(String str) {
        this.f2209a = str;
        if (str == null) {
            return;
        }
        int i2 = 0;
        this.f8081a = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i2);
            if (iIndexOf == -1) {
                d(str.substring(i2));
                return;
            } else {
                d(str.substring(i2, iIndexOf));
                i2 = iIndexOf + 1;
            }
        }
    }

    public void setReferenceTags(String str) {
        this.f8082b = str;
        if (str == null) {
            return;
        }
        int i2 = 0;
        this.f8081a = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i2);
            if (iIndexOf == -1) {
                f(str.substring(i2));
                return;
            } else {
                f(str.substring(i2, iIndexOf));
                i2 = iIndexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f2209a = null;
        this.f8081a = 0;
        for (int i2 : iArr) {
            e(i2);
        }
    }

    @Override // android.view.View
    public void setTag(int i2, Object obj) {
        super.setTag(i2, obj);
        if (obj == null && this.f2209a == null) {
            e(i2);
        }
    }

    public con(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2212a = new int[32];
        this.f2214b = false;
        this.f2213a = null;
        this.f2210a = new HashMap<>();
        this.f2208a = context;
        m(attributeSet);
    }
}
