package com.newrelic.agent.android.agentdata;

import com.newrelic.agent.android.Agent;
import com.newrelic.agent.android.AgentConfiguration;
import com.newrelic.agent.android.metric.MetricNames;
import com.newrelic.agent.android.payload.Payload;
import com.newrelic.agent.android.payload.PayloadController;
import com.newrelic.agent.android.payload.PayloadSender;
import com.newrelic.agent.android.stats.StatsEngine;
import com.newrelic.agent.android.util.Constants;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/* JADX INFO: loaded from: classes.dex */
public class AgentDataSender extends PayloadSender {
    public AgentDataSender(byte[] bArr, AgentConfiguration agentConfiguration) {
        super(bArr, agentConfiguration);
    }

    @Override // com.newrelic.agent.android.payload.PayloadSender
    public HttpURLConnection getConnection() throws IOException {
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(getProtocol() + this.agentConfiguration.getHexCollectorHost() + this.agentConfiguration.getHexCollectorPath()).openConnection();
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setRequestMethod("POST");
        httpURLConnection.setRequestProperty(Constants.Network.CONTENT_TYPE_HEADER, Constants.Network.ContentType.OCTET_STREAM);
        httpURLConnection.setRequestProperty(this.agentConfiguration.getAppTokenHeader(), this.agentConfiguration.getApplicationToken());
        httpURLConnection.setRequestProperty(this.agentConfiguration.getDeviceOsNameHeader(), Agent.getDeviceInformation().getOsName());
        httpURLConnection.setRequestProperty(this.agentConfiguration.getAppVersionHeader(), Agent.getApplicationInformation().getAppVersion());
        httpURLConnection.setConnectTimeout(this.agentConfiguration.getHexCollectorTimeout());
        httpURLConnection.setReadTimeout(this.agentConfiguration.getHexCollectorTimeout());
        return httpURLConnection;
    }

    @Override // com.newrelic.agent.android.payload.PayloadSender
    public void onFailedUpload(String str) {
        PayloadSender.log.error(str);
        StatsEngine.get().inc(MetricNames.SUPPORTABILITY_HEX_FAILED_UPLOAD);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x00a1  */
    /* JADX WARN: Instruction removed from duplicated block: B:17:0x00a1, please report this as an issue */
    @Override // com.newrelic.agent.android.payload.PayloadSender
    public void onRequestResponse(HttpURLConnection httpURLConnection) throws IOException {
        int responseCode = httpURLConnection.getResponseCode();
        if (responseCode == 200 || responseCode == 202) {
            StatsEngine.get().sampleTimeMs(MetricNames.SUPPORTABILITY_HEX_UPLOAD_TIME, this.timer.peek());
        } else if (responseCode == 403) {
            onFailedUpload("The data payload [" + this.payload.getUuid() + "] was rejected and will be deleted - Response code [" + responseCode + "]");
            StatsEngine.get().sampleTimeMs(MetricNames.SUPPORTABILITY_HEX_FAILED_UPLOAD, this.timer.peek());
        } else if (responseCode == 408) {
            onFailedUpload("The request to submit the payload [" + this.payload.getUuid() + "] has timed out (will try again later) - Response code [" + responseCode + "]");
            StatsEngine.get().inc(MetricNames.SUPPORTABILITY_HEX_UPLOAD_TIMEOUT);
        } else if (responseCode == 429) {
            onFailedUpload("The request to submit the payload [" + this.payload.getUuid() + "] was throttled (will try again later) - Response code [" + responseCode + "]");
            StatsEngine.get().inc(MetricNames.SUPPORTABILITY_HEX_UPLOAD_THROTTLED);
        } else if (responseCode != 500) {
            onFailedUpload("Something went wrong while submitting the payload [" + this.payload.getUuid() + "] - (will try again later) - Response code [" + responseCode + "]");
        } else {
            onFailedUpload("The data payload [" + this.payload.getUuid() + "] was rejected and will be deleted - Response code [" + responseCode + "]");
            StatsEngine.get().sampleTimeMs(MetricNames.SUPPORTABILITY_HEX_FAILED_UPLOAD, this.timer.peek());
        }
        PayloadSender.log.debug("Payload [" + this.payload.getUuid() + "] delivery took " + this.timer.toc() + "ms");
    }

    @Override // com.newrelic.agent.android.payload.PayloadSender
    public boolean shouldUploadOpportunistically() {
        return PayloadController.shouldUploadOpportunistically();
    }

    public AgentDataSender(Payload payload, AgentConfiguration agentConfiguration) {
        super(payload, agentConfiguration);
    }
}
