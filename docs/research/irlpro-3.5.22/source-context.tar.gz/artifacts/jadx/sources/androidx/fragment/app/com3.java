package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import p015CoM3.i;
import p015CoM3.k;
import p101com2.u2;
import p150pRN.lpt9;

/* JADX INFO: loaded from: classes.dex */
public abstract class com3<E> extends i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f8246a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Activity f2428a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f2429a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f2430a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com6 f2431a;

    public com3(prn prnVar) {
        this(prnVar, prnVar, new Handler(), 0);
    }

    @Override // p015CoM3.i
    public View c(int i2) {
        return null;
    }

    @Override // p015CoM3.i
    public boolean d() {
        return true;
    }

    Activity e() {
        return this.f2428a;
    }

    Context f() {
        return this.f2429a;
    }

    Handler g() {
        return this.f2430a;
    }

    public abstract E h();

    public LayoutInflater i() {
        return LayoutInflater.from(this.f2429a);
    }

    @Deprecated
    public void j(Fragment fragment, String[] strArr, int i2) {
    }

    public boolean k(Fragment fragment) {
        return true;
    }

    public boolean l(String str) {
        return false;
    }

    public void m(Fragment fragment, @SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (i2 != -1) {
            throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
        }
        PRN.aux.i(this.f2429a, intent, bundle);
    }

    @Deprecated
    public void n(Fragment fragment, @SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) throws IntentSender.SendIntentException {
        if (i2 != -1) {
            throw new IllegalStateException("Starting intent sender with a requestCode requires a FragmentActivity host");
        }
        lpt9.o(this.f2428a, intentSender, i2, intent, i3, i4, i5, bundle);
    }

    public void o() {
    }

    public com3(Activity activity, Context context, Handler handler, int i2) {
        this.f2431a = new k();
        this.f2428a = activity;
        this.f2429a = (Context) u2.g(context, "context == null");
        this.f2430a = (Handler) u2.g(handler, "handler == null");
        this.f8246a = i2;
    }
}
