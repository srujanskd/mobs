package COM9;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p078cOM9.lpt6;

/* JADX INFO: loaded from: classes.dex */
public class com9 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    @Deprecated
    public float f5755a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f139a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    @Deprecated
    public float f5756b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    @Deprecated
    public float f5757c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    @Deprecated
    public float f5758d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    @Deprecated
    public float f5759e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    @Deprecated
    public float f5760f;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<com2> f138a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final List<com3> f140b = new ArrayList();

    public class aux extends com3 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ List f141a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Matrix f5762b;

        public aux(List list, Matrix matrix) {
            this.f141a = list;
            this.f5762b = matrix;
        }

        @Override // COM9.com9.com3
        public void a(Matrix matrix, lpt6 lpt6Var, int i2, Canvas canvas) {
            Iterator it = this.f141a.iterator();
            while (it.hasNext()) {
                ((com3) it.next()).a(this.f5762b, lpt6Var, i2, canvas);
            }
        }
    }

    public static class com1 extends com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f5763a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f5764b;

        @Override // COM9.com9.com2
        public void a(Matrix matrix, Path path) {
            Matrix matrix2 = super.f5765a;
            matrix.invert(matrix2);
            path.transform(matrix2);
            path.lineTo(this.f5763a, this.f5764b);
            path.transform(matrix);
        }
    }

    public static abstract class com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Matrix f5765a = new Matrix();

        public abstract void a(Matrix matrix, Path path);
    }

    public static abstract class com3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final Matrix f5766a = new Matrix();

        public abstract void a(Matrix matrix, lpt6 lpt6Var, int i2, Canvas canvas);

        public final void b(lpt6 lpt6Var, int i2, Canvas canvas) {
            a(f5766a, lpt6Var, i2, canvas);
        }
    }

    public static class con extends com3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final prn f5767a;

        public con(prn prnVar) {
            this.f5767a = prnVar;
        }

        @Override // COM9.com9.com3
        public void a(Matrix matrix, lpt6 lpt6Var, int i2, Canvas canvas) {
            lpt6Var.a(canvas, matrix, new RectF(this.f5767a.k(), this.f5767a.o(), this.f5767a.l(), this.f5767a.j()), i2, this.f5767a.m(), this.f5767a.n());
        }
    }

    public static class nul extends com3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final float f5768a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com1 f142a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final float f5769b;

        public nul(com1 com1Var, float f2, float f3) {
            this.f142a = com1Var;
            this.f5768a = f2;
            this.f5769b = f3;
        }

        @Override // COM9.com9.com3
        public void a(Matrix matrix, lpt6 lpt6Var, int i2, Canvas canvas) {
            RectF rectF = new RectF(0.0f, 0.0f, (float) Math.hypot(this.f142a.f5764b - this.f5769b, this.f142a.f5763a - this.f5768a), 0.0f);
            Matrix matrix2 = new Matrix(matrix);
            matrix2.preTranslate(this.f5768a, this.f5769b);
            matrix2.preRotate(c());
            lpt6Var.b(canvas, matrix2, rectF, i2);
        }

        public float c() {
            return (float) Math.toDegrees(Math.atan((this.f142a.f5764b - this.f5769b) / (this.f142a.f5763a - this.f5768a)));
        }
    }

    public static class prn extends com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final RectF f5770a = new RectF();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        @Deprecated
        public float f143a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        @Deprecated
        public float f5771b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        @Deprecated
        public float f5772c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        @Deprecated
        public float f5773d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        @Deprecated
        public float f5774e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        @Deprecated
        public float f5775f;

        public prn(float f2, float f3, float f4, float f5) {
            q(f2);
            u(f3);
            r(f4);
            p(f5);
        }

        @Override // COM9.com9.com2
        public void a(Matrix matrix, Path path) {
            Matrix matrix2 = super.f5765a;
            matrix.invert(matrix2);
            path.transform(matrix2);
            RectF rectF = f5770a;
            rectF.set(k(), o(), l(), j());
            path.arcTo(rectF, m(), n(), false);
            path.transform(matrix);
        }

        public final float j() {
            return this.f5773d;
        }

        public final float k() {
            return this.f143a;
        }

        public final float l() {
            return this.f5772c;
        }

        public final float m() {
            return this.f5774e;
        }

        public final float n() {
            return this.f5775f;
        }

        public final float o() {
            return this.f5771b;
        }

        public final void p(float f2) {
            this.f5773d = f2;
        }

        public final void q(float f2) {
            this.f143a = f2;
        }

        public final void r(float f2) {
            this.f5772c = f2;
        }

        public final void s(float f2) {
            this.f5774e = f2;
        }

        public final void t(float f2) {
            this.f5775f = f2;
        }

        public final void u(float f2) {
            this.f5771b = f2;
        }
    }

    public com9() {
        n(0.0f, 0.0f);
    }

    public void a(float f2, float f3, float f4, float f5, float f6, float f7) {
        prn prnVar = new prn(f2, f3, f4, f5);
        prnVar.s(f6);
        prnVar.t(f7);
        this.f138a.add(prnVar);
        con conVar = new con(prnVar);
        float f8 = f6 + f7;
        boolean z2 = f7 < 0.0f;
        if (z2) {
            f6 = (f6 + 180.0f) % 360.0f;
        }
        c(conVar, f6, z2 ? (180.0f + f8) % 360.0f : f8);
        double d2 = f8;
        r(((f2 + f4) * 0.5f) + (((f4 - f2) / 2.0f) * ((float) Math.cos(Math.toRadians(d2)))));
        s(((f3 + f5) * 0.5f) + (((f5 - f3) / 2.0f) * ((float) Math.sin(Math.toRadians(d2)))));
    }

    public final void b(float f2) {
        if (g() == f2) {
            return;
        }
        float fG = ((f2 - g()) + 360.0f) % 360.0f;
        if (fG > 180.0f) {
            return;
        }
        prn prnVar = new prn(i(), j(), i(), j());
        prnVar.s(g());
        prnVar.t(fG);
        this.f140b.add(new con(prnVar));
        p(f2);
    }

    public final void c(com3 com3Var, float f2, float f3) {
        b(f2);
        this.f140b.add(com3Var);
        p(f3);
    }

    public void d(Matrix matrix, Path path) {
        int size = this.f138a.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f138a.get(i2).a(matrix, path);
        }
    }

    public boolean e() {
        return this.f139a;
    }

    public com3 f(Matrix matrix) {
        b(h());
        return new aux(new ArrayList(this.f140b), new Matrix(matrix));
    }

    public final float g() {
        return this.f5759e;
    }

    public final float h() {
        return this.f5760f;
    }

    public float i() {
        return this.f5757c;
    }

    public float j() {
        return this.f5758d;
    }

    public float k() {
        return this.f5755a;
    }

    public float l() {
        return this.f5756b;
    }

    public void m(float f2, float f3) {
        com1 com1Var = new com1();
        com1Var.f5763a = f2;
        com1Var.f5764b = f3;
        this.f138a.add(com1Var);
        nul nulVar = new nul(com1Var, i(), j());
        c(nulVar, nulVar.c() + 270.0f, nulVar.c() + 270.0f);
        r(f2);
        s(f3);
    }

    public void n(float f2, float f3) {
        o(f2, f3, 270.0f, 0.0f);
    }

    public void o(float f2, float f3, float f4, float f5) {
        t(f2);
        u(f3);
        r(f2);
        s(f3);
        p(f4);
        q((f4 + f5) % 360.0f);
        this.f138a.clear();
        this.f140b.clear();
        this.f139a = false;
    }

    public final void p(float f2) {
        this.f5759e = f2;
    }

    public final void q(float f2) {
        this.f5760f = f2;
    }

    public final void r(float f2) {
        this.f5757c = f2;
    }

    public final void s(float f2) {
        this.f5758d = f2;
    }

    public final void t(float f2) {
        this.f5755a = f2;
    }

    public final void u(float f2) {
        this.f5756b = f2;
    }
}
