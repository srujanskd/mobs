package c0;

import f.com3;
import f.com8;
import i0.BufferedSource;
import java.io.IOException;
import v.lpt8;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C0052aux f8802a = new C0052aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f3000a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final BufferedSource f3001a;

    /* JADX INFO: renamed from: c0.aux$aux, reason: collision with other inner class name */
    public static final class C0052aux {
        public C0052aux() {
        }

        public /* synthetic */ C0052aux(com3 com3Var) {
            this();
        }
    }

    public aux(BufferedSource bufferedSource) {
        com8.e(bufferedSource, "source");
        this.f3001a = bufferedSource;
        this.f3000a = 262144L;
    }

    public final lpt8 a() throws IOException {
        lpt8.aux auxVar = new lpt8.aux();
        while (true) {
            String strB = b();
            if (strB.length() == 0) {
                return auxVar.d();
            }
            auxVar.b(strB);
        }
    }

    public final String b() throws IOException {
        String strT = this.f3001a.T(this.f3000a);
        this.f3000a -= (long) strT.length();
        return strT;
    }
}
