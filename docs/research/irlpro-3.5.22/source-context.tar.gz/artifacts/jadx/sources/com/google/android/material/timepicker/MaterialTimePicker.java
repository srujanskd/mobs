package com.google.android.material.timepicker;

import COM9.com3;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Pair;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.DialogFragment;
import com.google.android.material.button.MaterialButton;
import com.newrelic.agent.android.api.v2.TraceFieldInterface;
import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.tracing.Trace;
import com.newrelic.agent.android.tracing.TraceMachine;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import p024Com2.y;
import p042LpT1.m;
import p042LpT1.n;
import p075cOM6.b4;
import p075cOM6.d4;
import p075cOM6.f4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p098coM9.a;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class MaterialTimePicker extends DialogFragment implements TimePickerView.com1, TraceFieldInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9691a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public m f3769a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public n f3770a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewStub f3771a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Button f3772a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public MaterialButton f3773a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TimePickerView f3774a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.timepicker.aux f3775a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.timepicker.nul f3776a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Trace f3777a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f3778a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f9692b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f3780b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f3782c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Set<View.OnClickListener> f3779a = new LinkedHashSet();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Set<View.OnClickListener> f3781b = new LinkedHashSet();

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final Set<DialogInterface.OnCancelListener> f3783c = new LinkedHashSet();

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final Set<DialogInterface.OnDismissListener> f3784d = new LinkedHashSet();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9693c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9694d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9695e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f9696f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f9697g = 0;

    public class aux implements View.OnClickListener {
        public aux() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Iterator it = MaterialTimePicker.this.f3779a.iterator();
            while (it.hasNext()) {
                ((View.OnClickListener) it.next()).onClick(view);
            }
            MaterialTimePicker.this.dismiss();
        }
    }

    public class con implements View.OnClickListener {
        public con() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Iterator it = MaterialTimePicker.this.f3781b.iterator();
            while (it.hasNext()) {
                ((View.OnClickListener) it.next()).onClick(view);
            }
            MaterialTimePicker.this.dismiss();
        }
    }

    public class nul implements View.OnClickListener {
        public nul() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            MaterialTimePicker materialTimePicker = MaterialTimePicker.this;
            materialTimePicker.f9696f = materialTimePicker.f9696f == 0 ? 1 : 0;
            MaterialTimePicker materialTimePicker2 = MaterialTimePicker.this;
            materialTimePicker2.v(materialTimePicker2.f3773a);
        }
    }

    @Override // com.google.android.material.timepicker.TimePickerView.com1
    public void b() {
        this.f9696f = 1;
        v(this.f3773a);
        this.f3776a.i();
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        Iterator<DialogInterface.OnCancelListener> it = this.f3783c.iterator();
        while (it.hasNext()) {
            it.next().onCancel(dialogInterface);
        }
        super.onCancel(dialogInterface);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        TraceMachine.startTracing("MaterialTimePicker");
        try {
            TraceMachine.enterMethod(this.f3777a, "MaterialTimePicker#onCreate", null);
        } catch (NoSuchFieldError unused) {
            TraceMachine.enterMethod(null, "MaterialTimePicker#onCreate", null);
        }
        super.onCreate(bundle);
        if (bundle == null) {
            bundle = getArguments();
        }
        s(bundle);
        TraceMachine.exitMethod();
    }

    @Override // androidx.fragment.app.DialogFragment
    public final Dialog onCreateDialog(Bundle bundle) {
        Dialog dialog = new Dialog(requireContext(), q());
        Context context = dialog.getContext();
        int iD = a.d(context, x3.f9038m, MaterialTimePicker.class.getCanonicalName());
        int i2 = x3.f9050y;
        int i3 = g4.f8978w;
        com3 com3Var = new com3(context, null, i2, i3);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, h4.f3060D0, i2, i3);
        this.f9692b = typedArrayObtainStyledAttributes.getResourceId(h4.W1, 0);
        this.f9691a = typedArrayObtainStyledAttributes.getResourceId(h4.X1, 0);
        typedArrayObtainStyledAttributes.recycle();
        com3Var.N(context);
        com3Var.Y(ColorStateList.valueOf(iD));
        Window window = dialog.getWindow();
        window.setBackgroundDrawable(com3Var);
        window.requestFeature(1);
        window.setLayout(-2, -2);
        com3Var.X(y.v(window.getDecorView()));
        return dialog;
    }

    @Override // androidx.fragment.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        try {
            TraceMachine.enterMethod(this.f3777a, "MaterialTimePicker#onCreateView", null);
        } catch (NoSuchFieldError unused) {
            TraceMachine.enterMethod(null, "MaterialTimePicker#onCreateView", null);
        }
        ViewGroup viewGroup2 = (ViewGroup) layoutInflater.inflate(d4.f8919m, viewGroup);
        TimePickerView timePickerView = (TimePickerView) viewGroup2.findViewById(b4.f8902y);
        this.f3774a = timePickerView;
        timePickerView.L(this);
        this.f3771a = (ViewStub) viewGroup2.findViewById(b4.f8898u);
        this.f3773a = (MaterialButton) viewGroup2.findViewById(b4.f8900w);
        TextView textView = (TextView) viewGroup2.findViewById(b4.f8886i);
        int i2 = this.f9693c;
        if (i2 != 0) {
            textView.setText(i2);
        } else if (!TextUtils.isEmpty(this.f3778a)) {
            textView.setText(this.f3778a);
        }
        v(this.f3773a);
        Button button = (Button) viewGroup2.findViewById(b4.f8901x);
        button.setOnClickListener(new aux());
        int i3 = this.f9694d;
        if (i3 != 0) {
            button.setText(i3);
        } else if (!TextUtils.isEmpty(this.f3780b)) {
            button.setText(this.f3780b);
        }
        Button button2 = (Button) viewGroup2.findViewById(b4.f8899v);
        this.f3772a = button2;
        button2.setOnClickListener(new con());
        int i4 = this.f9695e;
        if (i4 != 0) {
            this.f3772a.setText(i4);
        } else if (!TextUtils.isEmpty(this.f3782c)) {
            this.f3772a.setText(this.f3782c);
        }
        t();
        this.f3773a.setOnClickListener(new nul());
        TraceMachine.exitMethod();
        return viewGroup2;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.f3770a = null;
        this.f3775a = null;
        this.f3776a = null;
        TimePickerView timePickerView = this.f3774a;
        if (timePickerView != null) {
            timePickerView.L(null);
            this.f3774a = null;
        }
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        Iterator<DialogInterface.OnDismissListener> it = this.f3784d.iterator();
        while (it.hasNext()) {
            it.next().onDismiss(dialogInterface);
        }
        super.onDismiss(dialogInterface);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelable("TIME_PICKER_TIME_MODEL", this.f3769a);
        bundle.putInt("TIME_PICKER_INPUT_MODE", this.f9696f);
        bundle.putInt("TIME_PICKER_TITLE_RES", this.f9693c);
        bundle.putCharSequence("TIME_PICKER_TITLE_TEXT", this.f3778a);
        bundle.putInt("TIME_PICKER_POSITIVE_BUTTON_TEXT_RES", this.f9694d);
        bundle.putCharSequence("TIME_PICKER_POSITIVE_BUTTON_TEXT", this.f3780b);
        bundle.putInt("TIME_PICKER_NEGATIVE_BUTTON_TEXT_RES", this.f9695e);
        bundle.putCharSequence("TIME_PICKER_NEGATIVE_BUTTON_TEXT", this.f3782c);
        bundle.putInt("TIME_PICKER_OVERRIDE_THEME_RES_ID", this.f9697g);
    }

    public final Pair<Integer, Integer> p(int i2) {
        if (i2 == 0) {
            return new Pair<>(Integer.valueOf(this.f9691a), Integer.valueOf(f4.f8945p));
        }
        if (i2 == 1) {
            return new Pair<>(Integer.valueOf(this.f9692b), Integer.valueOf(f4.f8942m));
        }
        throw new IllegalArgumentException("no icon for mode: " + i2);
    }

    public final int q() {
        int i2 = this.f9697g;
        if (i2 != 0) {
            return i2;
        }
        TypedValue typedValueA = a.a(requireContext(), x3.f9051z);
        if (typedValueA == null) {
            return 0;
        }
        return typedValueA.data;
    }

    public final n r(int i2, TimePickerView timePickerView, ViewStub viewStub) {
        if (i2 != 0) {
            if (this.f3776a == null) {
                this.f3776a = new com.google.android.material.timepicker.nul((LinearLayout) viewStub.inflate(), this.f3769a);
            }
            this.f3776a.f();
            return this.f3776a;
        }
        com.google.android.material.timepicker.aux auxVar = this.f3775a;
        if (auxVar == null) {
            auxVar = new com.google.android.material.timepicker.aux(timePickerView, this.f3769a);
        }
        this.f3775a = auxVar;
        return auxVar;
    }

    public final void s(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        m mVar = (m) bundle.getParcelable("TIME_PICKER_TIME_MODEL");
        this.f3769a = mVar;
        if (mVar == null) {
            this.f3769a = new m();
        }
        this.f9696f = bundle.getInt("TIME_PICKER_INPUT_MODE", 0);
        this.f9693c = bundle.getInt("TIME_PICKER_TITLE_RES", 0);
        this.f3778a = bundle.getCharSequence("TIME_PICKER_TITLE_TEXT");
        this.f9694d = bundle.getInt("TIME_PICKER_POSITIVE_BUTTON_TEXT_RES", 0);
        this.f3780b = bundle.getCharSequence("TIME_PICKER_POSITIVE_BUTTON_TEXT");
        this.f9695e = bundle.getInt("TIME_PICKER_NEGATIVE_BUTTON_TEXT_RES", 0);
        this.f3782c = bundle.getCharSequence("TIME_PICKER_NEGATIVE_BUTTON_TEXT");
        this.f9697g = bundle.getInt("TIME_PICKER_OVERRIDE_THEME_RES_ID", 0);
    }

    @Override // androidx.fragment.app.DialogFragment
    public void setCancelable(boolean z2) {
        super.setCancelable(z2);
        t();
    }

    public final void t() {
        Button button = this.f3772a;
        if (button != null) {
            button.setVisibility(isCancelable() ? 0 : 8);
        }
    }

    public final void v(MaterialButton materialButton) {
        if (materialButton == null || this.f3774a == null || this.f3771a == null) {
            return;
        }
        n nVar = this.f3770a;
        if (nVar != null) {
            nVar.b();
        }
        n nVarR = r(this.f9696f, this.f3774a, this.f3771a);
        this.f3770a = nVarR;
        nVarR.a();
        this.f3770a.invalidate();
        Pair<Integer, Integer> pairP = p(this.f9696f);
        materialButton.setIconResource(((Integer) pairP.first).intValue());
        materialButton.setContentDescription(getResources().getString(((Integer) pairP.second).intValue()));
        materialButton.sendAccessibilityEvent(4);
    }
}
