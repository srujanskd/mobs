package com.google.android.material.bottomsheet;

import COM9.com7;
import android.R;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import p023Com1.lpt2;
import p024Com2.t0;
import p024Com2.y;
import p075cOM6.f4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.z3;
import p081cOm2.e2;
import p081cOm2.h2;
import p090coM1.b0;
import p098coM9.b;
import p102com3.p0;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.nul<V> {

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public static final int f9326w = g4.f8962g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f9327a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3328a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM9.com3 f3329a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com7 f3330a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3331a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3332a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public VelocityTracker f3333a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final BottomSheetBehavior<V>.com4 f3334a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p0.nul f3335a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p0 f3336a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public WeakReference<V> f3337a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<com2> f3338a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Map<View, Integer> f3339a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f3340a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f9328b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3341b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public WeakReference<View> f3342b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3343b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f9329c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f3344c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3345c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9330d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3346d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9331e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f3347e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f9332f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f3348f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f9333g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f3349g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f9334h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f3350h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f9335i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f3351i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f9336j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f3352j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f9337k;

    /* JADX INFO: renamed from: k, reason: collision with other field name */
    public boolean f3353k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f9338l;

    /* JADX INFO: renamed from: l, reason: collision with other field name */
    public boolean f3354l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f9339m;

    /* JADX INFO: renamed from: m, reason: collision with other field name */
    public boolean f3355m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f9340n;

    /* JADX INFO: renamed from: n, reason: collision with other field name */
    public boolean f3356n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f9341o;

    /* JADX INFO: renamed from: o, reason: collision with other field name */
    public boolean f3357o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f9342p;

    /* JADX INFO: renamed from: p, reason: collision with other field name */
    public boolean f3358p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f9343q;

    /* JADX INFO: renamed from: q, reason: collision with other field name */
    public boolean f3359q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f9344r;

    /* JADX INFO: renamed from: r, reason: collision with other field name */
    public boolean f3360r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f9345s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f9346t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f9347u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f9348v;

    public class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9349a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f3361a;

        public aux(View view, int i2) {
            this.f3361a = view;
            this.f9349a = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            BottomSheetBehavior.this.P0(this.f3361a, this.f9349a, false);
        }
    }

    public class com1 implements h2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9350a;

        public com1(int i2) {
            this.f9350a = i2;
        }

        @Override // p081cOm2.h2
        public boolean a(View view, h2.aux auxVar) {
            BottomSheetBehavior.this.H0(this.f9350a);
            return true;
        }
    }

    public static abstract class com2 {
        public void a(View view) {
        }

        public abstract void b(View view, float f2);

        public abstract void c(View view, int i2);
    }

    public class con implements ValueAnimator.AnimatorUpdateListener {
        public con() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            if (BottomSheetBehavior.this.f3329a != null) {
                BottomSheetBehavior.this.f3329a.Z(fFloatValue);
            }
        }
    }

    public class nul implements v.prn {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ boolean f3368a;

        public nul(boolean z2) {
            this.f3368a = z2;
        }

        /* JADX WARN: Code duplicated, block: B:22:0x0080  */
        /* JADX WARN: Code duplicated, block: B:33:0x00a3  */
        @Override // com9.v.prn
        public t0 a(View view, t0 t0Var, v.com1 com1Var) {
            boolean z2;
            lpt2 lpt2VarF = t0Var.f(t0.com9.c());
            lpt2 lpt2VarF2 = t0Var.f(t0.com9.b());
            BottomSheetBehavior.this.f9335i = lpt2VarF.f6415b;
            boolean zE = v.e(view);
            int paddingBottom = view.getPaddingBottom();
            int paddingLeft = view.getPaddingLeft();
            int paddingRight = view.getPaddingRight();
            if (BottomSheetBehavior.this.f3347e) {
                BottomSheetBehavior.this.f9334h = t0Var.i();
                paddingBottom = com1Var.f10585d + BottomSheetBehavior.this.f9334h;
            }
            if (BottomSheetBehavior.this.f3348f) {
                paddingLeft = (zE ? com1Var.f10584c : com1Var.f10582a) + lpt2VarF.f689a;
            }
            if (BottomSheetBehavior.this.f3349g) {
                paddingRight = (zE ? com1Var.f10582a : com1Var.f10584c) + lpt2VarF.f6416c;
            }
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            boolean z3 = true;
            if (BottomSheetBehavior.this.f3351i) {
                int i2 = marginLayoutParams.leftMargin;
                int i3 = lpt2VarF.f689a;
                if (i2 != i3) {
                    marginLayoutParams.leftMargin = i3;
                    z2 = true;
                } else {
                    z2 = false;
                }
            } else {
                z2 = false;
            }
            if (BottomSheetBehavior.this.f3352j) {
                int i4 = marginLayoutParams.rightMargin;
                int i5 = lpt2VarF.f6416c;
                if (i4 != i5) {
                    marginLayoutParams.rightMargin = i5;
                    z2 = true;
                }
            }
            if (BottomSheetBehavior.this.f3353k) {
                int i6 = marginLayoutParams.topMargin;
                int i7 = lpt2VarF.f6415b;
                if (i6 != i7) {
                    marginLayoutParams.topMargin = i7;
                } else {
                    z3 = z2;
                }
            } else {
                z3 = z2;
            }
            if (z3) {
                view.setLayoutParams(marginLayoutParams);
            }
            view.setPadding(paddingLeft, view.getPaddingTop(), paddingRight, paddingBottom);
            if (this.f3368a) {
                BottomSheetBehavior.this.f9333g = lpt2VarF2.f6417d;
            }
            if (BottomSheetBehavior.this.f3347e || this.f3368a) {
                BottomSheetBehavior.this.T0(false);
            }
            return t0Var;
        }
    }

    public class prn extends p0.nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public long f9359a;

        public prn() {
        }

        @Override // com3.p0.nul
        public int a(View view, int i2, int i3) {
            return view.getLeft();
        }

        @Override // com3.p0.nul
        public int b(View view, int i2, int i3) {
            int iH0 = BottomSheetBehavior.this.h0();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return b0.b(i2, iH0, bottomSheetBehavior.f3355m ? bottomSheetBehavior.f9345s : bottomSheetBehavior.f9339m);
        }

        @Override // com3.p0.nul
        public int e(View view) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return bottomSheetBehavior.f3355m ? bottomSheetBehavior.f9345s : bottomSheetBehavior.f9339m;
        }

        @Override // com3.p0.nul
        public void j(int i2) {
            if (i2 == 1 && BottomSheetBehavior.this.f3357o) {
                BottomSheetBehavior.this.I0(1);
            }
        }

        @Override // com3.p0.nul
        public void k(View view, int i2, int i3, int i4, int i5) {
            BottomSheetBehavior.this.d0(i3);
        }

        /* JADX WARN: Code duplicated, block: B:39:0x00a7  */
        /* JADX WARN: Code duplicated, block: B:6:0x0010  */
        @Override // com3.p0.nul
        public void l(View view, float f2, float f3) {
            int i2 = 6;
            if (f3 >= 0.0f) {
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
                if (bottomSheetBehavior.f3355m && bottomSheetBehavior.M0(view, f3)) {
                    if ((Math.abs(f2) < Math.abs(f3) && f3 > 500.0f) || n(view)) {
                        i2 = 5;
                    } else if (BottomSheetBehavior.this.f3340a || Math.abs(view.getTop() - BottomSheetBehavior.this.h0()) < Math.abs(view.getTop() - BottomSheetBehavior.this.f9338l)) {
                        i2 = 3;
                    }
                } else if (f3 == 0.0f || Math.abs(f2) > Math.abs(f3)) {
                    int top = view.getTop();
                    if (!BottomSheetBehavior.this.f3340a) {
                        BottomSheetBehavior bottomSheetBehavior2 = BottomSheetBehavior.this;
                        int i3 = bottomSheetBehavior2.f9338l;
                        if (top < i3) {
                            if (top < Math.abs(top - bottomSheetBehavior2.f9339m)) {
                                i2 = 3;
                            } else if (BottomSheetBehavior.this.N0()) {
                                i2 = 4;
                            }
                        } else if (Math.abs(top - i3) >= Math.abs(top - BottomSheetBehavior.this.f9339m) || BottomSheetBehavior.this.N0()) {
                            i2 = 4;
                        }
                    } else if (Math.abs(top - BottomSheetBehavior.this.f9337k) < Math.abs(top - BottomSheetBehavior.this.f9339m)) {
                        i2 = 3;
                    } else {
                        i2 = 4;
                    }
                } else if (BottomSheetBehavior.this.f3340a) {
                    i2 = 4;
                } else {
                    int top2 = view.getTop();
                    if (Math.abs(top2 - BottomSheetBehavior.this.f9338l) >= Math.abs(top2 - BottomSheetBehavior.this.f9339m) || BottomSheetBehavior.this.N0()) {
                        i2 = 4;
                    }
                }
            } else if (BottomSheetBehavior.this.f3340a) {
                i2 = 3;
            } else {
                int top3 = view.getTop();
                long jCurrentTimeMillis = System.currentTimeMillis() - this.f9359a;
                if (BottomSheetBehavior.this.N0()) {
                    BottomSheetBehavior bottomSheetBehavior3 = BottomSheetBehavior.this;
                    if (!bottomSheetBehavior3.K0(jCurrentTimeMillis, (top3 * 100.0f) / bottomSheetBehavior3.f9345s)) {
                        i2 = 4;
                    }
                } else if (top3 <= BottomSheetBehavior.this.f9338l) {
                }
                i2 = 3;
            }
            BottomSheetBehavior bottomSheetBehavior4 = BottomSheetBehavior.this;
            bottomSheetBehavior4.P0(view, i2, bottomSheetBehavior4.O0());
        }

        @Override // com3.p0.nul
        public boolean m(View view, int i2) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            int i3 = bottomSheetBehavior.f9340n;
            if (i3 == 1 || bottomSheetBehavior.f3360r) {
                return false;
            }
            if (i3 == 3 && bottomSheetBehavior.f9346t == i2) {
                WeakReference<View> weakReference = bottomSheetBehavior.f3342b;
                View view2 = weakReference != null ? weakReference.get() : null;
                if (view2 != null && view2.canScrollVertically(-1)) {
                    return false;
                }
            }
            this.f9359a = System.currentTimeMillis();
            WeakReference<V> weakReference2 = BottomSheetBehavior.this.f3337a;
            return weakReference2 != null && weakReference2.get() == view;
        }

        public final boolean n(View view) {
            int top = view.getTop();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return top > (bottomSheetBehavior.f9345s + bottomSheetBehavior.h0()) / 2;
        }
    }

    public BottomSheetBehavior() {
        this.f3328a = 0;
        this.f3340a = true;
        this.f3343b = false;
        this.f9331e = -1;
        this.f9332f = -1;
        this.f3334a = new com4(this, null);
        this.f9328b = 0.5f;
        this.f9329c = -1.0f;
        this.f3357o = true;
        this.f9340n = 4;
        this.f9341o = 4;
        this.f3338a = new ArrayList<>();
        this.f9348v = -1;
        this.f3335a = new prn();
    }

    public static <V extends View> BottomSheetBehavior<V> f0(V v2) {
        ViewGroup.LayoutParams layoutParams = v2.getLayoutParams();
        if (!(layoutParams instanceof CoordinatorLayout.com2)) {
            throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
        }
        CoordinatorLayout.nul nulVarF = ((CoordinatorLayout.com2) layoutParams).f();
        if (nulVarF instanceof BottomSheetBehavior) {
            return (BottomSheetBehavior) nulVarF;
        }
        throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean A(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2, int i3) {
        this.f9342p = 0;
        this.f3359q = false;
        return (i2 & 2) != 0;
    }

    public void A0(boolean z2) {
        if (this.f3355m != z2) {
            this.f3355m = z2;
            if (!z2 && this.f9340n == 5) {
                H0(4);
            }
            Q0();
        }
    }

    public void B0(int i2) {
        this.f9332f = i2;
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0092  */
    /* JADX WARN: Code duplicated, block: B:51:0x00a9  */
    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void C(CoordinatorLayout coordinatorLayout, V v2, View view, int i2) {
        WeakReference<View> weakReference;
        int i3 = 3;
        if (v2.getTop() == h0()) {
            I0(3);
            return;
        }
        if (!p0() || ((weakReference = this.f3342b) != null && view == weakReference.get() && this.f3359q)) {
            if (this.f9342p > 0) {
                if (!this.f3340a && v2.getTop() > this.f9338l) {
                    i3 = 6;
                }
            } else if (this.f3355m && M0(v2, l0())) {
                i3 = 5;
            } else if (this.f9342p == 0) {
                int top = v2.getTop();
                if (!this.f3340a) {
                    int i4 = this.f9338l;
                    if (top < i4) {
                        if (top >= Math.abs(top - this.f9339m)) {
                            if (N0()) {
                                i3 = 4;
                            } else {
                                i3 = 6;
                            }
                        }
                    } else if (Math.abs(top - i4) < Math.abs(top - this.f9339m)) {
                        i3 = 6;
                    } else {
                        i3 = 4;
                    }
                } else if (Math.abs(top - this.f9337k) >= Math.abs(top - this.f9339m)) {
                    i3 = 4;
                }
            } else {
                if (!this.f3340a) {
                    int top2 = v2.getTop();
                    if (Math.abs(top2 - this.f9338l) < Math.abs(top2 - this.f9339m)) {
                        i3 = 6;
                    }
                }
                i3 = 4;
            }
            P0(v2, i3, false);
            this.f3359q = false;
        }
    }

    public void C0(int i2) {
        this.f9331e = i2;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean D(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
        if (!v2.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f9340n == 1 && actionMasked == 0) {
            return true;
        }
        if (L0()) {
            this.f3336a.C(motionEvent);
        }
        if (actionMasked == 0) {
            s0();
        }
        if (this.f3333a == null) {
            this.f3333a = VelocityTracker.obtain();
        }
        this.f3333a.addMovement(motionEvent);
        if (L0() && actionMasked == 2 && !this.f3358p && Math.abs(this.f9347u - motionEvent.getY()) > this.f3336a.w()) {
            this.f3336a.c(v2, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        return !this.f3358p;
    }

    public void D0(int i2) {
        E0(i2, false);
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0015  */
    public final void E0(int i2, boolean z2) {
        boolean z3 = true;
        if (i2 == -1) {
            if (this.f3345c) {
                z3 = false;
            } else {
                this.f3345c = true;
            }
        } else if (this.f3345c || this.f3341b != i2) {
            this.f3345c = false;
            this.f3341b = Math.max(0, i2);
        } else {
            z3 = false;
        }
        if (z3) {
            T0(z2);
        }
    }

    public void F0(int i2) {
        this.f3328a = i2;
    }

    public void G0(boolean z2) {
        this.f3356n = z2;
    }

    public void H0(int i2) {
        if (i2 == 1 || i2 == 2) {
            StringBuilder sb = new StringBuilder();
            sb.append("STATE_");
            sb.append(i2 == 1 ? "DRAGGING" : "SETTLING");
            sb.append(" should not be set externally.");
            throw new IllegalArgumentException(sb.toString());
        }
        if (!this.f3355m && i2 == 5) {
            Log.w("BottomSheetBehavior", "Cannot set state: " + i2);
            return;
        }
        int i3 = (i2 == 6 && this.f3340a && k0(i2) <= this.f9337k) ? 3 : i2;
        WeakReference<V> weakReference = this.f3337a;
        if (weakReference == null || weakReference.get() == null) {
            I0(i2);
        } else {
            V v2 = this.f3337a.get();
            u0(v2, new aux(v2, i3));
        }
    }

    public void I0(int i2) {
        V v2;
        if (this.f9340n == i2) {
            return;
        }
        this.f9340n = i2;
        if (i2 == 4 || i2 == 3 || i2 == 6 || (this.f3355m && i2 == 5)) {
            this.f9341o = i2;
        }
        WeakReference<V> weakReference = this.f3337a;
        if (weakReference == null || (v2 = weakReference.get()) == null) {
            return;
        }
        if (i2 == 3) {
            S0(true);
        } else if (i2 == 6 || i2 == 5 || i2 == 4) {
            S0(false);
        }
        R0(i2);
        for (int i3 = 0; i3 < this.f3338a.size(); i3++) {
            this.f3338a.get(i3).c(v2, i2);
        }
        Q0();
    }

    public final void J0(View view) {
        boolean z2 = (Build.VERSION.SDK_INT < 29 || m0() || this.f3345c) ? false : true;
        if (this.f3347e || this.f3348f || this.f3349g || this.f3351i || this.f3352j || this.f3353k || z2) {
            v.a(view, new nul(z2));
        }
    }

    public boolean K0(long j2, float f2) {
        return false;
    }

    public final boolean L0() {
        return this.f3336a != null && (this.f3357o || this.f9340n == 1);
    }

    public boolean M0(View view, float f2) {
        if (this.f3356n) {
            return true;
        }
        if (view.getTop() < this.f9339m) {
            return false;
        }
        return Math.abs((((float) view.getTop()) + (f2 * 0.1f)) - ((float) this.f9339m)) / ((float) Z()) > 0.5f;
    }

    public boolean N0() {
        return false;
    }

    public boolean O0() {
        return true;
    }

    public final void P0(View view, int i2, boolean z2) {
        int iK0 = k0(i2);
        p0 p0Var = this.f3336a;
        if (!(p0Var != null && (!z2 ? !p0Var.N(view, view.getLeft(), iK0) : !p0Var.L(view.getLeft(), iK0)))) {
            I0(i2);
            return;
        }
        I0(2);
        R0(i2);
        this.f3334a.c(i2);
    }

    public final void Q0() {
        V v2;
        WeakReference<V> weakReference = this.f3337a;
        if (weakReference == null || (v2 = weakReference.get()) == null) {
            return;
        }
        y.i0(v2, inet.ipaddr.format.validate.aux.KEY_STANDARD_RANGE_STR);
        y.i0(v2, inet.ipaddr.format.validate.aux.KEY_STANDARD_STR);
        y.i0(v2, inet.ipaddr.format.validate.aux.KEY_RANGE_WILDCARD);
        int i2 = this.f9348v;
        if (i2 != -1) {
            y.i0(v2, i2);
        }
        if (!this.f3340a && this.f9340n != 6) {
            this.f9348v = V(v2, f4.f8930a, 6);
        }
        if (this.f3355m && this.f9340n != 5) {
            r0(v2, e2.aux.f9117u, 5);
        }
        int i3 = this.f9340n;
        if (i3 == 3) {
            r0(v2, e2.aux.f9116t, this.f3340a ? 4 : 6);
            return;
        }
        if (i3 == 4) {
            r0(v2, e2.aux.f9115s, this.f3340a ? 3 : 6);
        } else {
            if (i3 != 6) {
                return;
            }
            r0(v2, e2.aux.f9116t, 4);
            r0(v2, e2.aux.f9115s, 3);
        }
    }

    public final void R0(int i2) {
        ValueAnimator valueAnimator;
        if (i2 == 2) {
            return;
        }
        boolean z2 = i2 == 3;
        if (this.f3354l != z2) {
            this.f3354l = z2;
            if (this.f3329a == null || (valueAnimator = this.f3331a) == null) {
                return;
            }
            if (valueAnimator.isRunning()) {
                this.f3331a.reverse();
                return;
            }
            float f2 = z2 ? 0.0f : 1.0f;
            this.f3331a.setFloatValues(1.0f - f2, f2);
            this.f3331a.start();
        }
    }

    public final void S0(boolean z2) {
        Map<View, Integer> map;
        WeakReference<V> weakReference = this.f3337a;
        if (weakReference == null) {
            return;
        }
        ViewParent parent = weakReference.get().getParent();
        if (parent instanceof CoordinatorLayout) {
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
            int childCount = coordinatorLayout.getChildCount();
            if (z2) {
                if (this.f3339a != null) {
                    return;
                } else {
                    this.f3339a = new HashMap(childCount);
                }
            }
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                if (childAt != this.f3337a.get()) {
                    if (z2) {
                        this.f3339a.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                        if (this.f3343b) {
                            y.y0(childAt, 4);
                        }
                    } else if (this.f3343b && (map = this.f3339a) != null && map.containsKey(childAt)) {
                        y.y0(childAt, this.f3339a.get(childAt).intValue());
                    }
                }
            }
            if (!z2) {
                this.f3339a = null;
            } else if (this.f3343b) {
                this.f3337a.get().sendAccessibilityEvent(8);
            }
        }
    }

    public final void T0(boolean z2) {
        V v2;
        if (this.f3337a != null) {
            X();
            if (this.f9340n != 4 || (v2 = this.f3337a.get()) == null) {
                return;
            }
            if (z2) {
                H0(4);
            } else {
                v2.requestLayout();
            }
        }
    }

    public final int V(V v2, int i2, int i3) {
        return y.c(v2, v2.getResources().getString(i2), a0(i3));
    }

    public void W(com2 com2Var) {
        if (this.f3338a.contains(com2Var)) {
            return;
        }
        this.f3338a.add(com2Var);
    }

    public final void X() {
        int iZ = Z();
        if (this.f3340a) {
            this.f9339m = Math.max(this.f9345s - iZ, this.f9337k);
        } else {
            this.f9339m = this.f9345s - iZ;
        }
    }

    public final void Y() {
        this.f9338l = (int) (this.f9345s * (1.0f - this.f9328b));
    }

    public final int Z() {
        int i2;
        if (this.f3345c) {
            return Math.min(Math.max(this.f3344c, this.f9345s - ((this.f9344r * 9) / 16)), this.f9343q) + this.f9334h;
        }
        return (this.f3346d || this.f3347e || (i2 = this.f9333g) <= 0) ? this.f3341b + this.f9334h : Math.max(this.f3341b, i2 + this.f9330d);
    }

    public final h2 a0(int i2) {
        return new com1(i2);
    }

    public final void b0(Context context) {
        if (this.f3330a == null) {
            return;
        }
        COM9.com3 com3Var = new COM9.com3(this.f3330a);
        this.f3329a = com3Var;
        com3Var.N(context);
        ColorStateList colorStateList = this.f3332a;
        if (colorStateList != null) {
            this.f3329a.Y(colorStateList);
            return;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.colorBackground, typedValue, true);
        this.f3329a.setTint(typedValue.data);
    }

    public final void c0() {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f3331a = valueAnimatorOfFloat;
        valueAnimatorOfFloat.setDuration(500L);
        this.f3331a.addUpdateListener(new con());
    }

    public void d0(int i2) {
        float f2;
        float fH0;
        V v2 = this.f3337a.get();
        if (v2 == null || this.f3338a.isEmpty()) {
            return;
        }
        int i3 = this.f9339m;
        if (i2 > i3 || i3 == h0()) {
            int i4 = this.f9339m;
            f2 = i4 - i2;
            fH0 = this.f9345s - i4;
        } else {
            int i5 = this.f9339m;
            f2 = i5 - i2;
            fH0 = i5 - h0();
        }
        float f3 = f2 / fH0;
        for (int i6 = 0; i6 < this.f3338a.size(); i6++) {
            this.f3338a.get(i6).b(v2, f3);
        }
    }

    public View e0(View view) {
        if (y.T(view)) {
            return view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View viewE0 = e0(viewGroup.getChildAt(i2));
            if (viewE0 != null) {
                return viewE0;
            }
        }
        return null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void g(CoordinatorLayout.com2 com2Var) {
        super.g(com2Var);
        this.f3337a = null;
        this.f3336a = null;
    }

    public final int g0(int i2, int i3, int i4, int i5) {
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, i3, i5);
        if (i4 == -1) {
            return childMeasureSpec;
        }
        int mode = View.MeasureSpec.getMode(childMeasureSpec);
        int size = View.MeasureSpec.getSize(childMeasureSpec);
        if (mode == 1073741824) {
            return View.MeasureSpec.makeMeasureSpec(Math.min(size, i4), 1073741824);
        }
        if (size != 0) {
            i4 = Math.min(size, i4);
        }
        return View.MeasureSpec.makeMeasureSpec(i4, Integer.MIN_VALUE);
    }

    public int h0() {
        if (this.f3340a) {
            return this.f9337k;
        }
        return Math.max(this.f9336j, this.f3350h ? 0 : this.f9335i);
    }

    public COM9.com3 i0() {
        return this.f3329a;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void j() {
        super.j();
        this.f3337a = null;
        this.f3336a = null;
    }

    public int j0() {
        return this.f9340n;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean k(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
        p0 p0Var;
        if (!v2.isShown() || !this.f3357o) {
            this.f3358p = true;
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            s0();
        }
        if (this.f3333a == null) {
            this.f3333a = VelocityTracker.obtain();
        }
        this.f3333a.addMovement(motionEvent);
        if (actionMasked == 0) {
            int x2 = (int) motionEvent.getX();
            this.f9347u = (int) motionEvent.getY();
            if (this.f9340n != 2) {
                WeakReference<View> weakReference = this.f3342b;
                View view = weakReference != null ? weakReference.get() : null;
                if (view != null && coordinatorLayout.B(view, x2, this.f9347u)) {
                    this.f9346t = motionEvent.getPointerId(motionEvent.getActionIndex());
                    this.f3360r = true;
                }
            }
            this.f3358p = this.f9346t == -1 && !coordinatorLayout.B(v2, x2, this.f9347u);
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f3360r = false;
            this.f9346t = -1;
            if (this.f3358p) {
                this.f3358p = false;
                return false;
            }
        }
        if (!this.f3358p && (p0Var = this.f3336a) != null && p0Var.M(motionEvent)) {
            return true;
        }
        WeakReference<View> weakReference2 = this.f3342b;
        View view2 = weakReference2 != null ? weakReference2.get() : null;
        return (actionMasked != 2 || view2 == null || this.f3358p || this.f9340n == 1 || coordinatorLayout.B(view2, (int) motionEvent.getX(), (int) motionEvent.getY()) || this.f3336a == null || Math.abs(((float) this.f9347u) - motionEvent.getY()) <= ((float) this.f3336a.w())) ? false : true;
    }

    public final int k0(int i2) {
        if (i2 == 3) {
            return h0();
        }
        if (i2 == 4) {
            return this.f9339m;
        }
        if (i2 == 5) {
            return this.f9345s;
        }
        if (i2 == 6) {
            return this.f9338l;
        }
        throw new IllegalArgumentException("Invalid state to get top offset: " + i2);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean l(CoordinatorLayout coordinatorLayout, V v2, int i2) {
        if (y.x(coordinatorLayout) && !y.x(v2)) {
            v2.setFitsSystemWindows(true);
        }
        if (this.f3337a == null) {
            this.f3344c = coordinatorLayout.getResources().getDimensionPixelSize(z3.f9059b);
            J0(v2);
            this.f3337a = new WeakReference<>(v2);
            COM9.com3 com3Var = this.f3329a;
            if (com3Var != null) {
                y.s0(v2, com3Var);
                COM9.com3 com3Var2 = this.f3329a;
                float fV = this.f9329c;
                if (fV == -1.0f) {
                    fV = y.v(v2);
                }
                com3Var2.X(fV);
                boolean z2 = this.f9340n == 3;
                this.f3354l = z2;
                this.f3329a.Z(z2 ? 0.0f : 1.0f);
            } else {
                ColorStateList colorStateList = this.f3332a;
                if (colorStateList != null) {
                    y.t0(v2, colorStateList);
                }
            }
            Q0();
            if (y.y(v2) == 0) {
                y.y0(v2, 1);
            }
        }
        if (this.f3336a == null) {
            this.f3336a = p0.n(coordinatorLayout, this.f3335a);
        }
        int top = v2.getTop();
        coordinatorLayout.I(v2, i2);
        this.f9344r = coordinatorLayout.getWidth();
        this.f9345s = coordinatorLayout.getHeight();
        int height = v2.getHeight();
        this.f9343q = height;
        int i3 = this.f9345s;
        int i4 = i3 - height;
        int i5 = this.f9335i;
        if (i4 < i5) {
            if (this.f3350h) {
                this.f9343q = i3;
            } else {
                this.f9343q = i3 - i5;
            }
        }
        this.f9337k = Math.max(0, i3 - this.f9343q);
        Y();
        X();
        int i6 = this.f9340n;
        if (i6 == 3) {
            y.Z(v2, h0());
        } else if (i6 == 6) {
            y.Z(v2, this.f9338l);
        } else if (this.f3355m && i6 == 5) {
            y.Z(v2, this.f9345s);
        } else if (i6 == 4) {
            y.Z(v2, this.f9339m);
        } else if (i6 == 1 || i6 == 2) {
            y.Z(v2, top - v2.getTop());
        }
        this.f3342b = new WeakReference<>(e0(v2));
        for (int i7 = 0; i7 < this.f3338a.size(); i7++) {
            this.f3338a.get(i7).a(v2);
        }
        return true;
    }

    public final float l0() {
        VelocityTracker velocityTracker = this.f3333a;
        if (velocityTracker == null) {
            return 0.0f;
        }
        velocityTracker.computeCurrentVelocity(1000, this.f9327a);
        return this.f3333a.getYVelocity(this.f9346t);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean m(CoordinatorLayout coordinatorLayout, V v2, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) v2.getLayoutParams();
        v2.measure(g0(i2, coordinatorLayout.getPaddingLeft() + coordinatorLayout.getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, this.f9331e, marginLayoutParams.width), g0(i4, coordinatorLayout.getPaddingTop() + coordinatorLayout.getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, this.f9332f, marginLayoutParams.height));
        return true;
    }

    public boolean m0() {
        return this.f3346d;
    }

    public boolean n0() {
        return this.f3355m;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean o(CoordinatorLayout coordinatorLayout, V v2, View view, float f2, float f3) {
        WeakReference<View> weakReference;
        if (p0() && (weakReference = this.f3342b) != null && view == weakReference.get()) {
            return this.f9340n != 3 || super.o(coordinatorLayout, v2, view, f2, f3);
        }
        return false;
    }

    public final boolean o0(V v2) {
        ViewParent parent = v2.getParent();
        return parent != null && parent.isLayoutRequested() && y.R(v2);
    }

    public boolean p0() {
        return true;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void q(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 1) {
            return;
        }
        WeakReference<View> weakReference = this.f3342b;
        View view2 = weakReference != null ? weakReference.get() : null;
        if (!p0() || view == view2) {
            int top = v2.getTop();
            int i5 = top - i3;
            if (i3 > 0) {
                if (i5 < h0()) {
                    int iH0 = top - h0();
                    iArr[1] = iH0;
                    y.Z(v2, -iH0);
                    I0(3);
                } else {
                    if (!this.f3357o) {
                        return;
                    }
                    iArr[1] = i3;
                    y.Z(v2, -i3);
                    I0(1);
                }
            } else if (i3 < 0 && !view.canScrollVertically(-1)) {
                int i6 = this.f9339m;
                if (i5 > i6 && !this.f3355m) {
                    int i7 = top - i6;
                    iArr[1] = i7;
                    y.Z(v2, -i7);
                    I0(4);
                } else {
                    if (!this.f3357o) {
                        return;
                    }
                    iArr[1] = i3;
                    y.Z(v2, -i3);
                    I0(1);
                }
            }
            d0(v2.getTop());
            this.f9342p = i3;
            this.f3359q = true;
        }
    }

    public void q0(com2 com2Var) {
        this.f3338a.remove(com2Var);
    }

    public final void r0(V v2, e2.aux auxVar, int i2) {
        y.k0(v2, auxVar, null, a0(i2));
    }

    public final void s0() {
        this.f9346t = -1;
        VelocityTracker velocityTracker = this.f3333a;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f3333a = null;
        }
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void t(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
    }

    public final void t0(com3 com3Var) {
        int i2 = this.f3328a;
        if (i2 == 0) {
            return;
        }
        if (i2 == -1 || (i2 & 1) == 1) {
            this.f3341b = com3Var.f9352b;
        }
        if (i2 == -1 || (i2 & 2) == 2) {
            this.f3340a = com3Var.f3364b;
        }
        if (i2 == -1 || (i2 & 4) == 4) {
            this.f3355m = com3Var.f9353c;
        }
        if (i2 == -1 || (i2 & 8) == 8) {
            this.f3356n = com3Var.f9354d;
        }
    }

    public final void u0(V v2, Runnable runnable) {
        if (o0(v2)) {
            v2.post(runnable);
        } else {
            runnable.run();
        }
    }

    public void v0(boolean z2) {
        this.f3357o = z2;
    }

    public void w0(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("offset must be greater than or equal to 0");
        }
        this.f9336j = i2;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void x(CoordinatorLayout coordinatorLayout, V v2, Parcelable parcelable) {
        com3 com3Var = (com3) parcelable;
        super.x(coordinatorLayout, v2, com3Var.k());
        t0(com3Var);
        int i2 = com3Var.f9351a;
        if (i2 == 1 || i2 == 2) {
            this.f9340n = 4;
            this.f9341o = 4;
        } else {
            this.f9340n = i2;
            this.f9341o = i2;
        }
    }

    public void x0(boolean z2) {
        if (this.f3340a == z2) {
            return;
        }
        this.f3340a = z2;
        if (this.f3337a != null) {
            X();
        }
        I0((this.f3340a && this.f9340n == 6) ? 3 : this.f9340n);
        Q0();
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public Parcelable y(CoordinatorLayout coordinatorLayout, V v2) {
        return new com3(super.y(coordinatorLayout, v2), (BottomSheetBehavior<?>) this);
    }

    public void y0(boolean z2) {
        this.f3346d = z2;
    }

    public void z0(float f2) {
        if (f2 <= 0.0f || f2 >= 1.0f) {
            throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
        }
        this.f9328b = f2;
        if (this.f3337a != null) {
            Y();
        }
    }

    public class com4 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9355a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Runnable f3366a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f3367a;

        public class aux implements Runnable {
            public aux() {
            }

            @Override // java.lang.Runnable
            public void run() {
                com4.this.f3367a = false;
                p0 p0Var = BottomSheetBehavior.this.f3336a;
                if (p0Var != null && p0Var.l(true)) {
                    com4 com4Var = com4.this;
                    com4Var.c(com4Var.f9355a);
                    return;
                }
                com4 com4Var2 = com4.this;
                BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
                if (bottomSheetBehavior.f9340n == 2) {
                    bottomSheetBehavior.I0(com4Var2.f9355a);
                }
            }
        }

        public com4() {
            this.f3366a = new aux();
        }

        public void c(int i2) {
            WeakReference<V> weakReference = BottomSheetBehavior.this.f3337a;
            if (weakReference == null || weakReference.get() == null) {
                return;
            }
            this.f9355a = i2;
            if (this.f3367a) {
                return;
            }
            y.g0(BottomSheetBehavior.this.f3337a.get(), this.f3366a);
            this.f3367a = true;
        }

        public /* synthetic */ com4(BottomSheetBehavior bottomSheetBehavior, aux auxVar) {
            this();
        }
    }

    public static class com3 extends COM2.aux {
        public static final Parcelable.Creator<com3> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f9351a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f9352b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f3364b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f9353c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f9354d;

        public class aux implements Parcelable.ClassLoaderCreator<com3> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com3 createFromParcel(Parcel parcel) {
                return new com3(parcel, (ClassLoader) null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com3 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com3(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com3[] newArray(int i2) {
                return new com3[i2];
            }
        }

        public com3(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f9351a = parcel.readInt();
            this.f9352b = parcel.readInt();
            this.f3364b = parcel.readInt() == 1;
            this.f9353c = parcel.readInt() == 1;
            this.f9354d = parcel.readInt() == 1;
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f9351a);
            parcel.writeInt(this.f9352b);
            parcel.writeInt(this.f3364b ? 1 : 0);
            parcel.writeInt(this.f9353c ? 1 : 0);
            parcel.writeInt(this.f9354d ? 1 : 0);
        }

        public com3(Parcelable parcelable, BottomSheetBehavior<?> bottomSheetBehavior) {
            super(parcelable);
            this.f9351a = bottomSheetBehavior.f9340n;
            this.f9352b = bottomSheetBehavior.f3341b;
            this.f3364b = bottomSheetBehavior.f3340a;
            this.f9353c = bottomSheetBehavior.f3355m;
            this.f9354d = bottomSheetBehavior.f3356n;
        }
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        int i2;
        super(context, attributeSet);
        this.f3328a = 0;
        this.f3340a = true;
        this.f3343b = false;
        this.f9331e = -1;
        this.f9332f = -1;
        this.f3334a = new com4(this, null);
        this.f9328b = 0.5f;
        this.f9329c = -1.0f;
        this.f3357o = true;
        this.f9340n = 4;
        this.f9341o = 4;
        this.f3338a = new ArrayList<>();
        this.f9348v = -1;
        this.f3335a = new prn();
        this.f9330d = context.getResources().getDimensionPixelSize(z3.T);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3173w);
        int i3 = h4.f9014s;
        if (typedArrayObtainStyledAttributes.hasValue(i3)) {
            this.f3332a = b.b(context, typedArrayObtainStyledAttributes, i3);
        }
        if (typedArrayObtainStyledAttributes.hasValue(h4.J)) {
            this.f3330a = com7.e(context, attributeSet, x3.f9029d, f9326w).m();
        }
        b0(context);
        c0();
        this.f9329c = typedArrayObtainStyledAttributes.getDimension(h4.f9013r, -1.0f);
        int i4 = h4.f9011p;
        if (typedArrayObtainStyledAttributes.hasValue(i4)) {
            C0(typedArrayObtainStyledAttributes.getDimensionPixelSize(i4, -1));
        }
        int i5 = h4.f9012q;
        if (typedArrayObtainStyledAttributes.hasValue(i5)) {
            B0(typedArrayObtainStyledAttributes.getDimensionPixelSize(i5, -1));
        }
        int i6 = h4.f9020y;
        TypedValue typedValuePeekValue = typedArrayObtainStyledAttributes.peekValue(i6);
        if (typedValuePeekValue != null && (i2 = typedValuePeekValue.data) == -1) {
            D0(i2);
        } else {
            D0(typedArrayObtainStyledAttributes.getDimensionPixelSize(i6, -1));
        }
        A0(typedArrayObtainStyledAttributes.getBoolean(h4.f9019x, false));
        y0(typedArrayObtainStyledAttributes.getBoolean(h4.B, false));
        x0(typedArrayObtainStyledAttributes.getBoolean(h4.f9017v, true));
        G0(typedArrayObtainStyledAttributes.getBoolean(h4.A, false));
        v0(typedArrayObtainStyledAttributes.getBoolean(h4.f9015t, true));
        F0(typedArrayObtainStyledAttributes.getInt(h4.f9021z, 0));
        z0(typedArrayObtainStyledAttributes.getFloat(h4.f9018w, 0.5f));
        int i7 = h4.f9016u;
        TypedValue typedValuePeekValue2 = typedArrayObtainStyledAttributes.peekValue(i7);
        if (typedValuePeekValue2 != null && typedValuePeekValue2.type == 16) {
            w0(typedValuePeekValue2.data);
        } else {
            w0(typedArrayObtainStyledAttributes.getDimensionPixelOffset(i7, 0));
        }
        this.f3347e = typedArrayObtainStyledAttributes.getBoolean(h4.F, false);
        this.f3348f = typedArrayObtainStyledAttributes.getBoolean(h4.G, false);
        this.f3349g = typedArrayObtainStyledAttributes.getBoolean(h4.H, false);
        this.f3350h = typedArrayObtainStyledAttributes.getBoolean(h4.I, true);
        this.f3351i = typedArrayObtainStyledAttributes.getBoolean(h4.C, false);
        this.f3352j = typedArrayObtainStyledAttributes.getBoolean(h4.D, false);
        this.f3353k = typedArrayObtainStyledAttributes.getBoolean(h4.E, false);
        typedArrayObtainStyledAttributes.recycle();
        this.f9327a = ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }
}
