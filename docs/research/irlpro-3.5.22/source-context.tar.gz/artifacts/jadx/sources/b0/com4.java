package b0;

import f.com8;
import i0.BufferedSource;
import v.b;
import v.h;

/* JADX INFO: loaded from: classes.dex */
public final class com4 extends h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f8796a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final BufferedSource f2992a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final String f2993a;

    public com4(String str, long j2, BufferedSource bufferedSource) {
        com8.e(bufferedSource, "source");
        this.f2993a = str;
        this.f8796a = j2;
        this.f2992a = bufferedSource;
    }

    @Override // v.h
    public long contentLength() {
        return this.f8796a;
    }

    @Override // v.h
    public b contentType() {
        String str = this.f2993a;
        if (str == null) {
            return null;
        }
        return b.f5297a.b(str);
    }

    @Override // v.h
    public BufferedSource source() {
        return this.f2992a;
    }
}
