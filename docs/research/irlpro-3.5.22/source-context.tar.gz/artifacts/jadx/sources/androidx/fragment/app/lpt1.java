package androidx.fragment.app;

import COM3.lpt7;
import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import p024Com2.y;
import p092coM3.l0;

/* JADX INFO: loaded from: classes.dex */
public class lpt1 {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Fragment f2500a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com5 f2501a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt2 f2502a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2503a = false;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8293a = -1;

    public class aux implements View.OnAttachStateChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8294a;

        public aux(View view) {
            this.f8294a = view;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            this.f8294a.removeOnAttachStateChangeListener(this);
            y.l0(this.f8294a);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    public static /* synthetic */ class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8295a;

        static {
            int[] iArr = new int[androidx.lifecycle.nul.EnumC0039nul.values().length];
            f8295a = iArr;
            try {
                iArr[androidx.lifecycle.nul.EnumC0039nul.RESUMED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8295a[androidx.lifecycle.nul.EnumC0039nul.STARTED.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8295a[androidx.lifecycle.nul.EnumC0039nul.CREATED.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f8295a[androidx.lifecycle.nul.EnumC0039nul.INITIALIZED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public lpt1(com5 com5Var, lpt2 lpt2Var, Fragment fragment) {
        this.f2501a = com5Var;
        this.f2502a = lpt2Var;
        this.f2500a = fragment;
    }

    public void a() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + this.f2500a);
        }
        Fragment fragment = this.f2500a;
        fragment.performActivityCreated(fragment.mSavedFragmentState);
        com5 com5Var = this.f2501a;
        Fragment fragment2 = this.f2500a;
        com5Var.a(fragment2, fragment2.mSavedFragmentState, false);
    }

    public void b() {
        int iJ = this.f2502a.j(this.f2500a);
        Fragment fragment = this.f2500a;
        fragment.mContainer.addView(fragment.mView, iJ);
    }

    public void c() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "moveto ATTACHED: " + this.f2500a);
        }
        Fragment fragment = this.f2500a;
        Fragment fragment2 = fragment.mTarget;
        lpt1 lpt1VarM = null;
        if (fragment2 != null) {
            lpt1 lpt1VarM2 = this.f2502a.m(fragment2.mWho);
            if (lpt1VarM2 == null) {
                throw new IllegalStateException("Fragment " + this.f2500a + " declared target fragment " + this.f2500a.mTarget + " that does not belong to this FragmentManager!");
            }
            Fragment fragment3 = this.f2500a;
            fragment3.mTargetWho = fragment3.mTarget.mWho;
            fragment3.mTarget = null;
            lpt1VarM = lpt1VarM2;
        } else {
            String str = fragment.mTargetWho;
            if (str != null && (lpt1VarM = this.f2502a.m(str)) == null) {
                throw new IllegalStateException("Fragment " + this.f2500a + " declared target fragment " + this.f2500a.mTargetWho + " that does not belong to this FragmentManager!");
            }
        }
        if (lpt1VarM != null && (com6.f8252h || lpt1VarM.k().mState < 1)) {
            lpt1VarM.m();
        }
        Fragment fragment4 = this.f2500a;
        fragment4.mHost = fragment4.mFragmentManager.v0();
        Fragment fragment5 = this.f2500a;
        fragment5.mParentFragment = fragment5.mFragmentManager.y0();
        this.f2501a.g(this.f2500a, false);
        this.f2500a.performAttach();
        this.f2501a.b(this.f2500a, false);
    }

    public int d() {
        Fragment fragment;
        ViewGroup viewGroup;
        Fragment fragment2 = this.f2500a;
        if (fragment2.mFragmentManager == null) {
            return fragment2.mState;
        }
        int iMin = this.f8293a;
        int i2 = con.f8295a[fragment2.mMaxState.ordinal()];
        if (i2 != 1) {
            if (i2 == 2) {
                iMin = Math.min(iMin, 5);
            } else if (i2 != 3) {
                iMin = i2 != 4 ? Math.min(iMin, -1) : Math.min(iMin, 0);
            } else {
                iMin = Math.min(iMin, 1);
            }
        }
        Fragment fragment3 = this.f2500a;
        if (fragment3.mFromLayout) {
            if (fragment3.mInLayout) {
                iMin = Math.max(this.f8293a, 2);
                View view = this.f2500a.mView;
                if (view != null && view.getParent() == null) {
                    iMin = Math.min(iMin, 2);
                }
            } else {
                iMin = this.f8293a < 4 ? Math.min(iMin, fragment3.mState) : Math.min(iMin, 1);
            }
        }
        if (!this.f2500a.mAdded) {
            iMin = Math.min(iMin, 1);
        }
        lpt5.com1.con conVarL = (!com6.f8252h || (viewGroup = (fragment = this.f2500a).mContainer) == null) ? null : lpt5.o(viewGroup, fragment.getParentFragmentManager()).l(this);
        if (conVarL == lpt5.com1.con.ADDING) {
            iMin = Math.min(iMin, 6);
        } else if (conVarL == lpt5.com1.con.REMOVING) {
            iMin = Math.max(iMin, 3);
        } else {
            Fragment fragment4 = this.f2500a;
            if (fragment4.mRemoving) {
                iMin = fragment4.isInBackStack() ? Math.min(iMin, 1) : Math.min(iMin, -1);
            }
        }
        Fragment fragment5 = this.f2500a;
        if (fragment5.mDeferStart && fragment5.mState < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (com6.H0(2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + iMin + " for " + this.f2500a);
        }
        return iMin;
    }

    public void e() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "moveto CREATED: " + this.f2500a);
        }
        Fragment fragment = this.f2500a;
        if (fragment.mIsCreated) {
            fragment.restoreChildFragmentState(fragment.mSavedFragmentState);
            this.f2500a.mState = 1;
            return;
        }
        this.f2501a.h(fragment, fragment.mSavedFragmentState, false);
        Fragment fragment2 = this.f2500a;
        fragment2.performCreate(fragment2.mSavedFragmentState);
        com5 com5Var = this.f2501a;
        Fragment fragment3 = this.f2500a;
        com5Var.c(fragment3, fragment3.mSavedFragmentState, false);
    }

    public void f() {
        String resourceName;
        if (this.f2500a.mFromLayout) {
            return;
        }
        if (com6.H0(3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.f2500a);
        }
        Fragment fragment = this.f2500a;
        LayoutInflater layoutInflaterPerformGetLayoutInflater = fragment.performGetLayoutInflater(fragment.mSavedFragmentState);
        Fragment fragment2 = this.f2500a;
        ViewGroup viewGroup = fragment2.mContainer;
        if (viewGroup == null) {
            int i2 = fragment2.mContainerId;
            if (i2 == 0) {
                viewGroup = null;
            } else {
                if (i2 == -1) {
                    throw new IllegalArgumentException("Cannot create fragment " + this.f2500a + " for a container view with no id");
                }
                viewGroup = (ViewGroup) fragment2.mFragmentManager.q0().c(this.f2500a.mContainerId);
                if (viewGroup == null) {
                    Fragment fragment3 = this.f2500a;
                    if (!fragment3.mRestored) {
                        try {
                            resourceName = fragment3.getResources().getResourceName(this.f2500a.mContainerId);
                        } catch (Resources.NotFoundException unused) {
                            resourceName = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(this.f2500a.mContainerId) + " (" + resourceName + ") for fragment " + this.f2500a);
                    }
                }
            }
        }
        Fragment fragment4 = this.f2500a;
        fragment4.mContainer = viewGroup;
        fragment4.performCreateView(layoutInflaterPerformGetLayoutInflater, viewGroup, fragment4.mSavedFragmentState);
        View view = this.f2500a.mView;
        if (view != null) {
            boolean z2 = false;
            view.setSaveFromParentEnabled(false);
            Fragment fragment5 = this.f2500a;
            fragment5.mView.setTag(l0.f9199a, fragment5);
            if (viewGroup != null) {
                b();
            }
            Fragment fragment6 = this.f2500a;
            if (fragment6.mHidden) {
                fragment6.mView.setVisibility(8);
            }
            if (y.R(this.f2500a.mView)) {
                y.l0(this.f2500a.mView);
            } else {
                View view2 = this.f2500a.mView;
                view2.addOnAttachStateChangeListener(new aux(view2));
            }
            this.f2500a.performViewCreated();
            com5 com5Var = this.f2501a;
            Fragment fragment7 = this.f2500a;
            com5Var.m(fragment7, fragment7.mView, fragment7.mSavedFragmentState, false);
            int visibility = this.f2500a.mView.getVisibility();
            float alpha = this.f2500a.mView.getAlpha();
            if (com6.f8252h) {
                this.f2500a.setPostOnViewCreatedAlpha(alpha);
                Fragment fragment8 = this.f2500a;
                if (fragment8.mContainer != null && visibility == 0) {
                    View viewFindFocus = fragment8.mView.findFocus();
                    if (viewFindFocus != null) {
                        this.f2500a.setFocusedView(viewFindFocus);
                        if (com6.H0(2)) {
                            Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + this.f2500a);
                        }
                    }
                    this.f2500a.mView.setAlpha(0.0f);
                }
            } else {
                Fragment fragment9 = this.f2500a;
                if (visibility == 0 && fragment9.mContainer != null) {
                    z2 = true;
                }
                fragment9.mIsNewlyAdded = z2;
            }
        }
        this.f2500a.mState = 2;
    }

    public void g() {
        Fragment fragmentF;
        if (com6.H0(3)) {
            Log.d("FragmentManager", "movefrom CREATED: " + this.f2500a);
        }
        Fragment fragment = this.f2500a;
        boolean zIsChangingConfigurations = true;
        boolean z2 = fragment.mRemoving && !fragment.isInBackStack();
        if (!(z2 || this.f2502a.o().p(this.f2500a))) {
            String str = this.f2500a.mTargetWho;
            if (str != null && (fragmentF = this.f2502a.f(str)) != null && fragmentF.mRetainInstance) {
                this.f2500a.mTarget = fragmentF;
            }
            this.f2500a.mState = 0;
            return;
        }
        com3<?> com3Var = this.f2500a.mHost;
        if (com3Var instanceof lpt7) {
            zIsChangingConfigurations = this.f2502a.o().m();
        } else if (com3Var.f() instanceof Activity) {
            zIsChangingConfigurations = true ^ ((Activity) com3Var.f()).isChangingConfigurations();
        }
        if (z2 || zIsChangingConfigurations) {
            this.f2502a.o().g(this.f2500a);
        }
        this.f2500a.performDestroy();
        this.f2501a.d(this.f2500a, false);
        for (lpt1 lpt1Var : this.f2502a.k()) {
            if (lpt1Var != null) {
                Fragment fragmentK = lpt1Var.k();
                if (this.f2500a.mWho.equals(fragmentK.mTargetWho)) {
                    fragmentK.mTarget = this.f2500a;
                    fragmentK.mTargetWho = null;
                }
            }
        }
        Fragment fragment2 = this.f2500a;
        String str2 = fragment2.mTargetWho;
        if (str2 != null) {
            fragment2.mTarget = this.f2502a.f(str2);
        }
        this.f2502a.q(this);
    }

    public void h() {
        View view;
        if (com6.H0(3)) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + this.f2500a);
        }
        Fragment fragment = this.f2500a;
        ViewGroup viewGroup = fragment.mContainer;
        if (viewGroup != null && (view = fragment.mView) != null) {
            viewGroup.removeView(view);
        }
        this.f2500a.performDestroyView();
        this.f2501a.n(this.f2500a, false);
        Fragment fragment2 = this.f2500a;
        fragment2.mContainer = null;
        fragment2.mView = null;
        fragment2.mViewLifecycleOwner = null;
        fragment2.mViewLifecycleOwnerLiveData.i(null);
        this.f2500a.mInLayout = false;
    }

    public void i() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + this.f2500a);
        }
        this.f2500a.performDetach();
        boolean z2 = false;
        this.f2501a.e(this.f2500a, false);
        Fragment fragment = this.f2500a;
        fragment.mState = -1;
        fragment.mHost = null;
        fragment.mParentFragment = null;
        fragment.mFragmentManager = null;
        if (fragment.mRemoving && !fragment.isInBackStack()) {
            z2 = true;
        }
        if (z2 || this.f2502a.o().p(this.f2500a)) {
            if (com6.H0(3)) {
                Log.d("FragmentManager", "initState called for fragment: " + this.f2500a);
            }
            this.f2500a.initState();
        }
    }

    public void j() {
        Fragment fragment = this.f2500a;
        if (fragment.mFromLayout && fragment.mInLayout && !fragment.mPerformedCreateView) {
            if (com6.H0(3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + this.f2500a);
            }
            Fragment fragment2 = this.f2500a;
            fragment2.performCreateView(fragment2.performGetLayoutInflater(fragment2.mSavedFragmentState), null, this.f2500a.mSavedFragmentState);
            View view = this.f2500a.mView;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                Fragment fragment3 = this.f2500a;
                fragment3.mView.setTag(l0.f9199a, fragment3);
                Fragment fragment4 = this.f2500a;
                if (fragment4.mHidden) {
                    fragment4.mView.setVisibility(8);
                }
                this.f2500a.performViewCreated();
                com5 com5Var = this.f2501a;
                Fragment fragment5 = this.f2500a;
                com5Var.m(fragment5, fragment5.mView, fragment5.mSavedFragmentState, false);
                this.f2500a.mState = 2;
            }
        }
    }

    public Fragment k() {
        return this.f2500a;
    }

    public final boolean l(View view) {
        if (view == this.f2500a.mView) {
            return true;
        }
        for (ViewParent parent = view.getParent(); parent != null; parent = parent.getParent()) {
            if (parent == this.f2500a.mView) {
                return true;
            }
        }
        return false;
    }

    public void m() {
        ViewGroup viewGroup;
        ViewGroup viewGroup2;
        ViewGroup viewGroup3;
        if (this.f2503a) {
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Ignoring re-entrant call to moveToExpectedState() for " + k());
                return;
            }
            return;
        }
        try {
            this.f2503a = true;
            while (true) {
                int iD = d();
                Fragment fragment = this.f2500a;
                int i2 = fragment.mState;
                if (iD == i2) {
                    if (com6.f8252h && fragment.mHiddenChanged) {
                        if (fragment.mView != null && (viewGroup = fragment.mContainer) != null) {
                            lpt5 lpt5VarO = lpt5.o(viewGroup, fragment.getParentFragmentManager());
                            if (this.f2500a.mHidden) {
                                lpt5VarO.c(this);
                            } else {
                                lpt5VarO.e(this);
                            }
                        }
                        Fragment fragment2 = this.f2500a;
                        com6 com6Var = fragment2.mFragmentManager;
                        if (com6Var != null) {
                            com6Var.F0(fragment2);
                        }
                        Fragment fragment3 = this.f2500a;
                        fragment3.mHiddenChanged = false;
                        fragment3.onHiddenChanged(fragment3.mHidden);
                    }
                    return;
                }
                if (iD <= i2) {
                    switch (i2 - 1) {
                        case -1:
                            i();
                            break;
                        case 0:
                            g();
                            break;
                        case 1:
                            h();
                            this.f2500a.mState = 1;
                            break;
                        case 2:
                            fragment.mInLayout = false;
                            fragment.mState = 2;
                            break;
                        case 3:
                            if (com6.H0(3)) {
                                Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + this.f2500a);
                            }
                            Fragment fragment4 = this.f2500a;
                            if (fragment4.mView != null && fragment4.mSavedViewState == null) {
                                s();
                            }
                            Fragment fragment5 = this.f2500a;
                            if (fragment5.mView != null && (viewGroup3 = fragment5.mContainer) != null) {
                                lpt5.o(viewGroup3, fragment5.getParentFragmentManager()).d(this);
                            }
                            this.f2500a.mState = 3;
                            break;
                        case 4:
                            v();
                            break;
                        case 5:
                            fragment.mState = 5;
                            break;
                        case 6:
                            n();
                            break;
                    }
                } else {
                    switch (i2 + 1) {
                        case 0:
                            c();
                            break;
                        case 1:
                            e();
                            break;
                        case 2:
                            j();
                            f();
                            break;
                        case 3:
                            a();
                            break;
                        case 4:
                            if (fragment.mView != null && (viewGroup2 = fragment.mContainer) != null) {
                                lpt5.o(viewGroup2, fragment.getParentFragmentManager()).b(lpt5.com1.nul.c(this.f2500a.mView.getVisibility()), this);
                            }
                            this.f2500a.mState = 4;
                            break;
                        case 5:
                            u();
                            break;
                        case 6:
                            fragment.mState = 6;
                            break;
                        case 7:
                            p();
                            break;
                    }
                }
            }
        } finally {
            this.f2503a = false;
        }
    }

    public void n() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "movefrom RESUMED: " + this.f2500a);
        }
        this.f2500a.performPause();
        this.f2501a.f(this.f2500a, false);
    }

    public void o(ClassLoader classLoader) {
        Bundle bundle = this.f2500a.mSavedFragmentState;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        Fragment fragment = this.f2500a;
        fragment.mSavedViewState = fragment.mSavedFragmentState.getSparseParcelableArray("android:view_state");
        Fragment fragment2 = this.f2500a;
        fragment2.mSavedViewRegistryState = fragment2.mSavedFragmentState.getBundle("android:view_registry_state");
        Fragment fragment3 = this.f2500a;
        fragment3.mTargetWho = fragment3.mSavedFragmentState.getString("android:target_state");
        Fragment fragment4 = this.f2500a;
        if (fragment4.mTargetWho != null) {
            fragment4.mTargetRequestCode = fragment4.mSavedFragmentState.getInt("android:target_req_state", 0);
        }
        Fragment fragment5 = this.f2500a;
        Boolean bool = fragment5.mSavedUserVisibleHint;
        if (bool != null) {
            fragment5.mUserVisibleHint = bool.booleanValue();
            this.f2500a.mSavedUserVisibleHint = null;
        } else {
            fragment5.mUserVisibleHint = fragment5.mSavedFragmentState.getBoolean("android:user_visible_hint", true);
        }
        Fragment fragment6 = this.f2500a;
        if (fragment6.mUserVisibleHint) {
            return;
        }
        fragment6.mDeferStart = true;
    }

    public void p() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "moveto RESUMED: " + this.f2500a);
        }
        View focusedView = this.f2500a.getFocusedView();
        if (focusedView != null && l(focusedView)) {
            boolean zRequestFocus = focusedView.requestFocus();
            if (com6.H0(2)) {
                StringBuilder sb = new StringBuilder();
                sb.append("requestFocus: Restoring focused view ");
                sb.append(focusedView);
                sb.append(" ");
                sb.append(zRequestFocus ? "succeeded" : "failed");
                sb.append(" on Fragment ");
                sb.append(this.f2500a);
                sb.append(" resulting in focused view ");
                sb.append(this.f2500a.mView.findFocus());
                Log.v("FragmentManager", sb.toString());
            }
        }
        this.f2500a.setFocusedView(null);
        this.f2500a.performResume();
        this.f2501a.i(this.f2500a, false);
        Fragment fragment = this.f2500a;
        fragment.mSavedFragmentState = null;
        fragment.mSavedViewState = null;
        fragment.mSavedViewRegistryState = null;
    }

    public final Bundle q() {
        Bundle bundle = new Bundle();
        this.f2500a.performSaveInstanceState(bundle);
        this.f2501a.j(this.f2500a, bundle, false);
        if (bundle.isEmpty()) {
            bundle = null;
        }
        if (this.f2500a.mView != null) {
            s();
        }
        if (this.f2500a.mSavedViewState != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putSparseParcelableArray("android:view_state", this.f2500a.mSavedViewState);
        }
        if (this.f2500a.mSavedViewRegistryState != null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBundle("android:view_registry_state", this.f2500a.mSavedViewRegistryState);
        }
        if (!this.f2500a.mUserVisibleHint) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("android:user_visible_hint", this.f2500a.mUserVisibleHint);
        }
        return bundle;
    }

    public com9 r() {
        com9 com9Var = new com9(this.f2500a);
        Fragment fragment = this.f2500a;
        if (fragment.mState <= -1 || com9Var.f2485b != null) {
            com9Var.f2485b = fragment.mSavedFragmentState;
        } else {
            Bundle bundleQ = q();
            com9Var.f2485b = bundleQ;
            if (this.f2500a.mTargetWho != null) {
                if (bundleQ == null) {
                    com9Var.f2485b = new Bundle();
                }
                com9Var.f2485b.putString("android:target_state", this.f2500a.mTargetWho);
                int i2 = this.f2500a.mTargetRequestCode;
                if (i2 != 0) {
                    com9Var.f2485b.putInt("android:target_req_state", i2);
                }
            }
        }
        return com9Var;
    }

    public void s() {
        if (this.f2500a.mView == null) {
            return;
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        this.f2500a.mView.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            this.f2500a.mSavedViewState = sparseArray;
        }
        Bundle bundle = new Bundle();
        this.f2500a.mViewLifecycleOwner.e(bundle);
        if (bundle.isEmpty()) {
            return;
        }
        this.f2500a.mSavedViewRegistryState = bundle;
    }

    public void t(int i2) {
        this.f8293a = i2;
    }

    public void u() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "moveto STARTED: " + this.f2500a);
        }
        this.f2500a.performStart();
        this.f2501a.k(this.f2500a, false);
    }

    public void v() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "movefrom STARTED: " + this.f2500a);
        }
        this.f2500a.performStop();
        this.f2501a.l(this.f2500a, false);
    }

    public lpt1(com5 com5Var, lpt2 lpt2Var, ClassLoader classLoader, com2 com2Var, com9 com9Var) {
        this.f2501a = com5Var;
        this.f2502a = lpt2Var;
        Fragment fragmentA = com2Var.a(classLoader, com9Var.f2484a);
        this.f2500a = fragmentA;
        Bundle bundle = com9Var.f2483a;
        if (bundle != null) {
            bundle.setClassLoader(classLoader);
        }
        fragmentA.setArguments(com9Var.f2483a);
        fragmentA.mWho = com9Var.f2486b;
        fragmentA.mFromLayout = com9Var.f2487b;
        fragmentA.mRestored = true;
        fragmentA.mFragmentId = com9Var.f8283a;
        fragmentA.mContainerId = com9Var.f8284b;
        fragmentA.mTag = com9Var.f2488c;
        fragmentA.mRetainInstance = com9Var.f2489c;
        fragmentA.mRemoving = com9Var.f8286d;
        fragmentA.mDetached = com9Var.f8287e;
        fragmentA.mHidden = com9Var.f8288f;
        fragmentA.mMaxState = androidx.lifecycle.nul.EnumC0039nul.values()[com9Var.f8285c];
        Bundle bundle2 = com9Var.f2485b;
        if (bundle2 != null) {
            fragmentA.mSavedFragmentState = bundle2;
        } else {
            fragmentA.mSavedFragmentState = new Bundle();
        }
        if (com6.H0(2)) {
            Log.v("FragmentManager", "Instantiated fragment " + fragmentA);
        }
    }

    public lpt1(com5 com5Var, lpt2 lpt2Var, Fragment fragment, com9 com9Var) {
        this.f2501a = com5Var;
        this.f2502a = lpt2Var;
        this.f2500a = fragment;
        fragment.mSavedViewState = null;
        fragment.mSavedViewRegistryState = null;
        fragment.mBackStackNesting = 0;
        fragment.mInLayout = false;
        fragment.mAdded = false;
        Fragment fragment2 = fragment.mTarget;
        fragment.mTargetWho = fragment2 != null ? fragment2.mWho : null;
        fragment.mTarget = null;
        Bundle bundle = com9Var.f2485b;
        if (bundle != null) {
            fragment.mSavedFragmentState = bundle;
        } else {
            fragment.mSavedFragmentState = new Bundle();
        }
    }
}
