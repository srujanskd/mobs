package androidx.fragment.app;

import COM3.lpt6;
import COM3.lpt7;
import COM3.lpt8;
import COM3.lpt9;
import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.LiveData;
import androidx.savedstate.SavedStateRegistry;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import p015CoM3.i;
import p015CoM3.o;
import p015CoM3.r;
import p024Com2.h;
import p068auX.k;
import p083cOm4.c;
import p149nul.l0;
import p150pRN.a;
import p150pRN.c0;

/* JADX INFO: loaded from: classes.dex */
public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, COM3.com7, lpt7, COM4.con {
    static final int ACTIVITY_CREATED = 4;
    static final int ATTACHED = 0;
    static final int AWAITING_ENTER_EFFECTS = 6;
    static final int AWAITING_EXIT_EFFECTS = 3;
    static final int CREATED = 1;
    static final int INITIALIZING = -1;
    static final int RESUMED = 7;
    static final int STARTED = 5;
    static final Object USE_DEFAULT_TRANSITION = new Object();
    static final int VIEW_CREATED = 2;
    boolean mAdded;
    com5 mAnimationInfo;
    Bundle mArguments;
    int mBackStackNesting;
    private boolean mCalled;
    androidx.fragment.app.com6 mChildFragmentManager;
    ViewGroup mContainer;
    int mContainerId;
    private int mContentLayoutId;
    androidx.lifecycle.com7.con mDefaultFactory;
    boolean mDeferStart;
    boolean mDetached;
    int mFragmentId;
    androidx.fragment.app.com6 mFragmentManager;
    boolean mFromLayout;
    boolean mHasMenu;
    boolean mHidden;
    boolean mHiddenChanged;
    androidx.fragment.app.com3<?> mHost;
    boolean mInLayout;
    boolean mIsCreated;
    boolean mIsNewlyAdded;
    private Boolean mIsPrimaryNavigationFragment;
    LayoutInflater mLayoutInflater;
    androidx.lifecycle.com1 mLifecycleRegistry;
    androidx.lifecycle.nul.EnumC0039nul mMaxState;
    boolean mMenuVisible;
    private final AtomicInteger mNextLocalRequestCode;
    private final ArrayList<com7> mOnPreAttachedListeners;
    Fragment mParentFragment;
    boolean mPerformedCreateView;
    float mPostponedAlpha;
    Runnable mPostponedDurationRunnable;
    boolean mRemoving;
    boolean mRestored;
    boolean mRetainInstance;
    boolean mRetainInstanceChangedWhileDetached;
    Bundle mSavedFragmentState;
    androidx.savedstate.aux mSavedStateRegistryController;
    Boolean mSavedUserVisibleHint;
    Bundle mSavedViewRegistryState;
    SparseArray<Parcelable> mSavedViewState;
    int mState;
    String mTag;
    Fragment mTarget;
    int mTargetRequestCode;
    String mTargetWho;
    boolean mUserVisibleHint;
    View mView;
    o mViewLifecycleOwner;
    COM3.lpt1<COM3.com7> mViewLifecycleOwnerLiveData;
    String mWho;

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.startPostponedEnterTransition();
        }
    }

    public class com1 implements l0<Void, ActivityResultRegistry> {
        public com1() {
        }

        @Override // p149nul.l0
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public ActivityResultRegistry apply(Void r3) {
            Fragment fragment = Fragment.this;
            Object obj = fragment.mHost;
            return obj instanceof p000AUx.com1 ? ((p000AUx.com1) obj).E() : fragment.requireActivity().E();
        }
    }

    public class com2 implements l0<Void, ActivityResultRegistry> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ ActivityResultRegistry f8212a;

        public com2(ActivityResultRegistry activityResultRegistry) {
            this.f8212a = activityResultRegistry;
        }

        @Override // p149nul.l0
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public ActivityResultRegistry apply(Void r1) {
            return this.f8212a;
        }
    }

    public class com3 extends com7 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p000AUx.nul f8213a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ k f2384a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ AtomicReference f2385a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ l0 f2386a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public com3(l0 l0Var, AtomicReference atomicReference, k kVar, p000AUx.nul nulVar) {
            super(null);
            this.f2386a = l0Var;
            this.f2385a = atomicReference;
            this.f2384a = kVar;
            this.f8213a = nulVar;
        }

        @Override // androidx.fragment.app.Fragment.com7
        public void a() {
            String strGenerateActivityResultKey = Fragment.this.generateActivityResultKey();
            this.f2385a.set(((ActivityResultRegistry) this.f2386a.apply(null)).i(strGenerateActivityResultKey, Fragment.this, this.f2384a, this.f8213a));
        }
    }

    /* JADX INFO: Add missing generic type declarations: [I] */
    public class com4<I> extends p000AUx.prn<I> {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ k f2387a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ AtomicReference f2388a;

        public com4(AtomicReference atomicReference, k kVar) {
            this.f2388a = atomicReference;
            this.f2387a = kVar;
        }

        @Override // p000AUx.prn
        public void b(I i2, a aVar) {
            p000AUx.prn prnVar = (p000AUx.prn) this.f2388a.get();
            if (prnVar == null) {
                throw new IllegalStateException("Operation cannot be started before fragment is in created state");
            }
            prnVar.b(i2, aVar);
        }

        @Override // p000AUx.prn
        public void c() {
            p000AUx.prn prnVar = (p000AUx.prn) this.f2388a.getAndSet(null);
            if (prnVar != null) {
                prnVar.c();
            }
        }
    }

    public static class com5 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f8215a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2389a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Animator f2390a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f2391a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com8 f2392a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Boolean f2393a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Object f2394a = null;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ArrayList<String> f2395a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2396a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8216b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public View f2397b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public Boolean f2398b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public Object f2399b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public ArrayList<String> f2400b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2401b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8217c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public Object f2402c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2403c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8218d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public Object f2404d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8219e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public Object f2405e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public Object f8220f;

        public com5() {
            Object obj = Fragment.USE_DEFAULT_TRANSITION;
            this.f2399b = obj;
            this.f2402c = null;
            this.f2404d = obj;
            this.f2405e = null;
            this.f8220f = obj;
            this.f8215a = 1.0f;
            this.f2397b = null;
        }
    }

    public static class com6 extends RuntimeException {
        public com6(String str, Exception exc) {
            super(str, exc);
        }
    }

    public static abstract class com7 {
        public com7() {
        }

        public /* synthetic */ com7(aux auxVar) {
            this();
        }

        public abstract void a();
    }

    public interface com8 {
        void a();

        void b();
    }

    @SuppressLint({"BanParcelableUsage, ParcelClassLoader"})
    public static class com9 implements Parcelable {
        public static final Parcelable.Creator<com9> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Bundle f8221a;

        public class aux implements Parcelable.ClassLoaderCreator<com9> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com9 createFromParcel(Parcel parcel) {
                return new com9(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com9 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com9(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com9[] newArray(int i2) {
                return new com9[i2];
            }
        }

        public com9(Parcel parcel, ClassLoader classLoader) {
            Bundle bundle = parcel.readBundle();
            this.f8221a = bundle;
            if (classLoader == null || bundle == null) {
                return;
            }
            bundle.setClassLoader(classLoader);
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeBundle(this.f8221a);
        }
    }

    public class con implements Runnable {
        public con() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Fragment.this.callStartTransitionListener(false);
        }
    }

    public class nul implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ lpt5 f2406a;

        public nul(lpt5 lpt5Var) {
            this.f2406a = lpt5Var;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f2406a.g();
        }
    }

    public class prn extends i {
        public prn() {
        }

        @Override // p015CoM3.i
        public View c(int i2) {
            View view = Fragment.this.mView;
            if (view != null) {
                return view.findViewById(i2);
            }
            throw new IllegalStateException("Fragment " + Fragment.this + " does not have a view");
        }

        @Override // p015CoM3.i
        public boolean d() {
            return Fragment.this.mView != null;
        }
    }

    public Fragment() {
        this.mState = -1;
        this.mWho = UUID.randomUUID().toString();
        this.mTargetWho = null;
        this.mIsPrimaryNavigationFragment = null;
        this.mChildFragmentManager = new p015CoM3.k();
        this.mMenuVisible = true;
        this.mUserVisibleHint = true;
        this.mPostponedDurationRunnable = new aux();
        this.mMaxState = androidx.lifecycle.nul.EnumC0039nul.RESUMED;
        this.mViewLifecycleOwnerLiveData = new COM3.lpt1<>();
        this.mNextLocalRequestCode = new AtomicInteger();
        this.mOnPreAttachedListeners = new ArrayList<>();
        initLifecycle();
    }

    private com5 ensureAnimationInfo() {
        if (this.mAnimationInfo == null) {
            this.mAnimationInfo = new com5();
        }
        return this.mAnimationInfo;
    }

    private int getMinimumMaxLifecycleState() {
        androidx.lifecycle.nul.EnumC0039nul enumC0039nul = this.mMaxState;
        return (enumC0039nul == androidx.lifecycle.nul.EnumC0039nul.INITIALIZED || this.mParentFragment == null) ? enumC0039nul.ordinal() : Math.min(enumC0039nul.ordinal(), this.mParentFragment.getMinimumMaxLifecycleState());
    }

    private void initLifecycle() {
        this.mLifecycleRegistry = new androidx.lifecycle.com1(this);
        this.mSavedStateRegistryController = androidx.savedstate.aux.a(this);
        this.mDefaultFactory = null;
    }

    @Deprecated
    public static Fragment instantiate(Context context, String str) {
        return instantiate(context, str, null);
    }

    private <I, O> p000AUx.prn<I> prepareCallInternal(k<I, O> kVar, l0<Void, ActivityResultRegistry> l0Var, p000AUx.nul<O> nulVar) {
        if (this.mState <= 1) {
            AtomicReference atomicReference = new AtomicReference();
            registerOnPreAttachListener(new com3(l0Var, atomicReference, kVar, nulVar));
            return new com4(atomicReference, kVar);
        }
        throw new IllegalStateException("Fragment " + this + " is attempting to registerForActivityResult after being created. Fragments must call registerForActivityResult() before they are created (i.e. initialization, onAttach(), or onCreate()).");
    }

    private void registerOnPreAttachListener(com7 com7Var) {
        if (this.mState >= 0) {
            com7Var.a();
        } else {
            this.mOnPreAttachedListeners.add(com7Var);
        }
    }

    public void callStartTransitionListener(boolean z2) {
        ViewGroup viewGroup;
        androidx.fragment.app.com6 com6Var;
        com5 com5Var = this.mAnimationInfo;
        com8 com8Var = null;
        if (com5Var != null) {
            com5Var.f2401b = false;
            com8 com8Var2 = com5Var.f2392a;
            com5Var.f2392a = null;
            com8Var = com8Var2;
        }
        if (com8Var != null) {
            com8Var.b();
            return;
        }
        if (!androidx.fragment.app.com6.f8252h || this.mView == null || (viewGroup = this.mContainer) == null || (com6Var = this.mFragmentManager) == null) {
            return;
        }
        lpt5 lpt5VarO = lpt5.o(viewGroup, com6Var);
        lpt5VarO.p();
        if (z2) {
            this.mHost.g().post(new nul(lpt5VarO));
        } else {
            lpt5VarO.g();
        }
    }

    public i createFragmentContainer() {
        return new prn();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.mFragmentId));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.mContainerId));
        printWriter.print(" mTag=");
        printWriter.println(this.mTag);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.mState);
        printWriter.print(" mWho=");
        printWriter.print(this.mWho);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.mBackStackNesting);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.mAdded);
        printWriter.print(" mRemoving=");
        printWriter.print(this.mRemoving);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.mFromLayout);
        printWriter.print(" mInLayout=");
        printWriter.println(this.mInLayout);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.mHidden);
        printWriter.print(" mDetached=");
        printWriter.print(this.mDetached);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.mMenuVisible);
        printWriter.print(" mHasMenu=");
        printWriter.println(this.mHasMenu);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.mRetainInstance);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.mUserVisibleHint);
        if (this.mFragmentManager != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.mFragmentManager);
        }
        if (this.mHost != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.mHost);
        }
        if (this.mParentFragment != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.mParentFragment);
        }
        if (this.mArguments != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.mArguments);
        }
        if (this.mSavedFragmentState != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.mSavedFragmentState);
        }
        if (this.mSavedViewState != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.mSavedViewState);
        }
        if (this.mSavedViewRegistryState != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.mSavedViewRegistryState);
        }
        Fragment targetFragment = getTargetFragment();
        if (targetFragment != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(targetFragment);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.mTargetRequestCode);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        printWriter.println(getPopDirection());
        if (getEnterAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            printWriter.println(getEnterAnim());
        }
        if (getExitAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            printWriter.println(getExitAnim());
        }
        if (getPopEnterAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            printWriter.println(getPopEnterAnim());
        }
        if (getPopExitAnim() != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            printWriter.println(getPopExitAnim());
        }
        if (this.mContainer != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.mContainer);
        }
        if (this.mView != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.mView);
        }
        if (getAnimatingAway() != null) {
            printWriter.print(str);
            printWriter.print("mAnimatingAway=");
            printWriter.println(getAnimatingAway());
        }
        if (getContext() != null) {
            c.b(this).a(str, fileDescriptor, printWriter, strArr);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.mChildFragmentManager + ":");
        this.mChildFragmentManager.X(str + "  ", fileDescriptor, printWriter, strArr);
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public Fragment findFragmentByWho(String str) {
        return str.equals(this.mWho) ? this : this.mChildFragmentManager.k0(str);
    }

    public String generateActivityResultKey() {
        return "fragment_" + this.mWho + "_rq#" + this.mNextLocalRequestCode.getAndIncrement();
    }

    public final androidx.fragment.app.prn getActivity() {
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        if (com3Var == null) {
            return null;
        }
        return (androidx.fragment.app.prn) com3Var.e();
    }

    public boolean getAllowEnterTransitionOverlap() {
        Boolean bool;
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null || (bool = com5Var.f2398b) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public boolean getAllowReturnTransitionOverlap() {
        Boolean bool;
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null || (bool = com5Var.f2393a) == null) {
            return true;
        }
        return bool.booleanValue();
    }

    public View getAnimatingAway() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        return com5Var.f2391a;
    }

    public Animator getAnimator() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        return com5Var.f2390a;
    }

    public final Bundle getArguments() {
        return this.mArguments;
    }

    public final androidx.fragment.app.com6 getChildFragmentManager() {
        if (this.mHost != null) {
            return this.mChildFragmentManager;
        }
        throw new IllegalStateException("Fragment " + this + " has not been attached yet.");
    }

    public Context getContext() {
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        if (com3Var == null) {
            return null;
        }
        return com3Var.f();
    }

    public androidx.lifecycle.com7.con getDefaultViewModelProviderFactory() {
        Application application;
        if (this.mFragmentManager == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (this.mDefaultFactory == null) {
            Context applicationContext = requireContext().getApplicationContext();
            while (true) {
                if (!(applicationContext instanceof ContextWrapper)) {
                    application = null;
                    break;
                }
                if (applicationContext instanceof Application) {
                    application = (Application) applicationContext;
                    break;
                }
                applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
            }
            if (application == null && androidx.fragment.app.com6.H0(3)) {
                Log.d("FragmentManager", "Could not find Application instance from Context " + requireContext().getApplicationContext() + ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
            }
            this.mDefaultFactory = new androidx.lifecycle.com6(application, this, getArguments());
        }
        return this.mDefaultFactory;
    }

    public int getEnterAnim() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return 0;
        }
        return com5Var.f2389a;
    }

    public Object getEnterTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        return com5Var.f2394a;
    }

    public c0 getEnterTransitionCallback() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        com5Var.getClass();
        return null;
    }

    public int getExitAnim() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return 0;
        }
        return com5Var.f8216b;
    }

    public Object getExitTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        return com5Var.f2402c;
    }

    public c0 getExitTransitionCallback() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        com5Var.getClass();
        return null;
    }

    public View getFocusedView() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        return com5Var.f2397b;
    }

    @Deprecated
    public final androidx.fragment.app.com6 getFragmentManager() {
        return this.mFragmentManager;
    }

    public final Object getHost() {
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        if (com3Var == null) {
            return null;
        }
        return com3Var.h();
    }

    public final int getId() {
        return this.mFragmentId;
    }

    public final LayoutInflater getLayoutInflater() {
        LayoutInflater layoutInflater = this.mLayoutInflater;
        return layoutInflater == null ? performGetLayoutInflater(null) : layoutInflater;
    }

    @Override // COM3.com7
    public androidx.lifecycle.nul getLifecycle() {
        return this.mLifecycleRegistry;
    }

    @Deprecated
    public c getLoaderManager() {
        return c.b(this);
    }

    public int getNextTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return 0;
        }
        return com5Var.f8219e;
    }

    public final Fragment getParentFragment() {
        return this.mParentFragment;
    }

    public final androidx.fragment.app.com6 getParentFragmentManager() {
        androidx.fragment.app.com6 com6Var = this.mFragmentManager;
        if (com6Var != null) {
            return com6Var;
        }
        throw new IllegalStateException("Fragment " + this + " not associated with a fragment manager.");
    }

    public boolean getPopDirection() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return false;
        }
        return com5Var.f2396a;
    }

    public int getPopEnterAnim() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return 0;
        }
        return com5Var.f8217c;
    }

    public int getPopExitAnim() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return 0;
        }
        return com5Var.f8218d;
    }

    public float getPostOnViewCreatedAlpha() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return 1.0f;
        }
        return com5Var.f8215a;
    }

    public Object getReenterTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        Object obj = com5Var.f2404d;
        return obj == USE_DEFAULT_TRANSITION ? getExitTransition() : obj;
    }

    public final Resources getResources() {
        return requireContext().getResources();
    }

    @Deprecated
    public final boolean getRetainInstance() {
        return this.mRetainInstance;
    }

    public Object getReturnTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        Object obj = com5Var.f2399b;
        return obj == USE_DEFAULT_TRANSITION ? getEnterTransition() : obj;
    }

    @Override // COM4.con
    public final SavedStateRegistry getSavedStateRegistry() {
        return this.mSavedStateRegistryController.b();
    }

    public Object getSharedElementEnterTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        return com5Var.f2405e;
    }

    public Object getSharedElementReturnTransition() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return null;
        }
        Object obj = com5Var.f8220f;
        return obj == USE_DEFAULT_TRANSITION ? getSharedElementEnterTransition() : obj;
    }

    public ArrayList<String> getSharedElementSourceNames() {
        ArrayList<String> arrayList;
        com5 com5Var = this.mAnimationInfo;
        return (com5Var == null || (arrayList = com5Var.f2395a) == null) ? new ArrayList<>() : arrayList;
    }

    public ArrayList<String> getSharedElementTargetNames() {
        ArrayList<String> arrayList;
        com5 com5Var = this.mAnimationInfo;
        return (com5Var == null || (arrayList = com5Var.f2400b) == null) ? new ArrayList<>() : arrayList;
    }

    public final String getString(int i2) {
        return getResources().getString(i2);
    }

    public final String getTag() {
        return this.mTag;
    }

    @Deprecated
    public final Fragment getTargetFragment() {
        String str;
        Fragment fragment = this.mTarget;
        if (fragment != null) {
            return fragment;
        }
        androidx.fragment.app.com6 com6Var = this.mFragmentManager;
        if (com6Var == null || (str = this.mTargetWho) == null) {
            return null;
        }
        return com6Var.h0(str);
    }

    @Deprecated
    public final int getTargetRequestCode() {
        return this.mTargetRequestCode;
    }

    public final CharSequence getText(int i2) {
        return getResources().getText(i2);
    }

    @Deprecated
    public boolean getUserVisibleHint() {
        return this.mUserVisibleHint;
    }

    public View getView() {
        return this.mView;
    }

    public COM3.com7 getViewLifecycleOwner() {
        o oVar = this.mViewLifecycleOwner;
        if (oVar != null) {
            return oVar;
        }
        throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
    }

    public LiveData<COM3.com7> getViewLifecycleOwnerLiveData() {
        return this.mViewLifecycleOwnerLiveData;
    }

    @Override // COM3.lpt7
    public lpt6 getViewModelStore() {
        if (this.mFragmentManager == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (getMinimumMaxLifecycleState() != androidx.lifecycle.nul.EnumC0039nul.INITIALIZED.ordinal()) {
            return this.mFragmentManager.C0(this);
        }
        throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
    }

    @SuppressLint({"KotlinPropertyAccess"})
    public final boolean hasOptionsMenu() {
        return this.mHasMenu;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public void initState() {
        initLifecycle();
        this.mWho = UUID.randomUUID().toString();
        this.mAdded = false;
        this.mRemoving = false;
        this.mFromLayout = false;
        this.mInLayout = false;
        this.mRestored = false;
        this.mBackStackNesting = 0;
        this.mFragmentManager = null;
        this.mChildFragmentManager = new p015CoM3.k();
        this.mHost = null;
        this.mFragmentId = 0;
        this.mContainerId = 0;
        this.mTag = null;
        this.mHidden = false;
        this.mDetached = false;
    }

    public final boolean isAdded() {
        return this.mHost != null && this.mAdded;
    }

    public final boolean isDetached() {
        return this.mDetached;
    }

    public final boolean isHidden() {
        return this.mHidden;
    }

    public boolean isHideReplaced() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return false;
        }
        return com5Var.f2403c;
    }

    public final boolean isInBackStack() {
        return this.mBackStackNesting > 0;
    }

    public final boolean isInLayout() {
        return this.mInLayout;
    }

    public final boolean isMenuVisible() {
        androidx.fragment.app.com6 com6Var;
        return this.mMenuVisible && ((com6Var = this.mFragmentManager) == null || com6Var.J0(this.mParentFragment));
    }

    public boolean isPostponed() {
        com5 com5Var = this.mAnimationInfo;
        if (com5Var == null) {
            return false;
        }
        return com5Var.f2401b;
    }

    public final boolean isRemoving() {
        return this.mRemoving;
    }

    public final boolean isRemovingParent() {
        Fragment parentFragment = getParentFragment();
        return parentFragment != null && (parentFragment.isRemoving() || parentFragment.isRemovingParent());
    }

    public final boolean isResumed() {
        return this.mState >= 7;
    }

    public final boolean isStateSaved() {
        androidx.fragment.app.com6 com6Var = this.mFragmentManager;
        if (com6Var == null) {
            return false;
        }
        return com6Var.M0();
    }

    public final boolean isVisible() {
        View view;
        return (!isAdded() || isHidden() || (view = this.mView) == null || view.getWindowToken() == null || this.mView.getVisibility() != 0) ? false : true;
    }

    public void noteStateNotSaved() {
        this.mChildFragmentManager.V0();
    }

    @Deprecated
    public void onActivityCreated(Bundle bundle) {
        this.mCalled = true;
    }

    @Deprecated
    public void onActivityResult(int i2, int i3, Intent intent) {
        if (androidx.fragment.app.com6.H0(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i2 + " resultCode: " + i3 + " data: " + intent);
        }
    }

    public void onAttach(Context context) {
        this.mCalled = true;
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        Activity activityE = com3Var == null ? null : com3Var.e();
        if (activityE != null) {
            this.mCalled = false;
            onAttach(activityE);
        }
    }

    @Deprecated
    public void onAttachFragment(Fragment fragment) {
    }

    @Override // android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        this.mCalled = true;
    }

    public boolean onContextItemSelected(MenuItem menuItem) {
        return false;
    }

    public void onCreate(Bundle bundle) {
        this.mCalled = true;
        restoreChildFragmentState(bundle);
        if (this.mChildFragmentManager.L0(1)) {
            return;
        }
        this.mChildFragmentManager.D();
    }

    public Animation onCreateAnimation(int i2, boolean z2, int i3) {
        return null;
    }

    public Animator onCreateAnimator(int i2, boolean z2, int i3) {
        return null;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        requireActivity().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2 = this.mContentLayoutId;
        if (i2 != 0) {
            return layoutInflater.inflate(i2, viewGroup, false);
        }
        return null;
    }

    public void onDestroy() {
        this.mCalled = true;
    }

    public void onDestroyOptionsMenu() {
    }

    public void onDestroyView() {
        this.mCalled = true;
    }

    public void onDetach() {
        this.mCalled = true;
    }

    public LayoutInflater onGetLayoutInflater(Bundle bundle) {
        return getLayoutInflater(bundle);
    }

    public void onHiddenChanged(boolean z2) {
    }

    public void onInflate(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.mCalled = true;
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        Activity activityE = com3Var == null ? null : com3Var.e();
        if (activityE != null) {
            this.mCalled = false;
            onInflate(activityE, attributeSet, bundle);
        }
    }

    @Override // android.content.ComponentCallbacks
    public void onLowMemory() {
        this.mCalled = true;
    }

    public void onMultiWindowModeChanged(boolean z2) {
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        return false;
    }

    public void onOptionsMenuClosed(Menu menu) {
    }

    public void onPause() {
        this.mCalled = true;
    }

    public void onPictureInPictureModeChanged(boolean z2) {
    }

    public void onPrepareOptionsMenu(Menu menu) {
    }

    public void onPrimaryNavigationFragmentChanged(boolean z2) {
    }

    @Deprecated
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
    }

    public void onResume() {
        this.mCalled = true;
    }

    public void onSaveInstanceState(Bundle bundle) {
    }

    public void onStart() {
        this.mCalled = true;
    }

    public void onStop() {
        this.mCalled = true;
    }

    public void onViewCreated(View view, Bundle bundle) {
    }

    public void onViewStateRestored(Bundle bundle) {
        this.mCalled = true;
    }

    public void performActivityCreated(Bundle bundle) {
        this.mChildFragmentManager.V0();
        this.mState = 3;
        this.mCalled = false;
        onActivityCreated(bundle);
        if (this.mCalled) {
            restoreViewState();
            this.mChildFragmentManager.z();
        } else {
            throw new r("Fragment " + this + " did not call through to super.onActivityCreated()");
        }
    }

    public void performAttach() {
        Iterator<com7> it = this.mOnPreAttachedListeners.iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.mOnPreAttachedListeners.clear();
        this.mChildFragmentManager.l(this.mHost, createFragmentContainer(), this);
        this.mState = 0;
        this.mCalled = false;
        onAttach(this.mHost.f());
        if (this.mCalled) {
            this.mFragmentManager.J(this);
            this.mChildFragmentManager.A();
        } else {
            throw new r("Fragment " + this + " did not call through to super.onAttach()");
        }
    }

    public void performConfigurationChanged(Configuration configuration) {
        onConfigurationChanged(configuration);
        this.mChildFragmentManager.B(configuration);
    }

    public boolean performContextItemSelected(MenuItem menuItem) {
        if (this.mHidden) {
            return false;
        }
        if (onContextItemSelected(menuItem)) {
            return true;
        }
        return this.mChildFragmentManager.C(menuItem);
    }

    public void performCreate(Bundle bundle) {
        this.mChildFragmentManager.V0();
        this.mState = 1;
        this.mCalled = false;
        this.mLifecycleRegistry.a(new androidx.lifecycle.prn() { // from class: androidx.fragment.app.Fragment.5
            @Override // androidx.lifecycle.prn
            public void f(COM3.com7 com7Var, androidx.lifecycle.nul.con conVar) {
                View view;
                if (conVar != androidx.lifecycle.nul.con.ON_STOP || (view = Fragment.this.mView) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
            }
        });
        this.mSavedStateRegistryController.c(bundle);
        onCreate(bundle);
        this.mIsCreated = true;
        if (this.mCalled) {
            this.mLifecycleRegistry.h(androidx.lifecycle.nul.con.ON_CREATE);
            return;
        }
        throw new r("Fragment " + this + " did not call through to super.onCreate()");
    }

    public boolean performCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        boolean z2 = false;
        if (this.mHidden) {
            return false;
        }
        if (this.mHasMenu && this.mMenuVisible) {
            onCreateOptionsMenu(menu, menuInflater);
            z2 = true;
        }
        return z2 | this.mChildFragmentManager.E(menu, menuInflater);
    }

    public void performCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.mChildFragmentManager.V0();
        this.mPerformedCreateView = true;
        this.mViewLifecycleOwner = new o(this, getViewModelStore());
        View viewOnCreateView = onCreateView(layoutInflater, viewGroup, bundle);
        this.mView = viewOnCreateView;
        if (viewOnCreateView == null) {
            if (this.mViewLifecycleOwner.c()) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.mViewLifecycleOwner = null;
        } else {
            this.mViewLifecycleOwner.b();
            lpt8.a(this.mView, this.mViewLifecycleOwner);
            lpt9.a(this.mView, this.mViewLifecycleOwner);
            COM4.nul.a(this.mView, this.mViewLifecycleOwner);
            this.mViewLifecycleOwnerLiveData.i(this.mViewLifecycleOwner);
        }
    }

    public void performDestroy() {
        this.mChildFragmentManager.F();
        this.mLifecycleRegistry.h(androidx.lifecycle.nul.con.ON_DESTROY);
        this.mState = 0;
        this.mCalled = false;
        this.mIsCreated = false;
        onDestroy();
        if (this.mCalled) {
            return;
        }
        throw new r("Fragment " + this + " did not call through to super.onDestroy()");
    }

    public void performDestroyView() {
        this.mChildFragmentManager.G();
        if (this.mView != null && this.mViewLifecycleOwner.getLifecycle().b().a(androidx.lifecycle.nul.EnumC0039nul.CREATED)) {
            this.mViewLifecycleOwner.a(androidx.lifecycle.nul.con.ON_DESTROY);
        }
        this.mState = 1;
        this.mCalled = false;
        onDestroyView();
        if (this.mCalled) {
            c.b(this).c();
            this.mPerformedCreateView = false;
        } else {
            throw new r("Fragment " + this + " did not call through to super.onDestroyView()");
        }
    }

    public void performDetach() {
        this.mState = -1;
        this.mCalled = false;
        onDetach();
        this.mLayoutInflater = null;
        if (this.mCalled) {
            if (this.mChildFragmentManager.G0()) {
                return;
            }
            this.mChildFragmentManager.F();
            this.mChildFragmentManager = new p015CoM3.k();
            return;
        }
        throw new r("Fragment " + this + " did not call through to super.onDetach()");
    }

    public LayoutInflater performGetLayoutInflater(Bundle bundle) {
        LayoutInflater layoutInflaterOnGetLayoutInflater = onGetLayoutInflater(bundle);
        this.mLayoutInflater = layoutInflaterOnGetLayoutInflater;
        return layoutInflaterOnGetLayoutInflater;
    }

    public void performLowMemory() {
        onLowMemory();
        this.mChildFragmentManager.H();
    }

    public void performMultiWindowModeChanged(boolean z2) {
        onMultiWindowModeChanged(z2);
        this.mChildFragmentManager.I(z2);
    }

    public boolean performOptionsItemSelected(MenuItem menuItem) {
        if (this.mHidden) {
            return false;
        }
        if (this.mHasMenu && this.mMenuVisible && onOptionsItemSelected(menuItem)) {
            return true;
        }
        return this.mChildFragmentManager.K(menuItem);
    }

    public void performOptionsMenuClosed(Menu menu) {
        if (this.mHidden) {
            return;
        }
        if (this.mHasMenu && this.mMenuVisible) {
            onOptionsMenuClosed(menu);
        }
        this.mChildFragmentManager.L(menu);
    }

    public void performPause() {
        this.mChildFragmentManager.N();
        if (this.mView != null) {
            this.mViewLifecycleOwner.a(androidx.lifecycle.nul.con.ON_PAUSE);
        }
        this.mLifecycleRegistry.h(androidx.lifecycle.nul.con.ON_PAUSE);
        this.mState = 6;
        this.mCalled = false;
        onPause();
        if (this.mCalled) {
            return;
        }
        throw new r("Fragment " + this + " did not call through to super.onPause()");
    }

    public void performPictureInPictureModeChanged(boolean z2) {
        onPictureInPictureModeChanged(z2);
        this.mChildFragmentManager.O(z2);
    }

    public boolean performPrepareOptionsMenu(Menu menu) {
        boolean z2 = false;
        if (this.mHidden) {
            return false;
        }
        if (this.mHasMenu && this.mMenuVisible) {
            onPrepareOptionsMenu(menu);
            z2 = true;
        }
        return z2 | this.mChildFragmentManager.P(menu);
    }

    public void performPrimaryNavigationFragmentChanged() {
        boolean zK0 = this.mFragmentManager.K0(this);
        Boolean bool = this.mIsPrimaryNavigationFragment;
        if (bool == null || bool.booleanValue() != zK0) {
            this.mIsPrimaryNavigationFragment = Boolean.valueOf(zK0);
            onPrimaryNavigationFragmentChanged(zK0);
            this.mChildFragmentManager.Q();
        }
    }

    public void performResume() {
        this.mChildFragmentManager.V0();
        this.mChildFragmentManager.b0(true);
        this.mState = 7;
        this.mCalled = false;
        onResume();
        if (!this.mCalled) {
            throw new r("Fragment " + this + " did not call through to super.onResume()");
        }
        androidx.lifecycle.com1 com1Var = this.mLifecycleRegistry;
        androidx.lifecycle.nul.con conVar = androidx.lifecycle.nul.con.ON_RESUME;
        com1Var.h(conVar);
        if (this.mView != null) {
            this.mViewLifecycleOwner.a(conVar);
        }
        this.mChildFragmentManager.R();
    }

    public void performSaveInstanceState(Bundle bundle) {
        onSaveInstanceState(bundle);
        this.mSavedStateRegistryController.d(bundle);
        Parcelable parcelableL1 = this.mChildFragmentManager.l1();
        if (parcelableL1 != null) {
            bundle.putParcelable("android:support:fragments", parcelableL1);
        }
    }

    public void performStart() {
        this.mChildFragmentManager.V0();
        this.mChildFragmentManager.b0(true);
        this.mState = 5;
        this.mCalled = false;
        onStart();
        if (!this.mCalled) {
            throw new r("Fragment " + this + " did not call through to super.onStart()");
        }
        androidx.lifecycle.com1 com1Var = this.mLifecycleRegistry;
        androidx.lifecycle.nul.con conVar = androidx.lifecycle.nul.con.ON_START;
        com1Var.h(conVar);
        if (this.mView != null) {
            this.mViewLifecycleOwner.a(conVar);
        }
        this.mChildFragmentManager.S();
    }

    public void performStop() {
        this.mChildFragmentManager.U();
        if (this.mView != null) {
            this.mViewLifecycleOwner.a(androidx.lifecycle.nul.con.ON_STOP);
        }
        this.mLifecycleRegistry.h(androidx.lifecycle.nul.con.ON_STOP);
        this.mState = 4;
        this.mCalled = false;
        onStop();
        if (this.mCalled) {
            return;
        }
        throw new r("Fragment " + this + " did not call through to super.onStop()");
    }

    public void performViewCreated() {
        onViewCreated(this.mView, this.mSavedFragmentState);
        this.mChildFragmentManager.V();
    }

    public void postponeEnterTransition() {
        ensureAnimationInfo().f2401b = true;
    }

    public final <I, O> p000AUx.prn<I> registerForActivityResult(k<I, O> kVar, p000AUx.nul<O> nulVar) {
        return prepareCallInternal(kVar, new com1(), nulVar);
    }

    public void registerForContextMenu(View view) {
        view.setOnCreateContextMenuListener(this);
    }

    @Deprecated
    public final void requestPermissions(String[] strArr, int i2) {
        if (this.mHost != null) {
            getParentFragmentManager().N0(this, strArr, i2);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    public final androidx.fragment.app.prn requireActivity() {
        androidx.fragment.app.prn activity = getActivity();
        if (activity != null) {
            return activity;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to an activity.");
    }

    public final Bundle requireArguments() {
        Bundle arguments = getArguments();
        if (arguments != null) {
            return arguments;
        }
        throw new IllegalStateException("Fragment " + this + " does not have any arguments.");
    }

    public final Context requireContext() {
        Context context = getContext();
        if (context != null) {
            return context;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a context.");
    }

    @Deprecated
    public final androidx.fragment.app.com6 requireFragmentManager() {
        return getParentFragmentManager();
    }

    public final Object requireHost() {
        Object host = getHost();
        if (host != null) {
            return host;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to a host.");
    }

    public final Fragment requireParentFragment() {
        Fragment parentFragment = getParentFragment();
        if (parentFragment != null) {
            return parentFragment;
        }
        if (getContext() == null) {
            throw new IllegalStateException("Fragment " + this + " is not attached to any Fragment or host");
        }
        throw new IllegalStateException("Fragment " + this + " is not a child Fragment, it is directly attached to " + getContext());
    }

    public final View requireView() {
        View view = getView();
        if (view != null) {
            return view;
        }
        throw new IllegalStateException("Fragment " + this + " did not return a View from onCreateView() or this was called before onCreateView().");
    }

    public void restoreChildFragmentState(Bundle bundle) {
        Parcelable parcelable;
        if (bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null) {
            return;
        }
        this.mChildFragmentManager.j1(parcelable);
        this.mChildFragmentManager.D();
    }

    public final void restoreViewState(Bundle bundle) {
        SparseArray<Parcelable> sparseArray = this.mSavedViewState;
        if (sparseArray != null) {
            this.mView.restoreHierarchyState(sparseArray);
            this.mSavedViewState = null;
        }
        if (this.mView != null) {
            this.mViewLifecycleOwner.d(this.mSavedViewRegistryState);
            this.mSavedViewRegistryState = null;
        }
        this.mCalled = false;
        onViewStateRestored(bundle);
        if (this.mCalled) {
            if (this.mView != null) {
                this.mViewLifecycleOwner.a(androidx.lifecycle.nul.con.ON_CREATE);
            }
        } else {
            throw new r("Fragment " + this + " did not call through to super.onViewStateRestored()");
        }
    }

    public void setAllowEnterTransitionOverlap(boolean z2) {
        ensureAnimationInfo().f2398b = Boolean.valueOf(z2);
    }

    public void setAllowReturnTransitionOverlap(boolean z2) {
        ensureAnimationInfo().f2393a = Boolean.valueOf(z2);
    }

    public void setAnimatingAway(View view) {
        ensureAnimationInfo().f2391a = view;
    }

    public void setAnimations(int i2, int i3, int i4, int i5) {
        if (this.mAnimationInfo == null && i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) {
            return;
        }
        ensureAnimationInfo().f2389a = i2;
        ensureAnimationInfo().f8216b = i3;
        ensureAnimationInfo().f8217c = i4;
        ensureAnimationInfo().f8218d = i5;
    }

    public void setAnimator(Animator animator) {
        ensureAnimationInfo().f2390a = animator;
    }

    public void setArguments(Bundle bundle) {
        if (this.mFragmentManager != null && isStateSaved()) {
            throw new IllegalStateException("Fragment already added and state has been saved");
        }
        this.mArguments = bundle;
    }

    public void setEnterSharedElementCallback(c0 c0Var) {
        ensureAnimationInfo().getClass();
    }

    public void setEnterTransition(Object obj) {
        ensureAnimationInfo().f2394a = obj;
    }

    public void setExitSharedElementCallback(c0 c0Var) {
        ensureAnimationInfo().getClass();
    }

    public void setExitTransition(Object obj) {
        ensureAnimationInfo().f2402c = obj;
    }

    public void setFocusedView(View view) {
        ensureAnimationInfo().f2397b = view;
    }

    public void setHasOptionsMenu(boolean z2) {
        if (this.mHasMenu != z2) {
            this.mHasMenu = z2;
            if (!isAdded() || isHidden()) {
                return;
            }
            this.mHost.o();
        }
    }

    public void setHideReplaced(boolean z2) {
        ensureAnimationInfo().f2403c = z2;
    }

    public void setInitialSavedState(com9 com9Var) {
        Bundle bundle;
        if (this.mFragmentManager != null) {
            throw new IllegalStateException("Fragment already added");
        }
        if (com9Var == null || (bundle = com9Var.f8221a) == null) {
            bundle = null;
        }
        this.mSavedFragmentState = bundle;
    }

    public void setMenuVisibility(boolean z2) {
        if (this.mMenuVisible != z2) {
            this.mMenuVisible = z2;
            if (this.mHasMenu && isAdded() && !isHidden()) {
                this.mHost.o();
            }
        }
    }

    public void setNextTransition(int i2) {
        if (this.mAnimationInfo == null && i2 == 0) {
            return;
        }
        ensureAnimationInfo();
        this.mAnimationInfo.f8219e = i2;
    }

    public void setOnStartEnterTransitionListener(com8 com8Var) {
        ensureAnimationInfo();
        com5 com5Var = this.mAnimationInfo;
        com8 com8Var2 = com5Var.f2392a;
        if (com8Var == com8Var2) {
            return;
        }
        if (com8Var != null && com8Var2 != null) {
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
        if (com5Var.f2401b) {
            com5Var.f2392a = com8Var;
        }
        if (com8Var != null) {
            com8Var.a();
        }
    }

    public void setPopDirection(boolean z2) {
        if (this.mAnimationInfo == null) {
            return;
        }
        ensureAnimationInfo().f2396a = z2;
    }

    public void setPostOnViewCreatedAlpha(float f2) {
        ensureAnimationInfo().f8215a = f2;
    }

    public void setReenterTransition(Object obj) {
        ensureAnimationInfo().f2404d = obj;
    }

    @Deprecated
    public void setRetainInstance(boolean z2) {
        this.mRetainInstance = z2;
        androidx.fragment.app.com6 com6Var = this.mFragmentManager;
        if (com6Var == null) {
            this.mRetainInstanceChangedWhileDetached = true;
        } else if (z2) {
            com6Var.j(this);
        } else {
            com6Var.h1(this);
        }
    }

    public void setReturnTransition(Object obj) {
        ensureAnimationInfo().f2399b = obj;
    }

    public void setSharedElementEnterTransition(Object obj) {
        ensureAnimationInfo().f2405e = obj;
    }

    public void setSharedElementNames(ArrayList<String> arrayList, ArrayList<String> arrayList2) {
        ensureAnimationInfo();
        com5 com5Var = this.mAnimationInfo;
        com5Var.f2395a = arrayList;
        com5Var.f2400b = arrayList2;
    }

    public void setSharedElementReturnTransition(Object obj) {
        ensureAnimationInfo().f8220f = obj;
    }

    @Deprecated
    public void setTargetFragment(Fragment fragment, int i2) {
        androidx.fragment.app.com6 com6Var = this.mFragmentManager;
        androidx.fragment.app.com6 com6Var2 = fragment != null ? fragment.mFragmentManager : null;
        if (com6Var != null && com6Var2 != null && com6Var != com6Var2) {
            throw new IllegalArgumentException("Fragment " + fragment + " must share the same FragmentManager to be set as a target fragment");
        }
        for (Fragment targetFragment = fragment; targetFragment != null; targetFragment = targetFragment.getTargetFragment()) {
            if (targetFragment.equals(this)) {
                throw new IllegalArgumentException("Setting " + fragment + " as the target of " + this + " would create a target cycle");
            }
        }
        if (fragment == null) {
            this.mTargetWho = null;
            this.mTarget = null;
        } else if (this.mFragmentManager == null || fragment.mFragmentManager == null) {
            this.mTargetWho = null;
            this.mTarget = fragment;
        } else {
            this.mTargetWho = fragment.mWho;
            this.mTarget = null;
        }
        this.mTargetRequestCode = i2;
    }

    @Deprecated
    public void setUserVisibleHint(boolean z2) {
        if (!this.mUserVisibleHint && z2 && this.mState < 5 && this.mFragmentManager != null && isAdded() && this.mIsCreated) {
            androidx.fragment.app.com6 com6Var = this.mFragmentManager;
            com6Var.X0(com6Var.w(this));
        }
        this.mUserVisibleHint = z2;
        this.mDeferStart = this.mState < 5 && !z2;
        if (this.mSavedFragmentState != null) {
            this.mSavedUserVisibleHint = Boolean.valueOf(z2);
        }
    }

    public boolean shouldShowRequestPermissionRationale(String str) {
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        if (com3Var != null) {
            return com3Var.l(str);
        }
        return false;
    }

    public void startActivity(@SuppressLint({"UnknownNullness"}) Intent intent) {
        startActivity(intent, null);
    }

    @Deprecated
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        startActivityForResult(intent, i2, null);
    }

    @Deprecated
    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) throws IntentSender.SendIntentException {
        if (this.mHost == null) {
            throw new IllegalStateException("Fragment " + this + " not attached to Activity");
        }
        if (androidx.fragment.app.com6.H0(2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in startIntentSenderForResult() requestCode: " + i2 + " IntentSender: " + intentSender + " fillInIntent: " + intent + " options: " + bundle);
        }
        getParentFragmentManager().P0(this, intentSender, i2, intent, i3, i4, i5, bundle);
    }

    public void startPostponedEnterTransition() {
        if (this.mAnimationInfo == null || !ensureAnimationInfo().f2401b) {
            return;
        }
        if (this.mHost == null) {
            ensureAnimationInfo().f2401b = false;
        } else if (Looper.myLooper() != this.mHost.g().getLooper()) {
            this.mHost.g().postAtFrontOfQueue(new con());
        } else {
            callStartTransitionListener(true);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.mWho);
        if (this.mFragmentId != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.mFragmentId));
        }
        if (this.mTag != null) {
            sb.append(" tag=");
            sb.append(this.mTag);
        }
        sb.append(")");
        return sb.toString();
    }

    public void unregisterForContextMenu(View view) {
        view.setOnCreateContextMenuListener(null);
    }

    @Deprecated
    public static Fragment instantiate(Context context, String str, Bundle bundle) {
        try {
            Fragment fragmentNewInstance = androidx.fragment.app.com2.d(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(fragmentNewInstance.getClass().getClassLoader());
                fragmentNewInstance.setArguments(bundle);
            }
            return fragmentNewInstance;
        } catch (IllegalAccessException e2) {
            throw new com6("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new com6("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new com6("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new com6("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }

    public final String getString(int i2, Object... objArr) {
        return getResources().getString(i2, objArr);
    }

    public final void postponeEnterTransition(long j2, TimeUnit timeUnit) {
        ensureAnimationInfo().f2401b = true;
        androidx.fragment.app.com6 com6Var = this.mFragmentManager;
        Handler handlerG = com6Var != null ? com6Var.v0().g() : new Handler(Looper.getMainLooper());
        handlerG.removeCallbacks(this.mPostponedDurationRunnable);
        handlerG.postDelayed(this.mPostponedDurationRunnable, timeUnit.toMillis(j2));
    }

    public final <I, O> p000AUx.prn<I> registerForActivityResult(k<I, O> kVar, ActivityResultRegistry activityResultRegistry, p000AUx.nul<O> nulVar) {
        return prepareCallInternal(kVar, new com2(activityResultRegistry), nulVar);
    }

    public void startActivity(@SuppressLint({"UnknownNullness"}) Intent intent, Bundle bundle) {
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        if (com3Var != null) {
            com3Var.m(this, intent, -1, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    @Deprecated
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (this.mHost != null) {
            getParentFragmentManager().O0(this, intent, i2, bundle);
            return;
        }
        throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }

    @Deprecated
    public LayoutInflater getLayoutInflater(Bundle bundle) {
        androidx.fragment.app.com3<?> com3Var = this.mHost;
        if (com3Var != null) {
            LayoutInflater layoutInflaterI = com3Var.i();
            h.a(layoutInflaterI, this.mChildFragmentManager.w0());
            return layoutInflaterI;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    @Deprecated
    public void onAttach(Activity activity) {
        this.mCalled = true;
    }

    @Deprecated
    public void onInflate(Activity activity, AttributeSet attributeSet, Bundle bundle) {
        this.mCalled = true;
    }

    private void restoreViewState() {
        if (androidx.fragment.app.com6.H0(3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + this);
        }
        if (this.mView != null) {
            restoreViewState(this.mSavedFragmentState);
        }
        this.mSavedFragmentState = null;
    }

    public Fragment(int i2) {
        this();
        this.mContentLayoutId = i2;
    }
}
