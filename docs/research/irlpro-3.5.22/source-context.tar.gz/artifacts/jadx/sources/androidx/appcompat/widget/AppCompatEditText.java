package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import p001AuX.com3;
import p014CoM2.lpt1;
import p014CoM2.lpt2;
import p022CoN.a;
import p022CoN.i;
import p022CoN.l;
import p022CoN.l0;
import p022CoN.lpt8;
import p022CoN.m;
import p022CoN.n0;
import p024Com2.lpt5;
import p024Com2.u;
import p024Com2.y;
import p091coM2.j2;
import p091coM2.l2;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatEditText extends EditText implements u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt2 f7879a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final l f1979a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p022CoN.lpt2 f1980a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt8 f1981a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final m f1982a;

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.B);
    }

    @Override // p024Com2.u
    public lpt5 a(lpt5 lpt5Var) {
        return this.f7879a.a(this, lpt5Var);
    }

    public void b(lpt8 lpt8Var) {
        KeyListener keyListener = getKeyListener();
        if (lpt8Var.b(keyListener)) {
            boolean zIsFocusable = super.isFocusable();
            int inputType = super.getInputType();
            KeyListener keyListenerA = lpt8Var.a(keyListener);
            if (keyListenerA == keyListener) {
                return;
            }
            super.setKeyListener(keyListenerA);
            super.setRawInputType(inputType);
            super.setFocusable(zIsFocusable);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            lpt2Var.b();
        }
        m mVar = this.f1982a;
        if (mVar != null) {
            mVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return lpt1.p(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            return lpt2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            return lpt2Var.d();
        }
        return null;
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        return super.getTextClassifier();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        String[] strArrD;
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f1982a.r(this, inputConnectionOnCreateInputConnection, editorInfo);
        InputConnection inputConnectionA = a.a(inputConnectionOnCreateInputConnection, editorInfo, this);
        if (inputConnectionA != null && Build.VERSION.SDK_INT <= 30 && (strArrD = y.D(this)) != null) {
            j2.c(editorInfo, strArrD);
            inputConnectionA = l2.c(this, inputConnectionA, editorInfo);
        }
        return this.f1981a.d(inputConnectionA, editorInfo);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onDragEvent(DragEvent dragEvent) {
        if (i.a(this, dragEvent)) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public boolean onTextContextMenuItem(int i2) {
        if (i.b(this, i2)) {
            return true;
        }
        return super.onTextContextMenuItem(i2);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            lpt2Var.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            lpt2Var.g(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(lpt1.q(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        this.f1981a.e(z2);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f1981a.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            lpt2Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        p022CoN.lpt2 lpt2Var = this.f1980a;
        if (lpt2Var != null) {
            lpt2Var.j(mode);
        }
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        m mVar = this.f1982a;
        if (mVar != null) {
            mVar.q(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        super.setTextClassifier(textClassifier);
    }

    public AppCompatEditText(Context context, AttributeSet attributeSet, int i2) {
        super(n0.b(context), attributeSet, i2);
        l0.a(this, getContext());
        p022CoN.lpt2 lpt2Var = new p022CoN.lpt2(this);
        this.f1980a = lpt2Var;
        lpt2Var.e(attributeSet, i2);
        m mVar = new m(this);
        this.f1982a = mVar;
        mVar.m(attributeSet, i2);
        mVar.b();
        this.f1979a = new l(this);
        this.f7879a = new lpt2();
        lpt8 lpt8Var = new lpt8(this);
        this.f1981a = lpt8Var;
        lpt8Var.c(attributeSet, i2);
        b(lpt8Var);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public Editable getText() {
        return super.getText();
    }
}
