package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class CheckBoxPreference extends TwoStatePreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux f8417a;

    public class aux implements CompoundButton.OnCheckedChangeListener {
        public aux() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
            if (CheckBoxPreference.this.callChangeListener(Boolean.valueOf(z2))) {
                CheckBoxPreference.this.b(z2);
            } else {
                compoundButton.setChecked(!z2);
            }
        }
    }

    public CheckBoxPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void h(View view) {
        boolean z2 = view instanceof CompoundButton;
        if (z2) {
            ((CompoundButton) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(((TwoStatePreference) this).f2666b);
        }
        if (z2) {
            ((CompoundButton) view).setOnCheckedChangeListener(this.f8417a);
        }
    }

    public final void i(View view) {
        if (((AccessibilityManager) getContext().getSystemService("accessibility")).isEnabled()) {
            h(view.findViewById(R.id.checkbox));
            g(view.findViewById(R.id.summary));
        }
    }

    @Override // androidx.preference.Preference
    public void onBindViewHolder(com7 com7Var) {
        super.onBindViewHolder(com7Var);
        h(com7Var.M(R.id.checkbox));
        f(com7Var);
    }

    @Override // androidx.preference.Preference
    public void performClick(View view) {
        super.performClick(view);
        i(view);
    }

    public CheckBoxPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f8417a = new aux();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f529b, i2, i3);
        e(l0.f(typedArrayObtainStyledAttributes, lpt7.f6215g, lpt7.f6205b));
        d(l0.f(typedArrayObtainStyledAttributes, lpt7.f6213f, lpt7.f6207c));
        c(l0.b(typedArrayObtainStyledAttributes, lpt7.f6211e, lpt7.f6209d, false));
        typedArrayObtainStyledAttributes.recycle();
    }

    public CheckBoxPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6167a, R.attr.checkBoxPreferenceStyle));
    }

    public CheckBoxPreference(Context context) {
        this(context, null);
    }
}
