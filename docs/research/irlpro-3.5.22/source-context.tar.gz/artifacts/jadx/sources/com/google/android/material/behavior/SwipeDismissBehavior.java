package com.google.android.material.behavior;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import p024Com2.y;
import p081cOm2.e2;
import p081cOm2.h2;
import p102com3.p0;

/* JADX INFO: loaded from: classes.dex */
public class SwipeDismissBehavior<V extends View> extends CoordinatorLayout.nul<V> {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f3310a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p0 f3312a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f3313a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3314b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f9287a = 0.0f;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3309a = 2;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f9288b = 0.5f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f9289c = 0.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f9290d = 0.5f;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p0.nul f3311a = new aux();

    public class aux extends p0.nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9291a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f9292b = -1;

        public aux() {
        }

        @Override // com3.p0.nul
        public int a(View view, int i2, int i3) {
            int width;
            int width2;
            int width3;
            boolean z2 = y.A(view) == 1;
            int i4 = SwipeDismissBehavior.this.f3309a;
            if (i4 == 0) {
                if (z2) {
                    width = this.f9291a - view.getWidth();
                    width2 = this.f9291a;
                } else {
                    width = this.f9291a;
                    width3 = view.getWidth();
                    width2 = width3 + width;
                }
            } else if (i4 != 1) {
                width = this.f9291a - view.getWidth();
                width2 = view.getWidth() + this.f9291a;
            } else if (z2) {
                width = this.f9291a;
                width3 = view.getWidth();
                width2 = width3 + width;
            } else {
                width = this.f9291a - view.getWidth();
                width2 = this.f9291a;
            }
            return SwipeDismissBehavior.G(width, i2, width2);
        }

        @Override // com3.p0.nul
        public int b(View view, int i2, int i3) {
            return view.getTop();
        }

        @Override // com3.p0.nul
        public int d(View view) {
            return view.getWidth();
        }

        @Override // com3.p0.nul
        public void i(View view, int i2) {
            this.f9292b = i2;
            this.f9291a = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }

        @Override // com3.p0.nul
        public void j(int i2) {
            nul nulVar = SwipeDismissBehavior.this.f3310a;
            if (nulVar != null) {
                nulVar.b(i2);
            }
        }

        @Override // com3.p0.nul
        public void k(View view, int i2, int i3, int i4, int i5) {
            float width = this.f9291a + (view.getWidth() * SwipeDismissBehavior.this.f9289c);
            float width2 = this.f9291a + (view.getWidth() * SwipeDismissBehavior.this.f9290d);
            float f2 = i2;
            if (f2 <= width) {
                view.setAlpha(1.0f);
            } else if (f2 >= width2) {
                view.setAlpha(0.0f);
            } else {
                view.setAlpha(SwipeDismissBehavior.F(0.0f, 1.0f - SwipeDismissBehavior.I(width, width2, f2), 1.0f));
            }
        }

        @Override // com3.p0.nul
        public void l(View view, float f2, float f3) {
            int i2;
            boolean z2;
            nul nulVar;
            this.f9292b = -1;
            int width = view.getWidth();
            if (n(view, f2)) {
                int left = view.getLeft();
                int i3 = this.f9291a;
                i2 = left < i3 ? i3 - width : i3 + width;
                z2 = true;
            } else {
                i2 = this.f9291a;
                z2 = false;
            }
            if (SwipeDismissBehavior.this.f3312a.L(i2, view.getTop())) {
                y.g0(view, new prn(view, z2));
            } else {
                if (!z2 || (nulVar = SwipeDismissBehavior.this.f3310a) == null) {
                    return;
                }
                nulVar.a(view);
            }
        }

        @Override // com3.p0.nul
        public boolean m(View view, int i2) {
            int i3 = this.f9292b;
            return (i3 == -1 || i3 == i2) && SwipeDismissBehavior.this.E(view);
        }

        public final boolean n(View view, float f2) {
            if (f2 == 0.0f) {
                return Math.abs(view.getLeft() - this.f9291a) >= Math.round(((float) view.getWidth()) * SwipeDismissBehavior.this.f9288b);
            }
            boolean z2 = y.A(view) == 1;
            int i2 = SwipeDismissBehavior.this.f3309a;
            if (i2 == 2) {
                return true;
            }
            if (i2 == 0) {
                if (z2) {
                    if (f2 >= 0.0f) {
                        return false;
                    }
                } else if (f2 <= 0.0f) {
                    return false;
                }
                return true;
            }
            if (i2 != 1) {
                return false;
            }
            if (z2) {
                if (f2 <= 0.0f) {
                    return false;
                }
            } else if (f2 >= 0.0f) {
                return false;
            }
            return true;
        }
    }

    public class con implements h2 {
        public con() {
        }

        @Override // p081cOm2.h2
        public boolean a(View view, h2.aux auxVar) {
            boolean z2 = false;
            if (!SwipeDismissBehavior.this.E(view)) {
                return false;
            }
            boolean z3 = y.A(view) == 1;
            int i2 = SwipeDismissBehavior.this.f3309a;
            if ((i2 == 0 && z3) || (i2 == 1 && !z3)) {
                z2 = true;
            }
            int width = view.getWidth();
            if (z2) {
                width = -width;
            }
            y.Y(view, width);
            view.setAlpha(0.0f);
            nul nulVar = SwipeDismissBehavior.this.f3310a;
            if (nulVar != null) {
                nulVar.a(view);
            }
            return true;
        }
    }

    public interface nul {
        void a(View view);

        void b(int i2);
    }

    public class prn implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final View f9294a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final boolean f9295b;

        public prn(View view, boolean z2) {
            this.f9294a = view;
            this.f9295b = z2;
        }

        @Override // java.lang.Runnable
        public void run() {
            nul nulVar;
            p0 p0Var = SwipeDismissBehavior.this.f3312a;
            if (p0Var != null && p0Var.l(true)) {
                y.g0(this.f9294a, this);
            } else {
                if (!this.f9295b || (nulVar = SwipeDismissBehavior.this.f3310a) == null) {
                    return;
                }
                nulVar.a(this.f9294a);
            }
        }
    }

    public static float F(float f2, float f3, float f4) {
        return Math.min(Math.max(f2, f3), f4);
    }

    public static int G(int i2, int i3, int i4) {
        return Math.min(Math.max(i2, i3), i4);
    }

    public static float I(float f2, float f3, float f4) {
        return (f4 - f2) / (f3 - f2);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean D(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
        p0 p0Var = this.f3312a;
        if (p0Var == null) {
            return false;
        }
        p0Var.C(motionEvent);
        return true;
    }

    public boolean E(View view) {
        return true;
    }

    public final void H(ViewGroup viewGroup) {
        if (this.f3312a == null) {
            this.f3312a = this.f3314b ? p0.m(viewGroup, this.f9287a, this.f3311a) : p0.n(viewGroup, this.f3311a);
        }
    }

    public void J(float f2) {
        this.f9290d = F(0.0f, f2, 1.0f);
    }

    public void K(nul nulVar) {
        this.f3310a = nulVar;
    }

    public void L(float f2) {
        this.f9289c = F(0.0f, f2, 1.0f);
    }

    public void M(int i2) {
        this.f3309a = i2;
    }

    public final void N(View view) {
        y.i0(view, inet.ipaddr.format.validate.aux.KEY_RANGE_WILDCARD);
        if (E(view)) {
            y.k0(view, e2.aux.f9117u, null, new con());
        }
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean k(CoordinatorLayout coordinatorLayout, V v2, MotionEvent motionEvent) {
        boolean zB = this.f3313a;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            zB = coordinatorLayout.B(v2, (int) motionEvent.getX(), (int) motionEvent.getY());
            this.f3313a = zB;
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.f3313a = false;
        }
        if (!zB) {
            return false;
        }
        H(coordinatorLayout);
        return this.f3312a.M(motionEvent);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean l(CoordinatorLayout coordinatorLayout, V v2, int i2) {
        boolean zL = super.l(coordinatorLayout, v2, i2);
        if (y.y(v2) == 0) {
            y.y0(v2, 1);
            N(v2);
        }
        return zL;
    }
}
