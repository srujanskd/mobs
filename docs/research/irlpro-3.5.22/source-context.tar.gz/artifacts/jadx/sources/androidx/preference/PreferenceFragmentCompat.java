package androidx.preference;

import android.R;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.com6;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt2;
import p016CoM4.lpt4;
import p016CoM4.lpt6;
import p016CoM4.lpt7;

/* JADX INFO: loaded from: classes.dex */
public abstract class PreferenceFragmentCompat extends Fragment implements androidx.preference.nul.InterfaceC0044nul, androidx.preference.nul.aux, androidx.preference.nul.con, DialogPreference.aux {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.preference.nul f2647a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public RecyclerView f2648a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Runnable f2649a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2650b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f8453c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final nul f2646a = new nul();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8451a = lpt4.f6195c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f2645a = new aux(Looper.getMainLooper());

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Runnable f8452b = new con();

    public class aux extends Handler {
        public aux(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            if (message.what != 1) {
                return;
            }
            PreferenceFragmentCompat.this.k();
        }
    }

    public interface com1 {
        boolean f(PreferenceFragmentCompat preferenceFragmentCompat, Preference preference);
    }

    public interface com2 {
        boolean a(PreferenceFragmentCompat preferenceFragmentCompat, PreferenceScreen preferenceScreen);
    }

    public class con implements Runnable {
        public con() {
        }

        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override // java.lang.Runnable
        public void run() {
            RecyclerView recyclerView = PreferenceFragmentCompat.this.f2648a;
            recyclerView.focusableViewAvailable(recyclerView);
        }
    }

    public class nul extends RecyclerView.lpt1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8456a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Drawable f2651a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2653a = true;

        public nul() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt1
        public void e(Rect rect, View view, RecyclerView recyclerView, RecyclerView.e eVar) {
            if (m(view, recyclerView)) {
                rect.bottom = this.f8456a;
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt1
        public void i(Canvas canvas, RecyclerView recyclerView, RecyclerView.e eVar) {
            if (this.f2651a == null) {
                return;
            }
            int childCount = recyclerView.getChildCount();
            int width = recyclerView.getWidth();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = recyclerView.getChildAt(i2);
                if (m(childAt, recyclerView)) {
                    int y2 = ((int) childAt.getY()) + childAt.getHeight();
                    this.f2651a.setBounds(0, y2, width, this.f8456a + y2);
                    this.f2651a.draw(canvas);
                }
            }
        }

        public void j(boolean z2) {
            this.f2653a = z2;
        }

        public void k(Drawable drawable) {
            if (drawable != null) {
                this.f8456a = drawable.getIntrinsicHeight();
            } else {
                this.f8456a = 0;
            }
            this.f2651a = drawable;
            PreferenceFragmentCompat.this.f2648a.t0();
        }

        public void l(int i2) {
            this.f8456a = i2;
            PreferenceFragmentCompat.this.f2648a.t0();
        }

        public final boolean m(View view, RecyclerView recyclerView) {
            RecyclerView.h hVarF0 = recyclerView.f0(view);
            boolean z2 = false;
            if (!((hVarF0 instanceof com7) && ((com7) hVarF0).O())) {
                return false;
            }
            boolean z3 = this.f2653a;
            int iIndexOfChild = recyclerView.indexOfChild(view);
            if (iIndexOfChild >= recyclerView.getChildCount() - 1) {
                return z3;
            }
            RecyclerView.h hVarF1 = recyclerView.f0(recyclerView.getChildAt(iIndexOfChild + 1));
            if ((hVarF1 instanceof com7) && ((com7) hVarF1).N()) {
                z2 = true;
            }
            return z2;
        }
    }

    public interface prn {
        boolean a(PreferenceFragmentCompat preferenceFragmentCompat, Preference preference);
    }

    public void A(PreferenceScreen preferenceScreen) {
        if (!this.f2647a.s(preferenceScreen) || preferenceScreen == null) {
            return;
        }
        v();
        this.f2650b = true;
        if (this.f8453c) {
            w();
        }
    }

    public void B(int i2, String str) {
        Preference preferenceC;
        x();
        PreferenceScreen preferenceScreenN = this.f2647a.n(requireContext(), i2, null);
        Preference preference = preferenceScreenN;
        if (str != null) {
            preferenceC = preferenceScreenN.c(str);
            if (!(preferenceC instanceof PreferenceScreen)) {
                preference = preferenceC;
                throw new IllegalArgumentException("Preference object with key " + str + " is not a PreferenceScreen");
            }
        }
        preference = preferenceC;
        A((PreferenceScreen) preference);
    }

    public final void C() {
        m().setAdapter(null);
        PreferenceScreen preferenceScreenO = o();
        if (preferenceScreenO != null) {
            preferenceScreenO.onDetached();
        }
        v();
    }

    @Override // androidx.preference.DialogPreference.aux
    public <T extends Preference> T a(CharSequence charSequence) {
        androidx.preference.nul nulVar = this.f2647a;
        if (nulVar == null) {
            return null;
        }
        return (T) nulVar.b(charSequence);
    }

    @Override // androidx.preference.nul.con
    public void e(PreferenceScreen preferenceScreen) {
        boolean zA = l() instanceof com2 ? ((com2) l()).a(this, preferenceScreen) : false;
        for (Fragment parentFragment = this; !zA && parentFragment != null; parentFragment = parentFragment.getParentFragment()) {
            if (parentFragment instanceof com2) {
                zA = ((com2) parentFragment).a(this, preferenceScreen);
            }
        }
        if (!zA && (getContext() instanceof com2)) {
            zA = ((com2) getContext()).a(this, preferenceScreen);
        }
        if (zA || !(getActivity() instanceof com2)) {
            return;
        }
        ((com2) getActivity()).a(this, preferenceScreen);
    }

    @Override // androidx.preference.nul.aux
    public void h(Preference preference) {
        DialogFragment dialogFragmentS;
        boolean zA = l() instanceof prn ? ((prn) l()).a(this, preference) : false;
        for (Fragment parentFragment = this; !zA && parentFragment != null; parentFragment = parentFragment.getParentFragment()) {
            if (parentFragment instanceof prn) {
                zA = ((prn) parentFragment).a(this, preference);
            }
        }
        if (!zA && (getContext() instanceof prn)) {
            zA = ((prn) getContext()).a(this, preference);
        }
        if (!zA && (getActivity() instanceof prn)) {
            zA = ((prn) getActivity()).a(this, preference);
        }
        if (!zA && getParentFragmentManager().j0("androidx.preference.PreferenceFragment.DIALOG") == null) {
            if (preference instanceof EditTextPreference) {
                dialogFragmentS = EditTextPreferenceDialogFragmentCompat.t(preference.getKey());
            } else if (preference instanceof ListPreference) {
                dialogFragmentS = ListPreferenceDialogFragmentCompat.s(preference.getKey());
            } else {
                if (!(preference instanceof MultiSelectListPreference)) {
                    throw new IllegalArgumentException("Cannot display dialog for an unknown Preference type: " + preference.getClass().getSimpleName() + ". Make sure to implement onPreferenceDisplayDialog() to handle displaying a custom dialog for this Preference.");
                }
                dialogFragmentS = MultiSelectListPreferenceDialogFragmentCompat.s(preference.getKey());
            }
            dialogFragmentS.setTargetFragment(this, 0);
            dialogFragmentS.show(getParentFragmentManager(), "androidx.preference.PreferenceFragment.DIALOG");
        }
    }

    @Override // androidx.preference.nul.InterfaceC0044nul
    public boolean i(Preference preference) {
        if (preference.getFragment() == null) {
            return false;
        }
        boolean zF = l() instanceof com1 ? ((com1) l()).f(this, preference) : false;
        for (Fragment parentFragment = this; !zF && parentFragment != null; parentFragment = parentFragment.getParentFragment()) {
            if (parentFragment instanceof com1) {
                zF = ((com1) parentFragment).f(this, preference);
            }
        }
        if (!zF && (getContext() instanceof com1)) {
            zF = ((com1) getContext()).f(this, preference);
        }
        if (!zF && (getActivity() instanceof com1)) {
            zF = ((com1) getActivity()).f(this, preference);
        }
        if (zF) {
            return true;
        }
        Log.w("PreferenceFragment", "onPreferenceStartFragment is not implemented in the parent activity - attempting to use a fallback implementation. You should implement this method so that you can configure the new fragment that will be displayed, and set a transition between the fragments.");
        com6 parentFragmentManager = getParentFragmentManager();
        Bundle extras = preference.getExtras();
        Fragment fragmentA = parentFragmentManager.s0().a(requireActivity().getClassLoader(), preference.getFragment());
        fragmentA.setArguments(extras);
        fragmentA.setTargetFragment(this, 0);
        parentFragmentManager.n().q(((View) requireView().getParent()).getId(), fragmentA).g(null).i();
        return true;
    }

    public void j(int i2) {
        x();
        A(this.f2647a.n(requireContext(), i2, o()));
    }

    public void k() {
        PreferenceScreen preferenceScreenO = o();
        if (preferenceScreenO != null) {
            m().setAdapter(q(preferenceScreenO));
            preferenceScreenO.onAttached();
        }
        p();
    }

    public Fragment l() {
        return null;
    }

    public final RecyclerView m() {
        return this.f2648a;
    }

    public androidx.preference.nul n() {
        return this.f2647a;
    }

    public PreferenceScreen o() {
        return this.f2647a.l();
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        TypedValue typedValue = new TypedValue();
        requireContext().getTheme().resolveAttribute(com8.f6175i, typedValue, true);
        int i2 = typedValue.resourceId;
        if (i2 == 0) {
            i2 = lpt6.f6202a;
        }
        requireContext().getTheme().applyStyle(i2, false);
        androidx.preference.nul nulVar = new androidx.preference.nul(requireContext());
        this.f2647a = nulVar;
        nulVar.q(this);
        s(bundle, getArguments() != null ? getArguments().getString("androidx.preference.PreferenceFragmentCompat.PREFERENCE_ROOT") : null);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        TypedArray typedArrayObtainStyledAttributes = requireContext().obtainStyledAttributes(null, lpt7.f536i, com8.f6172f, 0);
        this.f8451a = typedArrayObtainStyledAttributes.getResourceId(lpt7.f6230n0, this.f8451a);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(lpt7.f6232o0);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(lpt7.p0, -1);
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(lpt7.q0, true);
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater layoutInflaterCloneInContext = layoutInflater.cloneInContext(requireContext());
        View viewInflate = layoutInflaterCloneInContext.inflate(this.f8451a, viewGroup, false);
        View viewFindViewById = viewInflate.findViewById(R.id.list_container);
        if (!(viewFindViewById instanceof ViewGroup)) {
            throw new IllegalStateException("Content has view with id attribute 'android.R.id.list_container' that is not a ViewGroup class");
        }
        ViewGroup viewGroup2 = (ViewGroup) viewFindViewById;
        RecyclerView recyclerViewT = t(layoutInflaterCloneInContext, viewGroup2, bundle);
        if (recyclerViewT == null) {
            throw new RuntimeException("Could not create RecyclerView");
        }
        this.f2648a = recyclerViewT;
        recyclerViewT.h(this.f2646a);
        y(drawable);
        if (dimensionPixelSize != -1) {
            z(dimensionPixelSize);
        }
        this.f2646a.j(z2);
        if (this.f2648a.getParent() == null) {
            viewGroup2.addView(this.f2648a);
        }
        this.f2645a.post(this.f8452b);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        this.f2645a.removeCallbacks(this.f8452b);
        this.f2645a.removeMessages(1);
        if (this.f2650b) {
            C();
        }
        this.f2648a = null;
        super.onDestroyView();
    }

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        PreferenceScreen preferenceScreenO = o();
        if (preferenceScreenO != null) {
            Bundle bundle2 = new Bundle();
            preferenceScreenO.saveHierarchyState(bundle2);
            bundle.putBundle("android:preferences", bundle2);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        this.f2647a.r(this);
        this.f2647a.p(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onStop() {
        super.onStop();
        this.f2647a.r(null);
        this.f2647a.p(null);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        Bundle bundle2;
        PreferenceScreen preferenceScreenO;
        super.onViewCreated(view, bundle);
        if (bundle != null && (bundle2 = bundle.getBundle("android:preferences")) != null && (preferenceScreenO = o()) != null) {
            preferenceScreenO.restoreHierarchyState(bundle2);
        }
        if (this.f2650b) {
            k();
            Runnable runnable = this.f2649a;
            if (runnable != null) {
                runnable.run();
                this.f2649a = null;
            }
        }
        this.f8453c = true;
    }

    public void p() {
    }

    public RecyclerView.com3 q(PreferenceScreen preferenceScreen) {
        return new androidx.preference.con(preferenceScreen);
    }

    public RecyclerView.lpt2 r() {
        return new LinearLayoutManager(requireContext());
    }

    public abstract void s(Bundle bundle, String str);

    public RecyclerView t(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        RecyclerView recyclerView;
        if (requireContext().getPackageManager().hasSystemFeature("android.hardware.type.automotive") && (recyclerView = (RecyclerView) viewGroup.findViewById(lpt2.f6186e)) != null) {
            return recyclerView;
        }
        RecyclerView recyclerView2 = (RecyclerView) layoutInflater.inflate(lpt4.f6196d, viewGroup, false);
        recyclerView2.setLayoutManager(r());
        recyclerView2.setAccessibilityDelegateCompat(new p016CoM4.com6(recyclerView2));
        return recyclerView2;
    }

    public void v() {
    }

    public final void w() {
        if (this.f2645a.hasMessages(1)) {
            return;
        }
        this.f2645a.obtainMessage(1).sendToTarget();
    }

    public final void x() {
        if (this.f2647a == null) {
            throw new RuntimeException("This should be called after super.onCreate.");
        }
    }

    public void y(Drawable drawable) {
        this.f2646a.k(drawable);
    }

    public void z(int i2) {
        this.f2646a.l(i2);
    }
}
