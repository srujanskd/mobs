package NUL;

import java.util.ArrayList;
import java.util.Iterator;
import p146nUL.l;
import p146nUL.o;
import p146nUL.p;
import p146nUL.q;
import p146nUL.r;
import p146nUL.t;

/* JADX INFO: loaded from: classes.dex */
public class com5 {
    public static lpt2 a(p pVar, int i2, ArrayList<lpt2> arrayList, lpt2 lpt2Var) {
        int iP1;
        int i3 = i2 == 0 ? pVar.E : pVar.F;
        if (i3 != -1 && (lpt2Var == null || i3 != lpt2Var.f7398a)) {
            for (int i4 = 0; i4 < arrayList.size(); i4++) {
                lpt2 lpt2Var2 = arrayList.get(i4);
                if (lpt2Var2.c() == i3) {
                    if (lpt2Var != null) {
                        lpt2Var.g(i2, lpt2Var2);
                        arrayList.remove(lpt2Var);
                    }
                    lpt2Var = lpt2Var2;
                    break;
                }
            }
        } else if (i3 != -1) {
            return lpt2Var;
        }
        if (lpt2Var == null) {
            if ((pVar instanceof t) && (iP1 = ((t) pVar).p1(i2)) != -1) {
                for (int i5 = 0; i5 < arrayList.size(); i5++) {
                    lpt2 lpt2Var3 = arrayList.get(i5);
                    if (lpt2Var3.c() == iP1) {
                        lpt2Var = lpt2Var3;
                        break;
                    }
                }
            }
            if (lpt2Var == null) {
                lpt2Var = new lpt2(i2);
            }
            arrayList.add(lpt2Var);
        }
        if (lpt2Var.a(pVar)) {
            if (pVar instanceof r) {
                r rVar = (r) pVar;
                rVar.o1().b(rVar.p1() == 0 ? 1 : 0, arrayList, lpt2Var);
            }
            if (i2 == 0) {
                pVar.E = lpt2Var.c();
                pVar.f4944a.b(i2, arrayList, lpt2Var);
                pVar.f4965c.b(i2, arrayList, lpt2Var);
            } else {
                pVar.F = lpt2Var.c();
                pVar.f4957b.b(i2, arrayList, lpt2Var);
                pVar.f4972e.b(i2, arrayList, lpt2Var);
                pVar.f4969d.b(i2, arrayList, lpt2Var);
            }
            pVar.f4981h.b(i2, arrayList, lpt2Var);
        }
        return lpt2Var;
    }

    public static lpt2 b(ArrayList<lpt2> arrayList, int i2) {
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            lpt2 lpt2Var = arrayList.get(i3);
            if (i2 == lpt2Var.f7398a) {
                return lpt2Var;
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:173:0x0346  */
    public static boolean c(q qVar, con.InterfaceC0018con interfaceC0018con) {
        lpt2 lpt2Var;
        boolean z2;
        boolean z3;
        lpt2 lpt2Var2;
        ArrayList<p> arrayListO1 = qVar.o1();
        int size = arrayListO1.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = arrayListO1.get(i3);
            if (!d(qVar.y(), qVar.R(), pVar.y(), pVar.R())) {
                return false;
            }
        }
        int i4 = 0;
        ArrayList arrayList = null;
        ArrayList<t> arrayList2 = null;
        ArrayList arrayList3 = null;
        ArrayList<t> arrayList4 = null;
        ArrayList arrayList5 = null;
        ArrayList arrayList6 = null;
        while (i4 < size) {
            p pVar2 = arrayListO1.get(i4);
            if (!d(qVar.y(), qVar.R(), pVar2.y(), pVar2.R())) {
                q.O1(i2, pVar2, interfaceC0018con, qVar.f4994a, con.aux.f7385g);
            }
            boolean z4 = pVar2 instanceof r;
            if (z4) {
                r rVar = (r) pVar2;
                if (rVar.p1() == 0) {
                    if (arrayList3 == null) {
                        arrayList3 = new ArrayList();
                    }
                    arrayList3.add(rVar);
                }
                if (rVar.p1() == 1) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(rVar);
                }
            }
            if (pVar2 instanceof t) {
                if (pVar2 instanceof l) {
                    l lVar = (l) pVar2;
                    if (lVar.u1() == 0) {
                        if (arrayList2 == null) {
                            arrayList2 = new ArrayList();
                        }
                        arrayList2.add(lVar);
                    }
                    if (lVar.u1() == 1) {
                        if (arrayList4 == null) {
                            arrayList4 = new ArrayList();
                        }
                        arrayList4.add(lVar);
                    }
                } else {
                    t tVar = (t) pVar2;
                    if (arrayList2 == null) {
                        arrayList2 = new ArrayList();
                    }
                    arrayList2.add(tVar);
                    if (arrayList4 == null) {
                        arrayList4 = new ArrayList();
                    }
                    arrayList4.add(tVar);
                }
            }
            if (pVar2.f4944a.f4932a == null && pVar2.f4965c.f4932a == null && !z4 && !(pVar2 instanceof l)) {
                if (arrayList5 == null) {
                    arrayList5 = new ArrayList();
                }
                arrayList5.add(pVar2);
            }
            if (pVar2.f4957b.f4932a == null && pVar2.f4969d.f4932a == null && pVar2.f4972e.f4932a == null && !z4 && !(pVar2 instanceof l)) {
                if (arrayList6 == null) {
                    arrayList6 = new ArrayList();
                }
                arrayList6.add(pVar2);
            }
            i4++;
            i2 = 0;
        }
        ArrayList<lpt2> arrayList7 = new ArrayList<>();
        if (arrayList != null) {
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                a((r) it.next(), 0, arrayList7, null);
            }
        }
        lpt2 lpt2Var3 = null;
        int i5 = 0;
        if (arrayList2 != null) {
            for (t tVar2 : arrayList2) {
                lpt2 lpt2VarA = a(tVar2, i5, arrayList7, lpt2Var3);
                tVar2.o1(arrayList7, i5, lpt2VarA);
                lpt2VarA.b(arrayList7);
                lpt2Var3 = null;
                i5 = 0;
            }
        }
        o oVarM = qVar.m(o.con.LEFT);
        if (oVarM.c() != null) {
            Iterator<o> it2 = oVarM.c().iterator();
            while (it2.hasNext()) {
                a(it2.next().f4933a, 0, arrayList7, null);
            }
        }
        o oVarM2 = qVar.m(o.con.RIGHT);
        if (oVarM2.c() != null) {
            Iterator<o> it3 = oVarM2.c().iterator();
            while (it3.hasNext()) {
                a(it3.next().f4933a, 0, arrayList7, null);
            }
        }
        o oVarM3 = qVar.m(o.con.CENTER);
        if (oVarM3.c() != null) {
            Iterator<o> it4 = oVarM3.c().iterator();
            while (it4.hasNext()) {
                a(it4.next().f4933a, 0, arrayList7, null);
            }
        }
        lpt2 lpt2Var4 = null;
        if (arrayList5 != null) {
            Iterator it5 = arrayList5.iterator();
            while (it5.hasNext()) {
                a((p) it5.next(), 0, arrayList7, null);
            }
        }
        if (arrayList3 != null) {
            Iterator it6 = arrayList3.iterator();
            while (it6.hasNext()) {
                a((r) it6.next(), 1, arrayList7, null);
            }
        }
        int i6 = 1;
        if (arrayList4 != null) {
            for (t tVar3 : arrayList4) {
                lpt2 lpt2VarA2 = a(tVar3, i6, arrayList7, lpt2Var4);
                tVar3.o1(arrayList7, i6, lpt2VarA2);
                lpt2VarA2.b(arrayList7);
                lpt2Var4 = null;
                i6 = 1;
            }
        }
        o oVarM4 = qVar.m(o.con.TOP);
        if (oVarM4.c() != null) {
            Iterator<o> it7 = oVarM4.c().iterator();
            while (it7.hasNext()) {
                a(it7.next().f4933a, 1, arrayList7, null);
            }
        }
        o oVarM5 = qVar.m(o.con.BASELINE);
        if (oVarM5.c() != null) {
            Iterator<o> it8 = oVarM5.c().iterator();
            while (it8.hasNext()) {
                a(it8.next().f4933a, 1, arrayList7, null);
            }
        }
        o oVarM6 = qVar.m(o.con.BOTTOM);
        if (oVarM6.c() != null) {
            Iterator<o> it9 = oVarM6.c().iterator();
            while (it9.hasNext()) {
                a(it9.next().f4933a, 1, arrayList7, null);
            }
        }
        o oVarM7 = qVar.m(o.con.CENTER);
        if (oVarM7.c() != null) {
            Iterator<o> it10 = oVarM7.c().iterator();
            while (it10.hasNext()) {
                a(it10.next().f4933a, 1, arrayList7, null);
            }
        }
        if (arrayList6 != null) {
            Iterator it11 = arrayList6.iterator();
            while (it11.hasNext()) {
                a((p) it11.next(), 1, arrayList7, null);
            }
        }
        for (int i7 = 0; i7 < size; i7++) {
            p pVar3 = arrayListO1.get(i7);
            if (pVar3.q0()) {
                lpt2 lpt2VarB = b(arrayList7, pVar3.E);
                lpt2 lpt2VarB2 = b(arrayList7, pVar3.F);
                if (lpt2VarB != null && lpt2VarB2 != null) {
                    lpt2VarB.g(0, lpt2VarB2);
                    lpt2VarB2.i(2);
                    arrayList7.remove(lpt2VarB);
                }
            }
        }
        if (arrayList7.size() <= 1) {
            return false;
        }
        if (qVar.y() == p.con.WRAP_CONTENT) {
            lpt2Var = null;
            int i8 = 0;
            for (lpt2 lpt2Var5 : arrayList7) {
                if (lpt2Var5.d() != 1) {
                    lpt2Var5.h(false);
                    int iF = lpt2Var5.f(qVar.H1(), 0);
                    if (iF > i8) {
                        lpt2Var = lpt2Var5;
                        i8 = iF;
                    }
                }
            }
            if (lpt2Var != null) {
                qVar.M0(p.con.FIXED);
                qVar.h1(i8);
                lpt2Var.h(true);
            } else {
                lpt2Var = null;
            }
        } else {
            lpt2Var = null;
        }
        if (qVar.R() == p.con.WRAP_CONTENT) {
            lpt2 lpt2Var6 = null;
            int i9 = 0;
            for (lpt2 lpt2Var7 : arrayList7) {
                if (lpt2Var7.d() != 0) {
                    lpt2Var7.h(false);
                    int iF2 = lpt2Var7.f(qVar.H1(), 1);
                    if (iF2 > i9) {
                        lpt2Var6 = lpt2Var7;
                        i9 = iF2;
                    }
                }
            }
            z2 = false;
            z3 = true;
            if (lpt2Var6 != null) {
                qVar.d1(p.con.FIXED);
                qVar.I0(i9);
                lpt2Var6.h(true);
                lpt2Var2 = lpt2Var6;
            }
            return (lpt2Var == null || lpt2Var2 != null) ? z3 : z2;
        }
        z2 = false;
        z3 = true;
        lpt2Var2 = null;
        if (lpt2Var == null) {
        }
    }

    public static boolean d(p.con conVar, p.con conVar2, p.con conVar3, p.con conVar4) {
        p.con conVar5;
        p.con conVar6;
        p.con conVar7 = p.con.FIXED;
        return (conVar3 == conVar7 || conVar3 == (conVar6 = p.con.WRAP_CONTENT) || (conVar3 == p.con.MATCH_PARENT && conVar != conVar6)) || (conVar4 == conVar7 || conVar4 == (conVar5 = p.con.WRAP_CONTENT) || (conVar4 == p.con.MATCH_PARENT && conVar2 != conVar5));
    }
}
