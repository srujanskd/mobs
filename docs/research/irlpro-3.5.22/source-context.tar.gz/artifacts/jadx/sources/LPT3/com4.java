package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;

/* JADX INFO: loaded from: classes.dex */
public class com4 extends lpt1 {
    public static int h(boolean[] zArr, int i2, int i3) {
        for (int i4 = 0; i4 < 9; i4++) {
            boolean z2 = true;
            int i5 = i2 + i4;
            if (((1 << (8 - i4)) & i3) == 0) {
                z2 = false;
            }
            zArr[i5] = z2;
        }
        return 9;
    }

    public static int i(String str, int i2) {
        int iIndexOf = 0;
        int i3 = 1;
        for (int length = str.length() - 1; length >= 0; length--) {
            iIndexOf += "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".indexOf(str.charAt(length)) * i3;
            i3++;
            if (i3 > i2) {
                i3 = 1;
            }
        }
        return iIndexOf % 47;
    }

    public static String j(String str) {
        int length = str.length();
        StringBuilder sb = new StringBuilder(length << 1);
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt == 0) {
                sb.append("bU");
            } else if (cCharAt <= 26) {
                sb.append('a');
                sb.append((char) ((cCharAt + 'A') - 1));
            } else if (cCharAt <= 31) {
                sb.append('b');
                sb.append((char) ((cCharAt + 'A') - 27));
            } else if (cCharAt == ' ' || cCharAt == '$' || cCharAt == '%' || cCharAt == '+') {
                sb.append(cCharAt);
            } else if (cCharAt <= ',') {
                sb.append('c');
                sb.append((char) ((cCharAt + 'A') - 33));
            } else if (cCharAt <= '9') {
                sb.append(cCharAt);
            } else if (cCharAt == ':') {
                sb.append("cZ");
            } else if (cCharAt <= '?') {
                sb.append('b');
                sb.append((char) ((cCharAt + 'F') - 59));
            } else if (cCharAt == '@') {
                sb.append("bV");
            } else if (cCharAt <= 'Z') {
                sb.append(cCharAt);
            } else if (cCharAt <= '_') {
                sb.append('b');
                sb.append((char) ((cCharAt + 'K') - 91));
            } else if (cCharAt == '`') {
                sb.append("bW");
            } else if (cCharAt <= 'z') {
                sb.append('d');
                sb.append((char) ((cCharAt + 'A') - 97));
            } else {
                if (cCharAt > 127) {
                    throw new IllegalArgumentException("Requested content contains a non-encodable character: '" + cCharAt + "'");
                }
                sb.append('b');
                sb.append((char) ((cCharAt + 'P') - 123));
            }
        }
        return sb.toString();
    }

    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        String strJ = j(str);
        int length = strJ.length();
        if (length > 80) {
            throw new IllegalArgumentException("Requested contents should be less than 80 digits long after converting to extended encoding, but got ".concat(String.valueOf(length)));
        }
        boolean[] zArr = new boolean[((strJ.length() + 2 + 2) * 9) + 1];
        int iH = h(zArr, 0, com3.f6623a);
        for (int i2 = 0; i2 < length; i2++) {
            iH += h(zArr, iH, com3.f857a["0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".indexOf(strJ.charAt(i2))]);
        }
        int i3 = i(strJ, 20);
        int[] iArr = com3.f857a;
        int iH2 = iH + h(zArr, iH, iArr[i3]);
        int iH3 = iH2 + h(zArr, iH2, iArr[i(strJ + "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".charAt(i3), 15)]);
        zArr[iH3 + h(zArr, iH3, com3.f6623a)] = true;
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.CODE_93);
    }
}
