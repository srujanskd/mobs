package COM9;

import android.graphics.RectF;

/* JADX INFO: loaded from: classes.dex */
public interface nul {
    float a(RectF rectF);
}
