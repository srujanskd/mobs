package COM8;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.util.Property;
import android.view.View;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import p021CoM9.lpt4;
import p078cOM9.lpt7;

/* JADX INFO: loaded from: classes.dex */
public class aux extends com.google.android.material.floatingactionbutton.aux {
    public aux(FloatingActionButton floatingActionButton, lpt7 lpt7Var) {
        super(floatingActionButton, lpt7Var);
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void A() {
        c0();
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void C(int[] iArr) {
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void D(float f2, float f3, float f4) {
        StateListAnimator stateListAnimator = new StateListAnimator();
        stateListAnimator.addState(com.google.android.material.floatingactionbutton.aux.f3539a, f0(f2, f4));
        stateListAnimator.addState(com.google.android.material.floatingactionbutton.aux.f9502b, f0(f2, f3));
        stateListAnimator.addState(com.google.android.material.floatingactionbutton.aux.f9503c, f0(f2, f3));
        stateListAnimator.addState(com.google.android.material.floatingactionbutton.aux.f9504d, f0(f2, f3));
        AnimatorSet animatorSet = new AnimatorSet();
        ArrayList arrayList = new ArrayList();
        arrayList.add(ObjectAnimator.ofFloat(((com.google.android.material.floatingactionbutton.aux) this).f3552a, "elevation", f2).setDuration(0L));
        arrayList.add(ObjectAnimator.ofFloat(((com.google.android.material.floatingactionbutton.aux) this).f3552a, (Property<FloatingActionButton, Float>) View.TRANSLATION_Z, 0.0f).setDuration(100L));
        animatorSet.playSequentially((Animator[]) arrayList.toArray(new Animator[0]));
        animatorSet.setInterpolator(com.google.android.material.floatingactionbutton.aux.f9501a);
        stateListAnimator.addState(com.google.android.material.floatingactionbutton.aux.f9505e, animatorSet);
        stateListAnimator.addState(com.google.android.material.floatingactionbutton.aux.f9506f, f0(0.0f, 0.0f));
        ((com.google.android.material.floatingactionbutton.aux) this).f3552a.setStateListAnimator(stateListAnimator);
        if (W()) {
            c0();
        }
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public boolean I() {
        return false;
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void S(ColorStateList colorStateList) {
        Drawable drawable = ((com.google.android.material.floatingactionbutton.aux) this).f3549a;
        if (drawable instanceof RippleDrawable) {
            ((RippleDrawable) drawable).setColor(lpt4.d(colorStateList));
        } else {
            super.S(colorStateList);
        }
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public boolean W() {
        return ((com.google.android.material.floatingactionbutton.aux) this).f3551a.b() || !Y();
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void a0() {
    }

    public final Animator f0(float f2, float f3) {
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(ObjectAnimator.ofFloat(((com.google.android.material.floatingactionbutton.aux) this).f3552a, "elevation", f2).setDuration(0L)).with(ObjectAnimator.ofFloat(((com.google.android.material.floatingactionbutton.aux) this).f3552a, (Property<FloatingActionButton, Float>) View.TRANSLATION_Z, f3).setDuration(100L));
        animatorSet.setInterpolator(com.google.android.material.floatingactionbutton.aux.f9501a);
        return animatorSet;
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public float m() {
        return ((com.google.android.material.floatingactionbutton.aux) this).f3552a.getElevation();
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void r(Rect rect) {
        if (((com.google.android.material.floatingactionbutton.aux) this).f3551a.b()) {
            super.r(rect);
        } else if (Y()) {
            rect.set(0, 0, 0, 0);
        } else {
            int sizeDimension = (((com.google.android.material.floatingactionbutton.aux) this).f3541a - ((com.google.android.material.floatingactionbutton.aux) this).f3552a.getSizeDimension()) / 2;
            rect.set(sizeDimension, sizeDimension, sizeDimension, sizeDimension);
        }
    }

    @Override // com.google.android.material.floatingactionbutton.aux
    public void y() {
    }
}
