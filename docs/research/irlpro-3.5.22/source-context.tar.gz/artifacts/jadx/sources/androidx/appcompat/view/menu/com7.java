package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import p001AuX.com9;
import p022CoN.g0;
import p024Com2.y;
import p099coN.f1;

/* JADX INFO: loaded from: classes.dex */
public final class com7 extends f1 implements PopupWindow.OnDismissListener, View.OnKeyListener {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int f7815f = com9.f5603m;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7816a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final g0 f1882a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f1883a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1885a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewTreeObserver f1887a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PopupWindow.OnDismissListener f1888a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com1 f1889a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1890a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final prn f1891a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7817b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f1892b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f1893b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f7818c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1894c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7819d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f1895d;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f1896e;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ViewTreeObserver.OnGlobalLayoutListener f1886a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnAttachStateChangeListener f1884a = new con();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7820e = 0;

    public class aux implements ViewTreeObserver.OnGlobalLayoutListener {
        public aux() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!com7.this.b() || com7.this.f1882a.B()) {
                return;
            }
            View view = com7.this.f1892b;
            if (view == null || !view.isShown()) {
                com7.this.dismiss();
            } else {
                com7.this.f1882a.a();
            }
        }
    }

    public class con implements View.OnAttachStateChangeListener {
        public con() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = com7.this.f1887a;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    com7.this.f1887a = view.getViewTreeObserver();
                }
                com7 com7Var = com7.this;
                com7Var.f1887a.removeGlobalOnLayoutListener(com7Var.f1886a);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    public com7(Context context, com1 com1Var, View view, int i2, int i3, boolean z2) {
        this.f1883a = context;
        this.f1889a = com1Var;
        this.f1893b = z2;
        this.f1891a = new prn(com1Var, LayoutInflater.from(context), z2, f7815f);
        this.f7817b = i2;
        this.f7818c = i3;
        Resources resources = context.getResources();
        this.f7816a = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(p001AuX.com6.f5531d));
        this.f1885a = view;
        this.f1882a = new g0(context, null, i2, i3);
        com1Var.c(this, context);
    }

    @Override // p099coN.h1
    public void a() {
        if (!z()) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
    }

    @Override // p099coN.h1
    public boolean b() {
        return !this.f1894c && this.f1882a.b();
    }

    @Override // androidx.appcompat.view.menu.com5
    public void c(com1 com1Var, boolean z2) {
        if (com1Var != this.f1889a) {
            return;
        }
        dismiss();
        com5.aux auxVar = this.f1890a;
        if (auxVar != null) {
            auxVar.c(com1Var, z2);
        }
    }

    @Override // p099coN.h1
    public ListView d() {
        return this.f1882a.d();
    }

    @Override // p099coN.h1
    public void dismiss() {
        if (b()) {
            this.f1882a.dismiss();
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public void e(boolean z2) {
        this.f1895d = false;
        prn prnVar = this.f1891a;
        if (prnVar != null) {
            prnVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean f() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.com5
    public void g(com5.aux auxVar) {
        this.f1890a = auxVar;
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean j(com8 com8Var) {
        if (com8Var.hasVisibleItems()) {
            com4 com4Var = new com4(this.f1883a, com8Var, this.f1892b, this.f1893b, this.f7817b, this.f7818c);
            com4Var.j(this.f1890a);
            com4Var.g(f1.x(com8Var));
            com4Var.i(this.f1888a);
            this.f1888a = null;
            this.f1889a.e(false);
            int iF = this.f1882a.f();
            int iM = this.f1882a.m();
            if ((Gravity.getAbsoluteGravity(this.f7820e, y.A(this.f1885a)) & 7) == 5) {
                iF += this.f1885a.getWidth();
            }
            if (com4Var.n(iF, iM)) {
                com5.aux auxVar = this.f1890a;
                if (auxVar == null) {
                    return true;
                }
                auxVar.d(com8Var);
                return true;
            }
        }
        return false;
    }

    @Override // p099coN.f1
    public void l(com1 com1Var) {
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        this.f1894c = true;
        this.f1889a.close();
        ViewTreeObserver viewTreeObserver = this.f1887a;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f1887a = this.f1892b.getViewTreeObserver();
            }
            this.f1887a.removeGlobalOnLayoutListener(this.f1886a);
            this.f1887a = null;
        }
        this.f1892b.removeOnAttachStateChangeListener(this.f1884a);
        PopupWindow.OnDismissListener onDismissListener = this.f1888a;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // p099coN.f1
    public void p(View view) {
        this.f1885a = view;
    }

    @Override // p099coN.f1
    public void r(boolean z2) {
        this.f1891a.d(z2);
    }

    @Override // p099coN.f1
    public void s(int i2) {
        this.f7820e = i2;
    }

    @Override // p099coN.f1
    public void t(int i2) {
        this.f1882a.e(i2);
    }

    @Override // p099coN.f1
    public void u(PopupWindow.OnDismissListener onDismissListener) {
        this.f1888a = onDismissListener;
    }

    @Override // p099coN.f1
    public void v(boolean z2) {
        this.f1896e = z2;
    }

    @Override // p099coN.f1
    public void w(int i2) {
        this.f1882a.o(i2);
    }

    public final boolean z() {
        View view;
        if (b()) {
            return true;
        }
        if (this.f1894c || (view = this.f1885a) == null) {
            return false;
        }
        this.f1892b = view;
        this.f1882a.K(this);
        this.f1882a.L(this);
        this.f1882a.J(true);
        View view2 = this.f1892b;
        boolean z2 = this.f1887a == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.f1887a = viewTreeObserver;
        if (z2) {
            viewTreeObserver.addOnGlobalLayoutListener(this.f1886a);
        }
        view2.addOnAttachStateChangeListener(this.f1884a);
        this.f1882a.D(view2);
        this.f1882a.G(this.f7820e);
        if (!this.f1895d) {
            this.f7819d = f1.o(this.f1891a, null, this.f1883a, this.f7816a);
            this.f1895d = true;
        }
        this.f1882a.F(this.f7819d);
        this.f1882a.I(2);
        this.f1882a.H(n());
        this.f1882a.a();
        ListView listViewD = this.f1882a.d();
        listViewD.setOnKeyListener(this);
        if (this.f1896e && this.f1889a.x() != null) {
            FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(this.f1883a).inflate(com9.f5602l, (ViewGroup) listViewD, false);
            TextView textView = (TextView) frameLayout.findViewById(R.id.title);
            if (textView != null) {
                textView.setText(this.f1889a.x());
            }
            frameLayout.setEnabled(false);
            listViewD.addHeaderView(frameLayout, null, false);
        }
        this.f1882a.g(this.f1891a);
        this.f1882a.a();
        return true;
    }
}
