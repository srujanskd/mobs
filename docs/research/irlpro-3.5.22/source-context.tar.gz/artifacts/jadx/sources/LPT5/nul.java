package LPT5;

/* JADX INFO: loaded from: classes.dex */
public class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f6671a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f6672b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f6673c;

    public nul(long j2, long j3, long j4) {
        this.f6671a = j2;
        this.f6672b = j3;
        this.f6673c = j4;
    }
}
