package androidx.fragment.app;

import android.R;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public class ListFragment extends Fragment {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f2411a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ListAdapter f2413a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ListView f2414a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f2415a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2416a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public View f8229b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2418b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View f8230c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Handler f8228a = new Handler();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2417a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AdapterView.OnItemClickListener f2412a = new con();

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ListView listView = ListFragment.this.f2414a;
            listView.focusableViewAvailable(listView);
        }
    }

    public class con implements AdapterView.OnItemClickListener {
        public con() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            ListFragment.this.k((ListView) adapterView, view, i2, j2);
        }
    }

    public final void j() {
        if (this.f2414a != null) {
            return;
        }
        View view = getView();
        if (view == null) {
            throw new IllegalStateException("Content view not yet created");
        }
        if (view instanceof ListView) {
            this.f2414a = (ListView) view;
        } else {
            TextView textView = (TextView) view.findViewById(16711681);
            this.f2415a = textView;
            if (textView == null) {
                this.f2411a = view.findViewById(R.id.empty);
            } else {
                textView.setVisibility(8);
            }
            this.f8229b = view.findViewById(16711682);
            this.f8230c = view.findViewById(16711683);
            View viewFindViewById = view.findViewById(R.id.list);
            if (!(viewFindViewById instanceof ListView)) {
                if (viewFindViewById != null) {
                    throw new RuntimeException("Content has view with id attribute 'android.R.id.list' that is not a ListView class");
                }
                throw new RuntimeException("Your content must have a ListView whose id attribute is 'android.R.id.list'");
            }
            ListView listView = (ListView) viewFindViewById;
            this.f2414a = listView;
            View view2 = this.f2411a;
            if (view2 != null) {
                listView.setEmptyView(view2);
            } else {
                CharSequence charSequence = this.f2416a;
                if (charSequence != null) {
                    this.f2415a.setText(charSequence);
                    this.f2414a.setEmptyView(this.f2415a);
                }
            }
        }
        this.f2418b = true;
        this.f2414a.setOnItemClickListener(this.f2412a);
        ListAdapter listAdapter = this.f2413a;
        if (listAdapter != null) {
            this.f2413a = null;
            l(listAdapter);
        } else if (this.f8229b != null) {
            m(false, false);
        }
        this.f8228a.post(this.f2417a);
    }

    public void k(ListView listView, View view, int i2, long j2) {
    }

    public void l(ListAdapter listAdapter) {
        boolean z2 = this.f2413a != null;
        this.f2413a = listAdapter;
        ListView listView = this.f2414a;
        if (listView != null) {
            listView.setAdapter(listAdapter);
            if (this.f2418b || z2) {
                return;
            }
            m(true, requireView().getWindowToken() != null);
        }
    }

    public final void m(boolean z2, boolean z3) {
        j();
        View view = this.f8229b;
        if (view == null) {
            throw new IllegalStateException("Can't be used with a custom content view");
        }
        if (this.f2418b == z2) {
            return;
        }
        this.f2418b = z2;
        if (z2) {
            if (z3) {
                view.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_out));
                this.f8230c.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_in));
            } else {
                view.clearAnimation();
                this.f8230c.clearAnimation();
            }
            this.f8229b.setVisibility(8);
            this.f8230c.setVisibility(0);
            return;
        }
        if (z3) {
            view.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_in));
            this.f8230c.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_out));
        } else {
            view.clearAnimation();
            this.f8230c.clearAnimation();
        }
        this.f8229b.setVisibility(0);
        this.f8230c.setVisibility(8);
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Context contextRequireContext = requireContext();
        FrameLayout frameLayout = new FrameLayout(contextRequireContext);
        LinearLayout linearLayout = new LinearLayout(contextRequireContext);
        linearLayout.setId(16711682);
        linearLayout.setOrientation(1);
        linearLayout.setVisibility(8);
        linearLayout.setGravity(17);
        linearLayout.addView(new ProgressBar(contextRequireContext, null, R.attr.progressBarStyleLarge), new FrameLayout.LayoutParams(-2, -2));
        frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout frameLayout2 = new FrameLayout(contextRequireContext);
        frameLayout2.setId(16711683);
        TextView textView = new TextView(contextRequireContext);
        textView.setId(16711681);
        textView.setGravity(17);
        frameLayout2.addView(textView, new FrameLayout.LayoutParams(-1, -1));
        ListView listView = new ListView(contextRequireContext);
        listView.setId(R.id.list);
        listView.setDrawSelectorOnTop(false);
        frameLayout2.addView(listView, new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(frameLayout2, new FrameLayout.LayoutParams(-1, -1));
        frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        return frameLayout;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        this.f8228a.removeCallbacks(this.f2417a);
        this.f2414a = null;
        this.f2418b = false;
        this.f8230c = null;
        this.f8229b = null;
        this.f2411a = null;
        this.f2415a = null;
        super.onDestroyView();
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        j();
    }
}
