package com.newrelic.agent.android.analytics;

import com.newrelic.agent.android.AgentConfiguration;
import com.newrelic.agent.android.logging.AgentLog;
import com.newrelic.agent.android.logging.AgentLogManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import p045LpT4.com2;

/* JADX INFO: loaded from: classes.dex */
public class EventManagerImpl implements EventManager, EventListener {
    public static final int DEFAULT_MAX_EVENT_BUFFER_SIZE = 4000;
    public static final int DEFAULT_MAX_EVENT_BUFFER_TIME = 600;
    public static final int DEFAULT_MIN_EVENT_BUFFER_SIZE = 64;
    public static final int DEFAULT_MIN_EVENT_BUFFER_TIME = 60;
    private static final AgentLog log = AgentLogManager.getAgentLog();
    private AtomicReference<List<AnalyticsEvent>> events;
    private AtomicInteger eventsDropped;
    private AtomicInteger eventsEvicted;
    private AtomicInteger eventsRecorded;
    private long firstEventTimestamp;
    private AtomicBoolean initialized;
    AtomicReference<EventManager> instance;
    private AtomicReference<EventListener> listener;
    int maxBufferTimeInSec;
    int maxEventPoolSize;
    private AtomicBoolean transmitRequired;

    public EventManagerImpl() {
        this(DEFAULT_MAX_EVENT_BUFFER_SIZE, DEFAULT_MAX_EVENT_BUFFER_TIME);
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public boolean addEvent(AnalyticsEvent analyticsEvent) {
        if (!this.initialized.get()) {
            this.eventsDropped.incrementAndGet();
            return false;
        }
        if (!this.listener.get().onEventAdded(analyticsEvent)) {
            log.warning("Listener dropped new event[" + analyticsEvent.getName() + "]");
            this.eventsDropped.incrementAndGet();
            return false;
        }
        if (isMaxEventBufferTimeExceeded()) {
            this.listener.get().onEventQueueTimeExceeded(this.maxBufferTimeInSec);
        }
        synchronized (this.events.get()) {
            int size = this.events.get().size();
            if (size == 0) {
                this.firstEventTimestamp = System.currentTimeMillis();
                log.debug("EventManager.addEvent(): Queue is empty, setting first event timestamp to " + this.firstEventTimestamp);
            }
            if (size >= this.maxEventPoolSize) {
                try {
                    if (this.listener.get().onEventOverflow(analyticsEvent)) {
                        AgentLog agentLog = log;
                        agentLog.warning("Listener dropped overflow event[" + analyticsEvent.getName() + "]");
                        this.eventsDropped.incrementAndGet();
                        agentLog.debug("Event queue is full, scheduling harvest");
                        return false;
                    }
                    int iRandom = (int) (Math.random() * ((double) this.eventsRecorded.get()));
                    if (iRandom < this.maxEventPoolSize) {
                        if (this.listener.get().onEventEvicted(this.events.get().get(iRandom))) {
                            this.events.get().remove(iRandom);
                            this.eventsEvicted.incrementAndGet();
                        }
                    } else if (this.listener.get().onEventEvicted(analyticsEvent)) {
                        this.eventsDropped.incrementAndGet();
                        log.debug("Event queue is full, scheduling harvest");
                        return false;
                    }
                    this.listener.get().onEventQueueSizeExceeded(size);
                    log.debug("Event queue is full, scheduling harvest");
                } catch (Throwable th) {
                    log.debug("Event queue is full, scheduling harvest");
                    throw th;
                }
            }
            if (!this.events.get().add(analyticsEvent)) {
                return false;
            }
            this.eventsRecorded.incrementAndGet();
            return true;
        }
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public void empty() {
        Collection<AnalyticsEvent> queuedEventsSnapshot = getQueuedEventsSnapshot();
        if (queuedEventsSnapshot.size() > 0) {
            log.warning("EventManager.empty(): dropped [" + queuedEventsSnapshot.size() + "] events");
        }
        queuedEventsSnapshot.clear();
        this.firstEventTimestamp = 0L;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public int getEventsDropped() {
        return this.eventsDropped.get();
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public int getEventsEjected() {
        return this.eventsEvicted.get();
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public int getEventsRecorded() {
        return this.eventsRecorded.get();
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public int getMaxEventBufferTime() {
        return this.maxBufferTimeInSec;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public int getMaxEventPoolSize() {
        return this.maxEventPoolSize;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public Collection<AnalyticsEvent> getQueuedEvents() {
        Collection<AnalyticsEvent> collectionUnmodifiableCollection;
        synchronized (this.events.get()) {
            collectionUnmodifiableCollection = Collections.unmodifiableCollection(this.events.get());
        }
        return collectionUnmodifiableCollection;
    }

    public Collection<AnalyticsEvent> getQueuedEventsSnapshot() {
        List<AnalyticsEvent> andSet;
        synchronized (this.events.get()) {
            this.listener.get().onEventFlush();
            this.transmitRequired.set(false);
            andSet = this.events.getAndSet(Collections.synchronizedList(new ArrayList(this.maxEventPoolSize)));
        }
        return andSet;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public void initialize(AgentConfiguration agentConfiguration) {
        if (!this.initialized.compareAndSet(false, true)) {
            log.verbose("EventManagerImpl.initialize(): Has already been initialized. Bypassing...");
            return;
        }
        this.firstEventTimestamp = 0L;
        this.eventsRecorded.set(0);
        this.eventsEvicted.set(0);
        empty();
        this.listener.get().onStart(this);
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public boolean isMaxEventBufferTimeExceeded() {
        return this.firstEventTimestamp > 0 && System.currentTimeMillis() - this.firstEventTimestamp > ((long) (this.maxBufferTimeInSec * 1000));
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public boolean isMaxEventPoolSizeExceeded() {
        return this.events.get().size() > this.maxEventPoolSize;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public boolean isTransmitRequired() {
        return (!this.initialized.get() && this.events.get().size() > 0) || this.transmitRequired.compareAndSet(true, false) || isMaxEventPoolSizeExceeded() || isMaxEventBufferTimeExceeded();
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public boolean onEventAdded(AnalyticsEvent analyticsEvent) {
        log.debug("Event [" + analyticsEvent.getCategory() + "] added to queue");
        return true;
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public boolean onEventEvicted(AnalyticsEvent analyticsEvent) {
        log.debug("Event [" + analyticsEvent.getName() + "] evicted from queue");
        this.transmitRequired.set(true);
        return true;
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public void onEventFlush() {
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public boolean onEventOverflow(AnalyticsEvent analyticsEvent) {
        log.debug("Event queue overflow adding event [" + analyticsEvent.getName() + "]");
        this.transmitRequired.set(true);
        return false;
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public void onEventQueueSizeExceeded(int i2) {
        log.debug("Event queue size [" + i2 + "] exceeded max[" + this.maxEventPoolSize + "]");
        this.transmitRequired.set(true);
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public void onEventQueueTimeExceeded(int i2) {
        log.debug("Event queue time [" + i2 + "] exceeded");
        this.transmitRequired.set(true);
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public void onShutdown() {
        if (!this.events.get().isEmpty()) {
            log.warning("Event manager is shutting down with [" + this.events.get().size() + "] events remaining in the queue");
        }
        this.transmitRequired.set(true);
    }

    @Override // com.newrelic.agent.android.analytics.EventListener
    public void onStart(EventManager eventManager) {
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public void setEventListener(EventListener eventListener) {
        if (eventListener != null) {
            com2.a(this.listener, this, eventListener);
        } else {
            this.listener.set(this);
        }
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    @Deprecated
    public void setMaxEventBufferTime(int i2) {
        if (i2 < 60) {
            log.error("Event buffer time cannot be shorter than 60 seconds");
            i2 = 60;
        }
        if (i2 > 600) {
            log.warning("Event buffer time should not be longer than 600 seconds");
            i2 = 600;
        }
        this.maxBufferTimeInSec = i2;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public void setMaxEventPoolSize(int i2) {
        if (i2 < 64) {
            log.error("Event queue cannot be smaller than 64");
            i2 = 64;
        }
        if (i2 > 4000) {
            log.warning("Event queue should not be larger than 4000");
        }
        this.maxEventPoolSize = i2;
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public void setTransmitRequired() {
        this.transmitRequired.set(true);
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public void shutdown() {
        this.listener.get().onShutdown();
        this.listener.set(this);
        this.initialized.set(false);
    }

    @Override // com.newrelic.agent.android.analytics.EventManager
    public int size() {
        return this.events.get().size();
    }

    public EventManagerImpl(int i2, int i3) {
        this.initialized = new AtomicBoolean(false);
        this.eventsRecorded = new AtomicInteger(0);
        this.eventsEvicted = new AtomicInteger(0);
        this.eventsDropped = new AtomicInteger(0);
        this.transmitRequired = new AtomicBoolean(true);
        this.listener = new AtomicReference<>(this);
        this.instance = new AtomicReference<>(null);
        this.events = new AtomicReference<>(Collections.synchronizedList(new ArrayList(i2)));
        this.maxBufferTimeInSec = i3;
        this.maxEventPoolSize = i2;
        this.firstEventTimestamp = 0L;
        this.eventsRecorded.set(0);
        this.eventsEvicted.set(0);
        this.eventsDropped.set(0);
        com2.a(this.instance, null, this);
    }

    public void empty(Collection<AnalyticsEvent> collection) {
        this.events.get().removeAll(collection);
    }
}
