package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/* JADX INFO: loaded from: classes.dex */
public class com3 extends RecyclerView.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f8664a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PointF f2867a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final DisplayMetrics f2868a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinearInterpolator f2870a = new LinearInterpolator();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final DecelerateInterpolator f2869a = new DecelerateInterpolator();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8667d = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8665b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8666c = 0;

    public com3(Context context) {
        this.f2868a = context.getResources().getDisplayMetrics();
    }

    public final float A() {
        if (!this.f8667d) {
            this.f8664a = v(this.f2868a);
            this.f8667d = true;
        }
        return this.f8664a;
    }

    public int B() {
        PointF pointF = this.f2867a;
        if (pointF != null) {
            float f2 = pointF.y;
            if (f2 != 0.0f) {
                return f2 > 0.0f ? 1 : -1;
            }
        }
        return 0;
    }

    public void C(RecyclerView.d.aux auxVar) {
        PointF pointFA = a(f());
        if (pointFA == null || (pointFA.x == 0.0f && pointFA.y == 0.0f)) {
            auxVar.b(f());
            r();
            return;
        }
        i(pointFA);
        this.f2867a = pointFA;
        this.f8665b = (int) (pointFA.x * 10000.0f);
        this.f8666c = (int) (pointFA.y * 10000.0f);
        auxVar.d((int) (this.f8665b * 1.2f), (int) (this.f8666c * 1.2f), (int) (x(10000) * 1.2f), this.f2870a);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.d
    public void l(int i2, int i3, RecyclerView.e eVar, RecyclerView.d.aux auxVar) {
        if (c() == 0) {
            r();
            return;
        }
        this.f8665b = y(this.f8665b, i2);
        int iY = y(this.f8666c, i3);
        this.f8666c = iY;
        if (this.f8665b == 0 && iY == 0) {
            C(auxVar);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.d
    public void m() {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.d
    public void n() {
        this.f8666c = 0;
        this.f8665b = 0;
        this.f2867a = null;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.d
    public void o(View view, RecyclerView.e eVar, RecyclerView.d.aux auxVar) {
        int iT = t(view, z());
        int iU = u(view, B());
        int iW = w((int) Math.sqrt((iT * iT) + (iU * iU)));
        if (iW > 0) {
            auxVar.d(-iT, -iU, iW, this.f2869a);
        }
    }

    public int s(int i2, int i3, int i4, int i5, int i6) {
        if (i6 == -1) {
            return i4 - i2;
        }
        if (i6 != 0) {
            if (i6 == 1) {
                return i5 - i3;
            }
            throw new IllegalArgumentException("snap preference should be one of the constants defined in SmoothScroller, starting with SNAP_");
        }
        int i7 = i4 - i2;
        if (i7 > 0) {
            return i7;
        }
        int i8 = i5 - i3;
        if (i8 < 0) {
            return i8;
        }
        return 0;
    }

    public int t(View view, int i2) {
        RecyclerView.lpt2 lpt2VarE = e();
        if (lpt2VarE == null || !lpt2VarE.k()) {
            return 0;
        }
        RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
        return s(lpt2VarE.Q(view) - ((ViewGroup.MarginLayoutParams) lpt3Var).leftMargin, lpt2VarE.T(view) + ((ViewGroup.MarginLayoutParams) lpt3Var).rightMargin, lpt2VarE.e0(), lpt2VarE.o0() - lpt2VarE.f0(), i2);
    }

    public int u(View view, int i2) {
        RecyclerView.lpt2 lpt2VarE = e();
        if (lpt2VarE == null || !lpt2VarE.l()) {
            return 0;
        }
        RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
        return s(lpt2VarE.U(view) - ((ViewGroup.MarginLayoutParams) lpt3Var).topMargin, lpt2VarE.O(view) + ((ViewGroup.MarginLayoutParams) lpt3Var).bottomMargin, lpt2VarE.g0(), lpt2VarE.W() - lpt2VarE.d0(), i2);
    }

    public float v(DisplayMetrics displayMetrics) {
        return 25.0f / displayMetrics.densityDpi;
    }

    public int w(int i2) {
        return (int) Math.ceil(((double) x(i2)) / 0.3356d);
    }

    public int x(int i2) {
        return (int) Math.ceil(Math.abs(i2) * A());
    }

    public final int y(int i2, int i3) {
        int i4 = i2 - i3;
        if (i2 * i4 <= 0) {
            return 0;
        }
        return i4;
    }

    public int z() {
        PointF pointF = this.f2867a;
        if (pointF != null) {
            float f2 = pointF.x;
            if (f2 != 0.0f) {
                return f2 > 0.0f ? 1 : -1;
            }
        }
        return 0;
    }
}
