package com.google.android.material.floatingactionbutton;

import android.animation.Animator;
import android.animation.AnimatorSet;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public interface con {
    List<Animator.AnimatorListener> a();

    boolean b();

    AnimatorSet c();

    void d();

    void e(ExtendedFloatingActionButton.com2 com2Var);
}
