package COM3;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import androidx.savedstate.SavedStateRegistry;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class lpt4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class[] f5692a = {Boolean.TYPE, boolean[].class, Double.TYPE, double[].class, Integer.TYPE, int[].class, Long.TYPE, long[].class, String.class, String[].class, Binder.class, Bundle.class, Byte.TYPE, byte[].class, Character.TYPE, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, Float.TYPE, float[].class, Parcelable.class, Parcelable[].class, Serializable.class, Short.TYPE, short[].class, SparseArray.class, Size.class, SizeF.class};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SavedStateRegistry.con f60a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<String, Object> f61a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Map<String, SavedStateRegistry.con> f5693b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Map<String, Object> f5694c;

    public class aux implements SavedStateRegistry.con {
        public aux() {
        }

        @Override // androidx.savedstate.SavedStateRegistry.con
        public Bundle a() {
            for (Map.Entry entry : new HashMap(lpt4.this.f5693b).entrySet()) {
                lpt4.this.c((String) entry.getKey(), ((SavedStateRegistry.con) entry.getValue()).a());
            }
            Set<String> setKeySet = lpt4.this.f61a.keySet();
            ArrayList<? extends Parcelable> arrayList = new ArrayList<>(setKeySet.size());
            ArrayList<? extends Parcelable> arrayList2 = new ArrayList<>(arrayList.size());
            for (String str : setKeySet) {
                arrayList.add(str);
                arrayList2.add(lpt4.this.f61a.get(str));
            }
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList("keys", arrayList);
            bundle.putParcelableArrayList("values", arrayList2);
            return bundle;
        }
    }

    public lpt4(Map<String, Object> map) {
        this.f5693b = new HashMap();
        this.f5694c = new HashMap();
        this.f60a = new aux();
        this.f61a = new HashMap(map);
    }

    public static lpt4 a(Bundle bundle, Bundle bundle2) {
        if (bundle == null && bundle2 == null) {
            return new lpt4();
        }
        HashMap map = new HashMap();
        if (bundle2 != null) {
            for (String str : bundle2.keySet()) {
                map.put(str, bundle2.get(str));
            }
        }
        if (bundle == null) {
            return new lpt4(map);
        }
        ArrayList parcelableArrayList = bundle.getParcelableArrayList("keys");
        ArrayList parcelableArrayList2 = bundle.getParcelableArrayList("values");
        if (parcelableArrayList == null || parcelableArrayList2 == null || parcelableArrayList.size() != parcelableArrayList2.size()) {
            throw new IllegalStateException("Invalid bundle passed as restored state");
        }
        for (int i2 = 0; i2 < parcelableArrayList.size(); i2++) {
            map.put((String) parcelableArrayList.get(i2), parcelableArrayList2.get(i2));
        }
        return new lpt4(map);
    }

    public static void d(Object obj) {
        if (obj == null) {
            return;
        }
        for (Class cls : f5692a) {
            if (cls.isInstance(obj)) {
                return;
            }
        }
        throw new IllegalArgumentException("Can't put value with type " + obj.getClass() + " into saved state");
    }

    public SavedStateRegistry.con b() {
        return this.f60a;
    }

    public <T> void c(String str, T t2) {
        d(t2);
        lpt1 lpt1Var = (lpt1) this.f5694c.get(str);
        if (lpt1Var != null) {
            lpt1Var.i(t2);
        } else {
            this.f61a.put(str, t2);
        }
    }

    public lpt4() {
        this.f5693b = new HashMap();
        this.f5694c = new HashMap();
        this.f60a = new aux();
        this.f61a = new HashMap();
    }
}
