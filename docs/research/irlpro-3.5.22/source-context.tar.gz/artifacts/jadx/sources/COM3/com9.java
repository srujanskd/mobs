package COM3;

import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class com9 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Map<String, Integer> f5691a = new HashMap();
}
