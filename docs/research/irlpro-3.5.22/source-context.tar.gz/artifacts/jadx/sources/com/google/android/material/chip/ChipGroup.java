package com.google.android.material.chip;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import java.util.Set;
import p024Com2.y;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p081cOm2.e2;
import p108com9.h;
import p108com9.l;
import p108com9.t;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
public class ChipGroup extends l {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final int f9405g = g4.f8971p;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public com1 f9406a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com2 f3410a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final h<Chip> f3411a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9407d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9408e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f9409f;

    public class aux implements h.con {
        public aux() {
        }

        @Override // com9.h.con
        public void a(Set<Integer> set) {
            if (ChipGroup.this.f9406a != null) {
                com1 com1Var = ChipGroup.this.f9406a;
                ChipGroup chipGroup = ChipGroup.this;
                com1Var.a(chipGroup, chipGroup.f3411a.j(ChipGroup.this));
            }
        }
    }

    public interface com1 {
        void a(ChipGroup chipGroup, List<Integer> list);
    }

    public class com2 implements ViewGroup.OnHierarchyChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public ViewGroup.OnHierarchyChangeListener f9411a;

        public com2() {
        }

        @Override // android.view.ViewGroup.OnHierarchyChangeListener
        public void onChildViewAdded(View view, View view2) {
            if (view == ChipGroup.this && (view2 instanceof Chip)) {
                if (view2.getId() == -1) {
                    view2.setId(y.j());
                }
                ChipGroup.this.f3411a.e((Chip) view2);
            }
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f9411a;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        @Override // android.view.ViewGroup.OnHierarchyChangeListener
        public void onChildViewRemoved(View view, View view2) {
            ChipGroup chipGroup = ChipGroup.this;
            if (view == chipGroup && (view2 instanceof Chip)) {
                chipGroup.f3411a.n((Chip) view2);
            }
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f9411a;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }

        public /* synthetic */ com2(ChipGroup chipGroup, aux auxVar) {
            this();
        }
    }

    public class con implements com1 {
        public con(prn prnVar) {
        }

        @Override // com.google.android.material.chip.ChipGroup.com1
        public void a(ChipGroup chipGroup, List<Integer> list) {
            if (ChipGroup.this.f3411a.l()) {
                ChipGroup.this.getCheckedChipId();
                throw null;
            }
        }
    }

    public static class nul extends ViewGroup.MarginLayoutParams {
        public nul(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public nul(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public nul(int i2, int i3) {
            super(i2, i3);
        }
    }

    @Deprecated
    public interface prn {
    }

    public ChipGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.f9031f);
    }

    private int getChipCount() {
        int i2 = 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            if (getChildAt(i3) instanceof Chip) {
                i2++;
            }
        }
        return i2;
    }

    @Override // p108com9.l
    public boolean c() {
        return super.c();
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof nul);
    }

    public int g(View view) {
        if (!(view instanceof Chip)) {
            return -1;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            if (getChildAt(i3) instanceof Chip) {
                if (((Chip) getChildAt(i3)) == view) {
                    return i2;
                }
                i2++;
            }
        }
        return -1;
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new nul(-2, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new nul(getContext(), attributeSet);
    }

    public int getCheckedChipId() {
        return this.f3411a.k();
    }

    public List<Integer> getCheckedChipIds() {
        return this.f3411a.j(this);
    }

    public int getChipSpacingHorizontal() {
        return this.f9407d;
    }

    public int getChipSpacingVertical() {
        return this.f9408e;
    }

    public boolean h() {
        return this.f3411a.l();
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        int i2 = this.f9409f;
        if (i2 != -1) {
            this.f3411a.f(i2);
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        e2.z0(accessibilityNodeInfo).V(e2.con.a(getRowCount(), c() ? getChipCount() : -1, false, h() ? 1 : 2));
    }

    public void setChipSpacing(int i2) {
        setChipSpacingHorizontal(i2);
        setChipSpacingVertical(i2);
    }

    public void setChipSpacingHorizontal(int i2) {
        if (this.f9407d != i2) {
            this.f9407d = i2;
            setItemSpacing(i2);
            requestLayout();
        }
    }

    public void setChipSpacingHorizontalResource(int i2) {
        setChipSpacingHorizontal(getResources().getDimensionPixelOffset(i2));
    }

    public void setChipSpacingResource(int i2) {
        setChipSpacing(getResources().getDimensionPixelOffset(i2));
    }

    public void setChipSpacingVertical(int i2) {
        if (this.f9408e != i2) {
            this.f9408e = i2;
            setLineSpacing(i2);
            requestLayout();
        }
    }

    public void setChipSpacingVerticalResource(int i2) {
        setChipSpacingVertical(getResources().getDimensionPixelOffset(i2));
    }

    @Deprecated
    public void setDividerDrawableHorizontal(Drawable drawable) {
        throw new UnsupportedOperationException("Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Deprecated
    public void setDividerDrawableVertical(Drawable drawable) {
        throw new UnsupportedOperationException("Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Deprecated
    public void setFlexWrap(int i2) {
        throw new UnsupportedOperationException("Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead.");
    }

    @Deprecated
    public void setOnCheckedChangeListener(prn prnVar) {
        if (prnVar == null) {
            setOnCheckedStateChangeListener(null);
        } else {
            setOnCheckedStateChangeListener(new con(prnVar));
        }
    }

    public void setOnCheckedStateChangeListener(com1 com1Var) {
        this.f9406a = com1Var;
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f3410a.f9411a = onHierarchyChangeListener;
    }

    public void setSelectionRequired(boolean z2) {
        this.f3411a.p(z2);
    }

    @Deprecated
    public void setShowDividerHorizontal(int i2) {
        throw new UnsupportedOperationException("Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Deprecated
    public void setShowDividerVertical(int i2) {
        throw new UnsupportedOperationException("Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Override // p108com9.l
    public void setSingleLine(boolean z2) {
        super.setSingleLine(z2);
    }

    public void setSingleSelection(boolean z2) {
        this.f3411a.q(z2);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public ChipGroup(Context context, AttributeSet attributeSet, int i2) {
        int i3 = f9405g;
        super(u.c(context, attributeSet, i2, i3), attributeSet, i2);
        h<Chip> hVar = new h<>();
        this.f3411a = hVar;
        com2 com2Var = new com2(this, null);
        this.f3410a = com2Var;
        TypedArray typedArrayH = t.h(getContext(), attributeSet, h4.f3050A, i2, i3, new int[0]);
        int dimensionPixelOffset = typedArrayH.getDimensionPixelOffset(h4.z0, 0);
        setChipSpacingHorizontal(typedArrayH.getDimensionPixelOffset(h4.A0, dimensionPixelOffset));
        setChipSpacingVertical(typedArrayH.getDimensionPixelOffset(h4.B0, dimensionPixelOffset));
        setSingleLine(typedArrayH.getBoolean(h4.D0, false));
        setSingleSelection(typedArrayH.getBoolean(h4.E0, false));
        setSelectionRequired(typedArrayH.getBoolean(h4.C0, false));
        this.f9409f = typedArrayH.getResourceId(h4.y0, -1);
        typedArrayH.recycle();
        hVar.o(new aux());
        super.setOnHierarchyChangeListener(com2Var);
        y.y0(this, 1);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new nul(layoutParams);
    }

    public void setSingleLine(int i2) {
        setSingleLine(getResources().getBoolean(i2));
    }

    public void setSingleSelection(int i2) {
        setSingleSelection(getResources().getBoolean(i2));
    }
}
