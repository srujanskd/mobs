package NUL;

import p146nUL.o;
import p146nUL.p;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt3 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7407a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com9 f1382a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p.con f1384a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p f1385a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f1381a = new com3(this);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7408b = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1386a = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com2 f1380a = new com2(this);

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public com2 f1387b = new com2(this);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f1383a = con.NONE;

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f7409a;

        static {
            int[] iArr = new int[o.con.values().length];
            f7409a = iArr;
            try {
                iArr[o.con.LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f7409a[o.con.RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f7409a[o.con.TOP.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f7409a[o.con.BASELINE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f7409a[o.con.BOTTOM.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public enum con {
        NONE,
        START,
        END,
        CENTER
    }

    public lpt3(p pVar) {
        this.f1385a = pVar;
    }

    @Override // NUL.prn
    public void a(prn prnVar) {
    }

    public final void b(com2 com2Var, com2 com2Var2, int i2) {
        com2Var.f1360b.add(com2Var2);
        com2Var.f7364a = i2;
        com2Var2.f1358a.add(com2Var);
    }

    public final void c(com2 com2Var, com2 com2Var2, int i2, com3 com3Var) {
        com2Var.f1360b.add(com2Var2);
        com2Var.f1360b.add(this.f1381a);
        com2Var.f7366c = i2;
        com2Var.f1355a = com3Var;
        com2Var2.f1358a.add(com2Var);
        ((com2) com3Var).f1358a.add(com2Var);
    }

    public abstract void d();

    public abstract void e();

    public abstract void f();

    public final int g(int i2, int i3) {
        int iMax;
        if (i3 == 0) {
            p pVar = this.f1385a;
            int i4 = pVar.f11503i;
            iMax = Math.max(pVar.f4980h, i2);
            if (i4 > 0) {
                iMax = Math.min(i4, i2);
            }
            if (iMax == i2) {
                return i2;
            }
        } else {
            p pVar2 = this.f1385a;
            int i5 = pVar2.f11505k;
            iMax = Math.max(pVar2.f11504j, i2);
            if (i5 > 0) {
                iMax = Math.min(i5, i2);
            }
            if (iMax == i2) {
                return i2;
            }
        }
        return iMax;
    }

    public final com2 h(o oVar) {
        o oVar2 = oVar.f4932a;
        if (oVar2 == null) {
            return null;
        }
        p pVar = oVar2.f4933a;
        int i2 = aux.f7409a[oVar2.f4931a.ordinal()];
        if (i2 == 1) {
            return ((lpt3) pVar.f4937a).f1380a;
        }
        if (i2 == 2) {
            return ((lpt3) pVar.f4937a).f1387b;
        }
        if (i2 == 3) {
            return ((lpt3) pVar.f4938a).f1380a;
        }
        if (i2 == 4) {
            return pVar.f4938a.f7395c;
        }
        if (i2 != 5) {
            return null;
        }
        return ((lpt3) pVar.f4938a).f1387b;
    }

    public final com2 i(o oVar, int i2) {
        o oVar2 = oVar.f4932a;
        if (oVar2 == null) {
            return null;
        }
        p pVar = oVar2.f4933a;
        lpt3 lpt3Var = i2 == 0 ? pVar.f4937a : pVar.f4938a;
        int i3 = aux.f7409a[oVar2.f4931a.ordinal()];
        if (i3 != 1) {
            if (i3 != 2) {
                if (i3 != 3) {
                    if (i3 != 5) {
                        return null;
                    }
                }
            }
            return lpt3Var.f1387b;
        }
        return lpt3Var.f1380a;
    }

    public long j() {
        com3 com3Var = this.f1381a;
        if (((com2) com3Var).f1362c) {
            return ((com2) com3Var).f7365b;
        }
        return 0L;
    }

    public boolean k() {
        return this.f1386a;
    }

    public final void l(int i2, int i3) {
        int i4 = this.f7407a;
        if (i4 == 0) {
            this.f1381a.d(g(i3, i2));
            return;
        }
        if (i4 == 1) {
            this.f1381a.d(Math.min(g(this.f1381a.f7375d, i2), i3));
            return;
        }
        if (i4 == 2) {
            p pVarI = this.f1385a.I();
            if (pVarI != null) {
                com3 com3Var = (i2 == 0 ? pVarI.f4937a : pVarI.f4938a).f1381a;
                if (((com2) com3Var).f1362c) {
                    p pVar = this.f1385a;
                    this.f1381a.d(g((int) ((((com2) com3Var).f7365b * (i2 == 0 ? pVar.f11496a : pVar.f11497b)) + 0.5f), i2));
                    return;
                }
                return;
            }
            return;
        }
        if (i4 != 3) {
            return;
        }
        p pVar2 = this.f1385a;
        lpt3 lpt3Var = pVar2.f4937a;
        p.con conVar = lpt3Var.f1384a;
        p.con conVar2 = p.con.MATCH_CONSTRAINT;
        if (conVar == conVar2 && lpt3Var.f7407a == 3) {
            lpt1 lpt1Var = pVar2.f4938a;
            if (((lpt3) lpt1Var).f1384a == conVar2 && ((lpt3) lpt1Var).f7407a == 3) {
                return;
            }
        }
        if (i2 == 0) {
            lpt3Var = pVar2.f4938a;
        }
        if (((com2) lpt3Var.f1381a).f1362c) {
            float fT = pVar2.t();
            this.f1381a.d(i2 == 1 ? (int) ((((com2) lpt3Var.f1381a).f7365b / fT) + 0.5f) : (int) ((fT * ((com2) lpt3Var.f1381a).f7365b) + 0.5f));
        }
    }

    public abstract boolean m();

    public void n(prn prnVar, o oVar, o oVar2, int i2) {
        com2 com2VarH = h(oVar);
        com2 com2VarH2 = h(oVar2);
        if (com2VarH.f1362c && com2VarH2.f1362c) {
            int iE = com2VarH.f7365b + oVar.e();
            int iE2 = com2VarH2.f7365b - oVar2.e();
            int i3 = iE2 - iE;
            if (!((com2) this.f1381a).f1362c && this.f1384a == p.con.MATCH_CONSTRAINT) {
                l(i2, i3);
            }
            com3 com3Var = this.f1381a;
            if (((com2) com3Var).f1362c) {
                if (((com2) com3Var).f7365b == i3) {
                    this.f1380a.d(iE);
                    this.f1387b.d(iE2);
                    return;
                }
                p pVar = this.f1385a;
                float fW = i2 == 0 ? pVar.w() : pVar.P();
                if (com2VarH == com2VarH2) {
                    iE = com2VarH.f7365b;
                    iE2 = com2VarH2.f7365b;
                    fW = 0.5f;
                }
                this.f1380a.d((int) (iE + 0.5f + (((iE2 - iE) - ((com2) this.f1381a).f7365b) * fW)));
                this.f1387b.d(this.f1380a.f7365b + ((com2) this.f1381a).f7365b);
            }
        }
    }

    public void o(prn prnVar) {
    }

    public void p(prn prnVar) {
    }
}
