package NUL;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class com2 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7364a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt3 f1356a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7365b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f1357a = null;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1359a = false;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1361b = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public aux f1354a = aux.UNKNOWN;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7366c = 1;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f1355a = null;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1362c = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<prn> f1358a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public List<com2> f1360b = new ArrayList();

    public enum aux {
        UNKNOWN,
        HORIZONTAL_DIMENSION,
        VERTICAL_DIMENSION,
        LEFT,
        RIGHT,
        TOP,
        BOTTOM,
        BASELINE
    }

    public com2(lpt3 lpt3Var) {
        this.f1356a = lpt3Var;
    }

    @Override // NUL.prn
    public void a(prn prnVar) {
        Iterator<com2> it = this.f1360b.iterator();
        while (it.hasNext()) {
            if (!it.next().f1362c) {
                return;
            }
        }
        this.f1361b = true;
        prn prnVar2 = this.f1357a;
        if (prnVar2 != null) {
            prnVar2.a(this);
        }
        if (this.f1359a) {
            this.f1356a.a(this);
            return;
        }
        com2 com2Var = null;
        int i2 = 0;
        for (com2 com2Var2 : this.f1360b) {
            if (!(com2Var2 instanceof com3)) {
                i2++;
                com2Var = com2Var2;
            }
        }
        if (com2Var != null && i2 == 1 && com2Var.f1362c) {
            com3 com3Var = this.f1355a;
            if (com3Var != null) {
                if (!((com2) com3Var).f1362c) {
                    return;
                } else {
                    this.f7364a = this.f7366c * ((com2) com3Var).f7365b;
                }
            }
            d(com2Var.f7365b + this.f7364a);
        }
        prn prnVar3 = this.f1357a;
        if (prnVar3 != null) {
            prnVar3.a(this);
        }
    }

    public void b(prn prnVar) {
        this.f1358a.add(prnVar);
        if (this.f1362c) {
            prnVar.a(prnVar);
        }
    }

    public void c() {
        this.f1360b.clear();
        this.f1358a.clear();
        this.f1362c = false;
        this.f7365b = 0;
        this.f1361b = false;
        this.f1359a = false;
    }

    public void d(int i2) {
        if (this.f1362c) {
            return;
        }
        this.f1362c = true;
        this.f7365b = i2;
        for (prn prnVar : this.f1358a) {
            prnVar.a(prnVar);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f1356a.f1385a.r());
        sb.append(":");
        sb.append(this.f1354a);
        sb.append("(");
        sb.append(this.f1362c ? Integer.valueOf(this.f7365b) : "unresolved");
        sb.append(") <t=");
        sb.append(this.f1360b.size());
        sb.append(":d=");
        sb.append(this.f1358a.size());
        sb.append(">");
        return sb.toString();
    }
}
