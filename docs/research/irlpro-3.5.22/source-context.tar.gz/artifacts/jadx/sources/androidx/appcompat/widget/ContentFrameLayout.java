package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f7902a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TypedValue f2005a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public aux f2006a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public TypedValue f7903b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f7904c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TypedValue f7905d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TypedValue f7906e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TypedValue f7907f;

    public interface aux {
        void a();

        void onDetachedFromWindow();
    }

    public ContentFrameLayout(Context context) {
        this(context, null);
    }

    public void a(int i2, int i3, int i4, int i5) {
        this.f7902a.set(i2, i3, i4, i5);
        if (y.S(this)) {
            requestLayout();
        }
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f7906e == null) {
            this.f7906e = new TypedValue();
        }
        return this.f7906e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f7907f == null) {
            this.f7907f = new TypedValue();
        }
        return this.f7907f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f7904c == null) {
            this.f7904c = new TypedValue();
        }
        return this.f7904c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f7905d == null) {
            this.f7905d = new TypedValue();
        }
        return this.f7905d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f2005a == null) {
            this.f2005a = new TypedValue();
        }
        return this.f2005a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f7903b == null) {
            this.f7903b = new TypedValue();
        }
        return this.f7903b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        aux auxVar = this.f2006a;
        if (auxVar != null) {
            auxVar.a();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        aux auxVar = this.f2006a;
        if (auxVar != null) {
            auxVar.onDetachedFromWindow();
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004a  */
    /* JADX WARN: Code duplicated, block: B:22:0x0060  */
    /* JADX WARN: Code duplicated, block: B:37:0x0086  */
    /* JADX WARN: Code duplicated, block: B:54:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:56:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:57:0x00db  */
    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        boolean z2;
        int i4;
        int i5;
        float fraction;
        int i6;
        int i7;
        float fraction2;
        int i8;
        int i9;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z3 = true;
        boolean z4 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        if (mode != Integer.MIN_VALUE) {
            z2 = false;
        } else {
            TypedValue typedValue = z4 ? this.f7905d : this.f7904c;
            if (typedValue == null || (i8 = typedValue.type) == 0) {
                z2 = false;
            } else {
                if (i8 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else {
                    if (i8 == 6) {
                        int i10 = displayMetrics.widthPixels;
                        fraction3 = typedValue.getFraction(i10, i10);
                    } else {
                        i9 = 0;
                    }
                    if (i9 > 0) {
                        Rect rect = this.f7902a;
                        i2 = View.MeasureSpec.makeMeasureSpec(Math.min(i9 - (rect.left + rect.right), View.MeasureSpec.getSize(i2)), 1073741824);
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                }
                i9 = (int) fraction3;
                if (i9 > 0) {
                    Rect rect2 = this.f7902a;
                    i2 = View.MeasureSpec.makeMeasureSpec(Math.min(i9 - (rect2.left + rect2.right), View.MeasureSpec.getSize(i2)), 1073741824);
                    z2 = true;
                } else {
                    z2 = false;
                }
            }
        }
        if (mode2 == Integer.MIN_VALUE) {
            TypedValue typedValue2 = z4 ? this.f7906e : this.f7907f;
            if (typedValue2 != null && (i6 = typedValue2.type) != 0) {
                if (i6 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else {
                    if (i6 == 6) {
                        int i11 = displayMetrics.heightPixels;
                        fraction2 = typedValue2.getFraction(i11, i11);
                    } else {
                        i7 = 0;
                    }
                    if (i7 > 0) {
                        Rect rect3 = this.f7902a;
                        i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i7 - (rect3.top + rect3.bottom), View.MeasureSpec.getSize(i3)), 1073741824);
                    }
                }
                i7 = (int) fraction2;
                if (i7 > 0) {
                    Rect rect4 = this.f7902a;
                    i3 = View.MeasureSpec.makeMeasureSpec(Math.min(i7 - (rect4.top + rect4.bottom), View.MeasureSpec.getSize(i3)), 1073741824);
                }
            }
        }
        super.onMeasure(i2, i3);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z2 || mode != Integer.MIN_VALUE) {
            z3 = false;
        } else {
            TypedValue typedValue3 = z4 ? this.f7903b : this.f2005a;
            if (typedValue3 == null || (i4 = typedValue3.type) == 0) {
                z3 = false;
            } else {
                if (i4 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else {
                    if (i4 == 6) {
                        int i12 = displayMetrics.widthPixels;
                        fraction = typedValue3.getFraction(i12, i12);
                    } else {
                        i5 = 0;
                    }
                    if (i5 > 0) {
                        Rect rect5 = this.f7902a;
                        i5 -= rect5.left + rect5.right;
                    }
                    if (measuredWidth < i5) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
                    } else {
                        z3 = false;
                    }
                }
                i5 = (int) fraction;
                if (i5 > 0) {
                    Rect rect6 = this.f7902a;
                    i5 -= rect6.left + rect6.right;
                }
                if (measuredWidth < i5) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
                } else {
                    z3 = false;
                }
            }
        }
        if (z3) {
            super.onMeasure(iMakeMeasureSpec, i3);
        }
    }

    public void setAttachListener(aux auxVar) {
        this.f2006a = auxVar;
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f7902a = new Rect();
    }
}
