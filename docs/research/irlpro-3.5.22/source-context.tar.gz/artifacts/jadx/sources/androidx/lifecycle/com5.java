package androidx.lifecycle;

import COM3.com8;
import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class com5 extends Fragment {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public aux f8403a;

    public interface aux {
        void a();

        void b();

        void c();
    }

    public static class con implements Application.ActivityLifecycleCallbacks {
        public static void registerIn(Activity activity) {
            activity.registerActivityLifecycleCallbacks(new con());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            com5.a(activity, nul.con.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            com5.a(activity, nul.con.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            com5.a(activity, nul.con.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            com5.a(activity, nul.con.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            com5.a(activity, nul.con.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            com5.a(activity, nul.con.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, nul.con conVar) {
        if (activity instanceof com8) {
            ((com8) activity).u().h(conVar);
        } else if (activity instanceof COM3.com7) {
            nul lifecycle = ((COM3.com7) activity).getLifecycle();
            if (lifecycle instanceof com1) {
                ((com1) lifecycle).h(conVar);
            }
        }
    }

    public static com5 f(Activity activity) {
        return (com5) activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
    }

    public static void g(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            con.registerIn(activity);
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new com5(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    public final void b(nul.con conVar) {
        if (Build.VERSION.SDK_INT < 29) {
            a(getActivity(), conVar);
        }
    }

    public final void c(aux auxVar) {
        if (auxVar != null) {
            auxVar.b();
        }
    }

    public final void d(aux auxVar) {
        if (auxVar != null) {
            auxVar.c();
        }
    }

    public final void e(aux auxVar) {
        if (auxVar != null) {
            auxVar.a();
        }
    }

    public void h(aux auxVar) {
        this.f8403a = auxVar;
    }

    @Override // android.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        c(this.f8403a);
        b(nul.con.ON_CREATE);
    }

    @Override // android.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        b(nul.con.ON_DESTROY);
        this.f8403a = null;
    }

    @Override // android.app.Fragment
    public void onPause() {
        super.onPause();
        b(nul.con.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public void onResume() {
        super.onResume();
        d(this.f8403a);
        b(nul.con.ON_RESUME);
    }

    @Override // android.app.Fragment
    public void onStart() {
        super.onStart();
        e(this.f8403a);
        b(nul.con.ON_START);
    }

    @Override // android.app.Fragment
    public void onStop() {
        super.onStop();
        b(nul.con.ON_STOP);
    }
}
