package LPT1;

import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class com9 extends com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p052Lpt2.lpt4<String, com6> f6582a = new p052Lpt2.lpt4<>();

    public boolean equals(Object obj) {
        return obj == this || ((obj instanceof com9) && ((com9) obj).f6582a.equals(this.f6582a));
    }

    public void h(String str, com6 com6Var) {
        p052Lpt2.lpt4<String, com6> lpt4Var = this.f6582a;
        if (com6Var == null) {
            com6Var = com8.f6581a;
        }
        lpt4Var.put(str, com6Var);
    }

    public int hashCode() {
        return this.f6582a.hashCode();
    }

    public Set<Map.Entry<String, com6>> i() {
        return this.f6582a.entrySet();
    }
}
