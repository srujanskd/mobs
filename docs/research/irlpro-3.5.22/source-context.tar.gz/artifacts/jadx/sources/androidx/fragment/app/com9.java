package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class com9 implements Parcelable {
    public static final Parcelable.Creator<com9> CREATOR = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f8283a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Bundle f2483a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final String f2484a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f8284b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Bundle f2485b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final String f2486b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f2487b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f8285c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final String f2488c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final boolean f2489c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f8286d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f8287e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f8288f;

    public class aux implements Parcelable.Creator<com9> {
        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public com9 createFromParcel(Parcel parcel) {
            return new com9(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public com9[] newArray(int i2) {
            return new com9[i2];
        }
    }

    public com9(Fragment fragment) {
        this.f2484a = fragment.getClass().getName();
        this.f2486b = fragment.mWho;
        this.f2487b = fragment.mFromLayout;
        this.f8283a = fragment.mFragmentId;
        this.f8284b = fragment.mContainerId;
        this.f2488c = fragment.mTag;
        this.f2489c = fragment.mRetainInstance;
        this.f8286d = fragment.mRemoving;
        this.f8287e = fragment.mDetached;
        this.f2483a = fragment.mArguments;
        this.f8288f = fragment.mHidden;
        this.f8285c = fragment.mMaxState.ordinal();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f2484a);
        sb.append(" (");
        sb.append(this.f2486b);
        sb.append(")}:");
        if (this.f2487b) {
            sb.append(" fromLayout");
        }
        if (this.f8284b != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f8284b));
        }
        String str = this.f2488c;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(this.f2488c);
        }
        if (this.f2489c) {
            sb.append(" retainInstance");
        }
        if (this.f8286d) {
            sb.append(" removing");
        }
        if (this.f8287e) {
            sb.append(" detached");
        }
        if (this.f8288f) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f2484a);
        parcel.writeString(this.f2486b);
        parcel.writeInt(this.f2487b ? 1 : 0);
        parcel.writeInt(this.f8283a);
        parcel.writeInt(this.f8284b);
        parcel.writeString(this.f2488c);
        parcel.writeInt(this.f2489c ? 1 : 0);
        parcel.writeInt(this.f8286d ? 1 : 0);
        parcel.writeInt(this.f8287e ? 1 : 0);
        parcel.writeBundle(this.f2483a);
        parcel.writeInt(this.f8288f ? 1 : 0);
        parcel.writeBundle(this.f2485b);
        parcel.writeInt(this.f8285c);
    }

    public com9(Parcel parcel) {
        this.f2484a = parcel.readString();
        this.f2486b = parcel.readString();
        this.f2487b = parcel.readInt() != 0;
        this.f8283a = parcel.readInt();
        this.f8284b = parcel.readInt();
        this.f2488c = parcel.readString();
        this.f2489c = parcel.readInt() != 0;
        this.f8286d = parcel.readInt() != 0;
        this.f8287e = parcel.readInt() != 0;
        this.f2483a = parcel.readBundle();
        this.f8288f = parcel.readInt() != 0;
        this.f2485b = parcel.readBundle();
        this.f8285c = parcel.readInt();
    }
}
