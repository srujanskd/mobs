package LPT6;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Function;
import java.util.stream.Stream;
import p039LPt7.i4;
import p115lPT6.j3;

/* JADX INFO: loaded from: classes.dex */
public interface nul extends com3, com4 {
    /* JADX INFO: Access modifiers changed from: private */
    static /* synthetic */ Stream lambda$stream$0(Stream stream) {
        return stream;
    }

    /* JADX INFO: Access modifiers changed from: private */
    static /* synthetic */ Stream lambda$stream$1(Stream stream) {
        return stream;
    }

    @SafeVarargs
    static <T extends j3> Stream<T> stream(Function<T, Stream<? extends T>> function, T... tArr) {
        return Arrays.stream(tArr).map(function).flatMap(new Function() { // from class: LPT6.con
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return nul.lambda$stream$0((Stream) obj);
            }
        });
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com3, java.lang.Comparable
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsPrefixBlock(int i2) {
        return super.containsPrefixBlock(i2);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsSinglePrefixBlock(int i2) {
        return super.containsSinglePrefixBlock(i2);
    }

    @Override // LPT6.com3
    /* synthetic */ int getBitCount();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int getByteCount() {
        return super.getByteCount();
    }

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes();

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr);

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr, int i2);

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getCount() {
        return super.getCount();
    }

    Iterable<? extends j3> getIterable();

    j3 getLower();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int getMinPrefixLengthForBlock() {
        return super.getMinPrefixLengthForBlock();
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getPrefixCount(int i2) {
        return super.getPrefixCount(i2);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default Integer getPrefixLengthForSingleBlock() {
        return super.getPrefixLengthForSingleBlock();
    }

    j3 getUpper();

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes();

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr);

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr, int i2);

    @Override // LPT6.com3
    /* synthetic */ BigInteger getUpperValue();

    @Override // LPT6.com3
    /* synthetic */ BigInteger getValue();

    @Override // LPT6.com3
    /* synthetic */ boolean includesMax();

    @Override // LPT6.com3
    /* synthetic */ boolean includesZero();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean isFullRange() {
        return super.isFullRange();
    }

    @Override // LPT6.com3
    /* synthetic */ boolean isMax();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean isMultiple() {
        return super.isMultiple();
    }

    @Override // LPT6.com3
    /* synthetic */ boolean isZero();

    Iterator<? extends j3> iterator();

    i4<? extends nul, ? extends j3> spliterator();

    Stream<? extends j3> stream();

    static <T extends j3> Stream<T> stream(Function<T, Stream<? extends T>> function, Collection<? extends T> collection) {
        return collection.stream().map(function).flatMap(new Function() { // from class: LPT6.aux
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return nul.lambda$stream$1((Stream) obj);
            }
        });
    }
}
