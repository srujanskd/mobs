package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import p024Com2.f;
import p024Com2.y;
import p099coN.f1;

/* JADX INFO: loaded from: classes.dex */
public class com4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f7811a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f1873a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1874a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PopupWindow.OnDismissListener f1875a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com1 f1876a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1877a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public f1 f1878a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f1879a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7812b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final PopupWindow.OnDismissListener f1880b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1881b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7813c;

    public class aux implements PopupWindow.OnDismissListener {
        public aux() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            com4.this.e();
        }
    }

    public com4(Context context, com1 com1Var, View view, boolean z2, int i2) {
        this(context, com1Var, view, z2, i2, 0);
    }

    public final f1 a() {
        Display defaultDisplay = ((WindowManager) this.f1873a.getSystemService("window")).getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getRealSize(point);
        f1 conVar = Math.min(point.x, point.y) >= this.f1873a.getResources().getDimensionPixelSize(p001AuX.com6.f5530c) ? new con(this.f1873a, this.f1874a, this.f7811a, this.f7812b, this.f1879a) : new com7(this.f1873a, this.f1876a, this.f1874a, this.f7811a, this.f7812b, this.f1879a);
        conVar.l(this.f1876a);
        conVar.u(this.f1880b);
        conVar.p(this.f1874a);
        conVar.g(this.f1877a);
        conVar.r(this.f1881b);
        conVar.s(this.f7813c);
        return conVar;
    }

    public void b() {
        if (d()) {
            this.f1878a.dismiss();
        }
    }

    public f1 c() {
        if (this.f1878a == null) {
            this.f1878a = a();
        }
        return this.f1878a;
    }

    public boolean d() {
        f1 f1Var = this.f1878a;
        return f1Var != null && f1Var.b();
    }

    public void e() {
        this.f1878a = null;
        PopupWindow.OnDismissListener onDismissListener = this.f1875a;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public void f(View view) {
        this.f1874a = view;
    }

    public void g(boolean z2) {
        this.f1881b = z2;
        f1 f1Var = this.f1878a;
        if (f1Var != null) {
            f1Var.r(z2);
        }
    }

    public void h(int i2) {
        this.f7813c = i2;
    }

    public void i(PopupWindow.OnDismissListener onDismissListener) {
        this.f1875a = onDismissListener;
    }

    public void j(com5.aux auxVar) {
        this.f1877a = auxVar;
        f1 f1Var = this.f1878a;
        if (f1Var != null) {
            f1Var.g(auxVar);
        }
    }

    public void k() {
        if (!m()) {
            throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
        }
    }

    public final void l(int i2, int i3, boolean z2, boolean z3) {
        f1 f1VarC = c();
        f1VarC.v(z3);
        if (z2) {
            if ((f.b(this.f7813c, y.A(this.f1874a)) & 7) == 5) {
                i2 -= this.f1874a.getWidth();
            }
            f1VarC.t(i2);
            f1VarC.w(i3);
            int i4 = (int) ((this.f1873a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            f1VarC.q(new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4));
        }
        f1VarC.a();
    }

    public boolean m() {
        if (d()) {
            return true;
        }
        if (this.f1874a == null) {
            return false;
        }
        l(0, 0, false, false);
        return true;
    }

    public boolean n(int i2, int i3) {
        if (d()) {
            return true;
        }
        if (this.f1874a == null) {
            return false;
        }
        l(i2, i3, true, true);
        return true;
    }

    public com4(Context context, com1 com1Var, View view, boolean z2, int i2, int i3) {
        this.f7813c = 8388611;
        this.f1880b = new aux();
        this.f1873a = context;
        this.f1876a = com1Var;
        this.f1874a = view;
        this.f1879a = z2;
        this.f7811a = i2;
        this.f7812b = i3;
    }
}
