package androidx.fragment.app;

import android.view.ViewGroup;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8297a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com2 f2507a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2508a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ClassLoader f2509a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2510a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2512a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8298b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f2513b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ArrayList<String> f2514b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8299c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ArrayList<String> f2516c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8300d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public ArrayList<Runnable> f2518d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f8301e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8302f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8303g;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<aux> f2511a = new ArrayList<>();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2515b = true;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2517c = false;

    public static final class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8304a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Fragment f2519a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.lifecycle.nul.EnumC0039nul f2520a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8305b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public androidx.lifecycle.nul.EnumC0039nul f2521b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8306c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8307d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8308e;

        public aux() {
        }

        public aux(int i2, Fragment fragment) {
            this.f8304a = i2;
            this.f2519a = fragment;
            androidx.lifecycle.nul.EnumC0039nul enumC0039nul = androidx.lifecycle.nul.EnumC0039nul.RESUMED;
            this.f2520a = enumC0039nul;
            this.f2521b = enumC0039nul;
        }
    }

    public lpt3(com2 com2Var, ClassLoader classLoader) {
        this.f2507a = com2Var;
        this.f2509a = classLoader;
    }

    public lpt3 b(int i2, Fragment fragment) {
        o(i2, fragment, null, 1);
        return this;
    }

    public lpt3 c(int i2, Fragment fragment, String str) {
        o(i2, fragment, str, 1);
        return this;
    }

    public lpt3 d(ViewGroup viewGroup, Fragment fragment, String str) {
        fragment.mContainer = viewGroup;
        return c(viewGroup.getId(), fragment, str);
    }

    public lpt3 e(Fragment fragment, String str) {
        o(0, fragment, str, 1);
        return this;
    }

    public void f(aux auxVar) {
        this.f2511a.add(auxVar);
        auxVar.f8305b = this.f8297a;
        auxVar.f8306c = this.f8298b;
        auxVar.f8307d = this.f8299c;
        auxVar.f8308e = this.f8300d;
    }

    public lpt3 g(String str) {
        if (!this.f2515b) {
            throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
        }
        this.f2512a = true;
        this.f2510a = str;
        return this;
    }

    public lpt3 h(Fragment fragment) {
        f(new aux(7, fragment));
        return this;
    }

    public abstract int i();

    public abstract int j();

    public abstract void k();

    public abstract void l();

    public lpt3 m(Fragment fragment) {
        f(new aux(6, fragment));
        return this;
    }

    public lpt3 n() {
        if (this.f2512a) {
            throw new IllegalStateException("This transaction is already being added to the back stack");
        }
        this.f2515b = false;
        return this;
    }

    public void o(int i2, Fragment fragment, String str, int i3) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str2 = fragment.mTag;
            if (str2 != null && !str.equals(str2)) {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.mTag + " now " + str);
            }
            fragment.mTag = str;
        }
        if (i2 != 0) {
            if (i2 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
            int i4 = fragment.mFragmentId;
            if (i4 != 0 && i4 != i2) {
                throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.mFragmentId + " now " + i2);
            }
            fragment.mFragmentId = i2;
            fragment.mContainerId = i2;
        }
        f(new aux(i3, fragment));
    }

    public lpt3 p(Fragment fragment) {
        f(new aux(3, fragment));
        return this;
    }

    public lpt3 q(int i2, Fragment fragment) {
        return r(i2, fragment, null);
    }

    public lpt3 r(int i2, Fragment fragment, String str) {
        if (i2 == 0) {
            throw new IllegalArgumentException("Must use non-zero containerViewId");
        }
        o(i2, fragment, str, 2);
        return this;
    }

    public lpt3 s(Fragment fragment) {
        f(new aux(8, fragment));
        return this;
    }

    public lpt3 t(boolean z2) {
        this.f2517c = z2;
        return this;
    }

    public lpt3 u(int i2) {
        this.f8301e = i2;
        return this;
    }
}
