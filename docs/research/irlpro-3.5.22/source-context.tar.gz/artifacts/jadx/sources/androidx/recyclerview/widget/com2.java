package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class com2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8658a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8659b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2865b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8660c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2866c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8661d;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2864a = true;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f8662e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8663f = 0;

    public boolean a(RecyclerView.e eVar) {
        int i2 = this.f8659b;
        return i2 >= 0 && i2 < eVar.b();
    }

    public View b(RecyclerView.lpt9 lpt9Var) {
        View viewO = lpt9Var.o(this.f8659b);
        this.f8659b += this.f8660c;
        return viewO;
    }

    public String toString() {
        return "LayoutState{mAvailable=" + this.f8658a + ", mCurrentPosition=" + this.f8659b + ", mItemDirection=" + this.f8660c + ", mLayoutDirection=" + this.f8661d + ", mStartLine=" + this.f8662e + ", mEndLine=" + this.f8663f + '}';
    }
}
