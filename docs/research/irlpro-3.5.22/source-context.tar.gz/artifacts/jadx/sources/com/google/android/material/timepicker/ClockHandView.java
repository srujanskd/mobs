package com.google.android.material.timepicker;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p024Com2.y;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.z3;

/* JADX INFO: loaded from: classes.dex */
class ClockHandView extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public double f9685a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f3756a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3757a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3758a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Paint f3759a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f3760a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f3761a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<prn> f3762a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f9686b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int f3763b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3764b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f9687c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final int f3765c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3766c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f9688d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public int f3767d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3768d;

    public class aux implements ValueAnimator.AnimatorUpdateListener {
        public aux() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ClockHandView.this.n(((Float) valueAnimator.getAnimatedValue()).floatValue(), true);
        }
    }

    public class con extends AnimatorListenerAdapter {
        public con() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            animator.end();
        }
    }

    public interface nul {
        void e(float f2, boolean z2);
    }

    public interface prn {
        void d(float f2, boolean z2);
    }

    public ClockHandView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.f9048w);
    }

    public void b(prn prnVar) {
        this.f3762a.add(prnVar);
    }

    public final void c(Canvas canvas) {
        int height = getHeight() / 2;
        int width = getWidth() / 2;
        float f2 = width;
        float fCos = (this.f3767d * ((float) Math.cos(this.f9685a))) + f2;
        float f3 = height;
        float fSin = (this.f3767d * ((float) Math.sin(this.f9685a))) + f3;
        this.f3759a.setStrokeWidth(0.0f);
        canvas.drawCircle(fCos, fSin, this.f3763b, this.f3759a);
        double dSin = Math.sin(this.f9685a);
        double dCos = Math.cos(this.f9685a);
        double d2 = this.f3767d - this.f3763b;
        this.f3759a.setStrokeWidth(this.f3765c);
        canvas.drawLine(f2, f3, width + ((int) (dCos * d2)), height + ((int) (d2 * dSin)), this.f3759a);
        canvas.drawCircle(f2, f3, this.f9687c, this.f3759a);
    }

    public RectF d() {
        return this.f3760a;
    }

    public final int e(float f2, float f3) {
        int degrees = ((int) Math.toDegrees(Math.atan2(f3 - (getHeight() / 2), f2 - (getWidth() / 2)))) + 90;
        return degrees < 0 ? degrees + 360 : degrees;
    }

    public float f() {
        return this.f9688d;
    }

    public int g() {
        return this.f3763b;
    }

    public final Pair<Float, Float> h(float f2) {
        float f3 = f();
        if (Math.abs(f3 - f2) > 180.0f) {
            if (f3 > 180.0f && f2 < 180.0f) {
                f2 += 360.0f;
            }
            if (f3 < 180.0f && f2 > 180.0f) {
                f3 += 360.0f;
            }
        }
        return new Pair<>(Float.valueOf(f3), Float.valueOf(f2));
    }

    public final boolean i(float f2, float f3, boolean z2, boolean z3, boolean z4) {
        float fE = e(f2, f3);
        boolean z5 = false;
        boolean z6 = f() != fE;
        if (z3 && z6) {
            return true;
        }
        if (!z6 && !z2) {
            return false;
        }
        if (z4 && this.f3764b) {
            z5 = true;
        }
        m(fE, z5);
        return true;
    }

    public void j(boolean z2) {
        this.f3764b = z2;
    }

    public void k(int i2) {
        this.f3767d = i2;
        invalidate();
    }

    public void l(float f2) {
        m(f2, false);
    }

    public void m(float f2, boolean z2) {
        ValueAnimator valueAnimator = this.f3758a;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        if (!z2) {
            n(f2, false);
            return;
        }
        Pair<Float, Float> pairH = h(f2);
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(((Float) pairH.first).floatValue(), ((Float) pairH.second).floatValue());
        this.f3758a = valueAnimatorOfFloat;
        valueAnimatorOfFloat.setDuration(200L);
        this.f3758a.addUpdateListener(new aux());
        this.f3758a.addListener(new con());
        this.f3758a.start();
    }

    public final void n(float f2, boolean z2) {
        float f3 = f2 % 360.0f;
        this.f9688d = f3;
        this.f9685a = Math.toRadians(f3 - 90.0f);
        int height = getHeight() / 2;
        float width = (getWidth() / 2) + (this.f3767d * ((float) Math.cos(this.f9685a)));
        float fSin = height + (this.f3767d * ((float) Math.sin(this.f9685a)));
        RectF rectF = this.f3760a;
        int i2 = this.f3763b;
        rectF.set(width - i2, fSin - i2, width + i2, fSin + i2);
        Iterator<prn> it = this.f3762a.iterator();
        while (it.hasNext()) {
            it.next().d(f3, z2);
        }
        invalidate();
    }

    public void o(nul nulVar) {
        this.f3761a = nulVar;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        c(canvas);
    }

    @Override // android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        l(f());
    }

    @Override // android.view.View
    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        boolean z3;
        boolean z4;
        nul nulVar;
        int actionMasked = motionEvent.getActionMasked();
        float x2 = motionEvent.getX();
        float y2 = motionEvent.getY();
        if (actionMasked == 0) {
            this.f3756a = x2;
            this.f9686b = y2;
            this.f3766c = true;
            this.f3768d = false;
            z2 = false;
            z3 = false;
            z4 = true;
        } else if (actionMasked == 1 || actionMasked == 2) {
            int i2 = (int) (x2 - this.f3756a);
            int i3 = (int) (y2 - this.f9686b);
            this.f3766c = (i2 * i2) + (i3 * i3) > this.f3757a;
            boolean z5 = this.f3768d;
            z2 = actionMasked == 1;
            z4 = false;
            z3 = z5;
        } else {
            z2 = false;
            z3 = false;
            z4 = false;
        }
        boolean zI = i(x2, y2, z3, z4, z2) | this.f3768d;
        this.f3768d = zI;
        if (zI && z2 && (nulVar = this.f3761a) != null) {
            nulVar.e(e(x2, y2), this.f3766c);
        }
        return true;
    }

    public ClockHandView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f3762a = new ArrayList();
        Paint paint = new Paint();
        this.f3759a = paint;
        this.f3760a = new RectF();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3059D, i2, g4.f8979x);
        this.f3767d = typedArrayObtainStyledAttributes.getDimensionPixelSize(h4.I0, 0);
        this.f3763b = typedArrayObtainStyledAttributes.getDimensionPixelSize(h4.J0, 0);
        Resources resources = getResources();
        this.f3765c = resources.getDimensionPixelSize(z3.f9070m);
        this.f9687c = resources.getDimensionPixelSize(z3.f9068k);
        int color = typedArrayObtainStyledAttributes.getColor(h4.H0, 0);
        paint.setAntiAlias(true);
        paint.setColor(color);
        l(0.0f);
        this.f3757a = ViewConfiguration.get(context).getScaledTouchSlop();
        y.y0(this, 2);
        typedArrayObtainStyledAttributes.recycle();
    }
}
