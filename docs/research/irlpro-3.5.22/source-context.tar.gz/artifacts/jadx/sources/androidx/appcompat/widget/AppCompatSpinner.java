package androidx.appcompat.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import p001AuX.com9;
import p001AuX.lpt3;
import p022CoN.a0;
import p022CoN.d0;
import p022CoN.l0;
import p022CoN.lpt2;
import p022CoN.m0;
import p022CoN.q0;
import p022CoN.u0;
import p024Com2.y;
import p099coN.h1;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatSpinner extends Spinner {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f7882a = {R.attr.spinnerMode};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f1984a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public a0 f1985a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt2 f1986a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f1987a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f1988a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public SpinnerAdapter f1989a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f1990a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f7883b;

    public class aux extends a0 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ com1 f7884a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public aux(View view, com1 com1Var) {
            super(view);
            this.f7884a = com1Var;
        }

        @Override // p022CoN.a0
        public h1 b() {
            return this.f7884a;
        }

        @Override // p022CoN.a0
        @SuppressLint({"SyntheticAccessor"})
        public boolean c() {
            if (AppCompatSpinner.this.getInternalPopup().b()) {
                return true;
            }
            AppCompatSpinner.this.b();
            return true;
        }
    }

    public class com1 extends d0 implements com3 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public CharSequence f1992a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public ListAdapter f7886b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final Rect f7887c;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public int f7888i;

        public class aux implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AppCompatSpinner f1993a;

            public aux(AppCompatSpinner appCompatSpinner) {
                this.f1993a = appCompatSpinner;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
                AppCompatSpinner.this.setSelection(i2);
                if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                    com1 com1Var = com1.this;
                    AppCompatSpinner.this.performItemClick(view, i2, com1Var.f7886b.getItemId(i2));
                }
                com1.this.dismiss();
            }
        }

        public class con implements ViewTreeObserver.OnGlobalLayoutListener {
            public con() {
            }

            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                com1 com1Var = com1.this;
                if (!com1Var.U(AppCompatSpinner.this)) {
                    com1.this.dismiss();
                } else {
                    com1.this.S();
                    com1.super.a();
                }
            }
        }

        public class nul implements PopupWindow.OnDismissListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f7891a;

            public nul(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f7891a = onGlobalLayoutListener;
            }

            @Override // android.widget.PopupWindow.OnDismissListener
            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.f7891a);
                }
            }
        }

        public com1(Context context, AttributeSet attributeSet, int i2) {
            super(context, attributeSet, i2);
            this.f7887c = new Rect();
            D(AppCompatSpinner.this);
            J(true);
            O(0);
            L(new aux(AppCompatSpinner.this));
        }

        public void S() {
            int i2;
            Drawable drawableI = i();
            if (drawableI != null) {
                drawableI.getPadding(AppCompatSpinner.this.f1988a);
                i2 = u0.b(AppCompatSpinner.this) ? AppCompatSpinner.this.f1988a.right : -AppCompatSpinner.this.f1988a.left;
            } else {
                Rect rect = AppCompatSpinner.this.f1988a;
                rect.right = 0;
                rect.left = 0;
                i2 = 0;
            }
            int paddingLeft = AppCompatSpinner.this.getPaddingLeft();
            int paddingRight = AppCompatSpinner.this.getPaddingRight();
            int width = AppCompatSpinner.this.getWidth();
            AppCompatSpinner appCompatSpinner = AppCompatSpinner.this;
            int i3 = appCompatSpinner.f1984a;
            if (i3 == -2) {
                int iA = appCompatSpinner.a((SpinnerAdapter) this.f7886b, i());
                int i4 = AppCompatSpinner.this.getContext().getResources().getDisplayMetrics().widthPixels;
                Rect rect2 = AppCompatSpinner.this.f1988a;
                int i5 = (i4 - rect2.left) - rect2.right;
                if (iA > i5) {
                    iA = i5;
                }
                F(Math.max(iA, (width - paddingLeft) - paddingRight));
            } else if (i3 == -1) {
                F((width - paddingLeft) - paddingRight);
            } else {
                F(i3);
            }
            e(u0.b(AppCompatSpinner.this) ? i2 + (((width - paddingRight) - z()) - T()) : i2 + paddingLeft + T());
        }

        public int T() {
            return this.f7888i;
        }

        public boolean U(View view) {
            return y.R(view) && view.getGlobalVisibleRect(this.f7887c);
        }

        @Override // p022CoN.d0, androidx.appcompat.widget.AppCompatSpinner.com3
        public void g(ListAdapter listAdapter) {
            super.g(listAdapter);
            this.f7886b = listAdapter;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public CharSequence h() {
            return this.f1992a;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void j(int i2) {
            this.f7888i = i2;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void k(int i2, int i3) {
            ViewTreeObserver viewTreeObserver;
            boolean zB = b();
            S();
            I(2);
            super.a();
            ListView listViewD = d();
            listViewD.setChoiceMode(1);
            listViewD.setTextDirection(i2);
            listViewD.setTextAlignment(i3);
            P(AppCompatSpinner.this.getSelectedItemPosition());
            if (zB || (viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver()) == null) {
                return;
            }
            con conVar = new con();
            viewTreeObserver.addOnGlobalLayoutListener(conVar);
            K(new nul(conVar));
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void l(CharSequence charSequence) {
            this.f1992a = charSequence;
        }
    }

    public static class com2 extends View.BaseSavedState {
        public static final Parcelable.Creator<com2> CREATOR = new aux();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f7892b;

        public class aux implements Parcelable.Creator<com2> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com2 createFromParcel(Parcel parcel) {
                return new com2(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com2[] newArray(int i2) {
                return new com2[i2];
            }
        }

        public com2(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeByte(this.f7892b ? (byte) 1 : (byte) 0);
        }

        public com2(Parcel parcel) {
            super(parcel);
            this.f7892b = parcel.readByte() != 0;
        }
    }

    public interface com3 {
        boolean b();

        void c(Drawable drawable);

        void dismiss();

        void e(int i2);

        int f();

        void g(ListAdapter listAdapter);

        CharSequence h();

        Drawable i();

        void j(int i2);

        void k(int i2, int i3);

        void l(CharSequence charSequence);

        int m();

        void o(int i2);
    }

    public class con implements ViewTreeObserver.OnGlobalLayoutListener {
        public con() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!AppCompatSpinner.this.getInternalPopup().b()) {
                AppCompatSpinner.this.b();
            }
            ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    public class nul implements com3, DialogInterface.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public ListAdapter f7894a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.appcompat.app.aux f1995a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public CharSequence f1997a;

        public nul() {
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public boolean b() {
            androidx.appcompat.app.aux auxVar = this.f1995a;
            if (auxVar != null) {
                return auxVar.isShowing();
            }
            return false;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void c(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void dismiss() {
            androidx.appcompat.app.aux auxVar = this.f1995a;
            if (auxVar != null) {
                auxVar.dismiss();
                this.f1995a = null;
            }
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void e(int i2) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public int f() {
            return 0;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void g(ListAdapter listAdapter) {
            this.f7894a = listAdapter;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public CharSequence h() {
            return this.f1997a;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public Drawable i() {
            return null;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void j(int i2) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void k(int i2, int i3) {
            if (this.f7894a == null) {
                return;
            }
            androidx.appcompat.app.aux.C0023aux c0023aux = new androidx.appcompat.app.aux.C0023aux(AppCompatSpinner.this.getPopupContext());
            CharSequence charSequence = this.f1997a;
            if (charSequence != null) {
                c0023aux.s(charSequence);
            }
            androidx.appcompat.app.aux auxVarA = c0023aux.p(this.f7894a, AppCompatSpinner.this.getSelectedItemPosition(), this).a();
            this.f1995a = auxVarA;
            ListView listViewG = auxVarA.g();
            listViewG.setTextDirection(i2);
            listViewG.setTextAlignment(i3);
            this.f1995a.show();
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void l(CharSequence charSequence) {
            this.f1997a = charSequence;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public int m() {
            return 0;
        }

        @Override // androidx.appcompat.widget.AppCompatSpinner.com3
        public void o(int i2) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            AppCompatSpinner.this.setSelection(i2);
            if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                AppCompatSpinner.this.performItemClick(null, i2, this.f7894a.getItemId(i2));
            }
            dismiss();
        }
    }

    public static class prn implements ListAdapter, SpinnerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public ListAdapter f7895a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public SpinnerAdapter f1998a;

        public prn(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.f1998a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f7895a = (ListAdapter) spinnerAdapter;
            }
            if (theme != null) {
                if (spinnerAdapter instanceof ThemedSpinnerAdapter) {
                    ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                    if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                        themedSpinnerAdapter.setDropDownViewTheme(theme);
                        return;
                    }
                    return;
                }
                if (spinnerAdapter instanceof m0) {
                    m0 m0Var = (m0) spinnerAdapter;
                    if (m0Var.getDropDownViewTheme() == null) {
                        m0Var.setDropDownViewTheme(theme);
                    }
                }
            }
        }

        @Override // android.widget.ListAdapter
        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f7895a;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        @Override // android.widget.Adapter
        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        @Override // android.widget.SpinnerAdapter
        public View getDropDownView(int i2, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i2, view, viewGroup);
        }

        @Override // android.widget.Adapter
        public Object getItem(int i2) {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i2);
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            if (spinnerAdapter == null) {
                return -1L;
            }
            return spinnerAdapter.getItemId(i2);
        }

        @Override // android.widget.Adapter
        public int getItemViewType(int i2) {
            return 0;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            return getDropDownView(i2, view, viewGroup);
        }

        @Override // android.widget.Adapter
        public int getViewTypeCount() {
            return 1;
        }

        @Override // android.widget.Adapter
        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        @Override // android.widget.Adapter
        public boolean isEmpty() {
            return getCount() == 0;
        }

        @Override // android.widget.ListAdapter
        public boolean isEnabled(int i2) {
            ListAdapter listAdapter = this.f7895a;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i2);
            }
            return true;
        }

        @Override // android.widget.Adapter
        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        @Override // android.widget.Adapter
        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f1998a;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, p001AuX.com3.K);
    }

    public int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i2 = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int iMax = Math.max(0, getSelectedItemPosition());
        int iMin = Math.min(spinnerAdapter.getCount(), iMax + 15);
        View view = null;
        int iMax2 = 0;
        for (int iMax3 = Math.max(0, iMax - (15 - (iMin - iMax))); iMax3 < iMin; iMax3++) {
            int itemViewType = spinnerAdapter.getItemViewType(iMax3);
            if (itemViewType != i2) {
                view = null;
                i2 = itemViewType;
            }
            view = spinnerAdapter.getView(iMax3, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
            iMax2 = Math.max(iMax2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return iMax2;
        }
        drawable.getPadding(this.f1988a);
        Rect rect = this.f1988a;
        return iMax2 + rect.left + rect.right;
    }

    public void b() {
        this.f1990a.k(getTextDirection(), getTextAlignment());
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            lpt2Var.b();
        }
    }

    @Override // android.widget.Spinner
    public int getDropDownHorizontalOffset() {
        com3 com3Var = this.f1990a;
        return com3Var != null ? com3Var.f() : super.getDropDownHorizontalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownVerticalOffset() {
        com3 com3Var = this.f1990a;
        return com3Var != null ? com3Var.m() : super.getDropDownVerticalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownWidth() {
        return this.f1990a != null ? this.f1984a : super.getDropDownWidth();
    }

    public final com3 getInternalPopup() {
        return this.f1990a;
    }

    @Override // android.widget.Spinner
    public Drawable getPopupBackground() {
        com3 com3Var = this.f1990a;
        return com3Var != null ? com3Var.i() : super.getPopupBackground();
    }

    @Override // android.widget.Spinner
    public Context getPopupContext() {
        return this.f1987a;
    }

    @Override // android.widget.Spinner
    public CharSequence getPrompt() {
        com3 com3Var = this.f1990a;
        return com3Var != null ? com3Var.h() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            return lpt2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            return lpt2Var.d();
        }
        return null;
    }

    @Override // android.widget.Spinner, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        com3 com3Var = this.f1990a;
        if (com3Var == null || !com3Var.b()) {
            return;
        }
        this.f1990a.dismiss();
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f1990a == null || View.MeasureSpec.getMode(i2) != Integer.MIN_VALUE) {
            return;
        }
        setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i2)), getMeasuredHeight());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        com2 com2Var = (com2) parcelable;
        super.onRestoreInstanceState(com2Var.getSuperState());
        if (!com2Var.f7892b || (viewTreeObserver = getViewTreeObserver()) == null) {
            return;
        }
        viewTreeObserver.addOnGlobalLayoutListener(new con());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public Parcelable onSaveInstanceState() {
        com2 com2Var = new com2(super.onSaveInstanceState());
        com3 com3Var = this.f1990a;
        com2Var.f7892b = com3Var != null && com3Var.b();
        return com2Var;
    }

    @Override // android.widget.Spinner, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        a0 a0Var = this.f1985a;
        if (a0Var == null || !a0Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.widget.Spinner, android.view.View
    public boolean performClick() {
        com3 com3Var = this.f1990a;
        if (com3Var == null) {
            return super.performClick();
        }
        if (com3Var.b()) {
            return true;
        }
        b();
        return true;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            lpt2Var.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            lpt2Var.g(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownHorizontalOffset(int i2) {
        com3 com3Var = this.f1990a;
        if (com3Var == null) {
            super.setDropDownHorizontalOffset(i2);
        } else {
            com3Var.j(i2);
            this.f1990a.e(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownVerticalOffset(int i2) {
        com3 com3Var = this.f1990a;
        if (com3Var != null) {
            com3Var.o(i2);
        } else {
            super.setDropDownVerticalOffset(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownWidth(int i2) {
        if (this.f1990a != null) {
            this.f1984a = i2;
        } else {
            super.setDropDownWidth(i2);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundDrawable(Drawable drawable) {
        com3 com3Var = this.f1990a;
        if (com3Var != null) {
            com3Var.c(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundResource(int i2) {
        setPopupBackgroundDrawable(AUX.aux.b(getPopupContext(), i2));
    }

    @Override // android.widget.Spinner
    public void setPrompt(CharSequence charSequence) {
        com3 com3Var = this.f1990a;
        if (com3Var != null) {
            com3Var.l(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            lpt2Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        lpt2 lpt2Var = this.f1986a;
        if (lpt2Var != null) {
            lpt2Var.j(mode);
        }
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, -1);
    }

    @Override // android.widget.AdapterView
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f7883b) {
            this.f1989a = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f1990a != null) {
            Context context = this.f1987a;
            if (context == null) {
                context = getContext();
            }
            this.f1990a.g(new prn(spinnerAdapter, context.getTheme()));
        }
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet, int i2, int i3) {
        this(context, attributeSet, i2, i3, null);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x006e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:34:0x0071  */
    /* JADX WARN: Code duplicated, block: B:35:0x00a8  */
    /* JADX WARN: Code duplicated, block: B:38:0x00c0  */
    /* JADX WARN: Code duplicated, block: B:41:0x00d9  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v11 */
    /* JADX WARN: Type inference failed for: r11v12 */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v7, types: [android.content.res.TypedArray] */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [android.content.res.TypedArray] */
    /* JADX WARN: Type inference failed for: r6v0, types: [android.view.View, androidx.appcompat.widget.AppCompatSpinner] */
    public AppCompatSpinner(Context context, AttributeSet attributeSet, int i2, int i3, Resources.Theme theme) throws Throwable {
        TypedArray typedArrayObtainStyledAttributes;
        CharSequence[] charSequenceArrQ;
        SpinnerAdapter spinnerAdapter;
        super(context, attributeSet, i2);
        this.f1988a = new Rect();
        l0.a(this, getContext());
        q0 q0VarV = q0.v(context, attributeSet, lpt3.f6B, i2, 0);
        this.f1986a = new lpt2(this);
        if (theme != null) {
            this.f1987a = new p012COn.com2(context, theme);
        } else {
            int iN = q0VarV.n(lpt3.a2, 0);
            if (iN != 0) {
                this.f1987a = new p012COn.com2(context, iN);
            } else {
                this.f1987a = context;
            }
        }
        ?? r11 = -1;
        ?? r2 = 0;
        try {
            if (i3 == -1) {
                try {
                    typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f7882a, i2, 0);
                    try {
                        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(0);
                        r11 = typedArrayObtainStyledAttributes;
                        if (zHasValue) {
                            i3 = typedArrayObtainStyledAttributes.getInt(0, 0);
                            r11 = typedArrayObtainStyledAttributes;
                        }
                    } catch (Exception e2) {
                        e = e2;
                        Log.i("AppCompatSpinner", "Could not read android:spinnerMode", e);
                        r11 = typedArrayObtainStyledAttributes;
                        if (typedArrayObtainStyledAttributes != null) {
                        }
                        if (i3 != 0) {
                            nul nulVar = new nul();
                            this.f1990a = nulVar;
                            nulVar.l(q0VarV.o(lpt3.Y1));
                        } else if (i3 == 1) {
                            com1 com1Var = new com1(this.f1987a, attributeSet, i2);
                            q0 q0VarV2 = q0.v(this.f1987a, attributeSet, lpt3.f6B, i2, 0);
                            this.f1984a = q0VarV2.m(lpt3.Z1, -2);
                            com1Var.c(q0VarV2.g(lpt3.X1));
                            com1Var.l(q0VarV.o(lpt3.Y1));
                            q0VarV2.w();
                            this.f1990a = com1Var;
                            this.f1985a = new aux(this, com1Var);
                        }
                        charSequenceArrQ = q0VarV.q(lpt3.W1);
                        if (charSequenceArrQ != null) {
                            ArrayAdapter arrayAdapter = new ArrayAdapter(context, R.layout.simple_spinner_item, charSequenceArrQ);
                            arrayAdapter.setDropDownViewResource(com9.f5609s);
                            setAdapter(arrayAdapter);
                        }
                        q0VarV.w();
                        this.f7883b = true;
                        spinnerAdapter = this.f1989a;
                        if (spinnerAdapter != null) {
                            setAdapter(spinnerAdapter);
                            this.f1989a = null;
                        }
                        this.f1986a.e(attributeSet, i2);
                    }
                } catch (Exception e3) {
                    e = e3;
                    typedArrayObtainStyledAttributes = null;
                } catch (Throwable th) {
                    th = th;
                    if (r2 != 0) {
                        r2.recycle();
                    }
                    throw th;
                }
                r11.recycle();
            }
            if (i3 != 0) {
                nul nulVar2 = new nul();
                this.f1990a = nulVar2;
                nulVar2.l(q0VarV.o(lpt3.Y1));
            } else if (i3 == 1) {
                com1 com1Var2 = new com1(this.f1987a, attributeSet, i2);
                q0 q0VarV3 = q0.v(this.f1987a, attributeSet, lpt3.f6B, i2, 0);
                this.f1984a = q0VarV3.m(lpt3.Z1, -2);
                com1Var2.c(q0VarV3.g(lpt3.X1));
                com1Var2.l(q0VarV.o(lpt3.Y1));
                q0VarV3.w();
                this.f1990a = com1Var2;
                this.f1985a = new aux(this, com1Var2);
            }
            charSequenceArrQ = q0VarV.q(lpt3.W1);
            if (charSequenceArrQ != null) {
                ArrayAdapter arrayAdapter2 = new ArrayAdapter(context, R.layout.simple_spinner_item, charSequenceArrQ);
                arrayAdapter2.setDropDownViewResource(com9.f5609s);
                setAdapter(arrayAdapter2);
            }
            q0VarV.w();
            this.f7883b = true;
            spinnerAdapter = this.f1989a;
            if (spinnerAdapter != null) {
                setAdapter(spinnerAdapter);
                this.f1989a = null;
            }
            this.f1986a.e(attributeSet, i2);
        } catch (Throwable th2) {
            th = th2;
            r2 = r11;
        }
    }
}
