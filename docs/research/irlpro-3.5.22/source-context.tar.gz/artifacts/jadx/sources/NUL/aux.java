package NUL;

/* JADX INFO: loaded from: classes.dex */
public class aux extends com3 {
    public aux(lpt3 lpt3Var) {
        super(lpt3Var);
    }
}
