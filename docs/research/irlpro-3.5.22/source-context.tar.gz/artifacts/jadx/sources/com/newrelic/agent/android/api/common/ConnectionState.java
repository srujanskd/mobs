package com.newrelic.agent.android.api.common;

import com.newrelic.agent.android.api.v1.Defaults;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public final class ConnectionState {
    public static final ConnectionState NULL = new ConnectionState();
    private final boolean collectingNetworkErrors;
    private final String crossProcessId;
    private final Object dataToken;
    private final int errorLimit;
    private final long harvestInterval;
    private final TimeUnit harvestIntervalTimeUnit;
    private final long maxTransactionAge;
    private final TimeUnit maxTransactionAgeTimeUnit;
    private final long maxTransactionCount;
    private final int responseBodyLimit;
    private final long serverTimestamp;
    private final int stackTraceLimit;

    private ConnectionState() {
        this.dataToken = null;
        this.crossProcessId = null;
        this.serverTimestamp = 0L;
        this.harvestInterval = 60L;
        TimeUnit timeUnit = TimeUnit.SECONDS;
        this.harvestIntervalTimeUnit = timeUnit;
        this.maxTransactionAge = 600L;
        this.maxTransactionAgeTimeUnit = timeUnit;
        this.maxTransactionCount = 1000L;
        this.stackTraceLimit = 50;
        this.responseBodyLimit = Defaults.RESPONSE_BODY_LIMIT;
        this.collectingNetworkErrors = true;
        this.errorLimit = 10;
    }

    public String getCrossProcessId() {
        return this.crossProcessId;
    }

    public Object getDataToken() {
        return this.dataToken;
    }

    public int getErrorLimit() {
        return this.errorLimit;
    }

    public long getHarvestIntervalInMilliseconds() {
        return TimeUnit.MILLISECONDS.convert(this.harvestInterval, this.harvestIntervalTimeUnit);
    }

    public long getHarvestIntervalInSeconds() {
        return TimeUnit.SECONDS.convert(this.harvestInterval, this.harvestIntervalTimeUnit);
    }

    public long getMaxTransactionAgeInMilliseconds() {
        return TimeUnit.MILLISECONDS.convert(this.maxTransactionAge, this.maxTransactionAgeTimeUnit);
    }

    public long getMaxTransactionAgeInSeconds() {
        return TimeUnit.SECONDS.convert(this.maxTransactionAge, this.maxTransactionAgeTimeUnit);
    }

    public long getMaxTransactionCount() {
        return this.maxTransactionCount;
    }

    public int getResponseBodyLimit() {
        return this.responseBodyLimit;
    }

    public long getServerTimestamp() {
        return this.serverTimestamp;
    }

    public int getStackTraceLimit() {
        return this.stackTraceLimit;
    }

    public boolean isCollectingNetworkErrors() {
        return this.collectingNetworkErrors;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.dataToken);
        return sb.toString();
    }

    public ConnectionState(Object obj, String str, long j2, long j3, TimeUnit timeUnit, long j4, TimeUnit timeUnit2, long j5, int i2, int i3, boolean z2, int i4) {
        this.dataToken = obj;
        this.crossProcessId = str;
        this.serverTimestamp = j2;
        this.harvestInterval = j3;
        this.harvestIntervalTimeUnit = timeUnit;
        this.maxTransactionAge = j4;
        this.maxTransactionAgeTimeUnit = timeUnit2;
        this.maxTransactionCount = j5;
        this.stackTraceLimit = i2;
        this.responseBodyLimit = i3;
        this.collectingNetworkErrors = z2;
        this.errorLimit = i4;
    }
}
