package LPT8;

/* JADX INFO: loaded from: classes.dex */
public interface com2<T> {
}
