package COM1;

import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import p101com2.p2;

/* JADX INFO: loaded from: classes.dex */
public class nul implements Spannable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f5686a = new Object();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final aux f53a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final PrecomputedText f54a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Spannable f55a;

    public static final class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f5687a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final PrecomputedText.Params f56a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final TextDirectionHeuristic f57a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final TextPaint f58a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final int f5688b;

        public aux(PrecomputedText.Params params) {
            this.f58a = params.getTextPaint();
            this.f57a = params.getTextDirection();
            this.f5687a = params.getBreakStrategy();
            this.f5688b = params.getHyphenationFrequency();
            this.f56a = Build.VERSION.SDK_INT < 29 ? null : params;
        }

        public boolean a(aux auxVar) {
            if (this.f5687a != auxVar.b() || this.f5688b != auxVar.c() || this.f58a.getTextSize() != auxVar.e().getTextSize() || this.f58a.getTextScaleX() != auxVar.e().getTextScaleX() || this.f58a.getTextSkewX() != auxVar.e().getTextSkewX() || this.f58a.getLetterSpacing() != auxVar.e().getLetterSpacing() || !TextUtils.equals(this.f58a.getFontFeatureSettings(), auxVar.e().getFontFeatureSettings()) || this.f58a.getFlags() != auxVar.e().getFlags() || !this.f58a.getTextLocales().equals(auxVar.e().getTextLocales())) {
                return false;
            }
            if (this.f58a.getTypeface() == null) {
                return auxVar.e().getTypeface() == null;
            }
            return this.f58a.getTypeface().equals(auxVar.e().getTypeface());
        }

        public int b() {
            return this.f5687a;
        }

        public int c() {
            return this.f5688b;
        }

        public TextDirectionHeuristic d() {
            return this.f57a;
        }

        public TextPaint e() {
            return this.f58a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof aux)) {
                return false;
            }
            aux auxVar = (aux) obj;
            return a(auxVar) && this.f57a == auxVar.d();
        }

        public int hashCode() {
            return p2.b(Float.valueOf(this.f58a.getTextSize()), Float.valueOf(this.f58a.getTextScaleX()), Float.valueOf(this.f58a.getTextSkewX()), Float.valueOf(this.f58a.getLetterSpacing()), Integer.valueOf(this.f58a.getFlags()), this.f58a.getTextLocales(), this.f58a.getTypeface(), Boolean.valueOf(this.f58a.isElegantTextHeight()), this.f57a, Integer.valueOf(this.f5687a), Integer.valueOf(this.f5688b));
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("{");
            sb.append("textSize=" + this.f58a.getTextSize());
            sb.append(", textScaleX=" + this.f58a.getTextScaleX());
            sb.append(", textSkewX=" + this.f58a.getTextSkewX());
            sb.append(", letterSpacing=" + this.f58a.getLetterSpacing());
            sb.append(", elegantTextHeight=" + this.f58a.isElegantTextHeight());
            sb.append(", textLocale=" + this.f58a.getTextLocales());
            sb.append(", typeface=" + this.f58a.getTypeface());
            sb.append(", variationSettings=" + this.f58a.getFontVariationSettings());
            sb.append(", textDir=" + this.f57a);
            sb.append(", breakStrategy=" + this.f5687a);
            sb.append(", hyphenationFrequency=" + this.f5688b);
            sb.append("}");
            return sb.toString();
        }
    }

    public aux a() {
        return this.f53a;
    }

    public PrecomputedText b() {
        Spannable spannable = this.f55a;
        if (spannable instanceof PrecomputedText) {
            return (PrecomputedText) spannable;
        }
        return null;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i2) {
        return this.f55a.charAt(i2);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.f55a.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.f55a.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.f55a.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public <T> T[] getSpans(int i2, int i3, Class<T> cls) {
        return Build.VERSION.SDK_INT >= 29 ? (T[]) this.f54a.getSpans(i2, i3, cls) : (T[]) this.f55a.getSpans(i2, i3, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f55a.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i2, int i3, Class cls) {
        return this.f55a.nextSpanTransition(i2, i3, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.f54a.removeSpan(obj);
        } else {
            this.f55a.removeSpan(obj);
        }
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i2, int i3, int i4) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            this.f54a.setSpan(obj, i2, i3, i4);
        } else {
            this.f55a.setSpan(obj, i2, i3, i4);
        }
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i2, int i3) {
        return this.f55a.subSequence(i2, i3);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f55a.toString();
    }
}
