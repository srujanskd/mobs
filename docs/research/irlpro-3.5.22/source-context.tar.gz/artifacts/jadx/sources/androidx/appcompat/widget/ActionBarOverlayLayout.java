package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.view.menu.com5;
import androidx.preference.Preference;
import p001AuX.com3;
import p001AuX.com8;
import p022CoN.q;
import p022CoN.r;
import p023Com1.lpt2;
import p024Com2.p;
import p024Com2.t0;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements q, p, p024Com2.q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f7855a = {com3.f5494b, R.attr.windowContentOverlay};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f1945a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public r f1946a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p024Com2.r f1947a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public t0 f1948a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AnimatorListenerAdapter f1949a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f1950a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1951a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewPropertyAnimator f1952a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public OverScroller f1953a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ActionBarContainer f1954a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f1955a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ContentFrameLayout f1956a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f1957a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7856b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public t0 f1958b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Rect f1959b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Runnable f1960b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1961b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7857c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public t0 f1962c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final Rect f1963c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1964c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7858d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public t0 f1965d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final Rect f1966d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f1967d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Rect f7859e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f1968e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Rect f7860f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f1969f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Rect f7861g;

    public class aux extends AnimatorListenerAdapter {
        public aux() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1952a = null;
            actionBarOverlayLayout.f1969f = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1952a = null;
            actionBarOverlayLayout.f1969f = false;
        }
    }

    public static class com1 extends ViewGroup.MarginLayoutParams {
        public com1(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public com1(int i2, int i3) {
            super(i2, i3);
        }

        public com1(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public class con implements Runnable {
        public con() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.u();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1952a = actionBarOverlayLayout.f1954a.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f1949a);
        }
    }

    public class nul implements Runnable {
        public nul() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.u();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f1952a = actionBarOverlayLayout.f1954a.animate().translationY(-ActionBarOverlayLayout.this.f1954a.getHeight()).setListener(ActionBarOverlayLayout.this.f1949a);
        }
    }

    public interface prn {
        void a();

        void b();

        void c();

        void d(boolean z2);

        void e();

        void onWindowVisibilityChanged(int i2);
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f7856b = 0;
        this.f1950a = new Rect();
        this.f1959b = new Rect();
        this.f1963c = new Rect();
        this.f1966d = new Rect();
        this.f7859e = new Rect();
        this.f7860f = new Rect();
        this.f7861g = new Rect();
        t0 t0Var = t0.f6461a;
        this.f1948a = t0Var;
        this.f1958b = t0Var;
        this.f1962c = t0Var;
        this.f1965d = t0Var;
        this.f1949a = new aux();
        this.f1957a = new con();
        this.f1960b = new nul();
        v(context);
        this.f1947a = new p024Com2.r(this);
    }

    public final void A() {
        u();
        this.f1957a.run();
    }

    public final boolean B(float f2) {
        this.f1953a.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Preference.DEFAULT_ORDER);
        return this.f1953a.getFinalY() > this.f1954a.getHeight();
    }

    @Override // p022CoN.q
    public boolean a() {
        z();
        return this.f1946a.a();
    }

    @Override // p022CoN.q
    public void b(Menu menu, com5.aux auxVar) {
        z();
        this.f1946a.b(menu, auxVar);
    }

    @Override // p022CoN.q
    public boolean c() {
        z();
        return this.f1946a.c();
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof com1;
    }

    @Override // p022CoN.q
    public boolean d() {
        z();
        return this.f1946a.d();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f1951a == null || this.f1961b) {
            return;
        }
        int bottom = this.f1954a.getVisibility() == 0 ? (int) (this.f1954a.getBottom() + this.f1954a.getTranslationY() + 0.5f) : 0;
        this.f1951a.setBounds(0, bottom, getWidth(), this.f1951a.getIntrinsicHeight() + bottom);
        this.f1951a.draw(canvas);
    }

    @Override // p022CoN.q
    public boolean e() {
        z();
        return this.f1946a.e();
    }

    @Override // p022CoN.q
    public void f() {
        z();
        this.f1946a.f();
    }

    @Override // android.view.View
    public boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // p022CoN.q
    public boolean g() {
        z();
        return this.f1946a.g();
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f1954a;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.f1947a.a();
    }

    public CharSequence getTitle() {
        z();
        return this.f1946a.getTitle();
    }

    @Override // p022CoN.q
    public void h() {
        z();
        this.f1946a.m();
    }

    @Override // p024Com2.p
    public void i(View view, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(view, i2, i3, i4, i5);
        }
    }

    @Override // p024Com2.p
    public void j(View view, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(view, i2, i3, iArr);
        }
    }

    @Override // p024Com2.p
    public void k(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // p024Com2.q
    public void l(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        i(view, i2, i3, i4, i5, i6);
    }

    @Override // p024Com2.p
    public void m(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // p022CoN.q
    public void n(int i2) {
        z();
        if (i2 == 2) {
            this.f1946a.r();
        } else if (i2 == 5) {
            this.f1946a.l();
        } else {
            if (i2 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // p024Com2.p
    public boolean o(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        z();
        t0 t0VarW = t0.w(windowInsets, this);
        boolean zQ = q(this.f1954a, new Rect(t0VarW.j(), t0VarW.l(), t0VarW.k(), t0VarW.i()), true, true, false, true);
        y.f(this, t0VarW, this.f1950a);
        Rect rect = this.f1950a;
        t0 t0VarM = t0VarW.m(rect.left, rect.top, rect.right, rect.bottom);
        this.f1948a = t0VarM;
        boolean z2 = true;
        if (!this.f1958b.equals(t0VarM)) {
            this.f1958b = this.f1948a;
            zQ = true;
        }
        if (this.f1959b.equals(this.f1950a)) {
            z2 = zQ;
        } else {
            this.f1959b.set(this.f1950a);
        }
        if (z2) {
            requestLayout();
        }
        return t0VarW.a().c().b().u();
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        v(getContext());
        y.l0(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        u();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                com1 com1Var = (com1) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) com1Var).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) com1Var).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        int measuredHeight;
        z();
        measureChildWithMargins(this.f1954a, i2, 0, i3, 0);
        com1 com1Var = (com1) this.f1954a.getLayoutParams();
        int iMax = Math.max(0, this.f1954a.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) com1Var).leftMargin + ((ViewGroup.MarginLayoutParams) com1Var).rightMargin);
        int iMax2 = Math.max(0, this.f1954a.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com1Var).topMargin + ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.f1954a.getMeasuredState());
        boolean z2 = (y.K(this) & 256) != 0;
        if (z2) {
            measuredHeight = this.f1945a;
            if (this.f1967d && this.f1954a.getTabContainer() != null) {
                measuredHeight += this.f1945a;
            }
        } else {
            measuredHeight = this.f1954a.getVisibility() != 8 ? this.f1954a.getMeasuredHeight() : 0;
        }
        this.f1963c.set(this.f1950a);
        t0 t0Var = this.f1948a;
        this.f1962c = t0Var;
        if (this.f1964c || z2) {
            this.f1962c = new t0.con(this.f1962c).c(lpt2.b(t0Var.j(), this.f1962c.l() + measuredHeight, this.f1962c.k(), this.f1962c.i() + 0)).a();
        } else {
            Rect rect = this.f1963c;
            rect.top += measuredHeight;
            rect.bottom += 0;
            this.f1962c = t0Var.m(0, measuredHeight, 0, 0);
        }
        q(this.f1956a, this.f1963c, true, true, true, true);
        if (!this.f1965d.equals(this.f1962c)) {
            t0 t0Var2 = this.f1962c;
            this.f1965d = t0Var2;
            y.g(this.f1956a, t0Var2);
        }
        measureChildWithMargins(this.f1956a, i2, 0, i3, 0);
        com1 com1Var2 = (com1) this.f1956a.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f1956a.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) com1Var2).leftMargin + ((ViewGroup.MarginLayoutParams) com1Var2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f1956a.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com1Var2).topMargin + ((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f1956a.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(iMax4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f2, float f3, boolean z2) {
        if (!this.f1968e || !z2) {
            return false;
        }
        if (B(f3)) {
            p();
        } else {
            A();
        }
        this.f1969f = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f2, float f3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f7857c + i3;
        this.f7857c = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f1947a.b(view, view2, i2);
        this.f7857c = getActionBarHideOffset();
        u();
        prn prnVar = this.f1955a;
        if (prnVar != null) {
            prnVar.a();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f1954a.getVisibility() != 0) {
            return false;
        }
        return this.f1968e;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        if (this.f1968e && !this.f1969f) {
            if (this.f7857c <= this.f1954a.getHeight()) {
                y();
            } else {
                x();
            }
        }
        prn prnVar = this.f1955a;
        if (prnVar != null) {
            prnVar.c();
        }
    }

    @Override // android.view.View
    @Deprecated
    public void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        z();
        int i3 = this.f7858d ^ i2;
        this.f7858d = i2;
        boolean z2 = (i2 & 4) == 0;
        boolean z3 = (i2 & 256) != 0;
        prn prnVar = this.f1955a;
        if (prnVar != null) {
            prnVar.d(!z3);
            if (z2 || !z3) {
                this.f1955a.e();
            } else {
                this.f1955a.b();
            }
        }
        if ((i3 & 256) == 0 || this.f1955a == null) {
            return;
        }
        y.l0(this);
    }

    @Override // android.view.View
    public void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.f7856b = i2;
        prn prnVar = this.f1955a;
        if (prnVar != null) {
            prnVar.onWindowVisibilityChanged(i2);
        }
    }

    public final void p() {
        u();
        this.f1960b.run();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final boolean q(View view, Rect rect, boolean z2, boolean z3, boolean z4, boolean z5) {
        boolean z6;
        com1 com1Var = (com1) view.getLayoutParams();
        if (z2) {
            int i2 = ((ViewGroup.MarginLayoutParams) com1Var).leftMargin;
            int i3 = rect.left;
            if (i2 != i3) {
                ((ViewGroup.MarginLayoutParams) com1Var).leftMargin = i3;
                z6 = true;
            } else {
                z6 = false;
            }
        } else {
            z6 = false;
        }
        if (z3) {
            int i4 = ((ViewGroup.MarginLayoutParams) com1Var).topMargin;
            int i5 = rect.top;
            if (i4 != i5) {
                ((ViewGroup.MarginLayoutParams) com1Var).topMargin = i5;
                z6 = true;
            }
        }
        if (z5) {
            int i6 = ((ViewGroup.MarginLayoutParams) com1Var).rightMargin;
            int i7 = rect.right;
            if (i6 != i7) {
                ((ViewGroup.MarginLayoutParams) com1Var).rightMargin = i7;
                z6 = true;
            }
        }
        if (z4) {
            int i8 = ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin;
            int i9 = rect.bottom;
            if (i8 != i9) {
                ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin = i9;
                return true;
            }
        }
        return z6;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: r, reason: merged with bridge method [inline-methods] */
    public com1 generateDefaultLayoutParams() {
        return new com1(-1, -1);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
    public com1 generateLayoutParams(AttributeSet attributeSet) {
        return new com1(getContext(), attributeSet);
    }

    public void setActionBarHideOffset(int i2) {
        u();
        this.f1954a.setTranslationY(-Math.max(0, Math.min(i2, this.f1954a.getHeight())));
    }

    public void setActionBarVisibilityCallback(prn prnVar) {
        this.f1955a = prnVar;
        if (getWindowToken() != null) {
            this.f1955a.onWindowVisibilityChanged(this.f7856b);
            int i2 = this.f7858d;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                y.l0(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f1967d = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f1968e) {
            this.f1968e = z2;
            if (z2) {
                return;
            }
            u();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        z();
        this.f1946a.j(i2);
    }

    public void setLogo(int i2) {
        z();
        this.f1946a.k(i2);
    }

    public void setOverlayMode(boolean z2) {
        this.f1964c = z2;
        this.f1961b = z2 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    @Override // p022CoN.q
    public void setWindowCallback(Window.Callback callback) {
        z();
        this.f1946a.setWindowCallback(callback);
    }

    @Override // p022CoN.q
    public void setWindowTitle(CharSequence charSequence) {
        z();
        this.f1946a.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final r t(View view) {
        if (view instanceof r) {
            return (r) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    public void u() {
        removeCallbacks(this.f1957a);
        removeCallbacks(this.f1960b);
        ViewPropertyAnimator viewPropertyAnimator = this.f1952a;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void v(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f7855a);
        this.f1945a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f1951a = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f1961b = context.getApplicationInfo().targetSdkVersion < 19;
        this.f1953a = new OverScroller(context);
    }

    public boolean w() {
        return this.f1964c;
    }

    public final void x() {
        u();
        postDelayed(this.f1960b, 600L);
    }

    public final void y() {
        u();
        postDelayed(this.f1957a, 600L);
    }

    public void z() {
        if (this.f1956a == null) {
            this.f1956a = (ContentFrameLayout) findViewById(com8.f5566b);
            this.f1954a = (ActionBarContainer) findViewById(com8.f5567c);
            this.f1946a = t(findViewById(com8.f5565a));
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new com1(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        z();
        this.f1946a.n(drawable);
    }
}
