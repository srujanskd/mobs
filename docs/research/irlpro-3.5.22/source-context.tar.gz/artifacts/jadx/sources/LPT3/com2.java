package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;

/* JADX INFO: loaded from: classes.dex */
public final class com2 extends lpt1 {
    public static void h(int i2, int[] iArr) {
        for (int i3 = 0; i3 < 9; i3++) {
            int i4 = 1;
            if (((1 << (8 - i3)) & i2) != 0) {
                i4 = 2;
            }
            iArr[i3] = i4;
        }
    }

    /* JADX WARN: Code duplicated, block: B:51:0x00ec  */
    public static String i(String str) {
        int length = str.length();
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt == 0) {
                sb.append("%U");
            } else if (cCharAt == ' ') {
                sb.append(cCharAt);
            } else if (cCharAt == '@') {
                sb.append("%V");
            } else if (cCharAt == '`') {
                sb.append("%W");
            } else if (cCharAt == '-' || cCharAt == '.') {
                sb.append(cCharAt);
            } else if (cCharAt <= 26) {
                sb.append('$');
                sb.append((char) ((cCharAt - 1) + 65));
            } else if (cCharAt < ' ') {
                sb.append('%');
                sb.append((char) ((cCharAt - 27) + 65));
            } else if (cCharAt <= ',' || cCharAt == '/' || cCharAt == ':') {
                sb.append(inet.ipaddr.com6.PREFIX_LEN_SEPARATOR);
                sb.append((char) ((cCharAt - '!') + 65));
            } else if (cCharAt <= '9') {
                sb.append((char) ((cCharAt - '0') + 48));
            } else if (cCharAt <= '?') {
                sb.append('%');
                sb.append((char) ((cCharAt - ';') + 70));
            } else if (cCharAt <= 'Z') {
                sb.append((char) ((cCharAt - 'A') + 65));
            } else if (cCharAt <= '_') {
                sb.append('%');
                sb.append((char) ((cCharAt - '[') + 75));
            } else if (cCharAt <= 'z') {
                sb.append('+');
                sb.append((char) ((cCharAt - 'a') + 65));
            } else {
                if (cCharAt > 127) {
                    throw new IllegalArgumentException("Requested content contains a non-encodable character: '" + str.charAt(i2) + "'");
                }
                sb.append('%');
                sb.append((char) ((cCharAt - '{') + 80));
            }
        }
        return sb.toString();
    }

    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int length = str.length();
        if (length > 80) {
            throw new IllegalArgumentException("Requested contents should be less than 80 digits long, but got ".concat(String.valueOf(length)));
        }
        for (int i2 = 0; i2 < length; i2++) {
            if ("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%".indexOf(str.charAt(i2)) < 0) {
                str = i(str);
                length = str.length();
                if (length <= 80) {
                    break;
                }
                throw new IllegalArgumentException("Requested contents should be less than 80 digits long, but got " + length + " (extended full ASCII mode)");
            }
        }
        int[] iArr = new int[9];
        boolean[] zArr = new boolean[(length * 13) + 25];
        h(148, iArr);
        int iB = lpt1.b(zArr, 0, iArr, true);
        int[] iArr2 = {1};
        int iB2 = iB + lpt1.b(zArr, iB, iArr2, false);
        for (int i3 = 0; i3 < length; i3++) {
            h(com1.f6622a["0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%".indexOf(str.charAt(i3))], iArr);
            int iB3 = iB2 + lpt1.b(zArr, iB2, iArr, true);
            iB2 = iB3 + lpt1.b(zArr, iB3, iArr2, false);
        }
        h(148, iArr);
        lpt1.b(zArr, iB2, iArr, true);
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.CODE_39);
    }
}
