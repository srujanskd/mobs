package androidx.lifecycle;

import f.com8;
import n.q0;

/* JADX INFO: loaded from: classes.dex */
final class LifecycleController$observer$1 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ q0 f8368a;

    @Override // androidx.lifecycle.prn
    public final void f(COM3.com7 com7Var, nul.con conVar) {
        com8.e(com7Var, "source");
        com8.e(conVar, "<anonymous parameter 1>");
        nul lifecycle = com7Var.getLifecycle();
        com8.d(lifecycle, "source.lifecycle");
        if (lifecycle.b() == nul.EnumC0039nul.DESTROYED) {
            q0.aux.a(this.f8368a, null, 1, null);
            throw null;
        }
        nul lifecycle2 = com7Var.getLifecycle();
        com8.d(lifecycle2, "source.lifecycle");
        if (lifecycle2.b().compareTo(COM3.com2.b(null)) < 0) {
            COM3.com2.a(null);
            throw null;
        }
        COM3.com2.a(null);
        throw null;
    }
}
