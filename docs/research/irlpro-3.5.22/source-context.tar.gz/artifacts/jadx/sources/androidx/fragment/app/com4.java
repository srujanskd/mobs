package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import p092coM3.m0;

/* JADX INFO: loaded from: classes.dex */
public class com4 implements LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com6 f8247a;

    public class aux implements View.OnAttachStateChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ lpt1 f2432a;

        public aux(lpt1 lpt1Var) {
            this.f2432a = lpt1Var;
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            Fragment fragmentK = this.f2432a.k();
            this.f2432a.m();
            lpt5.o((ViewGroup) fragmentK.mView.getParent(), com4.this.f8247a).j();
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }

    public com4(com6 com6Var) {
        this.f8247a = com6Var;
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // android.view.LayoutInflater.Factory2
    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        lpt1 lpt1VarW;
        if (FragmentContainerView.class.getName().equals(str)) {
            return new FragmentContainerView(context, attributeSet, this.f8247a);
        }
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, m0.f3227d);
        if (attributeValue == null) {
            attributeValue = typedArrayObtainStyledAttributes.getString(m0.f9202a);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(m0.f9203b, -1);
        String string = typedArrayObtainStyledAttributes.getString(m0.f9204c);
        typedArrayObtainStyledAttributes.recycle();
        if (attributeValue == null || !com2.b(context.getClassLoader(), attributeValue)) {
            return null;
        }
        int id = view != null ? view.getId() : 0;
        if (id == -1 && resourceId == -1 && string == null) {
            throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
        }
        Fragment fragmentI0 = resourceId != -1 ? this.f8247a.i0(resourceId) : null;
        if (fragmentI0 == null && string != null) {
            fragmentI0 = this.f8247a.j0(string);
        }
        if (fragmentI0 == null && id != -1) {
            fragmentI0 = this.f8247a.i0(id);
        }
        if (fragmentI0 == null) {
            fragmentI0 = this.f8247a.s0().a(context.getClassLoader(), attributeValue);
            fragmentI0.mFromLayout = true;
            fragmentI0.mFragmentId = resourceId != 0 ? resourceId : id;
            fragmentI0.mContainerId = id;
            fragmentI0.mTag = string;
            fragmentI0.mInLayout = true;
            com6 com6Var = this.f8247a;
            fragmentI0.mFragmentManager = com6Var;
            fragmentI0.mHost = com6Var.v0();
            fragmentI0.onInflate(this.f8247a.v0().f(), attributeSet, fragmentI0.mSavedFragmentState);
            lpt1VarW = this.f8247a.g(fragmentI0);
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Fragment " + fragmentI0 + " has been inflated via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
            }
        } else {
            if (fragmentI0.mInLayout) {
                throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
            }
            fragmentI0.mInLayout = true;
            com6 com6Var2 = this.f8247a;
            fragmentI0.mFragmentManager = com6Var2;
            fragmentI0.mHost = com6Var2.v0();
            fragmentI0.onInflate(this.f8247a.v0().f(), attributeSet, fragmentI0.mSavedFragmentState);
            lpt1VarW = this.f8247a.w(fragmentI0);
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Retained Fragment " + fragmentI0 + " has been re-attached via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
            }
        }
        fragmentI0.mContainer = (ViewGroup) view;
        lpt1VarW.m();
        lpt1VarW.j();
        View view2 = fragmentI0.mView;
        if (view2 == null) {
            throw new IllegalStateException("Fragment " + attributeValue + " did not create a view.");
        }
        if (resourceId != 0) {
            view2.setId(resourceId);
        }
        if (fragmentI0.mView.getTag() == null) {
            fragmentI0.mView.setTag(string);
        }
        fragmentI0.mView.addOnAttachStateChangeListener(new aux(lpt1VarW));
        return fragmentI0.mView;
    }
}
