package androidx.fragment.app;

import p147nUl.d0;

/* JADX INFO: loaded from: classes.dex */
public class com2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final d0<ClassLoader, d0<String, Class<?>>> f8245a = new d0<>();

    public static boolean b(ClassLoader classLoader, String str) {
        try {
            return Fragment.class.isAssignableFrom(c(classLoader, str));
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    public static Class<?> c(ClassLoader classLoader, String str) throws ClassNotFoundException {
        d0<ClassLoader, d0<String, Class<?>>> d0Var = f8245a;
        d0<String, Class<?>> d0Var2 = d0Var.get(classLoader);
        if (d0Var2 == null) {
            d0Var2 = new d0<>();
            d0Var.put(classLoader, d0Var2);
        }
        Class<?> cls = d0Var2.get(str);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        d0Var2.put(str, cls2);
        return cls2;
    }

    public static Class<? extends Fragment> d(ClassLoader classLoader, String str) {
        try {
            return c(classLoader, str);
        } catch (ClassCastException e2) {
            throw new Fragment.com6("Unable to instantiate fragment " + str + ": make sure class is a valid subclass of Fragment", e2);
        } catch (ClassNotFoundException e3) {
            throw new Fragment.com6("Unable to instantiate fragment " + str + ": make sure class name exists", e3);
        }
    }

    public Fragment a(ClassLoader classLoader, String str) {
        throw null;
    }
}
