package com.google.android.material.timepicker;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import java.util.Arrays;
import p024Com2.lpt3;
import p024Com2.y;
import p042LpT1.l;
import p075cOM6.b4;
import p075cOM6.d4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.y3;
import p075cOM6.z3;
import p081cOm2.e2;
import p098coM9.b;

/* JADX INFO: loaded from: classes.dex */
class ClockFaceView extends l implements ClockHandView.prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f9677a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt3 f3748a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ColorStateList f3749a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f3750a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f3751a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ClockHandView f3752a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final float[] f3753a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f3754a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String[] f3755a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final SparseArray<TextView> f9678c;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f9679p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f9680q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f9681r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f9682s;

    public class aux implements ViewTreeObserver.OnPreDrawListener {
        public aux() {
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            if (!ClockFaceView.this.isShown()) {
                return true;
            }
            ClockFaceView.this.getViewTreeObserver().removeOnPreDrawListener(this);
            ClockFaceView.this.D(((ClockFaceView.this.getHeight() / 2) - ClockFaceView.this.f3752a.g()) - ClockFaceView.this.f9679p);
            return true;
        }
    }

    public class con extends lpt3 {
        public con() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            int iIntValue = ((Integer) view.getTag(b4.f8903z)).intValue();
            if (iIntValue > 0) {
                e2Var.w0((View) ClockFaceView.this.f9678c.get(iIntValue - 1));
            }
            e2Var.W(e2.nul.a(0, 1, iIntValue, 1, false, view.isSelected()));
            e2Var.U(true);
            e2Var.b(e2.aux.f9101e);
        }

        @Override // p024Com2.lpt3
        public boolean j(View view, int i2, Bundle bundle) {
            if (i2 != 16) {
                return super.j(view, i2, bundle);
            }
            long jUptimeMillis = SystemClock.uptimeMillis();
            float x2 = view.getX() + (view.getWidth() / 2.0f);
            float height = (view.getHeight() / 2.0f) + view.getY();
            ClockFaceView.this.f3752a.onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 0, x2, height, 0));
            ClockFaceView.this.f3752a.onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 1, x2, height, 0));
            return true;
        }
    }

    public ClockFaceView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.f9048w);
    }

    public static float M(float f2, float f3, float f4) {
        return Math.max(Math.max(f2, f3), f4);
    }

    @Override // p042LpT1.l
    public void D(int i2) {
        if (i2 != C()) {
            super.D(i2);
            this.f3752a.k(C());
        }
    }

    public final void K() {
        RectF rectFD = this.f3752a.d();
        for (int i2 = 0; i2 < this.f9678c.size(); i2++) {
            TextView textView = this.f9678c.get(i2);
            if (textView != null) {
                textView.getDrawingRect(this.f3750a);
                offsetDescendantRectToMyCoords(textView, this.f3750a);
                textView.setSelected(rectFD.contains(this.f3750a.centerX(), this.f3750a.centerY()));
                textView.getPaint().setShader(L(rectFD, this.f3750a, textView));
                textView.invalidate();
            }
        }
    }

    public final RadialGradient L(RectF rectF, Rect rect, TextView textView) {
        this.f3751a.set(rect);
        this.f3751a.offset(textView.getPaddingLeft(), textView.getPaddingTop());
        if (RectF.intersects(rectF, this.f3751a)) {
            return new RadialGradient(rectF.centerX() - this.f3751a.left, rectF.centerY() - this.f3751a.top, rectF.width() * 0.5f, this.f3754a, this.f3753a, Shader.TileMode.CLAMP);
        }
        return null;
    }

    public void N(String[] strArr, int i2) {
        this.f3755a = strArr;
        O(i2);
    }

    public final void O(int i2) {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(getContext());
        int size = this.f9678c.size();
        for (int i3 = 0; i3 < Math.max(this.f3755a.length, size); i3++) {
            TextView textView = this.f9678c.get(i3);
            if (i3 >= this.f3755a.length) {
                removeView(textView);
                this.f9678c.remove(i3);
            } else {
                if (textView == null) {
                    textView = (TextView) layoutInflaterFrom.inflate(d4.f8913g, (ViewGroup) this, false);
                    this.f9678c.put(i3, textView);
                    addView(textView);
                }
                textView.setVisibility(0);
                textView.setText(this.f3755a[i3]);
                textView.setTag(b4.f8903z, Integer.valueOf(i3));
                y.o0(textView, this.f3748a);
                textView.setTextColor(this.f3749a);
                if (i2 != 0) {
                    textView.setContentDescription(getResources().getString(i2, this.f3755a[i3]));
                }
            }
        }
    }

    @Override // com.google.android.material.timepicker.ClockHandView.prn
    public void d(float f2, boolean z2) {
        if (Math.abs(this.f9677a - f2) > 0.001f) {
            this.f9677a = f2;
            K();
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        e2.z0(accessibilityNodeInfo).V(e2.con.a(1, this.f3755a.length, false, 1));
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        K();
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        int iM = (int) (this.f9682s / M(this.f9680q / displayMetrics.heightPixels, this.f9681r / displayMetrics.widthPixels, 1.0f));
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iM, 1073741824);
        setMeasuredDimension(iM, iM);
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public ClockFaceView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f3750a = new Rect();
        this.f3751a = new RectF();
        this.f9678c = new SparseArray<>();
        this.f3753a = new float[]{0.0f, 0.9f, 1.0f};
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3056C, i2, g4.f8979x);
        Resources resources = getResources();
        ColorStateList colorStateListB = b.b(context, typedArrayObtainStyledAttributes, h4.G0);
        this.f3749a = colorStateListB;
        LayoutInflater.from(context).inflate(d4.f8914h, (ViewGroup) this, true);
        ClockHandView clockHandView = (ClockHandView) findViewById(b4.f8889l);
        this.f3752a = clockHandView;
        this.f9679p = resources.getDimensionPixelSize(z3.f9069l);
        int colorForState = colorStateListB.getColorForState(new int[]{R.attr.state_selected}, colorStateListB.getDefaultColor());
        this.f3754a = new int[]{colorForState, colorForState, colorStateListB.getDefaultColor()};
        clockHandView.b(this);
        int defaultColor = AUX.aux.a(context, y3.f9053b).getDefaultColor();
        ColorStateList colorStateListB2 = b.b(context, typedArrayObtainStyledAttributes, h4.F0);
        setBackgroundColor(colorStateListB2 != null ? colorStateListB2.getDefaultColor() : defaultColor);
        getViewTreeObserver().addOnPreDrawListener(new aux());
        setFocusable(true);
        typedArrayObtainStyledAttributes.recycle();
        this.f3748a = new con();
        String[] strArr = new String[12];
        Arrays.fill(strArr, "");
        N(strArr, 0);
        this.f9680q = resources.getDimensionPixelSize(z3.f9082y);
        this.f9681r = resources.getDimensionPixelSize(z3.f9083z);
        this.f9682s = resources.getDimensionPixelSize(z3.f9071n);
    }
}
