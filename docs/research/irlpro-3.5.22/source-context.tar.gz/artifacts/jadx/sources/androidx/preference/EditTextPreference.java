package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.EditText;
import p016CoM4.com8;
import p016CoM4.lpt5;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class EditTextPreference extends DialogPreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public aux f8425a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2632a;

    public interface aux {
        void a(EditText editText);
    }

    public static final class nul implements Preference.com3<EditTextPreference> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static nul f8427a;

        public static nul b() {
            if (f8427a == null) {
                f8427a = new nul();
            }
            return f8427a;
        }

        @Override // androidx.preference.Preference.com3
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public CharSequence a(EditTextPreference editTextPreference) {
            return TextUtils.isEmpty(editTextPreference.b()) ? editTextPreference.getContext().getString(lpt5.f6199c) : editTextPreference.b();
        }
    }

    public EditTextPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f531d, i2, i3);
        int i4 = lpt7.f6237t;
        if (l0.b(typedArrayObtainStyledAttributes, i4, i4, false)) {
            setSummaryProvider(nul.b());
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public aux a() {
        return this.f8425a;
    }

    public String b() {
        return this.f2632a;
    }

    public void c(aux auxVar) {
        this.f8425a = auxVar;
    }

    public void d(String str) {
        boolean zShouldDisableDependents = shouldDisableDependents();
        this.f2632a = str;
        persistString(str);
        boolean zShouldDisableDependents2 = shouldDisableDependents();
        if (zShouldDisableDependents2 != zShouldDisableDependents) {
            notifyDependencyChange(zShouldDisableDependents2);
        }
        notifyChanged();
    }

    @Override // androidx.preference.Preference
    public Object onGetDefaultValue(TypedArray typedArray, int i2) {
        return typedArray.getString(i2);
    }

    @Override // androidx.preference.Preference
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(con.class)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        con conVar = (con) parcelable;
        super.onRestoreInstanceState(conVar.getSuperState());
        d(conVar.f8426a);
    }

    @Override // androidx.preference.Preference
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState = super.onSaveInstanceState();
        if (isPersistent()) {
            return parcelableOnSaveInstanceState;
        }
        con conVar = new con(parcelableOnSaveInstanceState);
        conVar.f8426a = b();
        return conVar;
    }

    @Override // androidx.preference.Preference
    public void onSetInitialValue(Object obj) {
        d(getPersistedString((String) obj));
    }

    @Override // androidx.preference.Preference
    public boolean shouldDisableDependents() {
        return TextUtils.isEmpty(this.f2632a) || super.shouldDisableDependents();
    }

    public static class con extends Preference.con {
        public static final Parcelable.Creator<con> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public String f8426a;

        public class aux implements Parcelable.Creator<con> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public con createFromParcel(Parcel parcel) {
                return new con(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public con[] newArray(int i2) {
                return new con[i2];
            }
        }

        public con(Parcel parcel) {
            super(parcel);
            this.f8426a = parcel.readString();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeString(this.f8426a);
        }

        public con(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public EditTextPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public EditTextPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6170d, R.attr.editTextPreferenceStyle));
    }

    public EditTextPreference(Context context) {
        this(context, null);
    }
}
