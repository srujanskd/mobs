package b0;

import i0.b;
import i0.lpt9;
import java.io.IOException;
import v.e;
import v.g;

/* JADX INFO: loaded from: classes.dex */
public interface prn {
    void a() throws IOException;

    a0.com2 b();

    lpt9 c(e eVar, long j2) throws IOException;

    void cancel();

    void d(e eVar) throws IOException;

    long e(g gVar) throws IOException;

    void f() throws IOException;

    g.aux g(boolean z2) throws IOException;

    b h(g gVar) throws IOException;
}
