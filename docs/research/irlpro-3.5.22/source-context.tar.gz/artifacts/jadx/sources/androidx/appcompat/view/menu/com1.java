package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import p024Com2.j0;
import p024Com2.lpt4;

/* JADX INFO: loaded from: classes.dex */
public class com1 implements p003COm1.com3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f7789a = {1, 4, 5, 3, 2, 0};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f1833a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Resources f1834a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1835a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ContextMenu.ContextMenuInfo f1836a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1837a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public aux f1838a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f1839a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f1840a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1843a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1844b;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f7799k;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f1832a = 0;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f1847e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f7794f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f7795g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f7796h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f7797i = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList<com3> f7793e = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CopyOnWriteArrayList<WeakReference<com5>> f1842a = new CopyOnWriteArrayList<>();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f7798j = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<com3> f1841a = new ArrayList<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList<com3> f7790b = new ArrayList<>();

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1845c = true;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ArrayList<com3> f7791c = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<com3> f7792d = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f1846d = true;

    public interface aux {
        void a(com1 com1Var);

        boolean b(com1 com1Var, MenuItem menuItem);
    }

    public interface con {
        boolean a(com3 com3Var);
    }

    public com1(Context context) {
        this.f1833a = context;
        this.f1834a = context.getResources();
        b0(true);
    }

    public static int B(int i2) {
        int i3 = ((-65536) & i2) >> 16;
        if (i3 >= 0) {
            int[] iArr = f7789a;
            if (i3 < iArr.length) {
                return (i2 & 65535) | (iArr[i3] << 16);
            }
        }
        throw new IllegalArgumentException("order does not contain a valid category.");
    }

    public static int n(ArrayList<com3> arrayList, int i2) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (arrayList.get(size).h() <= i2) {
                return size + 1;
            }
        }
        return 0;
    }

    public boolean A() {
        return this.f7796h;
    }

    public Resources C() {
        return this.f1834a;
    }

    public com1 D() {
        return this;
    }

    public ArrayList<com3> E() {
        if (!this.f1845c) {
            return this.f7790b;
        }
        this.f7790b.clear();
        int size = this.f1841a.size();
        for (int i2 = 0; i2 < size; i2++) {
            com3 com3Var = this.f1841a.get(i2);
            if (com3Var.isVisible()) {
                this.f7790b.add(com3Var);
            }
        }
        this.f1845c = false;
        this.f1846d = true;
        return this.f7790b;
    }

    public boolean F() {
        return this.f7798j;
    }

    public boolean G() {
        return this.f1843a;
    }

    public boolean H() {
        return this.f1844b;
    }

    public void I(com3 com3Var) {
        this.f1846d = true;
        K(true);
    }

    public void J(com3 com3Var) {
        this.f1845c = true;
        K(true);
    }

    public void K(boolean z2) {
        if (this.f1847e) {
            this.f7794f = true;
            if (z2) {
                this.f7795g = true;
                return;
            }
            return;
        }
        if (z2) {
            this.f1845c = true;
            this.f1846d = true;
        }
        i(z2);
    }

    public boolean L(MenuItem menuItem, int i2) {
        return M(menuItem, null, i2);
    }

    public boolean M(MenuItem menuItem, com5 com5Var, int i2) {
        com3 com3Var = (com3) menuItem;
        if (com3Var == null || !com3Var.isEnabled()) {
            return false;
        }
        boolean zM = com3Var.m();
        lpt4 lpt4VarC = com3Var.c();
        boolean z2 = lpt4VarC != null && lpt4VarC.a();
        if (com3Var.l()) {
            zM |= com3Var.expandActionView();
            if (zM) {
                e(true);
            }
        } else if (com3Var.hasSubMenu() || z2) {
            if ((i2 & 4) == 0) {
                e(false);
            }
            if (!com3Var.hasSubMenu()) {
                com3Var.z(new com8(u(), this, com3Var));
            }
            com8 com8Var = (com8) com3Var.getSubMenu();
            if (z2) {
                lpt4VarC.f(com8Var);
            }
            zM |= j(com8Var, com5Var);
            if (!zM) {
                e(true);
            }
        } else if ((i2 & 1) == 0) {
            e(true);
        }
        return zM;
    }

    public final void N(int i2, boolean z2) {
        if (i2 < 0 || i2 >= this.f1841a.size()) {
            return;
        }
        this.f1841a.remove(i2);
        if (z2) {
            K(true);
        }
    }

    public void O(com5 com5Var) {
        for (WeakReference<com5> weakReference : this.f1842a) {
            com5 com5Var2 = weakReference.get();
            if (com5Var2 == null || com5Var2 == com5Var) {
                this.f1842a.remove(weakReference);
            }
        }
    }

    public void P(Bundle bundle) {
        MenuItem menuItemFindItem;
        if (bundle == null) {
            return;
        }
        SparseArray<Parcelable> sparseParcelableArray = bundle.getSparseParcelableArray(t());
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = getItem(i2);
            View actionView = item.getActionView();
            if (actionView != null && actionView.getId() != -1) {
                actionView.restoreHierarchyState(sparseParcelableArray);
            }
            if (item.hasSubMenu()) {
                ((com8) item.getSubMenu()).P(bundle);
            }
        }
        int i3 = bundle.getInt("android:menu:expandedactionview");
        if (i3 <= 0 || (menuItemFindItem = findItem(i3)) == null) {
            return;
        }
        menuItemFindItem.expandActionView();
    }

    public void Q(Bundle bundle) {
        int size = size();
        SparseArray<? extends Parcelable> sparseArray = null;
        for (int i2 = 0; i2 < size; i2++) {
            MenuItem item = getItem(i2);
            View actionView = item.getActionView();
            if (actionView != null && actionView.getId() != -1) {
                if (sparseArray == null) {
                    sparseArray = new SparseArray<>();
                }
                actionView.saveHierarchyState(sparseArray);
                if (item.isActionViewExpanded()) {
                    bundle.putInt("android:menu:expandedactionview", item.getItemId());
                }
            }
            if (item.hasSubMenu()) {
                ((com8) item.getSubMenu()).Q(bundle);
            }
        }
        if (sparseArray != null) {
            bundle.putSparseParcelableArray(t(), sparseArray);
        }
    }

    public void R(aux auxVar) {
        this.f1838a = auxVar;
    }

    public com1 S(int i2) {
        this.f1832a = i2;
        return this;
    }

    public void T(MenuItem menuItem) {
        int groupId = menuItem.getGroupId();
        int size = this.f1841a.size();
        d0();
        for (int i2 = 0; i2 < size; i2++) {
            com3 com3Var = this.f1841a.get(i2);
            if (com3Var.getGroupId() == groupId && com3Var.o() && com3Var.isCheckable()) {
                com3Var.u(com3Var == menuItem);
            }
        }
        c0();
    }

    public com1 U(int i2) {
        W(0, null, i2, null, null);
        return this;
    }

    public com1 V(Drawable drawable) {
        W(0, null, 0, drawable, null);
        return this;
    }

    public final void W(int i2, CharSequence charSequence, int i3, Drawable drawable, View view) {
        Resources resourcesC = C();
        if (view != null) {
            this.f1837a = view;
            this.f1840a = null;
            this.f1835a = null;
        } else {
            if (i2 > 0) {
                this.f1840a = resourcesC.getText(i2);
            } else if (charSequence != null) {
                this.f1840a = charSequence;
            }
            if (i3 > 0) {
                this.f1835a = PRN.aux.e(u(), i3);
            } else if (drawable != null) {
                this.f1835a = drawable;
            }
            this.f1837a = null;
        }
        K(false);
    }

    public com1 X(int i2) {
        W(i2, null, 0, null, null);
        return this;
    }

    public com1 Y(CharSequence charSequence) {
        W(0, charSequence, 0, null, null);
        return this;
    }

    public com1 Z(View view) {
        W(0, null, 0, null, view);
        return this;
    }

    public MenuItem a(int i2, int i3, int i4, CharSequence charSequence) {
        int iB = B(i4);
        com3 com3VarG = g(i2, i3, i4, iB, charSequence, this.f1832a);
        ContextMenu.ContextMenuInfo contextMenuInfo = this.f1836a;
        if (contextMenuInfo != null) {
            com3VarG.x(contextMenuInfo);
        }
        ArrayList<com3> arrayList = this.f1841a;
        arrayList.add(n(arrayList, iB), com3VarG);
        K(true);
        return com3VarG;
    }

    public void a0(boolean z2) {
        this.f7799k = z2;
    }

    @Override // android.view.Menu
    public MenuItem add(CharSequence charSequence) {
        return a(0, 0, 0, charSequence);
    }

    @Override // android.view.Menu
    public int addIntentOptions(int i2, int i3, int i4, ComponentName componentName, Intent[] intentArr, Intent intent, int i5, MenuItem[] menuItemArr) {
        int i6;
        PackageManager packageManager = this.f1833a.getPackageManager();
        List<ResolveInfo> listQueryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        int size = listQueryIntentActivityOptions != null ? listQueryIntentActivityOptions.size() : 0;
        if ((i5 & 1) == 0) {
            removeGroup(i2);
        }
        for (int i7 = 0; i7 < size; i7++) {
            ResolveInfo resolveInfo = listQueryIntentActivityOptions.get(i7);
            int i8 = resolveInfo.specificIndex;
            Intent intent2 = new Intent(i8 < 0 ? intent : intentArr[i8]);
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            intent2.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
            MenuItem intent3 = add(i2, i3, i4, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent2);
            if (menuItemArr != null && (i6 = resolveInfo.specificIndex) >= 0) {
                menuItemArr[i6] = intent3;
            }
        }
        return size;
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }

    public void b(com5 com5Var) {
        c(com5Var, this.f1833a);
    }

    /* JADX WARN: Code duplicated, block: B:8:0x001c  */
    public final void b0(boolean z2) {
        boolean z3;
        if (z2) {
            z3 = this.f1834a.getConfiguration().keyboard != 1 && j0.c(ViewConfiguration.get(this.f1833a), this.f1833a);
        }
        this.f1844b = z3;
    }

    public void c(com5 com5Var, Context context) {
        this.f1842a.add(new WeakReference<>(com5Var));
        com5Var.i(context, this);
        this.f1846d = true;
    }

    public void c0() {
        this.f1847e = false;
        if (this.f7794f) {
            this.f7794f = false;
            K(this.f7795g);
        }
    }

    @Override // android.view.Menu
    public void clear() {
        com3 com3Var = this.f1839a;
        if (com3Var != null) {
            f(com3Var);
        }
        this.f1841a.clear();
        K(true);
    }

    public void clearHeader() {
        this.f1835a = null;
        this.f1840a = null;
        this.f1837a = null;
        K(false);
    }

    @Override // android.view.Menu
    public void close() {
        e(true);
    }

    public void d() {
        aux auxVar = this.f1838a;
        if (auxVar != null) {
            auxVar.a(this);
        }
    }

    public void d0() {
        if (this.f1847e) {
            return;
        }
        this.f1847e = true;
        this.f7794f = false;
        this.f7795g = false;
    }

    public final void e(boolean z2) {
        if (this.f7797i) {
            return;
        }
        this.f7797i = true;
        for (WeakReference<com5> weakReference : this.f1842a) {
            com5 com5Var = weakReference.get();
            if (com5Var == null) {
                this.f1842a.remove(weakReference);
            } else {
                com5Var.c(this, z2);
            }
        }
        this.f7797i = false;
    }

    public boolean f(com3 com3Var) {
        boolean zH = false;
        if (!this.f1842a.isEmpty() && this.f1839a == com3Var) {
            d0();
            for (WeakReference<com5> weakReference : this.f1842a) {
                com5 com5Var = weakReference.get();
                if (com5Var != null) {
                    zH = com5Var.h(this, com3Var);
                    if (zH) {
                        break;
                    }
                } else {
                    this.f1842a.remove(weakReference);
                }
            }
            c0();
            if (zH) {
                this.f1839a = null;
            }
        }
        return zH;
    }

    @Override // android.view.Menu
    public MenuItem findItem(int i2) {
        MenuItem menuItemFindItem;
        int size = size();
        for (int i3 = 0; i3 < size; i3++) {
            com3 com3Var = this.f1841a.get(i3);
            if (com3Var.getItemId() == i2) {
                return com3Var;
            }
            if (com3Var.hasSubMenu() && (menuItemFindItem = com3Var.getSubMenu().findItem(i2)) != null) {
                return menuItemFindItem;
            }
        }
        return null;
    }

    public final com3 g(int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        return new com3(this, i2, i3, i4, i5, charSequence, i6);
    }

    @Override // android.view.Menu
    public MenuItem getItem(int i2) {
        return this.f1841a.get(i2);
    }

    public boolean h(com1 com1Var, MenuItem menuItem) {
        aux auxVar = this.f1838a;
        return auxVar != null && auxVar.b(com1Var, menuItem);
    }

    @Override // android.view.Menu
    public boolean hasVisibleItems() {
        if (this.f7799k) {
            return true;
        }
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            if (this.f1841a.get(i2).isVisible()) {
                return true;
            }
        }
        return false;
    }

    public final void i(boolean z2) {
        if (this.f1842a.isEmpty()) {
            return;
        }
        d0();
        for (WeakReference<com5> weakReference : this.f1842a) {
            com5 com5Var = weakReference.get();
            if (com5Var == null) {
                this.f1842a.remove(weakReference);
            } else {
                com5Var.e(z2);
            }
        }
        c0();
    }

    @Override // android.view.Menu
    public boolean isShortcutKey(int i2, KeyEvent keyEvent) {
        return p(i2, keyEvent) != null;
    }

    public final boolean j(com8 com8Var, com5 com5Var) {
        if (this.f1842a.isEmpty()) {
            return false;
        }
        boolean zJ = com5Var != null ? com5Var.j(com8Var) : false;
        for (WeakReference<com5> weakReference : this.f1842a) {
            com5 com5Var2 = weakReference.get();
            if (com5Var2 == null) {
                this.f1842a.remove(weakReference);
            } else if (!zJ) {
                zJ = com5Var2.j(com8Var);
            }
        }
        return zJ;
    }

    public boolean k(com3 com3Var) {
        boolean zK = false;
        if (this.f1842a.isEmpty()) {
            return false;
        }
        d0();
        for (WeakReference<com5> weakReference : this.f1842a) {
            com5 com5Var = weakReference.get();
            if (com5Var != null) {
                zK = com5Var.k(this, com3Var);
                if (zK) {
                    break;
                }
            } else {
                this.f1842a.remove(weakReference);
            }
        }
        c0();
        if (zK) {
            this.f1839a = com3Var;
        }
        return zK;
    }

    public int l(int i2) {
        return m(i2, 0);
    }

    public int m(int i2, int i3) {
        int size = size();
        if (i3 < 0) {
            i3 = 0;
        }
        while (i3 < size) {
            if (this.f1841a.get(i3).getGroupId() == i2) {
                return i3;
            }
            i3++;
        }
        return -1;
    }

    public int o(int i2) {
        int size = size();
        for (int i3 = 0; i3 < size; i3++) {
            if (this.f1841a.get(i3).getItemId() == i2) {
                return i3;
            }
        }
        return -1;
    }

    public com3 p(int i2, KeyEvent keyEvent) {
        ArrayList<com3> arrayList = this.f7793e;
        arrayList.clear();
        q(arrayList, i2, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return arrayList.get(0);
        }
        boolean zG = G();
        for (int i3 = 0; i3 < size; i3++) {
            com3 com3Var = arrayList.get(i3);
            char alphabeticShortcut = zG ? com3Var.getAlphabeticShortcut() : com3Var.getNumericShortcut();
            char[] cArr = keyData.meta;
            if ((alphabeticShortcut == cArr[0] && (metaState & 2) == 0) || ((alphabeticShortcut == cArr[2] && (metaState & 2) != 0) || (zG && alphabeticShortcut == '\b' && i2 == 67))) {
                return com3Var;
            }
        }
        return null;
    }

    @Override // android.view.Menu
    public boolean performIdentifierAction(int i2, int i3) {
        return L(findItem(i2), i3);
    }

    @Override // android.view.Menu
    public boolean performShortcut(int i2, KeyEvent keyEvent, int i3) {
        com3 com3VarP = p(i2, keyEvent);
        boolean zL = com3VarP != null ? L(com3VarP, i3) : false;
        if ((i3 & 2) != 0) {
            e(true);
        }
        return zL;
    }

    public void q(List<com3> list, int i2, KeyEvent keyEvent) {
        boolean zG = G();
        int modifiers = keyEvent.getModifiers();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        if (keyEvent.getKeyData(keyData) || i2 == 67) {
            int size = this.f1841a.size();
            for (int i3 = 0; i3 < size; i3++) {
                com3 com3Var = this.f1841a.get(i3);
                if (com3Var.hasSubMenu()) {
                    ((com1) com3Var.getSubMenu()).q(list, i2, keyEvent);
                }
                char alphabeticShortcut = zG ? com3Var.getAlphabeticShortcut() : com3Var.getNumericShortcut();
                if (((modifiers & 69647) == ((zG ? com3Var.getAlphabeticModifiers() : com3Var.getNumericModifiers()) & 69647)) && alphabeticShortcut != 0) {
                    char[] cArr = keyData.meta;
                    if ((alphabeticShortcut == cArr[0] || alphabeticShortcut == cArr[2] || (zG && alphabeticShortcut == '\b' && i2 == 67)) && com3Var.isEnabled()) {
                        list.add(com3Var);
                    }
                }
            }
        }
    }

    public void r() {
        ArrayList<com3> arrayListE = E();
        if (this.f1846d) {
            boolean zF = false;
            for (WeakReference<com5> weakReference : this.f1842a) {
                com5 com5Var = weakReference.get();
                if (com5Var == null) {
                    this.f1842a.remove(weakReference);
                } else {
                    zF |= com5Var.f();
                }
            }
            if (zF) {
                this.f7791c.clear();
                this.f7792d.clear();
                int size = arrayListE.size();
                for (int i2 = 0; i2 < size; i2++) {
                    com3 com3Var = arrayListE.get(i2);
                    if (com3Var.n()) {
                        this.f7791c.add(com3Var);
                    } else {
                        this.f7792d.add(com3Var);
                    }
                }
            } else {
                this.f7791c.clear();
                this.f7792d.clear();
                this.f7792d.addAll(E());
            }
            this.f1846d = false;
        }
    }

    @Override // android.view.Menu
    public void removeGroup(int i2) {
        int iL = l(i2);
        if (iL >= 0) {
            int size = this.f1841a.size() - iL;
            int i3 = 0;
            while (true) {
                int i4 = i3 + 1;
                if (i3 >= size || this.f1841a.get(iL).getGroupId() != i2) {
                    break;
                }
                N(iL, false);
                i3 = i4;
            }
            K(true);
        }
    }

    @Override // android.view.Menu
    public void removeItem(int i2) {
        N(o(i2), true);
    }

    public ArrayList<com3> s() {
        r();
        return this.f7791c;
    }

    @Override // android.view.Menu
    public void setGroupCheckable(int i2, boolean z2, boolean z3) {
        int size = this.f1841a.size();
        for (int i3 = 0; i3 < size; i3++) {
            com3 com3Var = this.f1841a.get(i3);
            if (com3Var.getGroupId() == i2) {
                com3Var.v(z3);
                com3Var.setCheckable(z2);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupDividerEnabled(boolean z2) {
        this.f7798j = z2;
    }

    @Override // android.view.Menu
    public void setGroupEnabled(int i2, boolean z2) {
        int size = this.f1841a.size();
        for (int i3 = 0; i3 < size; i3++) {
            com3 com3Var = this.f1841a.get(i3);
            if (com3Var.getGroupId() == i2) {
                com3Var.setEnabled(z2);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupVisible(int i2, boolean z2) {
        int size = this.f1841a.size();
        boolean z3 = false;
        for (int i3 = 0; i3 < size; i3++) {
            com3 com3Var = this.f1841a.get(i3);
            if (com3Var.getGroupId() == i2 && com3Var.A(z2)) {
                z3 = true;
            }
        }
        if (z3) {
            K(true);
        }
    }

    @Override // android.view.Menu
    public void setQwertyMode(boolean z2) {
        this.f1843a = z2;
        K(false);
    }

    @Override // android.view.Menu
    public int size() {
        return this.f1841a.size();
    }

    public String t() {
        return "android:menu:actionviewstates";
    }

    public Context u() {
        return this.f1833a;
    }

    public com3 v() {
        return this.f1839a;
    }

    public Drawable w() {
        return this.f1835a;
    }

    public CharSequence x() {
        return this.f1840a;
    }

    public View y() {
        return this.f1837a;
    }

    public ArrayList<com3> z() {
        r();
        return this.f7792d;
    }

    @Override // android.view.Menu
    public MenuItem add(int i2) {
        return a(0, 0, 0, this.f1834a.getString(i2));
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i2) {
        return addSubMenu(0, 0, 0, this.f1834a.getString(i2));
    }

    @Override // android.view.Menu
    public MenuItem add(int i2, int i3, int i4, CharSequence charSequence) {
        return a(i2, i3, i4, charSequence);
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i2, int i3, int i4, CharSequence charSequence) {
        com3 com3Var = (com3) a(i2, i3, i4, charSequence);
        com8 com8Var = new com8(this.f1833a, this, com3Var);
        com3Var.z(com8Var);
        return com8Var;
    }

    @Override // android.view.Menu
    public MenuItem add(int i2, int i3, int i4, int i5) {
        return a(i2, i3, i4, this.f1834a.getString(i5));
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i2, int i3, int i4, int i5) {
        return addSubMenu(i2, i3, i4, this.f1834a.getString(i5));
    }
}
