package LPT1;

import java.lang.reflect.Field;
import java.util.Locale;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public abstract class nul implements LPT1.prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final nul f6592a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final /* synthetic */ nul[] f837a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final nul f6593b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final nul f6594c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final nul f6595d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final nul f6596e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final nul f6597f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final nul f6598g;

    public final enum aux extends nul {
        public aux(String str, int i2) {
            super(str, i2, null);
        }

        @Override // LPT1.prn
        public String translateName(Field field) {
            return field.getName();
        }
    }

    static {
        aux auxVar = new aux("IDENTITY", 0);
        f6592a = auxVar;
        nul nulVar = new nul("UPPER_CAMEL_CASE", 1) { // from class: LPT1.nul.con
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.prn
            public String translateName(Field field) {
                return nul.c(field.getName());
            }
        };
        f6593b = nulVar;
        nul nulVar2 = new nul("UPPER_CAMEL_CASE_WITH_SPACES", 2) { // from class: LPT1.nul.nul
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.prn
            public String translateName(Field field) {
                return nul.c(nul.a(field.getName(), ' '));
            }
        };
        f6594c = nulVar2;
        nul nulVar3 = new nul("UPPER_CASE_WITH_UNDERSCORES", 3) { // from class: LPT1.nul.prn
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.prn
            public String translateName(Field field) {
                return nul.a(field.getName(), inet.ipaddr.aux.SEGMENT_SQL_SINGLE_WILDCARD).toUpperCase(Locale.ENGLISH);
            }
        };
        f6595d = nulVar3;
        nul nulVar4 = new nul("LOWER_CASE_WITH_UNDERSCORES", 4) { // from class: LPT1.nul.com1
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.prn
            public String translateName(Field field) {
                return nul.a(field.getName(), inet.ipaddr.aux.SEGMENT_SQL_SINGLE_WILDCARD).toLowerCase(Locale.ENGLISH);
            }
        };
        f6596e = nulVar4;
        nul nulVar5 = new nul("LOWER_CASE_WITH_DASHES", 5) { // from class: LPT1.nul.com2
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.prn
            public String translateName(Field field) {
                return nul.a(field.getName(), '-').toLowerCase(Locale.ENGLISH);
            }
        };
        f6597f = nulVar5;
        nul nulVar6 = new nul("LOWER_CASE_WITH_DOTS", 6) { // from class: LPT1.nul.com3
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.prn
            public String translateName(Field field) {
                return nul.a(field.getName(), '.').toLowerCase(Locale.ENGLISH);
            }
        };
        f6598g = nulVar6;
        f837a = new nul[]{auxVar, nulVar, nulVar2, nulVar3, nulVar4, nulVar5, nulVar6};
    }

    public nul(String str, int i2) {
        super(str, i2);
    }

    public static String a(String str, char c2) {
        StringBuilder sb = new StringBuilder();
        int length = str.length();
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (Character.isUpperCase(cCharAt) && sb.length() != 0) {
                sb.append(c2);
            }
            sb.append(cCharAt);
        }
        return sb.toString();
    }

    public static String c(String str) {
        int length = str.length();
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            if (Character.isLetter(cCharAt)) {
                if (Character.isUpperCase(cCharAt)) {
                    return str;
                }
                char upperCase = Character.toUpperCase(cCharAt);
                if (i2 == 0) {
                    return upperCase + str.substring(1);
                }
                return str.substring(0, i2) + upperCase + str.substring(i2 + 1);
            }
        }
        return str;
    }

    public static nul valueOf(String str) {
        return (nul) Enum.valueOf(nul.class, str);
    }

    public static nul[] values() {
        return (nul[]) f837a.clone();
    }

    public /* synthetic */ nul(String str, int i2, aux auxVar) {
        this(str, i2);
    }
}
