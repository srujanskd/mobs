package b0;

import f.com8;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import p059Lpt9.a;

/* JADX INFO: loaded from: classes.dex */
public final class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f8801a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final String[] f2998a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final DateFormat[] f2999a;

    public static final class aux extends ThreadLocal<DateFormat> {
        @Override // java.lang.ThreadLocal
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public DateFormat initialValue() {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US);
            simpleDateFormat.setLenient(false);
            simpleDateFormat.setTimeZone(w.com1.f5453a);
            return simpleDateFormat;
        }
    }

    static {
        String[] strArr = {"EEE, dd MMM yyyy HH:mm:ss zzz", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy", "EEE, dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MMM-yyyy HH-mm-ss z", "EEE, dd MMM yy HH:mm:ss z", "EEE dd-MMM-yyyy HH:mm:ss z", "EEE dd MMM yyyy HH:mm:ss z", "EEE dd-MMM-yyyy HH-mm-ss z", "EEE dd-MMM-yy HH:mm:ss z", "EEE dd MMM yy HH:mm:ss z", "EEE,dd-MMM-yy HH:mm:ss z", "EEE,dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MM-yyyy HH:mm:ss z", "EEE MMM d yyyy HH:mm:ss z"};
        f2998a = strArr;
        f2999a = new DateFormat[strArr.length];
    }

    public static final Date a(String str) {
        com8.e(str, "<this>");
        if (str.length() == 0) {
            return null;
        }
        ParsePosition parsePosition = new ParsePosition(0);
        Date date = f8801a.get().parse(str, parsePosition);
        if (parsePosition.getIndex() == str.length()) {
            return date;
        }
        String[] strArr = f2998a;
        synchronized (strArr) {
            int length = strArr.length;
            int i2 = 0;
            while (i2 < length) {
                int i3 = i2 + 1;
                DateFormat[] dateFormatArr = f2999a;
                DateFormat simpleDateFormat = dateFormatArr[i2];
                if (simpleDateFormat == null) {
                    simpleDateFormat = new SimpleDateFormat(f2998a[i2], Locale.US);
                    simpleDateFormat.setTimeZone(w.com1.f5453a);
                    dateFormatArr[i2] = simpleDateFormat;
                }
                parsePosition.setIndex(0);
                Date date2 = simpleDateFormat.parse(str, parsePosition);
                if (parsePosition.getIndex() != 0) {
                    return date2;
                }
                i2 = i3;
            }
            a aVar = a.f7353a;
            return null;
        }
    }

    public static final String b(Date date) {
        com8.e(date, "<this>");
        String str = f8801a.get().format(date);
        com8.d(str, "STANDARD_DATE_FORMAT.get().format(this)");
        return str;
    }
}
