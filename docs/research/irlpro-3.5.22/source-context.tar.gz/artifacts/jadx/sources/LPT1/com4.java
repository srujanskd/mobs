package LPT1;

/* JADX INFO: loaded from: classes.dex */
public interface com4 {
}
