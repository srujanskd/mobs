package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import java.util.Arrays;
import p023Com1.lpt3;
import p025Com3.v;
import p025Com3.w;
import p025Com3.z;

/* JADX INFO: loaded from: classes.dex */
public final class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com1 f8197a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.emoji2.text.con.com5 f2362a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.emoji2.text.con.prn f2363a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f2364a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2365a;

    public static final class aux {
        public static int a(CharSequence charSequence, int i2, int i3) {
            int length = charSequence.length();
            if (i2 < 0 || length < i2 || i3 < 0) {
                return -1;
            }
            while (true) {
                boolean z2 = false;
                while (i3 != 0) {
                    i2--;
                    if (i2 < 0) {
                        return z2 ? -1 : 0;
                    }
                    char cCharAt = charSequence.charAt(i2);
                    if (z2) {
                        if (!Character.isHighSurrogate(cCharAt)) {
                            return -1;
                        }
                        i3--;
                    } else if (!Character.isSurrogate(cCharAt)) {
                        i3--;
                    } else {
                        if (Character.isHighSurrogate(cCharAt)) {
                            return -1;
                        }
                        z2 = true;
                    }
                }
                return i2;
            }
        }

        public static int b(CharSequence charSequence, int i2, int i3) {
            int length = charSequence.length();
            if (i2 < 0 || length < i2 || i3 < 0) {
                return -1;
            }
            while (true) {
                boolean z2 = false;
                while (i3 != 0) {
                    if (i2 >= length) {
                        if (z2) {
                            return -1;
                        }
                        return length;
                    }
                    char cCharAt = charSequence.charAt(i2);
                    if (z2) {
                        if (!Character.isLowSurrogate(cCharAt)) {
                            return -1;
                        }
                        i3--;
                        i2++;
                    } else if (!Character.isSurrogate(cCharAt)) {
                        i3--;
                        i2++;
                    } else {
                        if (Character.isLowSurrogate(cCharAt)) {
                            return -1;
                        }
                        i2++;
                        z2 = true;
                    }
                }
                return i2;
            }
        }
    }

    public static class con implements androidx.emoji2.text.con.prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final ThreadLocal<StringBuilder> f8198a = new ThreadLocal<>();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final TextPaint f2366a;

        public con() {
            TextPaint textPaint = new TextPaint();
            this.f2366a = textPaint;
            textPaint.setTextSize(10.0f);
        }

        public static StringBuilder b() {
            ThreadLocal<StringBuilder> threadLocal = f8198a;
            if (threadLocal.get() == null) {
                threadLocal.set(new StringBuilder());
            }
            return threadLocal.get();
        }

        @Override // androidx.emoji2.text.con.prn
        public boolean a(CharSequence charSequence, int i2, int i3, int i4) {
            StringBuilder sbB = b();
            sbB.setLength(0);
            while (i2 < i3) {
                sbB.append(charSequence.charAt(i2));
                i2++;
            }
            return lpt3.a(this.f2366a, sbB.toString());
        }
    }

    /* JADX INFO: renamed from: androidx.emoji2.text.nul$nul, reason: collision with other inner class name */
    public static final class C0034nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8199a = 1;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com1.aux f2367a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final boolean f2368a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final int[] f2369a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8200b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public com1.aux f2370b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8201c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public com1.aux f2371c;

        public C0034nul(com1.aux auxVar, boolean z2, int[] iArr) {
            this.f2367a = auxVar;
            this.f2370b = auxVar;
            this.f2368a = z2;
            this.f2369a = iArr;
        }

        public static boolean d(int i2) {
            return i2 == 65039;
        }

        public static boolean f(int i2) {
            return i2 == 65038;
        }

        public int a(int i2) {
            com1.aux auxVarA = this.f2370b.a(i2);
            int iG = 2;
            if (this.f8199a != 2) {
                if (auxVarA == null) {
                    iG = g();
                } else {
                    this.f8199a = 2;
                    this.f2370b = auxVarA;
                    this.f8201c = 1;
                }
            } else if (auxVarA != null) {
                this.f2370b = auxVarA;
                this.f8201c++;
            } else if (f(i2)) {
                iG = g();
            } else if (!d(i2)) {
                if (this.f2370b.b() != null) {
                    iG = 3;
                    if (this.f8201c != 1 || h()) {
                        this.f2371c = this.f2370b;
                        g();
                    } else {
                        iG = g();
                    }
                } else {
                    iG = g();
                }
            }
            this.f8200b = i2;
            return iG;
        }

        public v b() {
            return this.f2370b.b();
        }

        public v c() {
            return this.f2371c.b();
        }

        public boolean e() {
            return this.f8199a == 2 && this.f2370b.b() != null && (this.f8201c > 1 || h());
        }

        public final int g() {
            this.f8199a = 1;
            this.f2370b = this.f2367a;
            this.f8201c = 0;
            return 1;
        }

        public final boolean h() {
            if (this.f2370b.b().j() || d(this.f8200b)) {
                return true;
            }
            if (this.f2368a) {
                if (this.f2369a == null) {
                    return true;
                }
                if (Arrays.binarySearch(this.f2369a, this.f2370b.b().b(0)) < 0) {
                    return true;
                }
            }
            return false;
        }
    }

    public nul(com1 com1Var, androidx.emoji2.text.con.com5 com5Var, androidx.emoji2.text.con.prn prnVar, boolean z2, int[] iArr) {
        this.f2362a = com5Var;
        this.f8197a = com1Var;
        this.f2363a = prnVar;
        this.f2364a = z2;
        this.f2365a = iArr;
    }

    public static boolean b(Editable editable, KeyEvent keyEvent, boolean z2) {
        w[] wVarArr;
        if (g(keyEvent)) {
            return false;
        }
        int selectionStart = Selection.getSelectionStart(editable);
        int selectionEnd = Selection.getSelectionEnd(editable);
        if (!f(selectionStart, selectionEnd) && (wVarArr = (w[]) editable.getSpans(selectionStart, selectionEnd, w.class)) != null && wVarArr.length > 0) {
            for (w wVar : wVarArr) {
                int spanStart = editable.getSpanStart(wVar);
                int spanEnd = editable.getSpanEnd(wVar);
                if ((z2 && spanStart == selectionStart) || ((!z2 && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                    editable.delete(spanStart, spanEnd);
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean c(InputConnection inputConnection, Editable editable, int i2, int i3, boolean z2) {
        int iMax;
        int iMin;
        if (editable != null && inputConnection != null && i2 >= 0 && i3 >= 0) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (f(selectionStart, selectionEnd)) {
                return false;
            }
            if (z2) {
                iMax = aux.a(editable, selectionStart, Math.max(i2, 0));
                iMin = aux.b(editable, selectionEnd, Math.max(i3, 0));
                if (iMax == -1 || iMin == -1) {
                    return false;
                }
            } else {
                iMax = Math.max(selectionStart - i2, 0);
                iMin = Math.min(selectionEnd + i3, editable.length());
            }
            w[] wVarArr = (w[]) editable.getSpans(iMax, iMin, w.class);
            if (wVarArr != null && wVarArr.length > 0) {
                for (w wVar : wVarArr) {
                    int spanStart = editable.getSpanStart(wVar);
                    int spanEnd = editable.getSpanEnd(wVar);
                    iMax = Math.min(spanStart, iMax);
                    iMin = Math.max(spanEnd, iMin);
                }
                int iMax2 = Math.max(iMax, 0);
                int iMin2 = Math.min(iMin, editable.length());
                inputConnection.beginBatchEdit();
                editable.delete(iMax2, iMin2);
                inputConnection.endBatchEdit();
                return true;
            }
        }
        return false;
    }

    public static boolean d(Editable editable, int i2, KeyEvent keyEvent) {
        boolean zB;
        if (i2 != 67) {
            zB = i2 != 112 ? false : b(editable, keyEvent, true);
        } else {
            zB = b(editable, keyEvent, false);
        }
        if (!zB) {
            return false;
        }
        MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
        return true;
    }

    public static boolean f(int i2, int i3) {
        return i2 == -1 || i3 == -1 || i2 != i3;
    }

    public static boolean g(KeyEvent keyEvent) {
        return !KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState());
    }

    public final void a(Spannable spannable, v vVar, int i2, int i3) {
        spannable.setSpan(this.f2362a.a(vVar), i2, i3, 33);
    }

    public final boolean e(CharSequence charSequence, int i2, int i3, v vVar) {
        if (vVar.d() == 0) {
            vVar.k(this.f2363a.a(charSequence, i2, i3, vVar.h()));
        }
        return vVar.d() == 2;
    }

    public CharSequence h(CharSequence charSequence, int i2, int i3, int i4, boolean z2) {
        Spannable spannableString;
        int iCharCount;
        w[] wVarArr;
        boolean z3 = charSequence instanceof z;
        if (z3) {
            ((z) charSequence).a();
        }
        if (!z3) {
            try {
                spannableString = charSequence instanceof Spannable ? (Spannable) charSequence : (!(charSequence instanceof Spanned) || ((Spanned) charSequence).nextSpanTransition(i2 + (-1), i3 + 1, w.class) > i3) ? null : new SpannableString(charSequence);
            } finally {
                if (z3) {
                    ((z) charSequence).d();
                }
            }
        }
        if (spannableString != null && (wVarArr = (w[]) spannableString.getSpans(i2, i3, w.class)) != null && wVarArr.length > 0) {
            for (w wVar : wVarArr) {
                int spanStart = spannableString.getSpanStart(wVar);
                int spanEnd = spannableString.getSpanEnd(wVar);
                if (spanStart != i3) {
                    spannableString.removeSpan(wVar);
                }
                i2 = Math.min(spanStart, i2);
                i3 = Math.max(spanEnd, i3);
            }
        }
        if (i2 != i3 && i2 < charSequence.length()) {
            if (i4 != Integer.MAX_VALUE && spannableString != null) {
                i4 -= ((w[]) spannableString.getSpans(0, spannableString.length(), w.class)).length;
            }
            C0034nul c0034nul = new C0034nul(this.f8197a.f(), this.f2364a, this.f2365a);
            int iCodePointAt = Character.codePointAt(charSequence, i2);
            int i5 = 0;
            Spannable spannableString2 = spannableString;
            loop1: while (true) {
                iCharCount = i2;
                while (true) {
                    if (i2 >= i3 || i5 >= i4) {
                        break loop1;
                    }
                    int iA = c0034nul.a(iCodePointAt);
                    if (iA == 1) {
                        iCharCount += Character.charCount(Character.codePointAt(charSequence, iCharCount));
                        if (iCharCount < i3) {
                            iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                        }
                        i2 = iCharCount;
                    } else if (iA == 2) {
                        i2 += Character.charCount(iCodePointAt);
                        if (i2 < i3) {
                            iCodePointAt = Character.codePointAt(charSequence, i2);
                        }
                    } else if (iA != 3) {
                    }
                }
                if (z2 || !e(charSequence, iCharCount, i2, c0034nul.c())) {
                    if (spannableString2 == null) {
                        spannableString2 = new SpannableString(charSequence);
                    }
                    a(spannableString2, c0034nul.c(), iCharCount, i2);
                    i5++;
                }
            }
            CharSequence charSequence2 = spannableString2;
            charSequence2 = spannableString2;
            if (c0034nul.e() && i5 < i4 && (z2 || !e(charSequence, iCharCount, i2, c0034nul.b()))) {
                if (spannableString2 == null) {
                    spannableString2 = new SpannableString(charSequence);
                }
                a(spannableString2, c0034nul.b(), iCharCount, i2);
                charSequence2 = spannableString2;
            }
            if (charSequence2 == null) {
                charSequence2 = charSequence;
            }
            return charSequence2;
        }
        return charSequence;
    }
}
