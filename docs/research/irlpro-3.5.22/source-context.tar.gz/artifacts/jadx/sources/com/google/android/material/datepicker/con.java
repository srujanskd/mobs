package com.google.android.material.datepicker;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public class con implements com.google.android.material.datepicker.aux.nul {
    public static final Parcelable.Creator<con> CREATOR = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f9471a;

    public class aux implements Parcelable.Creator<con> {
        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public con createFromParcel(Parcel parcel) {
            return new con(parcel.readLong(), null);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public con[] newArray(int i2) {
            return new con[i2];
        }
    }

    public /* synthetic */ con(long j2, aux auxVar) {
        this(j2);
    }

    public static con k(long j2) {
        return new con(j2);
    }

    @Override // com.google.android.material.datepicker.aux.nul
    public boolean d(long j2) {
        return j2 >= this.f9471a;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof con) && this.f9471a == ((con) obj).f9471a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Long.valueOf(this.f9471a)});
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeLong(this.f9471a);
    }

    public con(long j2) {
        this.f9471a = j2;
    }
}
