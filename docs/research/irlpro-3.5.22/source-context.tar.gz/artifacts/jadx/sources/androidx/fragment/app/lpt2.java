package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class lpt2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public com8 f8296a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<Fragment> f2505a = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final HashMap<String, lpt1> f2506a = new HashMap<>();

    public void a(Fragment fragment) {
        if (this.f2505a.contains(fragment)) {
            throw new IllegalStateException("Fragment already added: " + fragment);
        }
        synchronized (this.f2505a) {
            this.f2505a.add(fragment);
        }
        fragment.mAdded = true;
    }

    public void b() {
        this.f2506a.values().removeAll(Collections.singleton(null));
    }

    public boolean c(String str) {
        return this.f2506a.get(str) != null;
    }

    public void d(int i2) {
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null) {
                lpt1Var.t(i2);
            }
        }
    }

    public void e(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String str2 = str + "    ";
        if (!this.f2506a.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (lpt1 lpt1Var : this.f2506a.values()) {
                printWriter.print(str);
                if (lpt1Var != null) {
                    Fragment fragmentK = lpt1Var.k();
                    printWriter.println(fragmentK);
                    fragmentK.dump(str2, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        int size = this.f2505a.size();
        if (size > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i2 = 0; i2 < size; i2++) {
                Fragment fragment = this.f2505a.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment.toString());
            }
        }
    }

    public Fragment f(String str) {
        lpt1 lpt1Var = this.f2506a.get(str);
        if (lpt1Var != null) {
            return lpt1Var.k();
        }
        return null;
    }

    public Fragment g(int i2) {
        for (int size = this.f2505a.size() - 1; size >= 0; size--) {
            Fragment fragment = this.f2505a.get(size);
            if (fragment != null && fragment.mFragmentId == i2) {
                return fragment;
            }
        }
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null) {
                Fragment fragmentK = lpt1Var.k();
                if (fragmentK.mFragmentId == i2) {
                    return fragmentK;
                }
            }
        }
        return null;
    }

    public Fragment h(String str) {
        if (str != null) {
            for (int size = this.f2505a.size() - 1; size >= 0; size--) {
                Fragment fragment = this.f2505a.get(size);
                if (fragment != null && str.equals(fragment.mTag)) {
                    return fragment;
                }
            }
        }
        if (str == null) {
            return null;
        }
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null) {
                Fragment fragmentK = lpt1Var.k();
                if (str.equals(fragmentK.mTag)) {
                    return fragmentK;
                }
            }
        }
        return null;
    }

    public Fragment i(String str) {
        Fragment fragmentFindFragmentByWho;
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null && (fragmentFindFragmentByWho = lpt1Var.k().findFragmentByWho(str)) != null) {
                return fragmentFindFragmentByWho;
            }
        }
        return null;
    }

    public int j(Fragment fragment) {
        View view;
        View view2;
        ViewGroup viewGroup = fragment.mContainer;
        if (viewGroup == null) {
            return -1;
        }
        int iIndexOf = this.f2505a.indexOf(fragment);
        for (int i2 = iIndexOf - 1; i2 >= 0; i2--) {
            Fragment fragment2 = this.f2505a.get(i2);
            if (fragment2.mContainer == viewGroup && (view2 = fragment2.mView) != null) {
                return viewGroup.indexOfChild(view2) + 1;
            }
        }
        while (true) {
            iIndexOf++;
            if (iIndexOf >= this.f2505a.size()) {
                return -1;
            }
            Fragment fragment3 = this.f2505a.get(iIndexOf);
            if (fragment3.mContainer == viewGroup && (view = fragment3.mView) != null) {
                return viewGroup.indexOfChild(view);
            }
        }
    }

    public List<lpt1> k() {
        ArrayList arrayList = new ArrayList();
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null) {
                arrayList.add(lpt1Var);
            }
        }
        return arrayList;
    }

    public List<Fragment> l() {
        ArrayList arrayList = new ArrayList();
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null) {
                arrayList.add(lpt1Var.k());
            } else {
                arrayList.add(null);
            }
        }
        return arrayList;
    }

    public lpt1 m(String str) {
        return this.f2506a.get(str);
    }

    public List<Fragment> n() {
        ArrayList arrayList;
        if (this.f2505a.isEmpty()) {
            return Collections.emptyList();
        }
        synchronized (this.f2505a) {
            arrayList = new ArrayList(this.f2505a);
        }
        return arrayList;
    }

    public com8 o() {
        return this.f8296a;
    }

    public void p(lpt1 lpt1Var) {
        Fragment fragmentK = lpt1Var.k();
        if (c(fragmentK.mWho)) {
            return;
        }
        this.f2506a.put(fragmentK.mWho, lpt1Var);
        if (fragmentK.mRetainInstanceChangedWhileDetached) {
            if (fragmentK.mRetainInstance) {
                this.f8296a.f(fragmentK);
            } else {
                this.f8296a.n(fragmentK);
            }
            fragmentK.mRetainInstanceChangedWhileDetached = false;
        }
        if (com6.H0(2)) {
            Log.v("FragmentManager", "Added fragment to active set " + fragmentK);
        }
    }

    public void q(lpt1 lpt1Var) {
        Fragment fragmentK = lpt1Var.k();
        if (fragmentK.mRetainInstance) {
            this.f8296a.n(fragmentK);
        }
        if (this.f2506a.put(fragmentK.mWho, null) != null && com6.H0(2)) {
            Log.v("FragmentManager", "Removed fragment from active set " + fragmentK);
        }
    }

    public void r() {
        Iterator<Fragment> it = this.f2505a.iterator();
        while (it.hasNext()) {
            lpt1 lpt1Var = this.f2506a.get(it.next().mWho);
            if (lpt1Var != null) {
                lpt1Var.m();
            }
        }
        for (lpt1 lpt1Var2 : this.f2506a.values()) {
            if (lpt1Var2 != null) {
                lpt1Var2.m();
                Fragment fragmentK = lpt1Var2.k();
                if (fragmentK.mRemoving && !fragmentK.isInBackStack()) {
                    q(lpt1Var2);
                }
            }
        }
    }

    public void s(Fragment fragment) {
        synchronized (this.f2505a) {
            this.f2505a.remove(fragment);
        }
        fragment.mAdded = false;
    }

    public void t() {
        this.f2506a.clear();
    }

    public void u(List<String> list) {
        this.f2505a.clear();
        if (list != null) {
            for (String str : list) {
                Fragment fragmentF = f(str);
                if (fragmentF == null) {
                    throw new IllegalStateException("No instantiated fragment for (" + str + ")");
                }
                if (com6.H0(2)) {
                    Log.v("FragmentManager", "restoreSaveState: added (" + str + "): " + fragmentF);
                }
                a(fragmentF);
            }
        }
    }

    public ArrayList<com9> v() {
        ArrayList<com9> arrayList = new ArrayList<>(this.f2506a.size());
        for (lpt1 lpt1Var : this.f2506a.values()) {
            if (lpt1Var != null) {
                Fragment fragmentK = lpt1Var.k();
                com9 com9VarR = lpt1Var.r();
                arrayList.add(com9VarR);
                if (com6.H0(2)) {
                    Log.v("FragmentManager", "Saved state of " + fragmentK + ": " + com9VarR.f2485b);
                }
            }
        }
        return arrayList;
    }

    public ArrayList<String> w() {
        synchronized (this.f2505a) {
            if (this.f2505a.isEmpty()) {
                return null;
            }
            ArrayList<String> arrayList = new ArrayList<>(this.f2505a.size());
            for (Fragment fragment : this.f2505a) {
                arrayList.add(fragment.mWho);
                if (com6.H0(2)) {
                    Log.v("FragmentManager", "saveAllState: adding fragment (" + fragment.mWho + "): " + fragment);
                }
            }
            return arrayList;
        }
    }

    public void x(com8 com8Var) {
        this.f8296a = com8Var;
    }
}
