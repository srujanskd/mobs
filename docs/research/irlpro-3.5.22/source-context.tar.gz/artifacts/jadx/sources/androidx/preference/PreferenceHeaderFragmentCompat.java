package androidx.preference;

import COM3.com7;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.OnBackPressedDispatcher;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.com2;
import androidx.fragment.app.com6;
import androidx.fragment.app.lpt3;
import androidx.preference.PreferenceHeaderFragmentCompat;
import f.com8;
import p002Aux.lpt5;
import p002Aux.lpt6;
import p016CoM4.com9;
import p016CoM4.lpt2;
import p024Com2.y;
import p104com5.i0;

/* JADX INFO: loaded from: classes.dex */
public abstract class PreferenceHeaderFragmentCompat extends Fragment implements PreferenceFragmentCompat.com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public lpt5 f8462a;

    public static final class aux extends lpt5 implements i0.com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final PreferenceHeaderFragmentCompat f8463a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public aux(PreferenceHeaderFragmentCompat preferenceHeaderFragmentCompat) {
            super(true);
            com8.e(preferenceHeaderFragmentCompat, "caller");
            this.f8463a = preferenceHeaderFragmentCompat;
            preferenceHeaderFragmentCompat.m().a(this);
        }

        @Override // com5.i0.com2
        public void a(View view) {
            com8.e(view, "panel");
            i(true);
        }

        @Override // com5.i0.com2
        public void b(View view) {
            com8.e(view, "panel");
            i(false);
        }

        @Override // com5.i0.com2
        public void c(View view, float f2) {
            com8.e(view, "panel");
        }

        @Override // p002Aux.lpt5
        public void e() {
            this.f8463a.m().b();
        }
    }

    public static final class con implements View.OnLayoutChangeListener {
        public con() {
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
            com8.f(view, "view");
            view.removeOnLayoutChangeListener(this);
            lpt5 lpt5Var = PreferenceHeaderFragmentCompat.this.f8462a;
            com8.b(lpt5Var);
            lpt5Var.i(PreferenceHeaderFragmentCompat.this.m().n() && PreferenceHeaderFragmentCompat.this.m().m());
        }
    }

    public static final void p(PreferenceHeaderFragmentCompat preferenceHeaderFragmentCompat) {
        com8.e(preferenceHeaderFragmentCompat, "this$0");
        lpt5 lpt5Var = preferenceHeaderFragmentCompat.f8462a;
        com8.b(lpt5Var);
        lpt5Var.i(preferenceHeaderFragmentCompat.getChildFragmentManager().o0() == 0);
    }

    @Override // androidx.preference.PreferenceFragmentCompat.com1
    public boolean f(PreferenceFragmentCompat preferenceFragmentCompat, Preference preference) {
        com8.e(preferenceFragmentCompat, "caller");
        com8.e(preference, "pref");
        if (preferenceFragmentCompat.getId() == lpt2.f6184c) {
            r(preference);
            return true;
        }
        int id = preferenceFragmentCompat.getId();
        int i2 = lpt2.f6183b;
        if (id != i2) {
            return false;
        }
        com2 com2VarS0 = getChildFragmentManager().s0();
        ClassLoader classLoader = requireContext().getClassLoader();
        String fragment = preference.getFragment();
        com8.b(fragment);
        Fragment fragmentA = com2VarS0.a(classLoader, fragment);
        com8.d(fragmentA, "childFragmentManager.fra….fragment!!\n            )");
        fragmentA.setArguments(preference.getExtras());
        com6 childFragmentManager = getChildFragmentManager();
        com8.d(childFragmentManager, "childFragmentManager");
        lpt3 lpt3VarN = childFragmentManager.n();
        com8.d(lpt3VarN, "beginTransaction()");
        lpt3VarN.t(true);
        lpt3VarN.q(i2, fragmentA);
        lpt3VarN.u(4099);
        lpt3VarN.g(null);
        lpt3VarN.i();
        return true;
    }

    public final i0 l(LayoutInflater layoutInflater) {
        i0 i0Var = new i0(layoutInflater.getContext());
        i0Var.setId(lpt2.f6185d);
        FragmentContainerView fragmentContainerView = new FragmentContainerView(layoutInflater.getContext());
        fragmentContainerView.setId(lpt2.f6184c);
        i0.com1 com1Var = new i0.com1(getResources().getDimensionPixelSize(com9.f6180b), -1);
        com1Var.f4128a = getResources().getInteger(p016CoM4.lpt3.f6192b);
        i0Var.addView(fragmentContainerView, com1Var);
        FragmentContainerView fragmentContainerView2 = new FragmentContainerView(layoutInflater.getContext());
        fragmentContainerView2.setId(lpt2.f6183b);
        i0.com1 com1Var2 = new i0.com1(getResources().getDimensionPixelSize(com9.f6179a), -1);
        com1Var2.f4128a = getResources().getInteger(p016CoM4.lpt3.f6191a);
        i0Var.addView(fragmentContainerView2, com1Var2);
        return i0Var;
    }

    public final i0 m() {
        return (i0) requireView();
    }

    public Fragment n() {
        Fragment fragmentI0 = getChildFragmentManager().i0(lpt2.f6184c);
        if (fragmentI0 == null) {
            throw new NullPointerException("null cannot be cast to non-null type androidx.preference.PreferenceFragmentCompat");
        }
        PreferenceFragmentCompat preferenceFragmentCompat = (PreferenceFragmentCompat) fragmentI0;
        if (preferenceFragmentCompat.o().g() <= 0) {
            return null;
        }
        int iG = preferenceFragmentCompat.o().g();
        int i2 = 0;
        while (i2 < iG) {
            int i3 = i2 + 1;
            Preference preferenceF = preferenceFragmentCompat.o().f(i2);
            com8.d(preferenceF, "headerFragment.preferenc…reen.getPreference(index)");
            if (preferenceF.getFragment() != null) {
                String fragment = preferenceF.getFragment();
                if (fragment == null) {
                    return null;
                }
                return getChildFragmentManager().s0().a(requireContext().getClassLoader(), fragment);
            }
            i2 = i3;
        }
        return null;
    }

    public abstract PreferenceFragmentCompat o();

    @Override // androidx.fragment.app.Fragment
    public void onAttach(Context context) {
        com8.e(context, "context");
        super.onAttach(context);
        com6 parentFragmentManager = getParentFragmentManager();
        com8.d(parentFragmentManager, "parentFragmentManager");
        lpt3 lpt3VarN = parentFragmentManager.n();
        com8.d(lpt3VarN, "beginTransaction()");
        lpt3VarN.s(this);
        lpt3VarN.i();
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        com8.e(layoutInflater, "inflater");
        i0 i0VarL = l(layoutInflater);
        com6 childFragmentManager = getChildFragmentManager();
        int i2 = lpt2.f6184c;
        if (childFragmentManager.i0(i2) == null) {
            PreferenceFragmentCompat preferenceFragmentCompatO = o();
            com6 childFragmentManager2 = getChildFragmentManager();
            com8.d(childFragmentManager2, "childFragmentManager");
            lpt3 lpt3VarN = childFragmentManager2.n();
            com8.d(lpt3VarN, "beginTransaction()");
            lpt3VarN.t(true);
            lpt3VarN.b(i2, preferenceFragmentCompatO);
            lpt3VarN.i();
        }
        i0VarL.setLockMode(3);
        return i0VarL;
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        com8.e(view, "view");
        super.onViewCreated(view, bundle);
        this.f8462a = new aux(this);
        i0 i0VarM = m();
        if (!y.S(i0VarM) || i0VarM.isLayoutRequested()) {
            i0VarM.addOnLayoutChangeListener(new con());
        } else {
            lpt5 lpt5Var = this.f8462a;
            com8.b(lpt5Var);
            lpt5Var.i(m().n() && m().m());
        }
        getChildFragmentManager().i(new com6.lpt1() { // from class: CoM4.com4
            @Override // androidx.fragment.app.com6.lpt1
            public final void onBackStackChanged() {
                PreferenceHeaderFragmentCompat.p(this.f6159a);
            }
        });
        Object objRequireContext = requireContext();
        lpt6 lpt6Var = objRequireContext instanceof lpt6 ? (lpt6) objRequireContext : null;
        if (lpt6Var == null) {
            return;
        }
        OnBackPressedDispatcher onBackPressedDispatcherG = lpt6Var.G();
        com7 viewLifecycleOwner = getViewLifecycleOwner();
        lpt5 lpt5Var2 = this.f8462a;
        com8.b(lpt5Var2);
        onBackPressedDispatcherG.a(viewLifecycleOwner, lpt5Var2);
    }

    @Override // androidx.fragment.app.Fragment
    public void onViewStateRestored(Bundle bundle) {
        Fragment fragmentN;
        super.onViewStateRestored(bundle);
        if (bundle != null || (fragmentN = n()) == null) {
            return;
        }
        com6 childFragmentManager = getChildFragmentManager();
        com8.d(childFragmentManager, "childFragmentManager");
        lpt3 lpt3VarN = childFragmentManager.n();
        com8.d(lpt3VarN, "beginTransaction()");
        lpt3VarN.t(true);
        lpt3VarN.q(lpt2.f6183b, fragmentN);
        lpt3VarN.i();
    }

    public final void q(Intent intent) {
        if (intent == null) {
            return;
        }
        startActivity(intent);
    }

    public final void r(Preference preference) {
        if (preference.getFragment() == null) {
            q(preference.getIntent());
            return;
        }
        String fragment = preference.getFragment();
        Fragment fragmentA = fragment == null ? null : getChildFragmentManager().s0().a(requireContext().getClassLoader(), fragment);
        if (fragmentA != null) {
            fragmentA.setArguments(preference.getExtras());
        }
        if (getChildFragmentManager().o0() > 0) {
            com6.com7 com7VarN0 = getChildFragmentManager().n0(0);
            com8.d(com7VarN0, "childFragmentManager.getBackStackEntryAt(0)");
            getChildFragmentManager().Z0(com7VarN0.getId(), 1);
        }
        com6 childFragmentManager = getChildFragmentManager();
        com8.d(childFragmentManager, "childFragmentManager");
        lpt3 lpt3VarN = childFragmentManager.n();
        com8.d(lpt3VarN, "beginTransaction()");
        lpt3VarN.t(true);
        int i2 = lpt2.f6183b;
        com8.b(fragmentA);
        lpt3VarN.q(i2, fragmentA);
        if (m().m()) {
            lpt3VarN.u(4099);
        }
        m().q();
        lpt3VarN.i();
    }
}
