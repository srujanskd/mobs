package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import p024Com2.v;
import p092coM3.k0;
import p092coM3.l0;

/* JADX INFO: loaded from: classes.dex */
public class com1 {

    public class aux implements CoM1.com7.con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Fragment f8236a;

        public aux(Fragment fragment) {
            this.f8236a = fragment;
        }

        @Override // CoM1.com7.con
        public void onCancel() {
            if (this.f8236a.getAnimatingAway() != null) {
                View animatingAway = this.f8236a.getAnimatingAway();
                this.f8236a.setAnimatingAway(null);
                animatingAway.clearAnimation();
            }
            this.f8236a.setAnimator(null);
        }
    }

    public class con implements Animation.AnimationListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p013CoM1.com7 f8241a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewGroup f2420a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2421a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ lpt4.com3 f2422a;

        public class aux implements Runnable {
            public aux() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (con.this.f2421a.getAnimatingAway() != null) {
                    con.this.f2421a.setAnimatingAway(null);
                    con conVar = con.this;
                    conVar.f2422a.b(conVar.f2421a, conVar.f8241a);
                }
            }
        }

        public con(ViewGroup viewGroup, Fragment fragment, lpt4.com3 com3Var, p013CoM1.com7 com7Var) {
            this.f2420a = viewGroup;
            this.f2421a = fragment;
            this.f2422a = com3Var;
            this.f8241a = com7Var;
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationEnd(Animation animation) {
            this.f2420a.post(new aux());
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationRepeat(Animation animation) {
        }

        @Override // android.view.animation.Animation.AnimationListener
        public void onAnimationStart(Animation animation) {
        }
    }

    public class nul extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p013CoM1.com7 f8243a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f2423a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewGroup f2424a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2425a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ lpt4.com3 f2426a;

        public nul(ViewGroup viewGroup, View view, Fragment fragment, lpt4.com3 com3Var, p013CoM1.com7 com7Var) {
            this.f2424a = viewGroup;
            this.f2423a = view;
            this.f2425a = fragment;
            this.f2426a = com3Var;
            this.f8243a = com7Var;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2424a.endViewTransition(this.f2423a);
            Animator animator2 = this.f2425a.getAnimator();
            this.f2425a.setAnimator(null);
            if (animator2 == null || this.f2424a.indexOfChild(this.f2423a) >= 0) {
                return;
            }
            this.f2426a.b(this.f2425a, this.f8243a);
        }
    }

    public static void a(Fragment fragment, prn prnVar, lpt4.com3 com3Var) {
        View view = fragment.mView;
        ViewGroup viewGroup = fragment.mContainer;
        viewGroup.startViewTransition(view);
        p013CoM1.com7 com7Var = new p013CoM1.com7();
        com7Var.c(new aux(fragment));
        com3Var.a(fragment, com7Var);
        if (prnVar.f2427a != null) {
            RunnableC0035com1 runnableC0035com1 = new RunnableC0035com1(prnVar.f2427a, viewGroup, view);
            fragment.setAnimatingAway(fragment.mView);
            runnableC0035com1.setAnimationListener(new con(viewGroup, fragment, com3Var, com7Var));
            fragment.mView.startAnimation(runnableC0035com1);
            return;
        }
        Animator animator = prnVar.f8244a;
        fragment.setAnimator(animator);
        animator.addListener(new nul(viewGroup, view, fragment, com3Var, com7Var));
        animator.setTarget(fragment.mView);
        animator.start();
    }

    public static int b(Fragment fragment, boolean z2, boolean z3) {
        if (z3) {
            return z2 ? fragment.getPopEnterAnim() : fragment.getPopExitAnim();
        }
        return z2 ? fragment.getEnterAnim() : fragment.getExitAnim();
    }

    public static prn c(Context context, Fragment fragment, boolean z2, boolean z3) {
        int nextTransition = fragment.getNextTransition();
        int iB = b(fragment, z2, z3);
        boolean z4 = false;
        fragment.setAnimations(0, 0, 0, 0);
        ViewGroup viewGroup = fragment.mContainer;
        if (viewGroup != null) {
            int i2 = l0.f9201c;
            if (viewGroup.getTag(i2) != null) {
                fragment.mContainer.setTag(i2, null);
            }
        }
        ViewGroup viewGroup2 = fragment.mContainer;
        if (viewGroup2 != null && viewGroup2.getLayoutTransition() != null) {
            return null;
        }
        Animation animationOnCreateAnimation = fragment.onCreateAnimation(nextTransition, z2, iB);
        if (animationOnCreateAnimation != null) {
            return new prn(animationOnCreateAnimation);
        }
        Animator animatorOnCreateAnimator = fragment.onCreateAnimator(nextTransition, z2, iB);
        if (animatorOnCreateAnimator != null) {
            return new prn(animatorOnCreateAnimator);
        }
        if (iB == 0 && nextTransition != 0) {
            iB = d(nextTransition, z2);
        }
        if (iB != 0) {
            boolean zEquals = "anim".equals(context.getResources().getResourceTypeName(iB));
            if (zEquals) {
                try {
                    Animation animationLoadAnimation = AnimationUtils.loadAnimation(context, iB);
                    if (animationLoadAnimation != null) {
                        return new prn(animationLoadAnimation);
                    }
                    z4 = true;
                } catch (Resources.NotFoundException e2) {
                    throw e2;
                } catch (RuntimeException unused) {
                }
            }
            if (!z4) {
                try {
                    Animator animatorLoadAnimator = AnimatorInflater.loadAnimator(context, iB);
                    if (animatorLoadAnimator != null) {
                        return new prn(animatorLoadAnimator);
                    }
                } catch (RuntimeException e3) {
                    if (zEquals) {
                        throw e3;
                    }
                    Animation animationLoadAnimation2 = AnimationUtils.loadAnimation(context, iB);
                    if (animationLoadAnimation2 != null) {
                        return new prn(animationLoadAnimation2);
                    }
                }
            }
        }
        return null;
    }

    public static int d(int i2, boolean z2) {
        if (i2 == 4097) {
            return z2 ? k0.f9197e : k0.f9198f;
        }
        if (i2 == 4099) {
            return z2 ? k0.f9195c : k0.f9196d;
        }
        if (i2 != 8194) {
            return -1;
        }
        return z2 ? k0.f9193a : k0.f9194b;
    }

    public static class prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Animator f8244a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Animation f2427a;

        public prn(Animation animation) {
            this.f2427a = animation;
            this.f8244a = null;
            if (animation == null) {
                throw new IllegalStateException("Animation cannot be null");
            }
        }

        public prn(Animator animator) {
            this.f2427a = null;
            this.f8244a = animator;
            if (animator == null) {
                throw new IllegalStateException("Animator cannot be null");
            }
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.com1$com1, reason: collision with other inner class name */
    public static class RunnableC0035com1 extends AnimationSet implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final View f8237a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final ViewGroup f2419a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8238b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8239c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f8240d;

        public RunnableC0035com1(Animation animation, ViewGroup viewGroup, View view) {
            super(false);
            this.f8240d = true;
            this.f2419a = viewGroup;
            this.f8237a = view;
            addAnimation(animation);
            viewGroup.post(this);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean getTransformation(long j2, Transformation transformation) {
            this.f8240d = true;
            if (this.f8238b) {
                return !this.f8239c;
            }
            if (!super.getTransformation(j2, transformation)) {
                this.f8238b = true;
                v.a(this.f2419a, this);
            }
            return true;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.f8238b || !this.f8240d) {
                this.f2419a.endViewTransition(this.f8237a);
                this.f8239c = true;
            } else {
                this.f8240d = false;
                this.f2419a.post(this);
            }
        }

        @Override // android.view.animation.Animation
        public boolean getTransformation(long j2, Transformation transformation, float f2) {
            this.f8240d = true;
            if (this.f8238b) {
                return !this.f8239c;
            }
            if (!super.getTransformation(j2, transformation, f2)) {
                this.f8238b = true;
                v.a(this.f2419a, this);
            }
            return true;
        }
    }
}
