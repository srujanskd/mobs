package com.google.android.material.appbar;

import COM9.com3;
import COM9.com4;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import p024Com2.y;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p108com9.t;
import p108com9.u;

/* JADX INFO: loaded from: classes.dex */
public class MaterialToolbar extends Toolbar {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ImageView.ScaleType f3305a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Boolean f3306a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Integer f3307a;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9281e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9282f;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final int f9280m = g4.f8980y;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ImageView.ScaleType[] f9279a = {ImageView.ScaleType.MATRIX, ImageView.ScaleType.FIT_XY, ImageView.ScaleType.FIT_START, ImageView.ScaleType.FIT_CENTER, ImageView.ScaleType.FIT_END, ImageView.ScaleType.CENTER, ImageView.ScaleType.CENTER_CROP, ImageView.ScaleType.CENTER_INSIDE};

    public MaterialToolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.O);
    }

    public final Pair<Integer, Integer> Q(TextView textView, TextView textView2) {
        int measuredWidth = getMeasuredWidth();
        int i2 = measuredWidth / 2;
        int paddingLeft = getPaddingLeft();
        int paddingRight = measuredWidth - getPaddingRight();
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() != 8 && childAt != textView && childAt != textView2) {
                if (childAt.getRight() < i2 && childAt.getRight() > paddingLeft) {
                    paddingLeft = childAt.getRight();
                }
                if (childAt.getLeft() > i2 && childAt.getLeft() < paddingRight) {
                    paddingRight = childAt.getLeft();
                }
            }
        }
        return new Pair<>(Integer.valueOf(paddingLeft), Integer.valueOf(paddingRight));
    }

    public final void R(Context context) {
        Drawable background = getBackground();
        if (background == null || (background instanceof ColorDrawable)) {
            com3 com3Var = new com3();
            com3Var.Y(ColorStateList.valueOf(background != null ? ((ColorDrawable) background).getColor() : 0));
            com3Var.N(context);
            com3Var.X(y.v(this));
            y.s0(this, com3Var);
        }
    }

    public final void S(View view, Pair<Integer, Integer> pair) {
        int measuredWidth = getMeasuredWidth();
        int measuredWidth2 = view.getMeasuredWidth();
        int i2 = (measuredWidth / 2) - (measuredWidth2 / 2);
        int i3 = measuredWidth2 + i2;
        int iMax = Math.max(Math.max(((Integer) pair.first).intValue() - i2, 0), Math.max(i3 - ((Integer) pair.second).intValue(), 0));
        if (iMax > 0) {
            i2 += iMax;
            i3 -= iMax;
            view.measure(View.MeasureSpec.makeMeasureSpec(i3 - i2, 1073741824), view.getMeasuredHeightAndState());
        }
        view.layout(i2, view.getTop(), i3, view.getBottom());
    }

    public final void T() {
        if (this.f9281e || this.f9282f) {
            TextView textViewE = u.e(this);
            TextView textViewC = u.c(this);
            if (textViewE == null && textViewC == null) {
                return;
            }
            Pair<Integer, Integer> pairQ = Q(textViewE, textViewC);
            if (this.f9281e && textViewE != null) {
                S(textViewE, pairQ);
            }
            if (!this.f9282f || textViewC == null) {
                return;
            }
            S(textViewC, pairQ);
        }
    }

    public final Drawable U(Drawable drawable) {
        if (drawable == null || this.f3307a == null) {
            return drawable;
        }
        Drawable drawableL = p080cOm1.y.l(drawable.mutate());
        p080cOm1.y.h(drawableL, this.f3307a.intValue());
        return drawableL;
    }

    public final void V() {
        ImageView imageViewB = u.b(this);
        if (imageViewB != null) {
            Boolean bool = this.f3306a;
            if (bool != null) {
                imageViewB.setAdjustViewBounds(bool.booleanValue());
            }
            ImageView.ScaleType scaleType = this.f3305a;
            if (scaleType != null) {
                imageViewB.setScaleType(scaleType);
            }
        }
    }

    public ImageView.ScaleType getLogoScaleType() {
        return this.f3305a;
    }

    public Integer getNavigationIconTint() {
        return this.f3307a;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        com4.e(this);
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        T();
        V();
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        com4.d(this, f2);
    }

    public void setLogoAdjustViewBounds(boolean z2) {
        Boolean bool = this.f3306a;
        if (bool == null || bool.booleanValue() != z2) {
            this.f3306a = Boolean.valueOf(z2);
            requestLayout();
        }
    }

    public void setLogoScaleType(ImageView.ScaleType scaleType) {
        if (this.f3305a != scaleType) {
            this.f3305a = scaleType;
            requestLayout();
        }
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationIcon(Drawable drawable) {
        super.setNavigationIcon(U(drawable));
    }

    public void setNavigationIconTint(int i2) {
        this.f3307a = Integer.valueOf(i2);
        Drawable navigationIcon = getNavigationIcon();
        if (navigationIcon != null) {
            setNavigationIcon(navigationIcon);
        }
    }

    public void setSubtitleCentered(boolean z2) {
        if (this.f9282f != z2) {
            this.f9282f = z2;
            requestLayout();
        }
    }

    public void setTitleCentered(boolean z2) {
        if (this.f9281e != z2) {
            this.f9281e = z2;
            requestLayout();
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public MaterialToolbar(Context context, AttributeSet attributeSet, int i2) {
        int i3 = f9280m;
        super(p128lpT1.u.c(context, attributeSet, i2, i3), attributeSet, i2);
        Context context2 = getContext();
        TypedArray typedArrayH = t.h(context2, attributeSet, h4.f3063E0, i2, i3, new int[0]);
        int i4 = h4.a2;
        if (typedArrayH.hasValue(i4)) {
            setNavigationIconTint(typedArrayH.getColor(i4, -1));
        }
        this.f9281e = typedArrayH.getBoolean(h4.c2, false);
        this.f9282f = typedArrayH.getBoolean(h4.b2, false);
        int i5 = typedArrayH.getInt(h4.Z1, -1);
        if (i5 >= 0) {
            ImageView.ScaleType[] scaleTypeArr = f9279a;
            if (i5 < scaleTypeArr.length) {
                this.f3305a = scaleTypeArr[i5];
            }
        }
        int i6 = h4.Y1;
        if (typedArrayH.hasValue(i6)) {
            this.f3306a = Boolean.valueOf(typedArrayH.getBoolean(i6, false));
        }
        typedArrayH.recycle();
        R(context2);
    }
}
