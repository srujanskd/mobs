package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;

/* JADX INFO: loaded from: classes.dex */
public final class com8 extends lpt1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f6625a = {1, 1, 1, 1};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f6626b = {3, 1, 1};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[][] f858a = {new int[]{1, 1, 3, 3, 1}, new int[]{3, 1, 1, 1, 3}, new int[]{1, 3, 1, 1, 3}, new int[]{3, 3, 1, 1, 1}, new int[]{1, 1, 3, 1, 3}, new int[]{3, 1, 3, 1, 1}, new int[]{1, 3, 3, 1, 1}, new int[]{1, 1, 1, 3, 3}, new int[]{3, 1, 1, 3, 1}, new int[]{1, 3, 1, 3, 1}};

    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int length = str.length();
        if (length % 2 != 0) {
            throw new IllegalArgumentException("The length of the input should be even");
        }
        if (length > 80) {
            throw new IllegalArgumentException("Requested contents should be less than 80 digits long, but got ".concat(String.valueOf(length)));
        }
        lpt1.c(str);
        boolean[] zArr = new boolean[(length * 9) + 9];
        int iB = lpt1.b(zArr, 0, f6625a, true);
        for (int i2 = 0; i2 < length; i2 += 2) {
            int iDigit = Character.digit(str.charAt(i2), 10);
            int iDigit2 = Character.digit(str.charAt(i2 + 1), 10);
            int[] iArr = new int[10];
            for (int i3 = 0; i3 < 5; i3++) {
                int i4 = i3 * 2;
                int[][] iArr2 = f858a;
                iArr[i4] = iArr2[iDigit][i3];
                iArr[i4 + 1] = iArr2[iDigit2][i3];
            }
            iB += lpt1.b(zArr, iB, iArr, true);
        }
        lpt1.b(zArr, iB, f6626b, true);
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.ITF);
    }
}
