package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Checkable;
import android.widget.CompoundButton;
import androidx.appcompat.widget.SwitchCompat;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt2;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class SwitchPreferenceCompat extends TwoStatePreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux f8480a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f8481c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f8482d;

    public class aux implements CompoundButton.OnCheckedChangeListener {
        public aux() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
            if (SwitchPreferenceCompat.this.callChangeListener(Boolean.valueOf(z2))) {
                SwitchPreferenceCompat.this.b(z2);
            } else {
                compoundButton.setChecked(!z2);
            }
        }
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f8480a = new aux();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f542o, i2, i3);
        e(l0.f(typedArrayObtainStyledAttributes, lpt7.S0, lpt7.L0));
        d(l0.f(typedArrayObtainStyledAttributes, lpt7.R0, lpt7.M0));
        i(l0.f(typedArrayObtainStyledAttributes, lpt7.U0, lpt7.O0));
        h(l0.f(typedArrayObtainStyledAttributes, lpt7.T0, lpt7.P0));
        c(l0.b(typedArrayObtainStyledAttributes, lpt7.Q0, lpt7.N0, false));
        typedArrayObtainStyledAttributes.recycle();
    }

    public void h(CharSequence charSequence) {
        this.f8482d = charSequence;
        notifyChanged();
    }

    public void i(CharSequence charSequence) {
        this.f8481c = charSequence;
        notifyChanged();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void j(View view) {
        boolean z2 = view instanceof SwitchCompat;
        if (z2) {
            ((SwitchCompat) view).setOnCheckedChangeListener(null);
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(((TwoStatePreference) this).f2666b);
        }
        if (z2) {
            SwitchCompat switchCompat = (SwitchCompat) view;
            switchCompat.setTextOn(this.f8481c);
            switchCompat.setTextOff(this.f8482d);
            switchCompat.setOnCheckedChangeListener(this.f8480a);
        }
    }

    public final void l(View view) {
        if (((AccessibilityManager) getContext().getSystemService("accessibility")).isEnabled()) {
            j(view.findViewById(lpt2.f6190i));
            g(view.findViewById(R.id.summary));
        }
    }

    @Override // androidx.preference.Preference
    public void onBindViewHolder(com7 com7Var) {
        super.onBindViewHolder(com7Var);
        j(com7Var.M(lpt2.f6190i));
        f(com7Var);
    }

    @Override // androidx.preference.Preference
    public void performClick(View view) {
        super.performClick(view);
        l(view);
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public SwitchPreferenceCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com8.f6177k);
    }
}
