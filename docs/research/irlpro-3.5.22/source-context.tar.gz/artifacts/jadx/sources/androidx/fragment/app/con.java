package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class con implements Parcelable {
    public static final Parcelable.Creator<con> CREATOR = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f8289a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CharSequence f2490a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final String f2491a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<String> f2492a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2493a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f8290b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final CharSequence f2494b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final ArrayList<String> f2495b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f2496b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int[] f2497b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f8291c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final ArrayList<String> f2498c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final int[] f2499c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f8292d;

    public class aux implements Parcelable.Creator<con> {
        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public con createFromParcel(Parcel parcel) {
            return new con(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public con[] newArray(int i2) {
            return new con[i2];
        }
    }

    public con(androidx.fragment.app.aux auxVar) {
        int size = ((lpt3) auxVar).f2511a.size();
        this.f2493a = new int[size * 5];
        if (!((lpt3) auxVar).f2512a) {
            throw new IllegalStateException("Not on back stack");
        }
        this.f2492a = new ArrayList<>(size);
        this.f2497b = new int[size];
        this.f2499c = new int[size];
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            lpt3.aux auxVar2 = ((lpt3) auxVar).f2511a.get(i2);
            int i4 = i3 + 1;
            this.f2493a[i3] = auxVar2.f8304a;
            ArrayList<String> arrayList = this.f2492a;
            Fragment fragment = auxVar2.f2519a;
            arrayList.add(fragment != null ? fragment.mWho : null);
            int[] iArr = this.f2493a;
            int i5 = i4 + 1;
            iArr[i4] = auxVar2.f8305b;
            int i6 = i5 + 1;
            iArr[i5] = auxVar2.f8306c;
            int i7 = i6 + 1;
            iArr[i6] = auxVar2.f8307d;
            iArr[i7] = auxVar2.f8308e;
            this.f2497b[i2] = auxVar2.f2520a.ordinal();
            this.f2499c[i2] = auxVar2.f2521b.ordinal();
            i2++;
            i3 = i7 + 1;
        }
        this.f8289a = auxVar.f8301e;
        this.f2491a = ((lpt3) auxVar).f2510a;
        this.f8290b = auxVar.f8235h;
        this.f8291c = auxVar.f8302f;
        this.f2490a = ((lpt3) auxVar).f2508a;
        this.f8292d = auxVar.f8303g;
        this.f2494b = ((lpt3) auxVar).f2513b;
        this.f2495b = ((lpt3) auxVar).f2514b;
        this.f2498c = ((lpt3) auxVar).f2516c;
        this.f2496b = ((lpt3) auxVar).f2517c;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public androidx.fragment.app.aux k(com6 com6Var) {
        androidx.fragment.app.aux auxVar = new androidx.fragment.app.aux(com6Var);
        int i2 = 0;
        int i3 = 0;
        while (i2 < this.f2493a.length) {
            lpt3.aux auxVar2 = new lpt3.aux();
            int i4 = i2 + 1;
            auxVar2.f8304a = this.f2493a[i2];
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Instantiate " + auxVar + " op #" + i3 + " base fragment #" + this.f2493a[i4]);
            }
            String str = this.f2492a.get(i3);
            if (str != null) {
                auxVar2.f2519a = com6Var.h0(str);
            } else {
                auxVar2.f2519a = null;
            }
            auxVar2.f2520a = androidx.lifecycle.nul.EnumC0039nul.values()[this.f2497b[i3]];
            auxVar2.f2521b = androidx.lifecycle.nul.EnumC0039nul.values()[this.f2499c[i3]];
            int[] iArr = this.f2493a;
            int i5 = i4 + 1;
            int i6 = iArr[i4];
            auxVar2.f8305b = i6;
            int i7 = i5 + 1;
            int i8 = iArr[i5];
            auxVar2.f8306c = i8;
            int i9 = i7 + 1;
            int i10 = iArr[i7];
            auxVar2.f8307d = i10;
            int i11 = iArr[i9];
            auxVar2.f8308e = i11;
            ((lpt3) auxVar).f8297a = i6;
            ((lpt3) auxVar).f8298b = i8;
            ((lpt3) auxVar).f8299c = i10;
            ((lpt3) auxVar).f8300d = i11;
            auxVar.f(auxVar2);
            i3++;
            i2 = i9 + 1;
        }
        auxVar.f8301e = this.f8289a;
        ((lpt3) auxVar).f2510a = this.f2491a;
        auxVar.f8235h = this.f8290b;
        ((lpt3) auxVar).f2512a = true;
        auxVar.f8302f = this.f8291c;
        ((lpt3) auxVar).f2508a = this.f2490a;
        auxVar.f8303g = this.f8292d;
        ((lpt3) auxVar).f2513b = this.f2494b;
        ((lpt3) auxVar).f2514b = this.f2495b;
        ((lpt3) auxVar).f2516c = this.f2498c;
        ((lpt3) auxVar).f2517c = this.f2496b;
        auxVar.v(1);
        return auxVar;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f2493a);
        parcel.writeStringList(this.f2492a);
        parcel.writeIntArray(this.f2497b);
        parcel.writeIntArray(this.f2499c);
        parcel.writeInt(this.f8289a);
        parcel.writeString(this.f2491a);
        parcel.writeInt(this.f8290b);
        parcel.writeInt(this.f8291c);
        TextUtils.writeToParcel(this.f2490a, parcel, 0);
        parcel.writeInt(this.f8292d);
        TextUtils.writeToParcel(this.f2494b, parcel, 0);
        parcel.writeStringList(this.f2495b);
        parcel.writeStringList(this.f2498c);
        parcel.writeInt(this.f2496b ? 1 : 0);
    }

    public con(Parcel parcel) {
        this.f2493a = parcel.createIntArray();
        this.f2492a = parcel.createStringArrayList();
        this.f2497b = parcel.createIntArray();
        this.f2499c = parcel.createIntArray();
        this.f8289a = parcel.readInt();
        this.f2491a = parcel.readString();
        this.f8290b = parcel.readInt();
        this.f8291c = parcel.readInt();
        this.f2490a = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f8292d = parcel.readInt();
        this.f2494b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f2495b = parcel.createStringArrayList();
        this.f2498c = parcel.createStringArrayList();
        this.f2496b = parcel.readInt() != 0;
    }
}
