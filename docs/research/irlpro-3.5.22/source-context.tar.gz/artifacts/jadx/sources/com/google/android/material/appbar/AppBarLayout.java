package com.google.android.material.appbar;

import COM9.com3;
import COM9.com4;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.newrelic.agent.android.analytics.EventManagerImpl;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.List;
import p024Com2.lpt3;
import p024Com2.n;
import p024Com2.t0;
import p024Com2.y;
import p075cOM6.c4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.z3;
import p081cOm2.e2;
import p081cOm2.h2;
import p090coM1.b0;
import p106com7.com9;
import p106com7.lpt1;
import p106com7.lpt4;

/* JADX INFO: loaded from: classes.dex */
public class AppBarLayout extends LinearLayout implements CoordinatorLayout.con {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final int f9256g = g4.f8961f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9257a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public t0 f3278a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3279a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f3280a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Behavior f3281a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public WeakReference<View> f3282a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<con> f3283a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f3284a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f9258b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final List<com2> f3285b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3286b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9259c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3287c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9260d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3288d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9261e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f3289e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f9262f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f3290f;

    public static class BaseBehavior<T extends AppBarLayout> extends com9<T> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public ValueAnimator f9263a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com1 f3291a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public WeakReference<View> f3292a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9264b;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f9265f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f9266g;

        public class aux implements ValueAnimator.AnimatorUpdateListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ CoordinatorLayout f9267a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AppBarLayout f3294a;

            public aux(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
                this.f9267a = coordinatorLayout;
                this.f3294a = appBarLayout;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                BaseBehavior.this.P(this.f9267a, this.f3294a, ((Integer) valueAnimator.getAnimatedValue()).intValue());
            }
        }

        public class con extends lpt3 {
            public con() {
            }

            @Override // p024Com2.lpt3
            public void g(View view, e2 e2Var) {
                super.g(view, e2Var);
                e2Var.p0(BaseBehavior.this.f9264b);
                e2Var.T(ScrollView.class.getName());
            }
        }

        public class nul implements h2 {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ int f9273a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ View f3296a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ CoordinatorLayout f3297a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AppBarLayout f3299a;

            public nul(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2) {
                this.f3297a = coordinatorLayout;
                this.f3299a = appBarLayout;
                this.f3296a = view;
                this.f9273a = i2;
            }

            /* JADX WARN: Multi-variable type inference failed */
            /* JADX WARN: Type inference fix 'apply assigned field type' failed
            java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
            	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
            	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
            	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
            	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
             */
            @Override // p081cOm2.h2
            public boolean a(View view, h2.aux auxVar) {
                BaseBehavior.this.q(this.f3297a, this.f3299a, this.f3296a, 0, this.f9273a, new int[]{0, 0}, 1);
                return true;
            }
        }

        public class prn implements h2 {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ AppBarLayout f3300a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ boolean f3301a;

            public prn(AppBarLayout appBarLayout, boolean z2) {
                this.f3300a = appBarLayout;
                this.f3301a = z2;
            }

            @Override // p081cOm2.h2
            public boolean a(View view, h2.aux auxVar) {
                this.f3300a.setExpanded(this.f3301a);
                return true;
            }
        }

        public BaseBehavior() {
        }

        public static boolean a0(int i2, int i3) {
            return (i2 & i3) == i3;
        }

        public static View d0(AppBarLayout appBarLayout, int i2) {
            int iAbs = Math.abs(i2);
            int childCount = appBarLayout.getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = appBarLayout.getChildAt(i3);
                if (iAbs >= childAt.getTop() && iAbs <= childAt.getBottom()) {
                    return childAt;
                }
            }
            return null;
        }

        @Override // p106com7.com9
        public int M() {
            return E() + this.f9265f;
        }

        public final boolean T(CoordinatorLayout coordinatorLayout, T t2, View view) {
            boolean z2 = false;
            if (M() != (-t2.getTotalScrollRange())) {
                U(coordinatorLayout, t2, e2.aux.f9109m, false);
                z2 = true;
            }
            if (M() != 0) {
                if (!view.canScrollVertically(-1)) {
                    U(coordinatorLayout, t2, e2.aux.f9110n, true);
                    return true;
                }
                int i2 = -t2.getDownNestedPreScrollRange();
                if (i2 != 0) {
                    y.k0(coordinatorLayout, e2.aux.f9110n, null, new nul(coordinatorLayout, t2, view, i2));
                    return true;
                }
            }
            return z2;
        }

        public final void U(CoordinatorLayout coordinatorLayout, T t2, e2.aux auxVar, boolean z2) {
            y.k0(coordinatorLayout, auxVar, null, new prn(t2, z2));
        }

        public final void V(CoordinatorLayout coordinatorLayout, T t2, int i2, float f2) {
            int iAbs = Math.abs(M() - i2);
            float fAbs = Math.abs(f2);
            W(coordinatorLayout, t2, i2, fAbs > 0.0f ? Math.round((iAbs / fAbs) * 1000.0f) * 3 : (int) (((iAbs / t2.getHeight()) + 1.0f) * 150.0f));
        }

        public final void W(CoordinatorLayout coordinatorLayout, T t2, int i2, int i3) {
            int iM = M();
            if (iM == i2) {
                ValueAnimator valueAnimator = this.f9263a;
                if (valueAnimator == null || !valueAnimator.isRunning()) {
                    return;
                }
                this.f9263a.cancel();
                return;
            }
            ValueAnimator valueAnimator2 = this.f9263a;
            if (valueAnimator2 == null) {
                ValueAnimator valueAnimator3 = new ValueAnimator();
                this.f9263a = valueAnimator3;
                valueAnimator3.setInterpolator(COM6.aux.f5704e);
                this.f9263a.addUpdateListener(new aux(coordinatorLayout, t2));
            } else {
                valueAnimator2.cancel();
            }
            this.f9263a.setDuration(Math.min(i3, EventManagerImpl.DEFAULT_MAX_EVENT_BUFFER_TIME));
            this.f9263a.setIntValues(iM, i2);
            this.f9263a.start();
        }

        public final int X(int i2, int i3, int i4) {
            return i2 < (i3 + i4) / 2 ? i3 : i4;
        }

        @Override // p106com7.com9
        /* JADX INFO: renamed from: Y, reason: merged with bridge method [inline-methods] */
        public boolean H(T t2) {
            WeakReference<View> weakReference = this.f3292a;
            if (weakReference == null) {
                return true;
            }
            View view = weakReference.get();
            return (view == null || !view.isShown() || view.canScrollVertically(-1)) ? false : true;
        }

        public final boolean Z(CoordinatorLayout coordinatorLayout, T t2, View view) {
            return t2.j() && coordinatorLayout.getHeight() - view.getHeight() <= t2.getHeight();
        }

        public final boolean b0(AppBarLayout appBarLayout) {
            int childCount = appBarLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                if (((com1) appBarLayout.getChildAt(i2).getLayoutParams()).f9276a != 0) {
                    return true;
                }
            }
            return false;
        }

        public final View c0(CoordinatorLayout coordinatorLayout) {
            int childCount = coordinatorLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                if ((childAt instanceof n) || (childAt instanceof ListView) || (childAt instanceof ScrollView)) {
                    return childAt;
                }
            }
            return null;
        }

        public final int e0(T t2, int i2) {
            int childCount = t2.getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = t2.getChildAt(i3);
                int top = childAt.getTop();
                int bottom = childAt.getBottom();
                com1 com1Var = (com1) childAt.getLayoutParams();
                if (a0(com1Var.c(), 32)) {
                    top -= ((LinearLayout.LayoutParams) com1Var).topMargin;
                    bottom += ((LinearLayout.LayoutParams) com1Var).bottomMargin;
                }
                int i4 = -i2;
                if (top <= i4 && bottom >= i4) {
                    return i3;
                }
            }
            return -1;
        }

        public final View f0(CoordinatorLayout coordinatorLayout) {
            int childCount = coordinatorLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = coordinatorLayout.getChildAt(i2);
                if (((CoordinatorLayout.com2) childAt.getLayoutParams()).f() instanceof ScrollingViewBehavior) {
                    return childAt;
                }
            }
            return null;
        }

        @Override // p106com7.com9
        /* JADX INFO: renamed from: g0, reason: merged with bridge method [inline-methods] */
        public int K(T t2) {
            return -t2.getDownNestedScrollRange();
        }

        @Override // p106com7.com9
        /* JADX INFO: renamed from: h0, reason: merged with bridge method [inline-methods] */
        public int L(T t2) {
            return t2.getTotalScrollRange();
        }

        public final int i0(T t2, int i2) {
            int iAbs = Math.abs(i2);
            int childCount = t2.getChildCount();
            int topInset = 0;
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = t2.getChildAt(i3);
                com1 com1Var = (com1) childAt.getLayoutParams();
                Interpolator interpolatorD = com1Var.d();
                if (iAbs >= childAt.getTop() && iAbs <= childAt.getBottom()) {
                    if (interpolatorD == null) {
                        break;
                    }
                    int iC = com1Var.c();
                    if ((iC & 1) != 0) {
                        topInset = 0 + childAt.getHeight() + ((LinearLayout.LayoutParams) com1Var).topMargin + ((LinearLayout.LayoutParams) com1Var).bottomMargin;
                        if ((iC & 2) != 0) {
                            topInset -= y.B(childAt);
                        }
                    }
                    if (y.x(childAt)) {
                        topInset -= t2.getTopInset();
                    }
                    if (topInset <= 0) {
                        break;
                    }
                    float f2 = topInset;
                    return Integer.signum(i2) * (childAt.getTop() + Math.round(f2 * interpolatorD.getInterpolation((iAbs - childAt.getTop()) / f2)));
                }
            }
            return i2;
        }

        @Override // p106com7.com9
        /* JADX INFO: renamed from: j0, reason: merged with bridge method [inline-methods] */
        public void N(CoordinatorLayout coordinatorLayout, T t2) {
            w0(coordinatorLayout, t2);
            if (t2.l()) {
                t2.r(t2.u(c0(coordinatorLayout)));
            }
        }

        @Override // p106com7.lpt2, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: k0, reason: merged with bridge method [inline-methods] */
        public boolean l(CoordinatorLayout coordinatorLayout, T t2, int i2) {
            boolean zL = super.l(coordinatorLayout, t2, i2);
            int pendingAction = t2.getPendingAction();
            com1 com1Var = this.f3291a;
            if (com1Var == null || (pendingAction & 8) != 0) {
                if (pendingAction != 0) {
                    boolean z2 = (pendingAction & 4) != 0;
                    if ((pendingAction & 2) != 0) {
                        int i3 = -t2.getUpNestedPreScrollRange();
                        if (z2) {
                            V(coordinatorLayout, t2, i3, 0.0f);
                        } else {
                            P(coordinatorLayout, t2, i3);
                        }
                    } else if ((pendingAction & 1) != 0) {
                        if (z2) {
                            V(coordinatorLayout, t2, 0, 0.0f);
                        } else {
                            P(coordinatorLayout, t2, 0);
                        }
                    }
                }
            } else if (com1Var.f9269b) {
                P(coordinatorLayout, t2, -t2.getTotalScrollRange());
            } else if (com1Var.f9270c) {
                P(coordinatorLayout, t2, 0);
            } else {
                View childAt = t2.getChildAt(com1Var.f3295a);
                P(coordinatorLayout, t2, (-childAt.getBottom()) + (this.f3291a.f9271d ? y.B(childAt) + t2.getTopInset() : Math.round(childAt.getHeight() * this.f3291a.f9268a)));
            }
            t2.n();
            this.f3291a = null;
            G(b0.b(E(), -t2.getTotalScrollRange(), 0));
            y0(coordinatorLayout, t2, E(), 0, true);
            t2.m(E());
            x0(coordinatorLayout, t2);
            return zL;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: l0, reason: merged with bridge method [inline-methods] */
        public boolean m(CoordinatorLayout coordinatorLayout, T t2, int i2, int i3, int i4, int i5) {
            if (((ViewGroup.MarginLayoutParams) ((CoordinatorLayout.com2) t2.getLayoutParams())).height != -2) {
                return super.m(coordinatorLayout, t2, i2, i3, i4, i5);
            }
            coordinatorLayout.J(t2, i2, i3, View.MeasureSpec.makeMeasureSpec(0, 0), i5);
            return true;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: m0, reason: merged with bridge method [inline-methods] */
        public void q(CoordinatorLayout coordinatorLayout, T t2, View view, int i2, int i3, int[] iArr, int i4) {
            int i5;
            int downNestedPreScrollRange;
            if (i3 != 0) {
                if (i3 < 0) {
                    i5 = -t2.getTotalScrollRange();
                    downNestedPreScrollRange = t2.getDownNestedPreScrollRange() + i5;
                } else {
                    i5 = -t2.getUpNestedPreScrollRange();
                    downNestedPreScrollRange = 0;
                }
                int i6 = i5;
                int i7 = downNestedPreScrollRange;
                if (i6 != i7) {
                    iArr[1] = O(coordinatorLayout, t2, i3, i6, i7);
                }
            }
            if (t2.l()) {
                t2.r(t2.u(view));
            }
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: n0, reason: merged with bridge method [inline-methods] */
        public void t(CoordinatorLayout coordinatorLayout, T t2, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            if (i5 < 0) {
                iArr[1] = O(coordinatorLayout, t2, i5, -t2.getDownNestedScrollRange(), 0);
            }
            if (i5 == 0) {
                x0(coordinatorLayout, t2);
            }
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: o0, reason: merged with bridge method [inline-methods] */
        public void x(CoordinatorLayout coordinatorLayout, T t2, Parcelable parcelable) {
            if (parcelable instanceof com1) {
                s0((com1) parcelable, true);
                super.x(coordinatorLayout, t2, this.f3291a.k());
            } else {
                super.x(coordinatorLayout, t2, parcelable);
                this.f3291a = null;
            }
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: p0, reason: merged with bridge method [inline-methods] */
        public Parcelable y(CoordinatorLayout coordinatorLayout, T t2) {
            Parcelable parcelableY = super.y(coordinatorLayout, t2);
            com1 com1VarT0 = t0(parcelableY, t2);
            return com1VarT0 == null ? parcelableY : com1VarT0;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: q0, reason: merged with bridge method [inline-methods] */
        public boolean A(CoordinatorLayout coordinatorLayout, T t2, View view, View view2, int i2, int i3) {
            ValueAnimator valueAnimator;
            boolean z2 = (i2 & 2) != 0 && (t2.l() || Z(coordinatorLayout, t2, view));
            if (z2 && (valueAnimator = this.f9263a) != null) {
                valueAnimator.cancel();
            }
            this.f3292a = null;
            this.f9266g = i3;
            return z2;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: r0, reason: merged with bridge method [inline-methods] */
        public void C(CoordinatorLayout coordinatorLayout, T t2, View view, int i2) {
            if (this.f9266g == 0 || i2 == 1) {
                w0(coordinatorLayout, t2);
                if (t2.l()) {
                    t2.r(t2.u(view));
                }
            }
            this.f3292a = new WeakReference<>(view);
        }

        public void s0(com1 com1Var, boolean z2) {
            if (this.f3291a == null || z2) {
                this.f3291a = com1Var;
            }
        }

        public com1 t0(Parcelable parcelable, T t2) {
            int iE = E();
            int childCount = t2.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = t2.getChildAt(i2);
                int bottom = childAt.getBottom() + iE;
                if (childAt.getTop() + iE <= 0 && bottom >= 0) {
                    if (parcelable == null) {
                        parcelable = COM2.aux.f5689a;
                    }
                    com1 com1Var = new com1(parcelable);
                    boolean z2 = iE == 0;
                    com1Var.f9270c = z2;
                    com1Var.f9269b = !z2 && (-iE) >= t2.getTotalScrollRange();
                    com1Var.f3295a = i2;
                    com1Var.f9271d = bottom == y.B(childAt) + t2.getTopInset();
                    com1Var.f9268a = bottom / childAt.getHeight();
                    return com1Var;
                }
            }
            return null;
        }

        @Override // p106com7.com9
        /* JADX INFO: renamed from: u0, reason: merged with bridge method [inline-methods] */
        public int Q(CoordinatorLayout coordinatorLayout, T t2, int i2, int i3, int i4) {
            int iM = M();
            int i5 = 0;
            if (i3 == 0 || iM < i3 || iM > i4) {
                this.f9265f = 0;
            } else {
                int iB = b0.b(i2, i3, i4);
                if (iM != iB) {
                    int iI0 = t2.h() ? i0(t2, iB) : iB;
                    boolean zG = G(iI0);
                    int i6 = iM - iB;
                    this.f9265f = iB - iI0;
                    if (zG) {
                        while (i5 < t2.getChildCount()) {
                            com1 com1Var = (com1) t2.getChildAt(i5).getLayoutParams();
                            nul nulVarB = com1Var.b();
                            if (nulVarB != null && (com1Var.c() & 1) != 0) {
                                nulVarB.a(t2, t2.getChildAt(i5), E());
                            }
                            i5++;
                        }
                    }
                    if (!zG && t2.h()) {
                        coordinatorLayout.f(t2);
                    }
                    t2.m(E());
                    y0(coordinatorLayout, t2, iB, iB < iM ? -1 : 1, false);
                    i5 = i6;
                }
            }
            x0(coordinatorLayout, t2);
            return i5;
        }

        public final boolean v0(CoordinatorLayout coordinatorLayout, T t2) {
            List<View> listS = coordinatorLayout.s(t2);
            int size = listS.size();
            for (int i2 = 0; i2 < size; i2++) {
                CoordinatorLayout.nul nulVarF = ((CoordinatorLayout.com2) listS.get(i2).getLayoutParams()).f();
                if (nulVarF instanceof ScrollingViewBehavior) {
                    return ((ScrollingViewBehavior) nulVarF).K() != 0;
                }
            }
            return false;
        }

        public final void w0(CoordinatorLayout coordinatorLayout, T t2) {
            int topInset = t2.getTopInset() + t2.getPaddingTop();
            int iM = M() - topInset;
            int iE0 = e0(t2, iM);
            if (iE0 >= 0) {
                View childAt = t2.getChildAt(iE0);
                com1 com1Var = (com1) childAt.getLayoutParams();
                int iC = com1Var.c();
                if ((iC & 17) == 17) {
                    int topInset2 = -childAt.getTop();
                    int iB = -childAt.getBottom();
                    if (iE0 == 0 && y.x(t2) && y.x(childAt)) {
                        topInset2 -= t2.getTopInset();
                    }
                    if (a0(iC, 2)) {
                        iB += y.B(childAt);
                    } else if (a0(iC, 5)) {
                        int iB2 = y.B(childAt) + iB;
                        if (iM < iB2) {
                            topInset2 = iB2;
                        } else {
                            iB = iB2;
                        }
                    }
                    if (a0(iC, 32)) {
                        topInset2 += ((LinearLayout.LayoutParams) com1Var).topMargin;
                        iB -= ((LinearLayout.LayoutParams) com1Var).bottomMargin;
                    }
                    V(coordinatorLayout, t2, b0.b(X(iM, iB, topInset2) + topInset, -t2.getTotalScrollRange(), 0), 0.0f);
                }
            }
        }

        public final void x0(CoordinatorLayout coordinatorLayout, T t2) {
            View viewF0;
            y.i0(coordinatorLayout, e2.aux.f9109m.b());
            y.i0(coordinatorLayout, e2.aux.f9110n.b());
            if (t2.getTotalScrollRange() == 0 || (viewF0 = f0(coordinatorLayout)) == null || !b0(t2)) {
                return;
            }
            if (!y.M(coordinatorLayout)) {
                y.o0(coordinatorLayout, new con());
            }
            this.f9264b = T(coordinatorLayout, t2, viewF0);
        }

        public final void y0(CoordinatorLayout coordinatorLayout, T t2, int i2, int i3, boolean z2) {
            View viewD0 = d0(t2, i2);
            boolean zU = false;
            if (viewD0 != null) {
                int iC = ((com1) viewD0.getLayoutParams()).c();
                if ((iC & 1) != 0) {
                    int iB = y.B(viewD0);
                    if (i3 <= 0 || (iC & 12) == 0 ? !((iC & 2) == 0 || (-i2) < (viewD0.getBottom() - iB) - t2.getTopInset()) : (-i2) >= (viewD0.getBottom() - iB) - t2.getTopInset()) {
                        zU = true;
                    }
                }
            }
            if (t2.l()) {
                zU = t2.u(c0(coordinatorLayout));
            }
            boolean zR = t2.r(zU);
            if (z2 || (zR && v0(coordinatorLayout, t2))) {
                t2.jumpDrawablesToCurrentState();
            }
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public static class com1 extends COM2.aux {
            public static final Parcelable.Creator<com1> CREATOR = new aux();

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public float f9268a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public int f3295a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public boolean f9269b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public boolean f9270c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            public boolean f9271d;

            public class aux implements Parcelable.ClassLoaderCreator<com1> {
                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public com1 createFromParcel(Parcel parcel) {
                    return new com1(parcel, null);
                }

                @Override // android.os.Parcelable.ClassLoaderCreator
                /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
                public com1 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return new com1(parcel, classLoader);
                }

                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
                public com1[] newArray(int i2) {
                    return new com1[i2];
                }
            }

            public com1(Parcel parcel, ClassLoader classLoader) {
                super(parcel, classLoader);
                this.f9269b = parcel.readByte() != 0;
                this.f9270c = parcel.readByte() != 0;
                this.f3295a = parcel.readInt();
                this.f9268a = parcel.readFloat();
                this.f9271d = parcel.readByte() != 0;
            }

            @Override // COM2.aux, android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i2) {
                super.writeToParcel(parcel, i2);
                parcel.writeByte(this.f9269b ? (byte) 1 : (byte) 0);
                parcel.writeByte(this.f9270c ? (byte) 1 : (byte) 0);
                parcel.writeInt(this.f3295a);
                parcel.writeFloat(this.f9268a);
                parcel.writeByte(this.f9271d ? (byte) 1 : (byte) 0);
            }

            public com1(Parcelable parcelable) {
                super(parcelable);
            }
        }
    }

    public static class Behavior extends BaseBehavior<AppBarLayout> {
        public Behavior() {
        }

        @Override // p106com7.com9, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public /* bridge */ /* synthetic */ boolean D(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return super.D(coordinatorLayout, view, motionEvent);
        }

        @Override // p106com7.lpt2
        public /* bridge */ /* synthetic */ int E() {
            return super.E();
        }

        @Override // p106com7.lpt2
        public /* bridge */ /* synthetic */ boolean G(int i2) {
            return super.G(i2);
        }

        @Override // p106com7.com9, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public /* bridge */ /* synthetic */ boolean k(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return super.k(coordinatorLayout, view, motionEvent);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: k0 */
        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2) {
            return super.l(coordinatorLayout, appBarLayout, i2);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: l0 */
        public /* bridge */ /* synthetic */ boolean m(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i2, int i3, int i4, int i5) {
            return super.m(coordinatorLayout, appBarLayout, i2, i3, i4, i5);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: m0 */
        public /* bridge */ /* synthetic */ void q(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2, int i3, int[] iArr, int i4) {
            super.q(coordinatorLayout, appBarLayout, view, i2, i3, iArr, i4);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: n0 */
        public /* bridge */ /* synthetic */ void t(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
            super.t(coordinatorLayout, appBarLayout, view, i2, i3, i4, i5, i6, iArr);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: o0 */
        public /* bridge */ /* synthetic */ void x(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Parcelable parcelable) {
            super.x(coordinatorLayout, appBarLayout, parcelable);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: p0 */
        public /* bridge */ /* synthetic */ Parcelable y(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            return super.y(coordinatorLayout, appBarLayout);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: q0 */
        public /* bridge */ /* synthetic */ boolean A(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, View view2, int i2, int i3) {
            return super.A(coordinatorLayout, appBarLayout, view, view2, i2, i3);
        }

        @Override // com.google.android.material.appbar.AppBarLayout.BaseBehavior
        /* JADX INFO: renamed from: r0 */
        public /* bridge */ /* synthetic */ void C(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i2) {
            super.C(coordinatorLayout, appBarLayout, view, i2);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public static class ScrollingViewBehavior extends lpt1 {
        public ScrollingViewBehavior() {
        }

        public static int R(AppBarLayout appBarLayout) {
            CoordinatorLayout.nul nulVarF = ((CoordinatorLayout.com2) appBarLayout.getLayoutParams()).f();
            if (nulVarF instanceof BaseBehavior) {
                return ((BaseBehavior) nulVarF).M();
            }
            return 0;
        }

        @Override // p106com7.lpt1
        public float J(View view) {
            int i2;
            if (view instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view;
                int totalScrollRange = appBarLayout.getTotalScrollRange();
                int downNestedPreScrollRange = appBarLayout.getDownNestedPreScrollRange();
                int iR = R(appBarLayout);
                if ((downNestedPreScrollRange == 0 || totalScrollRange + iR > downNestedPreScrollRange) && (i2 = totalScrollRange - downNestedPreScrollRange) != 0) {
                    return (iR / i2) + 1.0f;
                }
            }
            return 0.0f;
        }

        @Override // p106com7.lpt1
        public int L(View view) {
            return view instanceof AppBarLayout ? ((AppBarLayout) view).getTotalScrollRange() : super.L(view);
        }

        @Override // p106com7.lpt1
        /* JADX INFO: renamed from: Q, reason: merged with bridge method [inline-methods] */
        public AppBarLayout H(List<View> list) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = list.get(i2);
                if (view instanceof AppBarLayout) {
                    return (AppBarLayout) view;
                }
            }
            return null;
        }

        public final void S(View view, View view2) {
            CoordinatorLayout.nul nulVarF = ((CoordinatorLayout.com2) view2.getLayoutParams()).f();
            if (nulVarF instanceof BaseBehavior) {
                y.Z(view, (((view2.getBottom() - view.getTop()) + ((BaseBehavior) nulVarF).f9265f) + M()) - I(view2));
            }
        }

        public final void T(View view, View view2) {
            if (view2 instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view2;
                if (appBarLayout.l()) {
                    appBarLayout.r(appBarLayout.u(view));
                }
            }
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public boolean e(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return view2 instanceof AppBarLayout;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public boolean h(CoordinatorLayout coordinatorLayout, View view, View view2) {
            S(view, view2);
            T(view, view2);
            return false;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public void i(CoordinatorLayout coordinatorLayout, View view, View view2) {
            if (view2 instanceof AppBarLayout) {
                y.i0(coordinatorLayout, e2.aux.f9109m.b());
                y.i0(coordinatorLayout, e2.aux.f9110n.b());
                y.o0(coordinatorLayout, null);
            }
        }

        @Override // p106com7.lpt2, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, View view, int i2) {
            return super.l(coordinatorLayout, view, i2);
        }

        @Override // p106com7.lpt1, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public /* bridge */ /* synthetic */ boolean m(CoordinatorLayout coordinatorLayout, View view, int i2, int i3, int i4, int i5) {
            return super.m(coordinatorLayout, view, i2, i3, i4, i5);
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public boolean w(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z2) {
            AppBarLayout appBarLayoutH = H(coordinatorLayout.r(view));
            if (appBarLayoutH != null) {
                rect.offset(view.getLeft(), view.getTop());
                Rect rect2 = ((lpt1) this).f10516a;
                rect2.set(0, 0, coordinatorLayout.getWidth(), coordinatorLayout.getHeight());
                if (!rect2.contains(rect)) {
                    appBarLayoutH.o(false, !z2);
                    return true;
                }
            }
            return false;
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3115c1);
            O(typedArrayObtainStyledAttributes.getDimensionPixelSize(h4.e2, 0));
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public class aux implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ com3 f9275a;

        public aux(com3 com3Var) {
            this.f9275a = com3Var;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            this.f9275a.X(fFloatValue);
            if (AppBarLayout.this.f3280a instanceof com3) {
                ((com3) AppBarLayout.this.f3280a).X(fFloatValue);
            }
            Iterator it = AppBarLayout.this.f3285b.iterator();
            while (it.hasNext()) {
                ((com2) it.next()).a(fFloatValue, this.f9275a.z());
            }
        }
    }

    public interface com2 {
        void a(float f2, int i2);
    }

    public interface con<T extends AppBarLayout> {
        void a(T t2, int i2);
    }

    public static abstract class nul {
        public abstract void a(AppBarLayout appBarLayout, View view, float f2);
    }

    public static class prn extends nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Rect f9277a = new Rect();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final Rect f9278b = new Rect();

        public static void b(Rect rect, AppBarLayout appBarLayout, View view) {
            view.getDrawingRect(rect);
            appBarLayout.offsetDescendantRectToMyCoords(view, rect);
            rect.offset(0, -appBarLayout.getTopInset());
        }

        @Override // com.google.android.material.appbar.AppBarLayout.nul
        public void a(AppBarLayout appBarLayout, View view, float f2) {
            b(this.f9277a, appBarLayout, view);
            float fAbs = this.f9277a.top - Math.abs(f2);
            if (fAbs > 0.0f) {
                y.v0(view, null);
                view.setTranslationY(0.0f);
                return;
            }
            float fA = 1.0f - b0.a(Math.abs(fAbs / this.f9277a.height()), 0.0f, 1.0f);
            float fHeight = (-fAbs) - ((this.f9277a.height() * 0.3f) * (1.0f - (fA * fA)));
            view.setTranslationY(fHeight);
            view.getDrawingRect(this.f9278b);
            this.f9278b.offset(0, (int) (-fHeight));
            y.v0(view, this.f9278b);
        }
    }

    public final void c() {
        WeakReference<View> weakReference = this.f3282a;
        if (weakReference != null) {
            weakReference.clear();
        }
        this.f3282a = null;
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof com1;
    }

    public final View d(View view) {
        int i2;
        if (this.f3282a == null && (i2 = this.f9262f) != -1) {
            View viewFindViewById = view != null ? view.findViewById(i2) : null;
            if (viewFindViewById == null && (getParent() instanceof ViewGroup)) {
                viewFindViewById = ((ViewGroup) getParent()).findViewById(this.f9262f);
            }
            if (viewFindViewById != null) {
                this.f3282a = new WeakReference<>(viewFindViewById);
            }
        }
        WeakReference<View> weakReference = this.f3282a;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (t()) {
            int iSave = canvas.save();
            canvas.translate(0.0f, -this.f9257a);
            this.f3280a.draw(canvas);
            canvas.restoreToCount(iSave);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f3280a;
        if (drawable != null && drawable.isStateful() && drawable.setState(drawableState)) {
            invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public com1 generateDefaultLayoutParams() {
        return new com1(-1, -2);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
    public com1 generateLayoutParams(AttributeSet attributeSet) {
        return new com1(getContext(), attributeSet);
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup
    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public com1 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LinearLayout.LayoutParams) {
            return new com1((LinearLayout.LayoutParams) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new com1((ViewGroup.MarginLayoutParams) layoutParams) : new com1(layoutParams);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.con
    public CoordinatorLayout.nul<AppBarLayout> getBehavior() {
        Behavior behavior = new Behavior();
        this.f3281a = behavior;
        return behavior;
    }

    public int getDownNestedPreScrollRange() {
        int iMin;
        int iB;
        int i2 = this.f9259c;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            com1 com1Var = (com1) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = com1Var.f9276a;
            if ((i4 & 5) != 5) {
                if (i3 > 0) {
                    break;
                }
            } else {
                int i5 = ((LinearLayout.LayoutParams) com1Var).topMargin + ((LinearLayout.LayoutParams) com1Var).bottomMargin;
                if ((i4 & 8) != 0) {
                    iB = y.B(childAt);
                } else {
                    if ((i4 & 2) != 0) {
                        iB = measuredHeight - y.B(childAt);
                    } else {
                        iMin = i5 + measuredHeight;
                    }
                    if (childCount == 0 && y.x(childAt)) {
                        iMin = Math.min(iMin, measuredHeight - getTopInset());
                    }
                    i3 += iMin;
                }
                iMin = i5 + iB;
                if (childCount == 0) {
                    iMin = Math.min(iMin, measuredHeight - getTopInset());
                }
                i3 += iMin;
            }
        }
        int iMax = Math.max(0, i3);
        this.f9259c = iMax;
        return iMax;
    }

    public int getDownNestedScrollRange() {
        int i2 = this.f9260d;
        if (i2 != -1) {
            return i2;
        }
        int childCount = getChildCount();
        int iB = 0;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            com1 com1Var = (com1) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + ((LinearLayout.LayoutParams) com1Var).topMargin + ((LinearLayout.LayoutParams) com1Var).bottomMargin;
            int i4 = com1Var.f9276a;
            if ((i4 & 1) == 0) {
                break;
            }
            iB += measuredHeight;
            if ((i4 & 2) != 0) {
                iB -= y.B(childAt);
                break;
            }
        }
        int iMax = Math.max(0, iB);
        this.f9260d = iMax;
        return iMax;
    }

    public int getLiftOnScrollTargetViewId() {
        return this.f9262f;
    }

    public final int getMinimumHeightForVisibleOverlappingContent() {
        int topInset = getTopInset();
        int iB = y.B(this);
        if (iB == 0) {
            int childCount = getChildCount();
            iB = childCount >= 1 ? y.B(getChildAt(childCount - 1)) : 0;
            if (iB == 0) {
                return getHeight() / 3;
            }
        }
        return (iB * 2) + topInset;
    }

    public int getPendingAction() {
        return this.f9261e;
    }

    public Drawable getStatusBarForeground() {
        return this.f3280a;
    }

    @Deprecated
    public float getTargetElevation() {
        return 0.0f;
    }

    public final int getTopInset() {
        t0 t0Var = this.f3278a;
        if (t0Var != null) {
            return t0Var.l();
        }
        return 0;
    }

    public final int getTotalScrollRange() {
        int i2 = this.f9258b;
        if (i2 != -1) {
            return i2;
        }
        int childCount = getChildCount();
        int iB = 0;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            com1 com1Var = (com1) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = com1Var.f9276a;
            if ((i4 & 1) == 0) {
                break;
            }
            iB += measuredHeight + ((LinearLayout.LayoutParams) com1Var).topMargin + ((LinearLayout.LayoutParams) com1Var).bottomMargin;
            if (i3 == 0 && y.x(childAt)) {
                iB -= getTopInset();
            }
            if ((i4 & 2) != 0) {
                iB -= y.B(childAt);
                break;
            }
        }
        int iMax = Math.max(0, iB);
        this.f9258b = iMax;
        return iMax;
    }

    public int getUpNestedPreScrollRange() {
        return getTotalScrollRange();
    }

    public boolean h() {
        return this.f3286b;
    }

    public final boolean i() {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            if (((com1) getChildAt(i2).getLayoutParams()).e()) {
                return true;
            }
        }
        return false;
    }

    public boolean j() {
        return getTotalScrollRange() != 0;
    }

    public final void k() {
        Behavior behavior = this.f3281a;
        BaseBehavior.com1 com1VarT0 = (behavior == null || this.f9258b == -1 || this.f9261e != 0) ? null : behavior.t0(COM2.aux.f5689a, this);
        this.f9258b = -1;
        this.f9259c = -1;
        this.f9260d = -1;
        if (com1VarT0 != null) {
            this.f3281a.s0(com1VarT0, false);
        }
    }

    public boolean l() {
        return this.f3290f;
    }

    public void m(int i2) {
        this.f9257a = i2;
        if (!willNotDraw()) {
            y.f0(this);
        }
        List<con> list = this.f3283a;
        if (list != null) {
            int size = list.size();
            for (int i3 = 0; i3 < size; i3++) {
                con conVar = this.f3283a.get(i3);
                if (conVar != null) {
                    conVar.a(this, i2);
                }
            }
        }
    }

    public void n() {
        this.f9261e = 0;
    }

    public void o(boolean z2, boolean z3) {
        p(z2, z3, true);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        com4.e(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public int[] onCreateDrawableState(int i2) {
        if (this.f3284a == null) {
            this.f3284a = new int[4];
        }
        int[] iArr = this.f3284a;
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i2 + iArr.length);
        boolean z2 = this.f3288d;
        int i3 = x3.I;
        if (!z2) {
            i3 = -i3;
        }
        iArr[0] = i3;
        iArr[1] = (z2 && this.f3289e) ? x3.J : -x3.J;
        int i4 = x3.G;
        if (!z2) {
            i4 = -i4;
        }
        iArr[2] = i4;
        iArr[3] = (z2 && this.f3289e) ? x3.F : -x3.F;
        return View.mergeDrawableStates(iArrOnCreateDrawableState, iArr);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        c();
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        boolean z3 = true;
        if (y.x(this) && v()) {
            int topInset = getTopInset();
            for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
                y.Z(getChildAt(childCount), topInset);
            }
        }
        k();
        this.f3286b = false;
        int childCount2 = getChildCount();
        for (int i6 = 0; i6 < childCount2; i6++) {
            if (((com1) getChildAt(i6).getLayoutParams()).d() != null) {
                this.f3286b = true;
                break;
            }
        }
        Drawable drawable = this.f3280a;
        if (drawable != null) {
            drawable.setBounds(0, 0, getWidth(), getTopInset());
        }
        if (this.f3287c) {
            return;
        }
        if (!this.f3290f && !i()) {
            z3 = false;
        }
        q(z3);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i3);
        if (mode != 1073741824 && y.x(this) && v()) {
            int measuredHeight = getMeasuredHeight();
            if (mode == Integer.MIN_VALUE) {
                measuredHeight = b0.b(getMeasuredHeight() + getTopInset(), 0, View.MeasureSpec.getSize(i3));
            } else if (mode == 0) {
                measuredHeight += getTopInset();
            }
            setMeasuredDimension(getMeasuredWidth(), measuredHeight);
        }
        k();
    }

    public final void p(boolean z2, boolean z3, boolean z4) {
        this.f9261e = (z2 ? 1 : 2) | (z3 ? 4 : 0) | (z4 ? 8 : 0);
        requestLayout();
    }

    public final boolean q(boolean z2) {
        if (this.f3288d == z2) {
            return false;
        }
        this.f3288d = z2;
        refreshDrawableState();
        return true;
    }

    public boolean r(boolean z2) {
        return s(z2, !this.f3287c);
    }

    public boolean s(boolean z2, boolean z3) {
        if (!z3 || this.f3289e == z2) {
            return false;
        }
        this.f3289e = z2;
        refreshDrawableState();
        if (!this.f3290f || !(getBackground() instanceof com3)) {
            return true;
        }
        w((com3) getBackground(), z2);
        return true;
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        com4.d(this, f2);
    }

    public void setExpanded(boolean z2) {
        o(z2, y.S(this));
    }

    public void setLiftOnScroll(boolean z2) {
        this.f3290f = z2;
    }

    public void setLiftOnScrollTargetViewId(int i2) {
        this.f9262f = i2;
        c();
    }

    public void setLiftableOverrideEnabled(boolean z2) {
        this.f3287c = z2;
    }

    @Override // android.widget.LinearLayout
    public void setOrientation(int i2) {
        if (i2 != 1) {
            throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
        }
        super.setOrientation(i2);
    }

    public void setStatusBarForeground(Drawable drawable) {
        Drawable drawable2 = this.f3280a;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f3280a = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f3280a.setState(getDrawableState());
                }
                p080cOm1.y.g(this.f3280a, y.A(this));
                this.f3280a.setVisible(getVisibility() == 0, false);
                this.f3280a.setCallback(this);
            }
            x();
            y.f0(this);
        }
    }

    public void setStatusBarForegroundColor(int i2) {
        setStatusBarForeground(new ColorDrawable(i2));
    }

    public void setStatusBarForegroundResource(int i2) {
        setStatusBarForeground(AUX.aux.b(getContext(), i2));
    }

    @Deprecated
    public void setTargetElevation(float f2) {
        lpt4.a(this, f2);
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        boolean z2 = i2 == 0;
        Drawable drawable = this.f3280a;
        if (drawable != null) {
            drawable.setVisible(z2, false);
        }
    }

    public final boolean t() {
        return this.f3280a != null && getTopInset() > 0;
    }

    public boolean u(View view) {
        View viewD = d(view);
        if (viewD != null) {
            view = viewD;
        }
        return view != null && (view.canScrollVertically(-1) || view.getScrollY() > 0);
    }

    public final boolean v() {
        if (getChildCount() <= 0) {
            return false;
        }
        View childAt = getChildAt(0);
        return (childAt.getVisibility() == 8 || y.x(childAt)) ? false : true;
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f3280a;
    }

    public final void w(com3 com3Var, boolean z2) {
        float dimension = getResources().getDimension(z3.f9058a);
        float f2 = z2 ? 0.0f : dimension;
        if (!z2) {
            dimension = 0.0f;
        }
        ValueAnimator valueAnimator = this.f3279a;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(f2, dimension);
        this.f3279a = valueAnimatorOfFloat;
        valueAnimatorOfFloat.setDuration(getResources().getInteger(c4.f8904a));
        this.f3279a.setInterpolator(COM6.aux.f5700a);
        this.f3279a.addUpdateListener(new aux(com3Var));
        this.f3279a.start();
    }

    public final void x() {
        setWillNotDraw(!t());
    }

    public static class com1 extends LinearLayout.LayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9276a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Interpolator f3303a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public nul f3304a;

        public com1(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f9276a = 1;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3143m);
            this.f9276a = typedArrayObtainStyledAttributes.getInt(h4.f8983b, 0);
            f(a(typedArrayObtainStyledAttributes.getInt(h4.f8981a, 0)));
            int i2 = h4.f8985c;
            if (typedArrayObtainStyledAttributes.hasValue(i2)) {
                this.f3303a = AnimationUtils.loadInterpolator(context, typedArrayObtainStyledAttributes.getResourceId(i2, 0));
            }
            typedArrayObtainStyledAttributes.recycle();
        }

        public final nul a(int i2) {
            if (i2 != 1) {
                return null;
            }
            return new prn();
        }

        public nul b() {
            return this.f3304a;
        }

        public int c() {
            return this.f9276a;
        }

        public Interpolator d() {
            return this.f3303a;
        }

        public boolean e() {
            int i2 = this.f9276a;
            return (i2 & 1) == 1 && (i2 & 10) != 0;
        }

        public void f(nul nulVar) {
            this.f3304a = nulVar;
        }

        public com1(int i2, int i3) {
            super(i2, i3);
            this.f9276a = 1;
        }

        public com1(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f9276a = 1;
        }

        public com1(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f9276a = 1;
        }

        public com1(LinearLayout.LayoutParams layoutParams) {
            super(layoutParams);
            this.f9276a = 1;
        }
    }
}
