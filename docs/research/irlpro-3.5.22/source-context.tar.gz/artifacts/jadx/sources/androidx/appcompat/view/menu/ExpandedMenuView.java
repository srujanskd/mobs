package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import p022CoN.q0;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements com1.con, com6, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f7781a = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f1810a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1811a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listViewStyle);
    }

    @Override // androidx.appcompat.view.menu.com1.con
    public boolean a(com3 com3Var) {
        return this.f1811a.L(com3Var, 0);
    }

    @Override // androidx.appcompat.view.menu.com6
    public void c(com1 com1Var) {
        this.f1811a = com1Var;
    }

    public int getWindowAnimations() {
        return this.f1810a;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        a((com3) getAdapter().getItem(i2));
    }

    public ExpandedMenuView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        q0 q0VarV = q0.v(context, attributeSet, f7781a, i2, 0);
        if (q0VarV.s(0)) {
            setBackgroundDrawable(q0VarV.g(0));
        }
        if (q0VarV.s(1)) {
            setDivider(q0VarV.g(1));
        }
        q0VarV.w();
    }
}
