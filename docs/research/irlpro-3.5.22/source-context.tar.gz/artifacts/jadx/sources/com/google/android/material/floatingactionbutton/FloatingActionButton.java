package com.google.android.material.floatingactionbutton;

import COM6.com4;
import COM6.com7;
import COM9.lpt1;
import android.animation.Animator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.util.List;
import p022CoN.b;
import p024Com2.y;
import p051Lpt1.o;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.z3;
import p077cOM8.com1;
import p078cOM9.lpt7;
import p101com2.u2;
import p108com9.j;
import p108com9.w;

/* JADX INFO: loaded from: classes.dex */
public class FloatingActionButton extends w implements com1, lpt1, CoordinatorLayout.con {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int f9491f = g4.f8963h;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f9492a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3527a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f3528a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f3529a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.floatingactionbutton.aux f3530a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f9493b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f3531b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public PorterDuff.Mode f3532b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Rect f3533b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3534b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9494c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ColorStateList f3535c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9495d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9496e;

    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.BaseBehavior
        /* JADX INFO: renamed from: E */
        public /* bridge */ /* synthetic */ boolean b(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            return super.b(coordinatorLayout, floatingActionButton, rect);
        }

        @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.BaseBehavior
        /* JADX INFO: renamed from: H */
        public /* bridge */ /* synthetic */ boolean h(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            return super.h(coordinatorLayout, floatingActionButton, view);
        }

        @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.BaseBehavior
        /* JADX INFO: renamed from: I */
        public /* bridge */ /* synthetic */ boolean l(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i2) {
            return super.l(coordinatorLayout, floatingActionButton, i2);
        }

        @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.BaseBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public /* bridge */ /* synthetic */ void g(CoordinatorLayout.com2 com2Var) {
            super.g(com2Var);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public class aux implements com.google.android.material.floatingactionbutton.aux.com6 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ con f9498a;

        public aux(con conVar) {
            this.f9498a = conVar;
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com6
        public void a() {
            this.f9498a.a(FloatingActionButton.this);
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com6
        public void b() {
            this.f9498a.b(FloatingActionButton.this);
        }
    }

    public static abstract class con {
        public void a(FloatingActionButton floatingActionButton) {
        }

        public void b(FloatingActionButton floatingActionButton) {
        }
    }

    public class nul implements lpt7 {
        public nul() {
        }

        @Override // p078cOM9.lpt7
        public void a(int i2, int i3, int i4, int i5) {
            FloatingActionButton.this.f3529a.set(i2, i3, i4, i5);
            FloatingActionButton floatingActionButton = FloatingActionButton.this;
            floatingActionButton.setPadding(i2 + floatingActionButton.f9495d, i3 + FloatingActionButton.this.f9495d, i4 + FloatingActionButton.this.f9495d, i5 + FloatingActionButton.this.f9495d);
        }

        @Override // p078cOM9.lpt7
        public boolean b() {
            return FloatingActionButton.this.f3534b;
        }

        @Override // p078cOM9.lpt7
        public void c(Drawable drawable) {
            if (drawable != null) {
                FloatingActionButton.super.setBackgroundDrawable(drawable);
            }
        }
    }

    public class prn<T extends FloatingActionButton> implements com.google.android.material.floatingactionbutton.aux.com5 {
        public prn(com7<T> com7Var) {
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com5
        public void a() {
            throw null;
        }

        @Override // com.google.android.material.floatingactionbutton.aux.com5
        public void b() {
            throw null;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof prn)) {
                return false;
            }
            ((prn) obj).getClass();
            throw null;
        }

        public int hashCode() {
            throw null;
        }
    }

    private com.google.android.material.floatingactionbutton.aux getImpl() {
        if (this.f3530a == null) {
            this.f3530a = h();
        }
        return this.f3530a;
    }

    public static int r(int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        if (mode == Integer.MIN_VALUE) {
            return Math.min(i2, size);
        }
        if (mode == 0) {
            return i2;
        }
        if (mode == 1073741824) {
            return size;
        }
        throw new IllegalArgumentException();
    }

    @Override // p077cOM8.com1
    public boolean a() {
        throw null;
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        getImpl().C(getDrawableState());
    }

    public void e(Animator.AnimatorListener animatorListener) {
        getImpl().e(animatorListener);
    }

    public void f(Animator.AnimatorListener animatorListener) {
        getImpl().f(animatorListener);
    }

    public void g(com7<? extends FloatingActionButton> com7Var) {
        getImpl().g(new prn(com7Var));
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return this.f3527a;
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return this.f3528a;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.con
    public CoordinatorLayout.nul<FloatingActionButton> getBehavior() {
        return new Behavior();
    }

    public float getCompatElevation() {
        return getImpl().m();
    }

    public float getCompatHoveredFocusedTranslationZ() {
        return getImpl().p();
    }

    public float getCompatPressedTranslationZ() {
        return getImpl().s();
    }

    public Drawable getContentBackground() {
        return getImpl().l();
    }

    public int getCustomSize() {
        return this.f9494c;
    }

    public int getExpandedComponentIdHint() {
        throw null;
    }

    public com4 getHideMotionSpec() {
        return getImpl().o();
    }

    @Deprecated
    public int getRippleColor() {
        ColorStateList colorStateList = this.f3535c;
        if (colorStateList != null) {
            return colorStateList.getDefaultColor();
        }
        return 0;
    }

    public ColorStateList getRippleColorStateList() {
        return this.f3535c;
    }

    public COM9.com7 getShapeAppearanceModel() {
        return (COM9.com7) u2.f(getImpl().t());
    }

    public com4 getShowMotionSpec() {
        return getImpl().u();
    }

    public int getSize() {
        return this.f9493b;
    }

    public int getSizeDimension() {
        return k(this.f9493b);
    }

    public ColorStateList getSupportBackgroundTintList() {
        return getBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return getBackgroundTintMode();
    }

    public ColorStateList getSupportImageTintList() {
        return this.f3531b;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        return this.f3532b;
    }

    public boolean getUseCompatPadding() {
        return this.f3534b;
    }

    public final com.google.android.material.floatingactionbutton.aux h() {
        return new COM8.aux(this, new nul());
    }

    @Deprecated
    public boolean i(Rect rect) {
        if (!y.S(this)) {
            return false;
        }
        rect.set(0, 0, getWidth(), getHeight());
        p(rect);
        return true;
    }

    public void j(Rect rect) {
        rect.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
        p(rect);
    }

    @Override // android.widget.ImageView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        getImpl().y();
    }

    public final int k(int i2) {
        int i3 = this.f9494c;
        if (i3 != 0) {
            return i3;
        }
        Resources resources = getResources();
        if (i2 != -1) {
            return i2 != 1 ? resources.getDimensionPixelSize(z3.f9061d) : resources.getDimensionPixelSize(z3.f9060c);
        }
        return Math.max(resources.getConfiguration().screenWidthDp, resources.getConfiguration().screenHeightDp) < 470 ? k(1) : k(0);
    }

    public void l(con conVar) {
        m(conVar, true);
    }

    public void m(con conVar, boolean z2) {
        getImpl().v(u(conVar), z2);
    }

    public boolean n() {
        return getImpl().w();
    }

    public boolean o() {
        return getImpl().x();
    }

    @Override // android.widget.ImageView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getImpl().z();
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getImpl().B();
    }

    @Override // android.widget.ImageView, android.view.View
    public void onMeasure(int i2, int i3) {
        int sizeDimension = getSizeDimension();
        this.f9495d = (sizeDimension - this.f9496e) / 2;
        getImpl().c0();
        int iMin = Math.min(r(sizeDimension, i2), r(sizeDimension, i3));
        Rect rect = this.f3529a;
        setMeasuredDimension(rect.left + iMin + rect.right, iMin + rect.top + rect.bottom);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof o)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        o oVar = (o) parcelable;
        super.onRestoreInstanceState(oVar.k());
        throw null;
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState = super.onSaveInstanceState();
        if (parcelableOnSaveInstanceState == null) {
            parcelableOnSaveInstanceState = new Bundle();
        }
        new o(parcelableOnSaveInstanceState);
        throw null;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0 && i(this.f3533b) && !this.f3533b.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
            return false;
        }
        return super.onTouchEvent(motionEvent);
    }

    public final void p(Rect rect) {
        int i2 = rect.left;
        Rect rect2 = this.f3529a;
        rect.left = i2 + rect2.left;
        rect.top += rect2.top;
        rect.right -= rect2.right;
        rect.bottom -= rect2.bottom;
    }

    public final void q() {
        Drawable drawable = getDrawable();
        if (drawable == null) {
            return;
        }
        ColorStateList colorStateList = this.f3531b;
        if (colorStateList == null) {
            p080cOm1.y.a(drawable);
            return;
        }
        int colorForState = colorStateList.getColorForState(getDrawableState(), 0);
        PorterDuff.Mode mode = this.f3532b;
        if (mode == null) {
            mode = PorterDuff.Mode.SRC_IN;
        }
        drawable.mutate().setColorFilter(p022CoN.lpt7.e(colorForState, mode));
    }

    public void s(con conVar) {
        t(conVar, true);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f3527a != colorStateList) {
            this.f3527a = colorStateList;
            getImpl().J(colorStateList);
        }
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        if (this.f3528a != mode) {
            this.f3528a = mode;
            getImpl().K(mode);
        }
    }

    public void setCompatElevation(float f2) {
        getImpl().L(f2);
    }

    public void setCompatElevationResource(int i2) {
        setCompatElevation(getResources().getDimension(i2));
    }

    public void setCompatHoveredFocusedTranslationZ(float f2) {
        getImpl().O(f2);
    }

    public void setCompatHoveredFocusedTranslationZResource(int i2) {
        setCompatHoveredFocusedTranslationZ(getResources().getDimension(i2));
    }

    public void setCompatPressedTranslationZ(float f2) {
        getImpl().R(f2);
    }

    public void setCompatPressedTranslationZResource(int i2) {
        setCompatPressedTranslationZ(getResources().getDimension(i2));
    }

    public void setCustomSize(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("Custom size must be non-negative");
        }
        if (i2 != this.f9494c) {
            this.f9494c = i2;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        getImpl().d0(f2);
    }

    public void setEnsureMinTouchTargetSize(boolean z2) {
        if (z2 != getImpl().n()) {
            getImpl().M(z2);
            requestLayout();
        }
    }

    public void setExpandedComponentIdHint(int i2) {
        throw null;
    }

    public void setHideMotionSpec(com4 com4Var) {
        getImpl().N(com4Var);
    }

    public void setHideMotionSpecResource(int i2) {
        setHideMotionSpec(com4.c(getContext(), i2));
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        if (getDrawable() != drawable) {
            super.setImageDrawable(drawable);
            getImpl().b0();
            if (this.f3531b != null) {
                q();
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        this.f9492a.i(i2);
        q();
    }

    public void setMaxImageSize(int i2) {
        this.f9496e = i2;
        getImpl().Q(i2);
    }

    public void setRippleColor(int i2) {
        setRippleColor(ColorStateList.valueOf(i2));
    }

    @Override // android.view.View
    public void setScaleX(float f2) {
        super.setScaleX(f2);
        getImpl().G();
    }

    @Override // android.view.View
    public void setScaleY(float f2) {
        super.setScaleY(f2);
        getImpl().G();
    }

    public void setShadowPaddingEnabled(boolean z2) {
        getImpl().T(z2);
    }

    @Override // COM9.lpt1
    public void setShapeAppearanceModel(COM9.com7 com7Var) {
        getImpl().U(com7Var);
    }

    public void setShowMotionSpec(com4 com4Var) {
        getImpl().V(com4Var);
    }

    public void setShowMotionSpecResource(int i2) {
        setShowMotionSpec(com4.c(getContext(), i2));
    }

    public void setSize(int i2) {
        this.f9494c = 0;
        if (i2 != this.f9493b) {
            this.f9493b = i2;
            requestLayout();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        setBackgroundTintList(colorStateList);
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        setBackgroundTintMode(mode);
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f3531b != colorStateList) {
            this.f3531b = colorStateList;
            q();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        if (this.f3532b != mode) {
            this.f3532b = mode;
            q();
        }
    }

    @Override // android.view.View
    public void setTranslationX(float f2) {
        super.setTranslationX(f2);
        getImpl().H();
    }

    @Override // android.view.View
    public void setTranslationY(float f2) {
        super.setTranslationY(f2);
        getImpl().H();
    }

    @Override // android.view.View
    public void setTranslationZ(float f2) {
        super.setTranslationZ(f2);
        getImpl().H();
    }

    public void setUseCompatPadding(boolean z2) {
        if (this.f3534b != z2) {
            this.f3534b = z2;
            getImpl().A();
        }
    }

    @Override // p108com9.w, android.widget.ImageView, android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
    }

    public void t(con conVar, boolean z2) {
        getImpl().Z(u(conVar), z2);
    }

    public final com.google.android.material.floatingactionbutton.aux.com6 u(con conVar) {
        if (conVar == null) {
            return null;
        }
        return new aux(conVar);
    }

    public static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.nul<T> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public Rect f9497a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public con f3536a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f3537a;

        public BaseBehavior() {
            this.f3537a = true;
        }

        public static boolean F(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.com2) {
                return ((CoordinatorLayout.com2) layoutParams).f() instanceof BottomSheetBehavior;
            }
            return false;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: E, reason: merged with bridge method [inline-methods] */
        public boolean b(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            Rect rect2 = floatingActionButton.f3529a;
            rect.set(floatingActionButton.getLeft() + rect2.left, floatingActionButton.getTop() + rect2.top, floatingActionButton.getRight() - rect2.right, floatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        public final void G(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton) {
            int i2;
            Rect rect = floatingActionButton.f3529a;
            if (rect == null || rect.centerX() <= 0 || rect.centerY() <= 0) {
                return;
            }
            CoordinatorLayout.com2 com2Var = (CoordinatorLayout.com2) floatingActionButton.getLayoutParams();
            int i3 = 0;
            if (floatingActionButton.getRight() >= coordinatorLayout.getWidth() - ((ViewGroup.MarginLayoutParams) com2Var).rightMargin) {
                i2 = rect.right;
            } else {
                i2 = floatingActionButton.getLeft() <= ((ViewGroup.MarginLayoutParams) com2Var).leftMargin ? -rect.left : 0;
            }
            if (floatingActionButton.getBottom() >= coordinatorLayout.getHeight() - ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin) {
                i3 = rect.bottom;
            } else if (floatingActionButton.getTop() <= ((ViewGroup.MarginLayoutParams) com2Var).topMargin) {
                i3 = -rect.top;
            }
            if (i3 != 0) {
                y.Z(floatingActionButton, i3);
            }
            if (i2 != 0) {
                y.Y(floatingActionButton, i2);
            }
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: H, reason: merged with bridge method [inline-methods] */
        public boolean h(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                K(coordinatorLayout, (AppBarLayout) view, floatingActionButton);
                return false;
            }
            if (!F(view)) {
                return false;
            }
            L(view, floatingActionButton);
            return false;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: I, reason: merged with bridge method [inline-methods] */
        public boolean l(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i2) {
            List<View> listR = coordinatorLayout.r(floatingActionButton);
            int size = listR.size();
            for (int i3 = 0; i3 < size; i3++) {
                View view = listR.get(i3);
                if (!(view instanceof AppBarLayout)) {
                    if (F(view) && L(view, floatingActionButton)) {
                        break;
                    }
                } else {
                    if (K(coordinatorLayout, (AppBarLayout) view, floatingActionButton)) {
                        break;
                    }
                }
            }
            coordinatorLayout.I(floatingActionButton, i2);
            G(coordinatorLayout, floatingActionButton);
            return true;
        }

        public final boolean J(View view, FloatingActionButton floatingActionButton) {
            return this.f3537a && ((CoordinatorLayout.com2) floatingActionButton.getLayoutParams()).e() == view.getId() && floatingActionButton.getUserSetVisibility() == 0;
        }

        public final boolean K(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!J(appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.f9497a == null) {
                this.f9497a = new Rect();
            }
            Rect rect = this.f9497a;
            j.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.m(this.f3536a, false);
                return true;
            }
            floatingActionButton.t(this.f3536a, false);
            return true;
        }

        public final boolean L(View view, FloatingActionButton floatingActionButton) {
            if (!J(view, floatingActionButton)) {
                return false;
            }
            if (view.getTop() < (floatingActionButton.getHeight() / 2) + ((ViewGroup.MarginLayoutParams) ((CoordinatorLayout.com2) floatingActionButton.getLayoutParams())).topMargin) {
                floatingActionButton.m(this.f3536a, false);
                return true;
            }
            floatingActionButton.t(this.f3536a, false);
            return true;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public void g(CoordinatorLayout.com2 com2Var) {
            if (com2Var.f8163f == 0) {
                com2Var.f8163f = 80;
            }
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3095U);
            this.f3537a = typedArrayObtainStyledAttributes.getBoolean(h4.M0, true);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (this.f3535c != colorStateList) {
            this.f3535c = colorStateList;
            getImpl().S(this.f3535c);
        }
    }
}
