package PRN;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Process;
import java.io.File;
import java.util.concurrent.Executor;
import p100com1.h0;
import p101com2.p2;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"PrivateConstructorForUtilityClass"})
public class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f7475a = new Object();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f7476b = new Object();

    /* JADX INFO: renamed from: PRN.aux$aux, reason: collision with other inner class name */
    public static class C0019aux {
        public static void a(Context context, Intent[] intentArr, Bundle bundle) {
            context.startActivities(intentArr, bundle);
        }

        public static void b(Context context, Intent intent, Bundle bundle) {
            context.startActivity(intent, bundle);
        }
    }

    public static class com1 {
        public static Executor a(Context context) {
            return context.getMainExecutor();
        }
    }

    public static class con {
        public static File a(Context context) {
            return context.getCodeCacheDir();
        }

        public static Drawable b(Context context, int i2) {
            return context.getDrawable(i2);
        }

        public static File c(Context context) {
            return context.getNoBackupFilesDir();
        }
    }

    public static class nul {
        public static int a(Context context, int i2) {
            return context.getColor(i2);
        }

        public static <T> T b(Context context, Class<T> cls) {
            return (T) context.getSystemService(cls);
        }

        public static String c(Context context, Class<?> cls) {
            return context.getSystemServiceName(cls);
        }
    }

    public static class prn {
        public static Context a(Context context) {
            return context.createDeviceProtectedStorageContext();
        }

        public static File b(Context context) {
            return context.getDataDir();
        }

        public static boolean c(Context context) {
            return context.isDeviceProtectedStorage();
        }
    }

    public static int a(Context context, String str) {
        p2.d(str, "permission must be non-null");
        return context.checkPermission(str, Process.myPid(), Process.myUid());
    }

    public static Context b(Context context) {
        return prn.a(context);
    }

    public static int c(Context context, int i2) {
        return nul.a(context, i2);
    }

    public static ColorStateList d(Context context, int i2) {
        return h0.e(context.getResources(), i2, context.getTheme());
    }

    public static Drawable e(Context context, int i2) {
        return con.b(context, i2);
    }

    public static Executor f(Context context) {
        return com1.a(context);
    }

    public static <T> T g(Context context, Class<T> cls) {
        return (T) nul.b(context, cls);
    }

    public static boolean h(Context context, Intent[] intentArr, Bundle bundle) {
        C0019aux.a(context, intentArr, bundle);
        return true;
    }

    public static void i(Context context, Intent intent, Bundle bundle) {
        C0019aux.b(context, intent, bundle);
    }
}
