package androidx.lifecycle;

import COM3.lpt2;
import p079cON.y0;

/* JADX INFO: loaded from: classes.dex */
public abstract class LiveData<T> {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Object f8371d = new Object();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2592a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2593a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8373b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public volatile Object f2594b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2595b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile Object f8374c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2596c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Object f2591a = new Object();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CON.con<lpt2<? super T>, LiveData<T>.nul> f2590a = new CON.con<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8372a = 0;

    public class LifecycleBoundObserver extends LiveData<T>.nul implements prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final COM3.com7 f8375a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ LiveData f8376b;

        @Override // androidx.lifecycle.prn
        public void f(COM3.com7 com7Var, androidx.lifecycle.nul.con conVar) {
            androidx.lifecycle.nul.EnumC0039nul enumC0039nulB = this.f8375a.getLifecycle().b();
            if (enumC0039nulB == androidx.lifecycle.nul.EnumC0039nul.DESTROYED) {
                this.f8376b.h(((nul) this).f2597a);
                return;
            }
            androidx.lifecycle.nul.EnumC0039nul enumC0039nul = null;
            while (enumC0039nul != enumC0039nulB) {
                h(j());
                enumC0039nul = enumC0039nulB;
                enumC0039nulB = this.f8375a.getLifecycle().b();
            }
        }

        @Override // androidx.lifecycle.LiveData.nul
        public void i() {
            this.f8375a.getLifecycle().c(this);
        }

        @Override // androidx.lifecycle.LiveData.nul
        public boolean j() {
            return this.f8375a.getLifecycle().b().a(androidx.lifecycle.nul.EnumC0039nul.STARTED);
        }
    }

    public class aux implements Runnable {
        public aux() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.lang.Runnable
        public void run() {
            Object obj;
            synchronized (LiveData.this.f2591a) {
                obj = LiveData.this.f8374c;
                LiveData.this.f8374c = LiveData.f8371d;
            }
            LiveData.this.i(obj);
        }
    }

    public class con extends LiveData<T>.nul {
        public con(lpt2<? super T> lpt2Var) {
            super(lpt2Var);
        }

        @Override // androidx.lifecycle.LiveData.nul
        public boolean j() {
            return true;
        }
    }

    public abstract class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8379a = -1;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final lpt2<? super T> f2597a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8380b;

        public nul(lpt2<? super T> lpt2Var) {
            this.f2597a = lpt2Var;
        }

        public void h(boolean z2) {
            if (z2 == this.f8380b) {
                return;
            }
            this.f8380b = z2;
            LiveData.this.b(z2 ? 1 : -1);
            if (this.f8380b) {
                LiveData.this.d(this);
            }
        }

        public void i() {
        }

        public abstract boolean j();
    }

    public LiveData() {
        Object obj = f8371d;
        this.f8374c = obj;
        this.f2592a = new aux();
        this.f2594b = obj;
        this.f8373b = -1;
    }

    public static void a(String str) {
        if (y0.d().b()) {
            return;
        }
        throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
    }

    public void b(int i2) {
        int i3 = this.f8372a;
        this.f8372a = i2 + i3;
        if (this.f2593a) {
            return;
        }
        this.f2593a = true;
        while (true) {
            try {
                int i4 = this.f8372a;
                if (i3 == i4) {
                    this.f2593a = false;
                    return;
                }
                boolean z2 = i3 == 0 && i4 > 0;
                boolean z3 = i3 > 0 && i4 == 0;
                if (z2) {
                    f();
                } else if (z3) {
                    g();
                }
                i3 = i4;
            } catch (Throwable th) {
                this.f2593a = false;
                throw th;
            }
        }
    }

    public final void c(LiveData<T>.nul nulVar) {
        if (nulVar.f8380b) {
            if (!nulVar.j()) {
                nulVar.h(false);
                return;
            }
            int i2 = nulVar.f8379a;
            int i3 = this.f8373b;
            if (i2 >= i3) {
                return;
            }
            nulVar.f8379a = i3;
            nulVar.f2597a.a((Object) this.f2594b);
        }
    }

    public void d(LiveData<T>.nul nulVar) {
        if (this.f2595b) {
            this.f2596c = true;
            return;
        }
        this.f2595b = true;
        do {
            this.f2596c = false;
            if (nulVar != null) {
                c(nulVar);
                nulVar = null;
            } else {
                CON.con<lpt2<? super T>, LiveData<T>.nul>.prn prnVarC = this.f2590a.c();
                while (prnVarC.hasNext()) {
                    c((nul) prnVarC.next().getValue());
                    if (this.f2596c) {
                        break;
                    }
                }
            }
        } while (this.f2596c);
        this.f2595b = false;
    }

    public void e(lpt2<? super T> lpt2Var) {
        a("observeForever");
        con conVar = new con(lpt2Var);
        LiveData<T>.nul nulVarF = this.f2590a.f(lpt2Var, conVar);
        if (nulVarF instanceof LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (nulVarF != null) {
            return;
        }
        conVar.h(true);
    }

    public void f() {
    }

    public void g() {
    }

    public void h(lpt2<? super T> lpt2Var) {
        a("removeObserver");
        LiveData<T>.nul nulVarG = this.f2590a.g(lpt2Var);
        if (nulVarG == null) {
            return;
        }
        nulVarG.i();
        nulVarG.h(false);
    }

    public void i(T t2) {
        a("setValue");
        this.f8373b++;
        this.f2594b = t2;
        d(null);
    }
}
