package com.google.android.material.tabs;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.preference.Preference;
import androidx.viewpager.widget.ViewPager;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import p001AuX.lpt3;
import p014CoM2.lpt1;
import p021CoM9.lpt4;
import p022CoN.s0;
import p024Com2.i;
import p024Com2.w;
import p075cOM6.d4;
import p075cOM6.f4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.z3;
import p080cOm1.y;
import p081cOm2.e2;
import p098coM9.b;
import p101com2.r2;
import p101com2.s2;
import p101com2.t2;
import p108com9.v;
import p119lPt1.r;
import p119lPt1.s;
import p119lPt1.t;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
@ViewPager.com1
public class TabLayout extends HorizontalScrollView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f9570a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3612a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM5.aux f3613a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ValueAnimator f3614a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3615a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public DataSetObserver f3616a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f3617a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f3618a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewPager f3619a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com2 f3620a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f3621a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com4 f3622a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f3623a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f3624a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.tabs.aux f3625a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final r2<com5> f3626a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<com3> f3627a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public float f3628b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3629b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f3630b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public nul f3631b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final ArrayList<nul> f3632b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3633b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9571c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ColorStateList f3634c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3635c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9572d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3636d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9573e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f3637e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f9574f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f9575g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f9576h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f9577i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f9578j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f9579k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f9580l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f9581m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f9582n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f9583o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f9584p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f9585q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f9586r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final int f9569s = g4.f8964i;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final r2<com3> f9568b = new t2(16);

    public class aux implements ValueAnimator.AnimatorUpdateListener {
        public aux() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TabLayout.this.scrollTo(((Integer) valueAnimator.getAnimatedValue()).intValue(), 0);
        }
    }

    public class com1 extends DataSetObserver {
        public com1() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            TabLayout.this.C();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            TabLayout.this.C();
        }
    }

    public class com2 extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f9589a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f3638a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ValueAnimator f3639a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f9590b;

        public class aux implements ValueAnimator.AnimatorUpdateListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ View f9591a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ View f9592b;

            public aux(View view, View view2) {
                this.f9591a = view;
                this.f9592b = view2;
            }

            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                com2.this.h(this.f9591a, this.f9592b, valueAnimator.getAnimatedFraction());
            }
        }

        public class con extends AnimatorListenerAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ int f9593a;

            public con(int i2) {
                this.f9593a = i2;
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                com2.this.f3638a = this.f9593a;
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationStart(Animator animator) {
                com2.this.f3638a = this.f9593a;
            }
        }

        public com2(Context context) {
            super(context);
            this.f3638a = -1;
            this.f9590b = -1;
            setWillNotDraw(false);
        }

        public void c(int i2, int i3) {
            ValueAnimator valueAnimator = this.f3639a;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                this.f3639a.cancel();
            }
            i(true, i2, i3);
        }

        public boolean d() {
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                if (getChildAt(i2).getWidth() <= 0) {
                    return true;
                }
            }
            return false;
        }

        @Override // android.view.View
        public void draw(Canvas canvas) {
            int height;
            int iHeight = TabLayout.this.f3618a.getBounds().height();
            if (iHeight < 0) {
                iHeight = TabLayout.this.f3618a.getIntrinsicHeight();
            }
            int i2 = TabLayout.this.f9583o;
            if (i2 == 0) {
                height = getHeight() - iHeight;
                iHeight = getHeight();
            } else if (i2 != 1) {
                height = 0;
                if (i2 != 2) {
                    iHeight = i2 != 3 ? 0 : getHeight();
                }
            } else {
                height = (getHeight() - iHeight) / 2;
                iHeight = (getHeight() + iHeight) / 2;
            }
            if (TabLayout.this.f3618a.getBounds().width() > 0) {
                Rect bounds = TabLayout.this.f3618a.getBounds();
                TabLayout.this.f3618a.setBounds(bounds.left, height, bounds.right, iHeight);
                TabLayout tabLayout = TabLayout.this;
                Drawable drawableL = tabLayout.f3618a;
                if (tabLayout.f9574f != 0) {
                    drawableL = y.l(drawableL);
                    y.h(drawableL, TabLayout.this.f9574f);
                } else {
                    y.i(drawableL, null);
                }
                drawableL.draw(canvas);
            }
            super.draw(canvas);
        }

        public final void e() {
            View childAt = getChildAt(this.f3638a);
            com.google.android.material.tabs.aux auxVar = TabLayout.this.f3625a;
            TabLayout tabLayout = TabLayout.this;
            auxVar.c(tabLayout, childAt, tabLayout.f3618a);
        }

        public void f(int i2, float f2) {
            ValueAnimator valueAnimator = this.f3639a;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                this.f3639a.cancel();
            }
            this.f3638a = i2;
            this.f9589a = f2;
            h(getChildAt(i2), getChildAt(this.f3638a + 1), this.f9589a);
        }

        public void g(int i2) {
            Rect bounds = TabLayout.this.f3618a.getBounds();
            TabLayout.this.f3618a.setBounds(bounds.left, 0, bounds.right, i2);
            requestLayout();
        }

        public final void h(View view, View view2, float f2) {
            if (view != null && view.getWidth() > 0) {
                com.google.android.material.tabs.aux auxVar = TabLayout.this.f3625a;
                TabLayout tabLayout = TabLayout.this;
                auxVar.d(tabLayout, view, view2, f2, tabLayout.f3618a);
            } else {
                Drawable drawable = TabLayout.this.f3618a;
                drawable.setBounds(-1, drawable.getBounds().top, -1, TabLayout.this.f3618a.getBounds().bottom);
            }
            p024Com2.y.f0(this);
        }

        public final void i(boolean z2, int i2, int i3) {
            View childAt = getChildAt(this.f3638a);
            View childAt2 = getChildAt(i2);
            if (childAt2 == null) {
                e();
                return;
            }
            aux auxVar = new aux(childAt, childAt2);
            if (!z2) {
                this.f3639a.removeAllUpdateListeners();
                this.f3639a.addUpdateListener(auxVar);
                return;
            }
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f3639a = valueAnimator;
            valueAnimator.setInterpolator(COM6.aux.f5701b);
            valueAnimator.setDuration(i3);
            valueAnimator.setFloatValues(0.0f, 1.0f);
            valueAnimator.addUpdateListener(auxVar);
            valueAnimator.addListener(new con(i2));
            valueAnimator.start();
        }

        @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
        public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
            super.onLayout(z2, i2, i3, i4, i5);
            ValueAnimator valueAnimator = this.f3639a;
            if (valueAnimator == null || !valueAnimator.isRunning()) {
                e();
            } else {
                i(false, this.f3638a, -1);
            }
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (View.MeasureSpec.getMode(i2) != 1073741824) {
                return;
            }
            TabLayout tabLayout = TabLayout.this;
            boolean z2 = true;
            if (tabLayout.f9581m == 1 || tabLayout.f9584p == 2) {
                int childCount = getChildCount();
                int iMax = 0;
                for (int i4 = 0; i4 < childCount; i4++) {
                    View childAt = getChildAt(i4);
                    if (childAt.getVisibility() == 0) {
                        iMax = Math.max(iMax, childAt.getMeasuredWidth());
                    }
                }
                if (iMax <= 0) {
                    return;
                }
                if (iMax * childCount <= getMeasuredWidth() - (((int) v.b(getContext(), 16)) * 2)) {
                    boolean z3 = false;
                    for (int i5 = 0; i5 < childCount; i5++) {
                        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getChildAt(i5).getLayoutParams();
                        if (layoutParams.width != iMax || layoutParams.weight != 0.0f) {
                            layoutParams.width = iMax;
                            layoutParams.weight = 0.0f;
                            z3 = true;
                        }
                    }
                    z2 = z3;
                } else {
                    TabLayout tabLayout2 = TabLayout.this;
                    tabLayout2.f9581m = 0;
                    tabLayout2.Q(false);
                }
                if (z2) {
                    super.onMeasure(i2, i3);
                }
            }
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onRtlPropertiesChanged(int i2) {
            super.onRtlPropertiesChanged(i2);
        }
    }

    public static class com3 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Drawable f3643a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f3644a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com5 f3645a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public TabLayout f3646a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public CharSequence f3647a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Object f3648a;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public CharSequence f3649b;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9594a = -1;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f9595b = 1;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f9596c = -1;

        public View e() {
            return this.f3644a;
        }

        public Drawable f() {
            return this.f3643a;
        }

        public int g() {
            return this.f9596c;
        }

        public int h() {
            return this.f9594a;
        }

        public int i() {
            return this.f9595b;
        }

        public CharSequence j() {
            return this.f3647a;
        }

        public boolean k() {
            TabLayout tabLayout = this.f3646a;
            if (tabLayout == null) {
                throw new IllegalArgumentException("Tab not attached to a TabLayout");
            }
            int selectedTabPosition = tabLayout.getSelectedTabPosition();
            return selectedTabPosition != -1 && selectedTabPosition == this.f9594a;
        }

        public void l() {
            this.f3646a = null;
            this.f3645a = null;
            this.f3648a = null;
            this.f3643a = null;
            this.f9596c = -1;
            this.f3647a = null;
            this.f3649b = null;
            this.f9594a = -1;
            this.f3644a = null;
        }

        public void m() {
            TabLayout tabLayout = this.f3646a;
            if (tabLayout == null) {
                throw new IllegalArgumentException("Tab not attached to a TabLayout");
            }
            tabLayout.H(this);
        }

        public com3 n(CharSequence charSequence) {
            this.f3649b = charSequence;
            v();
            return this;
        }

        public com3 o(int i2) {
            return p(LayoutInflater.from(this.f3645a.getContext()).inflate(i2, (ViewGroup) this.f3645a, false));
        }

        public com3 p(View view) {
            this.f3644a = view;
            v();
            return this;
        }

        public com3 q(Drawable drawable) {
            this.f3643a = drawable;
            TabLayout tabLayout = this.f3646a;
            if (tabLayout.f9581m == 1 || tabLayout.f9584p == 2) {
                tabLayout.Q(true);
            }
            v();
            if (p029Com7.com5.f6565a && this.f3645a.l() && this.f3645a.f3651a.isVisible()) {
                this.f3645a.invalidate();
            }
            return this;
        }

        public com3 r(int i2) {
            this.f9596c = i2;
            com5 com5Var = this.f3645a;
            if (com5Var != null) {
                com5Var.setId(i2);
            }
            return this;
        }

        public void s(int i2) {
            this.f9594a = i2;
        }

        public com3 t(int i2) {
            TabLayout tabLayout = this.f3646a;
            if (tabLayout != null) {
                return u(tabLayout.getResources().getText(i2));
            }
            throw new IllegalArgumentException("Tab not attached to a TabLayout");
        }

        public com3 u(CharSequence charSequence) {
            if (TextUtils.isEmpty(this.f3649b) && !TextUtils.isEmpty(charSequence)) {
                this.f3645a.setContentDescription(charSequence);
            }
            this.f3647a = charSequence;
            v();
            return this;
        }

        public void v() {
            com5 com5Var = this.f3645a;
            if (com5Var != null) {
                com5Var.t();
            }
        }
    }

    public static class com4 implements ViewPager.com6 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9597a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final WeakReference<TabLayout> f3650a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f9598b;

        public com4(TabLayout tabLayout) {
            this.f3650a = new WeakReference<>(tabLayout);
        }

        @Override // androidx.viewpager.widget.ViewPager.com6
        public void a(int i2, float f2, int i3) {
            TabLayout tabLayout = this.f3650a.get();
            if (tabLayout != null) {
                int i4 = this.f9598b;
                tabLayout.L(i2, f2, i4 != 2 || this.f9597a == 1, (i4 == 2 && this.f9597a == 0) ? false : true);
            }
        }

        @Override // androidx.viewpager.widget.ViewPager.com6
        public void b(int i2) {
            this.f9597a = this.f9598b;
            this.f9598b = i2;
        }

        @Override // androidx.viewpager.widget.ViewPager.com6
        public void c(int i2) {
            TabLayout tabLayout = this.f3650a.get();
            if (tabLayout == null || tabLayout.getSelectedTabPosition() == i2 || i2 >= tabLayout.getTabCount()) {
                return;
            }
            int i3 = this.f9598b;
            tabLayout.I(tabLayout.y(i2), i3 == 0 || (i3 == 2 && this.f9597a == 0));
        }

        public void d() {
            this.f9598b = 0;
            this.f9597a = 0;
        }
    }

    public final class com5 extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9599a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public p029Com7.com3 f3651a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Drawable f3652a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f3653a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ImageView f3654a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public TextView f3655a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com3 f3656a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public View f9600b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public ImageView f3658b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public TextView f3659b;

        public class aux implements View.OnLayoutChangeListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ View f9601a;

            public aux(View view) {
                this.f9601a = view;
            }

            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
                if (this.f9601a.getVisibility() == 0) {
                    com5.this.s(this.f9601a);
                }
            }
        }

        public com5(Context context) {
            super(context);
            this.f9599a = 2;
            u(context);
            p024Com2.y.C0(this, TabLayout.this.f3612a, TabLayout.this.f3629b, TabLayout.this.f9571c, TabLayout.this.f9572d);
            setGravity(17);
            setOrientation(!TabLayout.this.f3633b ? 1 : 0);
            setClickable(true);
            p024Com2.y.D0(this, w.b(getContext(), 1002));
        }

        private p029Com7.com3 getBadge() {
            return this.f3651a;
        }

        private p029Com7.com3 getOrCreateBadge() {
            if (this.f3651a == null) {
                this.f3651a = p029Com7.com3.c(getContext());
            }
            r();
            p029Com7.com3 com3Var = this.f3651a;
            if (com3Var != null) {
                return com3Var;
            }
            throw new IllegalStateException("Unable to create badge");
        }

        @Override // android.view.ViewGroup, android.view.View
        public void drawableStateChanged() {
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            Drawable drawable = this.f3652a;
            boolean state = false;
            if (drawable != null && drawable.isStateful()) {
                state = false | this.f3652a.setState(drawableState);
            }
            if (state) {
                invalidate();
                TabLayout.this.invalidate();
            }
        }

        public final void f(View view) {
            if (view == null) {
                return;
            }
            view.addOnLayoutChangeListener(new aux(view));
        }

        public final float g(Layout layout, int i2, float f2) {
            return layout.getLineWidth(i2) * (f2 / layout.getPaint().getTextSize());
        }

        public int getContentHeight() {
            View[] viewArr = {this.f3655a, this.f3654a, this.f9600b};
            int iMax = 0;
            int iMin = 0;
            boolean z2 = false;
            for (int i2 = 0; i2 < 3; i2++) {
                View view = viewArr[i2];
                if (view != null && view.getVisibility() == 0) {
                    iMin = z2 ? Math.min(iMin, view.getTop()) : view.getTop();
                    iMax = z2 ? Math.max(iMax, view.getBottom()) : view.getBottom();
                    z2 = true;
                }
            }
            return iMax - iMin;
        }

        public int getContentWidth() {
            View[] viewArr = {this.f3655a, this.f3654a, this.f9600b};
            int iMax = 0;
            int iMin = 0;
            boolean z2 = false;
            for (int i2 = 0; i2 < 3; i2++) {
                View view = viewArr[i2];
                if (view != null && view.getVisibility() == 0) {
                    iMin = z2 ? Math.min(iMin, view.getLeft()) : view.getLeft();
                    iMax = z2 ? Math.max(iMax, view.getRight()) : view.getRight();
                    z2 = true;
                }
            }
            return iMax - iMin;
        }

        public com3 getTab() {
            return this.f3656a;
        }

        public final void h(boolean z2) {
            setClipChildren(z2);
            setClipToPadding(z2);
            ViewGroup viewGroup = (ViewGroup) getParent();
            if (viewGroup != null) {
                viewGroup.setClipChildren(z2);
                viewGroup.setClipToPadding(z2);
            }
        }

        public final FrameLayout i() {
            FrameLayout frameLayout = new FrameLayout(getContext());
            frameLayout.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
            return frameLayout;
        }

        public final void j(Canvas canvas) {
            Drawable drawable = this.f3652a;
            if (drawable != null) {
                drawable.setBounds(getLeft(), getTop(), getRight(), getBottom());
                this.f3652a.draw(canvas);
            }
        }

        public final FrameLayout k(View view) {
            if ((view == this.f3654a || view == this.f3655a) && p029Com7.com5.f6565a) {
                return (FrameLayout) view.getParent();
            }
            return null;
        }

        public final boolean l() {
            return this.f3651a != null;
        }

        public final void m() {
            ViewGroup viewGroup;
            if (p029Com7.com5.f6565a) {
                FrameLayout frameLayoutI = i();
                addView(frameLayoutI, 0);
                viewGroup = frameLayoutI;
            } else {
                viewGroup = this;
            }
            ImageView imageView = (ImageView) LayoutInflater.from(getContext()).inflate(d4.f8908b, viewGroup, false);
            this.f3654a = imageView;
            viewGroup.addView(imageView, 0);
        }

        public final void n() {
            ViewGroup viewGroup;
            if (p029Com7.com5.f6565a) {
                FrameLayout frameLayoutI = i();
                addView(frameLayoutI);
                viewGroup = frameLayoutI;
            } else {
                viewGroup = this;
            }
            TextView textView = (TextView) LayoutInflater.from(getContext()).inflate(d4.f8909c, viewGroup, false);
            this.f3655a = textView;
            viewGroup.addView(textView);
        }

        public void o() {
            setTab(null);
            setSelected(false);
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            p029Com7.com3 com3Var = this.f3651a;
            if (com3Var != null && com3Var.isVisible()) {
                accessibilityNodeInfo.setContentDescription(((Object) getContentDescription()) + ", " + ((Object) this.f3651a.f()));
            }
            e2 e2VarZ0 = e2.z0(accessibilityNodeInfo);
            e2VarZ0.W(e2.nul.a(0, 1, this.f3656a.h(), 1, false, isSelected()));
            if (isSelected()) {
                e2VarZ0.U(false);
                e2VarZ0.N(e2.aux.f9101e);
            }
            e2VarZ0.n0(getResources().getString(f4.f8937h));
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            Layout layout;
            int size = View.MeasureSpec.getSize(i2);
            int mode = View.MeasureSpec.getMode(i2);
            int tabMaxWidth = TabLayout.this.getTabMaxWidth();
            if (tabMaxWidth > 0 && (mode == 0 || size > tabMaxWidth)) {
                i2 = View.MeasureSpec.makeMeasureSpec(TabLayout.this.f9576h, Integer.MIN_VALUE);
            }
            super.onMeasure(i2, i3);
            if (this.f3655a != null) {
                float f2 = TabLayout.this.f9570a;
                int i4 = this.f9599a;
                ImageView imageView = this.f3654a;
                boolean z2 = true;
                if (imageView == null || imageView.getVisibility() != 0) {
                    TextView textView = this.f3655a;
                    if (textView != null && textView.getLineCount() > 1) {
                        f2 = TabLayout.this.f3628b;
                    }
                } else {
                    i4 = 1;
                }
                float textSize = this.f3655a.getTextSize();
                int lineCount = this.f3655a.getLineCount();
                int iD = lpt1.d(this.f3655a);
                if (f2 != textSize || (iD >= 0 && i4 != iD)) {
                    if (TabLayout.this.f9584p == 1 && f2 > textSize && lineCount == 1 && ((layout = this.f3655a.getLayout()) == null || g(layout, 0, f2) > (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight())) {
                        z2 = false;
                    }
                    if (z2) {
                        this.f3655a.setTextSize(0, f2);
                        this.f3655a.setMaxLines(i4);
                        super.onMeasure(i2, i3);
                    }
                }
            }
        }

        public final void p(View view) {
            if (l() && view != null) {
                h(false);
                p029Com7.com5.a(this.f3651a, view, k(view));
                this.f3653a = view;
            }
        }

        @Override // android.view.View
        public boolean performClick() {
            boolean zPerformClick = super.performClick();
            if (this.f3656a == null) {
                return zPerformClick;
            }
            if (!zPerformClick) {
                playSoundEffect(0);
            }
            this.f3656a.m();
            return true;
        }

        public final void q() {
            if (l()) {
                h(true);
                View view = this.f3653a;
                if (view != null) {
                    p029Com7.com5.b(this.f3651a, view);
                    this.f3653a = null;
                }
            }
        }

        public final void r() {
            com3 com3Var;
            com3 com3Var2;
            if (l()) {
                if (this.f9600b != null) {
                    q();
                    return;
                }
                if (this.f3654a != null && (com3Var2 = this.f3656a) != null && com3Var2.f() != null) {
                    View view = this.f3653a;
                    ImageView imageView = this.f3654a;
                    if (view == imageView) {
                        s(imageView);
                        return;
                    } else {
                        q();
                        p(this.f3654a);
                        return;
                    }
                }
                if (this.f3655a == null || (com3Var = this.f3656a) == null || com3Var.i() != 1) {
                    q();
                    return;
                }
                View view2 = this.f3653a;
                TextView textView = this.f3655a;
                if (view2 == textView) {
                    s(textView);
                } else {
                    q();
                    p(this.f3655a);
                }
            }
        }

        public final void s(View view) {
            if (l() && view == this.f3653a) {
                p029Com7.com5.c(this.f3651a, view, k(view));
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z2) {
            if (isSelected() != z2) {
            }
            super.setSelected(z2);
            TextView textView = this.f3655a;
            if (textView != null) {
                textView.setSelected(z2);
            }
            ImageView imageView = this.f3654a;
            if (imageView != null) {
                imageView.setSelected(z2);
            }
            View view = this.f9600b;
            if (view != null) {
                view.setSelected(z2);
            }
        }

        public void setTab(com3 com3Var) {
            if (com3Var != this.f3656a) {
                this.f3656a = com3Var;
                t();
            }
        }

        public final void t() {
            com3 com3Var = this.f3656a;
            View viewE = com3Var != null ? com3Var.e() : null;
            if (viewE != null) {
                ViewParent parent = viewE.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(viewE);
                    }
                    addView(viewE);
                }
                this.f9600b = viewE;
                TextView textView = this.f3655a;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.f3654a;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.f3654a.setImageDrawable(null);
                }
                TextView textView2 = (TextView) viewE.findViewById(R.id.text1);
                this.f3659b = textView2;
                if (textView2 != null) {
                    this.f9599a = lpt1.d(textView2);
                }
                this.f3658b = (ImageView) viewE.findViewById(R.id.icon);
            } else {
                View view = this.f9600b;
                if (view != null) {
                    removeView(view);
                    this.f9600b = null;
                }
                this.f3659b = null;
                this.f3658b = null;
            }
            if (this.f9600b == null) {
                if (this.f3654a == null) {
                    m();
                }
                if (this.f3655a == null) {
                    n();
                    this.f9599a = lpt1.d(this.f3655a);
                }
                lpt1.n(this.f3655a, TabLayout.this.f9573e);
                ColorStateList colorStateList = TabLayout.this.f3615a;
                if (colorStateList != null) {
                    this.f3655a.setTextColor(colorStateList);
                }
                w(this.f3655a, this.f3654a);
                r();
                f(this.f3654a);
                f(this.f3655a);
            } else {
                TextView textView3 = this.f3659b;
                if (textView3 != null || this.f3658b != null) {
                    w(textView3, this.f3658b);
                }
            }
            if (com3Var != null && !TextUtils.isEmpty(com3Var.f3649b)) {
                setContentDescription(com3Var.f3649b);
            }
            setSelected(com3Var != null && com3Var.k());
        }

        public final void u(Context context) {
            GradientDrawable gradientDrawable;
            int i2 = TabLayout.this.f9575g;
            if (i2 != 0) {
                Drawable drawableB = AUX.aux.b(context, i2);
                this.f3652a = drawableB;
                if (drawableB != null && drawableB.isStateful()) {
                    this.f3652a.setState(getDrawableState());
                }
            } else {
                this.f3652a = null;
            }
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(0);
            Drawable rippleDrawable = gradientDrawable2;
            if (TabLayout.this.f3634c != null) {
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                gradientDrawable3.setCornerRadius(1.0E-5f);
                gradientDrawable3.setColor(-1);
                ColorStateList colorStateListA = lpt4.a(TabLayout.this.f3634c);
                boolean z2 = TabLayout.this.f3636d;
                if (z2) {
                    gradientDrawable = gradientDrawable2;
                    gradientDrawable = null;
                }
                rippleDrawable = new RippleDrawable(colorStateListA, gradientDrawable, z2 ? null : gradientDrawable3);
            }
            p024Com2.y.s0(this, rippleDrawable);
            TabLayout.this.invalidate();
        }

        public final void v() {
            setOrientation(!TabLayout.this.f3633b ? 1 : 0);
            TextView textView = this.f3659b;
            if (textView == null && this.f3658b == null) {
                w(this.f3655a, this.f3654a);
            } else {
                w(textView, this.f3658b);
            }
        }

        public final void w(TextView textView, ImageView imageView) {
            com3 com3Var = this.f3656a;
            Drawable drawableMutate = (com3Var == null || com3Var.f() == null) ? null : y.l(this.f3656a.f()).mutate();
            if (drawableMutate != null) {
                y.i(drawableMutate, TabLayout.this.f3630b);
                PorterDuff.Mode mode = TabLayout.this.f3617a;
                if (mode != null) {
                    y.j(drawableMutate, mode);
                }
            }
            com3 com3Var2 = this.f3656a;
            CharSequence charSequenceJ = com3Var2 != null ? com3Var2.j() : null;
            if (imageView != null) {
                if (drawableMutate != null) {
                    imageView.setImageDrawable(drawableMutate);
                    imageView.setVisibility(0);
                    setVisibility(0);
                } else {
                    imageView.setVisibility(8);
                    imageView.setImageDrawable(null);
                }
            }
            boolean z2 = !TextUtils.isEmpty(charSequenceJ);
            if (textView != null) {
                if (z2) {
                    textView.setText(charSequenceJ);
                    if (this.f3656a.f9595b == 1) {
                        textView.setVisibility(0);
                    } else {
                        textView.setVisibility(8);
                    }
                    setVisibility(0);
                } else {
                    textView.setVisibility(8);
                    textView.setText((CharSequence) null);
                }
            }
            if (imageView != null) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) imageView.getLayoutParams();
                int iB = (z2 && imageView.getVisibility() == 0) ? (int) v.b(getContext(), 8) : 0;
                if (TabLayout.this.f3633b) {
                    if (iB != i.a(marginLayoutParams)) {
                        i.c(marginLayoutParams, iB);
                        marginLayoutParams.bottomMargin = 0;
                        imageView.setLayoutParams(marginLayoutParams);
                        imageView.requestLayout();
                    }
                } else if (iB != marginLayoutParams.bottomMargin) {
                    marginLayoutParams.bottomMargin = iB;
                    i.c(marginLayoutParams, 0);
                    imageView.setLayoutParams(marginLayoutParams);
                    imageView.requestLayout();
                }
            }
            com3 com3Var3 = this.f3656a;
            CharSequence charSequence = com3Var3 != null ? com3Var3.f3649b : null;
            if (!z2) {
                charSequenceJ = charSequence;
            }
            s0.a(this, charSequenceJ);
        }
    }

    public static class com6 implements prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final ViewPager f9602a;

        public com6(ViewPager viewPager) {
            this.f9602a = viewPager;
        }

        @Override // com.google.android.material.tabs.TabLayout.nul
        public void a(com3 com3Var) {
        }

        @Override // com.google.android.material.tabs.TabLayout.nul
        public void b(com3 com3Var) {
            this.f9602a.setCurrentItem(com3Var.h());
        }

        @Override // com.google.android.material.tabs.TabLayout.nul
        public void c(com3 com3Var) {
        }
    }

    public class con implements ViewPager.com5 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f3661a;

        public con() {
        }

        @Override // androidx.viewpager.widget.ViewPager.com5
        public void a(ViewPager viewPager, COM5.aux auxVar, COM5.aux auxVar2) {
            TabLayout tabLayout = TabLayout.this;
            if (tabLayout.f3619a == viewPager) {
                tabLayout.J(auxVar2, this.f3661a);
            }
        }

        public void b(boolean z2) {
            this.f3661a = z2;
        }
    }

    @Deprecated
    public interface nul<T extends com3> {
        void a(T t2);

        void b(T t2);

        void c(T t2);
    }

    public interface prn extends nul<com3> {
    }

    public TabLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.K);
    }

    private int getDefaultHeight() {
        int size = this.f3627a.size();
        boolean z2 = false;
        for (int i2 = 0; i2 < size; i2++) {
            com3 com3Var = this.f3627a.get(i2);
            if (com3Var != null && com3Var.f() != null && !TextUtils.isEmpty(com3Var.j())) {
                z2 = true;
                break;
            }
        }
        return (!z2 || this.f3633b) ? 48 : 72;
    }

    private int getTabMinWidth() {
        int i2 = this.f9577i;
        if (i2 != -1) {
            return i2;
        }
        int i3 = this.f9584p;
        if (i3 == 0 || i3 == 2) {
            return this.f9579k;
        }
        return 0;
    }

    private int getTabScrollRange() {
        return Math.max(0, ((this.f3620a.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
    }

    public static ColorStateList q(int i2, int i3) {
        return new ColorStateList(new int[][]{HorizontalScrollView.SELECTED_STATE_SET, HorizontalScrollView.EMPTY_STATE_SET}, new int[]{i3, i2});
    }

    private void setSelectedTabView(int i2) {
        int childCount = this.f3620a.getChildCount();
        if (i2 < childCount) {
            int i3 = 0;
            while (i3 < childCount) {
                View childAt = this.f3620a.getChildAt(i3);
                boolean z2 = true;
                childAt.setSelected(i3 == i2);
                if (i3 != i2) {
                    z2 = false;
                }
                childAt.setActivated(z2);
                i3++;
            }
        }
    }

    public boolean A() {
        return this.f3635c;
    }

    public com3 B() {
        com3 com3VarS = s();
        com3VarS.f3646a = this;
        com3VarS.f3645a = t(com3VarS);
        if (com3VarS.f9596c != -1) {
            com3VarS.f3645a.setId(com3VarS.f9596c);
        }
        return com3VarS;
    }

    public void C() {
        int currentItem;
        E();
        COM5.aux auxVar = this.f3613a;
        if (auxVar != null) {
            int iC = auxVar.c();
            for (int i2 = 0; i2 < iC; i2++) {
                g(B().u(this.f3613a.e(i2)), false);
            }
            ViewPager viewPager = this.f3619a;
            if (viewPager == null || iC <= 0 || (currentItem = viewPager.getCurrentItem()) == getSelectedTabPosition() || currentItem >= getTabCount()) {
                return;
            }
            H(y(currentItem));
        }
    }

    public boolean D(com3 com3Var) {
        return f9568b.a(com3Var);
    }

    public void E() {
        for (int childCount = this.f3620a.getChildCount() - 1; childCount >= 0; childCount--) {
            G(childCount);
        }
        Iterator<com3> it = this.f3627a.iterator();
        while (it.hasNext()) {
            com3 next = it.next();
            it.remove();
            next.l();
            D(next);
        }
        this.f3621a = null;
    }

    @Deprecated
    public void F(nul nulVar) {
        this.f3632b.remove(nulVar);
    }

    public final void G(int i2) {
        com5 com5Var = (com5) this.f3620a.getChildAt(i2);
        this.f3620a.removeViewAt(i2);
        if (com5Var != null) {
            com5Var.o();
            this.f3626a.a(com5Var);
        }
        requestLayout();
    }

    public void H(com3 com3Var) {
        I(com3Var, true);
    }

    public void I(com3 com3Var, boolean z2) {
        com3 com3Var2 = this.f3621a;
        if (com3Var2 == com3Var) {
            if (com3Var2 != null) {
                u(com3Var);
                k(com3Var.h());
                return;
            }
            return;
        }
        int iH = com3Var != null ? com3Var.h() : -1;
        if (z2) {
            if ((com3Var2 == null || com3Var2.h() == -1) && iH != -1) {
                K(iH, 0.0f, true);
            } else {
                k(iH);
            }
            if (iH != -1) {
                setSelectedTabView(iH);
            }
        }
        this.f3621a = com3Var;
        if (com3Var2 != null) {
            w(com3Var2);
        }
        if (com3Var != null) {
            v(com3Var);
        }
    }

    public void J(COM5.aux auxVar, boolean z2) {
        DataSetObserver dataSetObserver;
        COM5.aux auxVar2 = this.f3613a;
        if (auxVar2 != null && (dataSetObserver = this.f3616a) != null) {
            auxVar2.p(dataSetObserver);
        }
        this.f3613a = auxVar;
        if (z2 && auxVar != null) {
            if (this.f3616a == null) {
                this.f3616a = new com1();
            }
            auxVar.j(this.f3616a);
        }
        C();
    }

    public void K(int i2, float f2, boolean z2) {
        L(i2, f2, z2, true);
    }

    public void L(int i2, float f2, boolean z2, boolean z3) {
        int iRound = Math.round(i2 + f2);
        if (iRound < 0 || iRound >= this.f3620a.getChildCount()) {
            return;
        }
        if (z3) {
            this.f3620a.f(i2, f2);
        }
        ValueAnimator valueAnimator = this.f3614a;
        if (valueAnimator != null && valueAnimator.isRunning()) {
            this.f3614a.cancel();
        }
        scrollTo(i2 < 0 ? 0 : n(i2, f2), 0);
        if (z2) {
            setSelectedTabView(iRound);
        }
    }

    public void M(ViewPager viewPager, boolean z2) {
        N(viewPager, z2, false);
    }

    public final void N(ViewPager viewPager, boolean z2, boolean z3) {
        ViewPager viewPager2 = this.f3619a;
        if (viewPager2 != null) {
            com4 com4Var = this.f3622a;
            if (com4Var != null) {
                viewPager2.I(com4Var);
            }
            con conVar = this.f3623a;
            if (conVar != null) {
                this.f3619a.H(conVar);
            }
        }
        nul nulVar = this.f3631b;
        if (nulVar != null) {
            F(nulVar);
            this.f3631b = null;
        }
        if (viewPager != null) {
            this.f3619a = viewPager;
            if (this.f3622a == null) {
                this.f3622a = new com4(this);
            }
            this.f3622a.d();
            viewPager.c(this.f3622a);
            com6 com6Var = new com6(viewPager);
            this.f3631b = com6Var;
            c(com6Var);
            COM5.aux adapter = viewPager.getAdapter();
            if (adapter != null) {
                J(adapter, z2);
            }
            if (this.f3623a == null) {
                this.f3623a = new con();
            }
            this.f3623a.b(z2);
            viewPager.b(this.f3623a);
            K(viewPager.getCurrentItem(), 0.0f, true);
        } else {
            this.f3619a = null;
            J(null, false);
        }
        this.f3637e = z3;
    }

    public final void O() {
        int size = this.f3627a.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f3627a.get(i2).v();
        }
    }

    public final void P(LinearLayout.LayoutParams layoutParams) {
        if (this.f9584p == 1 && this.f9581m == 0) {
            layoutParams.width = 0;
            layoutParams.weight = 1.0f;
        } else {
            layoutParams.width = -2;
            layoutParams.weight = 0.0f;
        }
    }

    public void Q(boolean z2) {
        for (int i2 = 0; i2 < this.f3620a.getChildCount(); i2++) {
            View childAt = this.f3620a.getChildAt(i2);
            childAt.setMinimumWidth(getTabMinWidth());
            P((LinearLayout.LayoutParams) childAt.getLayoutParams());
            if (z2) {
                childAt.requestLayout();
            }
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public void addView(View view) {
        j(view);
    }

    @Deprecated
    public void c(nul nulVar) {
        if (this.f3632b.contains(nulVar)) {
            return;
        }
        this.f3632b.add(nulVar);
    }

    public void d(prn prnVar) {
        c(prnVar);
    }

    public void e(com3 com3Var) {
        g(com3Var, this.f3627a.isEmpty());
    }

    public void f(com3 com3Var, int i2, boolean z2) {
        if (com3Var.f3646a != this) {
            throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
        }
        p(com3Var, i2);
        i(com3Var);
        if (z2) {
            com3Var.m();
        }
    }

    public void g(com3 com3Var, boolean z2) {
        f(com3Var, this.f3627a.size(), z2);
    }

    public int getSelectedTabPosition() {
        com3 com3Var = this.f3621a;
        if (com3Var != null) {
            return com3Var.h();
        }
        return -1;
    }

    public int getTabCount() {
        return this.f3627a.size();
    }

    public int getTabGravity() {
        return this.f9581m;
    }

    public ColorStateList getTabIconTint() {
        return this.f3630b;
    }

    public int getTabIndicatorAnimationMode() {
        return this.f9586r;
    }

    public int getTabIndicatorGravity() {
        return this.f9583o;
    }

    public int getTabMaxWidth() {
        return this.f9576h;
    }

    public int getTabMode() {
        return this.f9584p;
    }

    public ColorStateList getTabRippleColor() {
        return this.f3634c;
    }

    public Drawable getTabSelectedIndicator() {
        return this.f3618a;
    }

    public ColorStateList getTabTextColors() {
        return this.f3615a;
    }

    public final void h(t tVar) {
        com3 com3VarB = B();
        CharSequence charSequence = tVar.f4615a;
        if (charSequence != null) {
            com3VarB.u(charSequence);
        }
        Drawable drawable = tVar.f4614a;
        if (drawable != null) {
            com3VarB.q(drawable);
        }
        int i2 = tVar.f11048a;
        if (i2 != 0) {
            com3VarB.o(i2);
        }
        if (!TextUtils.isEmpty(tVar.getContentDescription())) {
            com3VarB.n(tVar.getContentDescription());
        }
        e(com3VarB);
    }

    public final void i(com3 com3Var) {
        com5 com5Var = com3Var.f3645a;
        com5Var.setSelected(false);
        com5Var.setActivated(false);
        this.f3620a.addView(com5Var, com3Var.h(), r());
    }

    public final void j(View view) {
        if (!(view instanceof t)) {
            throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
        }
        h((t) view);
    }

    public final void k(int i2) {
        if (i2 == -1) {
            return;
        }
        if (getWindowToken() == null || !p024Com2.y.S(this) || this.f3620a.d()) {
            K(i2, 0.0f, true);
            return;
        }
        int scrollX = getScrollX();
        int iN = n(i2, 0.0f);
        if (scrollX != iN) {
            x();
            this.f3614a.setIntValues(scrollX, iN);
            this.f3614a.start();
        }
        this.f3620a.c(i2, this.f9582n);
    }

    public final void l(int i2) {
        if (i2 == 0) {
            Log.w("TabLayout", "MODE_SCROLLABLE + GRAVITY_FILL is not supported, GRAVITY_START will be used instead");
        } else if (i2 == 1) {
            this.f3620a.setGravity(1);
            return;
        } else if (i2 != 2) {
            return;
        }
        this.f3620a.setGravity(8388611);
    }

    public final void m() {
        int i2 = this.f9584p;
        p024Com2.y.C0(this.f3620a, (i2 == 0 || i2 == 2) ? Math.max(0, this.f9580l - this.f3612a) : 0, 0, 0, 0);
        int i3 = this.f9584p;
        if (i3 == 0) {
            l(this.f9581m);
        } else if (i3 == 1 || i3 == 2) {
            if (this.f9581m == 2) {
                Log.w("TabLayout", "GRAVITY_START is not supported with the current tab mode, GRAVITY_CENTER will be used instead");
            }
            this.f3620a.setGravity(1);
        }
        Q(true);
    }

    public final int n(int i2, float f2) {
        View childAt;
        int i3 = this.f9584p;
        if ((i3 != 0 && i3 != 2) || (childAt = this.f3620a.getChildAt(i2)) == null) {
            return 0;
        }
        int i4 = i2 + 1;
        View childAt2 = i4 < this.f3620a.getChildCount() ? this.f3620a.getChildAt(i4) : null;
        int width = childAt.getWidth();
        int width2 = childAt2 != null ? childAt2.getWidth() : 0;
        int left = (childAt.getLeft() + (width / 2)) - (getWidth() / 2);
        int i5 = (int) ((width + width2) * 0.5f * f2);
        return p024Com2.y.A(this) == 0 ? left + i5 : left - i5;
    }

    public void o() {
        this.f3632b.clear();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        COM9.com4.e(this);
        if (this.f3619a == null) {
            ViewParent parent = getParent();
            if (parent instanceof ViewPager) {
                N((ViewPager) parent, true, true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f3637e) {
            setupWithViewPager(null);
            this.f3637e = false;
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        for (int i2 = 0; i2 < this.f3620a.getChildCount(); i2++) {
            View childAt = this.f3620a.getChildAt(i2);
            if (childAt instanceof com5) {
                ((com5) childAt).j(canvas);
            }
        }
        super.onDraw(canvas);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        e2.z0(accessibilityNodeInfo).V(e2.con.a(1, getTabCount(), false, 1));
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return z() && super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0080  */
    /* JADX WARN: Code duplicated, block: B:30:0x0082  */
    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        int iRound = Math.round(v.b(getContext(), getDefaultHeight()));
        int mode = View.MeasureSpec.getMode(i3);
        boolean z2 = false;
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                i3 = View.MeasureSpec.makeMeasureSpec(iRound + getPaddingTop() + getPaddingBottom(), 1073741824);
            }
        } else if (getChildCount() == 1 && View.MeasureSpec.getSize(i3) >= iRound) {
            getChildAt(0).setMinimumHeight(iRound);
        }
        int size = View.MeasureSpec.getSize(i2);
        if (View.MeasureSpec.getMode(i2) != 0) {
            int iB = this.f9578j;
            if (iB <= 0) {
                iB = (int) (size - v.b(getContext(), 56));
            }
            this.f9576h = iB;
        }
        super.onMeasure(i2, i3);
        if (getChildCount() == 1) {
            View childAt = getChildAt(0);
            int i4 = this.f9584p;
            if (i4 == 0) {
                if (childAt.getMeasuredWidth() < getMeasuredWidth()) {
                    z2 = true;
                }
            } else if (i4 != 1) {
                if (i4 == 2) {
                    if (childAt.getMeasuredWidth() < getMeasuredWidth()) {
                        z2 = true;
                    }
                }
            } else if (childAt.getMeasuredWidth() != getMeasuredWidth()) {
                z2 = true;
            }
            if (z2) {
                childAt.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), ViewGroup.getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom(), childAt.getLayoutParams().height));
            }
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.View
    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() != 8 || z()) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    public final void p(com3 com3Var, int i2) {
        com3Var.s(i2);
        this.f3627a.add(i2, com3Var);
        int size = this.f3627a.size();
        while (true) {
            i2++;
            if (i2 >= size) {
                return;
            } else {
                this.f3627a.get(i2).s(i2);
            }
        }
    }

    public final LinearLayout.LayoutParams r() {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
        P(layoutParams);
        return layoutParams;
    }

    public com3 s() {
        com3 com3VarB = f9568b.b();
        return com3VarB == null ? new com3() : com3VarB;
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        COM9.com4.d(this, f2);
    }

    public void setInlineLabel(boolean z2) {
        if (this.f3633b != z2) {
            this.f3633b = z2;
            for (int i2 = 0; i2 < this.f3620a.getChildCount(); i2++) {
                View childAt = this.f3620a.getChildAt(i2);
                if (childAt instanceof com5) {
                    ((com5) childAt).v();
                }
            }
            m();
        }
    }

    public void setInlineLabelResource(int i2) {
        setInlineLabel(getResources().getBoolean(i2));
    }

    @Deprecated
    public void setOnTabSelectedListener(prn prnVar) {
        setOnTabSelectedListener((nul) prnVar);
    }

    public void setScrollAnimatorListener(Animator.AnimatorListener animatorListener) {
        x();
        this.f3614a.addListener(animatorListener);
    }

    public void setSelectedTabIndicator(Drawable drawable) {
        if (this.f3618a != drawable) {
            if (drawable == null) {
                drawable = new GradientDrawable();
            }
            this.f3618a = drawable;
            int intrinsicHeight = this.f9585q;
            if (intrinsicHeight == -1) {
                intrinsicHeight = drawable.getIntrinsicHeight();
            }
            this.f3620a.g(intrinsicHeight);
        }
    }

    public void setSelectedTabIndicatorColor(int i2) {
        this.f9574f = i2;
        Q(false);
    }

    public void setSelectedTabIndicatorGravity(int i2) {
        if (this.f9583o != i2) {
            this.f9583o = i2;
            p024Com2.y.f0(this.f3620a);
        }
    }

    @Deprecated
    public void setSelectedTabIndicatorHeight(int i2) {
        this.f9585q = i2;
        this.f3620a.g(i2);
    }

    public void setTabGravity(int i2) {
        if (this.f9581m != i2) {
            this.f9581m = i2;
            m();
        }
    }

    public void setTabIconTint(ColorStateList colorStateList) {
        if (this.f3630b != colorStateList) {
            this.f3630b = colorStateList;
            O();
        }
    }

    public void setTabIconTintResource(int i2) {
        setTabIconTint(AUX.aux.a(getContext(), i2));
    }

    public void setTabIndicatorAnimationMode(int i2) {
        this.f9586r = i2;
        if (i2 == 0) {
            this.f3625a = new com.google.android.material.tabs.aux();
            return;
        }
        if (i2 == 1) {
            this.f3625a = new r();
        } else {
            if (i2 == 2) {
                this.f3625a = new s();
                return;
            }
            throw new IllegalArgumentException(i2 + " is not a valid TabIndicatorAnimationMode");
        }
    }

    public void setTabIndicatorFullWidth(boolean z2) {
        this.f3635c = z2;
        this.f3620a.e();
        p024Com2.y.f0(this.f3620a);
    }

    public void setTabMode(int i2) {
        if (i2 != this.f9584p) {
            this.f9584p = i2;
            m();
        }
    }

    public void setTabRippleColor(ColorStateList colorStateList) {
        if (this.f3634c != colorStateList) {
            this.f3634c = colorStateList;
            for (int i2 = 0; i2 < this.f3620a.getChildCount(); i2++) {
                View childAt = this.f3620a.getChildAt(i2);
                if (childAt instanceof com5) {
                    ((com5) childAt).u(getContext());
                }
            }
        }
    }

    public void setTabRippleColorResource(int i2) {
        setTabRippleColor(AUX.aux.a(getContext(), i2));
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.f3615a != colorStateList) {
            this.f3615a = colorStateList;
            O();
        }
    }

    @Deprecated
    public void setTabsFromPagerAdapter(COM5.aux auxVar) {
        J(auxVar, false);
    }

    public void setUnboundedRipple(boolean z2) {
        if (this.f3636d != z2) {
            this.f3636d = z2;
            for (int i2 = 0; i2 < this.f3620a.getChildCount(); i2++) {
                View childAt = this.f3620a.getChildAt(i2);
                if (childAt instanceof com5) {
                    ((com5) childAt).u(getContext());
                }
            }
        }
    }

    public void setUnboundedRippleResource(int i2) {
        setUnboundedRipple(getResources().getBoolean(i2));
    }

    public void setupWithViewPager(ViewPager viewPager) {
        M(viewPager, true);
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return getTabScrollRange() > 0;
    }

    public final com5 t(com3 com3Var) {
        r2<com5> r2Var = this.f3626a;
        com5 com5VarB = r2Var != null ? r2Var.b() : null;
        if (com5VarB == null) {
            com5VarB = new com5(getContext());
        }
        com5VarB.setTab(com3Var);
        com5VarB.setFocusable(true);
        com5VarB.setMinimumWidth(getTabMinWidth());
        if (TextUtils.isEmpty(com3Var.f3649b)) {
            com5VarB.setContentDescription(com3Var.f3647a);
        } else {
            com5VarB.setContentDescription(com3Var.f3649b);
        }
        return com5VarB;
    }

    public final void u(com3 com3Var) {
        for (int size = this.f3632b.size() - 1; size >= 0; size--) {
            this.f3632b.get(size).c(com3Var);
        }
    }

    public final void v(com3 com3Var) {
        for (int size = this.f3632b.size() - 1; size >= 0; size--) {
            this.f3632b.get(size).b(com3Var);
        }
    }

    public final void w(com3 com3Var) {
        for (int size = this.f3632b.size() - 1; size >= 0; size--) {
            this.f3632b.get(size).a(com3Var);
        }
    }

    public final void x() {
        if (this.f3614a == null) {
            ValueAnimator valueAnimator = new ValueAnimator();
            this.f3614a = valueAnimator;
            valueAnimator.setInterpolator(COM6.aux.f5701b);
            this.f3614a.setDuration(this.f9582n);
            this.f3614a.addUpdateListener(new aux());
        }
    }

    public com3 y(int i2) {
        if (i2 < 0 || i2 >= getTabCount()) {
            return null;
        }
        return this.f3627a.get(i2);
    }

    public final boolean z() {
        return getTabMode() == 0 || getTabMode() == 2;
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public TabLayout(Context context, AttributeSet attributeSet, int i2) {
        int i3 = f9569s;
        super(u.c(context, attributeSet, i2, i3), attributeSet, i2);
        this.f3627a = new ArrayList<>();
        this.f3618a = new GradientDrawable();
        this.f9574f = 0;
        this.f9576h = Preference.DEFAULT_ORDER;
        this.f9585q = -1;
        this.f3632b = new ArrayList<>();
        this.f3626a = new s2(12);
        Context context2 = getContext();
        setHorizontalScrollBarEnabled(false);
        com2 com2Var = new com2(context2);
        this.f3620a = com2Var;
        super.addView(com2Var, 0, new FrameLayout.LayoutParams(-2, -1));
        int[] iArr = h4.f3160r1;
        int i4 = h4.U2;
        TypedArray typedArrayH = p108com9.t.h(context2, attributeSet, iArr, i2, i3, i4);
        if (getBackground() instanceof ColorDrawable) {
            ColorDrawable colorDrawable = (ColorDrawable) getBackground();
            COM9.com3 com3Var = new COM9.com3();
            com3Var.Y(ColorStateList.valueOf(colorDrawable.getColor()));
            com3Var.N(context2);
            com3Var.X(p024Com2.y.v(this));
            p024Com2.y.s0(this, com3Var);
        }
        setSelectedTabIndicator(b.d(context2, typedArrayH, h4.C2));
        setSelectedTabIndicatorColor(typedArrayH.getColor(h4.F2, 0));
        com2Var.g(typedArrayH.getDimensionPixelSize(h4.I2, -1));
        setSelectedTabIndicatorGravity(typedArrayH.getInt(h4.H2, 0));
        setTabIndicatorAnimationMode(typedArrayH.getInt(h4.E2, 0));
        setTabIndicatorFullWidth(typedArrayH.getBoolean(h4.G2, true));
        int dimensionPixelSize = typedArrayH.getDimensionPixelSize(h4.N2, 0);
        this.f9572d = dimensionPixelSize;
        this.f9571c = dimensionPixelSize;
        this.f3629b = dimensionPixelSize;
        this.f3612a = dimensionPixelSize;
        this.f3612a = typedArrayH.getDimensionPixelSize(h4.Q2, dimensionPixelSize);
        this.f3629b = typedArrayH.getDimensionPixelSize(h4.R2, this.f3629b);
        this.f9571c = typedArrayH.getDimensionPixelSize(h4.P2, this.f9571c);
        this.f9572d = typedArrayH.getDimensionPixelSize(h4.O2, this.f9572d);
        int resourceId = typedArrayH.getResourceId(i4, g4.f8957b);
        this.f9573e = resourceId;
        TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(resourceId, lpt3.f8D);
        try {
            this.f9570a = typedArrayObtainStyledAttributes.getDimensionPixelSize(lpt3.p2, 0);
            this.f3615a = b.b(context2, typedArrayObtainStyledAttributes, lpt3.s2);
            typedArrayObtainStyledAttributes.recycle();
            int i5 = h4.V2;
            if (typedArrayH.hasValue(i5)) {
                this.f3615a = b.b(context2, typedArrayH, i5);
            }
            int i6 = h4.T2;
            if (typedArrayH.hasValue(i6)) {
                this.f3615a = q(this.f3615a.getDefaultColor(), typedArrayH.getColor(i6, 0));
            }
            this.f3630b = b.b(context2, typedArrayH, h4.A2);
            this.f3617a = v.f(typedArrayH.getInt(h4.B2, -1), null);
            this.f3634c = b.b(context2, typedArrayH, h4.S2);
            this.f9582n = typedArrayH.getInt(h4.D2, 300);
            this.f9577i = typedArrayH.getDimensionPixelSize(h4.L2, -1);
            this.f9578j = typedArrayH.getDimensionPixelSize(h4.K2, -1);
            this.f9575g = typedArrayH.getResourceId(h4.x2, 0);
            this.f9580l = typedArrayH.getDimensionPixelSize(h4.y2, 0);
            this.f9584p = typedArrayH.getInt(h4.M2, 1);
            this.f9581m = typedArrayH.getInt(h4.z2, 0);
            this.f3633b = typedArrayH.getBoolean(h4.J2, false);
            this.f3636d = typedArrayH.getBoolean(h4.W2, false);
            typedArrayH.recycle();
            Resources resources = getResources();
            this.f3628b = resources.getDimensionPixelSize(z3.f9066i);
            this.f9579k = resources.getDimensionPixelSize(z3.f9065h);
            m();
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public void addView(View view, int i2) {
        j(view);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    @Deprecated
    public void setOnTabSelectedListener(nul nulVar) {
        nul nulVar2 = this.f3624a;
        if (nulVar2 != null) {
            F(nulVar2);
        }
        this.f3624a = nulVar;
        if (nulVar != null) {
            c(nulVar);
        }
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup, android.view.ViewManager
    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        j(view);
    }

    @Override // android.widget.HorizontalScrollView, android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        j(view);
    }

    public void setSelectedTabIndicator(int i2) {
        if (i2 != 0) {
            setSelectedTabIndicator(AUX.aux.b(getContext(), i2));
        } else {
            setSelectedTabIndicator((Drawable) null);
        }
    }
}
