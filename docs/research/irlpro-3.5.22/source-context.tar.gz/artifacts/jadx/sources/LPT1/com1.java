package LPT1;

import com.newrelic.agent.android.instrumentation.GsonInstrumentation;
import com.newrelic.agent.android.instrumentation.Instrumented;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;
import p120lPt2.b;
import p120lPt2.c;
import p120lPt2.d;
import p120lPt2.f;
import p120lPt2.g;
import p120lPt2.i;
import p120lPt2.j;
import p120lPt2.k;
import p120lPt2.l;
import p120lPt2.o;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class com1 {

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public static final String f814b = null;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f815a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt6 f816a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt8 f817a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LPT1.prn f818a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p052Lpt2.com8 f819a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p052Lpt2.com9 f820a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final String f821a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ThreadLocal<Map<p111lPT2.a<?>, com2<?>>> f822a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<a> f823a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<p111lPT2.a<?>, lpt9<?>> f824a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final f f825a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f826a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int f827b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final lpt8 f828b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final List<a> f829b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Map<Type, LPT1.com2<?>> f830b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f831b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final List<a> f832c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final boolean f833c;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final boolean f834d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f6571e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f6572f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f6573g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f6574h;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final LPT1.prn f6568b = LPT1.nul.f6592a;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final lpt8 f6569c = lpt7.f6587a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final lpt8 f6570d = lpt7.f6588b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final p111lPT2.a<?> f6567a = p111lPT2.a.a(Object.class);

    public class aux extends lpt9<Number> {
        public aux() {
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public Double b(LPT2.aux auxVar) throws IOException {
            if (auxVar.b0() != LPT2.con.NULL) {
                return Double.valueOf(auxVar.M());
            }
            auxVar.X();
            return null;
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
        public void d(LPT2.nul nulVar, Number number) throws IOException {
            if (number == null) {
                nulVar.G();
            } else {
                com1.d(number.doubleValue());
                nulVar.b0(number);
            }
        }
    }

    /* JADX INFO: renamed from: LPT1.com1$com1, reason: collision with other inner class name */
    public class C0012com1 extends lpt9<AtomicLongArray> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ lpt9 f6576a;

        public C0012com1(lpt9 lpt9Var) {
            this.f6576a = lpt9Var;
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public AtomicLongArray b(LPT2.aux auxVar) throws IOException {
            ArrayList arrayList = new ArrayList();
            auxVar.a();
            while (auxVar.E()) {
                arrayList.add(Long.valueOf(((Number) this.f6576a.b(auxVar)).longValue()));
            }
            auxVar.n();
            int size = arrayList.size();
            AtomicLongArray atomicLongArray = new AtomicLongArray(size);
            for (int i2 = 0; i2 < size; i2++) {
                atomicLongArray.set(i2, ((Long) arrayList.get(i2)).longValue());
            }
            return atomicLongArray;
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
        public void d(LPT2.nul nulVar, AtomicLongArray atomicLongArray) throws IOException {
            nulVar.d();
            int length = atomicLongArray.length();
            for (int i2 = 0; i2 < length; i2++) {
                this.f6576a.d(nulVar, Long.valueOf(atomicLongArray.get(i2)));
            }
            nulVar.n();
        }
    }

    public static class com2<T> extends lpt9<T> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public lpt9<T> f6577a;

        @Override // LPT1.lpt9
        public T b(LPT2.aux auxVar) throws IOException {
            lpt9<T> lpt9Var = this.f6577a;
            if (lpt9Var != null) {
                return lpt9Var.b(auxVar);
            }
            throw new IllegalStateException();
        }

        @Override // LPT1.lpt9
        public void d(LPT2.nul nulVar, T t2) throws IOException {
            lpt9<T> lpt9Var = this.f6577a;
            if (lpt9Var == null) {
                throw new IllegalStateException();
            }
            lpt9Var.d(nulVar, t2);
        }

        public void e(lpt9<T> lpt9Var) {
            if (this.f6577a != null) {
                throw new AssertionError();
            }
            this.f6577a = lpt9Var;
        }
    }

    public class con extends lpt9<Number> {
        public con() {
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public Float b(LPT2.aux auxVar) throws IOException {
            if (auxVar.b0() != LPT2.con.NULL) {
                return Float.valueOf((float) auxVar.M());
            }
            auxVar.X();
            return null;
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
        public void d(LPT2.nul nulVar, Number number) throws IOException {
            if (number == null) {
                nulVar.G();
            } else {
                com1.d(number.floatValue());
                nulVar.b0(number);
            }
        }
    }

    public class nul extends lpt9<Number> {
        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public Number b(LPT2.aux auxVar) throws IOException {
            if (auxVar.b0() != LPT2.con.NULL) {
                return Long.valueOf(auxVar.O());
            }
            auxVar.X();
            return null;
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
        public void d(LPT2.nul nulVar, Number number) throws IOException {
            if (number == null) {
                nulVar.G();
            } else {
                nulVar.c0(number.toString());
            }
        }
    }

    public class prn extends lpt9<AtomicLong> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ lpt9 f6579a;

        public prn(lpt9 lpt9Var) {
            this.f6579a = lpt9Var;
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public AtomicLong b(LPT2.aux auxVar) throws IOException {
            return new AtomicLong(((Number) this.f6579a.b(auxVar)).longValue());
        }

        @Override // LPT1.lpt9
        /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
        public void d(LPT2.nul nulVar, AtomicLong atomicLong) throws IOException {
            this.f6579a.d(nulVar, Long.valueOf(atomicLong.get()));
        }
    }

    public com1() {
        this(p052Lpt2.com9.f7286a, f6568b, Collections.emptyMap(), false, false, false, true, false, false, false, true, lpt6.f6585a, f814b, 2, 2, Collections.emptyList(), Collections.emptyList(), Collections.emptyList(), f6569c, f6570d);
    }

    public static void a(Object obj, LPT2.aux auxVar) {
        if (obj != null) {
            try {
                if (auxVar.b0() == LPT2.con.END_DOCUMENT) {
                } else {
                    throw new com7("JSON document was not fully consumed.");
                }
            } catch (LPT2.prn e2) {
                throw new lpt5(e2);
            } catch (IOException e3) {
                throw new com7(e3);
            }
        }
    }

    public static lpt9<AtomicLong> b(lpt9<Number> lpt9Var) {
        return new prn(lpt9Var).a();
    }

    public static lpt9<AtomicLongArray> c(lpt9<Number> lpt9Var) {
        return new C0012com1(lpt9Var).a();
    }

    public static void d(double d2) {
        if (Double.isNaN(d2) || Double.isInfinite(d2)) {
            throw new IllegalArgumentException(d2 + " is not a valid double value as per JSON specification. To override this behavior, use GsonBuilder.serializeSpecialFloatingPointValues() method.");
        }
    }

    public static lpt9<Number> q(lpt6 lpt6Var) {
        return lpt6Var == lpt6.f6585a ? o.f4657k : new nul();
    }

    public void A(Object obj, Type type, Appendable appendable) throws com7 {
        try {
            GsonInstrumentation.toJson(this, obj, type, s(p052Lpt2.lpt8.c(appendable)));
        } catch (IOException e2) {
            throw new com7(e2);
        }
    }

    public final lpt9<Number> e(boolean z2) {
        return z2 ? o.f4659m : new aux();
    }

    public final lpt9<Number> f(boolean z2) {
        return z2 ? o.f4658l : new con();
    }

    public <T> T g(com6 com6Var, Class<T> cls) throws lpt5 {
        return (T) p052Lpt2.lpt7.b(cls).cast(GsonInstrumentation.fromJson(this, com6Var, (Type) cls));
    }

    public <T> T h(com6 com6Var, Type type) throws lpt5 {
        if (com6Var == null) {
            return null;
        }
        return (T) GsonInstrumentation.fromJson(this, new g(com6Var), type);
    }

    public <T> T i(LPT2.aux auxVar, Type type) throws lpt5, com7 {
        boolean zF = auxVar.F();
        boolean z2 = true;
        auxVar.g0(true);
        try {
            try {
                try {
                    auxVar.b0();
                    z2 = false;
                    T tB = o(p111lPT2.a.b(type)).b(auxVar);
                    auxVar.g0(zF);
                    return tB;
                } catch (AssertionError e2) {
                    AssertionError assertionError = new AssertionError("AssertionError (GSON 2.9.0): " + e2.getMessage());
                    assertionError.initCause(e2);
                    throw assertionError;
                } catch (IllegalStateException e3) {
                    throw new lpt5(e3);
                }
            } catch (EOFException e4) {
                if (!z2) {
                    throw new lpt5(e4);
                }
                auxVar.g0(zF);
                return null;
            } catch (IOException e5) {
                throw new lpt5(e5);
            }
        } catch (Throwable th) {
            auxVar.g0(zF);
            throw th;
        }
    }

    public <T> T j(Reader reader, Class<T> cls) throws lpt5, com7 {
        LPT2.aux auxVarR = r(reader);
        Object objFromJson = GsonInstrumentation.fromJson(this, auxVarR, cls);
        a(objFromJson, auxVarR);
        return (T) p052Lpt2.lpt7.b(cls).cast(objFromJson);
    }

    public <T> T k(Reader reader, Type type) throws lpt5, com7 {
        LPT2.aux auxVarR = r(reader);
        T t2 = (T) GsonInstrumentation.fromJson(this, auxVarR, type);
        a(t2, auxVarR);
        return t2;
    }

    public <T> T l(String str, Class<T> cls) throws lpt5 {
        return (T) p052Lpt2.lpt7.b(cls).cast(GsonInstrumentation.fromJson(this, str, (Type) cls));
    }

    public <T> T m(String str, Type type) throws lpt5 {
        if (str == null) {
            return null;
        }
        return (T) GsonInstrumentation.fromJson(this, new StringReader(str), type);
    }

    public <T> lpt9<T> n(Class<T> cls) {
        return o(p111lPT2.a.a(cls));
    }

    public <T> lpt9<T> o(p111lPT2.a<T> aVar) {
        boolean z2;
        lpt9<T> lpt9Var = (lpt9) this.f824a.get(aVar == null ? f6567a : aVar);
        if (lpt9Var != null) {
            return lpt9Var;
        }
        Map<p111lPT2.a<?>, com2<?>> map = this.f822a.get();
        if (map == null) {
            map = new HashMap<>();
            this.f822a.set(map);
            z2 = true;
        } else {
            z2 = false;
        }
        com2<?> com2Var = map.get(aVar);
        if (com2Var != null) {
            return com2Var;
        }
        try {
            com2<?> com2Var2 = new com2<>();
            map.put(aVar, com2Var2);
            Iterator<a> it = this.f823a.iterator();
            while (it.hasNext()) {
                lpt9<T> lpt9VarA = it.next().a(this, aVar);
                if (lpt9VarA != null) {
                    com2Var2.e(lpt9VarA);
                    this.f824a.put(aVar, lpt9VarA);
                    map.remove(aVar);
                    if (z2) {
                        this.f822a.remove();
                    }
                    return lpt9VarA;
                }
            }
            throw new IllegalArgumentException("GSON (2.9.0) cannot handle " + aVar);
        } catch (Throwable th) {
            map.remove(aVar);
            if (z2) {
                this.f822a.remove();
            }
            throw th;
        }
    }

    public <T> lpt9<T> p(a aVar, p111lPT2.a<T> aVar2) {
        if (!this.f823a.contains(aVar)) {
            aVar = this.f825a;
        }
        boolean z2 = false;
        for (a aVar3 : this.f823a) {
            if (z2) {
                lpt9<T> lpt9VarA = aVar3.a(this, aVar2);
                if (lpt9VarA != null) {
                    return lpt9VarA;
                }
            } else if (aVar3 == aVar) {
                z2 = true;
            }
        }
        throw new IllegalArgumentException("GSON cannot serialize " + aVar2);
    }

    public LPT2.aux r(Reader reader) {
        LPT2.aux auxVar = new LPT2.aux(reader);
        auxVar.g0(this.f6572f);
        return auxVar;
    }

    public LPT2.nul s(Writer writer) throws IOException {
        if (this.f833c) {
            writer.write(")]}'\n");
        }
        LPT2.nul nulVar = new LPT2.nul(writer);
        if (this.f6571e) {
            nulVar.V("  ");
        }
        nulVar.O(this.f834d);
        nulVar.W(this.f6572f);
        nulVar.X(this.f826a);
        return nulVar;
    }

    public String t(com6 com6Var) {
        StringWriter stringWriter = new StringWriter();
        GsonInstrumentation.toJson(this, com6Var, (Appendable) stringWriter);
        return stringWriter.toString();
    }

    public String toString() {
        return "{serializeNulls:" + this.f826a + ",factories:" + this.f823a + ",instanceCreators:" + this.f819a + "}";
    }

    public String u(Object obj) {
        return obj == null ? GsonInstrumentation.toJson(this, (com6) com8.f6581a) : GsonInstrumentation.toJson(this, obj, obj.getClass());
    }

    public String v(Object obj, Type type) {
        StringWriter stringWriter = new StringWriter();
        GsonInstrumentation.toJson(this, obj, type, stringWriter);
        return stringWriter.toString();
    }

    public void w(com6 com6Var, LPT2.nul nulVar) throws com7 {
        boolean zY = nulVar.y();
        nulVar.W(true);
        boolean zS = nulVar.s();
        nulVar.O(this.f834d);
        boolean zP = nulVar.p();
        nulVar.X(this.f826a);
        try {
            try {
                p052Lpt2.lpt8.b(com6Var, nulVar);
                nulVar.W(zY);
                nulVar.O(zS);
                nulVar.X(zP);
            } catch (IOException e2) {
                throw new com7(e2);
            } catch (AssertionError e3) {
                AssertionError assertionError = new AssertionError("AssertionError (GSON 2.9.0): " + e3.getMessage());
                assertionError.initCause(e3);
                throw assertionError;
            }
        } catch (Throwable th) {
            nulVar.W(zY);
            nulVar.O(zS);
            nulVar.X(zP);
            throw th;
        }
    }

    public void x(com6 com6Var, Appendable appendable) throws com7 {
        try {
            GsonInstrumentation.toJson(this, com6Var, s(p052Lpt2.lpt8.c(appendable)));
        } catch (IOException e2) {
            throw new com7(e2);
        }
    }

    public void y(Object obj, Appendable appendable) throws com7 {
        if (obj != null) {
            GsonInstrumentation.toJson(this, obj, obj.getClass(), appendable);
        } else {
            GsonInstrumentation.toJson(this, (com6) com8.f6581a, appendable);
        }
    }

    public void z(Object obj, Type type, LPT2.nul nulVar) throws com7 {
        lpt9 lpt9VarO = o(p111lPT2.a.b(type));
        boolean zY = nulVar.y();
        nulVar.W(true);
        boolean zS = nulVar.s();
        nulVar.O(this.f834d);
        boolean zP = nulVar.p();
        nulVar.X(this.f826a);
        try {
            try {
                lpt9VarO.d(nulVar, obj);
                nulVar.W(zY);
                nulVar.O(zS);
                nulVar.X(zP);
            } catch (IOException e2) {
                throw new com7(e2);
            } catch (AssertionError e3) {
                AssertionError assertionError = new AssertionError("AssertionError (GSON 2.9.0): " + e3.getMessage());
                assertionError.initCause(e3);
                throw assertionError;
            }
        } catch (Throwable th) {
            nulVar.W(zY);
            nulVar.O(zS);
            nulVar.X(zP);
            throw th;
        }
    }

    public com1(p052Lpt2.com9 com9Var, LPT1.prn prnVar, Map<Type, LPT1.com2<?>> map, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6, boolean z7, boolean z8, boolean z9, lpt6 lpt6Var, String str, int i2, int i3, List<a> list, List<a> list2, List<a> list3, lpt8 lpt8Var, lpt8 lpt8Var2) {
        this.f822a = new ThreadLocal<>();
        this.f824a = new ConcurrentHashMap();
        this.f820a = com9Var;
        this.f818a = prnVar;
        this.f830b = map;
        p052Lpt2.com8 com8Var = new p052Lpt2.com8(map, z9);
        this.f819a = com8Var;
        this.f826a = z2;
        this.f831b = z3;
        this.f833c = z4;
        this.f834d = z5;
        this.f6571e = z6;
        this.f6572f = z7;
        this.f6573g = z8;
        this.f6574h = z9;
        this.f816a = lpt6Var;
        this.f821a = str;
        this.f815a = i2;
        this.f827b = i3;
        this.f829b = list;
        this.f832c = list2;
        this.f817a = lpt8Var;
        this.f828b = lpt8Var2;
        ArrayList arrayList = new ArrayList();
        arrayList.add(o.f11102u);
        arrayList.add(k.e(lpt8Var));
        arrayList.add(com9Var);
        arrayList.addAll(list3);
        arrayList.add(o.f11092k);
        arrayList.add(o.f11087f);
        arrayList.add(o.f11084c);
        arrayList.add(o.f11085d);
        arrayList.add(o.f11086e);
        lpt9<Number> lpt9VarQ = q(lpt6Var);
        arrayList.add(o.b(Long.TYPE, Long.class, lpt9VarQ));
        arrayList.add(o.b(Double.TYPE, Double.class, e(z8)));
        arrayList.add(o.b(Float.TYPE, Float.class, f(z8)));
        arrayList.add(j.e(lpt8Var2));
        arrayList.add(o.f11088g);
        arrayList.add(o.f11089h);
        arrayList.add(o.a(AtomicLong.class, b(lpt9VarQ)));
        arrayList.add(o.a(AtomicLongArray.class, c(lpt9VarQ)));
        arrayList.add(o.f11090i);
        arrayList.add(o.f11091j);
        arrayList.add(o.f11093l);
        arrayList.add(o.f11094m);
        arrayList.add(o.a(BigDecimal.class, o.f4662p));
        arrayList.add(o.a(BigInteger.class, o.f4663q));
        arrayList.add(o.a(p052Lpt2.lpt3.class, o.f4664r));
        arrayList.add(o.f11095n);
        arrayList.add(o.f11096o);
        arrayList.add(o.f11098q);
        arrayList.add(o.f11099r);
        arrayList.add(o.f11101t);
        arrayList.add(o.f11097p);
        arrayList.add(o.f11083b);
        arrayList.add(d.f11052a);
        arrayList.add(o.f11100s);
        if (p043LpT2.com5.f1112a) {
            arrayList.add(p043LpT2.com5.f7046b);
            arrayList.add(p043LpT2.com5.f7045a);
            arrayList.add(p043LpT2.com5.f7047c);
        }
        arrayList.add(b.f11049a);
        arrayList.add(o.f11082a);
        arrayList.add(new c(com8Var));
        arrayList.add(new i(com8Var, z3));
        f fVar = new f(com8Var);
        this.f825a = fVar;
        arrayList.add(fVar);
        arrayList.add(o.f11103v);
        arrayList.add(new l(com8Var, prnVar, com9Var, fVar));
        this.f823a = Collections.unmodifiableList(arrayList);
    }
}
