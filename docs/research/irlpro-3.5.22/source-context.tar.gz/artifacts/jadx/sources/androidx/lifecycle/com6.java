package androidx.lifecycle;

import COM3.lpt4;
import COM3.lpt5;
import android.annotation.SuppressLint;
import android.app.Application;
import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class com6 extends com7.nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Class<?>[] f8404a = {Application.class, lpt4.class};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Class<?>[] f8405b = {lpt4.class};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Application f2619a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Bundle f2620a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com7.con f2621a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final nul f2622a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SavedStateRegistry f2623a;

    @SuppressLint({"LambdaLast"})
    public com6(Application application, COM4.con conVar, Bundle bundle) {
        this.f2623a = conVar.getSavedStateRegistry();
        this.f2622a = conVar.getLifecycle();
        this.f2620a = bundle;
        this.f2619a = application;
        this.f2621a = application != null ? com7.aux.c(application) : com7.prn.b();
    }

    public static <T> Constructor<T> d(Class<T> cls, Class<?>[] clsArr) {
        for (Object obj : cls.getConstructors()) {
            Constructor<T> constructor = (Constructor<T>) obj;
            if (Arrays.equals(clsArr, constructor.getParameterTypes())) {
                return constructor;
            }
        }
        return null;
    }

    @Override // androidx.lifecycle.com7.nul, androidx.lifecycle.com7.con
    public <T extends lpt5> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return (T) c(canonicalName, cls);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Override // androidx.lifecycle.com7.com1
    public void b(lpt5 lpt5Var) {
        SavedStateHandleController.h(lpt5Var, this.f2623a, this.f2622a);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0046 A[Catch: InvocationTargetException -> 0x005a, InstantiationException -> 0x0076, IllegalAccessException -> 0x0093, TryCatch #2 {IllegalAccessException -> 0x0093, InstantiationException -> 0x0076, InvocationTargetException -> 0x005a, blocks: (B:13:0x0030, B:15:0x0034, B:17:0x0054, B:16:0x0046), top: B:28:0x0030 }] */
    @Override // androidx.lifecycle.com7.nul
    public <T extends lpt5> T c(String str, Class<T> cls) {
        T t2;
        boolean zIsAssignableFrom = COM3.aux.class.isAssignableFrom(cls);
        Constructor constructorD = (!zIsAssignableFrom || this.f2619a == null) ? d(cls, f8405b) : d(cls, f8404a);
        if (constructorD == null) {
            return (T) this.f2621a.a(cls);
        }
        SavedStateHandleController savedStateHandleControllerJ = SavedStateHandleController.j(this.f2623a, this.f2622a, str, this.f2620a);
        if (zIsAssignableFrom) {
            try {
                Application application = this.f2619a;
                if (application != null) {
                    t2 = (T) constructorD.newInstance(application, savedStateHandleControllerJ.k());
                } else {
                    t2 = (T) constructorD.newInstance(savedStateHandleControllerJ.k());
                }
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Failed to access " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("A " + cls + " cannot be instantiated.", e3);
            } catch (InvocationTargetException e4) {
                throw new RuntimeException("An exception happened in constructor of " + cls, e4.getCause());
            }
        } else {
            t2 = (T) constructorD.newInstance(savedStateHandleControllerJ.k());
        }
        t2.e("androidx.lifecycle.savedstate.vm.tag", savedStateHandleControllerJ);
        return t2;
    }
}
