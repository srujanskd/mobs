package a0;

import f.com8;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import p127lPt9.a0;
import p127lPt9.u;
import p127lPt9.v;
import v.i;
import v.lpt5;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
public final class com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f7615a = new aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f1583a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com4 f1584a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<? extends Proxy> f1585a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final v.aux f1586a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final v.com1 f1587a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt5 f1588a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public List<? extends InetSocketAddress> f7616b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final List<i> f7617c;

    public static final class aux {
        public aux() {
        }

        public /* synthetic */ aux(f.com3 com3Var) {
            this();
        }

        public final String a(InetSocketAddress inetSocketAddress) {
            com8.e(inetSocketAddress, "<this>");
            InetAddress address = inetSocketAddress.getAddress();
            if (address == null) {
                String hostName = inetSocketAddress.getHostName();
                com8.d(hostName, "hostName");
                return hostName;
            }
            String hostAddress = address.getHostAddress();
            com8.d(hostAddress, "address.hostAddress");
            return hostAddress;
        }
    }

    public static final class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7618a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final List<i> f1589a;

        public con(List<i> list) {
            com8.e(list, "routes");
            this.f1589a = list;
        }

        public final List<i> a() {
            return this.f1589a;
        }

        public final boolean b() {
            return this.f7618a < this.f1589a.size();
        }

        public final i c() {
            if (!b()) {
                throw new NoSuchElementException();
            }
            List<i> list = this.f1589a;
            int i2 = this.f7618a;
            this.f7618a = i2 + 1;
            return list.get(i2);
        }
    }

    public com6(v.aux auxVar, com4 com4Var, v.com1 com1Var, lpt5 lpt5Var) {
        com8.e(auxVar, "address");
        com8.e(com4Var, "routeDatabase");
        com8.e(com1Var, "call");
        com8.e(lpt5Var, "eventListener");
        this.f1586a = auxVar;
        this.f1584a = com4Var;
        this.f1587a = com1Var;
        this.f1588a = lpt5Var;
        this.f1585a = v.f();
        this.f7616b = v.f();
        this.f7617c = new ArrayList();
        f(auxVar.l(), auxVar.g());
    }

    public static final List<Proxy> g(Proxy proxy, lpt9 lpt9Var, com6 com6Var) {
        if (proxy != null) {
            return u.b(proxy);
        }
        URI uriR = lpt9Var.r();
        if (uriR.getHost() == null) {
            return w.com1.w(Proxy.NO_PROXY);
        }
        List<Proxy> listSelect = com6Var.f1586a.i().select(uriR);
        if (listSelect == null || listSelect.isEmpty()) {
            return w.com1.w(Proxy.NO_PROXY);
        }
        com8.d(listSelect, "proxiesOrNull");
        return w.com1.S(listSelect);
    }

    public final boolean a() {
        return b() || (this.f7617c.isEmpty() ^ true);
    }

    public final boolean b() {
        return this.f1583a < this.f1585a.size();
    }

    public final con c() throws IOException {
        if (!a()) {
            throw new NoSuchElementException();
        }
        ArrayList arrayList = new ArrayList();
        while (b()) {
            Proxy proxyD = d();
            Iterator<? extends InetSocketAddress> it = this.f7616b.iterator();
            while (it.hasNext()) {
                i iVar = new i(this.f1586a, proxyD, it.next());
                if (this.f1584a.c(iVar)) {
                    this.f7617c.add(iVar);
                } else {
                    arrayList.add(iVar);
                }
            }
            if (!arrayList.isEmpty()) {
                break;
            }
        }
        if (arrayList.isEmpty()) {
            a0.p(arrayList, this.f7617c);
            this.f7617c.clear();
        }
        return new con(arrayList);
    }

    public final Proxy d() throws IOException {
        if (b()) {
            List<? extends Proxy> list = this.f1585a;
            int i2 = this.f1583a;
            this.f1583a = i2 + 1;
            Proxy proxy = list.get(i2);
            e(proxy);
            return proxy;
        }
        throw new SocketException("No route to " + this.f1586a.l().h() + "; exhausted proxy configurations: " + this.f1585a);
    }

    public final void e(Proxy proxy) throws IOException {
        String strH;
        int iM;
        ArrayList arrayList = new ArrayList();
        this.f7616b = arrayList;
        if (proxy.type() == Proxy.Type.DIRECT || proxy.type() == Proxy.Type.SOCKS) {
            strH = this.f1586a.l().h();
            iM = this.f1586a.l().m();
        } else {
            SocketAddress socketAddressAddress = proxy.address();
            if (!(socketAddressAddress instanceof InetSocketAddress)) {
                throw new IllegalArgumentException(com8.k("Proxy.address() is not an InetSocketAddress: ", socketAddressAddress.getClass()).toString());
            }
            aux auxVar = f7615a;
            com8.d(socketAddressAddress, "proxyAddress");
            InetSocketAddress inetSocketAddress = (InetSocketAddress) socketAddressAddress;
            strH = auxVar.a(inetSocketAddress);
            iM = inetSocketAddress.getPort();
        }
        boolean z2 = false;
        if (1 <= iM && iM < 65536) {
            z2 = true;
        }
        if (!z2) {
            throw new SocketException("No route to " + strH + ':' + iM + "; port is out of range");
        }
        if (proxy.type() == Proxy.Type.SOCKS) {
            arrayList.add(InetSocketAddress.createUnresolved(strH, iM));
            return;
        }
        this.f1588a.m(this.f1587a, strH);
        List<InetAddress> listA = this.f1586a.c().a(strH);
        if (listA.isEmpty()) {
            throw new UnknownHostException(this.f1586a.c() + " returned no addresses for " + strH);
        }
        this.f1588a.l(this.f1587a, strH, listA);
        Iterator<InetAddress> it = listA.iterator();
        while (it.hasNext()) {
            arrayList.add(new InetSocketAddress(it.next(), iM));
        }
    }

    public final void f(lpt9 lpt9Var, Proxy proxy) {
        this.f1588a.o(this.f1587a, lpt9Var);
        List<Proxy> listG = g(proxy, lpt9Var, this);
        this.f1585a = listG;
        this.f1583a = 0;
        this.f1588a.n(this.f1587a, lpt9Var, listG);
    }
}
