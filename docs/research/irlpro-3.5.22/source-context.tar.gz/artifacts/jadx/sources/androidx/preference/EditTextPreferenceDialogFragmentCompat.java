package androidx.preference;

import android.R;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

/* JADX INFO: loaded from: classes.dex */
public class EditTextPreferenceDialogFragmentCompat extends PreferenceDialogFragmentCompat {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public EditText f2633a;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CharSequence f8429e;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2634a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f8428a = -1;

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            EditTextPreferenceDialogFragmentCompat.this.v();
        }
    }

    public static EditTextPreferenceDialogFragmentCompat t(String str) {
        EditTextPreferenceDialogFragmentCompat editTextPreferenceDialogFragmentCompat = new EditTextPreferenceDialogFragmentCompat();
        Bundle bundle = new Bundle(1);
        bundle.putString("key", str);
        editTextPreferenceDialogFragmentCompat.setArguments(bundle);
        return editTextPreferenceDialogFragmentCompat;
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public boolean k() {
        return true;
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void l(View view) {
        super.l(view);
        EditText editText = (EditText) view.findViewById(R.id.edit);
        this.f2633a = editText;
        if (editText == null) {
            throw new IllegalStateException("Dialog view must contain an EditText with id @android:id/edit");
        }
        editText.requestFocus();
        this.f2633a.setText(this.f8429e);
        EditText editText2 = this.f2633a;
        editText2.setSelection(editText2.getText().length());
        if (r().a() != null) {
            r().a().a(this.f2633a);
        }
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void n(boolean z2) {
        if (z2) {
            String string = this.f2633a.getText().toString();
            EditTextPreference editTextPreferenceR = r();
            if (editTextPreferenceR.callChangeListener(string)) {
                editTextPreferenceR.d(string);
            }
        }
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle == null) {
            this.f8429e = r().b();
        } else {
            this.f8429e = bundle.getCharSequence("EditTextPreferenceDialogFragment.text");
        }
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putCharSequence("EditTextPreferenceDialogFragment.text", this.f8429e);
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void q() {
        w(true);
        v();
    }

    public final EditTextPreference r() {
        return (EditTextPreference) j();
    }

    public final boolean s() {
        long j2 = this.f8428a;
        return j2 != -1 && j2 + 1000 > SystemClock.currentThreadTimeMillis();
    }

    public void v() {
        if (s()) {
            EditText editText = this.f2633a;
            if (editText == null || !editText.isFocused()) {
                w(false);
            } else if (((InputMethodManager) this.f2633a.getContext().getSystemService("input_method")).showSoftInput(this.f2633a, 0)) {
                w(false);
            } else {
                this.f2633a.removeCallbacks(this.f2634a);
                this.f2633a.postDelayed(this.f2634a, 50L);
            }
        }
    }

    public final void w(boolean z2) {
        this.f8428a = z2 ? SystemClock.currentThreadTimeMillis() : -1L;
    }
}
