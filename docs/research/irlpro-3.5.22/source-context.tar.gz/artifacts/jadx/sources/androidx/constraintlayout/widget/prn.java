package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;
import p151pRn.h0;

/* JADX INFO: loaded from: classes.dex */
public class prn extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public nul f8138a;

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public aux generateDefaultLayoutParams() {
        return new aux(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public aux generateLayoutParams(AttributeSet attributeSet) {
        return new aux(getContext(), attributeSet);
    }

    public nul getConstraintSet() {
        if (this.f8138a == null) {
            this.f8138a = new nul();
        }
        this.f8138a.h(this);
        return this.f8138a;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ConstraintLayout.con(layoutParams);
    }

    public static class aux extends ConstraintLayout.con {

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public float f8139l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public float f8140m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public float f8141n;

        /* JADX INFO: renamed from: n, reason: collision with other field name */
        public boolean f2269n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public float f8142o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public float f8143p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public float f8144q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public float f8145r;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public float f8146s;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public float f8147t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public float f8148u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public float f8149v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public float f8150w;

        public aux(int i2, int i3) {
            super(i2, i3);
            this.f8139l = 1.0f;
            this.f2269n = false;
            this.f8140m = 0.0f;
            this.f8141n = 0.0f;
            this.f8142o = 0.0f;
            this.f8143p = 0.0f;
            this.f8144q = 1.0f;
            this.f8145r = 1.0f;
            this.f8146s = 0.0f;
            this.f8147t = 0.0f;
            this.f8148u = 0.0f;
            this.f8149v = 0.0f;
            this.f8150w = 0.0f;
        }

        public aux(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f8139l = 1.0f;
            this.f2269n = false;
            this.f8140m = 0.0f;
            this.f8141n = 0.0f;
            this.f8142o = 0.0f;
            this.f8143p = 0.0f;
            this.f8144q = 1.0f;
            this.f8145r = 1.0f;
            this.f8146s = 0.0f;
            this.f8147t = 0.0f;
            this.f8148u = 0.0f;
            this.f8149v = 0.0f;
            this.f8150w = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h0.f5232y);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                if (index == h0.N3) {
                    this.f8139l = typedArrayObtainStyledAttributes.getFloat(index, this.f8139l);
                } else if (index == h0.Y3) {
                    this.f8140m = typedArrayObtainStyledAttributes.getFloat(index, this.f8140m);
                    this.f2269n = true;
                } else if (index == h0.V3) {
                    this.f8142o = typedArrayObtainStyledAttributes.getFloat(index, this.f8142o);
                } else if (index == h0.W3) {
                    this.f8143p = typedArrayObtainStyledAttributes.getFloat(index, this.f8143p);
                } else if (index == h0.U3) {
                    this.f8141n = typedArrayObtainStyledAttributes.getFloat(index, this.f8141n);
                } else if (index == h0.S3) {
                    this.f8144q = typedArrayObtainStyledAttributes.getFloat(index, this.f8144q);
                } else if (index == h0.T3) {
                    this.f8145r = typedArrayObtainStyledAttributes.getFloat(index, this.f8145r);
                } else if (index == h0.O3) {
                    this.f8146s = typedArrayObtainStyledAttributes.getFloat(index, this.f8146s);
                } else if (index == h0.P3) {
                    this.f8147t = typedArrayObtainStyledAttributes.getFloat(index, this.f8147t);
                } else if (index == h0.Q3) {
                    this.f8148u = typedArrayObtainStyledAttributes.getFloat(index, this.f8148u);
                } else if (index == h0.R3) {
                    this.f8149v = typedArrayObtainStyledAttributes.getFloat(index, this.f8149v);
                } else if (index == h0.X3) {
                    this.f8150w = typedArrayObtainStyledAttributes.getFloat(index, this.f8150w);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }
}
