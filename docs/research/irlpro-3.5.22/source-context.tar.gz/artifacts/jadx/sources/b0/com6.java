package b0;

import androidx.preference.Preference;
import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.instrumentation.okhttp3.OkHttp3Instrumentation;
import com.newrelic.agent.android.util.Constants;
import f.com8;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import java.util.List;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import p127lPt9.d0;
import p127lPt9.v;
import v.a;
import v.c;
import v.e;
import v.f;
import v.g;
import v.h;
import v.i;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class com6 implements a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f8798a = new aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final c f2994a;

    public static final class aux {
        public aux() {
        }

        public /* synthetic */ aux(f.com3 com3Var) {
            this();
        }
    }

    public com6(c cVar) {
        com8.e(cVar, "client");
        this.f2994a = cVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v22, types: [v.g] */
    /* JADX WARN: Type inference failed for: r0v8, types: [v.g] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r10v0, types: [b0.com6] */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1, types: [v.g] */
    /* JADX WARN: Type inference failed for: r7v2, types: [v.g] */
    /* JADX WARN: Type inference failed for: r7v5 */
    @Override // v.a
    public g a(a.aux auxVar) throws IOException {
        ?? B;
        com8.e(auxVar, "chain");
        com3 com3Var = (com3) auxVar;
        e eVarI = com3Var.i();
        a0.com1 com1VarE = com3Var.e();
        List listF = v.f();
        int i2 = 0;
        ?? r7 = 0;
        while (true) {
            boolean z2 = true;
            while (true) {
                com1VarE.h(eVarI, z2);
                try {
                    if (com1VarE.isCanceled()) {
                        throw new IOException("Canceled");
                    }
                    try {
                        try {
                            B = com3Var.b(eVarI);
                        } catch (a0.com5 e2) {
                            if (!e(e2.d(), com1VarE, eVarI, false)) {
                                throw w.com1.Y(e2.c(), listF);
                            }
                            listF = d0.C(listF, e2.c());
                            com1VarE.i(true);
                            z2 = false;
                        }
                    } catch (IOException e3) {
                        if (!e(e3, com1VarE, eVarI, !(e3 instanceof d0.aux))) {
                            throw w.com1.Y(e3, listF);
                        }
                        listF = d0.C(listF, e3);
                        com1VarE.i(true);
                        z2 = false;
                    }
                    com1VarE.i(true);
                    z2 = false;
                } catch (Throwable th) {
                    com1VarE.i(true);
                    throw th;
                }
            }
            if (r7 != 0) {
                g.aux auxVarH = !(B instanceof g.aux) ? B.H() : OkHttp3Instrumentation.newBuilder((g.aux) B);
                g.aux auxVarH2 = !(r7 instanceof g.aux) ? r7.H() : OkHttp3Instrumentation.newBuilder((g.aux) r7);
                B = auxVarH.priorResponse((!(auxVarH2 instanceof g.aux) ? auxVarH2.body(null) : OkHttp3Instrumentation.body(auxVarH2, null)).build()).build();
            }
            ?? r8 = B;
            a0.nul nulVarN = com1VarE.n();
            e eVarC = c(r8, nulVarN);
            if (eVarC == null) {
                if (nulVarN != null && nulVarN.l()) {
                    com1VarE.y();
                }
                com1VarE.i(false);
                return r8;
            }
            f fVarA = eVarC.a();
            if (fVarA != null && fVarA.d()) {
                com1VarE.i(false);
                return r8;
            }
            h hVarA = r8.a();
            if (hVarA != null) {
                w.com1.m(hVarA);
            }
            i2++;
            if (i2 > 20) {
                throw new ProtocolException(com8.k("Too many follow-up requests: ", Integer.valueOf(i2)));
            }
            com1VarE.i(true);
            eVarI = eVarC;
            r7 = r8;
        }
    }

    public final e b(g gVar, String str) {
        String strY;
        lpt9 lpt9VarP;
        if (!this.f2994a.n() || (strY = g.y(gVar, "Location", null, 2, null)) == null || (lpt9VarP = gVar.V().i().p(strY)) == null) {
            return null;
        }
        if (!com8.a(lpt9VarP.q(), gVar.V().i().q()) && !this.f2994a.o()) {
            return null;
        }
        e.aux auxVarH = gVar.V().h();
        if (com2.a(str)) {
            int iL = gVar.l();
            com2 com2Var = com2.f8790a;
            boolean z2 = com2Var.c(str) || iL == 308 || iL == 307;
            if (!com2Var.b(str) || iL == 308 || iL == 307) {
                auxVarH.f(str, z2 ? gVar.V().a() : null);
            } else {
                auxVarH.f("GET", null);
            }
            if (!z2) {
                auxVarH.h("Transfer-Encoding");
                auxVarH.h(Constants.Network.CONTENT_LENGTH_HEADER);
                auxVarH.h(Constants.Network.CONTENT_TYPE_HEADER);
            }
        }
        if (!w.com1.j(gVar.V().i(), lpt9VarP)) {
            auxVarH.h("Authorization");
        }
        e.aux auxVarM = auxVarH.m(lpt9VarP);
        return !(auxVarM instanceof e.aux) ? auxVarM.b() : OkHttp3Instrumentation.build(auxVarM);
    }

    public final e c(g gVar, a0.nul nulVar) throws IOException {
        a0.com2 com2VarH;
        i iVarZ = (nulVar == null || (com2VarH = nulVar.h()) == null) ? null : com2VarH.z();
        int iL = gVar.l();
        String strG = gVar.V().g();
        if (iL != 307 && iL != 308) {
            if (iL == 401) {
                return this.f2994a.c().a(iVarZ, gVar);
            }
            if (iL == 421) {
                f fVarA = gVar.V().a();
                if ((fVarA != null && fVarA.d()) || nulVar == null || !nulVar.k()) {
                    return null;
                }
                nulVar.h().x();
                return gVar.V();
            }
            if (iL == 503) {
                g gVarM = gVar.M();
                if ((gVarM == null || gVarM.l() != 503) && g(gVar, Preference.DEFAULT_ORDER) == 0) {
                    return gVar.V();
                }
                return null;
            }
            if (iL == 407) {
                com8.b(iVarZ);
                if (iVarZ.b().type() == Proxy.Type.HTTP) {
                    return this.f2994a.x().a(iVarZ, gVar);
                }
                throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
            }
            if (iL == 408) {
                if (!this.f2994a.A()) {
                    return null;
                }
                f fVarA2 = gVar.V().a();
                if (fVarA2 != null && fVarA2.d()) {
                    return null;
                }
                g gVarM2 = gVar.M();
                if ((gVarM2 == null || gVarM2.l() != 408) && g(gVar, 0) <= 0) {
                    return gVar.V();
                }
                return null;
            }
            switch (iL) {
                case 300:
                case 301:
                case 302:
                case 303:
                    break;
                default:
                    return null;
            }
        }
        return b(gVar, strG);
    }

    public final boolean d(IOException iOException, boolean z2) {
        if (iOException instanceof ProtocolException) {
            return false;
        }
        if (iOException instanceof InterruptedIOException) {
            return (iOException instanceof SocketTimeoutException) && !z2;
        }
        return (((iOException instanceof SSLHandshakeException) && (iOException.getCause() instanceof CertificateException)) || (iOException instanceof SSLPeerUnverifiedException)) ? false : true;
    }

    public final boolean e(IOException iOException, a0.com1 com1Var, e eVar, boolean z2) {
        if (this.f2994a.A()) {
            return !(z2 && f(iOException, eVar)) && d(iOException, z2) && com1Var.v();
        }
        return false;
    }

    public final boolean f(IOException iOException, e eVar) {
        f fVarA = eVar.a();
        return (fVarA != null && fVarA.d()) || (iOException instanceof FileNotFoundException);
    }

    public final int g(g gVar, int i2) {
        String strY = g.y(gVar, "Retry-After", null, 2, null);
        if (strY == null) {
            return i2;
        }
        if (!new m.com1("\\d+").a(strY)) {
            return Preference.DEFAULT_ORDER;
        }
        Integer numValueOf = Integer.valueOf(strY);
        com8.d(numValueOf, "valueOf(header)");
        return numValueOf.intValue();
    }
}
