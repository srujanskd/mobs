package androidx.fragment.app;

import COM3.lpt6;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class com8 extends COM3.lpt5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final androidx.lifecycle.com7.con f8278a = new aux();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f2481b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final HashMap<String, Fragment> f2480a = new HashMap<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap<String, com8> f8279b = new HashMap<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap<String, lpt6> f8280c = new HashMap<>();

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2482c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8281d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f8282e = false;

    public class aux implements androidx.lifecycle.com7.con {
        @Override // androidx.lifecycle.com7.con
        public <T extends COM3.lpt5> T a(Class<T> cls) {
            return new com8(true);
        }
    }

    public com8(boolean z2) {
        this.f2481b = z2;
    }

    public static com8 j(lpt6 lpt6Var) {
        return (com8) new androidx.lifecycle.com7(lpt6Var, f8278a).a(com8.class);
    }

    @Override // COM3.lpt5
    public void d() {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f2482c = true;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || com8.class != obj.getClass()) {
            return false;
        }
        com8 com8Var = (com8) obj;
        return this.f2480a.equals(com8Var.f2480a) && this.f8279b.equals(com8Var.f8279b) && this.f8280c.equals(com8Var.f8280c);
    }

    public void f(Fragment fragment) {
        if (this.f8282e) {
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved");
            }
        } else {
            if (this.f2480a.containsKey(fragment.mWho)) {
                return;
            }
            this.f2480a.put(fragment.mWho, fragment);
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Updating retained Fragments: Added " + fragment);
            }
        }
    }

    public void g(Fragment fragment) {
        if (com6.H0(3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + fragment);
        }
        com8 com8Var = this.f8279b.get(fragment.mWho);
        if (com8Var != null) {
            com8Var.d();
            this.f8279b.remove(fragment.mWho);
        }
        lpt6 lpt6Var = this.f8280c.get(fragment.mWho);
        if (lpt6Var != null) {
            lpt6Var.a();
            this.f8280c.remove(fragment.mWho);
        }
    }

    public Fragment h(String str) {
        return this.f2480a.get(str);
    }

    public int hashCode() {
        return (((this.f2480a.hashCode() * 31) + this.f8279b.hashCode()) * 31) + this.f8280c.hashCode();
    }

    public com8 i(Fragment fragment) {
        com8 com8Var = this.f8279b.get(fragment.mWho);
        if (com8Var != null) {
            return com8Var;
        }
        com8 com8Var2 = new com8(this.f2481b);
        this.f8279b.put(fragment.mWho, com8Var2);
        return com8Var2;
    }

    public Collection<Fragment> k() {
        return new ArrayList(this.f2480a.values());
    }

    public lpt6 l(Fragment fragment) {
        lpt6 lpt6Var = this.f8280c.get(fragment.mWho);
        if (lpt6Var != null) {
            return lpt6Var;
        }
        lpt6 lpt6Var2 = new lpt6();
        this.f8280c.put(fragment.mWho, lpt6Var2);
        return lpt6Var2;
    }

    public boolean m() {
        return this.f2482c;
    }

    public void n(Fragment fragment) {
        if (this.f8282e) {
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
                return;
            }
            return;
        }
        if ((this.f2480a.remove(fragment.mWho) != null) && com6.H0(2)) {
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + fragment);
        }
    }

    public void o(boolean z2) {
        this.f8282e = z2;
    }

    public boolean p(Fragment fragment) {
        if (this.f2480a.containsKey(fragment.mWho)) {
            return this.f2481b ? this.f2482c : !this.f8281d;
        }
        return true;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator<Fragment> it = this.f2480a.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator<String> it2 = this.f8279b.keySet().iterator();
        while (it2.hasNext()) {
            sb.append(it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator<String> it3 = this.f8280c.keySet().iterator();
        while (it3.hasNext()) {
            sb.append(it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
