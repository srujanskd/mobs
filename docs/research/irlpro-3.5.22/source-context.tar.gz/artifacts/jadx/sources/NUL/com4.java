package NUL;

import java.util.ArrayList;
import java.util.Iterator;
import p146nUL.l;
import p146nUL.o;
import p146nUL.p;
import p146nUL.q;
import p146nUL.r;

/* JADX INFO: loaded from: classes.dex */
public class com4 {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static con.aux f1364a = new con.aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int f7376a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static int f7377b = 0;

    public static boolean a(int i2, p pVar) {
        p.con conVar;
        p.con conVar2;
        p.con conVarY = pVar.y();
        p.con conVarR = pVar.R();
        q qVar = pVar.I() != null ? (q) pVar.I() : null;
        if (qVar != null) {
            qVar.y();
            p.con conVar3 = p.con.FIXED;
        }
        if (qVar != null) {
            qVar.R();
            p.con conVar4 = p.con.FIXED;
        }
        p.con conVar5 = p.con.FIXED;
        boolean z2 = conVarY == conVar5 || pVar.l0() || conVarY == p.con.WRAP_CONTENT || (conVarY == (conVar2 = p.con.MATCH_CONSTRAINT) && pVar.f4974f == 0 && pVar.f11500e == 0.0f && pVar.Y(0)) || (conVarY == conVar2 && pVar.f4974f == 1 && pVar.b0(0, pVar.U()));
        boolean z3 = conVarR == conVar5 || pVar.m0() || conVarR == p.con.WRAP_CONTENT || (conVarR == (conVar = p.con.MATCH_CONSTRAINT) && pVar.f4977g == 0 && pVar.f11500e == 0.0f && pVar.Y(1)) || (conVarR == conVar && pVar.f4977g == 1 && pVar.b0(1, pVar.v()));
        if (pVar.f11500e <= 0.0f || !(z2 || z3)) {
            return z2 && z3;
        }
        return true;
    }

    public static void b(int i2, p pVar, con.InterfaceC0018con interfaceC0018con, boolean z2) {
        o oVar;
        o oVar2;
        o oVar3;
        o oVar4;
        if (pVar.e0()) {
            return;
        }
        boolean z3 = true;
        f7376a++;
        if (!(pVar instanceof q) && pVar.k0()) {
            int i3 = i2 + 1;
            if (a(i3, pVar)) {
                q.O1(i3, pVar, interfaceC0018con, new con.aux(), con.aux.f7385g);
            }
        }
        o oVarM = pVar.m(o.con.LEFT);
        o oVarM2 = pVar.m(o.con.RIGHT);
        int iD = oVarM.d();
        int iD2 = oVarM2.d();
        if (oVarM.c() != null && oVarM.m()) {
            Iterator<o> it = oVarM.c().iterator();
            while (it.hasNext()) {
                o next = it.next();
                p pVar2 = next.f4933a;
                int i4 = i2 + 1;
                boolean zA = a(i4, pVar2);
                if (pVar2.k0() && zA) {
                    q.O1(i4, pVar2, interfaceC0018con, new con.aux(), con.aux.f7385g);
                }
                boolean z4 = ((next == pVar2.f4944a && (oVar4 = pVar2.f4965c.f4932a) != null && oVar4.m()) || (next == pVar2.f4965c && (oVar3 = pVar2.f4944a.f4932a) != null && oVar3.m())) ? z3 : false;
                p.con conVarY = pVar2.y();
                p.con conVar = p.con.MATCH_CONSTRAINT;
                if (conVarY != conVar || zA) {
                    if (!pVar2.k0()) {
                        o oVar5 = pVar2.f4944a;
                        if (next == oVar5 && pVar2.f4965c.f4932a == null) {
                            int iE = oVar5.e() + iD;
                            pVar2.C0(iE, pVar2.U() + iE);
                            b(i4, pVar2, interfaceC0018con, z2);
                        } else {
                            o oVar6 = pVar2.f4965c;
                            if (next == oVar6 && oVar5.f4932a == null) {
                                int iE2 = iD - oVar6.e();
                                pVar2.C0(iE2 - pVar2.U(), iE2);
                                b(i4, pVar2, interfaceC0018con, z2);
                            } else if (z4 && !pVar2.g0()) {
                                d(i4, interfaceC0018con, pVar2, z2);
                            }
                        }
                    }
                } else if (pVar2.y() == conVar && pVar2.f11503i >= 0 && pVar2.f4980h >= 0 && ((pVar2.T() == 8 || (pVar2.f4974f == 0 && pVar2.t() == 0.0f)) && !pVar2.g0() && !pVar2.j0() && z4 && !pVar2.g0())) {
                    e(i4, pVar, interfaceC0018con, pVar2, z2);
                }
                z3 = true;
            }
        }
        if (pVar instanceof r) {
            return;
        }
        if (oVarM2.c() != null && oVarM2.m()) {
            Iterator<o> it2 = oVarM2.c().iterator();
            while (it2.hasNext()) {
                o next2 = it2.next();
                p pVar3 = next2.f4933a;
                int i5 = i2 + 1;
                boolean zA2 = a(i5, pVar3);
                if (pVar3.k0() && zA2) {
                    q.O1(i5, pVar3, interfaceC0018con, new con.aux(), con.aux.f7385g);
                }
                boolean z5 = (next2 == pVar3.f4944a && (oVar2 = pVar3.f4965c.f4932a) != null && oVar2.m()) || (next2 == pVar3.f4965c && (oVar = pVar3.f4944a.f4932a) != null && oVar.m());
                p.con conVarY2 = pVar3.y();
                p.con conVar2 = p.con.MATCH_CONSTRAINT;
                if (conVarY2 != conVar2 || zA2) {
                    if (!pVar3.k0()) {
                        o oVar7 = pVar3.f4944a;
                        if (next2 == oVar7 && pVar3.f4965c.f4932a == null) {
                            int iE3 = oVar7.e() + iD2;
                            pVar3.C0(iE3, pVar3.U() + iE3);
                            b(i5, pVar3, interfaceC0018con, z2);
                        } else {
                            o oVar8 = pVar3.f4965c;
                            if (next2 == oVar8 && oVar7.f4932a == null) {
                                int iE4 = iD2 - oVar8.e();
                                pVar3.C0(iE4 - pVar3.U(), iE4);
                                b(i5, pVar3, interfaceC0018con, z2);
                            } else if (z5 && !pVar3.g0()) {
                                d(i5, interfaceC0018con, pVar3, z2);
                            }
                        }
                    }
                } else if (pVar3.y() == conVar2 && pVar3.f11503i >= 0 && pVar3.f4980h >= 0 && (pVar3.T() == 8 || (pVar3.f4974f == 0 && pVar3.t() == 0.0f))) {
                    if (!pVar3.g0() && !pVar3.j0() && z5 && !pVar3.g0()) {
                        e(i5, pVar, interfaceC0018con, pVar3, z2);
                    }
                }
            }
        }
        pVar.o0();
    }

    public static void c(int i2, l lVar, con.InterfaceC0018con interfaceC0018con, int i3, boolean z2) {
        if (lVar.q1()) {
            if (i3 == 0) {
                b(i2 + 1, lVar, interfaceC0018con, z2);
            } else {
                i(i2 + 1, lVar, interfaceC0018con);
            }
        }
    }

    public static void d(int i2, con.InterfaceC0018con interfaceC0018con, p pVar, boolean z2) {
        float fW = pVar.w();
        int iD = pVar.f4944a.f4932a.d();
        int iD2 = pVar.f4965c.f4932a.d();
        int iE = pVar.f4944a.e() + iD;
        int iE2 = iD2 - pVar.f4965c.e();
        if (iD == iD2) {
            fW = 0.5f;
        } else {
            iD = iE;
            iD2 = iE2;
        }
        int iU = pVar.U();
        int i3 = (iD2 - iD) - iU;
        if (iD > iD2) {
            i3 = (iD - iD2) - iU;
        }
        int i4 = ((int) (i3 > 0 ? (fW * i3) + 0.5f : fW * i3)) + iD;
        int i5 = i4 + iU;
        if (iD > iD2) {
            i5 = i4 - iU;
        }
        pVar.C0(i4, i5);
        b(i2 + 1, pVar, interfaceC0018con, z2);
    }

    public static void e(int i2, p pVar, con.InterfaceC0018con interfaceC0018con, p pVar2, boolean z2) {
        float fW = pVar2.w();
        int iD = pVar2.f4944a.f4932a.d() + pVar2.f4944a.e();
        int iD2 = pVar2.f4965c.f4932a.d() - pVar2.f4965c.e();
        if (iD2 >= iD) {
            int iU = pVar2.U();
            if (pVar2.T() != 8) {
                int i3 = pVar2.f4974f;
                if (i3 == 2) {
                    iU = (int) (pVar2.w() * 0.5f * (pVar instanceof q ? pVar.U() : pVar.I().U()));
                } else if (i3 == 0) {
                    iU = iD2 - iD;
                }
                iU = Math.max(pVar2.f4980h, iU);
                int i4 = pVar2.f11503i;
                if (i4 > 0) {
                    iU = Math.min(i4, iU);
                }
            }
            int i5 = iD + ((int) ((fW * ((iD2 - iD) - iU)) + 0.5f));
            pVar2.C0(i5, iU + i5);
            b(i2 + 1, pVar2, interfaceC0018con, z2);
        }
    }

    public static void f(int i2, con.InterfaceC0018con interfaceC0018con, p pVar) {
        float fP = pVar.P();
        int iD = pVar.f4957b.f4932a.d();
        int iD2 = pVar.f4969d.f4932a.d();
        int iE = pVar.f4957b.e() + iD;
        int iE2 = iD2 - pVar.f4969d.e();
        if (iD == iD2) {
            fP = 0.5f;
        } else {
            iD = iE;
            iD2 = iE2;
        }
        int iV = pVar.v();
        int i3 = (iD2 - iD) - iV;
        if (iD > iD2) {
            i3 = (iD - iD2) - iV;
        }
        int i4 = (int) (i3 > 0 ? (fP * i3) + 0.5f : fP * i3);
        int i5 = iD + i4;
        int i6 = i5 + iV;
        if (iD > iD2) {
            i5 = iD - i4;
            i6 = i5 - iV;
        }
        pVar.F0(i5, i6);
        i(i2 + 1, pVar, interfaceC0018con);
    }

    public static void g(int i2, p pVar, con.InterfaceC0018con interfaceC0018con, p pVar2) {
        float fP = pVar2.P();
        int iD = pVar2.f4957b.f4932a.d() + pVar2.f4957b.e();
        int iD2 = pVar2.f4969d.f4932a.d() - pVar2.f4969d.e();
        if (iD2 >= iD) {
            int iV = pVar2.v();
            if (pVar2.T() != 8) {
                int i3 = pVar2.f4977g;
                if (i3 == 2) {
                    iV = (int) (fP * 0.5f * (pVar instanceof q ? pVar.v() : pVar.I().v()));
                } else if (i3 == 0) {
                    iV = iD2 - iD;
                }
                iV = Math.max(pVar2.f11504j, iV);
                int i4 = pVar2.f11505k;
                if (i4 > 0) {
                    iV = Math.min(i4, iV);
                }
            }
            int i5 = iD + ((int) ((fP * ((iD2 - iD) - iV)) + 0.5f));
            pVar2.F0(i5, iV + i5);
            i(i2 + 1, pVar2, interfaceC0018con);
        }
    }

    public static void h(q qVar, con.InterfaceC0018con interfaceC0018con) {
        p.con conVarY = qVar.y();
        p.con conVarR = qVar.R();
        f7376a = 0;
        f7377b = 0;
        qVar.s0();
        ArrayList<p> arrayListO1 = qVar.o1();
        int size = arrayListO1.size();
        for (int i2 = 0; i2 < size; i2++) {
            arrayListO1.get(i2).s0();
        }
        boolean zL1 = qVar.L1();
        if (conVarY == p.con.FIXED) {
            qVar.C0(0, qVar.U());
        } else {
            qVar.D0(0);
        }
        boolean z2 = false;
        boolean z3 = false;
        for (int i3 = 0; i3 < size; i3++) {
            p pVar = arrayListO1.get(i3);
            if (pVar instanceof r) {
                r rVar = (r) pVar;
                if (rVar.p1() == 1) {
                    if (rVar.q1() != -1) {
                        rVar.t1(rVar.q1());
                    } else if (rVar.r1() != -1 && qVar.l0()) {
                        rVar.t1(qVar.U() - rVar.r1());
                    } else if (qVar.l0()) {
                        rVar.t1((int) ((rVar.s1() * qVar.U()) + 0.5f));
                    }
                    z2 = true;
                }
            } else if ((pVar instanceof l) && ((l) pVar).u1() == 0) {
                z3 = true;
            }
        }
        if (z2) {
            for (int i4 = 0; i4 < size; i4++) {
                p pVar2 = arrayListO1.get(i4);
                if (pVar2 instanceof r) {
                    r rVar2 = (r) pVar2;
                    if (rVar2.p1() == 1) {
                        b(0, rVar2, interfaceC0018con, zL1);
                    }
                }
            }
        }
        b(0, qVar, interfaceC0018con, zL1);
        if (z3) {
            for (int i5 = 0; i5 < size; i5++) {
                p pVar3 = arrayListO1.get(i5);
                if (pVar3 instanceof l) {
                    l lVar = (l) pVar3;
                    if (lVar.u1() == 0) {
                        c(0, lVar, interfaceC0018con, 0, zL1);
                    }
                }
            }
        }
        if (conVarR == p.con.FIXED) {
            qVar.F0(0, qVar.v());
        } else {
            qVar.E0(0);
        }
        boolean z4 = false;
        boolean z5 = false;
        for (int i6 = 0; i6 < size; i6++) {
            p pVar4 = arrayListO1.get(i6);
            if (pVar4 instanceof r) {
                r rVar3 = (r) pVar4;
                if (rVar3.p1() == 0) {
                    if (rVar3.q1() != -1) {
                        rVar3.t1(rVar3.q1());
                    } else if (rVar3.r1() != -1 && qVar.m0()) {
                        rVar3.t1(qVar.v() - rVar3.r1());
                    } else if (qVar.m0()) {
                        rVar3.t1((int) ((rVar3.s1() * qVar.v()) + 0.5f));
                    }
                    z4 = true;
                }
            } else if ((pVar4 instanceof l) && ((l) pVar4).u1() == 1) {
                z5 = true;
            }
        }
        if (z4) {
            for (int i7 = 0; i7 < size; i7++) {
                p pVar5 = arrayListO1.get(i7);
                if (pVar5 instanceof r) {
                    r rVar4 = (r) pVar5;
                    if (rVar4.p1() == 0) {
                        i(1, rVar4, interfaceC0018con);
                    }
                }
            }
        }
        i(0, qVar, interfaceC0018con);
        if (z5) {
            for (int i8 = 0; i8 < size; i8++) {
                p pVar6 = arrayListO1.get(i8);
                if (pVar6 instanceof l) {
                    l lVar2 = (l) pVar6;
                    if (lVar2.u1() == 1) {
                        c(0, lVar2, interfaceC0018con, 1, zL1);
                    }
                }
            }
        }
        for (int i9 = 0; i9 < size; i9++) {
            p pVar7 = arrayListO1.get(i9);
            if (pVar7.k0() && a(0, pVar7)) {
                q.O1(0, pVar7, interfaceC0018con, f1364a, con.aux.f7385g);
                if (!(pVar7 instanceof r)) {
                    b(0, pVar7, interfaceC0018con, zL1);
                    i(0, pVar7, interfaceC0018con);
                } else if (((r) pVar7).p1() == 0) {
                    i(0, pVar7, interfaceC0018con);
                } else {
                    b(0, pVar7, interfaceC0018con, zL1);
                }
            }
        }
    }

    public static void i(int i2, p pVar, con.InterfaceC0018con interfaceC0018con) {
        o oVar;
        o oVar2;
        o oVar3;
        o oVar4;
        if (pVar.n0()) {
            return;
        }
        f7377b++;
        if (!(pVar instanceof q) && pVar.k0()) {
            int i3 = i2 + 1;
            if (a(i3, pVar)) {
                q.O1(i3, pVar, interfaceC0018con, new con.aux(), con.aux.f7385g);
            }
        }
        o oVarM = pVar.m(o.con.TOP);
        o oVarM2 = pVar.m(o.con.BOTTOM);
        int iD = oVarM.d();
        int iD2 = oVarM2.d();
        if (oVarM.c() != null && oVarM.m()) {
            Iterator<o> it = oVarM.c().iterator();
            while (it.hasNext()) {
                o next = it.next();
                p pVar2 = next.f4933a;
                int i4 = i2 + 1;
                boolean zA = a(i4, pVar2);
                if (pVar2.k0() && zA) {
                    q.O1(i4, pVar2, interfaceC0018con, new con.aux(), con.aux.f7385g);
                }
                boolean z2 = (next == pVar2.f4957b && (oVar4 = pVar2.f4969d.f4932a) != null && oVar4.m()) || (next == pVar2.f4969d && (oVar3 = pVar2.f4957b.f4932a) != null && oVar3.m());
                p.con conVarR = pVar2.R();
                p.con conVar = p.con.MATCH_CONSTRAINT;
                if (conVarR != conVar || zA) {
                    if (!pVar2.k0()) {
                        o oVar5 = pVar2.f4957b;
                        if (next == oVar5 && pVar2.f4969d.f4932a == null) {
                            int iE = oVar5.e() + iD;
                            pVar2.F0(iE, pVar2.v() + iE);
                            i(i4, pVar2, interfaceC0018con);
                        } else {
                            o oVar6 = pVar2.f4969d;
                            if (next == oVar6 && oVar5.f4932a == null) {
                                int iE2 = iD - oVar6.e();
                                pVar2.F0(iE2 - pVar2.v(), iE2);
                                i(i4, pVar2, interfaceC0018con);
                            } else if (z2 && !pVar2.i0()) {
                                f(i4, interfaceC0018con, pVar2);
                            }
                        }
                    }
                } else if (pVar2.R() == conVar && pVar2.f11505k >= 0 && pVar2.f11504j >= 0 && (pVar2.T() == 8 || (pVar2.f4977g == 0 && pVar2.t() == 0.0f))) {
                    if (!pVar2.i0() && !pVar2.j0() && z2 && !pVar2.i0()) {
                        g(i4, pVar, interfaceC0018con, pVar2);
                    }
                }
            }
        }
        if (pVar instanceof r) {
            return;
        }
        if (oVarM2.c() != null && oVarM2.m()) {
            Iterator<o> it2 = oVarM2.c().iterator();
            while (it2.hasNext()) {
                o next2 = it2.next();
                p pVar3 = next2.f4933a;
                int i5 = i2 + 1;
                boolean zA2 = a(i5, pVar3);
                if (pVar3.k0() && zA2) {
                    q.O1(i5, pVar3, interfaceC0018con, new con.aux(), con.aux.f7385g);
                }
                boolean z3 = (next2 == pVar3.f4957b && (oVar2 = pVar3.f4969d.f4932a) != null && oVar2.m()) || (next2 == pVar3.f4969d && (oVar = pVar3.f4957b.f4932a) != null && oVar.m());
                p.con conVarR2 = pVar3.R();
                p.con conVar2 = p.con.MATCH_CONSTRAINT;
                if (conVarR2 != conVar2 || zA2) {
                    if (!pVar3.k0()) {
                        o oVar7 = pVar3.f4957b;
                        if (next2 == oVar7 && pVar3.f4969d.f4932a == null) {
                            int iE3 = oVar7.e() + iD2;
                            pVar3.F0(iE3, pVar3.v() + iE3);
                            i(i5, pVar3, interfaceC0018con);
                        } else {
                            o oVar8 = pVar3.f4969d;
                            if (next2 == oVar8 && oVar7.f4932a == null) {
                                int iE4 = iD2 - oVar8.e();
                                pVar3.F0(iE4 - pVar3.v(), iE4);
                                i(i5, pVar3, interfaceC0018con);
                            } else if (z3 && !pVar3.i0()) {
                                f(i5, interfaceC0018con, pVar3);
                            }
                        }
                    }
                } else if (pVar3.R() == conVar2 && pVar3.f11505k >= 0 && pVar3.f11504j >= 0 && (pVar3.T() == 8 || (pVar3.f4977g == 0 && pVar3.t() == 0.0f))) {
                    if (!pVar3.i0() && !pVar3.j0() && z3 && !pVar3.i0()) {
                        g(i5, pVar, interfaceC0018con, pVar3);
                    }
                }
            }
        }
        o oVarM3 = pVar.m(o.con.BASELINE);
        if (oVarM3.c() != null && oVarM3.m()) {
            int iD3 = oVarM3.d();
            for (o oVar9 : oVarM3.c()) {
                p pVar4 = oVar9.f4933a;
                int i6 = i2 + 1;
                boolean zA3 = a(i6, pVar4);
                if (pVar4.k0() && zA3) {
                    q.O1(i6, pVar4, interfaceC0018con, new con.aux(), con.aux.f7385g);
                }
                if (pVar4.R() != p.con.MATCH_CONSTRAINT || zA3) {
                    if (!pVar4.k0() && oVar9 == pVar4.f4972e) {
                        pVar4.B0(oVar9.e() + iD3);
                        i(i6, pVar4, interfaceC0018con);
                    }
                }
            }
        }
        pVar.p0();
    }
}
