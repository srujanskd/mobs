package androidx.lifecycle;

import COM3.com9;

/* JADX INFO: loaded from: classes.dex */
public interface con {
    void a(COM3.com7 com7Var, nul.con conVar, boolean z2, com9 com9Var);
}
