package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import com.newrelic.agent.android.api.v1.Defaults;
import java.io.IOException;
import java.nio.ByteBuffer;
import p013CoM1.com8;
import p025Com3.v;
import p025Com3.y;
import p082cOm3.g0;
import p101com2.u2;

/* JADX INFO: loaded from: classes.dex */
public final class com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Typeface f8185a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final aux f2336a = new aux(Defaults.RESPONSE_BODY_LIMIT);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final g0 f2337a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final char[] f2338a;

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public v f8186a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final SparseArray<aux> f2339a;

        public aux() {
            this(1);
        }

        public aux a(int i2) {
            SparseArray<aux> sparseArray = this.f2339a;
            if (sparseArray == null) {
                return null;
            }
            return sparseArray.get(i2);
        }

        public final v b() {
            return this.f8186a;
        }

        public void c(v vVar, int i2, int i3) {
            aux auxVarA = a(vVar.b(i2));
            if (auxVarA == null) {
                auxVarA = new aux();
                this.f2339a.put(vVar.b(i2), auxVarA);
            }
            if (i3 > i2) {
                auxVarA.c(vVar, i2 + 1, i3);
            } else {
                auxVarA.f8186a = vVar;
            }
        }

        public aux(int i2) {
            this.f2339a = new SparseArray<>(i2);
        }
    }

    public com1(Typeface typeface, g0 g0Var) {
        this.f8185a = typeface;
        this.f2337a = g0Var;
        this.f2338a = new char[g0Var.k() * 2];
        a(g0Var);
    }

    public static com1 b(Typeface typeface, ByteBuffer byteBuffer) throws IOException {
        try {
            com8.a("EmojiCompat.MetadataRepo.create");
            return new com1(typeface, y.b(byteBuffer));
        } finally {
            com8.b();
        }
    }

    public final void a(g0 g0Var) {
        int iK = g0Var.k();
        for (int i2 = 0; i2 < iK; i2++) {
            v vVar = new v(this, i2);
            Character.toChars(vVar.f(), this.f2338a, i2 * 2);
            h(vVar);
        }
    }

    public char[] c() {
        return this.f2338a;
    }

    public g0 d() {
        return this.f2337a;
    }

    public int e() {
        return this.f2337a.l();
    }

    public aux f() {
        return this.f2336a;
    }

    public Typeface g() {
        return this.f8185a;
    }

    public void h(v vVar) {
        u2.g(vVar, "emoji metadata cannot be null");
        u2.a(vVar.c() > 0, "invalid metadata codepoint length");
        this.f2336a.c(vVar, 0, vVar.c() - 1);
    }
}
