package com.google.android.material.datepicker;

import COM9.com3;
import android.R;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.lpt3;
import com.google.android.material.internal.CheckableImageButton;
import com.newrelic.agent.android.api.v2.TraceFieldInterface;
import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.tracing.Trace;
import com.newrelic.agent.android.tracing.TraceMachine;
import java.util.Iterator;
import java.util.LinkedHashSet;
import p024Com2.s;
import p024Com2.t0;
import p024Com2.y;
import p075cOM6.a4;
import p075cOM6.b4;
import p075cOM6.d4;
import p075cOM6.f4;
import p075cOM6.g4;
import p075cOM6.x3;
import p075cOM6.z3;
import p087cOm8.com4;
import p087cOm8.com7;
import p087cOm8.com8;
import p087cOm8.com9;
import p098coM9.a;
import p108com9.k;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class MaterialDatePicker extends DialogFragment implements TraceFieldInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f9447a = "CONFIRM_BUTTON_TAG";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f9448b = "CANCEL_BUTTON_TAG";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Object f9449c = "TOGGLE_BUTTON_TAG";

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3481a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f3482a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Button f3483a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f3484a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com4<Object> f3485a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public MaterialCalendar<Object> f3486a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PickerFragment f3487a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.datepicker.aux f3488a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CheckableImageButton f3489a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Trace f3490a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f3491a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3493b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f3494b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3496b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f3497c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f3498c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3500c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9450d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9451e;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinkedHashSet<com7<Object>> f3492a = new LinkedHashSet<>();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final LinkedHashSet<View.OnClickListener> f3495b = new LinkedHashSet<>();

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final LinkedHashSet<DialogInterface.OnCancelListener> f3499c = new LinkedHashSet<>();

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final LinkedHashSet<DialogInterface.OnDismissListener> f3501d = new LinkedHashSet<>();

    public class aux implements View.OnClickListener {
        public aux() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Iterator it = MaterialDatePicker.this.f3492a.iterator();
            while (it.hasNext()) {
                ((com7) it.next()).a(MaterialDatePicker.this.x());
            }
            MaterialDatePicker.this.dismiss();
        }
    }

    public class com1 implements View.OnClickListener {
        public com1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            MaterialDatePicker.this.f3483a.setEnabled(MaterialDatePicker.this.t().l());
            MaterialDatePicker.this.f3489a.toggle();
            MaterialDatePicker materialDatePicker = MaterialDatePicker.this;
            materialDatePicker.F(materialDatePicker.f3489a);
            MaterialDatePicker.this.D();
        }
    }

    public class con implements View.OnClickListener {
        public con() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Iterator it = MaterialDatePicker.this.f3495b.iterator();
            while (it.hasNext()) {
                ((View.OnClickListener) it.next()).onClick(view);
            }
            MaterialDatePicker.this.dismiss();
        }
    }

    public class nul implements s {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9455a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f3502a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f9456b;

        public nul(int i2, View view, int i3) {
            this.f9455a = i2;
            this.f3502a = view;
            this.f9456b = i3;
        }

        @Override // p024Com2.s
        public t0 a(View view, t0 t0Var) {
            int i2 = t0Var.f(t0.com9.c()).f6415b;
            if (this.f9455a >= 0) {
                this.f3502a.getLayoutParams().height = this.f9455a + i2;
                View view2 = this.f3502a;
                view2.setLayoutParams(view2.getLayoutParams());
            }
            View view3 = this.f3502a;
            view3.setPadding(view3.getPaddingLeft(), this.f9456b + i2, this.f3502a.getPaddingRight(), this.f3502a.getPaddingBottom());
            return t0Var;
        }
    }

    public class prn extends com9<Object> {
        public prn() {
        }

        @Override // p087cOm8.com9
        public void a(Object obj) {
            MaterialDatePicker.this.E();
            MaterialDatePicker.this.f3483a.setEnabled(MaterialDatePicker.this.t().l());
        }
    }

    public static boolean A(Context context) {
        return C(context, R.attr.windowFullscreen);
    }

    public static boolean B(Context context) {
        return C(context, x3.C);
    }

    public static boolean C(Context context, int i2) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(a.d(context, x3.f9047v, MaterialCalendar.class.getCanonicalName()), new int[]{i2});
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(0, false);
        typedArrayObtainStyledAttributes.recycle();
        return z2;
    }

    public static Drawable r(Context context) {
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(new int[]{R.attr.state_checked}, AUX.aux.b(context, a4.f8869b));
        stateListDrawable.addState(new int[0], AUX.aux.b(context, a4.f8870c));
        return stateListDrawable;
    }

    public static int w(Context context) {
        Resources resources = context.getResources();
        int dimensionPixelOffset = resources.getDimensionPixelOffset(z3.H);
        int i2 = com8.p().f9182c;
        return (dimensionPixelOffset * 2) + (resources.getDimensionPixelSize(z3.J) * i2) + ((i2 - 1) * resources.getDimensionPixelOffset(z3.M));
    }

    public final void D() {
        int iY = y(requireContext());
        this.f3486a = MaterialCalendar.C(t(), iY, this.f3488a);
        this.f3487a = this.f3489a.isChecked() ? MaterialTextInputPicker.l(t(), iY, this.f3488a) : this.f3486a;
        E();
        lpt3 lpt3VarN = getChildFragmentManager().n();
        lpt3VarN.q(b4.I, this.f3487a);
        lpt3VarN.k();
        this.f3487a.j(new prn());
    }

    public final void E() {
        String strV = v();
        this.f3484a.setContentDescription(String.format(getString(f4.f8950u), strV));
        this.f3484a.setText(strV);
    }

    public final void F(CheckableImageButton checkableImageButton) {
        this.f3489a.setContentDescription(this.f3489a.isChecked() ? checkableImageButton.getContext().getString(f4.f8953x) : checkableImageButton.getContext().getString(f4.f8955z));
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        Iterator<DialogInterface.OnCancelListener> it = this.f3499c.iterator();
        while (it.hasNext()) {
            it.next().onCancel(dialogInterface);
        }
        super.onCancel(dialogInterface);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public final void onCreate(Bundle bundle) {
        TraceMachine.startTracing("MaterialDatePicker");
        try {
            TraceMachine.enterMethod(this.f3490a, "MaterialDatePicker#onCreate", null);
        } catch (NoSuchFieldError unused) {
            TraceMachine.enterMethod(null, "MaterialDatePicker#onCreate", null);
        }
        super.onCreate(bundle);
        if (bundle == null) {
            bundle = getArguments();
        }
        this.f3481a = bundle.getInt("OVERRIDE_THEME_RES_ID");
        this.f3485a = (com4) bundle.getParcelable("DATE_SELECTOR_KEY");
        this.f3488a = (com.google.android.material.datepicker.aux) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
        this.f3493b = bundle.getInt("TITLE_TEXT_RES_ID_KEY");
        this.f3491a = bundle.getCharSequence("TITLE_TEXT_KEY");
        this.f3497c = bundle.getInt("INPUT_MODE_KEY");
        this.f9450d = bundle.getInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY");
        this.f3494b = bundle.getCharSequence("POSITIVE_BUTTON_TEXT_KEY");
        this.f9451e = bundle.getInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY");
        this.f3498c = bundle.getCharSequence("NEGATIVE_BUTTON_TEXT_KEY");
        TraceMachine.exitMethod();
    }

    @Override // androidx.fragment.app.DialogFragment
    public final Dialog onCreateDialog(Bundle bundle) {
        Dialog dialog = new Dialog(requireContext(), y(requireContext()));
        Context context = dialog.getContext();
        this.f3496b = A(context);
        int iD = a.d(context, x3.f9038m, MaterialDatePicker.class.getCanonicalName());
        com3 com3Var = new com3(context, null, x3.f9047v, g4.f8977v);
        this.f3482a = com3Var;
        com3Var.N(context);
        this.f3482a.Y(ColorStateList.valueOf(iD));
        this.f3482a.X(y.v(dialog.getWindow().getDecorView()));
        return dialog;
    }

    @Override // androidx.fragment.app.Fragment
    public final View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        try {
            TraceMachine.enterMethod(this.f3490a, "MaterialDatePicker#onCreateView", null);
        } catch (NoSuchFieldError unused) {
            TraceMachine.enterMethod(null, "MaterialDatePicker#onCreateView", null);
        }
        View viewInflate = layoutInflater.inflate(this.f3496b ? d4.f8928v : d4.f8927u, viewGroup);
        Context context = viewInflate.getContext();
        if (this.f3496b) {
            viewInflate.findViewById(b4.I).setLayoutParams(new LinearLayout.LayoutParams(w(context), -2));
        } else {
            viewInflate.findViewById(b4.J).setLayoutParams(new LinearLayout.LayoutParams(w(context), -1));
        }
        TextView textView = (TextView) viewInflate.findViewById(b4.O);
        this.f3484a = textView;
        y.q0(textView, 1);
        this.f3489a = (CheckableImageButton) viewInflate.findViewById(b4.P);
        TextView textView2 = (TextView) viewInflate.findViewById(b4.Q);
        CharSequence charSequence = this.f3491a;
        if (charSequence != null) {
            textView2.setText(charSequence);
        } else {
            textView2.setText(this.f3493b);
        }
        z(context);
        this.f3483a = (Button) viewInflate.findViewById(b4.f8879c);
        if (t().l()) {
            this.f3483a.setEnabled(true);
        } else {
            this.f3483a.setEnabled(false);
        }
        this.f3483a.setTag(f9447a);
        CharSequence charSequence2 = this.f3494b;
        if (charSequence2 != null) {
            this.f3483a.setText(charSequence2);
        } else {
            int i2 = this.f9450d;
            if (i2 != 0) {
                this.f3483a.setText(i2);
            }
        }
        this.f3483a.setOnClickListener(new aux());
        Button button = (Button) viewInflate.findViewById(b4.f8875a);
        button.setTag(f9448b);
        CharSequence charSequence3 = this.f3498c;
        if (charSequence3 != null) {
            button.setText(charSequence3);
        } else {
            int i3 = this.f9451e;
            if (i3 != 0) {
                button.setText(i3);
            }
        }
        button.setOnClickListener(new con());
        TraceMachine.exitMethod();
        return viewInflate;
    }

    @Override // androidx.fragment.app.DialogFragment, android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        Iterator<DialogInterface.OnDismissListener> it = this.f3501d.iterator();
        while (it.hasNext()) {
            it.next().onDismiss(dialogInterface);
        }
        ViewGroup viewGroup = (ViewGroup) getView();
        if (viewGroup != null) {
            viewGroup.removeAllViews();
        }
        super.onDismiss(dialogInterface);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public final void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("OVERRIDE_THEME_RES_ID", this.f3481a);
        bundle.putParcelable("DATE_SELECTOR_KEY", this.f3485a);
        com.google.android.material.datepicker.aux.con conVar = new com.google.android.material.datepicker.aux.con(this.f3488a);
        if (this.f3486a.x() != null) {
            conVar.b(this.f3486a.x().f3219a);
        }
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", conVar.a());
        bundle.putInt("TITLE_TEXT_RES_ID_KEY", this.f3493b);
        bundle.putCharSequence("TITLE_TEXT_KEY", this.f3491a);
        bundle.putInt("POSITIVE_BUTTON_TEXT_RES_ID_KEY", this.f9450d);
        bundle.putCharSequence("POSITIVE_BUTTON_TEXT_KEY", this.f3494b);
        bundle.putInt("NEGATIVE_BUTTON_TEXT_RES_ID_KEY", this.f9451e);
        bundle.putCharSequence("NEGATIVE_BUTTON_TEXT_KEY", this.f3498c);
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onStart() {
        super.onStart();
        Window window = requireDialog().getWindow();
        if (this.f3496b) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawable(this.f3482a);
            s(window);
        } else {
            window.setLayout(-2, -2);
            int dimensionPixelOffset = getResources().getDimensionPixelOffset(z3.L);
            Rect rect = new Rect(dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset);
            window.setBackgroundDrawable(new InsetDrawable((Drawable) this.f3482a, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset, dimensionPixelOffset));
            window.getDecorView().setOnTouchListener(new p010COm8.con(requireDialog(), rect));
        }
        D();
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onStop() {
        this.f3487a.k();
        super.onStop();
    }

    public final void s(Window window) {
        if (this.f3500c) {
            return;
        }
        View viewFindViewById = requireView().findViewById(b4.f8885h);
        k.a(window, true, v.c(viewFindViewById), null);
        y.B0(viewFindViewById, new nul(viewFindViewById.getLayoutParams().height, viewFindViewById, viewFindViewById.getPaddingTop()));
        this.f3500c = true;
    }

    public final com4<Object> t() {
        if (this.f3485a == null) {
            this.f3485a = (com4) getArguments().getParcelable("DATE_SELECTOR_KEY");
        }
        return this.f3485a;
    }

    public String v() {
        return t().a(getContext());
    }

    public final Object x() {
        return t().b();
    }

    public final int y(Context context) {
        int i2 = this.f3481a;
        return i2 != 0 ? i2 : t().i(context);
    }

    public final void z(Context context) {
        this.f3489a.setTag(f9449c);
        this.f3489a.setImageDrawable(r(context));
        this.f3489a.setChecked(this.f3497c != 0);
        y.o0(this.f3489a, null);
        F(this.f3489a);
        this.f3489a.setOnClickListener(new com1());
    }
}
