package androidx.lifecycle;

import android.annotation.SuppressLint;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import p079cON.y0;

/* JADX INFO: loaded from: classes.dex */
public class com1 extends nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8392a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CON.aux<COM3.com6, aux> f2607a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul.EnumC0039nul f2608a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final WeakReference<COM3.com7> f2609a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<nul.EnumC0039nul> f2610a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2611a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f8393b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f8394c;

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public nul.EnumC0039nul f8395a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public prn f2612a;

        public aux(COM3.com6 com6Var, nul.EnumC0039nul enumC0039nul) {
            this.f2612a = com2.f(com6Var);
            this.f8395a = enumC0039nul;
        }

        public void a(COM3.com7 com7Var, nul.con conVar) {
            nul.EnumC0039nul enumC0039nulC = conVar.c();
            this.f8395a = com1.k(this.f8395a, enumC0039nulC);
            this.f2612a.f(com7Var, conVar);
            this.f8395a = enumC0039nulC;
        }
    }

    public com1(COM3.com7 com7Var) {
        this(com7Var, true);
    }

    public static nul.EnumC0039nul k(nul.EnumC0039nul enumC0039nul, nul.EnumC0039nul enumC0039nul2) {
        return (enumC0039nul2 == null || enumC0039nul2.compareTo(enumC0039nul) >= 0) ? enumC0039nul : enumC0039nul2;
    }

    @Override // androidx.lifecycle.nul
    public void a(COM3.com6 com6Var) {
        COM3.com7 com7Var;
        f("addObserver");
        nul.EnumC0039nul enumC0039nul = this.f2608a;
        nul.EnumC0039nul enumC0039nul2 = nul.EnumC0039nul.DESTROYED;
        if (enumC0039nul != enumC0039nul2) {
            enumC0039nul2 = nul.EnumC0039nul.INITIALIZED;
        }
        aux auxVar = new aux(com6Var, enumC0039nul2);
        if (this.f2607a.f(com6Var, auxVar) == null && (com7Var = this.f2609a.get()) != null) {
            boolean z2 = this.f8392a != 0 || this.f2611a;
            nul.EnumC0039nul enumC0039nulE = e(com6Var);
            this.f8392a++;
            while (auxVar.f8395a.compareTo(enumC0039nulE) < 0 && this.f2607a.contains(com6Var)) {
                n(auxVar.f8395a);
                nul.con conVarD = nul.con.d(auxVar.f8395a);
                if (conVarD == null) {
                    throw new IllegalStateException("no event up from " + auxVar.f8395a);
                }
                auxVar.a(com7Var, conVarD);
                m();
                enumC0039nulE = e(com6Var);
            }
            if (!z2) {
                p();
            }
            this.f8392a--;
        }
    }

    @Override // androidx.lifecycle.nul
    public nul.EnumC0039nul b() {
        return this.f2608a;
    }

    @Override // androidx.lifecycle.nul
    public void c(COM3.com6 com6Var) {
        f("removeObserver");
        this.f2607a.g(com6Var);
    }

    public final void d(COM3.com7 com7Var) {
        Iterator<Map.Entry<COM3.com6, aux>> itDescendingIterator = this.f2607a.descendingIterator();
        while (itDescendingIterator.hasNext() && !this.f8393b) {
            Map.Entry<COM3.com6, aux> next = itDescendingIterator.next();
            aux value = next.getValue();
            while (value.f8395a.compareTo(this.f2608a) > 0 && !this.f8393b && this.f2607a.contains(next.getKey())) {
                nul.con conVarA = nul.con.a(value.f8395a);
                if (conVarA == null) {
                    throw new IllegalStateException("no event down from " + value.f8395a);
                }
                n(conVarA.c());
                value.a(com7Var, conVarA);
                m();
            }
        }
    }

    public final nul.EnumC0039nul e(COM3.com6 com6Var) {
        Map.Entry<COM3.com6, aux> entryH = this.f2607a.h(com6Var);
        nul.EnumC0039nul enumC0039nul = null;
        nul.EnumC0039nul enumC0039nul2 = entryH != null ? entryH.getValue().f8395a : null;
        if (!this.f2610a.isEmpty()) {
            ArrayList<nul.EnumC0039nul> arrayList = this.f2610a;
            enumC0039nul = arrayList.get(arrayList.size() - 1);
        }
        return k(k(this.f2608a, enumC0039nul2), enumC0039nul);
    }

    @SuppressLint({"RestrictedApi"})
    public final void f(String str) {
        if (!this.f8394c || y0.d().b()) {
            return;
        }
        throw new IllegalStateException("Method " + str + " must be called on the main thread");
    }

    public final void g(COM3.com7 com7Var) {
        CON.con<COM3.com6, aux>.prn prnVarC = this.f2607a.c();
        while (prnVarC.hasNext() && !this.f8393b) {
            Map.Entry next = prnVarC.next();
            aux auxVar = (aux) next.getValue();
            while (auxVar.f8395a.compareTo(this.f2608a) < 0 && !this.f8393b && this.f2607a.contains((COM3.com6) next.getKey())) {
                n(auxVar.f8395a);
                nul.con conVarD = nul.con.d(auxVar.f8395a);
                if (conVarD == null) {
                    throw new IllegalStateException("no event up from " + auxVar.f8395a);
                }
                auxVar.a(com7Var, conVarD);
                m();
            }
        }
    }

    public void h(nul.con conVar) {
        f("handleLifecycleEvent");
        l(conVar.c());
    }

    public final boolean i() {
        if (this.f2607a.size() == 0) {
            return true;
        }
        nul.EnumC0039nul enumC0039nul = this.f2607a.a().getValue().f8395a;
        nul.EnumC0039nul enumC0039nul2 = this.f2607a.d().getValue().f8395a;
        return enumC0039nul == enumC0039nul2 && this.f2608a == enumC0039nul2;
    }

    @Deprecated
    public void j(nul.EnumC0039nul enumC0039nul) {
        f("markState");
        o(enumC0039nul);
    }

    public final void l(nul.EnumC0039nul enumC0039nul) {
        if (this.f2608a == enumC0039nul) {
            return;
        }
        this.f2608a = enumC0039nul;
        if (this.f2611a || this.f8392a != 0) {
            this.f8393b = true;
            return;
        }
        this.f2611a = true;
        p();
        this.f2611a = false;
    }

    public final void m() {
        ArrayList<nul.EnumC0039nul> arrayList = this.f2610a;
        arrayList.remove(arrayList.size() - 1);
    }

    public final void n(nul.EnumC0039nul enumC0039nul) {
        this.f2610a.add(enumC0039nul);
    }

    public void o(nul.EnumC0039nul enumC0039nul) {
        f("setCurrentState");
        l(enumC0039nul);
    }

    public final void p() {
        COM3.com7 com7Var = this.f2609a.get();
        if (com7Var == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is alreadygarbage collected. It is too late to change lifecycle state.");
        }
        while (!i()) {
            this.f8393b = false;
            if (this.f2608a.compareTo(this.f2607a.a().getValue().f8395a) < 0) {
                d(com7Var);
            }
            Map.Entry<COM3.com6, aux> entryD = this.f2607a.d();
            if (!this.f8393b && entryD != null && this.f2608a.compareTo(entryD.getValue().f8395a) > 0) {
                g(com7Var);
            }
        }
        this.f8393b = false;
    }

    public com1(COM3.com7 com7Var, boolean z2) {
        this.f2607a = new CON.aux<>();
        this.f8392a = 0;
        this.f2611a = false;
        this.f8393b = false;
        this.f2610a = new ArrayList<>();
        this.f2609a = new WeakReference<>(com7Var);
        this.f2608a = nul.EnumC0039nul.INITIALIZED;
        this.f8394c = z2;
    }
}
