package COM1;

/* JADX INFO: loaded from: classes.dex */
public interface prn {
    boolean isRtl(CharSequence charSequence, int i2, int i3);
}
