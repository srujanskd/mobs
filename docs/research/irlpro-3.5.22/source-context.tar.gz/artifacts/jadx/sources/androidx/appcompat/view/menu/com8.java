package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class com8 extends com1 implements SubMenu {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public com1 f7823a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public com3 f7824b;

    public com8(Context context, com1 com1Var, com3 com3Var) {
        super(context);
        this.f7823a = com1Var;
        this.f7824b = com3Var;
    }

    @Override // androidx.appcompat.view.menu.com1
    public com1 D() {
        return this.f7823a.D();
    }

    @Override // androidx.appcompat.view.menu.com1
    public boolean F() {
        return this.f7823a.F();
    }

    @Override // androidx.appcompat.view.menu.com1
    public boolean G() {
        return this.f7823a.G();
    }

    @Override // androidx.appcompat.view.menu.com1
    public boolean H() {
        return this.f7823a.H();
    }

    @Override // androidx.appcompat.view.menu.com1
    public void R(com1.aux auxVar) {
        this.f7823a.R(auxVar);
    }

    public Menu e0() {
        return this.f7823a;
    }

    @Override // androidx.appcompat.view.menu.com1
    public boolean f(com3 com3Var) {
        return this.f7823a.f(com3Var);
    }

    @Override // android.view.SubMenu
    public MenuItem getItem() {
        return this.f7824b;
    }

    @Override // androidx.appcompat.view.menu.com1
    public boolean h(com1 com1Var, MenuItem menuItem) {
        return super.h(com1Var, menuItem) || this.f7823a.h(com1Var, menuItem);
    }

    @Override // androidx.appcompat.view.menu.com1
    public boolean k(com3 com3Var) {
        return this.f7823a.k(com3Var);
    }

    @Override // androidx.appcompat.view.menu.com1, android.view.Menu
    public void setGroupDividerEnabled(boolean z2) {
        this.f7823a.setGroupDividerEnabled(z2);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(Drawable drawable) {
        return (SubMenu) super.V(drawable);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(CharSequence charSequence) {
        return (SubMenu) super.Y(charSequence);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderView(View view) {
        return (SubMenu) super.Z(view);
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(Drawable drawable) {
        this.f7824b.setIcon(drawable);
        return this;
    }

    @Override // androidx.appcompat.view.menu.com1, android.view.Menu
    public void setQwertyMode(boolean z2) {
        this.f7823a.setQwertyMode(z2);
    }

    @Override // androidx.appcompat.view.menu.com1
    public String t() {
        com3 com3Var = this.f7824b;
        int itemId = com3Var != null ? com3Var.getItemId() : 0;
        if (itemId == 0) {
            return null;
        }
        return super.t() + ":" + itemId;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(int i2) {
        return (SubMenu) super.U(i2);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(int i2) {
        return (SubMenu) super.X(i2);
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(int i2) {
        this.f7824b.setIcon(i2);
        return this;
    }
}
