package LPT1;

/* JADX INFO: loaded from: classes.dex */
public interface aux {
    boolean a(con conVar);

    boolean shouldSkipClass(Class<?> cls);
}
