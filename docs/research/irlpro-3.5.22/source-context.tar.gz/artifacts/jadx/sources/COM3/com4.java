package COM3;

import java.util.concurrent.CancellationException;

/* JADX INFO: loaded from: classes.dex */
public final class com4 extends CancellationException {
}
