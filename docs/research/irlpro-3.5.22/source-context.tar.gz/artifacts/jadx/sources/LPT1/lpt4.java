package LPT1;

import java.lang.reflect.Type;

/* JADX INFO: loaded from: classes.dex */
public interface lpt4<T> {
    com6 a(T t2, Type type, lpt3 lpt3Var);
}
