package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import p146nUL.l;
import p146nUL.p;
import p151pRn.h0;

/* JADX INFO: loaded from: classes.dex */
public class Barrier extends con {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l f8016a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8017b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8018c;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    public boolean getAllowsGoneWidget() {
        return this.f8016a.r1();
    }

    public int getMargin() {
        return this.f8016a.t1();
    }

    public int getType() {
        return this.f8017b;
    }

    @Override // androidx.constraintlayout.widget.con
    public void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        this.f8016a = new l();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, h0.f5224u);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                if (index == h0.b1) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == h0.a1) {
                    this.f8016a.w1(typedArrayObtainStyledAttributes.getBoolean(index, true));
                } else if (index == h0.c1) {
                    this.f8016a.y1(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        ((con) this).f2211a = this.f8016a;
        s();
    }

    @Override // androidx.constraintlayout.widget.con
    public void n(p pVar, boolean z2) {
        t(pVar, this.f8017b, z2);
    }

    public void setAllowsGoneWidget(boolean z2) {
        this.f8016a.w1(z2);
    }

    public void setDpMargin(int i2) {
        this.f8016a.y1((int) ((i2 * getResources().getDisplayMetrics().density) + 0.5f));
    }

    public void setMargin(int i2) {
        this.f8016a.y1(i2);
    }

    public void setType(int i2) {
        this.f8017b = i2;
    }

    public final void t(p pVar, int i2, boolean z2) {
        this.f8018c = i2;
        if (z2) {
            int i3 = this.f8017b;
            if (i3 == 5) {
                this.f8018c = 1;
            } else if (i3 == 6) {
                this.f8018c = 0;
            }
        } else {
            int i4 = this.f8017b;
            if (i4 == 5) {
                this.f8018c = 0;
            } else if (i4 == 6) {
                this.f8018c = 1;
            }
        }
        if (pVar instanceof l) {
            ((l) pVar).x1(this.f8018c);
        }
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }
}
