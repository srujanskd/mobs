package COM9;

/* JADX INFO: loaded from: classes.dex */
public class com6 extends prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f5739a = -1.0f;

    @Override // COM9.prn
    public void a(com9 com9Var, float f2, float f3, float f4) {
        com9Var.o(0.0f, f4 * f3, 180.0f, 180.0f - f2);
        float f5 = f4 * 2.0f * f3;
        com9Var.a(0.0f, 0.0f, f5, f5, 180.0f, f2);
    }
}
