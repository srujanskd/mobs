package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import p016CoM4.com8;
import p016CoM4.lpt5;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class ListPreference extends DialogPreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f8431a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence[] f2635a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f8432b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2636b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence[] f2637b;

    public static final class con implements Preference.com3<ListPreference> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static con f8434a;

        public static con b() {
            if (f8434a == null) {
                f8434a = new con();
            }
            return f8434a;
        }

        @Override // androidx.preference.Preference.com3
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public CharSequence a(ListPreference listPreference) {
            return TextUtils.isEmpty(listPreference.c()) ? listPreference.getContext().getString(lpt5.f6199c) : listPreference.c();
        }
    }

    public ListPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f532e, i2, i3);
        this.f2635a = l0.h(typedArrayObtainStyledAttributes, lpt7.f6240w, lpt7.f6238u);
        this.f2637b = l0.h(typedArrayObtainStyledAttributes, lpt7.f6241x, lpt7.f6239v);
        int i4 = lpt7.f6242y;
        if (l0.b(typedArrayObtainStyledAttributes, i4, i4, false)) {
            setSummaryProvider(con.b());
        }
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, lpt7.f534g, i2, i3);
        this.f8432b = l0.f(typedArrayObtainStyledAttributes2, lpt7.f6224k0, lpt7.K);
        typedArrayObtainStyledAttributes2.recycle();
    }

    public int a(String str) {
        CharSequence[] charSequenceArr;
        if (str == null || (charSequenceArr = this.f2637b) == null) {
            return -1;
        }
        for (int length = charSequenceArr.length - 1; length >= 0; length--) {
            if (TextUtils.equals(this.f2637b[length].toString(), str)) {
                return length;
            }
        }
        return -1;
    }

    public CharSequence[] b() {
        return this.f2635a;
    }

    public CharSequence c() {
        CharSequence[] charSequenceArr;
        int iF = f();
        if (iF < 0 || (charSequenceArr = this.f2635a) == null) {
            return null;
        }
        return charSequenceArr[iF];
    }

    public CharSequence[] d() {
        return this.f2637b;
    }

    public String e() {
        return this.f8431a;
    }

    public final int f() {
        return a(this.f8431a);
    }

    public void g(int i2) {
        h(getContext().getResources().getTextArray(i2));
    }

    @Override // androidx.preference.Preference
    public CharSequence getSummary() {
        if (getSummaryProvider() != null) {
            return getSummaryProvider().a(this);
        }
        CharSequence charSequenceC = c();
        CharSequence summary = super.getSummary();
        String str = this.f8432b;
        if (str == null) {
            return summary;
        }
        Object[] objArr = new Object[1];
        if (charSequenceC == null) {
            charSequenceC = "";
        }
        objArr[0] = charSequenceC;
        String str2 = String.format(str, objArr);
        if (TextUtils.equals(str2, summary)) {
            return summary;
        }
        Log.w("ListPreference", "Setting a summary with a String formatting marker is no longer supported. You should use a SummaryProvider instead.");
        return str2;
    }

    public void h(CharSequence[] charSequenceArr) {
        this.f2635a = charSequenceArr;
    }

    public void i(int i2) {
        j(getContext().getResources().getTextArray(i2));
    }

    public void j(CharSequence[] charSequenceArr) {
        this.f2637b = charSequenceArr;
    }

    public void l(String str) {
        boolean z2 = !TextUtils.equals(this.f8431a, str);
        if (z2 || !this.f2636b) {
            this.f8431a = str;
            this.f2636b = true;
            persistString(str);
            if (z2) {
                notifyChanged();
            }
        }
    }

    public void m(int i2) {
        CharSequence[] charSequenceArr = this.f2637b;
        if (charSequenceArr != null) {
            l(charSequenceArr[i2].toString());
        }
    }

    @Override // androidx.preference.Preference
    public Object onGetDefaultValue(TypedArray typedArray, int i2) {
        return typedArray.getString(i2);
    }

    @Override // androidx.preference.Preference
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(aux.class)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        aux auxVar = (aux) parcelable;
        super.onRestoreInstanceState(auxVar.getSuperState());
        l(auxVar.f8433a);
    }

    @Override // androidx.preference.Preference
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState = super.onSaveInstanceState();
        if (isPersistent()) {
            return parcelableOnSaveInstanceState;
        }
        aux auxVar = new aux(parcelableOnSaveInstanceState);
        auxVar.f8433a = e();
        return auxVar;
    }

    @Override // androidx.preference.Preference
    public void onSetInitialValue(Object obj) {
        l(getPersistedString((String) obj));
    }

    @Override // androidx.preference.Preference
    public void setSummary(CharSequence charSequence) {
        super.setSummary(charSequence);
        if (charSequence == null) {
            this.f8432b = null;
        } else {
            this.f8432b = charSequence.toString();
        }
    }

    public static class aux extends Preference.con {
        public static final Parcelable.Creator<aux> CREATOR = new C0040aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public String f8433a;

        /* JADX INFO: renamed from: androidx.preference.ListPreference$aux$aux, reason: collision with other inner class name */
        public class C0040aux implements Parcelable.Creator<aux> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public aux createFromParcel(Parcel parcel) {
                return new aux(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public aux[] newArray(int i2) {
                return new aux[i2];
            }
        }

        public aux(Parcel parcel) {
            super(parcel);
            this.f8433a = parcel.readString();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeString(this.f8433a);
        }

        public aux(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public ListPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public ListPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6168b, R.attr.dialogPreferenceStyle));
    }

    public ListPreference(Context context) {
        this(context, null);
    }
}
