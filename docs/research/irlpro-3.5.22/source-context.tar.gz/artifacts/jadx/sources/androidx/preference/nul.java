package androidx.preference;

import android.content.Context;
import android.content.SharedPreferences;
import p016CoM4.com1;
import p016CoM4.com5;

/* JADX INFO: loaded from: classes.dex */
public class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8499a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Context f2673a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public SharedPreferences.Editor f2674a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public SharedPreferences f2675a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PreferenceScreen f2676a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public aux f2677a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f2678a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public InterfaceC0044nul f2679a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2680a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2681a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f2672a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8500b = 0;

    public interface aux {
        void h(Preference preference);
    }

    public interface con {
        void e(PreferenceScreen preferenceScreen);
    }

    /* JADX INFO: renamed from: androidx.preference.nul$nul, reason: collision with other inner class name */
    public interface InterfaceC0044nul {
        boolean i(Preference preference);
    }

    public static abstract class prn {
    }

    public nul(Context context) {
        this.f2673a = context;
        t(e(context));
    }

    public static SharedPreferences c(Context context) {
        return context.getSharedPreferences(e(context), d());
    }

    public static int d() {
        return 0;
    }

    public static String e(Context context) {
        return context.getPackageName() + "_preferences";
    }

    public PreferenceScreen a(Context context) {
        PreferenceScreen preferenceScreen = new PreferenceScreen(context, null);
        preferenceScreen.onAttachedToHierarchy(this);
        return preferenceScreen;
    }

    public <T extends Preference> T b(CharSequence charSequence) {
        PreferenceScreen preferenceScreen = this.f2676a;
        if (preferenceScreen == null) {
            return null;
        }
        return (T) preferenceScreen.c(charSequence);
    }

    public SharedPreferences.Editor f() {
        if (!this.f2681a) {
            return m().edit();
        }
        if (this.f2674a == null) {
            this.f2674a = m().edit();
        }
        return this.f2674a;
    }

    public long g() {
        long j2;
        synchronized (this) {
            j2 = this.f2672a;
            this.f2672a = 1 + j2;
        }
        return j2;
    }

    public con h() {
        return this.f2678a;
    }

    public InterfaceC0044nul i() {
        return this.f2679a;
    }

    public prn j() {
        return null;
    }

    public com1 k() {
        return null;
    }

    public PreferenceScreen l() {
        return this.f2676a;
    }

    public SharedPreferences m() {
        k();
        if (this.f2675a == null) {
            this.f2675a = (this.f8500b != 1 ? this.f2673a : PRN.aux.b(this.f2673a)).getSharedPreferences(this.f2680a, this.f8499a);
        }
        return this.f2675a;
    }

    public PreferenceScreen n(Context context, int i2, PreferenceScreen preferenceScreen) {
        o(true);
        PreferenceScreen preferenceScreen2 = (PreferenceScreen) new com5(context, this).d(i2, preferenceScreen);
        preferenceScreen2.onAttachedToHierarchy(this);
        o(false);
        return preferenceScreen2;
    }

    public final void o(boolean z2) {
        SharedPreferences.Editor editor;
        if (!z2 && (editor = this.f2674a) != null) {
            editor.apply();
        }
        this.f2681a = z2;
    }

    public void p(aux auxVar) {
        this.f2677a = auxVar;
    }

    public void q(con conVar) {
        this.f2678a = conVar;
    }

    public void r(InterfaceC0044nul interfaceC0044nul) {
        this.f2679a = interfaceC0044nul;
    }

    public boolean s(PreferenceScreen preferenceScreen) {
        PreferenceScreen preferenceScreen2 = this.f2676a;
        if (preferenceScreen == preferenceScreen2) {
            return false;
        }
        if (preferenceScreen2 != null) {
            preferenceScreen2.onDetached();
        }
        this.f2676a = preferenceScreen;
        return true;
    }

    public void t(String str) {
        this.f2680a = str;
        this.f2675a = null;
    }

    public boolean u() {
        return !this.f2681a;
    }

    public void v(Preference preference) {
        aux auxVar = this.f2677a;
        if (auxVar != null) {
            auxVar.h(preference);
        }
    }
}
