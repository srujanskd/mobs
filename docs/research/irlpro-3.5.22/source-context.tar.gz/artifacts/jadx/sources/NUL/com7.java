package NUL;

import java.util.Iterator;
import p146nUL.l;
import p146nUL.p;
import p146nUL.t;

/* JADX INFO: loaded from: classes.dex */
public class com7 extends lpt3 {
    public com7(p pVar) {
        super(pVar);
    }

    @Override // NUL.lpt3, NUL.prn
    public void a(prn prnVar) {
        l lVar = (l) ((lpt3) this).f1385a;
        int iS1 = lVar.s1();
        Iterator<com2> it = ((lpt3) this).f1380a.f1360b.iterator();
        int i2 = 0;
        int i3 = -1;
        while (it.hasNext()) {
            int i4 = it.next().f7365b;
            if (i3 == -1 || i4 < i3) {
                i3 = i4;
            }
            if (i2 < i4) {
                i2 = i4;
            }
        }
        if (iS1 == 0 || iS1 == 2) {
            ((lpt3) this).f1380a.d(i3 + lVar.t1());
        } else {
            ((lpt3) this).f1380a.d(i2 + lVar.t1());
        }
    }

    @Override // NUL.lpt3
    public void d() {
        p pVar = ((lpt3) this).f1385a;
        if (pVar instanceof l) {
            ((lpt3) this).f1380a.f1359a = true;
            l lVar = (l) pVar;
            int iS1 = lVar.s1();
            boolean zR1 = lVar.r1();
            int i2 = 0;
            if (iS1 == 0) {
                ((lpt3) this).f1380a.f1354a = com2.aux.LEFT;
                while (i2 < lVar.G) {
                    p pVar2 = ((t) lVar).f11542c[i2];
                    if (zR1 || pVar2.T() != 8) {
                        com2 com2Var = ((lpt3) pVar2.f4937a).f1380a;
                        com2Var.f1358a.add(((lpt3) this).f1380a);
                        ((lpt3) this).f1380a.f1360b.add(com2Var);
                    }
                    i2++;
                }
                q(((lpt3) ((lpt3) this).f1385a.f4937a).f1380a);
                q(((lpt3) ((lpt3) this).f1385a.f4937a).f1387b);
                return;
            }
            if (iS1 == 1) {
                ((lpt3) this).f1380a.f1354a = com2.aux.RIGHT;
                while (i2 < lVar.G) {
                    p pVar3 = ((t) lVar).f11542c[i2];
                    if (zR1 || pVar3.T() != 8) {
                        com2 com2Var2 = ((lpt3) pVar3.f4937a).f1387b;
                        com2Var2.f1358a.add(((lpt3) this).f1380a);
                        ((lpt3) this).f1380a.f1360b.add(com2Var2);
                    }
                    i2++;
                }
                q(((lpt3) ((lpt3) this).f1385a.f4937a).f1380a);
                q(((lpt3) ((lpt3) this).f1385a.f4937a).f1387b);
                return;
            }
            if (iS1 == 2) {
                ((lpt3) this).f1380a.f1354a = com2.aux.TOP;
                while (i2 < lVar.G) {
                    p pVar4 = ((t) lVar).f11542c[i2];
                    if (zR1 || pVar4.T() != 8) {
                        com2 com2Var3 = ((lpt3) pVar4.f4938a).f1380a;
                        com2Var3.f1358a.add(((lpt3) this).f1380a);
                        ((lpt3) this).f1380a.f1360b.add(com2Var3);
                    }
                    i2++;
                }
                q(((lpt3) ((lpt3) this).f1385a.f4938a).f1380a);
                q(((lpt3) ((lpt3) this).f1385a.f4938a).f1387b);
                return;
            }
            if (iS1 != 3) {
                return;
            }
            ((lpt3) this).f1380a.f1354a = com2.aux.BOTTOM;
            while (i2 < lVar.G) {
                p pVar5 = ((t) lVar).f11542c[i2];
                if (zR1 || pVar5.T() != 8) {
                    com2 com2Var4 = ((lpt3) pVar5.f4938a).f1387b;
                    com2Var4.f1358a.add(((lpt3) this).f1380a);
                    ((lpt3) this).f1380a.f1360b.add(com2Var4);
                }
                i2++;
            }
            q(((lpt3) ((lpt3) this).f1385a.f4938a).f1380a);
            q(((lpt3) ((lpt3) this).f1385a.f4938a).f1387b);
        }
    }

    @Override // NUL.lpt3
    public void e() {
        p pVar = ((lpt3) this).f1385a;
        if (pVar instanceof l) {
            int iS1 = ((l) pVar).s1();
            if (iS1 == 0 || iS1 == 1) {
                ((lpt3) this).f1385a.j1(((lpt3) this).f1380a.f7365b);
            } else {
                ((lpt3) this).f1385a.k1(((lpt3) this).f1380a.f7365b);
            }
        }
    }

    @Override // NUL.lpt3
    public void f() {
        ((lpt3) this).f1382a = null;
        ((lpt3) this).f1380a.c();
    }

    @Override // NUL.lpt3
    public boolean m() {
        return false;
    }

    public final void q(com2 com2Var) {
        ((lpt3) this).f1380a.f1358a.add(com2Var);
        com2Var.f1360b.add(((lpt3) this).f1380a);
    }
}
