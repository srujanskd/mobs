package LPT3;

/* JADX INFO: loaded from: classes.dex */
public final class aux extends com9 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final char[] f6620a = "0123456789-$:/.+ABCD".toCharArray();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f855a = {3, 6, 9, 96, 18, 66, 33, 36, 48, 72, 12, 24, 69, 81, 84, 21, 26, 41, 11, 14};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final char[] f6621b = {'A', 'B', 'C', 'D'};

    public static boolean a(char[] cArr, char c2) {
        if (cArr != null) {
            for (char c3 : cArr) {
                if (c3 == c2) {
                    return true;
                }
            }
        }
        return false;
    }
}
