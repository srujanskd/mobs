package LPT1;

import java.io.IOException;
import java.io.StringWriter;

/* JADX INFO: loaded from: classes.dex */
public abstract class com6 {
    public com3 a() {
        if (d()) {
            return (com3) this;
        }
        throw new IllegalStateException("Not a JSON Array: " + this);
    }

    public com9 b() {
        if (f()) {
            return (com9) this;
        }
        throw new IllegalStateException("Not a JSON Object: " + this);
    }

    public lpt2 c() {
        if (g()) {
            return (lpt2) this;
        }
        throw new IllegalStateException("Not a JSON Primitive: " + this);
    }

    public boolean d() {
        return this instanceof com3;
    }

    public boolean e() {
        return this instanceof com8;
    }

    public boolean f() {
        return this instanceof com9;
    }

    public boolean g() {
        return this instanceof lpt2;
    }

    public String toString() {
        try {
            StringWriter stringWriter = new StringWriter();
            LPT2.nul nulVar = new LPT2.nul(stringWriter);
            nulVar.W(true);
            p052Lpt2.lpt8.b(this, nulVar);
            return stringWriter.toString();
        } catch (IOException e2) {
            throw new AssertionError(e2);
        }
    }
}
