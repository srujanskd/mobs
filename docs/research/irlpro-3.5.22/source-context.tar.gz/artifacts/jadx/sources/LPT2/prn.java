package LPT2;

import java.io.IOException;

/* JADX INFO: loaded from: classes.dex */
public final class prn extends IOException {
    public prn(String str) {
        super(str);
    }
}
