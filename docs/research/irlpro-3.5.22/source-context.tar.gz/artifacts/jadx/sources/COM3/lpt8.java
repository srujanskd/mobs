package COM3;

import android.view.View;
import p103com4.i;

/* JADX INFO: loaded from: classes.dex */
public class lpt8 {
    public static void a(View view, com7 com7Var) {
        view.setTag(i.f10470a, com7Var);
    }
}
