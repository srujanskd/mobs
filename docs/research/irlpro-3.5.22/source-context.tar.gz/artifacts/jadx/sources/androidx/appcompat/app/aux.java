package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import p001AuX.com3;
import p066aUX.c;

/* JADX INFO: loaded from: classes.dex */
public class aux extends c implements DialogInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AlertController f7774a;

    /* JADX INFO: renamed from: androidx.appcompat.app.aux$aux, reason: collision with other inner class name */
    public static class C0023aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f7775a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final AlertController.con f1802a;

        public C0023aux(Context context) {
            this(context, aux.i(context, 0));
        }

        public aux a() {
            aux auxVar = new aux(this.f1802a.f1762a, this.f7775a);
            this.f1802a.a(auxVar.f7774a);
            auxVar.setCancelable(this.f1802a.f1776a);
            if (this.f1802a.f1776a) {
                auxVar.setCanceledOnTouchOutside(true);
            }
            auxVar.setOnCancelListener(this.f1802a.f1763a);
            auxVar.setOnDismissListener(this.f1802a.f1765a);
            DialogInterface.OnKeyListener onKeyListener = this.f1802a.f1766a;
            if (onKeyListener != null) {
                auxVar.setOnKeyListener(onKeyListener);
            }
            return auxVar;
        }

        public Context b() {
            return this.f1802a.f1762a;
        }

        public C0023aux c(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1773a = listAdapter;
            conVar.f1789d = onClickListener;
            return this;
        }

        public C0023aux d(boolean z2) {
            this.f1802a.f1776a = z2;
            return this;
        }

        public C0023aux e(View view) {
            this.f1802a.f1771a = view;
            return this;
        }

        public C0023aux f(Drawable drawable) {
            this.f1802a.f1769a = drawable;
            return this;
        }

        public C0023aux g(int i2) {
            AlertController.con conVar = this.f1802a;
            conVar.f1782b = conVar.f1762a.getText(i2);
            return this;
        }

        public C0023aux h(CharSequence charSequence) {
            this.f1802a.f1782b = charSequence;
            return this;
        }

        public C0023aux i(CharSequence[] charSequenceArr, boolean[] zArr, DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1777a = charSequenceArr;
            conVar.f1767a = onMultiChoiceClickListener;
            conVar.f1778a = zArr;
            conVar.f1788c = true;
            return this;
        }

        public C0023aux j(int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1791d = conVar.f1762a.getText(i2);
            this.f1802a.f1779b = onClickListener;
            return this;
        }

        public C0023aux k(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1791d = charSequence;
            conVar.f1779b = onClickListener;
            return this;
        }

        public C0023aux l(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1793e = charSequence;
            conVar.f1785c = onClickListener;
            return this;
        }

        public C0023aux m(DialogInterface.OnKeyListener onKeyListener) {
            this.f1802a.f1766a = onKeyListener;
            return this;
        }

        public C0023aux n(int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1787c = conVar.f1762a.getText(i2);
            this.f1802a.f1764a = onClickListener;
            return this;
        }

        public C0023aux o(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1787c = charSequence;
            conVar.f1764a = onClickListener;
            return this;
        }

        public C0023aux p(ListAdapter listAdapter, int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1773a = listAdapter;
            conVar.f1789d = onClickListener;
            conVar.f7767h = i2;
            conVar.f1792d = true;
            return this;
        }

        public C0023aux q(CharSequence[] charSequenceArr, int i2, DialogInterface.OnClickListener onClickListener) {
            AlertController.con conVar = this.f1802a;
            conVar.f1777a = charSequenceArr;
            conVar.f1789d = onClickListener;
            conVar.f7767h = i2;
            conVar.f1792d = true;
            return this;
        }

        public C0023aux r(int i2) {
            AlertController.con conVar = this.f1802a;
            conVar.f1774a = conVar.f1762a.getText(i2);
            return this;
        }

        public C0023aux s(CharSequence charSequence) {
            this.f1802a.f1774a = charSequence;
            return this;
        }

        public C0023aux t(View view) {
            AlertController.con conVar = this.f1802a;
            conVar.f1781b = view;
            conVar.f7762c = 0;
            conVar.f1784b = false;
            return this;
        }

        public aux u() {
            aux auxVarA = a();
            auxVarA.show();
            return auxVarA;
        }

        public C0023aux(Context context, int i2) {
            this.f1802a = new AlertController.con(new ContextThemeWrapper(context, aux.i(context, i2)));
            this.f7775a = i2;
        }
    }

    public aux(Context context, int i2) {
        super(context, i(context, i2));
        this.f7774a = new AlertController(getContext(), this, getWindow());
    }

    public static int i(Context context, int i2) {
        if (((i2 >>> 24) & 255) >= 1) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(com3.f5507o, typedValue, true);
        return typedValue.resourceId;
    }

    public Button f(int i2) {
        return this.f7774a.c(i2);
    }

    public ListView g() {
        return this.f7774a.e();
    }

    @Override // p066aUX.c, android.app.Dialog
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f7774a.f();
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (this.f7774a.g(i2, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i2, keyEvent);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        if (this.f7774a.h(i2, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i2, keyEvent);
    }

    @Override // p066aUX.c, android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f7774a.q(charSequence);
    }
}
