package COM9;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import java.util.BitSet;
import p075cOM6.x3;
import p078cOM9.lpt6;
import p101com2.p2;

/* JADX INFO: loaded from: classes.dex */
public class com3 extends Drawable implements lpt1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f5727a = "com3";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Paint f5728c;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f71a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f72a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com7 f73a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com8.con f74a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com8 f75a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Matrix f76a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Paint f77a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Path f78a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuffColorFilter f79a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f80a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Region f81a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt6 f82a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final BitSet f83a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com9.com3[] f84a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Paint f5729b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Path f85b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public PorterDuffColorFilter f86b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final RectF f87b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Region f88b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f89b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final com9.com3[] f90b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final RectF f91c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f92c;

    public class aux implements com8.con {
        public aux() {
        }

        @Override // COM9.com8.con
        public void a(com9 com9Var, Matrix matrix, int i2) {
            com3.this.f83a.set(i2, com9Var.e());
            com3.this.f84a[i2] = com9Var.f(matrix);
        }

        @Override // COM9.com8.con
        public void b(com9 com9Var, Matrix matrix, int i2) {
            com3.this.f83a.set(i2 + 4, com9Var.e());
            com3.this.f90b[i2] = com9Var.f(matrix);
        }
    }

    public class con implements com7.nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ float f5731a;

        public con(float f2) {
            this.f5731a = f2;
        }

        @Override // COM9.com7.nul
        public COM9.nul a(COM9.nul nulVar) {
            return nulVar instanceof com5 ? nulVar : new COM9.con(this.f5731a, nulVar);
        }
    }

    static {
        Paint paint = new Paint(1);
        f5728c = paint;
        paint.setColor(-1);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
    }

    public /* synthetic */ com3(nul nulVar, aux auxVar) {
        this(nulVar);
    }

    public static int S(int i2, int i3) {
        return (i2 * (i3 + (i3 >>> 7))) >>> 8;
    }

    public static com3 m(Context context, float f2) {
        int iC = p030Com8.prn.c(context, x3.f9038m, com3.class.getSimpleName());
        com3 com3Var = new com3();
        com3Var.N(context);
        com3Var.Y(ColorStateList.valueOf(iC));
        com3Var.X(f2);
        return com3Var;
    }

    public int A() {
        nul nulVar = this.f72a;
        return (int) (((double) nulVar.f107d) * Math.sin(Math.toRadians(nulVar.f109e)));
    }

    public int B() {
        nul nulVar = this.f72a;
        return (int) (((double) nulVar.f107d) * Math.cos(Math.toRadians(nulVar.f109e)));
    }

    public int C() {
        return this.f72a.f105c;
    }

    public com7 D() {
        return this.f72a.f95a;
    }

    public final float E() {
        if (M()) {
            return this.f5729b.getStrokeWidth() / 2.0f;
        }
        return 0.0f;
    }

    public ColorStateList F() {
        return this.f72a.f108d;
    }

    public float G() {
        return this.f72a.f95a.r().a(u());
    }

    public float H() {
        return this.f72a.f95a.t().a(u());
    }

    public float I() {
        return this.f72a.f5737f;
    }

    public float J() {
        return w() + I();
    }

    public final boolean K() {
        nul nulVar = this.f72a;
        int i2 = nulVar.f103b;
        return i2 != 1 && nulVar.f105c > 0 && (i2 == 2 || U());
    }

    public final boolean L() {
        Paint.Style style = this.f72a.f99a;
        return style == Paint.Style.FILL_AND_STROKE || style == Paint.Style.FILL;
    }

    public final boolean M() {
        Paint.Style style = this.f72a.f99a;
        return (style == Paint.Style.FILL_AND_STROKE || style == Paint.Style.STROKE) && this.f5729b.getStrokeWidth() > 0.0f;
    }

    public void N(Context context) {
        this.f72a.f96a = new p020CoM8.nul(context);
        i0();
    }

    public final void O() {
        super.invalidateSelf();
    }

    public boolean P() {
        p020CoM8.nul nulVar = this.f72a.f96a;
        return nulVar != null && nulVar.d();
    }

    public boolean Q() {
        return this.f72a.f95a.u(u());
    }

    public final void R(Canvas canvas) {
        if (K()) {
            canvas.save();
            T(canvas);
            if (!this.f92c) {
                n(canvas);
                canvas.restore();
                return;
            }
            int iWidth = (int) (this.f91c.width() - getBounds().width());
            int iHeight = (int) (this.f91c.height() - getBounds().height());
            if (iWidth < 0 || iHeight < 0) {
                throw new IllegalStateException("Invalid shadow bounds. Check that the treatments result in a valid path.");
            }
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(((int) this.f91c.width()) + (this.f72a.f105c * 2) + iWidth, ((int) this.f91c.height()) + (this.f72a.f105c * 2) + iHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas2 = new Canvas(bitmapCreateBitmap);
            float f2 = (getBounds().left - this.f72a.f105c) - iWidth;
            float f3 = (getBounds().top - this.f72a.f105c) - iHeight;
            canvas2.translate(-f2, -f3);
            n(canvas2);
            canvas.drawBitmap(bitmapCreateBitmap, f2, f3, (Paint) null);
            bitmapCreateBitmap.recycle();
            canvas.restore();
        }
    }

    public final void T(Canvas canvas) {
        canvas.translate(A(), B());
    }

    public boolean U() {
        return (Q() || this.f78a.isConvex() || Build.VERSION.SDK_INT >= 29) ? false : true;
    }

    public void V(float f2) {
        setShapeAppearanceModel(this.f72a.f95a.w(f2));
    }

    public void W(COM9.nul nulVar) {
        setShapeAppearanceModel(this.f72a.f95a.x(nulVar));
    }

    public void X(float f2) {
        nul nulVar = this.f72a;
        if (nulVar.f5736e != f2) {
            nulVar.f5736e = f2;
            i0();
        }
    }

    public void Y(ColorStateList colorStateList) {
        nul nulVar = this.f72a;
        if (nulVar.f97a != colorStateList) {
            nulVar.f97a = colorStateList;
            onStateChange(getState());
        }
    }

    public void Z(float f2) {
        nul nulVar = this.f72a;
        if (nulVar.f5733b != f2) {
            nulVar.f5733b = f2;
            this.f89b = true;
            invalidateSelf();
        }
    }

    public void a0(int i2, int i3, int i4, int i5) {
        nul nulVar = this.f72a;
        if (nulVar.f101a == null) {
            nulVar.f101a = new Rect();
        }
        this.f72a.f101a.set(i2, i3, i4, i5);
        invalidateSelf();
    }

    public void b0(float f2) {
        nul nulVar = this.f72a;
        if (nulVar.f5735d != f2) {
            nulVar.f5735d = f2;
            i0();
        }
    }

    public void c0(float f2, int i2) {
        f0(f2);
        e0(ColorStateList.valueOf(i2));
    }

    public void d0(float f2, ColorStateList colorStateList) {
        f0(f2);
        e0(colorStateList);
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        this.f77a.setColorFilter(this.f79a);
        int alpha = this.f77a.getAlpha();
        this.f77a.setAlpha(S(alpha, this.f72a.f94a));
        this.f5729b.setColorFilter(this.f86b);
        this.f5729b.setStrokeWidth(this.f72a.f5734c);
        int alpha2 = this.f5729b.getAlpha();
        this.f5729b.setAlpha(S(alpha2, this.f72a.f94a));
        if (this.f89b) {
            i();
            g(u(), this.f78a);
            this.f89b = false;
        }
        R(canvas);
        if (L()) {
            o(canvas);
        }
        if (M()) {
            r(canvas);
        }
        this.f77a.setAlpha(alpha);
        this.f5729b.setAlpha(alpha2);
    }

    public void e0(ColorStateList colorStateList) {
        nul nulVar = this.f72a;
        if (nulVar.f104b != colorStateList) {
            nulVar.f104b = colorStateList;
            onStateChange(getState());
        }
    }

    public final PorterDuffColorFilter f(Paint paint, boolean z2) {
        if (!z2) {
            return null;
        }
        int color = paint.getColor();
        int iL = l(color);
        this.f71a = iL;
        if (iL != color) {
            return new PorterDuffColorFilter(iL, PorterDuff.Mode.SRC_IN);
        }
        return null;
    }

    public void f0(float f2) {
        this.f72a.f5734c = f2;
        invalidateSelf();
    }

    public final void g(RectF rectF, Path path) {
        h(rectF, path);
        if (this.f72a.f5732a != 1.0f) {
            this.f76a.reset();
            Matrix matrix = this.f76a;
            float f2 = this.f72a.f5732a;
            matrix.setScale(f2, f2, rectF.width() / 2.0f, rectF.height() / 2.0f);
            path.transform(this.f76a);
        }
        path.computeBounds(this.f91c, true);
    }

    public final boolean g0(int[] iArr) {
        boolean z2;
        int color;
        int colorForState;
        int color2;
        int colorForState2;
        if (this.f72a.f97a == null || color2 == (colorForState2 = this.f72a.f97a.getColorForState(iArr, (color2 = this.f77a.getColor())))) {
            z2 = false;
        } else {
            this.f77a.setColor(colorForState2);
            z2 = true;
        }
        if (this.f72a.f104b == null || color == (colorForState = this.f72a.f104b.getColorForState(iArr, (color = this.f5729b.getColor())))) {
            return z2;
        }
        this.f5729b.setColor(colorForState);
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        return this.f72a.f94a;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        return this.f72a;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    @TargetApi(21)
    public void getOutline(Outline outline) {
        if (this.f72a.f103b == 2) {
            return;
        }
        if (Q()) {
            outline.setRoundRect(getBounds(), G() * this.f72a.f5733b);
            return;
        }
        g(u(), this.f78a);
        if (this.f78a.isConvex() || Build.VERSION.SDK_INT >= 29) {
            try {
                outline.setConvexPath(this.f78a);
            } catch (IllegalArgumentException unused) {
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        Rect rect2 = this.f72a.f101a;
        if (rect2 == null) {
            return super.getPadding(rect);
        }
        rect.set(rect2);
        return true;
    }

    @Override // android.graphics.drawable.Drawable
    public Region getTransparentRegion() {
        this.f81a.set(getBounds());
        g(u(), this.f78a);
        this.f88b.setPath(this.f78a, this.f81a);
        this.f81a.op(this.f88b, Region.Op.DIFFERENCE);
        return this.f81a;
    }

    public final void h(RectF rectF, Path path) {
        com8 com8Var = this.f75a;
        nul nulVar = this.f72a;
        com8Var.d(nulVar.f95a, nulVar.f5733b, rectF, this.f74a, path);
    }

    public final boolean h0() {
        PorterDuffColorFilter porterDuffColorFilter = this.f79a;
        PorterDuffColorFilter porterDuffColorFilter2 = this.f86b;
        nul nulVar = this.f72a;
        this.f79a = k(nulVar.f108d, nulVar.f100a, this.f77a, true);
        nul nulVar2 = this.f72a;
        this.f86b = k(nulVar2.f106c, nulVar2.f100a, this.f5729b, false);
        nul nulVar3 = this.f72a;
        if (nulVar3.f102a) {
            this.f82a.d(nulVar3.f108d.getColorForState(getState(), 0));
        }
        return (p2.a(porterDuffColorFilter, this.f79a) && p2.a(porterDuffColorFilter2, this.f86b)) ? false : true;
    }

    public final void i() {
        com7 com7VarY = D().y(new con(-E()));
        this.f73a = com7VarY;
        this.f75a.e(com7VarY, this.f72a.f5733b, v(), this.f85b);
    }

    public final void i0() {
        float fJ = J();
        this.f72a.f105c = (int) Math.ceil(0.75f * fJ);
        this.f72a.f107d = (int) Math.ceil(fJ * 0.25f);
        h0();
        O();
    }

    @Override // android.graphics.drawable.Drawable
    public void invalidateSelf() {
        this.f89b = true;
        super.invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        ColorStateList colorStateList3;
        ColorStateList colorStateList4;
        return super.isStateful() || ((colorStateList = this.f72a.f108d) != null && colorStateList.isStateful()) || (((colorStateList2 = this.f72a.f106c) != null && colorStateList2.isStateful()) || (((colorStateList3 = this.f72a.f104b) != null && colorStateList3.isStateful()) || ((colorStateList4 = this.f72a.f97a) != null && colorStateList4.isStateful())));
    }

    public final PorterDuffColorFilter j(ColorStateList colorStateList, PorterDuff.Mode mode, boolean z2) {
        int colorForState = colorStateList.getColorForState(getState(), 0);
        if (z2) {
            colorForState = l(colorForState);
        }
        this.f71a = colorForState;
        return new PorterDuffColorFilter(colorForState, mode);
    }

    public final PorterDuffColorFilter k(ColorStateList colorStateList, PorterDuff.Mode mode, Paint paint, boolean z2) {
        return (colorStateList == null || mode == null) ? f(paint, z2) : j(colorStateList, mode, z2);
    }

    public int l(int i2) {
        float fJ = J() + y();
        p020CoM8.nul nulVar = this.f72a.f96a;
        return nulVar != null ? nulVar.c(i2, fJ) : i2;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        this.f72a = new nul(this.f72a);
        return this;
    }

    public final void n(Canvas canvas) {
        if (this.f83a.cardinality() > 0) {
            Log.w(f5727a, "Compatibility shadow requested but can't be drawn for all operations in this shape.");
        }
        if (this.f72a.f107d != 0) {
            canvas.drawPath(this.f78a, this.f82a.c());
        }
        for (int i2 = 0; i2 < 4; i2++) {
            this.f84a[i2].b(this.f82a, this.f72a.f105c, canvas);
            this.f90b[i2].b(this.f82a, this.f72a.f105c, canvas);
        }
        if (this.f92c) {
            int iA = A();
            int iB = B();
            canvas.translate(-iA, -iB);
            canvas.drawPath(this.f78a, f5728c);
            canvas.translate(iA, iB);
        }
    }

    public final void o(Canvas canvas) {
        p(canvas, this.f77a, this.f78a, this.f72a.f95a, u());
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        this.f89b = true;
        super.onBoundsChange(rect);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        boolean z2 = g0(iArr) || h0();
        if (z2) {
            invalidateSelf();
        }
        return z2;
    }

    public final void p(Canvas canvas, Paint paint, Path path, com7 com7Var, RectF rectF) {
        if (!com7Var.u(rectF)) {
            canvas.drawPath(path, paint);
        } else {
            float fA = com7Var.t().a(rectF) * this.f72a.f5733b;
            canvas.drawRoundRect(rectF, fA, fA, paint);
        }
    }

    public void q(Canvas canvas, Paint paint, Path path, RectF rectF) {
        p(canvas, paint, path, this.f72a.f95a, rectF);
    }

    public void r(Canvas canvas) {
        p(canvas, this.f5729b, this.f85b, this.f73a, v());
    }

    public float s() {
        return this.f72a.f95a.j().a(u());
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        nul nulVar = this.f72a;
        if (nulVar.f94a != i2) {
            nulVar.f94a = i2;
            O();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        this.f72a.f98a = colorFilter;
        O();
    }

    @Override // COM9.lpt1
    public void setShapeAppearanceModel(com7 com7Var) {
        this.f72a.f95a = com7Var;
        invalidateSelf();
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i2) {
        setTintList(ColorStateList.valueOf(i2));
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        this.f72a.f108d = colorStateList;
        h0();
        O();
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        nul nulVar = this.f72a;
        if (nulVar.f100a != mode) {
            nulVar.f100a = mode;
            h0();
            O();
        }
    }

    public float t() {
        return this.f72a.f95a.l().a(u());
    }

    public RectF u() {
        this.f80a.set(getBounds());
        return this.f80a;
    }

    public final RectF v() {
        this.f87b.set(u());
        float fE = E();
        this.f87b.inset(fE, fE);
        return this.f87b;
    }

    public float w() {
        return this.f72a.f5736e;
    }

    public ColorStateList x() {
        return this.f72a.f97a;
    }

    public float y() {
        return this.f72a.f5735d;
    }

    public int z() {
        return this.f71a;
    }

    public com3() {
        this(new com7());
    }

    public com3(Context context, AttributeSet attributeSet, int i2, int i3) {
        this(com7.e(context, attributeSet, i2, i3).m());
    }

    public com3(com7 com7Var) {
        this(new nul(com7Var, null));
    }

    public com3(nul nulVar) {
        com8 com8Var;
        this.f84a = new com9.com3[4];
        this.f90b = new com9.com3[4];
        this.f83a = new BitSet(8);
        this.f76a = new Matrix();
        this.f78a = new Path();
        this.f85b = new Path();
        this.f80a = new RectF();
        this.f87b = new RectF();
        this.f81a = new Region();
        this.f88b = new Region();
        Paint paint = new Paint(1);
        this.f77a = paint;
        Paint paint2 = new Paint(1);
        this.f5729b = paint2;
        this.f82a = new lpt6();
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            com8Var = com8.k();
        } else {
            com8Var = new com8();
        }
        this.f75a = com8Var;
        this.f91c = new RectF();
        this.f92c = true;
        this.f72a = nulVar;
        paint2.setStyle(Paint.Style.STROKE);
        paint.setStyle(Paint.Style.FILL);
        h0();
        g0(getState());
        this.f74a = new aux();
    }

    public static final class nul extends Drawable.ConstantState {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f5732a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f94a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com7 f95a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public p020CoM8.nul f96a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ColorStateList f97a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ColorFilter f98a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Paint.Style f99a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public PorterDuff.Mode f100a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Rect f101a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f102a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f5733b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public int f103b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public ColorStateList f104b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f5734c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public int f105c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public ColorStateList f106c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f5735d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public int f107d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public ColorStateList f108d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f5736e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public int f109e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f5737f;

        public nul(com7 com7Var, p020CoM8.nul nulVar) {
            this.f97a = null;
            this.f104b = null;
            this.f106c = null;
            this.f108d = null;
            this.f100a = PorterDuff.Mode.SRC_IN;
            this.f101a = null;
            this.f5732a = 1.0f;
            this.f5733b = 1.0f;
            this.f94a = 255;
            this.f5735d = 0.0f;
            this.f5736e = 0.0f;
            this.f5737f = 0.0f;
            this.f103b = 0;
            this.f105c = 0;
            this.f107d = 0;
            this.f109e = 0;
            this.f102a = false;
            this.f99a = Paint.Style.FILL_AND_STROKE;
            this.f95a = com7Var;
            this.f96a = nulVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return 0;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            com3 com3Var = new com3(this, null);
            com3Var.f89b = true;
            return com3Var;
        }

        public nul(nul nulVar) {
            this.f97a = null;
            this.f104b = null;
            this.f106c = null;
            this.f108d = null;
            this.f100a = PorterDuff.Mode.SRC_IN;
            this.f101a = null;
            this.f5732a = 1.0f;
            this.f5733b = 1.0f;
            this.f94a = 255;
            this.f5735d = 0.0f;
            this.f5736e = 0.0f;
            this.f5737f = 0.0f;
            this.f103b = 0;
            this.f105c = 0;
            this.f107d = 0;
            this.f109e = 0;
            this.f102a = false;
            this.f99a = Paint.Style.FILL_AND_STROKE;
            this.f95a = nulVar.f95a;
            this.f96a = nulVar.f96a;
            this.f5734c = nulVar.f5734c;
            this.f98a = nulVar.f98a;
            this.f97a = nulVar.f97a;
            this.f104b = nulVar.f104b;
            this.f100a = nulVar.f100a;
            this.f108d = nulVar.f108d;
            this.f94a = nulVar.f94a;
            this.f5732a = nulVar.f5732a;
            this.f107d = nulVar.f107d;
            this.f103b = nulVar.f103b;
            this.f102a = nulVar.f102a;
            this.f5733b = nulVar.f5733b;
            this.f5735d = nulVar.f5735d;
            this.f5736e = nulVar.f5736e;
            this.f5737f = nulVar.f5737f;
            this.f105c = nulVar.f105c;
            this.f109e = nulVar.f109e;
            this.f106c = nulVar.f106c;
            this.f99a = nulVar.f99a;
            if (nulVar.f101a != null) {
                this.f101a = new Rect(nulVar.f101a);
            }
        }
    }
}
