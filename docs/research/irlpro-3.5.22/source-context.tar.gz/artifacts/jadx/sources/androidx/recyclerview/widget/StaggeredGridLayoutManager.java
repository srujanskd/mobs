package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.preference.Preference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import p081cOm2.e2;

/* JADX INFO: loaded from: classes.dex */
public class StaggeredGridLayoutManager extends RecyclerView.lpt2 implements RecyclerView.d.con {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f2820a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.recyclerview.widget.com2 f2823a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5 f2824a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public BitSet f2826a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f2827a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com2[] f2828a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public com5 f8620b;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8622g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8623h;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f2831i;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f2832j;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f8627l;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8621f = -1;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f2829g = false;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f2830h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8624i = -1;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8625j = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f2822a = new prn();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8626k = 2;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f8619a = new Rect();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final con f2821a = new con();

    /* JADX INFO: renamed from: k, reason: collision with other field name */
    public boolean f2833k = false;

    /* JADX INFO: renamed from: l, reason: collision with other field name */
    public boolean f2834l = true;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2825a = new aux();

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            StaggeredGridLayoutManager.this.S1();
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class com1 implements Parcelable {
        public static final Parcelable.Creator<com1> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8629a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public List<prn.aux> f2835a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int[] f2836a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8630b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2837b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public int[] f2838b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8631c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2839c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8632d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f2840d;

        public static class aux implements Parcelable.Creator<com1> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com1 createFromParcel(Parcel parcel) {
                return new com1(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com1[] newArray(int i2) {
                return new com1[i2];
            }
        }

        public com1() {
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public void k() {
            this.f2836a = null;
            this.f8631c = 0;
            this.f8629a = -1;
            this.f8630b = -1;
        }

        public void m() {
            this.f2836a = null;
            this.f8631c = 0;
            this.f8632d = 0;
            this.f2838b = null;
            this.f2835a = null;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.f8629a);
            parcel.writeInt(this.f8630b);
            parcel.writeInt(this.f8631c);
            if (this.f8631c > 0) {
                parcel.writeIntArray(this.f2836a);
            }
            parcel.writeInt(this.f8632d);
            if (this.f8632d > 0) {
                parcel.writeIntArray(this.f2838b);
            }
            parcel.writeInt(this.f2837b ? 1 : 0);
            parcel.writeInt(this.f2839c ? 1 : 0);
            parcel.writeInt(this.f2840d ? 1 : 0);
            parcel.writeList(this.f2835a);
        }

        public com1(Parcel parcel) {
            this.f8629a = parcel.readInt();
            this.f8630b = parcel.readInt();
            int i2 = parcel.readInt();
            this.f8631c = i2;
            if (i2 > 0) {
                int[] iArr = new int[i2];
                this.f2836a = iArr;
                parcel.readIntArray(iArr);
            }
            int i3 = parcel.readInt();
            this.f8632d = i3;
            if (i3 > 0) {
                int[] iArr2 = new int[i3];
                this.f2838b = iArr2;
                parcel.readIntArray(iArr2);
            }
            this.f2837b = parcel.readInt() == 1;
            this.f2839c = parcel.readInt() == 1;
            this.f2840d = parcel.readInt() == 1;
            this.f2835a = parcel.readArrayList(prn.aux.class.getClassLoader());
        }

        public com1(com1 com1Var) {
            this.f8631c = com1Var.f8631c;
            this.f8629a = com1Var.f8629a;
            this.f8630b = com1Var.f8630b;
            this.f2836a = com1Var.f2836a;
            this.f8632d = com1Var.f8632d;
            this.f2838b = com1Var.f2838b;
            this.f2837b = com1Var.f2837b;
            this.f2839c = com1Var.f2839c;
            this.f2840d = com1Var.f2840d;
            this.f2835a = com1Var.f2835a;
        }
    }

    public class com2 {

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final int f8636d;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ArrayList<View> f2842a = new ArrayList<>();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8633a = Integer.MIN_VALUE;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8634b = Integer.MIN_VALUE;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8635c = 0;

        public com2(int i2) {
            this.f8636d = i2;
        }

        public void a(View view) {
            nul nulVarN = n(view);
            nulVarN.f8640a = this;
            this.f2842a.add(view);
            this.f8634b = Integer.MIN_VALUE;
            if (this.f2842a.size() == 1) {
                this.f8633a = Integer.MIN_VALUE;
            }
            if (nulVarN.c() || nulVarN.b()) {
                this.f8635c += StaggeredGridLayoutManager.this.f2824a.e(view);
            }
        }

        public void b(boolean z2, int i2) {
            int iL = z2 ? l(Integer.MIN_VALUE) : p(Integer.MIN_VALUE);
            e();
            if (iL == Integer.MIN_VALUE) {
                return;
            }
            if (!z2 || iL >= StaggeredGridLayoutManager.this.f2824a.i()) {
                if (z2 || iL <= StaggeredGridLayoutManager.this.f2824a.m()) {
                    if (i2 != Integer.MIN_VALUE) {
                        iL += i2;
                    }
                    this.f8634b = iL;
                    this.f8633a = iL;
                }
            }
        }

        public void c() {
            prn.aux auxVarF;
            ArrayList<View> arrayList = this.f2842a;
            View view = arrayList.get(arrayList.size() - 1);
            nul nulVarN = n(view);
            this.f8634b = StaggeredGridLayoutManager.this.f2824a.d(view);
            if (nulVarN.f8641c && (auxVarF = StaggeredGridLayoutManager.this.f2822a.f(nulVarN.a())) != null && auxVarF.f8644b == 1) {
                this.f8634b += auxVarF.k(this.f8636d);
            }
        }

        public void d() {
            prn.aux auxVarF;
            View view = this.f2842a.get(0);
            nul nulVarN = n(view);
            this.f8633a = StaggeredGridLayoutManager.this.f2824a.g(view);
            if (nulVarN.f8641c && (auxVarF = StaggeredGridLayoutManager.this.f2822a.f(nulVarN.a())) != null && auxVarF.f8644b == -1) {
                this.f8633a -= auxVarF.k(this.f8636d);
            }
        }

        public void e() {
            this.f2842a.clear();
            q();
            this.f8635c = 0;
        }

        public int f() {
            return StaggeredGridLayoutManager.this.f2829g ? i(this.f2842a.size() - 1, -1, true) : i(0, this.f2842a.size(), true);
        }

        public int g() {
            return StaggeredGridLayoutManager.this.f2829g ? i(0, this.f2842a.size(), true) : i(this.f2842a.size() - 1, -1, true);
        }

        public int h(int i2, int i3, boolean z2, boolean z3, boolean z4) {
            int iM = StaggeredGridLayoutManager.this.f2824a.m();
            int i4 = StaggeredGridLayoutManager.this.f2824a.i();
            int i5 = i3 > i2 ? 1 : -1;
            while (i2 != i3) {
                View view = this.f2842a.get(i2);
                int iG = StaggeredGridLayoutManager.this.f2824a.g(view);
                int iD = StaggeredGridLayoutManager.this.f2824a.d(view);
                boolean z5 = false;
                boolean z6 = !z4 ? iG >= i4 : iG > i4;
                if (!z4 ? iD > iM : iD >= iM) {
                    z5 = true;
                }
                if (z6 && z5) {
                    if (z2 && z3) {
                        if (iG >= iM && iD <= i4) {
                            return StaggeredGridLayoutManager.this.h0(view);
                        }
                    } else {
                        if (z3) {
                            return StaggeredGridLayoutManager.this.h0(view);
                        }
                        if (iG < iM || iD > i4) {
                            return StaggeredGridLayoutManager.this.h0(view);
                        }
                    }
                }
                i2 += i5;
            }
            return -1;
        }

        public int i(int i2, int i3, boolean z2) {
            return h(i2, i3, false, false, z2);
        }

        public int j() {
            return this.f8635c;
        }

        public int k() {
            int i2 = this.f8634b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            c();
            return this.f8634b;
        }

        public int l(int i2) {
            int i3 = this.f8634b;
            if (i3 != Integer.MIN_VALUE) {
                return i3;
            }
            if (this.f2842a.size() == 0) {
                return i2;
            }
            c();
            return this.f8634b;
        }

        public View m(int i2, int i3) {
            View view = null;
            if (i3 != -1) {
                int size = this.f2842a.size() - 1;
                while (size >= 0) {
                    View view2 = this.f2842a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.f2829g && staggeredGridLayoutManager.h0(view2) >= i2) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.f2829g && staggeredGridLayoutManager2.h0(view2) <= i2) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.f2842a.size();
                int i4 = 0;
                while (i4 < size2) {
                    View view3 = this.f2842a.get(i4);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.f2829g && staggeredGridLayoutManager3.h0(view3) <= i2) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.f2829g && staggeredGridLayoutManager4.h0(view3) >= i2) || !view3.hasFocusable()) {
                        break;
                    }
                    i4++;
                    view = view3;
                }
            }
            return view;
        }

        public nul n(View view) {
            return (nul) view.getLayoutParams();
        }

        public int o() {
            int i2 = this.f8633a;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            d();
            return this.f8633a;
        }

        public int p(int i2) {
            int i3 = this.f8633a;
            if (i3 != Integer.MIN_VALUE) {
                return i3;
            }
            if (this.f2842a.size() == 0) {
                return i2;
            }
            d();
            return this.f8633a;
        }

        public void q() {
            this.f8633a = Integer.MIN_VALUE;
            this.f8634b = Integer.MIN_VALUE;
        }

        public void r(int i2) {
            int i3 = this.f8633a;
            if (i3 != Integer.MIN_VALUE) {
                this.f8633a = i3 + i2;
            }
            int i4 = this.f8634b;
            if (i4 != Integer.MIN_VALUE) {
                this.f8634b = i4 + i2;
            }
        }

        public void s() {
            int size = this.f2842a.size();
            View viewRemove = this.f2842a.remove(size - 1);
            nul nulVarN = n(viewRemove);
            nulVarN.f8640a = null;
            if (nulVarN.c() || nulVarN.b()) {
                this.f8635c -= StaggeredGridLayoutManager.this.f2824a.e(viewRemove);
            }
            if (size == 1) {
                this.f8633a = Integer.MIN_VALUE;
            }
            this.f8634b = Integer.MIN_VALUE;
        }

        public void t() {
            View viewRemove = this.f2842a.remove(0);
            nul nulVarN = n(viewRemove);
            nulVarN.f8640a = null;
            if (this.f2842a.size() == 0) {
                this.f8634b = Integer.MIN_VALUE;
            }
            if (nulVarN.c() || nulVarN.b()) {
                this.f8635c -= StaggeredGridLayoutManager.this.f2824a.e(viewRemove);
            }
            this.f8633a = Integer.MIN_VALUE;
        }

        public void u(View view) {
            nul nulVarN = n(view);
            nulVarN.f8640a = this;
            this.f2842a.add(0, view);
            this.f8633a = Integer.MIN_VALUE;
            if (this.f2842a.size() == 1) {
                this.f8634b = Integer.MIN_VALUE;
            }
            if (nulVarN.c() || nulVarN.b()) {
                this.f8635c += StaggeredGridLayoutManager.this.f2824a.e(view);
            }
        }

        public void v(int i2) {
            this.f8633a = i2;
            this.f8634b = i2;
        }
    }

    public class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8637a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2844a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int[] f2845a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8638b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2846b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8639c;

        public con() {
            c();
        }

        public void a() {
            this.f8638b = this.f2844a ? StaggeredGridLayoutManager.this.f2824a.i() : StaggeredGridLayoutManager.this.f2824a.m();
        }

        public void b(int i2) {
            if (this.f2844a) {
                this.f8638b = StaggeredGridLayoutManager.this.f2824a.i() - i2;
            } else {
                this.f8638b = StaggeredGridLayoutManager.this.f2824a.m() + i2;
            }
        }

        public void c() {
            this.f8637a = -1;
            this.f8638b = Integer.MIN_VALUE;
            this.f2844a = false;
            this.f2846b = false;
            this.f8639c = false;
            int[] iArr = this.f2845a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }

        public void d(com2[] com2VarArr) {
            int length = com2VarArr.length;
            int[] iArr = this.f2845a;
            if (iArr == null || iArr.length < length) {
                this.f2845a = new int[StaggeredGridLayoutManager.this.f2828a.length];
            }
            for (int i2 = 0; i2 < length; i2++) {
                this.f2845a[i2] = com2VarArr[i2].p(Integer.MIN_VALUE);
            }
        }
    }

    public static class nul extends RecyclerView.lpt3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public com2 f8640a;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8641c;

        public nul(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public final int e() {
            com2 com2Var = this.f8640a;
            if (com2Var == null) {
                return -1;
            }
            return com2Var.f8636d;
        }

        public boolean f() {
            return this.f8641c;
        }

        public nul(int i2, int i3) {
            super(i2, i3);
        }

        public nul(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public nul(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        RecyclerView.lpt2.prn prnVarI0 = RecyclerView.lpt2.i0(context, attributeSet, i2, i3);
        H2(prnVarI0.f8608a);
        J2(prnVarI0.f8609b);
        I2(prnVarI0.f2808a);
        this.f2823a = new androidx.recyclerview.widget.com2();
        a2();
    }

    public final void A2(RecyclerView.lpt9 lpt9Var, androidx.recyclerview.widget.com2 com2Var) {
        int iMin;
        if (!com2Var.f2864a || com2Var.f2866c) {
            return;
        }
        if (com2Var.f8658a == 0) {
            if (com2Var.f8661d == -1) {
                B2(lpt9Var, com2Var.f8663f);
                return;
            } else {
                C2(lpt9Var, com2Var.f8662e);
                return;
            }
        }
        if (com2Var.f8661d == -1) {
            int i2 = com2Var.f8662e;
            int iM2 = i2 - m2(i2);
            B2(lpt9Var, iM2 < 0 ? com2Var.f8663f : com2Var.f8663f - Math.min(iM2, com2Var.f8658a));
        } else {
            int iN2 = n2(com2Var.f8663f) - com2Var.f8663f;
            if (iN2 < 0) {
                iMin = com2Var.f8662e;
            } else {
                iMin = Math.min(iN2, com2Var.f8658a) + com2Var.f8662e;
            }
            C2(lpt9Var, iMin);
        }
    }

    public final void B2(RecyclerView.lpt9 lpt9Var, int i2) {
        for (int iJ = J() - 1; iJ >= 0; iJ--) {
            View viewI = I(iJ);
            if (this.f2824a.g(viewI) < i2 || this.f2824a.q(viewI) < i2) {
                return;
            }
            nul nulVar = (nul) viewI.getLayoutParams();
            if (nulVar.f8641c) {
                for (int i3 = 0; i3 < this.f8621f; i3++) {
                    if (this.f2828a[i3].f2842a.size() == 1) {
                        return;
                    }
                }
                for (int i4 = 0; i4 < this.f8621f; i4++) {
                    this.f2828a[i4].s();
                }
            } else if (nulVar.f8640a.f2842a.size() == 1) {
                return;
            } else {
                nulVar.f8640a.s();
            }
            m1(viewI, lpt9Var);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void C0(int i2) {
        super.C0(i2);
        for (int i3 = 0; i3 < this.f8621f; i3++) {
            this.f2828a[i3].r(i2);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void C1(Rect rect, int i2, int i3) {
        int iN;
        int iN2;
        int iE0 = e0() + f0();
        int iG0 = g0() + d0();
        if (this.f8622g == 1) {
            iN2 = RecyclerView.lpt2.n(i3, rect.height() + iG0, b0());
            iN = RecyclerView.lpt2.n(i2, (this.f8623h * this.f8621f) + iE0, c0());
        } else {
            iN = RecyclerView.lpt2.n(i2, rect.width() + iE0, c0());
            iN2 = RecyclerView.lpt2.n(i3, (this.f8623h * this.f8621f) + iG0, b0());
        }
        B1(iN, iN2);
    }

    public final void C2(RecyclerView.lpt9 lpt9Var, int i2) {
        while (J() > 0) {
            View viewI = I(0);
            if (this.f2824a.d(viewI) > i2 || this.f2824a.p(viewI) > i2) {
                return;
            }
            nul nulVar = (nul) viewI.getLayoutParams();
            if (nulVar.f8641c) {
                for (int i3 = 0; i3 < this.f8621f; i3++) {
                    if (this.f2828a[i3].f2842a.size() == 1) {
                        return;
                    }
                }
                for (int i4 = 0; i4 < this.f8621f; i4++) {
                    this.f2828a[i4].t();
                }
            } else if (nulVar.f8640a.f2842a.size() == 1) {
                return;
            } else {
                nulVar.f8640a.t();
            }
            m1(viewI, lpt9Var);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 D() {
        return this.f8622g == 0 ? new nul(-2, -1) : new nul(-1, -2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void D0(int i2) {
        super.D0(i2);
        for (int i3 = 0; i3 < this.f8621f; i3++) {
            this.f2828a[i3].r(i2);
        }
    }

    public final void D2() {
        if (this.f8620b.k() == 1073741824) {
            return;
        }
        int iJ = J();
        float fMax = 0.0f;
        for (int i2 = 0; i2 < iJ; i2++) {
            View viewI = I(i2);
            float fE = this.f8620b.e(viewI);
            if (fE >= fMax) {
                if (((nul) viewI.getLayoutParams()).f()) {
                    fE = (fE * 1.0f) / this.f8621f;
                }
                fMax = Math.max(fMax, fE);
            }
        }
        int i3 = this.f8623h;
        int iRound = Math.round(fMax * this.f8621f);
        if (this.f8620b.k() == Integer.MIN_VALUE) {
            iRound = Math.min(iRound, this.f8620b.n());
        }
        P2(iRound);
        if (this.f8623h == i3) {
            return;
        }
        for (int i4 = 0; i4 < iJ; i4++) {
            View viewI2 = I(i4);
            nul nulVar = (nul) viewI2.getLayoutParams();
            if (!nulVar.f8641c) {
                if (t2() && this.f8622g == 1) {
                    int i5 = this.f8621f;
                    int i6 = nulVar.f8640a.f8636d;
                    viewI2.offsetLeftAndRight(((-((i5 - 1) - i6)) * this.f8623h) - ((-((i5 - 1) - i6)) * i3));
                } else {
                    int i7 = nulVar.f8640a.f8636d;
                    int i8 = this.f8623h * i7;
                    int i9 = i7 * i3;
                    if (this.f8622g == 1) {
                        viewI2.offsetLeftAndRight(i8 - i9);
                    } else {
                        viewI2.offsetTopAndBottom(i8 - i9);
                    }
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 E(Context context, AttributeSet attributeSet) {
        return new nul(context, attributeSet);
    }

    public final void E2() {
        if (this.f8622g == 1 || !t2()) {
            this.f2830h = this.f2829g;
        } else {
            this.f2830h = !this.f2829g;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 F(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new nul((ViewGroup.MarginLayoutParams) layoutParams) : new nul(layoutParams);
    }

    public int F2(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (J() == 0 || i2 == 0) {
            return 0;
        }
        y2(i2, eVar);
        int iB2 = b2(lpt9Var, this.f2823a, eVar);
        if (this.f2823a.f8658a >= iB2) {
            i2 = i2 < 0 ? -iB2 : iB2;
        }
        this.f2824a.r(-i2);
        this.f2831i = this.f2830h;
        androidx.recyclerview.widget.com2 com2Var = this.f2823a;
        com2Var.f8658a = 0;
        A2(lpt9Var, com2Var);
        return i2;
    }

    public final void G2(int i2) {
        androidx.recyclerview.widget.com2 com2Var = this.f2823a;
        com2Var.f8661d = i2;
        com2Var.f8660c = this.f2830h != (i2 == -1) ? -1 : 1;
    }

    public void H2(int i2) {
        if (i2 != 0 && i2 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        g(null);
        if (i2 == this.f8622g) {
            return;
        }
        this.f8622g = i2;
        com5 com5Var = this.f2824a;
        this.f2824a = this.f8620b;
        this.f8620b = com5Var;
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void I0(RecyclerView recyclerView, RecyclerView.lpt9 lpt9Var) {
        super.I0(recyclerView, lpt9Var);
        o1(this.f2825a);
        for (int i2 = 0; i2 < this.f8621f; i2++) {
            this.f2828a[i2].e();
        }
        recyclerView.requestLayout();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void I1(RecyclerView recyclerView, RecyclerView.e eVar, int i2) {
        com3 com3Var = new com3(recyclerView.getContext());
        com3Var.p(i2);
        J1(com3Var);
    }

    public void I2(boolean z2) {
        g(null);
        com1 com1Var = this.f2820a;
        if (com1Var != null && com1Var.f2837b != z2) {
            com1Var.f2837b = z2;
        }
        this.f2829g = z2;
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public View J0(View view, int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        View viewB;
        View viewM;
        if (J() == 0 || (viewB = B(view)) == null) {
            return null;
        }
        E2();
        int iX1 = X1(i2);
        if (iX1 == Integer.MIN_VALUE) {
            return null;
        }
        nul nulVar = (nul) viewB.getLayoutParams();
        boolean z2 = nulVar.f8641c;
        com2 com2Var = nulVar.f8640a;
        int iK2 = iX1 == 1 ? k2() : j2();
        O2(iK2, eVar);
        G2(iX1);
        androidx.recyclerview.widget.com2 com2Var2 = this.f2823a;
        com2Var2.f8659b = com2Var2.f8660c + iK2;
        com2Var2.f8658a = (int) (this.f2824a.n() * 0.33333334f);
        androidx.recyclerview.widget.com2 com2Var3 = this.f2823a;
        com2Var3.f2865b = true;
        com2Var3.f2864a = false;
        b2(lpt9Var, com2Var3, eVar);
        this.f2831i = this.f2830h;
        if (!z2 && (viewM = com2Var.m(iK2, iX1)) != null && viewM != viewB) {
            return viewM;
        }
        if (x2(iX1)) {
            for (int i3 = this.f8621f - 1; i3 >= 0; i3--) {
                View viewM2 = this.f2828a[i3].m(iK2, iX1);
                if (viewM2 != null && viewM2 != viewB) {
                    return viewM2;
                }
            }
        } else {
            for (int i4 = 0; i4 < this.f8621f; i4++) {
                View viewM3 = this.f2828a[i4].m(iK2, iX1);
                if (viewM3 != null && viewM3 != viewB) {
                    return viewM3;
                }
            }
        }
        boolean z3 = (this.f2829g ^ true) == (iX1 == -1);
        if (!z2) {
            View viewC = C(z3 ? com2Var.f() : com2Var.g());
            if (viewC != null && viewC != viewB) {
                return viewC;
            }
        }
        if (x2(iX1)) {
            for (int i5 = this.f8621f - 1; i5 >= 0; i5--) {
                if (i5 != com2Var.f8636d) {
                    View viewC2 = C(z3 ? this.f2828a[i5].f() : this.f2828a[i5].g());
                    if (viewC2 != null && viewC2 != viewB) {
                        return viewC2;
                    }
                }
            }
        } else {
            for (int i6 = 0; i6 < this.f8621f; i6++) {
                View viewC3 = C(z3 ? this.f2828a[i6].f() : this.f2828a[i6].g());
                if (viewC3 != null && viewC3 != viewB) {
                    return viewC3;
                }
            }
        }
        return null;
    }

    public void J2(int i2) {
        g(null);
        if (i2 != this.f8621f) {
            s2();
            this.f8621f = i2;
            this.f2826a = new BitSet(this.f8621f);
            this.f2828a = new com2[this.f8621f];
            for (int i3 = 0; i3 < this.f8621f; i3++) {
                this.f2828a[i3] = new com2(i3);
            }
            t1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void K0(AccessibilityEvent accessibilityEvent) {
        super.K0(accessibilityEvent);
        if (J() > 0) {
            View viewE2 = e2(false);
            View viewD2 = d2(false);
            if (viewE2 == null || viewD2 == null) {
                return;
            }
            int iH0 = h0(viewE2);
            int iH1 = h0(viewD2);
            if (iH0 < iH1) {
                accessibilityEvent.setFromIndex(iH0);
                accessibilityEvent.setToIndex(iH1);
            } else {
                accessibilityEvent.setFromIndex(iH1);
                accessibilityEvent.setToIndex(iH0);
            }
        }
    }

    public final void K2(int i2, int i3) {
        for (int i4 = 0; i4 < this.f8621f; i4++) {
            if (!this.f2828a[i4].f2842a.isEmpty()) {
                Q2(this.f2828a[i4], i2, i3);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean L1() {
        return this.f2820a == null;
    }

    public final boolean L2(RecyclerView.e eVar, con conVar) {
        conVar.f8637a = this.f2831i ? g2(eVar.b()) : c2(eVar.b());
        conVar.f8638b = Integer.MIN_VALUE;
        return true;
    }

    public final void M1(View view) {
        for (int i2 = this.f8621f - 1; i2 >= 0; i2--) {
            this.f2828a[i2].a(view);
        }
    }

    public boolean M2(RecyclerView.e eVar, con conVar) {
        int i2;
        if (!eVar.e() && (i2 = this.f8624i) != -1) {
            if (i2 >= 0 && i2 < eVar.b()) {
                com1 com1Var = this.f2820a;
                if (com1Var == null || com1Var.f8629a == -1 || com1Var.f8631c < 1) {
                    View viewC = C(this.f8624i);
                    if (viewC != null) {
                        conVar.f8637a = this.f2830h ? k2() : j2();
                        if (this.f8625j != Integer.MIN_VALUE) {
                            if (conVar.f2844a) {
                                conVar.f8638b = (this.f2824a.i() - this.f8625j) - this.f2824a.d(viewC);
                            } else {
                                conVar.f8638b = (this.f2824a.m() + this.f8625j) - this.f2824a.g(viewC);
                            }
                            return true;
                        }
                        if (this.f2824a.e(viewC) > this.f2824a.n()) {
                            conVar.f8638b = conVar.f2844a ? this.f2824a.i() : this.f2824a.m();
                            return true;
                        }
                        int iG = this.f2824a.g(viewC) - this.f2824a.m();
                        if (iG < 0) {
                            conVar.f8638b = -iG;
                            return true;
                        }
                        int i3 = this.f2824a.i() - this.f2824a.d(viewC);
                        if (i3 < 0) {
                            conVar.f8638b = i3;
                            return true;
                        }
                        conVar.f8638b = Integer.MIN_VALUE;
                    } else {
                        int i4 = this.f8624i;
                        conVar.f8637a = i4;
                        int i5 = this.f8625j;
                        if (i5 == Integer.MIN_VALUE) {
                            conVar.f2844a = R1(i4) == 1;
                            conVar.a();
                        } else {
                            conVar.b(i5);
                        }
                        conVar.f2846b = true;
                    }
                } else {
                    conVar.f8638b = Integer.MIN_VALUE;
                    conVar.f8637a = this.f8624i;
                }
                return true;
            }
            this.f8624i = -1;
            this.f8625j = Integer.MIN_VALUE;
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int N(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return this.f8622g == 1 ? this.f8621f : super.N(lpt9Var, eVar);
    }

    public final void N1(con conVar) {
        com1 com1Var = this.f2820a;
        int i2 = com1Var.f8631c;
        if (i2 > 0) {
            if (i2 == this.f8621f) {
                for (int i3 = 0; i3 < this.f8621f; i3++) {
                    this.f2828a[i3].e();
                    com1 com1Var2 = this.f2820a;
                    int i4 = com1Var2.f2836a[i3];
                    if (i4 != Integer.MIN_VALUE) {
                        i4 += com1Var2.f2839c ? this.f2824a.i() : this.f2824a.m();
                    }
                    this.f2828a[i3].v(i4);
                }
            } else {
                com1Var.m();
                com1 com1Var3 = this.f2820a;
                com1Var3.f8629a = com1Var3.f8630b;
            }
        }
        com1 com1Var4 = this.f2820a;
        this.f2832j = com1Var4.f2840d;
        I2(com1Var4.f2837b);
        E2();
        com1 com1Var5 = this.f2820a;
        int i5 = com1Var5.f8629a;
        if (i5 != -1) {
            this.f8624i = i5;
            conVar.f2844a = com1Var5.f2839c;
        } else {
            conVar.f2844a = this.f2830h;
        }
        if (com1Var5.f8632d > 1) {
            prn prnVar = this.f2822a;
            prnVar.f2847a = com1Var5.f2838b;
            prnVar.f8642a = com1Var5.f2835a;
        }
    }

    public void N2(RecyclerView.e eVar, con conVar) {
        if (M2(eVar, conVar) || L2(eVar, conVar)) {
            return;
        }
        conVar.a();
        conVar.f8637a = 0;
    }

    public boolean O1() {
        int iL = this.f2828a[0].l(Integer.MIN_VALUE);
        for (int i2 = 1; i2 < this.f8621f; i2++) {
            if (this.f2828a[i2].l(Integer.MIN_VALUE) != iL) {
                return false;
            }
        }
        return true;
    }

    public final void O2(int i2, RecyclerView.e eVar) {
        int iN;
        int iN2;
        int iC;
        androidx.recyclerview.widget.com2 com2Var = this.f2823a;
        boolean z2 = false;
        com2Var.f8658a = 0;
        com2Var.f8659b = i2;
        if (!x0() || (iC = eVar.c()) == -1) {
            iN = 0;
            iN2 = 0;
        } else {
            if (this.f2830h == (iC < i2)) {
                iN = this.f2824a.n();
                iN2 = 0;
            } else {
                iN2 = this.f2824a.n();
                iN = 0;
            }
        }
        if (M()) {
            this.f2823a.f8662e = this.f2824a.m() - iN2;
            this.f2823a.f8663f = this.f2824a.i() + iN;
        } else {
            this.f2823a.f8663f = this.f2824a.h() + iN;
            this.f2823a.f8662e = -iN2;
        }
        androidx.recyclerview.widget.com2 com2Var2 = this.f2823a;
        com2Var2.f2865b = false;
        com2Var2.f2864a = true;
        if (this.f2824a.k() == 0 && this.f2824a.h() == 0) {
            z2 = true;
        }
        com2Var2.f2866c = z2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void P0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, View view, e2 e2Var) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof nul)) {
            super.O0(view, e2Var);
            return;
        }
        nul nulVar = (nul) layoutParams;
        if (this.f8622g == 0) {
            e2Var.W(e2.nul.a(nulVar.e(), nulVar.f8641c ? this.f8621f : 1, -1, -1, false, false));
        } else {
            e2Var.W(e2.nul.a(-1, -1, nulVar.e(), nulVar.f8641c ? this.f8621f : 1, false, false));
        }
    }

    public boolean P1() {
        int iP = this.f2828a[0].p(Integer.MIN_VALUE);
        for (int i2 = 1; i2 < this.f8621f; i2++) {
            if (this.f2828a[i2].p(Integer.MIN_VALUE) != iP) {
                return false;
            }
        }
        return true;
    }

    public void P2(int i2) {
        this.f8623h = i2 / this.f8621f;
        this.f8627l = View.MeasureSpec.makeMeasureSpec(i2, this.f8620b.k());
    }

    public final void Q1(View view, nul nulVar, androidx.recyclerview.widget.com2 com2Var) {
        if (com2Var.f8661d == 1) {
            if (nulVar.f8641c) {
                M1(view);
                return;
            } else {
                nulVar.f8640a.a(view);
                return;
            }
        }
        if (nulVar.f8641c) {
            z2(view);
        } else {
            nulVar.f8640a.u(view);
        }
    }

    public final void Q2(com2 com2Var, int i2, int i3) {
        int iJ = com2Var.j();
        if (i2 == -1) {
            if (com2Var.o() + iJ <= i3) {
                this.f2826a.set(com2Var.f8636d, false);
            }
        } else if (com2Var.k() - iJ >= i3) {
            this.f2826a.set(com2Var.f8636d, false);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void R0(RecyclerView recyclerView, int i2, int i3) {
        q2(i2, i3, 1);
    }

    public final int R1(int i2) {
        if (J() == 0) {
            return this.f2830h ? 1 : -1;
        }
        return (i2 < j2()) != this.f2830h ? -1 : 1;
    }

    public final int R2(int i2, int i3, int i4) {
        if (i3 == 0 && i4 == 0) {
            return i2;
        }
        int mode = View.MeasureSpec.getMode(i2);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - i3) - i4), mode) : i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void S0(RecyclerView recyclerView) {
        this.f2822a.b();
        t1();
    }

    public boolean S1() {
        int iJ2;
        int iK2;
        if (J() == 0 || this.f8626k == 0 || !r0()) {
            return false;
        }
        if (this.f2830h) {
            iJ2 = k2();
            iK2 = j2();
        } else {
            iJ2 = j2();
            iK2 = k2();
        }
        if (iJ2 == 0 && r2() != null) {
            this.f2822a.b();
            u1();
            t1();
            return true;
        }
        if (!this.f2833k) {
            return false;
        }
        int i2 = this.f2830h ? -1 : 1;
        int i3 = iK2 + 1;
        prn.aux auxVarE = this.f2822a.e(iJ2, i3, i2, true);
        if (auxVarE == null) {
            this.f2833k = false;
            this.f2822a.d(i3);
            return false;
        }
        prn.aux auxVarE2 = this.f2822a.e(iJ2, auxVarE.f8643a, i2 * (-1), true);
        if (auxVarE2 == null) {
            this.f2822a.d(auxVarE.f8643a);
        } else {
            this.f2822a.d(auxVarE2.f8643a + 1);
        }
        u1();
        t1();
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void T0(RecyclerView recyclerView, int i2, int i3, int i4) {
        q2(i2, i3, 8);
    }

    public final boolean T1(com2 com2Var) {
        if (this.f2830h) {
            if (com2Var.k() < this.f2824a.i()) {
                ArrayList<View> arrayList = com2Var.f2842a;
                return !com2Var.n(arrayList.get(arrayList.size() - 1)).f8641c;
            }
        } else if (com2Var.o() > this.f2824a.m()) {
            return !com2Var.n(com2Var.f2842a.get(0)).f8641c;
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void U0(RecyclerView recyclerView, int i2, int i3) {
        q2(i2, i3, 2);
    }

    public final int U1(RecyclerView.e eVar) {
        if (J() == 0) {
            return 0;
        }
        return com8.a(eVar, this.f2824a, e2(!this.f2834l), d2(!this.f2834l), this, this.f2834l);
    }

    public final int V1(RecyclerView.e eVar) {
        if (J() == 0) {
            return 0;
        }
        return com8.b(eVar, this.f2824a, e2(!this.f2834l), d2(!this.f2834l), this, this.f2834l, this.f2830h);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void W0(RecyclerView recyclerView, int i2, int i3, Object obj) {
        q2(i2, i3, 4);
    }

    public final int W1(RecyclerView.e eVar) {
        if (J() == 0) {
            return 0;
        }
        return com8.c(eVar, this.f2824a, e2(!this.f2834l), d2(!this.f2834l), this, this.f2834l);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void X0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        w2(lpt9Var, eVar, true);
    }

    public final int X1(int i2) {
        if (i2 == 1) {
            return (this.f8622g != 1 && t2()) ? 1 : -1;
        }
        if (i2 == 2) {
            return (this.f8622g != 1 && t2()) ? -1 : 1;
        }
        if (i2 == 17) {
            return this.f8622g == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i2 == 33) {
            return this.f8622g == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i2 != 66) {
            return (i2 == 130 && this.f8622g == 1) ? 1 : Integer.MIN_VALUE;
        }
        return this.f8622g == 0 ? 1 : Integer.MIN_VALUE;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void Y0(RecyclerView.e eVar) {
        super.Y0(eVar);
        this.f8624i = -1;
        this.f8625j = Integer.MIN_VALUE;
        this.f2820a = null;
        this.f2821a.c();
    }

    public final prn.aux Y1(int i2) {
        prn.aux auxVar = new prn.aux();
        auxVar.f2848a = new int[this.f8621f];
        for (int i3 = 0; i3 < this.f8621f; i3++) {
            auxVar.f2848a[i3] = i2 - this.f2828a[i3].l(i2);
        }
        return auxVar;
    }

    public final prn.aux Z1(int i2) {
        prn.aux auxVar = new prn.aux();
        auxVar.f2848a = new int[this.f8621f];
        for (int i3 = 0; i3 < this.f8621f; i3++) {
            auxVar.f2848a[i3] = this.f2828a[i3].p(i2) - i2;
        }
        return auxVar;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.d.con
    public PointF a(int i2) {
        int iR1 = R1(i2);
        PointF pointF = new PointF();
        if (iR1 == 0) {
            return null;
        }
        if (this.f8622g == 0) {
            pointF.x = iR1;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = iR1;
        }
        return pointF;
    }

    public final void a2() {
        this.f2824a = com5.b(this, this.f8622g);
        this.f8620b = com5.b(this, 1 - this.f8622g);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14 */
    /* JADX WARN: Type inference failed for: r0v15 */
    /* JADX WARN: Type inference failed for: r0v44 */
    /* JADX WARN: Type inference failed for: r16v0, types: [androidx.recyclerview.widget.RecyclerView$lpt2, androidx.recyclerview.widget.StaggeredGridLayoutManager] */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r9v7 */
    public final int b2(RecyclerView.lpt9 lpt9Var, androidx.recyclerview.widget.com2 com2Var, RecyclerView.e eVar) {
        int i2;
        int iL2;
        com2 com2VarP2;
        int iE;
        int i3;
        int iE2;
        int iE3;
        boolean z2;
        ?? r9 = 0;
        this.f2826a.set(0, this.f8621f, true);
        if (this.f2823a.f2866c) {
            i2 = com2Var.f8661d == 1 ? Preference.DEFAULT_ORDER : Integer.MIN_VALUE;
        } else {
            i2 = com2Var.f8661d == 1 ? com2Var.f8663f + com2Var.f8658a : com2Var.f8662e - com2Var.f8658a;
        }
        int i4 = i2;
        K2(com2Var.f8661d, i4);
        int i5 = this.f2830h ? this.f2824a.i() : this.f2824a.m();
        ?? r0 = false;
        while (com2Var.a(eVar) && (this.f2823a.f2866c || !this.f2826a.isEmpty())) {
            View viewB = com2Var.b(lpt9Var);
            nul nulVar = (nul) viewB.getLayoutParams();
            int iA = nulVar.a();
            int iG = this.f2822a.g(iA);
            ?? r3 = iG == -1 ? 1 : r9;
            if (r3 != 0) {
                com2VarP2 = nulVar.f8641c ? this.f2828a[r9] : p2(com2Var);
                this.f2822a.n(iA, com2VarP2);
            } else {
                com2VarP2 = this.f2828a[iG];
            }
            com2 com2Var2 = com2VarP2;
            nulVar.f8640a = com2Var2;
            if (com2Var.f8661d == 1) {
                d(viewB);
            } else {
                e(viewB, r9);
            }
            v2(viewB, nulVar, r9);
            if (com2Var.f8661d == 1) {
                int iL3 = nulVar.f8641c ? l2(i5) : com2Var2.l(i5);
                int iE4 = this.f2824a.e(viewB) + iL3;
                if (r3 != 0 && nulVar.f8641c) {
                    prn.aux auxVarY1 = Y1(iL3);
                    auxVarY1.f8644b = -1;
                    auxVarY1.f8643a = iA;
                    this.f2822a.a(auxVarY1);
                }
                i3 = iE4;
                iE = iL3;
            } else {
                int iO2 = nulVar.f8641c ? o2(i5) : com2Var2.p(i5);
                iE = iO2 - this.f2824a.e(viewB);
                if (r3 != 0 && nulVar.f8641c) {
                    prn.aux auxVarZ1 = Z1(iO2);
                    auxVarZ1.f8644b = 1;
                    auxVarZ1.f8643a = iA;
                    this.f2822a.a(auxVarZ1);
                }
                i3 = iO2;
            }
            if (nulVar.f8641c && com2Var.f8660c == -1) {
                if (r3 != 0) {
                    this.f2833k = true;
                } else {
                    if (!(com2Var.f8661d == 1 ? O1() : P1())) {
                        prn.aux auxVarF = this.f2822a.f(iA);
                        if (auxVarF != null) {
                            auxVarF.f2849b = true;
                        }
                        this.f2833k = true;
                    }
                }
            }
            Q1(viewB, nulVar, com2Var);
            if (t2() && this.f8622g == 1) {
                int i6 = nulVar.f8641c ? this.f8620b.i() : this.f8620b.i() - (((this.f8621f - 1) - com2Var2.f8636d) * this.f8623h);
                iE3 = i6;
                iE2 = i6 - this.f8620b.e(viewB);
            } else {
                int iM = nulVar.f8641c ? this.f8620b.m() : (com2Var2.f8636d * this.f8623h) + this.f8620b.m();
                iE2 = iM;
                iE3 = this.f8620b.e(viewB) + iM;
            }
            if (this.f8622g == 1) {
                z0(viewB, iE2, iE, iE3, i3);
            } else {
                z0(viewB, iE, iE2, i3, iE3);
            }
            if (nulVar.f8641c) {
                K2(this.f2823a.f8661d, i4);
            } else {
                Q2(com2Var2, this.f2823a.f8661d, i4);
            }
            A2(lpt9Var, this.f2823a);
            if (!this.f2823a.f2865b || !viewB.hasFocusable()) {
                z2 = false;
            } else if (nulVar.f8641c) {
                this.f2826a.clear();
                z2 = false;
            } else {
                z2 = false;
                this.f2826a.set(com2Var2.f8636d, false);
            }
            r9 = z2;
            r0 = true;
        }
        ?? r4 = r9;
        if (r0 == false) {
            A2(lpt9Var, this.f2823a);
        }
        if (this.f2823a.f8661d == -1) {
            iL2 = this.f2824a.m() - o2(this.f2824a.m());
        } else {
            iL2 = l2(this.f2824a.i()) - this.f2824a.i();
        }
        return iL2 > 0 ? Math.min(com2Var.f8658a, iL2) : r4 == true ? 1 : 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void c1(Parcelable parcelable) {
        if (parcelable instanceof com1) {
            this.f2820a = (com1) parcelable;
            t1();
        }
    }

    public final int c2(int i2) {
        int iJ = J();
        for (int i3 = 0; i3 < iJ; i3++) {
            int iH0 = h0(I(i3));
            if (iH0 >= 0 && iH0 < i2) {
                return iH0;
            }
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public Parcelable d1() {
        int iP;
        int iM;
        int[] iArr;
        if (this.f2820a != null) {
            return new com1(this.f2820a);
        }
        com1 com1Var = new com1();
        com1Var.f2837b = this.f2829g;
        com1Var.f2839c = this.f2831i;
        com1Var.f2840d = this.f2832j;
        prn prnVar = this.f2822a;
        if (prnVar == null || (iArr = prnVar.f2847a) == null) {
            com1Var.f8632d = 0;
        } else {
            com1Var.f2838b = iArr;
            com1Var.f8632d = iArr.length;
            com1Var.f2835a = prnVar.f8642a;
        }
        if (J() > 0) {
            com1Var.f8629a = this.f2831i ? k2() : j2();
            com1Var.f8630b = f2();
            int i2 = this.f8621f;
            com1Var.f8631c = i2;
            com1Var.f2836a = new int[i2];
            for (int i3 = 0; i3 < this.f8621f; i3++) {
                if (this.f2831i) {
                    iP = this.f2828a[i3].l(Integer.MIN_VALUE);
                    if (iP != Integer.MIN_VALUE) {
                        iM = this.f2824a.i();
                        iP -= iM;
                    }
                } else {
                    iP = this.f2828a[i3].p(Integer.MIN_VALUE);
                    if (iP != Integer.MIN_VALUE) {
                        iM = this.f2824a.m();
                        iP -= iM;
                    }
                }
                com1Var.f2836a[i3] = iP;
            }
        } else {
            com1Var.f8629a = -1;
            com1Var.f8630b = -1;
            com1Var.f8631c = 0;
        }
        return com1Var;
    }

    public View d2(boolean z2) {
        int iM = this.f2824a.m();
        int i2 = this.f2824a.i();
        View view = null;
        for (int iJ = J() - 1; iJ >= 0; iJ--) {
            View viewI = I(iJ);
            int iG = this.f2824a.g(viewI);
            int iD = this.f2824a.d(viewI);
            if (iD > iM && iG < i2) {
                if (iD <= i2 || !z2) {
                    return viewI;
                }
                if (view == null) {
                    view = viewI;
                }
            }
        }
        return view;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void e1(int i2) {
        if (i2 == 0) {
            S1();
        }
    }

    public View e2(boolean z2) {
        int iM = this.f2824a.m();
        int i2 = this.f2824a.i();
        int iJ = J();
        View view = null;
        for (int i3 = 0; i3 < iJ; i3++) {
            View viewI = I(i3);
            int iG = this.f2824a.g(viewI);
            if (this.f2824a.d(viewI) > iM && iG < i2) {
                if (iG >= iM || !z2) {
                    return viewI;
                }
                if (view == null) {
                    view = viewI;
                }
            }
        }
        return view;
    }

    public int f2() {
        View viewD2 = this.f2830h ? d2(true) : e2(true);
        if (viewD2 == null) {
            return -1;
        }
        return h0(viewD2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void g(String str) {
        if (this.f2820a == null) {
            super.g(str);
        }
    }

    public final int g2(int i2) {
        for (int iJ = J() - 1; iJ >= 0; iJ--) {
            int iH0 = h0(I(iJ));
            if (iH0 >= 0 && iH0 < i2) {
                return iH0;
            }
        }
        return 0;
    }

    public final void h2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, boolean z2) {
        int i2;
        int iL2 = l2(Integer.MIN_VALUE);
        if (iL2 != Integer.MIN_VALUE && (i2 = this.f2824a.i() - iL2) > 0) {
            int i3 = i2 - (-F2(-i2, lpt9Var, eVar));
            if (!z2 || i3 <= 0) {
                return;
            }
            this.f2824a.r(i3);
        }
    }

    public final void i2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, boolean z2) {
        int iM;
        int iO2 = o2(Preference.DEFAULT_ORDER);
        if (iO2 != Integer.MAX_VALUE && (iM = iO2 - this.f2824a.m()) > 0) {
            int iF2 = iM - F2(iM, lpt9Var, eVar);
            if (!z2 || iF2 <= 0) {
                return;
            }
            this.f2824a.r(-iF2);
        }
    }

    public int j2() {
        if (J() == 0) {
            return 0;
        }
        return h0(I(0));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean k() {
        return this.f8622g == 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int k0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return this.f8622g == 0 ? this.f8621f : super.k0(lpt9Var, eVar);
    }

    public int k2() {
        int iJ = J();
        if (iJ == 0) {
            return 0;
        }
        return h0(I(iJ - 1));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean l() {
        return this.f8622g == 1;
    }

    public final int l2(int i2) {
        int iL = this.f2828a[0].l(i2);
        for (int i3 = 1; i3 < this.f8621f; i3++) {
            int iL2 = this.f2828a[i3].l(i2);
            if (iL2 > iL) {
                iL = iL2;
            }
        }
        return iL;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean m(RecyclerView.lpt3 lpt3Var) {
        return lpt3Var instanceof nul;
    }

    public final int m2(int i2) {
        int iP = this.f2828a[0].p(i2);
        for (int i3 = 1; i3 < this.f8621f; i3++) {
            int iP2 = this.f2828a[i3].p(i2);
            if (iP2 > iP) {
                iP = iP2;
            }
        }
        return iP;
    }

    public final int n2(int i2) {
        int iL = this.f2828a[0].l(i2);
        for (int i3 = 1; i3 < this.f8621f; i3++) {
            int iL2 = this.f2828a[i3].l(i2);
            if (iL2 < iL) {
                iL = iL2;
            }
        }
        return iL;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void o(int i2, int i3, RecyclerView.e eVar, RecyclerView.lpt2.nul nulVar) {
        int iL;
        int iP;
        if (this.f8622g != 0) {
            i2 = i3;
        }
        if (J() == 0 || i2 == 0) {
            return;
        }
        y2(i2, eVar);
        int[] iArr = this.f2827a;
        if (iArr == null || iArr.length < this.f8621f) {
            this.f2827a = new int[this.f8621f];
        }
        int i4 = 0;
        for (int i5 = 0; i5 < this.f8621f; i5++) {
            androidx.recyclerview.widget.com2 com2Var = this.f2823a;
            if (com2Var.f8660c == -1) {
                iL = com2Var.f8662e;
                iP = this.f2828a[i5].p(iL);
            } else {
                iL = this.f2828a[i5].l(com2Var.f8663f);
                iP = this.f2823a.f8663f;
            }
            int i6 = iL - iP;
            if (i6 >= 0) {
                this.f2827a[i4] = i6;
                i4++;
            }
        }
        Arrays.sort(this.f2827a, 0, i4);
        for (int i7 = 0; i7 < i4 && this.f2823a.a(eVar); i7++) {
            nulVar.a(this.f2823a.f8659b, this.f2827a[i7]);
            androidx.recyclerview.widget.com2 com2Var2 = this.f2823a;
            com2Var2.f8659b += com2Var2.f8660c;
        }
    }

    public final int o2(int i2) {
        int iP = this.f2828a[0].p(i2);
        for (int i3 = 1; i3 < this.f8621f; i3++) {
            int iP2 = this.f2828a[i3].p(i2);
            if (iP2 < iP) {
                iP = iP2;
            }
        }
        return iP;
    }

    public final com2 p2(androidx.recyclerview.widget.com2 com2Var) {
        int i2;
        int i3;
        int i4;
        if (x2(com2Var.f8661d)) {
            i3 = this.f8621f - 1;
            i2 = -1;
            i4 = -1;
        } else {
            i2 = this.f8621f;
            i3 = 0;
            i4 = 1;
        }
        com2 com2Var2 = null;
        if (com2Var.f8661d == 1) {
            int iM = this.f2824a.m();
            int i5 = Preference.DEFAULT_ORDER;
            while (i3 != i2) {
                com2 com2Var3 = this.f2828a[i3];
                int iL = com2Var3.l(iM);
                if (iL < i5) {
                    com2Var2 = com2Var3;
                    i5 = iL;
                }
                i3 += i4;
            }
            return com2Var2;
        }
        int i6 = this.f2824a.i();
        int i7 = Integer.MIN_VALUE;
        while (i3 != i2) {
            com2 com2Var4 = this.f2828a[i3];
            int iP = com2Var4.p(i6);
            if (iP > i7) {
                com2Var2 = com2Var4;
                i7 = iP;
            }
            i3 += i4;
        }
        return com2Var2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int q(RecyclerView.e eVar) {
        return U1(eVar);
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0025  */
    /* JADX WARN: Code duplicated, block: B:17:0x0028 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:19:0x002b  */
    /* JADX WARN: Code duplicated, block: B:20:0x0036  */
    /* JADX WARN: Code duplicated, block: B:21:0x003c  */
    /* JADX WARN: Code duplicated, block: B:23:0x0043 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:24:0x0044  */
    /* JADX WARN: Code duplicated, block: B:26:0x0048  */
    /* JADX WARN: Code duplicated, block: B:27:0x004d  */
    /* JADX WARN: Code duplicated, block: B:29:0x0053  */
    /* JADX WARN: Code duplicated, block: B:31:? A[RETURN, SYNTHETIC] */
    public final void q2(int i2, int i3, int i4) {
        int i5;
        int i6;
        int iK2;
        int iK3 = this.f2830h ? k2() : j2();
        if (i4 == 8) {
            if (i2 < i3) {
                i5 = i3 + 1;
            } else {
                i5 = i2 + 1;
                i6 = i3;
            }
            this.f2822a.h(i6);
            if (i4 != 1) {
                this.f2822a.j(i2, i3);
            } else if (i4 != 2) {
                this.f2822a.k(i2, i3);
            } else if (i4 == 8) {
                this.f2822a.k(i2, 1);
                this.f2822a.j(i3, 1);
            }
            if (i5 <= iK3) {
                return;
            }
            if (this.f2830h) {
                iK2 = j2();
            } else {
                iK2 = k2();
            }
            if (i6 <= iK2) {
                t1();
            }
        }
        i5 = i2 + i3;
        i6 = i2;
        this.f2822a.h(i6);
        if (i4 != 1) {
            this.f2822a.j(i2, i3);
        } else if (i4 != 2) {
            this.f2822a.k(i2, i3);
        } else if (i4 == 8) {
            this.f2822a.k(i2, 1);
            this.f2822a.j(i3, 1);
        }
        if (i5 <= iK3) {
            return;
        }
        if (this.f2830h) {
            iK2 = j2();
        } else {
            iK2 = k2();
        }
        if (i6 <= iK2) {
            t1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int r(RecyclerView.e eVar) {
        return V1(eVar);
    }

    /* JADX WARN: Code duplicated, block: B:37:0x0088  */
    /* JADX WARN: Code duplicated, block: B:38:0x008a  */
    public View r2() {
        int i2;
        int i3;
        boolean z2;
        int iJ = J() - 1;
        BitSet bitSet = new BitSet(this.f8621f);
        bitSet.set(0, this.f8621f, true);
        byte b2 = (this.f8622g == 1 && t2()) ? (byte) 1 : (byte) -1;
        if (this.f2830h) {
            i2 = -1;
        } else {
            i2 = iJ + 1;
            iJ = 0;
        }
        int i4 = iJ < i2 ? 1 : -1;
        while (iJ != i2) {
            View viewI = I(iJ);
            nul nulVar = (nul) viewI.getLayoutParams();
            if (bitSet.get(nulVar.f8640a.f8636d)) {
                if (T1(nulVar.f8640a)) {
                    return viewI;
                }
                bitSet.clear(nulVar.f8640a.f8636d);
            }
            if (!nulVar.f8641c && (i3 = iJ + i4) != i2) {
                View viewI2 = I(i3);
                if (this.f2830h) {
                    int iD = this.f2824a.d(viewI);
                    int iD2 = this.f2824a.d(viewI2);
                    if (iD < iD2) {
                        return viewI;
                    }
                    if (iD == iD2) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                } else {
                    int iG = this.f2824a.g(viewI);
                    int iG2 = this.f2824a.g(viewI2);
                    if (iG > iG2) {
                        return viewI;
                    }
                    if (iG == iG2) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                }
                if (z2) {
                    if ((nulVar.f8640a.f8636d - ((nul) viewI2.getLayoutParams()).f8640a.f8636d < 0) != (b2 < 0)) {
                        return viewI;
                    }
                } else {
                    continue;
                }
            }
            iJ += i4;
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int s(RecyclerView.e eVar) {
        return W1(eVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean s0() {
        return this.f8626k != 0;
    }

    public void s2() {
        this.f2822a.b();
        t1();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int t(RecyclerView.e eVar) {
        return U1(eVar);
    }

    public boolean t2() {
        return Z() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int u(RecyclerView.e eVar) {
        return V1(eVar);
    }

    public final void u2(View view, int i2, int i3, boolean z2) {
        j(view, this.f8619a);
        nul nulVar = (nul) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) nulVar).leftMargin;
        Rect rect = this.f8619a;
        int iR2 = R2(i2, i4 + rect.left, ((ViewGroup.MarginLayoutParams) nulVar).rightMargin + rect.right);
        int i5 = ((ViewGroup.MarginLayoutParams) nulVar).topMargin;
        Rect rect2 = this.f8619a;
        int iR3 = R2(i3, i5 + rect2.top, ((ViewGroup.MarginLayoutParams) nulVar).bottomMargin + rect2.bottom);
        if (z2 ? H1(view, iR2, iR3, nulVar) : F1(view, iR2, iR3, nulVar)) {
            view.measure(iR2, iR3);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int v(RecyclerView.e eVar) {
        return W1(eVar);
    }

    public final void v2(View view, nul nulVar, boolean z2) {
        if (nulVar.f8641c) {
            if (this.f8622g == 1) {
                u2(view, this.f8627l, RecyclerView.lpt2.K(W(), X(), g0() + d0(), ((ViewGroup.MarginLayoutParams) nulVar).height, true), z2);
                return;
            } else {
                u2(view, RecyclerView.lpt2.K(o0(), p0(), e0() + f0(), ((ViewGroup.MarginLayoutParams) nulVar).width, true), this.f8627l, z2);
                return;
            }
        }
        if (this.f8622g == 1) {
            u2(view, RecyclerView.lpt2.K(this.f8623h, p0(), 0, ((ViewGroup.MarginLayoutParams) nulVar).width, false), RecyclerView.lpt2.K(W(), X(), g0() + d0(), ((ViewGroup.MarginLayoutParams) nulVar).height, true), z2);
        } else {
            u2(view, RecyclerView.lpt2.K(o0(), p0(), e0() + f0(), ((ViewGroup.MarginLayoutParams) nulVar).width, true), RecyclerView.lpt2.K(this.f8623h, X(), 0, ((ViewGroup.MarginLayoutParams) nulVar).height, false), z2);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int w1(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return F2(i2, lpt9Var, eVar);
    }

    /* JADX WARN: Code duplicated, block: B:89:0x015a  */
    public final void w2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, boolean z2) {
        boolean z3;
        com1 com1Var;
        con conVar = this.f2821a;
        if (!(this.f2820a == null && this.f8624i == -1) && eVar.b() == 0) {
            k1(lpt9Var);
            conVar.c();
            return;
        }
        boolean z4 = (conVar.f8639c && this.f8624i == -1 && this.f2820a == null) ? false : true;
        if (z4) {
            conVar.c();
            if (this.f2820a != null) {
                N1(conVar);
            } else {
                E2();
                conVar.f2844a = this.f2830h;
            }
            N2(eVar, conVar);
            conVar.f8639c = true;
        }
        if (this.f2820a == null && this.f8624i == -1 && (conVar.f2844a != this.f2831i || t2() != this.f2832j)) {
            this.f2822a.b();
            conVar.f2846b = true;
        }
        if (J() > 0 && ((com1Var = this.f2820a) == null || com1Var.f8631c < 1)) {
            if (conVar.f2846b) {
                for (int i2 = 0; i2 < this.f8621f; i2++) {
                    this.f2828a[i2].e();
                    int i3 = conVar.f8638b;
                    if (i3 != Integer.MIN_VALUE) {
                        this.f2828a[i2].v(i3);
                    }
                }
            } else if (z4 || this.f2821a.f2845a == null) {
                for (int i4 = 0; i4 < this.f8621f; i4++) {
                    this.f2828a[i4].b(this.f2830h, conVar.f8638b);
                }
                this.f2821a.d(this.f2828a);
            } else {
                for (int i5 = 0; i5 < this.f8621f; i5++) {
                    com2 com2Var = this.f2828a[i5];
                    com2Var.e();
                    com2Var.v(this.f2821a.f2845a[i5]);
                }
            }
        }
        w(lpt9Var);
        this.f2823a.f2864a = false;
        this.f2833k = false;
        P2(this.f8620b.n());
        O2(conVar.f8637a, eVar);
        if (conVar.f2844a) {
            G2(-1);
            b2(lpt9Var, this.f2823a, eVar);
            G2(1);
            androidx.recyclerview.widget.com2 com2Var2 = this.f2823a;
            com2Var2.f8659b = conVar.f8637a + com2Var2.f8660c;
            b2(lpt9Var, com2Var2, eVar);
        } else {
            G2(1);
            b2(lpt9Var, this.f2823a, eVar);
            G2(-1);
            androidx.recyclerview.widget.com2 com2Var3 = this.f2823a;
            com2Var3.f8659b = conVar.f8637a + com2Var3.f8660c;
            b2(lpt9Var, com2Var3, eVar);
        }
        D2();
        if (J() > 0) {
            if (this.f2830h) {
                h2(lpt9Var, eVar, true);
                i2(lpt9Var, eVar, false);
            } else {
                i2(lpt9Var, eVar, true);
                h2(lpt9Var, eVar, false);
            }
        }
        if (z2 && !eVar.e()) {
            if (this.f8626k != 0 && J() > 0 && (this.f2833k || r2() != null)) {
                o1(this.f2825a);
                z3 = S1();
            }
        }
        if (eVar.e()) {
            this.f2821a.c();
        }
        this.f2831i = conVar.f2844a;
        this.f2832j = t2();
        if (z3) {
            this.f2821a.c();
            w2(lpt9Var, eVar, false);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void x1(int i2) {
        com1 com1Var = this.f2820a;
        if (com1Var != null && com1Var.f8629a != i2) {
            com1Var.k();
        }
        this.f8624i = i2;
        this.f8625j = Integer.MIN_VALUE;
        t1();
    }

    public final boolean x2(int i2) {
        if (this.f8622g == 0) {
            return (i2 == -1) != this.f2830h;
        }
        return ((i2 == -1) == this.f2830h) == t2();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int y1(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return F2(i2, lpt9Var, eVar);
    }

    public void y2(int i2, RecyclerView.e eVar) {
        int iJ2;
        int i3;
        if (i2 > 0) {
            iJ2 = k2();
            i3 = 1;
        } else {
            iJ2 = j2();
            i3 = -1;
        }
        this.f2823a.f2864a = true;
        O2(iJ2, eVar);
        G2(i3);
        androidx.recyclerview.widget.com2 com2Var = this.f2823a;
        com2Var.f8659b = iJ2 + com2Var.f8660c;
        com2Var.f8658a = Math.abs(i2);
    }

    public final void z2(View view) {
        for (int i2 = this.f8621f - 1; i2 >= 0; i2--) {
            this.f2828a[i2].u(view);
        }
    }

    public static class prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public List<aux> f8642a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int[] f2847a;

        public void a(aux auxVar) {
            if (this.f8642a == null) {
                this.f8642a = new ArrayList();
            }
            int size = this.f8642a.size();
            for (int i2 = 0; i2 < size; i2++) {
                aux auxVar2 = this.f8642a.get(i2);
                if (auxVar2.f8643a == auxVar.f8643a) {
                    this.f8642a.remove(i2);
                }
                if (auxVar2.f8643a >= auxVar.f8643a) {
                    this.f8642a.add(i2, auxVar);
                    return;
                }
            }
            this.f8642a.add(auxVar);
        }

        public void b() {
            int[] iArr = this.f2847a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f8642a = null;
        }

        public void c(int i2) {
            int[] iArr = this.f2847a;
            if (iArr == null) {
                int[] iArr2 = new int[Math.max(i2, 10) + 1];
                this.f2847a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i2 >= iArr.length) {
                int[] iArr3 = new int[o(i2)];
                this.f2847a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.f2847a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        public int d(int i2) {
            List<aux> list = this.f8642a;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    if (this.f8642a.get(size).f8643a >= i2) {
                        this.f8642a.remove(size);
                    }
                }
            }
            return h(i2);
        }

        public aux e(int i2, int i3, int i4, boolean z2) {
            List<aux> list = this.f8642a;
            if (list == null) {
                return null;
            }
            int size = list.size();
            for (int i5 = 0; i5 < size; i5++) {
                aux auxVar = this.f8642a.get(i5);
                int i6 = auxVar.f8643a;
                if (i6 >= i3) {
                    return null;
                }
                if (i6 >= i2 && (i4 == 0 || auxVar.f8644b == i4 || (z2 && auxVar.f2849b))) {
                    return auxVar;
                }
            }
            return null;
        }

        public aux f(int i2) {
            List<aux> list = this.f8642a;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                aux auxVar = this.f8642a.get(size);
                if (auxVar.f8643a == i2) {
                    return auxVar;
                }
            }
            return null;
        }

        public int g(int i2) {
            int[] iArr = this.f2847a;
            if (iArr == null || i2 >= iArr.length) {
                return -1;
            }
            return iArr[i2];
        }

        public int h(int i2) {
            int[] iArr = this.f2847a;
            if (iArr == null || i2 >= iArr.length) {
                return -1;
            }
            int i3 = i(i2);
            if (i3 == -1) {
                int[] iArr2 = this.f2847a;
                Arrays.fill(iArr2, i2, iArr2.length, -1);
                return this.f2847a.length;
            }
            int i4 = i3 + 1;
            Arrays.fill(this.f2847a, i2, i4, -1);
            return i4;
        }

        public final int i(int i2) {
            if (this.f8642a == null) {
                return -1;
            }
            aux auxVarF = f(i2);
            if (auxVarF != null) {
                this.f8642a.remove(auxVarF);
            }
            int size = this.f8642a.size();
            int i3 = 0;
            while (true) {
                if (i3 >= size) {
                    i3 = -1;
                    break;
                }
                if (this.f8642a.get(i3).f8643a >= i2) {
                    break;
                }
                i3++;
            }
            if (i3 == -1) {
                return -1;
            }
            aux auxVar = this.f8642a.get(i3);
            this.f8642a.remove(i3);
            return auxVar.f8643a;
        }

        public void j(int i2, int i3) {
            int[] iArr = this.f2847a;
            if (iArr == null || i2 >= iArr.length) {
                return;
            }
            int i4 = i2 + i3;
            c(i4);
            int[] iArr2 = this.f2847a;
            System.arraycopy(iArr2, i2, iArr2, i4, (iArr2.length - i2) - i3);
            Arrays.fill(this.f2847a, i2, i4, -1);
            l(i2, i3);
        }

        public void k(int i2, int i3) {
            int[] iArr = this.f2847a;
            if (iArr == null || i2 >= iArr.length) {
                return;
            }
            int i4 = i2 + i3;
            c(i4);
            int[] iArr2 = this.f2847a;
            System.arraycopy(iArr2, i4, iArr2, i2, (iArr2.length - i2) - i3);
            int[] iArr3 = this.f2847a;
            Arrays.fill(iArr3, iArr3.length - i3, iArr3.length, -1);
            m(i2, i3);
        }

        public final void l(int i2, int i3) {
            List<aux> list = this.f8642a;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                aux auxVar = this.f8642a.get(size);
                int i4 = auxVar.f8643a;
                if (i4 >= i2) {
                    auxVar.f8643a = i4 + i3;
                }
            }
        }

        public final void m(int i2, int i3) {
            List<aux> list = this.f8642a;
            if (list == null) {
                return;
            }
            int i4 = i2 + i3;
            for (int size = list.size() - 1; size >= 0; size--) {
                aux auxVar = this.f8642a.get(size);
                int i5 = auxVar.f8643a;
                if (i5 >= i2) {
                    if (i5 < i4) {
                        this.f8642a.remove(size);
                    } else {
                        auxVar.f8643a = i5 - i3;
                    }
                }
            }
        }

        public void n(int i2, com2 com2Var) {
            c(i2);
            this.f2847a[i2] = com2Var.f8636d;
        }

        public int o(int i2) {
            int length = this.f2847a.length;
            while (length <= i2) {
                length *= 2;
            }
            return length;
        }

        @SuppressLint({"BanParcelableUsage"})
        public static class aux implements Parcelable {
            public static final Parcelable.Creator<aux> CREATOR = new C0045aux();

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public int f8643a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public int[] f2848a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public int f8644b;

            /* JADX INFO: renamed from: b, reason: collision with other field name */
            public boolean f2849b;

            /* JADX INFO: renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$prn$aux$aux, reason: collision with other inner class name */
            public static class C0045aux implements Parcelable.Creator<aux> {
                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public aux createFromParcel(Parcel parcel) {
                    return new aux(parcel);
                }

                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
                public aux[] newArray(int i2) {
                    return new aux[i2];
                }
            }

            public aux(Parcel parcel) {
                this.f8643a = parcel.readInt();
                this.f8644b = parcel.readInt();
                this.f2849b = parcel.readInt() == 1;
                int i2 = parcel.readInt();
                if (i2 > 0) {
                    int[] iArr = new int[i2];
                    this.f2848a = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            public int k(int i2) {
                int[] iArr = this.f2848a;
                if (iArr == null) {
                    return 0;
                }
                return iArr[i2];
            }

            public String toString() {
                return "FullSpanItem{mPosition=" + this.f8643a + ", mGapDir=" + this.f8644b + ", mHasUnwantedGapAfter=" + this.f2849b + ", mGapPerSpan=" + Arrays.toString(this.f2848a) + '}';
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i2) {
                parcel.writeInt(this.f8643a);
                parcel.writeInt(this.f8644b);
                parcel.writeInt(this.f2849b ? 1 : 0);
                int[] iArr = this.f2848a;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                } else {
                    parcel.writeInt(iArr.length);
                    parcel.writeIntArray(this.f2848a);
                }
            }

            public aux() {
            }
        }
    }
}
