package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public final class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static aux f8387a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<Class<?>, C0038aux> f2605a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Map<Class<?>, Boolean> f8388b = new HashMap();

    /* JADX INFO: renamed from: androidx.lifecycle.aux$aux, reason: collision with other inner class name */
    @Deprecated
    public static class C0038aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Map<nul.con, List<con>> f8389a = new HashMap();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final Map<con, nul.con> f8390b;

        public C0038aux(Map<con, nul.con> map) {
            this.f8390b = map;
            for (Map.Entry<con, nul.con> entry : map.entrySet()) {
                nul.con value = entry.getValue();
                List<con> arrayList = this.f8389a.get(value);
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                    this.f8389a.put(value, arrayList);
                }
                arrayList.add(entry.getKey());
            }
        }

        public static void b(List<con> list, COM3.com7 com7Var, nul.con conVar, Object obj) {
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    list.get(size).a(com7Var, conVar, obj);
                }
            }
        }

        public void a(COM3.com7 com7Var, nul.con conVar, Object obj) {
            b(this.f8389a.get(conVar), com7Var, conVar, obj);
            b(this.f8389a.get(nul.con.ON_ANY), com7Var, conVar, obj);
        }
    }

    @Deprecated
    public static final class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f8391a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Method f2606a;

        public con(int i2, Method method) {
            this.f8391a = i2;
            this.f2606a = method;
            method.setAccessible(true);
        }

        public void a(COM3.com7 com7Var, nul.con conVar, Object obj) {
            try {
                int i2 = this.f8391a;
                if (i2 == 0) {
                    this.f2606a.invoke(obj, new Object[0]);
                } else if (i2 == 1) {
                    this.f2606a.invoke(obj, com7Var);
                } else {
                    if (i2 != 2) {
                        return;
                    }
                    this.f2606a.invoke(obj, com7Var, conVar);
                }
            } catch (IllegalAccessException e2) {
                throw new RuntimeException(e2);
            } catch (InvocationTargetException e3) {
                throw new RuntimeException("Failed to call observer method", e3.getCause());
            }
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof con)) {
                return false;
            }
            con conVar = (con) obj;
            return this.f8391a == conVar.f8391a && this.f2606a.getName().equals(conVar.f2606a.getName());
        }

        public int hashCode() {
            return (this.f8391a * 31) + this.f2606a.getName().hashCode();
        }
    }

    public final C0038aux a(Class<?> cls, Method[] methodArr) {
        int i2;
        C0038aux c0038auxC;
        Class<? super Object> superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        if (superclass != null && (c0038auxC = c(superclass)) != null) {
            map.putAll(c0038auxC.f8390b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            for (Map.Entry<con, nul.con> entry : c(cls2).f8390b.entrySet()) {
                e(map, entry.getKey(), entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            methodArr = b(cls);
        }
        boolean z2 = false;
        for (Method method : methodArr) {
            com3 com3Var = (com3) method.getAnnotation(com3.class);
            if (com3Var != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i2 = 0;
                } else {
                    if (!parameterTypes[0].isAssignableFrom(COM3.com7.class)) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i2 = 1;
                }
                nul.con conVarValue = com3Var.value();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(nul.con.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (conVarValue != nul.con.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i2 = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                e(map, new con(i2, method), conVarValue, cls);
                z2 = true;
            }
        }
        C0038aux c0038aux = new C0038aux(map);
        this.f2605a.put(cls, c0038aux);
        this.f8388b.put(cls, Boolean.valueOf(z2));
        return c0038aux;
    }

    public final Method[] b(Class<?> cls) {
        try {
            return cls.getDeclaredMethods();
        } catch (NoClassDefFoundError e2) {
            throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e2);
        }
    }

    public C0038aux c(Class<?> cls) {
        C0038aux c0038aux = this.f2605a.get(cls);
        return c0038aux != null ? c0038aux : a(cls, null);
    }

    public boolean d(Class<?> cls) {
        Boolean bool = this.f8388b.get(cls);
        if (bool != null) {
            return bool.booleanValue();
        }
        Method[] methodArrB = b(cls);
        for (Method method : methodArrB) {
            if (((com3) method.getAnnotation(com3.class)) != null) {
                a(cls, methodArrB);
                return true;
            }
        }
        this.f8388b.put(cls, Boolean.FALSE);
        return false;
    }

    public final void e(Map<con, nul.con> map, con conVar, nul.con conVar2, Class<?> cls) {
        nul.con conVar3 = map.get(conVar);
        if (conVar3 == null || conVar2 == conVar3) {
            if (conVar3 == null) {
                map.put(conVar, conVar2);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + conVar.f2606a.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + conVar3 + ", new value " + conVar2);
    }
}
