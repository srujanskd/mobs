package COM3;

/* JADX INFO: loaded from: classes.dex */
public final class com2 {
    public static final /* synthetic */ nul a(com2 com2Var) {
        throw null;
    }

    public static final /* synthetic */ androidx.lifecycle.nul.EnumC0039nul b(com2 com2Var) {
        throw null;
    }
}
