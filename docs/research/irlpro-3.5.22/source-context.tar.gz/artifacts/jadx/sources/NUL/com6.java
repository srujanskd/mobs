package NUL;

import p146nUL.p;
import p146nUL.r;

/* JADX INFO: loaded from: classes.dex */
public class com6 extends lpt3 {
    public com6(p pVar) {
        super(pVar);
        pVar.f4937a.f();
        pVar.f4938a.f();
        ((lpt3) this).f7408b = ((r) pVar).p1();
    }

    @Override // NUL.lpt3, NUL.prn
    public void a(prn prnVar) {
        com2 com2Var = ((lpt3) this).f1380a;
        if (com2Var.f1361b && !com2Var.f1362c) {
            ((lpt3) this).f1380a.d((int) ((com2Var.f1360b.get(0).f7365b * ((r) ((lpt3) this).f1385a).s1()) + 0.5f));
        }
    }

    @Override // NUL.lpt3
    public void d() {
        r rVar = (r) ((lpt3) this).f1385a;
        int iQ1 = rVar.q1();
        int iR1 = rVar.r1();
        rVar.s1();
        if (rVar.p1() == 1) {
            if (iQ1 != -1) {
                ((lpt3) this).f1380a.f1360b.add(((lpt3) ((lpt3) this).f1385a.f4945a.f4937a).f1380a);
                ((lpt3) ((lpt3) this).f1385a.f4945a.f4937a).f1380a.f1358a.add(((lpt3) this).f1380a);
                ((lpt3) this).f1380a.f7364a = iQ1;
            } else if (iR1 != -1) {
                ((lpt3) this).f1380a.f1360b.add(((lpt3) ((lpt3) this).f1385a.f4945a.f4937a).f1387b);
                ((lpt3) ((lpt3) this).f1385a.f4945a.f4937a).f1387b.f1358a.add(((lpt3) this).f1380a);
                ((lpt3) this).f1380a.f7364a = -iR1;
            } else {
                com2 com2Var = ((lpt3) this).f1380a;
                com2Var.f1359a = true;
                com2Var.f1360b.add(((lpt3) ((lpt3) this).f1385a.f4945a.f4937a).f1387b);
                ((lpt3) ((lpt3) this).f1385a.f4945a.f4937a).f1387b.f1358a.add(((lpt3) this).f1380a);
            }
            q(((lpt3) ((lpt3) this).f1385a.f4937a).f1380a);
            q(((lpt3) ((lpt3) this).f1385a.f4937a).f1387b);
            return;
        }
        if (iQ1 != -1) {
            ((lpt3) this).f1380a.f1360b.add(((lpt3) ((lpt3) this).f1385a.f4945a.f4938a).f1380a);
            ((lpt3) ((lpt3) this).f1385a.f4945a.f4938a).f1380a.f1358a.add(((lpt3) this).f1380a);
            ((lpt3) this).f1380a.f7364a = iQ1;
        } else if (iR1 != -1) {
            ((lpt3) this).f1380a.f1360b.add(((lpt3) ((lpt3) this).f1385a.f4945a.f4938a).f1387b);
            ((lpt3) ((lpt3) this).f1385a.f4945a.f4938a).f1387b.f1358a.add(((lpt3) this).f1380a);
            ((lpt3) this).f1380a.f7364a = -iR1;
        } else {
            com2 com2Var2 = ((lpt3) this).f1380a;
            com2Var2.f1359a = true;
            com2Var2.f1360b.add(((lpt3) ((lpt3) this).f1385a.f4945a.f4938a).f1387b);
            ((lpt3) ((lpt3) this).f1385a.f4945a.f4938a).f1387b.f1358a.add(((lpt3) this).f1380a);
        }
        q(((lpt3) ((lpt3) this).f1385a.f4938a).f1380a);
        q(((lpt3) ((lpt3) this).f1385a.f4938a).f1387b);
    }

    @Override // NUL.lpt3
    public void e() {
        if (((r) ((lpt3) this).f1385a).p1() == 1) {
            ((lpt3) this).f1385a.j1(((lpt3) this).f1380a.f7365b);
        } else {
            ((lpt3) this).f1385a.k1(((lpt3) this).f1380a.f7365b);
        }
    }

    @Override // NUL.lpt3
    public void f() {
        ((lpt3) this).f1380a.c();
    }

    @Override // NUL.lpt3
    public boolean m() {
        return false;
    }

    public final void q(com2 com2Var) {
        ((lpt3) this).f1380a.f1358a.add(com2Var);
        com2Var.f1360b.add(((lpt3) this).f1380a);
    }
}
