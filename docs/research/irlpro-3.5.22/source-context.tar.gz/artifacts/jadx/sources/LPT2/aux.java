package LPT2;

import com.newrelic.agent.android.api.v1.Defaults;
import inet.ipaddr.com4;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import p052Lpt2.lpt2;
import p113lPT4.lpt4;
import p120lPt2.g;

/* JADX INFO: loaded from: classes.dex */
public class aux implements Closeable {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f838a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Reader f839a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f840a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f842a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String[] f843a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int[] f845b;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f6604f;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f844b = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final char[] f841a = new char[Defaults.RESPONSE_BODY_LIMIT];

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f6599a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f6600b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f6601c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f6602d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f6603e = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f6605g = 0 + 1;

    /* JADX INFO: renamed from: LPT2.aux$aux, reason: collision with other inner class name */
    public class C0014aux extends lpt2 {
        @Override // p052Lpt2.lpt2
        public void a(aux auxVar) throws IOException {
            if (auxVar instanceof g) {
                ((g) auxVar).r0();
                return;
            }
            int iL = auxVar.f6603e;
            if (iL == 0) {
                iL = auxVar.l();
            }
            if (iL == 13) {
                auxVar.f6603e = 9;
                return;
            }
            if (iL == 12) {
                auxVar.f6603e = 8;
                return;
            }
            if (iL == 14) {
                auxVar.f6603e = 10;
                return;
            }
            throw new IllegalStateException("Expected a name but was " + auxVar.b0() + auxVar.H());
        }
    }

    static {
        lpt2.f7292a = new C0014aux();
    }

    public aux(Reader reader) {
        int[] iArr = new int[32];
        this.f842a = iArr;
        iArr[0] = 6;
        this.f843a = new String[32];
        this.f845b = new int[32];
        if (reader == null) {
            throw new NullPointerException("in == null");
        }
        this.f839a = reader;
    }

    public String C() {
        return y(true);
    }

    public boolean E() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        return (iL == 2 || iL == 4 || iL == 17) ? false : true;
    }

    public final boolean F() {
        return this.f844b;
    }

    public final boolean G(char c2) throws IOException {
        if (c2 == '\t' || c2 == '\n' || c2 == '\f' || c2 == '\r' || c2 == ' ') {
            return false;
        }
        if (c2 != '#') {
            if (c2 == ',') {
                return false;
            }
            if (c2 != '/' && c2 != '=') {
                if (c2 == '{' || c2 == '}' || c2 == ':') {
                    return false;
                }
                if (c2 != ';') {
                    switch (c2) {
                        case lpt4.AppCompatTheme_radioButtonStyle /* 91 */:
                        case lpt4.AppCompatTheme_ratingBarStyleIndicator /* 93 */:
                            return false;
                        case lpt4.AppCompatTheme_ratingBarStyle /* 92 */:
                            break;
                        default:
                            return true;
                    }
                }
            }
        }
        d();
        return false;
    }

    public String H() {
        return " at line " + (this.f6601c + 1) + " column " + ((this.f6599a - this.f6602d) + 1) + " path " + s();
    }

    public boolean L() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 5) {
            this.f6603e = 0;
            int[] iArr = this.f845b;
            int i2 = this.f6605g - 1;
            iArr[i2] = iArr[i2] + 1;
            return true;
        }
        if (iL == 6) {
            this.f6603e = 0;
            int[] iArr2 = this.f845b;
            int i3 = this.f6605g - 1;
            iArr2[i3] = iArr2[i3] + 1;
            return false;
        }
        throw new IllegalStateException("Expected a boolean but was " + b0() + H());
    }

    public double M() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 15) {
            this.f6603e = 0;
            int[] iArr = this.f845b;
            int i2 = this.f6605g - 1;
            iArr[i2] = iArr[i2] + 1;
            return this.f838a;
        }
        if (iL == 16) {
            this.f840a = new String(this.f841a, this.f6599a, this.f6604f);
            this.f6599a += this.f6604f;
        } else if (iL == 8 || iL == 9) {
            this.f840a = Y(iL == 8 ? '\'' : '\"');
        } else if (iL == 10) {
            this.f840a = a0();
        } else if (iL != 11) {
            throw new IllegalStateException("Expected a double but was " + b0() + H());
        }
        this.f6603e = 11;
        double d2 = Double.parseDouble(this.f840a);
        if (!this.f844b && (Double.isNaN(d2) || Double.isInfinite(d2))) {
            throw new prn("JSON forbids NaN and infinities: " + d2 + H());
        }
        this.f840a = null;
        this.f6603e = 0;
        int[] iArr2 = this.f845b;
        int i3 = this.f6605g - 1;
        iArr2[i3] = iArr2[i3] + 1;
        return d2;
    }

    public int N() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 15) {
            long j2 = this.f838a;
            int i2 = (int) j2;
            if (j2 == i2) {
                this.f6603e = 0;
                int[] iArr = this.f845b;
                int i3 = this.f6605g - 1;
                iArr[i3] = iArr[i3] + 1;
                return i2;
            }
            throw new NumberFormatException("Expected an int but was " + this.f838a + H());
        }
        if (iL == 16) {
            this.f840a = new String(this.f841a, this.f6599a, this.f6604f);
            this.f6599a += this.f6604f;
        } else {
            if (iL != 8 && iL != 9 && iL != 10) {
                throw new IllegalStateException("Expected an int but was " + b0() + H());
            }
            if (iL == 10) {
                this.f840a = a0();
            } else {
                this.f840a = Y(iL == 8 ? '\'' : '\"');
            }
            try {
                int i4 = Integer.parseInt(this.f840a);
                this.f6603e = 0;
                int[] iArr2 = this.f845b;
                int i5 = this.f6605g - 1;
                iArr2[i5] = iArr2[i5] + 1;
                return i4;
            } catch (NumberFormatException unused) {
            }
        }
        this.f6603e = 11;
        double d2 = Double.parseDouble(this.f840a);
        int i6 = (int) d2;
        if (i6 != d2) {
            throw new NumberFormatException("Expected an int but was " + this.f840a + H());
        }
        this.f840a = null;
        this.f6603e = 0;
        int[] iArr3 = this.f845b;
        int i7 = this.f6605g - 1;
        iArr3[i7] = iArr3[i7] + 1;
        return i6;
    }

    public long O() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 15) {
            this.f6603e = 0;
            int[] iArr = this.f845b;
            int i2 = this.f6605g - 1;
            iArr[i2] = iArr[i2] + 1;
            return this.f838a;
        }
        if (iL == 16) {
            this.f840a = new String(this.f841a, this.f6599a, this.f6604f);
            this.f6599a += this.f6604f;
        } else {
            if (iL != 8 && iL != 9 && iL != 10) {
                throw new IllegalStateException("Expected a long but was " + b0() + H());
            }
            if (iL == 10) {
                this.f840a = a0();
            } else {
                this.f840a = Y(iL == 8 ? '\'' : '\"');
            }
            try {
                long j2 = Long.parseLong(this.f840a);
                this.f6603e = 0;
                int[] iArr2 = this.f845b;
                int i3 = this.f6605g - 1;
                iArr2[i3] = iArr2[i3] + 1;
                return j2;
            } catch (NumberFormatException unused) {
            }
        }
        this.f6603e = 11;
        double d2 = Double.parseDouble(this.f840a);
        long j3 = (long) d2;
        if (j3 != d2) {
            throw new NumberFormatException("Expected a long but was " + this.f840a + H());
        }
        this.f840a = null;
        this.f6603e = 0;
        int[] iArr3 = this.f845b;
        int i4 = this.f6605g - 1;
        iArr3[i4] = iArr3[i4] + 1;
        return j3;
    }

    public String V() throws IOException {
        String strY;
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 14) {
            strY = a0();
        } else if (iL == 12) {
            strY = Y('\'');
        } else {
            if (iL != 13) {
                throw new IllegalStateException("Expected a name but was " + b0() + H());
            }
            strY = Y('\"');
        }
        this.f6603e = 0;
        this.f843a[this.f6605g - 1] = strY;
        return strY;
    }

    public final int W(boolean z2) throws IOException {
        char[] cArr = this.f841a;
        int i2 = this.f6599a;
        int i3 = this.f6600b;
        while (true) {
            if (i2 == i3) {
                this.f6599a = i2;
                if (!p(1)) {
                    if (!z2) {
                        return -1;
                    }
                    throw new EOFException("End of input" + H());
                }
                i2 = this.f6599a;
                i3 = this.f6600b;
            }
            int i4 = i2 + 1;
            char c2 = cArr[i2];
            if (c2 == '\n') {
                this.f6601c++;
                this.f6602d = i4;
            } else if (c2 != ' ' && c2 != '\r' && c2 != '\t') {
                if (c2 == '/') {
                    this.f6599a = i4;
                    if (i4 == i3) {
                        this.f6599a = i4 - 1;
                        boolean zP = p(2);
                        this.f6599a++;
                        if (!zP) {
                            return c2;
                        }
                    }
                    d();
                    int i5 = this.f6599a;
                    char c3 = cArr[i5];
                    if (c3 == '*') {
                        this.f6599a = i5 + 1;
                        if (!i0("*/")) {
                            throw m0("Unterminated comment");
                        }
                        i2 = this.f6599a + 2;
                        i3 = this.f6600b;
                    } else {
                        if (c3 != '/') {
                            return c2;
                        }
                        this.f6599a = i5 + 1;
                        j0();
                        i2 = this.f6599a;
                        i3 = this.f6600b;
                    }
                } else {
                    if (c2 != '#') {
                        this.f6599a = i4;
                        return c2;
                    }
                    this.f6599a = i4;
                    d();
                    j0();
                    i2 = this.f6599a;
                    i3 = this.f6600b;
                }
            }
            i2 = i4;
        }
    }

    public void X() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 7) {
            this.f6603e = 0;
            int[] iArr = this.f845b;
            int i2 = this.f6605g - 1;
            iArr[i2] = iArr[i2] + 1;
            return;
        }
        throw new IllegalStateException("Expected null but was " + b0() + H());
    }

    public final String Y(char c2) throws IOException {
        int i2;
        char[] cArr = this.f841a;
        StringBuilder sb = null;
        do {
            int i3 = this.f6599a;
            int i4 = this.f6600b;
            while (true) {
                int i5 = i4;
                i2 = i3;
                while (true) {
                    if (i3 < i5) {
                        int i6 = i3 + 1;
                        char c3 = cArr[i3];
                        if (c3 == c2) {
                            this.f6599a = i6;
                            int i7 = (i6 - i2) - 1;
                            if (sb == null) {
                                return new String(cArr, i2, i7);
                            }
                            sb.append(cArr, i2, i7);
                            return sb.toString();
                        }
                        if (c3 == '\\') {
                            this.f6599a = i6;
                            int i8 = (i6 - i2) - 1;
                            if (sb == null) {
                                sb = new StringBuilder(Math.max((i8 + 1) * 2, 16));
                            }
                            sb.append(cArr, i2, i8);
                            sb.append(f0());
                            i3 = this.f6599a;
                            i4 = this.f6600b;
                        } else {
                            if (c3 == '\n') {
                                this.f6601c++;
                                this.f6602d = i6;
                            }
                            i3 = i6;
                        }
                    }
                }
            }
            if (sb == null) {
                sb = new StringBuilder(Math.max((i3 - i2) * 2, 16));
            }
            sb.append(cArr, i2, i3 - i2);
            this.f6599a = i3;
        } while (p(1));
        throw m0("Unterminated string");
    }

    public String Z() throws IOException {
        String str;
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 10) {
            str = a0();
        } else if (iL == 8) {
            str = Y('\'');
        } else if (iL == 9) {
            str = Y('\"');
        } else if (iL == 11) {
            str = this.f840a;
            this.f840a = null;
        } else if (iL == 15) {
            str = Long.toString(this.f838a);
        } else {
            if (iL != 16) {
                throw new IllegalStateException("Expected a string but was " + b0() + H());
            }
            str = new String(this.f841a, this.f6599a, this.f6604f);
            this.f6599a += this.f6604f;
        }
        this.f6603e = 0;
        int[] iArr = this.f845b;
        int i2 = this.f6605g - 1;
        iArr[i2] = iArr[i2] + 1;
        return str;
    }

    public void a() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 3) {
            e0(1);
            this.f845b[this.f6605g - 1] = 0;
            this.f6603e = 0;
        } else {
            throw new IllegalStateException("Expected BEGIN_ARRAY but was " + b0() + H());
        }
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:32:0x0044. Please report as an issue. */
    public final String a0() throws IOException {
        String string;
        StringBuilder sb = null;
        int i2 = 0;
        while (true) {
            int i3 = 0;
            while (true) {
                int i4 = this.f6599a;
                if (i4 + i3 < this.f6600b) {
                    char c2 = this.f841a[i4 + i3];
                    if (c2 != '\t' && c2 != '\n' && c2 != '\f' && c2 != '\r' && c2 != ' ') {
                        if (c2 != '#') {
                            if (c2 != ',') {
                                if (c2 != '/' && c2 != '=') {
                                    if (c2 != '{' && c2 != '}' && c2 != ':') {
                                        if (c2 != ';') {
                                            switch (c2) {
                                                case lpt4.AppCompatTheme_radioButtonStyle /* 91 */:
                                                case lpt4.AppCompatTheme_ratingBarStyleIndicator /* 93 */:
                                                    break;
                                                case lpt4.AppCompatTheme_ratingBarStyle /* 92 */:
                                                    break;
                                                default:
                                                    i3++;
                                                    break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        d();
                    }
                    i2 = i3;
                } else if (i3 >= this.f841a.length) {
                    if (sb == null) {
                        sb = new StringBuilder(Math.max(i3, 16));
                    }
                    sb.append(this.f841a, this.f6599a, i3);
                    this.f6599a += i3;
                    if (!p(1)) {
                    }
                } else if (!p(i3 + 1)) {
                    i2 = i3;
                }
                if (sb == null) {
                    string = new String(this.f841a, this.f6599a, i2);
                } else {
                    sb.append(this.f841a, this.f6599a, i2);
                    string = sb.toString();
                }
                this.f6599a += i2;
                return string;
            }
        }
    }

    public con b0() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        switch (iL) {
            case 1:
                return con.BEGIN_OBJECT;
            case 2:
                return con.END_OBJECT;
            case 3:
                return con.BEGIN_ARRAY;
            case 4:
                return con.END_ARRAY;
            case 5:
            case 6:
                return con.BOOLEAN;
            case 7:
                return con.NULL;
            case 8:
            case 9:
            case 10:
            case 11:
                return con.STRING;
            case 12:
            case 13:
            case 14:
                return con.NAME;
            case 15:
            case 16:
                return con.NUMBER;
            case 17:
                return con.END_DOCUMENT;
            default:
                throw new AssertionError();
        }
    }

    public void c() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL == 1) {
            e0(3);
            this.f6603e = 0;
        } else {
            throw new IllegalStateException("Expected BEGIN_OBJECT but was " + b0() + H());
        }
    }

    public final int c0() throws IOException {
        String str;
        String str2;
        int i2;
        char c2 = this.f841a[this.f6599a];
        if (c2 == 't' || c2 == 'T') {
            str = "true";
            str2 = "TRUE";
            i2 = 5;
        } else if (c2 == 'f' || c2 == 'F') {
            str = "false";
            str2 = "FALSE";
            i2 = 6;
        } else {
            if (c2 != 'n' && c2 != 'N') {
                return 0;
            }
            str = "null";
            str2 = "NULL";
            i2 = 7;
        }
        int length = str.length();
        for (int i3 = 1; i3 < length; i3++) {
            if (this.f6599a + i3 >= this.f6600b && !p(i3 + 1)) {
                return 0;
            }
            char c3 = this.f841a[this.f6599a + i3];
            if (c3 != str.charAt(i3) && c3 != str2.charAt(i3)) {
                return 0;
            }
        }
        if ((this.f6599a + length < this.f6600b || p(length + 1)) && G(this.f841a[this.f6599a + length])) {
            return 0;
        }
        this.f6599a += length;
        this.f6603e = i2;
        return i2;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.f6603e = 0;
        this.f842a[0] = 8;
        this.f6605g = 1;
        this.f839a.close();
    }

    public final void d() throws IOException {
        if (!this.f844b) {
            throw m0("Use JsonReader.setLenient(true) to accept malformed JSON");
        }
    }

    /* JADX WARN: Code duplicated, block: B:110:0x00f6 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:14:0x0030  */
    /* JADX WARN: Code duplicated, block: B:90:0x00df  */
    /* JADX WARN: Code duplicated, block: B:92:0x00e4  */
    /* JADX WARN: Code duplicated, block: B:97:0x00eb  */
    public final int d0() throws IOException {
        char c2;
        char c3;
        char[] cArr = this.f841a;
        int i2 = this.f6599a;
        int i3 = this.f6600b;
        int i4 = 0;
        int i5 = 0;
        char c4 = 0;
        boolean z2 = false;
        boolean z3 = true;
        long j2 = 0;
        while (true) {
            if (i2 + i5 != i3) {
                c2 = cArr[i2 + i5];
                if (c2 != '+') {
                    if (c2 != 'E' || c2 == 'e') {
                        i4 = 0;
                        if (c4 == 2 && c4 != 4) {
                            return 0;
                        }
                        c4 = 5;
                    } else if (c2 != '-') {
                        c3 = 3;
                        if (c2 == '.') {
                            i4 = 0;
                            if (c4 != 2) {
                                return 0;
                            }
                        } else {
                            if (c2 < '0' || c2 > '9') {
                                if (!G(c2)) {
                                    break;
                                }
                                return 0;
                            }
                            if (c4 == 1 || c4 == 0) {
                                j2 = -(c2 - '0');
                                c4 = 2;
                            } else if (c4 == 2) {
                                if (j2 == 0) {
                                    return 0;
                                }
                                long j3 = (10 * j2) - ((long) (c2 - '0'));
                                z3 &= j2 > -922337203685477580L || (j2 == -922337203685477580L && j3 < j2);
                                j2 = j3;
                            } else if (c4 == 3) {
                                i4 = 0;
                                c4 = 4;
                            } else if (c4 == 5 || c4 == 6) {
                                i4 = 0;
                                c4 = 7;
                            }
                            i4 = 0;
                        }
                    } else {
                        c3 = 6;
                        i4 = 0;
                        if (c4 == 0) {
                            c4 = 1;
                            z2 = true;
                        } else if (c4 != 5) {
                            return 0;
                        }
                    }
                    i5++;
                } else {
                    c3 = 6;
                    i4 = 0;
                    if (c4 != 5) {
                        return 0;
                    }
                }
                c4 = c3;
                i5++;
            } else {
                if (i5 == cArr.length) {
                    return i4;
                }
                if (!p(i5 + 1)) {
                    break;
                }
                i2 = this.f6599a;
                i3 = this.f6600b;
                c2 = cArr[i2 + i5];
                if (c2 != '+') {
                    if (c2 != 'E') {
                        i4 = 0;
                        if (c4 == 2) {
                        }
                        c4 = 5;
                    } else {
                        i4 = 0;
                        if (c4 == 2) {
                        }
                        c4 = 5;
                    }
                    i5++;
                } else {
                    c3 = 6;
                    i4 = 0;
                    if (c4 != 5) {
                        return 0;
                    }
                }
                c4 = c3;
                i5++;
            }
        }
        if (c4 == 2 && z3 && ((j2 != Long.MIN_VALUE || z2) && (j2 != 0 || !z2))) {
            if (!z2) {
                j2 = -j2;
            }
            this.f838a = j2;
            this.f6599a += i5;
            this.f6603e = 15;
            return 15;
        }
        if (c4 != 2 && c4 != 4 && c4 != 7) {
            return 0;
        }
        this.f6604f = i5;
        this.f6603e = 16;
        return 16;
    }

    public final void e0(int i2) {
        int i3 = this.f6605g;
        int[] iArr = this.f842a;
        if (i3 == iArr.length) {
            int i4 = i3 * 2;
            this.f842a = Arrays.copyOf(iArr, i4);
            this.f845b = Arrays.copyOf(this.f845b, i4);
            this.f843a = (String[]) Arrays.copyOf(this.f843a, i4);
        }
        int[] iArr2 = this.f842a;
        int i5 = this.f6605g;
        this.f6605g = i5 + 1;
        iArr2[i5] = i2;
    }

    public final void f() throws IOException {
        W(true);
        int i2 = this.f6599a - 1;
        this.f6599a = i2;
        if (i2 + 5 <= this.f6600b || p(5)) {
            int i3 = this.f6599a;
            char[] cArr = this.f841a;
            if (cArr[i3] == ')' && cArr[i3 + 1] == ']' && cArr[i3 + 2] == '}' && cArr[i3 + 3] == '\'' && cArr[i3 + 4] == '\n') {
                this.f6599a = i3 + 5;
            }
        }
    }

    public final char f0() throws IOException {
        int i2;
        int i3;
        if (this.f6599a == this.f6600b && !p(1)) {
            throw m0("Unterminated escape sequence");
        }
        char[] cArr = this.f841a;
        int i4 = this.f6599a;
        int i5 = i4 + 1;
        this.f6599a = i5;
        char c2 = cArr[i4];
        if (c2 == '\n') {
            this.f6601c++;
            this.f6602d = i5;
        } else if (c2 != '\"' && c2 != '\'' && c2 != '/' && c2 != '\\') {
            if (c2 == 'b') {
                return '\b';
            }
            if (c2 == 'f') {
                return '\f';
            }
            if (c2 == 'n') {
                return '\n';
            }
            if (c2 == 'r') {
                return '\r';
            }
            if (c2 == 't') {
                return '\t';
            }
            if (c2 != 'u') {
                throw m0("Invalid escape sequence");
            }
            if (i5 + 4 > this.f6600b && !p(4)) {
                throw m0("Unterminated escape sequence");
            }
            int i6 = this.f6599a;
            int i7 = i6 + 4;
            char c3 = 0;
            while (i6 < i7) {
                char c4 = this.f841a[i6];
                char c5 = (char) (c3 << 4);
                if (c4 < '0' || c4 > '9') {
                    if (c4 >= 'a' && c4 <= 'f') {
                        i2 = c4 - 'a';
                    } else {
                        if (c4 < 'A' || c4 > 'F') {
                            throw new NumberFormatException("\\u" + new String(this.f841a, this.f6599a, 4));
                        }
                        i2 = c4 - 'A';
                    }
                    i3 = i2 + 10;
                } else {
                    i3 = c4 - '0';
                }
                c3 = (char) (c5 + i3);
                i6++;
            }
            this.f6599a += 4;
            return c3;
        }
        return c2;
    }

    public final void g0(boolean z2) {
        this.f844b = z2;
    }

    public final void h0(char c2) throws IOException {
        char[] cArr = this.f841a;
        do {
            int i2 = this.f6599a;
            int i3 = this.f6600b;
            while (i2 < i3) {
                int i4 = i2 + 1;
                char c3 = cArr[i2];
                if (c3 == c2) {
                    this.f6599a = i4;
                    return;
                }
                if (c3 == '\\') {
                    this.f6599a = i4;
                    f0();
                    i2 = this.f6599a;
                    i3 = this.f6600b;
                } else {
                    if (c3 == '\n') {
                        this.f6601c++;
                        this.f6602d = i4;
                    }
                    i2 = i4;
                }
            }
            this.f6599a = i2;
        } while (p(1));
        throw m0("Unterminated string");
    }

    public final boolean i0(String str) throws IOException {
        int length = str.length();
        while (true) {
            if (this.f6599a + length > this.f6600b && !p(length)) {
                return false;
            }
            char[] cArr = this.f841a;
            int i2 = this.f6599a;
            if (cArr[i2] != '\n') {
                for (int i3 = 0; i3 < length; i3++) {
                    if (this.f841a[this.f6599a + i3] == str.charAt(i3)) {
                    }
                }
                return true;
            }
            this.f6601c++;
            this.f6602d = i2 + 1;
            this.f6599a++;
        }
    }

    public final void j0() throws IOException {
        char c2;
        do {
            if (this.f6599a >= this.f6600b && !p(1)) {
                return;
            }
            char[] cArr = this.f841a;
            int i2 = this.f6599a;
            int i3 = i2 + 1;
            this.f6599a = i3;
            c2 = cArr[i2];
            if (c2 == '\n') {
                this.f6601c++;
                this.f6602d = i3;
                return;
            }
        } while (c2 != '\r');
    }

    public final void k0() throws IOException {
        do {
            int i2 = 0;
            while (true) {
                int i3 = this.f6599a;
                if (i3 + i2 < this.f6600b) {
                    char c2 = this.f841a[i3 + i2];
                    if (c2 != '\t' && c2 != '\n' && c2 != '\f' && c2 != '\r' && c2 != ' ') {
                        if (c2 != '#') {
                            if (c2 != ',') {
                                if (c2 != '/' && c2 != '=') {
                                    if (c2 != '{' && c2 != '}' && c2 != ':') {
                                        if (c2 != ';') {
                                            switch (c2) {
                                                case lpt4.AppCompatTheme_radioButtonStyle /* 91 */:
                                                case lpt4.AppCompatTheme_ratingBarStyleIndicator /* 93 */:
                                                    break;
                                                case lpt4.AppCompatTheme_ratingBarStyle /* 92 */:
                                                    break;
                                                default:
                                                    i2++;
                                                    break;
                                            }
                                            return;
                                        }
                                    }
                                }
                            }
                        }
                        d();
                    }
                    this.f6599a += i2;
                    return;
                }
                this.f6599a = i3 + i2;
            }
        } while (p(1));
    }

    public int l() throws IOException {
        int iW;
        int[] iArr = this.f842a;
        int i2 = this.f6605g;
        int i3 = iArr[i2 - 1];
        if (i3 == 1) {
            iArr[i2 - 1] = 2;
        } else if (i3 == 2) {
            int iW2 = W(true);
            if (iW2 != 44) {
                if (iW2 != 59) {
                    if (iW2 != 93) {
                        throw m0("Unterminated array");
                    }
                    this.f6603e = 4;
                    return 4;
                }
                d();
            }
        } else {
            if (i3 == 3 || i3 == 5) {
                iArr[i2 - 1] = 4;
                if (i3 == 5 && (iW = W(true)) != 44) {
                    if (iW != 59) {
                        if (iW != 125) {
                            throw m0("Unterminated object");
                        }
                        this.f6603e = 2;
                        return 2;
                    }
                    d();
                }
                int iW3 = W(true);
                if (iW3 == 34) {
                    this.f6603e = 13;
                    return 13;
                }
                if (iW3 == 39) {
                    d();
                    this.f6603e = 12;
                    return 12;
                }
                if (iW3 == 125) {
                    if (i3 == 5) {
                        throw m0("Expected name");
                    }
                    this.f6603e = 2;
                    return 2;
                }
                d();
                this.f6599a--;
                if (!G((char) iW3)) {
                    throw m0("Expected name");
                }
                this.f6603e = 14;
                return 14;
            }
            if (i3 == 4) {
                iArr[i2 - 1] = 5;
                int iW4 = W(true);
                if (iW4 != 58) {
                    if (iW4 != 61) {
                        throw m0("Expected ':'");
                    }
                    d();
                    if (this.f6599a < this.f6600b || p(1)) {
                        char[] cArr = this.f841a;
                        int i4 = this.f6599a;
                        if (cArr[i4] == '>') {
                            this.f6599a = i4 + 1;
                        }
                    }
                }
            } else if (i3 == 6) {
                if (this.f844b) {
                    f();
                }
                this.f842a[this.f6605g - 1] = 7;
            } else if (i3 == 7) {
                if (W(false) == -1) {
                    this.f6603e = 17;
                    return 17;
                }
                d();
                this.f6599a--;
            } else if (i3 == 8) {
                throw new IllegalStateException("JsonReader is closed");
            }
        }
        int iW5 = W(true);
        if (iW5 == 34) {
            this.f6603e = 9;
            return 9;
        }
        if (iW5 == 39) {
            d();
            this.f6603e = 8;
            return 8;
        }
        if (iW5 != 44 && iW5 != 59) {
            if (iW5 == 91) {
                this.f6603e = 3;
                return 3;
            }
            if (iW5 != 93) {
                if (iW5 == 123) {
                    this.f6603e = 1;
                    return 1;
                }
                this.f6599a--;
                int iC0 = c0();
                if (iC0 != 0) {
                    return iC0;
                }
                int iD0 = d0();
                if (iD0 != 0) {
                    return iD0;
                }
                if (!G(this.f841a[this.f6599a])) {
                    throw m0("Expected value");
                }
                d();
                this.f6603e = 10;
                return 10;
            }
            if (i3 == 1) {
                this.f6603e = 4;
                return 4;
            }
        }
        if (i3 != 1 && i3 != 2) {
            throw m0("Unexpected value");
        }
        d();
        this.f6599a--;
        this.f6603e = 7;
        return 7;
    }

    public void l0() throws IOException {
        int i2 = 0;
        do {
            int iL = this.f6603e;
            if (iL == 0) {
                iL = l();
            }
            if (iL == 3) {
                e0(1);
            } else {
                if (iL == 1) {
                    e0(3);
                } else if (iL == 4 || iL == 2) {
                    this.f6605g--;
                    i2--;
                } else if (iL == 14 || iL == 10) {
                    k0();
                } else if (iL == 8 || iL == 12) {
                    h0('\'');
                } else if (iL == 9 || iL == 13) {
                    h0('\"');
                } else if (iL == 16) {
                    this.f6599a += this.f6604f;
                }
                this.f6603e = 0;
            }
            i2++;
            this.f6603e = 0;
        } while (i2 != 0);
        int[] iArr = this.f845b;
        int i3 = this.f6605g;
        int i4 = i3 - 1;
        iArr[i4] = iArr[i4] + 1;
        this.f843a[i3 - 1] = "null";
    }

    public final IOException m0(String str) throws IOException {
        throw new prn(str + H());
    }

    public void n() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL != 4) {
            throw new IllegalStateException("Expected END_ARRAY but was " + b0() + H());
        }
        int i2 = this.f6605g - 1;
        this.f6605g = i2;
        int[] iArr = this.f845b;
        int i3 = i2 - 1;
        iArr[i3] = iArr[i3] + 1;
        this.f6603e = 0;
    }

    public void o() throws IOException {
        int iL = this.f6603e;
        if (iL == 0) {
            iL = l();
        }
        if (iL != 2) {
            throw new IllegalStateException("Expected END_OBJECT but was " + b0() + H());
        }
        int i2 = this.f6605g - 1;
        this.f6605g = i2;
        this.f843a[i2] = null;
        int[] iArr = this.f845b;
        int i3 = i2 - 1;
        iArr[i3] = iArr[i3] + 1;
        this.f6603e = 0;
    }

    public final boolean p(int i2) throws IOException {
        int i3;
        int i4;
        char[] cArr = this.f841a;
        int i5 = this.f6602d;
        int i6 = this.f6599a;
        this.f6602d = i5 - i6;
        int i7 = this.f6600b;
        if (i7 != i6) {
            int i8 = i7 - i6;
            this.f6600b = i8;
            System.arraycopy(cArr, i6, cArr, 0, i8);
        } else {
            this.f6600b = 0;
        }
        this.f6599a = 0;
        do {
            Reader reader = this.f839a;
            int i9 = this.f6600b;
            int i10 = reader.read(cArr, i9, cArr.length - i9);
            if (i10 == -1) {
                return false;
            }
            i3 = this.f6600b + i10;
            this.f6600b = i3;
            if (this.f6601c == 0 && (i4 = this.f6602d) == 0 && i3 > 0 && cArr[0] == 65279) {
                this.f6599a++;
                this.f6602d = i4 + 1;
                i2++;
            }
        } while (i3 < i2);
        return true;
    }

    public String s() {
        return y(false);
    }

    public String toString() {
        return getClass().getSimpleName() + H();
    }

    public final String y(boolean z2) {
        StringBuilder sb = new StringBuilder();
        sb.append('$');
        int i2 = 0;
        while (true) {
            int i3 = this.f6605g;
            if (i2 >= i3) {
                return sb.toString();
            }
            int i4 = this.f842a[i2];
            if (i4 == 1 || i4 == 2) {
                int i5 = this.f845b[i2];
                if (z2 && i5 > 0 && i2 == i3 - 1) {
                    i5--;
                }
                sb.append(com4.IPV6_START_BRACKET);
                sb.append(i5);
                sb.append(com4.IPV6_END_BRACKET);
            } else if (i4 == 3 || i4 == 4 || i4 == 5) {
                sb.append('.');
                String str = this.f843a[i2];
                if (str != null) {
                    sb.append(str);
                }
            }
            i2++;
        }
    }
}
