package androidx.savedstate;

import COM3.com7;
import COM4.con;
import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.nul;
import androidx.lifecycle.prn;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"RestrictedApi"})
final class Recreator implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final con f8738a;

    public static final class aux implements SavedStateRegistry.con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Set<String> f8739a = new HashSet();

        public aux(SavedStateRegistry savedStateRegistry) {
            savedStateRegistry.d("androidx.savedstate.Restarter", this);
        }

        @Override // androidx.savedstate.SavedStateRegistry.con
        public Bundle a() {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("classes_to_restore", new ArrayList<>(this.f8739a));
            return bundle;
        }

        public void b(String str) {
            this.f8739a.add(str);
        }
    }

    public Recreator(con conVar) {
        this.f8738a = conVar;
    }

    @Override // androidx.lifecycle.prn
    public void f(com7 com7Var, nul.con conVar) {
        if (conVar != nul.con.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        com7Var.getLifecycle().c(this);
        Bundle bundleA = this.f8738a.getSavedStateRegistry().a("androidx.savedstate.Restarter");
        if (bundleA == null) {
            return;
        }
        ArrayList<String> stringArrayList = bundleA.getStringArrayList("classes_to_restore");
        if (stringArrayList == null) {
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        Iterator<String> it = stringArrayList.iterator();
        while (it.hasNext()) {
            h(it.next());
        }
    }

    public final void h(String str) {
        try {
            Class<? extends U> clsAsSubclass = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(SavedStateRegistry.aux.class);
            try {
                Constructor declaredConstructor = clsAsSubclass.getDeclaredConstructor(new Class[0]);
                declaredConstructor.setAccessible(true);
                try {
                    ((SavedStateRegistry.aux) declaredConstructor.newInstance(new Object[0])).a(this.f8738a);
                } catch (Exception e2) {
                    throw new RuntimeException("Failed to instantiate " + str, e2);
                }
            } catch (NoSuchMethodException e3) {
                throw new IllegalStateException("Class" + clsAsSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e3);
            }
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("Class " + str + " wasn't found", e4);
        }
    }
}
