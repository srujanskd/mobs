package LPT4;

import android.content.ContentResolver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import com.newrelic.agent.android.instrumentation.BitmapFactoryInstrumentation;
import com.newrelic.agent.android.instrumentation.Instrumented;
import java.io.ByteArrayOutputStream;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import p141lpt5.h3;
import p141lpt5.j3;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class aux {
    public static final int OPTIONS_RECYCLE_INPUT = 2;
    private static final int OPTIONS_SCALE_UP = 1;

    public static byte[] BitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        if (bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)) {
            return byteArrayOutputStream.toByteArray();
        }
        return null;
    }

    public static Bitmap asBitmap(byte[] bArr) {
        if (bArr != null) {
            return BitmapFactoryInstrumentation.decodeByteArray(bArr, 0, bArr.length);
        }
        return null;
    }

    public static Bitmap asBitmapStrictSize(byte[] bArr, int i2, int i3) {
        if (bArr == null) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeByteArray(bArr, 0, bArr.length, options);
        int iCalcSampleSize = calcSampleSize(options, i2, i3);
        int iMSB = 1 << h3.MSB(iCalcSampleSize);
        options.inSampleSize = iMSB;
        options.inJustDecodeBounds = false;
        Bitmap bitmapDecodeByteArray = BitmapFactoryInstrumentation.decodeByteArray(bArr, 0, bArr.length, options);
        if (iMSB == iCalcSampleSize && bitmapDecodeByteArray.getWidth() == i2 && bitmapDecodeByteArray.getHeight() == i3) {
            return bitmapDecodeByteArray;
        }
        Bitmap bitmapScaleBitmap = scaleBitmap(bitmapDecodeByteArray, i2, i3);
        bitmapDecodeByteArray.recycle();
        return bitmapScaleBitmap;
    }

    public static int calcSampleSize(BitmapFactory.Options options, int i2, int i3) {
        int i4 = options.outWidth;
        int i5 = options.outHeight;
        if (i5 > i3 || i4 > i2) {
            return (int) (i4 > i5 ? Math.floor(i5 / i3) : Math.floor(i4 / i2));
        }
        return 1;
    }

    public static Bitmap copyBitmap(Bitmap bitmap, Bitmap bitmap2) {
        if (bitmap == null) {
            throw new NullPointerException("src bitmap should not be null.");
        }
        if (bitmap2 == null) {
            return Bitmap.createBitmap(bitmap);
        }
        if (bitmap.equals(bitmap2)) {
            return bitmap2;
        }
        new Canvas(bitmap2).setBitmap(bitmap);
        return bitmap2;
    }

    public static Bitmap extractBitmap(Bitmap bitmap, int i2, int i3) {
        float f2;
        int height;
        if (bitmap == null) {
            return null;
        }
        if (bitmap.getWidth() < bitmap.getHeight()) {
            f2 = i2;
            height = bitmap.getWidth();
        } else {
            f2 = i3;
            height = bitmap.getHeight();
        }
        float f3 = f2 / height;
        Matrix matrix = new Matrix();
        matrix.setScale(f3, f3);
        return transform(matrix, bitmap, i2, i3, 3);
    }

    public static int getOrientation(ContentResolver contentResolver, Uri uri) {
        try {
            int attributeInt = new ExifInterface(j3.getAbsolutePath(contentResolver, uri)).getAttributeInt("Orientation", 0);
            if (attributeInt == 3) {
                return 180;
            }
            if (attributeInt != 6) {
                return attributeInt != 8 ? 0 : 270;
            }
            return 90;
        } catch (Exception unused) {
            return 0;
        }
    }

    public static Bitmap makeCheckBitmap() {
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(40, 40, Bitmap.Config.RGB_565);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        canvas.drawColor(-1);
        Paint paint = new Paint();
        paint.setColor(-3355444);
        canvas.drawRect(0.0f, 0.0f, 20.0f, 20.0f, paint);
        canvas.drawRect(20.0f, 20.0f, 40.0f, 40.0f, paint);
        return bitmapCreateBitmap;
    }

    public static Bitmap rotateBitmap(Bitmap bitmap, int i2) {
        if (bitmap == null) {
            return null;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.postRotate(i2);
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
    }

    public static Bitmap scaleBitmap(Bitmap bitmap, int i2, int i3) {
        if (bitmap == null) {
            return null;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.postScale(width / i2, height / i3);
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
    }

    public static Bitmap scaleRotateBitmap(Bitmap bitmap, int i2, int i3, int i4) {
        if (bitmap == null) {
            return null;
        }
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        Matrix matrix = new Matrix();
        matrix.postScale(width / i2, height / i3);
        matrix.postRotate(i4);
        return Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
    }

    /* JADX WARN: Code duplicated, block: B:37:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:38:0x00c4  */
    private static Bitmap transform(Matrix matrix, Bitmap bitmap, int i2, int i3, int i4) {
        Matrix matrix2;
        Bitmap bitmapCreateBitmap;
        Bitmap bitmapCreateBitmap2;
        Matrix matrix3 = matrix;
        boolean z2 = (i4 & 1) != 0;
        boolean z3 = (i4 & 2) != 0;
        int width = bitmap.getWidth() - i2;
        int height = bitmap.getHeight() - i3;
        if (!z2 && (width < 0 || height < 0)) {
            Bitmap bitmapCreateBitmap3 = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmapCreateBitmap3);
            int iMax = Math.max(0, width / 2);
            int iMax2 = Math.max(0, height / 2);
            Rect rect = new Rect(iMax, iMax2, Math.min(i2, bitmap.getWidth()) + iMax, Math.min(i3, bitmap.getHeight()) + iMax2);
            int iWidth = (i2 - rect.width()) / 2;
            int iHeight = (i3 - rect.height()) / 2;
            canvas.drawBitmap(bitmap, rect, new Rect(iWidth, iHeight, i2 - iWidth, i3 - iHeight), (Paint) null);
            if (z3) {
                bitmap.recycle();
            }
            canvas.setBitmap(null);
            return bitmapCreateBitmap3;
        }
        float width2 = bitmap.getWidth();
        float height2 = bitmap.getHeight();
        float f2 = i2;
        float f3 = i3;
        if (width2 / height2 <= f2 / f3) {
            float f4 = f2 / width2;
            if (f4 < 0.9f || f4 > 1.0f) {
                matrix.setScale(f4, f4);
            } else {
                matrix2 = null;
            }
            if (matrix2 != null) {
                bitmapCreateBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix2, true);
            } else {
                bitmapCreateBitmap = bitmap;
            }
            if (z3 && bitmapCreateBitmap != bitmap) {
                bitmap.recycle();
            }
            bitmapCreateBitmap2 = Bitmap.createBitmap(bitmapCreateBitmap, Math.max(0, bitmapCreateBitmap.getWidth() - i2) / 2, Math.max(0, bitmapCreateBitmap.getHeight() - i3) / 2, i2, i3);
            if (bitmapCreateBitmap2 != bitmapCreateBitmap && (z3 || bitmapCreateBitmap != bitmap)) {
                bitmapCreateBitmap.recycle();
            }
            return bitmapCreateBitmap2;
        }
        float f5 = f3 / height2;
        if (f5 < 0.9f || f5 > 1.0f) {
            matrix.setScale(f5, f5);
        } else {
            matrix3 = null;
        }
        matrix2 = matrix3;
        if (matrix2 != null) {
            bitmapCreateBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix2, true);
        } else {
            bitmapCreateBitmap = bitmap;
        }
        if (z3) {
            bitmap.recycle();
        }
        bitmapCreateBitmap2 = Bitmap.createBitmap(bitmapCreateBitmap, Math.max(0, bitmapCreateBitmap.getWidth() - i2) / 2, Math.max(0, bitmapCreateBitmap.getHeight() - i3) / 2, i2, i3);
        if (bitmapCreateBitmap2 != bitmapCreateBitmap) {
            bitmapCreateBitmap.recycle();
        }
        return bitmapCreateBitmap2;
    }

    public static Bitmap asBitmap(byte[] bArr, int i2, int i3) {
        if (bArr == null) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeByteArray(bArr, 0, bArr.length, options);
        options.inJustDecodeBounds = false;
        options.inSampleSize = calcSampleSize(options, i2, i3);
        return BitmapFactoryInstrumentation.decodeByteArray(bArr, 0, bArr.length, options);
    }

    public static Bitmap asBitmap(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        return BitmapFactoryInstrumentation.decodeFile(str);
    }

    public static Bitmap asBitmap(String str, int i2, int i3) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeFile(str, options);
        options.inJustDecodeBounds = false;
        options.inSampleSize = calcSampleSize(options, i2, i3);
        return BitmapFactoryInstrumentation.decodeFile(str, options);
    }

    public static Bitmap asBitmapStrictSize(String str, int i2, int i3) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeFile(str, options);
        int iCalcSampleSize = calcSampleSize(options, i2, i3);
        int iMSB = 1 << h3.MSB(iCalcSampleSize);
        options.inSampleSize = iMSB;
        options.inJustDecodeBounds = false;
        Bitmap bitmapDecodeFile = BitmapFactoryInstrumentation.decodeFile(str, options);
        if (iMSB == iCalcSampleSize && bitmapDecodeFile.getWidth() == i2 && bitmapDecodeFile.getHeight() == i3) {
            return bitmapDecodeFile;
        }
        Bitmap bitmapScaleBitmap = scaleBitmap(bitmapDecodeFile, i2, i3);
        bitmapDecodeFile.recycle();
        return bitmapScaleBitmap;
    }

    public static Bitmap asBitmap(FileDescriptor fileDescriptor) {
        if (fileDescriptor == null || !fileDescriptor.valid()) {
            return null;
        }
        return BitmapFactoryInstrumentation.decodeFileDescriptor(fileDescriptor);
    }

    public static Bitmap asBitmap(FileDescriptor fileDescriptor, int i2, int i3) {
        if (fileDescriptor == null || !fileDescriptor.valid()) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeFileDescriptor(fileDescriptor, null, options);
        options.inJustDecodeBounds = false;
        options.inSampleSize = calcSampleSize(options, i2, i3);
        return BitmapFactoryInstrumentation.decodeFileDescriptor(fileDescriptor, null, options);
    }

    public static Bitmap asBitmap(ContentResolver contentResolver, Uri uri) throws IOException {
        ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor;
        if (uri == null || (parcelFileDescriptorOpenFileDescriptor = contentResolver.openFileDescriptor(uri, "r")) == null) {
            return null;
        }
        Bitmap bitmapDecodeFileDescriptor = BitmapFactoryInstrumentation.decodeFileDescriptor(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor());
        int orientation = getOrientation(contentResolver, uri);
        if (orientation == 0) {
            return bitmapDecodeFileDescriptor;
        }
        Bitmap bitmapRotateBitmap = rotateBitmap(bitmapDecodeFileDescriptor, orientation);
        bitmapDecodeFileDescriptor.recycle();
        return bitmapRotateBitmap;
    }

    public static Bitmap asBitmapStrictSize(FileDescriptor fileDescriptor, int i2, int i3) {
        if (fileDescriptor == null || !fileDescriptor.valid()) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeFileDescriptor(fileDescriptor, null, options);
        int iCalcSampleSize = calcSampleSize(options, i2, i3);
        int iMSB = 1 << h3.MSB(iCalcSampleSize);
        options.inSampleSize = iMSB;
        options.inJustDecodeBounds = false;
        Bitmap bitmapDecodeFileDescriptor = BitmapFactoryInstrumentation.decodeFileDescriptor(fileDescriptor, null, options);
        if (iMSB == iCalcSampleSize && bitmapDecodeFileDescriptor.getWidth() == i2 && bitmapDecodeFileDescriptor.getHeight() == i3) {
            return bitmapDecodeFileDescriptor;
        }
        Bitmap bitmapScaleBitmap = scaleBitmap(bitmapDecodeFileDescriptor, i2, i3);
        bitmapDecodeFileDescriptor.recycle();
        return bitmapScaleBitmap;
    }

    public static Bitmap asBitmap(ContentResolver contentResolver, Uri uri, int i2, int i3) throws IOException {
        ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor;
        if (uri == null || (parcelFileDescriptorOpenFileDescriptor = contentResolver.openFileDescriptor(uri, "r")) == null) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeFileDescriptor(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor(), null, options);
        options.inJustDecodeBounds = false;
        options.inSampleSize = calcSampleSize(options, i2, i3);
        Bitmap bitmapDecodeFileDescriptor = BitmapFactoryInstrumentation.decodeFileDescriptor(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor(), null, options);
        int orientation = getOrientation(contentResolver, uri);
        if (orientation == 0) {
            return bitmapDecodeFileDescriptor;
        }
        Bitmap bitmapRotateBitmap = rotateBitmap(bitmapDecodeFileDescriptor, orientation);
        bitmapDecodeFileDescriptor.recycle();
        return bitmapRotateBitmap;
    }

    public static Bitmap asBitmapStrictSize(ContentResolver contentResolver, Uri uri, int i2, int i3) throws IOException {
        ParcelFileDescriptor parcelFileDescriptorOpenFileDescriptor;
        if (uri == null || (parcelFileDescriptorOpenFileDescriptor = contentResolver.openFileDescriptor(uri, "r")) == null) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeFileDescriptor(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor(), null, options);
        int iCalcSampleSize = calcSampleSize(options, i2, i3);
        int iMSB = 1 << h3.MSB(iCalcSampleSize);
        options.inSampleSize = iMSB;
        options.inJustDecodeBounds = false;
        Bitmap bitmapDecodeFileDescriptor = BitmapFactoryInstrumentation.decodeFileDescriptor(parcelFileDescriptorOpenFileDescriptor.getFileDescriptor(), null, options);
        int orientation = getOrientation(contentResolver, uri);
        if (iMSB == iCalcSampleSize && orientation == 0 && bitmapDecodeFileDescriptor.getWidth() == i2 && bitmapDecodeFileDescriptor.getHeight() == i3) {
            return bitmapDecodeFileDescriptor;
        }
        Bitmap bitmapScaleRotateBitmap = scaleRotateBitmap(bitmapDecodeFileDescriptor, i2, i3, orientation);
        bitmapDecodeFileDescriptor.recycle();
        return bitmapScaleRotateBitmap;
    }

    public static Bitmap asBitmap(InputStream inputStream) {
        if (inputStream != null) {
            return BitmapFactoryInstrumentation.decodeStream(inputStream);
        }
        return null;
    }

    public static Bitmap asBitmap(InputStream inputStream, int i2, int i3) {
        if (inputStream == null) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        Rect rect = new Rect();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeStream(inputStream, rect, options);
        options.inJustDecodeBounds = false;
        options.inSampleSize = calcSampleSize(options, i2, i3);
        return BitmapFactoryInstrumentation.decodeStream(inputStream, rect, options);
    }

    public static Bitmap asBitmapStrictSize(InputStream inputStream, int i2, int i3) {
        if (inputStream == null) {
            return null;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        Rect rect = new Rect();
        options.inJustDecodeBounds = true;
        BitmapFactoryInstrumentation.decodeStream(inputStream, rect, options);
        int iCalcSampleSize = calcSampleSize(options, i2, i3);
        int iMSB = 1 << h3.MSB(iCalcSampleSize);
        options.inSampleSize = iMSB;
        options.inJustDecodeBounds = false;
        Bitmap bitmapDecodeStream = BitmapFactoryInstrumentation.decodeStream(inputStream, rect, options);
        if (iMSB == iCalcSampleSize && bitmapDecodeStream.getWidth() == i2 && bitmapDecodeStream.getHeight() == i3) {
            return bitmapDecodeStream;
        }
        Bitmap bitmapScaleBitmap = scaleBitmap(bitmapDecodeStream, i2, i3);
        bitmapDecodeStream.recycle();
        return bitmapScaleBitmap;
    }
}
