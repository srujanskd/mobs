package LPT7;

import java.util.Comparator;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class com2 implements Comparator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ inet.ipaddr.con f6696a;

    public /* synthetic */ com2(inet.ipaddr.con conVar) {
        this.f6696a = conVar;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        return this.f6696a.compare((inet.ipaddr.aux) obj, (inet.ipaddr.aux) obj2);
    }
}
