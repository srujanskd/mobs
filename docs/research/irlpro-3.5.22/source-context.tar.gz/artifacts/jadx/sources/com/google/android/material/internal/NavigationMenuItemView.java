package com.google.android.material.internal;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.com3;
import androidx.appcompat.view.menu.com6;
import androidx.appcompat.widget.con;
import p014CoM2.lpt1;
import p022CoN.s0;
import p024Com2.lpt3;
import p024Com2.y;
import p075cOM6.a4;
import p075cOM6.b4;
import p075cOM6.d4;
import p075cOM6.z3;
import p081cOm2.e2;
import p100com1.h0;
import p108com9.m;

/* JADX INFO: loaded from: classes.dex */
public class NavigationMenuItemView extends m implements com6.aux {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int[] f9534c = {R.attr.state_checked};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt3 f9535a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3574a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CheckedTextView f3575a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public FrameLayout f3576a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f3577a;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Drawable f3578c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9536f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f9537g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f9538h;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f9539k;

    public class aux extends lpt3 {
        public aux() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.R(NavigationMenuItemView.this.f9537g);
        }
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.f3576a == null) {
                this.f3576a = (FrameLayout) ((ViewStub) findViewById(b4.f8883f)).inflate();
            }
            this.f3576a.removeAllViews();
            this.f3576a.addView(view);
        }
    }

    public final StateListDrawable A() {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(p001AuX.com3.f5515w, typedValue, true)) {
            return null;
        }
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(f9534c, new ColorDrawable(typedValue.data));
        stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
        return stateListDrawable;
    }

    public final boolean B() {
        return this.f3577a.getTitle() == null && this.f3577a.getIcon() == null && this.f3577a.getActionView() != null;
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public void b(com3 com3Var, int i2) {
        this.f3577a = com3Var;
        if (com3Var.getItemId() > 0) {
            setId(com3Var.getItemId());
        }
        setVisibility(com3Var.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            y.s0(this, A());
        }
        setCheckable(com3Var.isCheckable());
        setChecked(com3Var.isChecked());
        setEnabled(com3Var.isEnabled());
        setTitle(com3Var.getTitle());
        setIcon(com3Var.getIcon());
        setActionView(com3Var.getActionView());
        setContentDescription(com3Var.getContentDescription());
        s0.a(this, com3Var.getTooltipText());
        z();
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public boolean d() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public com3 getItemData() {
        return this.f3577a;
    }

    @Override // android.view.ViewGroup, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i2 + 1);
        com3 com3Var = this.f3577a;
        if (com3Var != null && com3Var.isCheckable() && this.f3577a.isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f9534c);
        }
        return iArrOnCreateDrawableState;
    }

    public void setCheckable(boolean z2) {
        refreshDrawableState();
        if (this.f9537g != z2) {
            this.f9537g = z2;
            this.f9535a.l(this.f3575a, 2048);
        }
    }

    public void setChecked(boolean z2) {
        refreshDrawableState();
        this.f3575a.setChecked(z2);
    }

    public void setHorizontalPadding(int i2) {
        setPadding(i2, getPaddingTop(), i2, getPaddingBottom());
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.f9538h) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = p080cOm1.y.l(drawable).mutate();
                p080cOm1.y.i(drawable, this.f3574a);
            }
            int i2 = this.f9539k;
            drawable.setBounds(0, 0, i2, i2);
        } else if (this.f9536f) {
            if (this.f3578c == null) {
                Drawable drawableF = h0.f(getResources(), a4.f8874g, getContext().getTheme());
                this.f3578c = drawableF;
                if (drawableF != null) {
                    int i3 = this.f9539k;
                    drawableF.setBounds(0, 0, i3, i3);
                }
            }
            drawable = this.f3578c;
        }
        lpt1.i(this.f3575a, drawable, null, null, null);
    }

    public void setIconPadding(int i2) {
        this.f3575a.setCompoundDrawablePadding(i2);
    }

    public void setIconSize(int i2) {
        this.f9539k = i2;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.f3574a = colorStateList;
        this.f9538h = colorStateList != null;
        com3 com3Var = this.f3577a;
        if (com3Var != null) {
            setIcon(com3Var.getIcon());
        }
    }

    public void setMaxLines(int i2) {
        this.f3575a.setMaxLines(i2);
    }

    public void setNeedsEmptyIcon(boolean z2) {
        this.f9536f = z2;
    }

    public void setTextAppearance(int i2) {
        lpt1.n(this.f3575a, i2);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f3575a.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.f3575a.setText(charSequence);
    }

    public final void z() {
        if (B()) {
            this.f3575a.setVisibility(8);
            FrameLayout frameLayout = this.f3576a;
            if (frameLayout != null) {
                con.aux auxVar = (con.aux) frameLayout.getLayoutParams();
                ((LinearLayout.LayoutParams) auxVar).width = -1;
                this.f3576a.setLayoutParams(auxVar);
                return;
            }
            return;
        }
        this.f3575a.setVisibility(0);
        FrameLayout frameLayout2 = this.f3576a;
        if (frameLayout2 != null) {
            con.aux auxVar2 = (con.aux) frameLayout2.getLayoutParams();
            ((LinearLayout.LayoutParams) auxVar2).width = -2;
            this.f3576a.setLayoutParams(auxVar2);
        }
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        aux auxVar = new aux();
        this.f9535a = auxVar;
        setOrientation(0);
        LayoutInflater.from(context).inflate(d4.f8910d, (ViewGroup) this, true);
        setIconSize(context.getResources().getDimensionPixelSize(z3.f9062e));
        CheckedTextView checkedTextView = (CheckedTextView) findViewById(b4.f8884g);
        this.f3575a = checkedTextView;
        checkedTextView.setDuplicateParentStateEnabled(true);
        y.o0(checkedTextView, auxVar);
    }
}
