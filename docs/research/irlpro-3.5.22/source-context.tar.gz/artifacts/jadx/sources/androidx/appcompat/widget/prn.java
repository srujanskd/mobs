package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.com1;
import androidx.appcompat.view.menu.com5;
import p001AuX.com3;
import p001AuX.com7;
import p001AuX.com8;
import p001AuX.lpt1;
import p001AuX.lpt3;
import p022CoN.q0;
import p022CoN.r;
import p024Com2.n0;
import p024Com2.p0;
import p024Com2.y;
import p099coN.c1;

/* JADX INFO: loaded from: classes.dex */
public class prn implements r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8010a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2145a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f2146a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Window.Callback f2147a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Toolbar f2148a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.widget.aux f2149a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2150a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2151a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8011b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Drawable f2152b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f2153b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f2154b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2155b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8012c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Drawable f2156c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f2157c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f8013d;

    public class aux implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final c1 f2158a;

        public aux() {
            this.f2158a = new c1(prn.this.f2148a.getContext(), 0, R.id.home, 0, 0, prn.this.f2150a);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            prn prnVar = prn.this;
            Window.Callback callback = prnVar.f2147a;
            if (callback == null || !prnVar.f2155b) {
                return;
            }
            callback.onMenuItemSelected(0, this.f2158a);
        }
    }

    public class con extends p0 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f8015a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2160a = false;

        public con(int i2) {
            this.f8015a = i2;
        }

        @Override // p024Com2.o0
        public void a(View view) {
            if (this.f2160a) {
                return;
            }
            prn.this.f2148a.setVisibility(this.f8015a);
        }

        @Override // p024Com2.p0, p024Com2.o0
        public void b(View view) {
            prn.this.f2148a.setVisibility(0);
        }

        @Override // p024Com2.p0, p024Com2.o0
        public void c(View view) {
            this.f2160a = true;
        }
    }

    public prn(Toolbar toolbar, boolean z2) {
        this(toolbar, z2, lpt1.f5610a, com7.f5552n);
    }

    public void A(int i2) {
        if (i2 == this.f8012c) {
            return;
        }
        this.f8012c = i2;
        if (TextUtils.isEmpty(this.f2148a.getNavigationContentDescription())) {
            C(this.f8012c);
        }
    }

    public void B(Drawable drawable) {
        this.f2152b = drawable;
        K();
    }

    public void C(int i2) {
        D(i2 == 0 ? null : i().getString(i2));
    }

    public void D(CharSequence charSequence) {
        this.f2157c = charSequence;
        I();
    }

    public void E(Drawable drawable) {
        this.f2156c = drawable;
        J();
    }

    public void F(CharSequence charSequence) {
        this.f2154b = charSequence;
        if ((this.f8010a & 8) != 0) {
            this.f2148a.setSubtitle(charSequence);
        }
    }

    public void G(CharSequence charSequence) {
        this.f2151a = true;
        H(charSequence);
    }

    public final void H(CharSequence charSequence) {
        this.f2150a = charSequence;
        if ((this.f8010a & 8) != 0) {
            this.f2148a.setTitle(charSequence);
            if (this.f2151a) {
                y.r0(this.f2148a.getRootView(), charSequence);
            }
        }
    }

    public final void I() {
        if ((this.f8010a & 4) != 0) {
            if (TextUtils.isEmpty(this.f2157c)) {
                this.f2148a.setNavigationContentDescription(this.f8012c);
            } else {
                this.f2148a.setNavigationContentDescription(this.f2157c);
            }
        }
    }

    public final void J() {
        if ((this.f8010a & 4) == 0) {
            this.f2148a.setNavigationIcon((Drawable) null);
            return;
        }
        Toolbar toolbar = this.f2148a;
        Drawable drawable = this.f2156c;
        if (drawable == null) {
            drawable = this.f8013d;
        }
        toolbar.setNavigationIcon(drawable);
    }

    public final void K() {
        Drawable drawable;
        int i2 = this.f8010a;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f2152b) == null) {
            drawable = this.f2145a;
        }
        this.f2148a.setLogo(drawable);
    }

    @Override // p022CoN.r
    public boolean a() {
        return this.f2148a.d();
    }

    @Override // p022CoN.r
    public void b(Menu menu, com5.aux auxVar) {
        if (this.f2149a == null) {
            androidx.appcompat.widget.aux auxVar2 = new androidx.appcompat.widget.aux(this.f2148a.getContext());
            this.f2149a = auxVar2;
            auxVar2.p(com8.f5571g);
        }
        this.f2149a.g(auxVar);
        this.f2148a.K((com1) menu, this.f2149a);
    }

    @Override // p022CoN.r
    public boolean c() {
        return this.f2148a.B();
    }

    @Override // p022CoN.r
    public boolean d() {
        return this.f2148a.w();
    }

    @Override // p022CoN.r
    public boolean e() {
        return this.f2148a.P();
    }

    @Override // p022CoN.r
    public void f() {
        this.f2155b = true;
    }

    @Override // p022CoN.r
    public boolean g() {
        return this.f2148a.A();
    }

    @Override // p022CoN.r
    public CharSequence getTitle() {
        return this.f2148a.getTitle();
    }

    @Override // p022CoN.r
    public boolean h() {
        return this.f2148a.v();
    }

    @Override // p022CoN.r
    public Context i() {
        return this.f2148a.getContext();
    }

    @Override // p022CoN.r
    public void j(int i2) {
        n(i2 != 0 ? AUX.aux.b(i(), i2) : null);
    }

    @Override // p022CoN.r
    public void k(int i2) {
        B(i2 != 0 ? AUX.aux.b(i(), i2) : null);
    }

    @Override // p022CoN.r
    public void l() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // p022CoN.r
    public void m() {
        this.f2148a.f();
    }

    @Override // p022CoN.r
    public void n(Drawable drawable) {
        this.f2145a = drawable;
        K();
    }

    @Override // p022CoN.r
    public int o() {
        return this.f8011b;
    }

    @Override // p022CoN.r
    public n0 p(int i2, long j2) {
        return y.e(this.f2148a).b(i2 == 0 ? 1.0f : 0.0f).f(j2).h(new con(i2));
    }

    @Override // p022CoN.r
    public void q(int i2) {
        this.f2148a.setVisibility(i2);
    }

    @Override // p022CoN.r
    public void r() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // p022CoN.r
    public void s(boolean z2) {
        this.f2148a.setCollapsible(z2);
    }

    @Override // p022CoN.r
    public void setWindowCallback(Window.Callback callback) {
        this.f2147a = callback;
    }

    @Override // p022CoN.r
    public void setWindowTitle(CharSequence charSequence) {
        if (this.f2151a) {
            return;
        }
        H(charSequence);
    }

    @Override // p022CoN.r
    public int t() {
        return this.f8010a;
    }

    @Override // p022CoN.r
    public void u(boolean z2) {
    }

    @Override // p022CoN.r
    public void v(int i2) {
        View view;
        int i3 = this.f8010a ^ i2;
        this.f8010a = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    I();
                }
                J();
            }
            if ((i3 & 3) != 0) {
                K();
            }
            if ((i3 & 8) != 0) {
                if ((i2 & 8) != 0) {
                    this.f2148a.setTitle(this.f2150a);
                    this.f2148a.setSubtitle(this.f2154b);
                } else {
                    this.f2148a.setTitle((CharSequence) null);
                    this.f2148a.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) == 0 || (view = this.f2153b) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                this.f2148a.addView(view);
            } else {
                this.f2148a.removeView(view);
            }
        }
    }

    @Override // p022CoN.r
    public void w() {
        this.f2148a.e();
    }

    @Override // p022CoN.r
    public void x(nul nulVar) {
        View view = this.f2146a;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.f2148a;
            if (parent == toolbar) {
                toolbar.removeView(this.f2146a);
            }
        }
        this.f2146a = nulVar;
        if (nulVar == null || this.f8011b != 2) {
            return;
        }
        this.f2148a.addView(nulVar, 0);
        Toolbar.com1 com1Var = (Toolbar.com1) this.f2146a.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) com1Var).width = -2;
        ((ViewGroup.MarginLayoutParams) com1Var).height = -2;
        com1Var.f7709a = 8388691;
        nulVar.setAllowCollapse(true);
    }

    public final int y() {
        if (this.f2148a.getNavigationIcon() == null) {
            return 11;
        }
        this.f8013d = this.f2148a.getNavigationIcon();
        return 15;
    }

    public void z(View view) {
        View view2 = this.f2153b;
        if (view2 != null && (this.f8010a & 16) != 0) {
            this.f2148a.removeView(view2);
        }
        this.f2153b = view;
        if (view == null || (this.f8010a & 16) == 0) {
            return;
        }
        this.f2148a.addView(view);
    }

    public prn(Toolbar toolbar, boolean z2, int i2, int i3) {
        Drawable drawable;
        this.f8011b = 0;
        this.f8012c = 0;
        this.f2148a = toolbar;
        this.f2150a = toolbar.getTitle();
        this.f2154b = toolbar.getSubtitle();
        this.f2151a = this.f2150a != null;
        this.f2156c = toolbar.getNavigationIcon();
        q0 q0VarV = q0.v(toolbar.getContext(), null, lpt3.f13a, com3.f5495c, 0);
        this.f8013d = q0VarV.g(lpt3.f5647k);
        if (z2) {
            CharSequence charSequenceP = q0VarV.p(lpt3.f5658q);
            if (!TextUtils.isEmpty(charSequenceP)) {
                G(charSequenceP);
            }
            CharSequence charSequenceP2 = q0VarV.p(lpt3.f5655o);
            if (!TextUtils.isEmpty(charSequenceP2)) {
                F(charSequenceP2);
            }
            Drawable drawableG = q0VarV.g(lpt3.f5651m);
            if (drawableG != null) {
                B(drawableG);
            }
            Drawable drawableG2 = q0VarV.g(lpt3.f5649l);
            if (drawableG2 != null) {
                n(drawableG2);
            }
            if (this.f2156c == null && (drawable = this.f8013d) != null) {
                E(drawable);
            }
            v(q0VarV.k(lpt3.f5639g, 0));
            int iN = q0VarV.n(lpt3.f5637f, 0);
            if (iN != 0) {
                z(LayoutInflater.from(this.f2148a.getContext()).inflate(iN, (ViewGroup) this.f2148a, false));
                v(this.f8010a | 16);
            }
            int iM = q0VarV.m(lpt3.f5643i, 0);
            if (iM > 0) {
                ViewGroup.LayoutParams layoutParams = this.f2148a.getLayoutParams();
                layoutParams.height = iM;
                this.f2148a.setLayoutParams(layoutParams);
            }
            int iE = q0VarV.e(lpt3.f5635e, -1);
            int iE2 = q0VarV.e(lpt3.f5633d, -1);
            if (iE >= 0 || iE2 >= 0) {
                this.f2148a.J(Math.max(iE, 0), Math.max(iE2, 0));
            }
            int iN2 = q0VarV.n(lpt3.f5659r, 0);
            if (iN2 != 0) {
                Toolbar toolbar2 = this.f2148a;
                toolbar2.M(toolbar2.getContext(), iN2);
            }
            int iN3 = q0VarV.n(lpt3.f5657p, 0);
            if (iN3 != 0) {
                Toolbar toolbar3 = this.f2148a;
                toolbar3.L(toolbar3.getContext(), iN3);
            }
            int iN4 = q0VarV.n(lpt3.f5653n, 0);
            if (iN4 != 0) {
                this.f2148a.setPopupTheme(iN4);
            }
        } else {
            this.f8010a = y();
        }
        q0VarV.w();
        A(i2);
        this.f2157c = this.f2148a.getNavigationContentDescription();
        this.f2148a.setNavigationOnClickListener(new aux());
    }
}
