package com.google.android.material.behavior;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

/* JADX INFO: loaded from: classes.dex */
public class HideBottomViewOnScrollBehavior<V extends View> extends CoordinatorLayout.nul<V> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9283a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewPropertyAnimator f3308a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f9284b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9285c;

    public class aux extends AnimatorListenerAdapter {
        public aux() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            HideBottomViewOnScrollBehavior.this.f3308a = null;
        }
    }

    public HideBottomViewOnScrollBehavior() {
        this.f9283a = 0;
        this.f9284b = 2;
        this.f9285c = 0;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean A(CoordinatorLayout coordinatorLayout, V v2, View view, View view2, int i2, int i3) {
        return i2 == 2;
    }

    public final void F(V v2, int i2, long j2, TimeInterpolator timeInterpolator) {
        this.f3308a = v2.animate().translationY(i2).setInterpolator(timeInterpolator).setDuration(j2).setListener(new aux());
    }

    public boolean G() {
        return this.f9284b == 1;
    }

    public boolean H() {
        return this.f9284b == 2;
    }

    public void I(V v2, int i2) {
        this.f9285c = i2;
        if (this.f9284b == 1) {
            v2.setTranslationY(this.f9283a + i2);
        }
    }

    public void J(V v2) {
        K(v2, true);
    }

    public void K(V v2, boolean z2) {
        if (G()) {
            return;
        }
        ViewPropertyAnimator viewPropertyAnimator = this.f3308a;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
            v2.clearAnimation();
        }
        this.f9284b = 1;
        int i2 = this.f9283a + this.f9285c;
        if (z2) {
            F(v2, i2, 175L, COM6.aux.f5702c);
        } else {
            v2.setTranslationY(i2);
        }
    }

    public void L(V v2) {
        M(v2, true);
    }

    public void M(V v2, boolean z2) {
        if (H()) {
            return;
        }
        ViewPropertyAnimator viewPropertyAnimator = this.f3308a;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
            v2.clearAnimation();
        }
        this.f9284b = 2;
        if (z2) {
            F(v2, 0, 225L, COM6.aux.f5703d);
        } else {
            v2.setTranslationY(0);
        }
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public boolean l(CoordinatorLayout coordinatorLayout, V v2, int i2) {
        this.f9283a = v2.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) v2.getLayoutParams()).bottomMargin;
        return super.l(coordinatorLayout, v2, i2);
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
    public void t(CoordinatorLayout coordinatorLayout, V v2, View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i3 > 0) {
            J(v2);
        } else if (i3 < 0) {
            L(v2);
        }
    }

    public HideBottomViewOnScrollBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f9283a = 0;
        this.f9284b = 2;
        this.f9285c = 0;
    }
}
