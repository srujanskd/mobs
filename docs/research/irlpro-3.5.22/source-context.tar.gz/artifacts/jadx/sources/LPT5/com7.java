package LPT5;

import p037LPt5.lpt7;

/* JADX INFO: loaded from: classes.dex */
public final class com7 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public double f6667a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com8 f872a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt7 f873a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public double f6668b;

    public com7(int i2) {
        this.f872a = new com8(i2);
    }

    public lpt7 a() {
        return this.f873a;
    }

    public double b() {
        return this.f6668b;
    }

    public double c() {
        return this.f6667a;
    }

    public void d(lpt7 lpt7Var, long j2) {
        this.f872a.b(lpt7Var.byteSentUnique - (lpt7Var.pktSentUnique * 44));
        this.f6668b = lpt7Var.mbpsBandwidth * 125000.0d;
        this.f6667a = this.f872a.a() / (j2 / 1000.0d);
        this.f873a = lpt7Var;
    }
}
