package androidx.recyclerview.widget;

import android.R;
import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import androidx.preference.Preference;
import com.newrelic.agent.android.analytics.AnalyticsAttribute;
import com.newrelic.agent.android.api.v1.Defaults;
import com.newrelic.agent.android.tracing.ActivityTrace;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import p024Com2.j0;
import p024Com2.m;
import p024Com2.n;
import p024Com2.o;
import p024Com2.y;
import p081cOm2.e2;
import p081cOm2.v1;
import p101com2.u2;

/* JADX INFO: loaded from: classes.dex */
public class RecyclerView extends ViewGroup implements n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Interpolator f8534a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final Class<?>[] f2705a;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int[] f8535e = {R.attr.nestedScrollingEnabled};

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final boolean f8536q = false;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final boolean f8537r = true;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final boolean f8538s = true;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final boolean f8539t = true;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final boolean f8540u = false;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public static final boolean f8541v = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f2706a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2707a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public o f2708a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f2709a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f2710a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public VelocityTracker f2711a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AccessibilityManager f2712a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public EdgeEffect f2713a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final b f2714a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public c f2715a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f2716a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com7 f2717a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com8.con f2718a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com8 f2719a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final e f2720a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final g f2721a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt2 f2722a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt5 f2723a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt6 f2724a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt7 f2725a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt9 f2726a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.recyclerview.widget.aux f2727a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.recyclerview.widget.com1.con f2728a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.recyclerview.widget.com1 f2729a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.recyclerview.widget.com7 f2730a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.recyclerview.widget.con f2731a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.recyclerview.widget.lpt3.con f2732a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.recyclerview.widget.lpt3 f2733a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2734a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<lpt1> f2735a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<lpt4> f2736a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2737a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f8542b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f2738b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Rect f2739b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public EdgeEffect f2740b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Runnable f2741b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final ArrayList<lpt6> f2742b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public List<lpt7> f2743b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2744b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int[] f2745b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8543c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public EdgeEffect f2746c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final List<h> f2747c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2748c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public final int[] f2749c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8544d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public EdgeEffect f2750d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2751d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public final int[] f2752d;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public int f2753e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2754e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8545f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f2755f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8546g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f2756g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8547h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f2757h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8548i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f2758i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8549j;

    /* JADX INFO: renamed from: j, reason: collision with other field name */
    public boolean f2759j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8550k;

    /* JADX INFO: renamed from: k, reason: collision with other field name */
    public boolean f2760k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f8551l;

    /* JADX INFO: renamed from: l, reason: collision with other field name */
    public boolean f2761l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f8552m;

    /* JADX INFO: renamed from: m, reason: collision with other field name */
    public boolean f2762m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f8553n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f8554o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f8555p;

    public interface a {
    }

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (!recyclerView.f2755f || recyclerView.isLayoutRequested()) {
                return;
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            if (!recyclerView2.f2748c) {
                recyclerView2.requestLayout();
            } else if (recyclerView2.f2757h) {
                recyclerView2.f2756g = true;
            } else {
                recyclerView2.u();
            }
        }
    }

    public class b extends com5 {
        public b() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.com5
        public void a() {
            RecyclerView.this.o(null);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f2720a.f2775a = true;
            recyclerView.Q0(true);
            if (RecyclerView.this.f2727a.p()) {
                return;
            }
            RecyclerView.this.requestLayout();
        }

        @Override // androidx.recyclerview.widget.RecyclerView.com5
        public void c(int i2, int i3, Object obj) {
            RecyclerView.this.o(null);
            if (RecyclerView.this.f2727a.r(i2, i3, obj)) {
                d();
            }
        }

        public void d() {
            if (RecyclerView.f8538s) {
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.f2751d && recyclerView.f2748c) {
                    y.g0(recyclerView, recyclerView.f2734a);
                    return;
                }
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            recyclerView2.f2759j = true;
            recyclerView2.requestLayout();
        }
    }

    public class com1 implements androidx.recyclerview.widget.con.InterfaceC0047con {
        public com1() {
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public View a(int i2) {
            return RecyclerView.this.getChildAt(i2);
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void b(int i2) {
            View childAt = RecyclerView.this.getChildAt(i2);
            if (childAt != null) {
                RecyclerView.this.z(childAt);
                childAt.clearAnimation();
            }
            RecyclerView.this.removeViewAt(i2);
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public int c() {
            return RecyclerView.this.getChildCount();
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void d(View view) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0 != null) {
                hVarG0.B(RecyclerView.this);
            }
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public int e(View view) {
            return RecyclerView.this.indexOfChild(view);
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void f(int i2) {
            h hVarG0;
            View viewA = a(i2);
            if (viewA != null && (hVarG0 = RecyclerView.g0(viewA)) != null) {
                if (hVarG0.x() && !hVarG0.J()) {
                    throw new IllegalArgumentException("called detach on an already detached child " + hVarG0 + RecyclerView.this.P());
                }
                hVarG0.b(256);
            }
            RecyclerView.this.detachViewFromParent(i2);
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public h g(View view) {
            return RecyclerView.g0(view);
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void h(View view) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0 != null) {
                hVarG0.C(RecyclerView.this);
            }
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void i(View view, int i2, ViewGroup.LayoutParams layoutParams) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0 != null) {
                if (!hVarG0.x() && !hVarG0.J()) {
                    throw new IllegalArgumentException("Called attach on a child which is not detached: " + hVarG0 + RecyclerView.this.P());
                }
                hVarG0.f();
            }
            RecyclerView.this.attachViewToParent(view, i2, layoutParams);
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void j() {
            int iC = c();
            for (int i2 = 0; i2 < iC; i2++) {
                View viewA = a(i2);
                RecyclerView.this.z(viewA);
                viewA.clearAnimation();
            }
            RecyclerView.this.removeAllViews();
        }

        @Override // androidx.recyclerview.widget.con.InterfaceC0047con
        public void k(View view, int i2) {
            RecyclerView.this.addView(view, i2);
            RecyclerView.this.y(view);
        }
    }

    public class com2 implements androidx.recyclerview.widget.aux.InterfaceC0046aux {
        public com2() {
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void a(int i2, int i3) {
            RecyclerView.this.E0(i2, i3, true);
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f8553n = true;
            recyclerView.f2720a.f8582c += i3;
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void b(int i2, int i3, Object obj) {
            RecyclerView.this.x1(i2, i3, obj);
            RecyclerView.this.f8554o = true;
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void c(androidx.recyclerview.widget.aux.con conVar) {
            i(conVar);
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public h d(int i2) {
            h hVarZ = RecyclerView.this.Z(i2, true);
            if (hVarZ == null || RecyclerView.this.f2731a.n(hVarZ.f2786a)) {
                return null;
            }
            return hVarZ;
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void e(androidx.recyclerview.widget.aux.con conVar) {
            i(conVar);
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void f(int i2, int i3) {
            RecyclerView.this.E0(i2, i3, false);
            RecyclerView.this.f8553n = true;
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void g(int i2, int i3) {
            RecyclerView.this.D0(i2, i3);
            RecyclerView.this.f8553n = true;
        }

        @Override // androidx.recyclerview.widget.aux.InterfaceC0046aux
        public void h(int i2, int i3) {
            RecyclerView.this.C0(i2, i3);
            RecyclerView.this.f8553n = true;
        }

        public void i(androidx.recyclerview.widget.aux.con conVar) {
            int i2 = conVar.f8647a;
            if (i2 == 1) {
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.f2722a.R0(recyclerView, conVar.f8648b, conVar.f8649c);
                return;
            }
            if (i2 == 2) {
                RecyclerView recyclerView2 = RecyclerView.this;
                recyclerView2.f2722a.U0(recyclerView2, conVar.f8648b, conVar.f8649c);
            } else if (i2 == 4) {
                RecyclerView recyclerView3 = RecyclerView.this;
                recyclerView3.f2722a.W0(recyclerView3, conVar.f8648b, conVar.f8649c, conVar.f2856a);
            } else {
                if (i2 != 8) {
                    return;
                }
                RecyclerView recyclerView4 = RecyclerView.this;
                recyclerView4.f2722a.T0(recyclerView4, conVar.f8648b, conVar.f8649c, 1);
            }
        }
    }

    public static abstract class com3<VH extends h> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final com4 f8561a = new com4();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2763a = false;

        public final void d(VH vh, int i2) {
            vh.f8593a = i2;
            if (j()) {
                vh.f2785a = g(i2);
            }
            vh.F(1, 519);
            p013CoM1.com8.a("RV OnBindView");
            o(vh, i2, vh.o());
            vh.d();
            ViewGroup.LayoutParams layoutParams = vh.f2786a.getLayoutParams();
            if (layoutParams instanceof lpt3) {
                ((lpt3) layoutParams).f2811a = true;
            }
            p013CoM1.com8.b();
        }

        public final VH e(ViewGroup viewGroup, int i2) {
            try {
                p013CoM1.com8.a("RV CreateView");
                VH vh = (VH) p(viewGroup, i2);
                if (vh.f2786a.getParent() != null) {
                    throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
                }
                vh.f2795c = i2;
                p013CoM1.com8.b();
                return vh;
            } catch (Throwable th) {
                p013CoM1.com8.b();
                throw th;
            }
        }

        public abstract int f();

        public long g(int i2) {
            return -1L;
        }

        public int h(int i2) {
            return 0;
        }

        public final boolean i() {
            return this.f8561a.a();
        }

        public final boolean j() {
            return this.f2763a;
        }

        public final void k() {
            this.f8561a.b();
        }

        public final void l(int i2, Object obj) {
            this.f8561a.c(i2, 1, obj);
        }

        public void m(RecyclerView recyclerView) {
        }

        public abstract void n(VH vh, int i2);

        public void o(VH vh, int i2, List<Object> list) {
            n(vh, i2);
        }

        public abstract VH p(ViewGroup viewGroup, int i2);

        public void q(RecyclerView recyclerView) {
        }

        public boolean r(VH vh) {
            return false;
        }

        public void s(VH vh) {
        }

        public void t(VH vh) {
        }

        public void u(VH vh) {
        }

        public void v(com5 com5Var) {
            this.f8561a.registerObserver(com5Var);
        }

        public void w(boolean z2) {
            if (i()) {
                throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
            }
            this.f2763a = z2;
        }

        public void x(com5 com5Var) {
            this.f8561a.unregisterObserver(com5Var);
        }
    }

    public static class com4 extends Observable<com5> {
        public boolean a() {
            return !((Observable) this).mObservers.isEmpty();
        }

        public void b() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((com5) ((Observable) this).mObservers.get(size)).a();
            }
        }

        public void c(int i2, int i3, Object obj) {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                ((com5) ((Observable) this).mObservers.get(size)).c(i2, i3, obj);
            }
        }
    }

    public static abstract class com5 {
        public void a() {
        }

        public void b(int i2, int i3) {
        }

        public void c(int i2, int i3, Object obj) {
            b(i2, i3);
        }
    }

    public interface com6 {
    }

    public static class com7 {
        public EdgeEffect a(RecyclerView recyclerView, int i2) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    public static abstract class com8 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public con f2764a = null;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ArrayList<aux> f2765a = new ArrayList<>();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public long f8562a = 120;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public long f8563b = 120;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public long f8564c = 250;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public long f8565d = 250;

        public interface aux {
            void a();
        }

        public interface con {
            void a(h hVar);
        }

        public static class nul {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public int f8566a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public int f8567b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public int f8568c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            public int f8569d;

            public nul a(h hVar) {
                return b(hVar, 0);
            }

            public nul b(h hVar, int i2) {
                View view = hVar.f2786a;
                this.f8566a = view.getLeft();
                this.f8567b = view.getTop();
                this.f8568c = view.getRight();
                this.f8569d = view.getBottom();
                return this;
            }
        }

        public static int e(h hVar) {
            int i2 = hVar.f8596e & 14;
            if (hVar.t()) {
                return 4;
            }
            if ((i2 & 4) != 0) {
                return i2;
            }
            int iN = hVar.n();
            int iJ = hVar.j();
            return (iN == -1 || iJ == -1 || iN == iJ) ? i2 : i2 | 2048;
        }

        public abstract boolean a(h hVar, nul nulVar, nul nulVar2);

        public abstract boolean b(h hVar, h hVar2, nul nulVar, nul nulVar2);

        public abstract boolean c(h hVar, nul nulVar, nul nulVar2);

        public abstract boolean d(h hVar, nul nulVar, nul nulVar2);

        public abstract boolean f(h hVar);

        public boolean g(h hVar, List<Object> list) {
            return f(hVar);
        }

        public final void h(h hVar) {
            r(hVar);
            con conVar = this.f2764a;
            if (conVar != null) {
                conVar.a(hVar);
            }
        }

        public final void i() {
            int size = this.f2765a.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f2765a.get(i2).a();
            }
            this.f2765a.clear();
        }

        public abstract void j(h hVar);

        public abstract void k();

        public long l() {
            return this.f8562a;
        }

        public long m() {
            return this.f8565d;
        }

        public long n() {
            return this.f8564c;
        }

        public long o() {
            return this.f8563b;
        }

        public abstract boolean p();

        public nul q() {
            return new nul();
        }

        public void r(h hVar) {
        }

        public nul s(e eVar, h hVar) {
            return q().a(hVar);
        }

        public nul t(e eVar, h hVar, int i2, List<Object> list) {
            return q().a(hVar);
        }

        public abstract void u();

        public void v(con conVar) {
            this.f2764a = conVar;
        }
    }

    public class com9 implements com8.con {
        public com9() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.com8.con
        public void a(h hVar) {
            hVar.G(true);
            if (hVar.f2787a != null && hVar.f2793b == null) {
                hVar.f2787a = null;
            }
            hVar.f2793b = null;
            if (hVar.I() || RecyclerView.this.W0(hVar.f2786a) || !hVar.x()) {
                return;
            }
            RecyclerView.this.removeDetachedView(hVar.f2786a, false);
        }
    }

    public class con implements Runnable {
        public con() {
        }

        @Override // java.lang.Runnable
        public void run() {
            com8 com8Var = RecyclerView.this.f2719a;
            if (com8Var != null) {
                com8Var.u();
            }
            RecyclerView.this.f8555p = false;
        }
    }

    public static abstract class d {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f2766a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public lpt2 f2768a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView f2769a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2770a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8573b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8574c;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8572a = -1;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final aux f2767a = new aux(0, 0);

        public static class aux {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public int f8575a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public Interpolator f2771a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public boolean f2772a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public int f8576b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public int f8577c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            public int f8578d;

            /* JADX INFO: renamed from: e, reason: collision with root package name */
            public int f8579e;

            public aux(int i2, int i3) {
                this(i2, i3, Integer.MIN_VALUE, null);
            }

            public boolean a() {
                return this.f8578d >= 0;
            }

            public void b(int i2) {
                this.f8578d = i2;
            }

            public void c(RecyclerView recyclerView) {
                int i2 = this.f8578d;
                if (i2 >= 0) {
                    this.f8578d = -1;
                    recyclerView.x0(i2);
                    this.f2772a = false;
                } else {
                    if (!this.f2772a) {
                        this.f8579e = 0;
                        return;
                    }
                    e();
                    recyclerView.f2721a.f(this.f8575a, this.f8576b, this.f8577c, this.f2771a);
                    int i3 = this.f8579e + 1;
                    this.f8579e = i3;
                    if (i3 > 10) {
                        Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                    }
                    this.f2772a = false;
                }
            }

            public void d(int i2, int i3, int i4, Interpolator interpolator) {
                this.f8575a = i2;
                this.f8576b = i3;
                this.f8577c = i4;
                this.f2771a = interpolator;
                this.f2772a = true;
            }

            public final void e() {
                if (this.f2771a != null && this.f8577c < 1) {
                    throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                }
                if (this.f8577c < 1) {
                    throw new IllegalStateException("Scroll duration must be a positive number");
                }
            }

            public aux(int i2, int i3, int i4, Interpolator interpolator) {
                this.f8578d = -1;
                this.f2772a = false;
                this.f8579e = 0;
                this.f8575a = i2;
                this.f8576b = i3;
                this.f8577c = i4;
                this.f2771a = interpolator;
            }
        }

        public interface con {
            PointF a(int i2);
        }

        public PointF a(int i2) {
            Object objE = e();
            if (objE instanceof con) {
                return ((con) objE).a(i2);
            }
            Log.w("RecyclerView", "You should override computeScrollVectorForPosition when the LayoutManager does not implement " + con.class.getCanonicalName());
            return null;
        }

        public View b(int i2) {
            return this.f2769a.f2722a.C(i2);
        }

        public int c() {
            return this.f2769a.f2722a.J();
        }

        public int d(View view) {
            return this.f2769a.e0(view);
        }

        public lpt2 e() {
            return this.f2768a;
        }

        public int f() {
            return this.f8572a;
        }

        public boolean g() {
            return this.f2770a;
        }

        public boolean h() {
            return this.f8573b;
        }

        public void i(PointF pointF) {
            float f2 = pointF.x;
            float f3 = pointF.y;
            float fSqrt = (float) Math.sqrt((f2 * f2) + (f3 * f3));
            pointF.x /= fSqrt;
            pointF.y /= fSqrt;
        }

        public void j(int i2, int i3) {
            PointF pointFA;
            RecyclerView recyclerView = this.f2769a;
            if (this.f8572a == -1 || recyclerView == null) {
                r();
            }
            if (this.f2770a && this.f2766a == null && this.f2768a != null && (pointFA = a(this.f8572a)) != null) {
                float f2 = pointFA.x;
                if (f2 != 0.0f || pointFA.y != 0.0f) {
                    recyclerView.h1((int) Math.signum(f2), (int) Math.signum(pointFA.y), null);
                }
            }
            this.f2770a = false;
            View view = this.f2766a;
            if (view != null) {
                if (d(view) == this.f8572a) {
                    o(this.f2766a, recyclerView.f2720a, this.f2767a);
                    this.f2767a.c(recyclerView);
                    r();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.f2766a = null;
                }
            }
            if (this.f8573b) {
                l(i2, i3, recyclerView.f2720a, this.f2767a);
                boolean zA = this.f2767a.a();
                this.f2767a.c(recyclerView);
                if (zA && this.f8573b) {
                    this.f2770a = true;
                    recyclerView.f2721a.e();
                }
            }
        }

        public void k(View view) {
            if (d(view) == f()) {
                this.f2766a = view;
            }
        }

        public abstract void l(int i2, int i3, e eVar, aux auxVar);

        public abstract void m();

        public abstract void n();

        public abstract void o(View view, e eVar, aux auxVar);

        public void p(int i2) {
            this.f8572a = i2;
        }

        public void q(RecyclerView recyclerView, lpt2 lpt2Var) {
            recyclerView.f2721a.g();
            if (this.f8574c) {
                Log.w("RecyclerView", "An instance of " + getClass().getSimpleName() + " was started more than once. Each instance of" + getClass().getSimpleName() + " is intended to only be used once. You should create a new instance for each use.");
            }
            this.f2769a = recyclerView;
            this.f2768a = lpt2Var;
            int i2 = this.f8572a;
            if (i2 == -1) {
                throw new IllegalArgumentException("Invalid target position");
            }
            recyclerView.f2720a.f8580a = i2;
            this.f8573b = true;
            this.f2770a = true;
            this.f2766a = b(f());
            m();
            this.f2769a.f2721a.e();
            this.f8574c = true;
        }

        public final void r() {
            if (this.f8573b) {
                this.f8573b = false;
                n();
                this.f2769a.f2720a.f8580a = -1;
                this.f2766a = null;
                this.f8572a = -1;
                this.f2770a = false;
                this.f2768a.f1(this);
                this.f2768a = null;
                this.f2769a = null;
            }
        }
    }

    public static class e {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public long f2773a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public SparseArray<Object> f2774a;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f8585f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f8586g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f8587h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public int f8588i;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8580a = -1;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8581b = 0;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8582c = 0;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8583d = 1;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8584e = 0;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2775a = false;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2776b = false;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2777c = false;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f2778d = false;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public boolean f2779e = false;

        /* JADX INFO: renamed from: f, reason: collision with other field name */
        public boolean f2780f = false;

        public void a(int i2) {
            if ((this.f8583d & i2) != 0) {
                return;
            }
            throw new IllegalStateException("Layout state should be one of " + Integer.toBinaryString(i2) + " but it is " + Integer.toBinaryString(this.f8583d));
        }

        public int b() {
            return this.f2776b ? this.f8581b - this.f8582c : this.f8584e;
        }

        public int c() {
            return this.f8580a;
        }

        public boolean d() {
            return this.f8580a != -1;
        }

        public boolean e() {
            return this.f2776b;
        }

        public void f(com3 com3Var) {
            this.f8583d = 1;
            this.f8584e = com3Var.f();
            this.f2776b = false;
            this.f2777c = false;
            this.f2778d = false;
        }

        public boolean g() {
            return this.f2780f;
        }

        public String toString() {
            return "State{mTargetPosition=" + this.f8580a + ", mData=" + this.f2774a + ", mItemCount=" + this.f8584e + ", mIsMeasuring=" + this.f2778d + ", mPreviousLayoutItemCount=" + this.f8581b + ", mDeletedInvisibleItemCountSincePreviousLayout=" + this.f8582c + ", mStructureChanged=" + this.f2775a + ", mInPreLayout=" + this.f2776b + ", mRunSimpleAnimations=" + this.f2779e + ", mRunPredictiveAnimations=" + this.f2780f + '}';
        }
    }

    public static abstract class f {
    }

    public class g implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8589a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Interpolator f2781a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public OverScroller f2782a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8590b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2784b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8591c;

        public g() {
            Interpolator interpolator = RecyclerView.f8534a;
            this.f2781a = interpolator;
            this.f2784b = false;
            this.f8591c = false;
            this.f2782a = new OverScroller(RecyclerView.this.getContext(), interpolator);
        }

        public final int a(int i2, int i3, int i4, int i5) {
            int iRound;
            int iAbs = Math.abs(i2);
            int iAbs2 = Math.abs(i3);
            boolean z2 = iAbs > iAbs2;
            int iSqrt = (int) Math.sqrt((i4 * i4) + (i5 * i5));
            int iSqrt2 = (int) Math.sqrt((i2 * i2) + (i3 * i3));
            RecyclerView recyclerView = RecyclerView.this;
            int width = z2 ? recyclerView.getWidth() : recyclerView.getHeight();
            int i6 = width / 2;
            float f2 = width;
            float f3 = i6;
            float fB = f3 + (b(Math.min(1.0f, (iSqrt2 * 1.0f) / f2)) * f3);
            if (iSqrt > 0) {
                iRound = Math.round(Math.abs(fB / iSqrt) * 1000.0f) * 4;
            } else {
                if (!z2) {
                    iAbs = iAbs2;
                }
                iRound = (int) (((iAbs / f2) + 1.0f) * 300.0f);
            }
            return Math.min(iRound, ActivityTrace.MAX_TRACES);
        }

        public final float b(float f2) {
            return (float) Math.sin((f2 - 0.5f) * 0.47123894f);
        }

        public void c(int i2, int i3) {
            RecyclerView.this.setScrollState(2);
            this.f8590b = 0;
            this.f8589a = 0;
            Interpolator interpolator = this.f2781a;
            Interpolator interpolator2 = RecyclerView.f8534a;
            if (interpolator != interpolator2) {
                this.f2781a = interpolator2;
                this.f2782a = new OverScroller(RecyclerView.this.getContext(), interpolator2);
            }
            this.f2782a.fling(0, 0, i2, i3, Integer.MIN_VALUE, Preference.DEFAULT_ORDER, Integer.MIN_VALUE, Preference.DEFAULT_ORDER);
            e();
        }

        public final void d() {
            RecyclerView.this.removeCallbacks(this);
            y.g0(RecyclerView.this, this);
        }

        public void e() {
            if (this.f2784b) {
                this.f8591c = true;
            } else {
                d();
            }
        }

        public void f(int i2, int i3, int i4, Interpolator interpolator) {
            if (i4 == Integer.MIN_VALUE) {
                i4 = a(i2, i3, 0, 0);
            }
            int i5 = i4;
            if (interpolator == null) {
                interpolator = RecyclerView.f8534a;
            }
            if (this.f2781a != interpolator) {
                this.f2781a = interpolator;
                this.f2782a = new OverScroller(RecyclerView.this.getContext(), interpolator);
            }
            this.f8590b = 0;
            this.f8589a = 0;
            RecyclerView.this.setScrollState(2);
            this.f2782a.startScroll(0, 0, i2, i3, i5);
            e();
        }

        public void g() {
            RecyclerView.this.removeCallbacks(this);
            this.f2782a.abortAnimation();
        }

        @Override // java.lang.Runnable
        public void run() {
            int i2;
            int i3;
            int i4;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f2722a == null) {
                g();
                return;
            }
            this.f8591c = false;
            this.f2784b = true;
            recyclerView.u();
            OverScroller overScroller = this.f2782a;
            if (overScroller.computeScrollOffset()) {
                int currX = overScroller.getCurrX();
                int currY = overScroller.getCurrY();
                int i5 = currX - this.f8589a;
                int i6 = currY - this.f8590b;
                this.f8589a = currX;
                this.f8590b = currY;
                RecyclerView recyclerView2 = RecyclerView.this;
                int[] iArr = recyclerView2.f2752d;
                iArr[0] = 0;
                iArr[1] = 0;
                if (recyclerView2.F(i5, i6, iArr, null, 1)) {
                    int[] iArr2 = RecyclerView.this.f2752d;
                    i5 -= iArr2[0];
                    i6 -= iArr2[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.t(i5, i6);
                }
                RecyclerView recyclerView3 = RecyclerView.this;
                if (recyclerView3.f2716a != null) {
                    int[] iArr3 = recyclerView3.f2752d;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView3.h1(i5, i6, iArr3);
                    RecyclerView recyclerView4 = RecyclerView.this;
                    int[] iArr4 = recyclerView4.f2752d;
                    i3 = iArr4[0];
                    i2 = iArr4[1];
                    i5 -= i3;
                    i6 -= i2;
                    d dVar = recyclerView4.f2722a.f2796a;
                    if (dVar != null && !dVar.g() && dVar.h()) {
                        int iB = RecyclerView.this.f2720a.b();
                        if (iB == 0) {
                            dVar.r();
                        } else if (dVar.f() >= iB) {
                            dVar.p(iB - 1);
                            dVar.j(i3, i2);
                        } else {
                            dVar.j(i3, i2);
                        }
                    }
                } else {
                    i2 = 0;
                    i3 = 0;
                }
                if (!RecyclerView.this.f2735a.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                int[] iArr5 = recyclerView5.f2752d;
                iArr5[0] = 0;
                iArr5[1] = 0;
                recyclerView5.G(i3, i2, i5, i6, null, 1, iArr5);
                RecyclerView recyclerView6 = RecyclerView.this;
                int[] iArr6 = recyclerView6.f2752d;
                int i7 = i5 - iArr6[0];
                int i8 = i6 - iArr6[1];
                if (i3 != 0 || i2 != 0) {
                    recyclerView6.I(i3, i2);
                }
                if (!RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                boolean z2 = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i7 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i8 != 0));
                d dVar2 = RecyclerView.this.f2722a.f2796a;
                if ((dVar2 != null && dVar2.g()) || !z2) {
                    e();
                    RecyclerView recyclerView7 = RecyclerView.this;
                    androidx.recyclerview.widget.com1 com1Var = recyclerView7.f2729a;
                    if (com1Var != null) {
                        com1Var.f(recyclerView7, i3, i2);
                    }
                } else {
                    if (RecyclerView.this.getOverScrollMode() != 2) {
                        int currVelocity = (int) overScroller.getCurrVelocity();
                        if (i7 < 0) {
                            i4 = -currVelocity;
                        } else {
                            i4 = i7 > 0 ? currVelocity : 0;
                        }
                        if (i8 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i8 <= 0) {
                            currVelocity = 0;
                        }
                        RecyclerView.this.a(i4, currVelocity);
                    }
                    if (RecyclerView.f8539t) {
                        RecyclerView.this.f2728a.b();
                    }
                }
            }
            d dVar3 = RecyclerView.this.f2722a.f2796a;
            if (dVar3 != null && dVar3.g()) {
                dVar3.j(0, 0);
            }
            this.f2784b = false;
            if (this.f8591c) {
                d();
            } else {
                RecyclerView.this.setScrollState(0);
                RecyclerView.this.u1(1);
            }
        }
    }

    public static abstract class h {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public static final List<Object> f8592c = Collections.emptyList();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final View f2786a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView f2789a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public WeakReference<RecyclerView> f2790a;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8596e;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8593a = -1;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8594b = -1;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public long f2785a = -1;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public int f2795c = -1;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8595d = -1;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public h f2787a = null;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public h f2793b = null;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public List<Object> f2791a = null;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public List<Object> f2794b = null;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f8597f = 0;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public lpt9 f2788a = null;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2792a = false;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f8598g = 0;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f8599h = -1;

        public h(View view) {
            if (view == null) {
                throw new IllegalArgumentException("itemView may not be null");
            }
            this.f2786a = view;
        }

        public void A(int i2, boolean z2) {
            if (this.f8594b == -1) {
                this.f8594b = this.f8593a;
            }
            if (this.f8595d == -1) {
                this.f8595d = this.f8593a;
            }
            if (z2) {
                this.f8595d += i2;
            }
            this.f8593a += i2;
            if (this.f2786a.getLayoutParams() != null) {
                ((lpt3) this.f2786a.getLayoutParams()).f2811a = true;
            }
        }

        public void B(RecyclerView recyclerView) {
            int i2 = this.f8599h;
            if (i2 != -1) {
                this.f8598g = i2;
            } else {
                this.f8598g = y.y(this.f2786a);
            }
            recyclerView.k1(this, 4);
        }

        public void C(RecyclerView recyclerView) {
            recyclerView.k1(this, this.f8598g);
            this.f8598g = 0;
        }

        public void D() {
            this.f8596e = 0;
            this.f8593a = -1;
            this.f8594b = -1;
            this.f2785a = -1L;
            this.f8595d = -1;
            this.f8597f = 0;
            this.f2787a = null;
            this.f2793b = null;
            d();
            this.f8598g = 0;
            this.f8599h = -1;
            RecyclerView.r(this);
        }

        public void E() {
            if (this.f8594b == -1) {
                this.f8594b = this.f8593a;
            }
        }

        public void F(int i2, int i3) {
            this.f8596e = (i2 & i3) | (this.f8596e & (~i3));
        }

        public final void G(boolean z2) {
            int i2 = this.f8597f;
            int i3 = z2 ? i2 - 1 : i2 + 1;
            this.f8597f = i3;
            if (i3 < 0) {
                this.f8597f = 0;
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
                return;
            }
            if (!z2 && i3 == 1) {
                this.f8596e |= 16;
            } else if (z2 && i3 == 0) {
                this.f8596e &= -17;
            }
        }

        public void H(lpt9 lpt9Var, boolean z2) {
            this.f2788a = lpt9Var;
            this.f2792a = z2;
        }

        public boolean I() {
            return (this.f8596e & 16) != 0;
        }

        public boolean J() {
            return (this.f8596e & 128) != 0;
        }

        public void K() {
            this.f2788a.J(this);
        }

        public boolean L() {
            return (this.f8596e & 32) != 0;
        }

        public void a(Object obj) {
            if (obj == null) {
                b(Defaults.RESPONSE_BODY_LIMIT);
            } else if ((1024 & this.f8596e) == 0) {
                g();
                this.f2791a.add(obj);
            }
        }

        public void b(int i2) {
            this.f8596e = i2 | this.f8596e;
        }

        public void c() {
            this.f8594b = -1;
            this.f8595d = -1;
        }

        public void d() {
            List<Object> list = this.f2791a;
            if (list != null) {
                list.clear();
            }
            this.f8596e &= -1025;
        }

        public void e() {
            this.f8596e &= -33;
        }

        public void f() {
            this.f8596e &= -257;
        }

        public final void g() {
            if (this.f2791a == null) {
                ArrayList arrayList = new ArrayList();
                this.f2791a = arrayList;
                this.f2794b = Collections.unmodifiableList(arrayList);
            }
        }

        public boolean h() {
            return (this.f8596e & 16) == 0 && y.P(this.f2786a);
        }

        public void i(int i2, int i3, boolean z2) {
            b(8);
            A(i3, z2);
            this.f8593a = i2;
        }

        public final int j() {
            RecyclerView recyclerView = this.f2789a;
            if (recyclerView == null) {
                return -1;
            }
            return recyclerView.b0(this);
        }

        public final long k() {
            return this.f2785a;
        }

        public final int l() {
            return this.f2795c;
        }

        public final int m() {
            int i2 = this.f8595d;
            return i2 == -1 ? this.f8593a : i2;
        }

        public final int n() {
            return this.f8594b;
        }

        public List<Object> o() {
            if ((this.f8596e & Defaults.RESPONSE_BODY_LIMIT) != 0) {
                return f8592c;
            }
            List<Object> list = this.f2791a;
            return (list == null || list.size() == 0) ? f8592c : this.f2794b;
        }

        public boolean p(int i2) {
            return (i2 & this.f8596e) != 0;
        }

        public boolean q() {
            return (this.f8596e & inet.ipaddr.ipv4.nul.com1.HEX) != 0 || t();
        }

        public boolean r() {
            return (this.f2786a.getParent() == null || this.f2786a.getParent() == this.f2789a) ? false : true;
        }

        public boolean s() {
            return (this.f8596e & 1) != 0;
        }

        public boolean t() {
            return (this.f8596e & 4) != 0;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder((getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName()) + "{" + Integer.toHexString(hashCode()) + " position=" + this.f8593a + " id=" + this.f2785a + ", oldPos=" + this.f8594b + ", pLpos:" + this.f8595d);
            if (w()) {
                sb.append(" scrap ");
                sb.append(this.f2792a ? "[changeScrap]" : "[attachedScrap]");
            }
            if (t()) {
                sb.append(" invalid");
            }
            if (!s()) {
                sb.append(" unbound");
            }
            if (z()) {
                sb.append(" update");
            }
            if (v()) {
                sb.append(" removed");
            }
            if (J()) {
                sb.append(" ignored");
            }
            if (x()) {
                sb.append(" tmpDetached");
            }
            if (!u()) {
                sb.append(" not recyclable(" + this.f8597f + ")");
            }
            if (q()) {
                sb.append(" undefined adapter position");
            }
            if (this.f2786a.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }

        public final boolean u() {
            return (this.f8596e & 16) == 0 && !y.P(this.f2786a);
        }

        public boolean v() {
            return (this.f8596e & 8) != 0;
        }

        public boolean w() {
            return this.f2788a != null;
        }

        public boolean x() {
            return (this.f8596e & 256) != 0;
        }

        public boolean y() {
            return (this.f8596e & 2) != 0;
        }

        public boolean z() {
            return (this.f8596e & 2) != 0;
        }
    }

    public static abstract class lpt1 {
        @Deprecated
        public void d(Rect rect, int i2, RecyclerView recyclerView) {
            rect.set(0, 0, 0, 0);
        }

        public void e(Rect rect, View view, RecyclerView recyclerView, e eVar) {
            d(rect, ((lpt3) view.getLayoutParams()).a(), recyclerView);
        }

        @Deprecated
        public void f(Canvas canvas, RecyclerView recyclerView) {
        }

        public void g(Canvas canvas, RecyclerView recyclerView, e eVar) {
            f(canvas, recyclerView);
        }

        @Deprecated
        public void h(Canvas canvas, RecyclerView recyclerView) {
        }

        public void i(Canvas canvas, RecyclerView recyclerView, e eVar) {
            h(canvas, recyclerView);
        }
    }

    public static abstract class lpt2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8600a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public d f2796a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView f2797a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.recyclerview.widget.con f2798a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final androidx.recyclerview.widget.lpt2.con f2799a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.recyclerview.widget.lpt2 f2800a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2801a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8601b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final androidx.recyclerview.widget.lpt2.con f2802b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public androidx.recyclerview.widget.lpt2 f2803b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2804b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8602c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2805c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8603d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f2806d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8604e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public boolean f2807e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public boolean f8605f;

        public class aux implements androidx.recyclerview.widget.lpt2.con {
            public aux() {
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public View a(int i2) {
                return lpt2.this.I(i2);
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int b(View view) {
                return lpt2.this.Q(view) - ((ViewGroup.MarginLayoutParams) ((lpt3) view.getLayoutParams())).leftMargin;
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int c() {
                return lpt2.this.e0();
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int d() {
                return lpt2.this.o0() - lpt2.this.f0();
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int e(View view) {
                return lpt2.this.T(view) + ((ViewGroup.MarginLayoutParams) ((lpt3) view.getLayoutParams())).rightMargin;
            }
        }

        public class con implements androidx.recyclerview.widget.lpt2.con {
            public con() {
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public View a(int i2) {
                return lpt2.this.I(i2);
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int b(View view) {
                return lpt2.this.U(view) - ((ViewGroup.MarginLayoutParams) ((lpt3) view.getLayoutParams())).topMargin;
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int c() {
                return lpt2.this.g0();
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int d() {
                return lpt2.this.W() - lpt2.this.d0();
            }

            @Override // androidx.recyclerview.widget.lpt2.con
            public int e(View view) {
                return lpt2.this.O(view) + ((ViewGroup.MarginLayoutParams) ((lpt3) view.getLayoutParams())).bottomMargin;
            }
        }

        public interface nul {
            void a(int i2, int i3);
        }

        public static class prn {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public int f8608a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public boolean f2808a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public int f8609b;

            /* JADX INFO: renamed from: b, reason: collision with other field name */
            public boolean f2809b;
        }

        public lpt2() {
            aux auxVar = new aux();
            this.f2799a = auxVar;
            con conVar = new con();
            this.f2802b = conVar;
            this.f2800a = new androidx.recyclerview.widget.lpt2(auxVar);
            this.f2803b = new androidx.recyclerview.widget.lpt2(conVar);
            this.f2801a = false;
            this.f2804b = false;
            this.f2805c = false;
            this.f2806d = true;
            this.f2807e = true;
        }

        /* JADX WARN: Code duplicated, block: B:12:0x001c  */
        /* JADX WARN: Code duplicated, block: B:14:0x0020  */
        /* JADX WARN: Code duplicated, block: B:21:0x002f  */
        public static int K(int i2, int i3, int i4, int i5, boolean z2) {
            int iMax = Math.max(0, i2 - i4);
            if (z2) {
                if (i5 >= 0) {
                    i3 = 1073741824;
                } else if (i5 != -1 || (i3 != Integer.MIN_VALUE && (i3 == 0 || i3 != 1073741824))) {
                    i3 = 0;
                    i5 = 0;
                } else {
                    i5 = iMax;
                }
            } else if (i5 >= 0) {
                i3 = 1073741824;
            } else if (i5 == -1) {
                i5 = iMax;
            } else if (i5 != -2) {
                i3 = 0;
                i5 = 0;
            } else if (i3 == Integer.MIN_VALUE || i3 == 1073741824) {
                i5 = iMax;
                i3 = Integer.MIN_VALUE;
            } else {
                i5 = iMax;
                i3 = 0;
            }
            return View.MeasureSpec.makeMeasureSpec(i5, i3);
        }

        public static prn i0(Context context, AttributeSet attributeSet, int i2, int i3) {
            prn prnVar = new prn();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p073cOM4.b.f3049f, i2, i3);
            prnVar.f8608a = typedArrayObtainStyledAttributes.getInt(p073cOM4.b.f8855a, 1);
            prnVar.f8609b = typedArrayObtainStyledAttributes.getInt(p073cOM4.b.f8865k, 1);
            prnVar.f2808a = typedArrayObtainStyledAttributes.getBoolean(p073cOM4.b.f8864j, false);
            prnVar.f2809b = typedArrayObtainStyledAttributes.getBoolean(p073cOM4.b.f8866l, false);
            typedArrayObtainStyledAttributes.recycle();
            return prnVar;
        }

        public static int n(int i2, int i3, int i4) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (mode != Integer.MIN_VALUE) {
                return mode != 1073741824 ? Math.max(i3, i4) : size;
            }
            return Math.min(size, Math.max(i3, i4));
        }

        public static boolean w0(int i2, int i3, int i4) {
            int mode = View.MeasureSpec.getMode(i3);
            int size = View.MeasureSpec.getSize(i3);
            if (i4 > 0 && i2 != i4) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                return size >= i2;
            }
            if (mode != 0) {
                return mode == 1073741824 && size == i2;
            }
            return true;
        }

        public void A(RecyclerView recyclerView, lpt9 lpt9Var) {
            this.f2804b = false;
            I0(recyclerView, lpt9Var);
        }

        public void A0(View view, int i2, int i3) {
            lpt3 lpt3Var = (lpt3) view.getLayoutParams();
            Rect rectK0 = this.f2797a.k0(view);
            int i4 = i2 + rectK0.left + rectK0.right;
            int i5 = i3 + rectK0.top + rectK0.bottom;
            int iK = K(o0(), p0(), e0() + f0() + ((ViewGroup.MarginLayoutParams) lpt3Var).leftMargin + ((ViewGroup.MarginLayoutParams) lpt3Var).rightMargin + i4, ((ViewGroup.MarginLayoutParams) lpt3Var).width, k());
            int iK2 = K(W(), X(), g0() + d0() + ((ViewGroup.MarginLayoutParams) lpt3Var).topMargin + ((ViewGroup.MarginLayoutParams) lpt3Var).bottomMargin + i5, ((ViewGroup.MarginLayoutParams) lpt3Var).height, l());
            if (F1(view, iK, iK2, lpt3Var)) {
                view.measure(iK, iK2);
            }
        }

        public void A1(int i2, int i3) {
            this.f8603d = View.MeasureSpec.getSize(i2);
            int mode = View.MeasureSpec.getMode(i2);
            this.f8601b = mode;
            if (mode == 0 && !RecyclerView.f8537r) {
                this.f8603d = 0;
            }
            this.f8604e = View.MeasureSpec.getSize(i3);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.f8602c = mode2;
            if (mode2 != 0 || RecyclerView.f8537r) {
                return;
            }
            this.f8604e = 0;
        }

        public View B(View view) {
            View viewR;
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null || (viewR = recyclerView.R(view)) == null || this.f2798a.n(viewR)) {
                return null;
            }
            return viewR;
        }

        public void B0(int i2, int i3) {
            View viewI = I(i2);
            if (viewI != null) {
                x(i2);
                h(viewI, i3);
            } else {
                throw new IllegalArgumentException("Cannot move a child from non-existing index:" + i2 + this.f2797a.toString());
            }
        }

        public void B1(int i2, int i3) {
            this.f2797a.setMeasuredDimension(i2, i3);
        }

        public View C(int i2) {
            int iJ = J();
            for (int i3 = 0; i3 < iJ; i3++) {
                View viewI = I(i3);
                h hVarG0 = RecyclerView.g0(viewI);
                if (hVarG0 != null && hVarG0.m() == i2 && !hVarG0.J() && (this.f2797a.f2720a.e() || !hVarG0.v())) {
                    return viewI;
                }
            }
            return null;
        }

        public void C0(int i2) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                recyclerView.A0(i2);
            }
        }

        public void C1(Rect rect, int i2, int i3) {
            B1(n(i2, rect.width() + e0() + f0(), c0()), n(i3, rect.height() + g0() + d0(), b0()));
        }

        public abstract lpt3 D();

        public void D0(int i2) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                recyclerView.B0(i2);
            }
        }

        public void D1(int i2, int i3) {
            int iJ = J();
            if (iJ == 0) {
                this.f2797a.w(i2, i3);
                return;
            }
            int i4 = Integer.MIN_VALUE;
            int i5 = Integer.MAX_VALUE;
            int i6 = Integer.MIN_VALUE;
            int i7 = Integer.MAX_VALUE;
            for (int i8 = 0; i8 < iJ; i8++) {
                View viewI = I(i8);
                Rect rect = this.f2797a.f2709a;
                P(viewI, rect);
                int i9 = rect.left;
                if (i9 < i7) {
                    i7 = i9;
                }
                int i10 = rect.right;
                if (i10 > i4) {
                    i4 = i10;
                }
                int i11 = rect.top;
                if (i11 < i5) {
                    i5 = i11;
                }
                int i12 = rect.bottom;
                if (i12 > i6) {
                    i6 = i12;
                }
            }
            this.f2797a.f2709a.set(i7, i5, i4, i6);
            C1(this.f2797a.f2709a, i2, i3);
        }

        public lpt3 E(Context context, AttributeSet attributeSet) {
            return new lpt3(context, attributeSet);
        }

        public void E0(com3 com3Var, com3 com3Var2) {
        }

        public void E1(RecyclerView recyclerView) {
            if (recyclerView == null) {
                this.f2797a = null;
                this.f2798a = null;
                this.f8603d = 0;
                this.f8604e = 0;
            } else {
                this.f2797a = recyclerView;
                this.f2798a = recyclerView.f2731a;
                this.f8603d = recyclerView.getWidth();
                this.f8604e = recyclerView.getHeight();
            }
            this.f8601b = 1073741824;
            this.f8602c = 1073741824;
        }

        public lpt3 F(ViewGroup.LayoutParams layoutParams) {
            if (layoutParams instanceof lpt3) {
                return new lpt3((lpt3) layoutParams);
            }
            return layoutParams instanceof ViewGroup.MarginLayoutParams ? new lpt3((ViewGroup.MarginLayoutParams) layoutParams) : new lpt3(layoutParams);
        }

        public boolean F0(RecyclerView recyclerView, ArrayList<View> arrayList, int i2, int i3) {
            return false;
        }

        public boolean F1(View view, int i2, int i3, lpt3 lpt3Var) {
            return (!view.isLayoutRequested() && this.f2806d && w0(view.getWidth(), i2, ((ViewGroup.MarginLayoutParams) lpt3Var).width) && w0(view.getHeight(), i3, ((ViewGroup.MarginLayoutParams) lpt3Var).height)) ? false : true;
        }

        public int G() {
            return -1;
        }

        public void G0(RecyclerView recyclerView) {
        }

        public boolean G1() {
            return false;
        }

        public int H(View view) {
            return ((lpt3) view.getLayoutParams()).f8610a.bottom;
        }

        @Deprecated
        public void H0(RecyclerView recyclerView) {
        }

        public boolean H1(View view, int i2, int i3, lpt3 lpt3Var) {
            return (this.f2806d && w0(view.getMeasuredWidth(), i2, ((ViewGroup.MarginLayoutParams) lpt3Var).width) && w0(view.getMeasuredHeight(), i3, ((ViewGroup.MarginLayoutParams) lpt3Var).height)) ? false : true;
        }

        public View I(int i2) {
            androidx.recyclerview.widget.con conVar = this.f2798a;
            if (conVar != null) {
                return conVar.f(i2);
            }
            return null;
        }

        public void I0(RecyclerView recyclerView, lpt9 lpt9Var) {
            H0(recyclerView);
        }

        public void I1(RecyclerView recyclerView, e eVar, int i2) {
            Log.e("RecyclerView", "You must override smoothScrollToPosition to support smooth scrolling");
        }

        public int J() {
            androidx.recyclerview.widget.con conVar = this.f2798a;
            if (conVar != null) {
                return conVar.g();
            }
            return 0;
        }

        public View J0(View view, int i2, lpt9 lpt9Var, e eVar) {
            return null;
        }

        public void J1(d dVar) {
            d dVar2 = this.f2796a;
            if (dVar2 != null && dVar != dVar2 && dVar2.h()) {
                this.f2796a.r();
            }
            this.f2796a = dVar;
            dVar.q(this.f2797a, this);
        }

        public void K0(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f2797a;
            L0(recyclerView.f2726a, recyclerView.f2720a, accessibilityEvent);
        }

        public void K1() {
            d dVar = this.f2796a;
            if (dVar != null) {
                dVar.r();
            }
        }

        public final int[] L(View view, Rect rect) {
            int[] iArr = new int[2];
            int iE0 = e0();
            int iG0 = g0();
            int iO0 = o0() - f0();
            int iW = W() - d0();
            int left = (view.getLeft() + rect.left) - view.getScrollX();
            int top = (view.getTop() + rect.top) - view.getScrollY();
            int iWidth = rect.width() + left;
            int iHeight = rect.height() + top;
            int i2 = left - iE0;
            int iMin = Math.min(0, i2);
            int i3 = top - iG0;
            int iMin2 = Math.min(0, i3);
            int i4 = iWidth - iO0;
            int iMax = Math.max(0, i4);
            int iMax2 = Math.max(0, iHeight - iW);
            if (Z() != 1) {
                if (iMin == 0) {
                    iMin = Math.min(i2, iMax);
                }
                iMax = iMin;
            } else if (iMax == 0) {
                iMax = Math.max(iMin, i4);
            }
            if (iMin2 == 0) {
                iMin2 = Math.min(i3, iMax2);
            }
            iArr[0] = iMax;
            iArr[1] = iMin2;
            return iArr;
        }

        public void L0(lpt9 lpt9Var, e eVar, AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null || accessibilityEvent == null) {
                return;
            }
            boolean z2 = true;
            if (!recyclerView.canScrollVertically(1) && !this.f2797a.canScrollVertically(-1) && !this.f2797a.canScrollHorizontally(-1) && !this.f2797a.canScrollHorizontally(1)) {
                z2 = false;
            }
            accessibilityEvent.setScrollable(z2);
            com3 com3Var = this.f2797a.f2716a;
            if (com3Var != null) {
                accessibilityEvent.setItemCount(com3Var.f());
            }
        }

        public boolean L1() {
            return false;
        }

        public boolean M() {
            RecyclerView recyclerView = this.f2797a;
            return recyclerView != null && recyclerView.f2744b;
        }

        public void M0(lpt9 lpt9Var, e eVar, e2 e2Var) {
            if (this.f2797a.canScrollVertically(-1) || this.f2797a.canScrollHorizontally(-1)) {
                e2Var.a(8192);
                e2Var.p0(true);
            }
            if (this.f2797a.canScrollVertically(1) || this.f2797a.canScrollHorizontally(1)) {
                e2Var.a(AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH);
                e2Var.p0(true);
            }
            e2Var.V(e2.con.a(k0(lpt9Var, eVar), N(lpt9Var, eVar), v0(lpt9Var, eVar), l0(lpt9Var, eVar)));
        }

        public int N(lpt9 lpt9Var, e eVar) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null || recyclerView.f2716a == null || !k()) {
                return 1;
            }
            return this.f2797a.f2716a.f();
        }

        public void N0(e2 e2Var) {
            RecyclerView recyclerView = this.f2797a;
            M0(recyclerView.f2726a, recyclerView.f2720a, e2Var);
        }

        public int O(View view) {
            return view.getBottom() + H(view);
        }

        public void O0(View view, e2 e2Var) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0 == null || hVarG0.v() || this.f2798a.n(hVarG0.f2786a)) {
                return;
            }
            RecyclerView recyclerView = this.f2797a;
            P0(recyclerView.f2726a, recyclerView.f2720a, view, e2Var);
        }

        public void P(View view, Rect rect) {
            RecyclerView.h0(view, rect);
        }

        public void P0(lpt9 lpt9Var, e eVar, View view, e2 e2Var) {
            e2Var.W(e2.nul.a(l() ? h0(view) : 0, 1, k() ? h0(view) : 0, 1, false, false));
        }

        public int Q(View view) {
            return view.getLeft() - a0(view);
        }

        public View Q0(View view, int i2) {
            return null;
        }

        public int R(View view) {
            Rect rect = ((lpt3) view.getLayoutParams()).f8610a;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        public void R0(RecyclerView recyclerView, int i2, int i3) {
        }

        public int S(View view) {
            Rect rect = ((lpt3) view.getLayoutParams()).f8610a;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        public void S0(RecyclerView recyclerView) {
        }

        public int T(View view) {
            return view.getRight() + j0(view);
        }

        public void T0(RecyclerView recyclerView, int i2, int i3, int i4) {
        }

        public int U(View view) {
            return view.getTop() - m0(view);
        }

        public void U0(RecyclerView recyclerView, int i2, int i3) {
        }

        public View V() {
            View focusedChild;
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.f2798a.n(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        public void V0(RecyclerView recyclerView, int i2, int i3) {
        }

        public int W() {
            return this.f8604e;
        }

        public void W0(RecyclerView recyclerView, int i2, int i3, Object obj) {
            V0(recyclerView, i2, i3);
        }

        public int X() {
            return this.f8602c;
        }

        public void X0(lpt9 lpt9Var, e eVar) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        public int Y() {
            RecyclerView recyclerView = this.f2797a;
            com3 adapter = recyclerView != null ? recyclerView.getAdapter() : null;
            if (adapter != null) {
                return adapter.f();
            }
            return 0;
        }

        public void Y0(e eVar) {
        }

        public int Z() {
            return y.A(this.f2797a);
        }

        public void Z0(lpt9 lpt9Var, e eVar, int i2, int i3) {
            this.f2797a.w(i2, i3);
        }

        public int a0(View view) {
            return ((lpt3) view.getLayoutParams()).f8610a.left;
        }

        @Deprecated
        public boolean a1(RecyclerView recyclerView, View view, View view2) {
            return x0() || recyclerView.v0();
        }

        public void b(View view) {
            c(view, -1);
        }

        public int b0() {
            return y.B(this.f2797a);
        }

        public boolean b1(RecyclerView recyclerView, e eVar, View view, View view2) {
            return a1(recyclerView, view, view2);
        }

        public void c(View view, int i2) {
            f(view, i2, true);
        }

        public int c0() {
            return y.C(this.f2797a);
        }

        public void c1(Parcelable parcelable) {
        }

        public void d(View view) {
            e(view, -1);
        }

        public int d0() {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                return recyclerView.getPaddingBottom();
            }
            return 0;
        }

        public Parcelable d1() {
            return null;
        }

        public void e(View view, int i2) {
            f(view, i2, false);
        }

        public int e0() {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                return recyclerView.getPaddingLeft();
            }
            return 0;
        }

        public void e1(int i2) {
        }

        public final void f(View view, int i2, boolean z2) {
            h hVarG0 = RecyclerView.g0(view);
            if (z2 || hVarG0.v()) {
                this.f2797a.f2733a.b(hVarG0);
            } else {
                this.f2797a.f2733a.p(hVarG0);
            }
            lpt3 lpt3Var = (lpt3) view.getLayoutParams();
            if (hVarG0.L() || hVarG0.w()) {
                if (hVarG0.w()) {
                    hVarG0.K();
                } else {
                    hVarG0.e();
                }
                this.f2798a.c(view, i2, view.getLayoutParams(), false);
            } else if (view.getParent() == this.f2797a) {
                int iM = this.f2798a.m(view);
                if (i2 == -1) {
                    i2 = this.f2798a.g();
                }
                if (iM == -1) {
                    throw new IllegalStateException("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:" + this.f2797a.indexOfChild(view) + this.f2797a.P());
                }
                if (iM != i2) {
                    this.f2797a.f2722a.B0(iM, i2);
                }
            } else {
                this.f2798a.a(view, i2, false);
                lpt3Var.f2811a = true;
                d dVar = this.f2796a;
                if (dVar != null && dVar.h()) {
                    this.f2796a.k(view);
                }
            }
            if (lpt3Var.f8611b) {
                hVarG0.f2786a.invalidate();
                lpt3Var.f8611b = false;
            }
        }

        public int f0() {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                return recyclerView.getPaddingRight();
            }
            return 0;
        }

        public void f1(d dVar) {
            if (this.f2796a == dVar) {
                this.f2796a = null;
            }
        }

        public void g(String str) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                recyclerView.o(str);
            }
        }

        public int g0() {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                return recyclerView.getPaddingTop();
            }
            return 0;
        }

        public boolean g1(int i2, Bundle bundle) {
            RecyclerView recyclerView = this.f2797a;
            return h1(recyclerView.f2726a, recyclerView.f2720a, i2, bundle);
        }

        public void h(View view, int i2) {
            i(view, i2, (lpt3) view.getLayoutParams());
        }

        public int h0(View view) {
            return ((lpt3) view.getLayoutParams()).a();
        }

        /* JADX WARN: Code duplicated, block: B:25:0x0071 A[PHI: r8
          0x0071: PHI (r8v8 int) = (r8v4 int), (r8v12 int) binds: [B:22:0x005e, B:15:0x0030] A[DONT_GENERATE, DONT_INLINE]] */
        public boolean h1(lpt9 lpt9Var, e eVar, int i2, Bundle bundle) {
            int iW;
            int iO0;
            int i3;
            int i4;
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null) {
                return false;
            }
            if (i2 == 4096) {
                iW = recyclerView.canScrollVertically(1) ? (W() - g0()) - d0() : 0;
                if (this.f2797a.canScrollHorizontally(1)) {
                    iO0 = (o0() - e0()) - f0();
                    i3 = iW;
                    i4 = iO0;
                } else {
                    i3 = iW;
                    i4 = 0;
                }
            } else if (i2 != 8192) {
                i4 = 0;
                i3 = 0;
            } else {
                iW = recyclerView.canScrollVertically(-1) ? -((W() - g0()) - d0()) : 0;
                if (this.f2797a.canScrollHorizontally(-1)) {
                    iO0 = -((o0() - e0()) - f0());
                    i3 = iW;
                    i4 = iO0;
                } else {
                    i3 = iW;
                    i4 = 0;
                }
            }
            if (i3 == 0 && i4 == 0) {
                return false;
            }
            this.f2797a.p1(i4, i3, null, Integer.MIN_VALUE, true);
            return true;
        }

        public void i(View view, int i2, lpt3 lpt3Var) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0.v()) {
                this.f2797a.f2733a.b(hVarG0);
            } else {
                this.f2797a.f2733a.p(hVarG0);
            }
            this.f2798a.c(view, i2, lpt3Var, hVarG0.v());
        }

        public boolean i1(View view, int i2, Bundle bundle) {
            RecyclerView recyclerView = this.f2797a;
            return j1(recyclerView.f2726a, recyclerView.f2720a, view, i2, bundle);
        }

        public void j(View view, Rect rect) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(recyclerView.k0(view));
            }
        }

        public int j0(View view) {
            return ((lpt3) view.getLayoutParams()).f8610a.right;
        }

        public boolean j1(lpt9 lpt9Var, e eVar, View view, int i2, Bundle bundle) {
            return false;
        }

        public boolean k() {
            return false;
        }

        public int k0(lpt9 lpt9Var, e eVar) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView == null || recyclerView.f2716a == null || !l()) {
                return 1;
            }
            return this.f2797a.f2716a.f();
        }

        public void k1(lpt9 lpt9Var) {
            for (int iJ = J() - 1; iJ >= 0; iJ--) {
                if (!RecyclerView.g0(I(iJ)).J()) {
                    n1(iJ, lpt9Var);
                }
            }
        }

        public boolean l() {
            return false;
        }

        public int l0(lpt9 lpt9Var, e eVar) {
            return 0;
        }

        public void l1(lpt9 lpt9Var) {
            int iJ = lpt9Var.j();
            for (int i2 = iJ - 1; i2 >= 0; i2--) {
                View viewN = lpt9Var.n(i2);
                h hVarG0 = RecyclerView.g0(viewN);
                if (!hVarG0.J()) {
                    hVarG0.G(false);
                    if (hVarG0.x()) {
                        this.f2797a.removeDetachedView(viewN, false);
                    }
                    com8 com8Var = this.f2797a.f2719a;
                    if (com8Var != null) {
                        com8Var.j(hVarG0);
                    }
                    hVarG0.G(true);
                    lpt9Var.y(viewN);
                }
            }
            lpt9Var.e();
            if (iJ > 0) {
                this.f2797a.invalidate();
            }
        }

        public boolean m(lpt3 lpt3Var) {
            return lpt3Var != null;
        }

        public int m0(View view) {
            return ((lpt3) view.getLayoutParams()).f8610a.top;
        }

        public void m1(View view, lpt9 lpt9Var) {
            p1(view);
            lpt9Var.B(view);
        }

        public void n0(View view, boolean z2, Rect rect) {
            Matrix matrix;
            if (z2) {
                Rect rect2 = ((lpt3) view.getLayoutParams()).f8610a;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (this.f2797a != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
                RectF rectF = this.f2797a.f2710a;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        public void n1(int i2, lpt9 lpt9Var) {
            View viewI = I(i2);
            q1(i2);
            lpt9Var.B(viewI);
        }

        public void o(int i2, int i3, e eVar, nul nulVar) {
        }

        public int o0() {
            return this.f8603d;
        }

        public boolean o1(Runnable runnable) {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                return recyclerView.removeCallbacks(runnable);
            }
            return false;
        }

        public void p(int i2, nul nulVar) {
        }

        public int p0() {
            return this.f8601b;
        }

        public void p1(View view) {
            this.f2798a.p(view);
        }

        public int q(e eVar) {
            return 0;
        }

        public boolean q0() {
            int iJ = J();
            for (int i2 = 0; i2 < iJ; i2++) {
                ViewGroup.LayoutParams layoutParams = I(i2).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
            return false;
        }

        public void q1(int i2) {
            if (I(i2) != null) {
                this.f2798a.q(i2);
            }
        }

        public int r(e eVar) {
            return 0;
        }

        public boolean r0() {
            return this.f2804b;
        }

        public boolean r1(RecyclerView recyclerView, View view, Rect rect, boolean z2) {
            return s1(recyclerView, view, rect, z2, false);
        }

        public int s(e eVar) {
            return 0;
        }

        public boolean s0() {
            return this.f2805c;
        }

        public boolean s1(RecyclerView recyclerView, View view, Rect rect, boolean z2, boolean z3) {
            int[] iArrL = L(view, rect);
            int i2 = iArrL[0];
            int i3 = iArrL[1];
            if ((z3 && !t0(recyclerView, i2, i3)) || (i2 == 0 && i3 == 0)) {
                return false;
            }
            if (z2) {
                recyclerView.scrollBy(i2, i3);
            } else {
                recyclerView.m1(i2, i3);
            }
            return true;
        }

        public int t(e eVar) {
            return 0;
        }

        public final boolean t0(RecyclerView recyclerView, int i2, int i3) {
            View focusedChild = recyclerView.getFocusedChild();
            if (focusedChild == null) {
                return false;
            }
            int iE0 = e0();
            int iG0 = g0();
            int iO0 = o0() - f0();
            int iW = W() - d0();
            Rect rect = this.f2797a.f2709a;
            P(focusedChild, rect);
            return rect.left - i2 < iO0 && rect.right - i2 > iE0 && rect.top - i3 < iW && rect.bottom - i3 > iG0;
        }

        public void t1() {
            RecyclerView recyclerView = this.f2797a;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        public int u(e eVar) {
            return 0;
        }

        public final boolean u0() {
            return this.f2807e;
        }

        public void u1() {
            this.f2801a = true;
        }

        public int v(e eVar) {
            return 0;
        }

        public boolean v0(lpt9 lpt9Var, e eVar) {
            return false;
        }

        public final void v1(lpt9 lpt9Var, int i2, View view) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0.J()) {
                return;
            }
            if (hVarG0.t() && !hVarG0.v() && !this.f2797a.f2716a.j()) {
                q1(i2);
                lpt9Var.C(hVarG0);
            } else {
                x(i2);
                lpt9Var.D(view);
                this.f2797a.f2733a.k(hVarG0);
            }
        }

        public void w(lpt9 lpt9Var) {
            for (int iJ = J() - 1; iJ >= 0; iJ--) {
                v1(lpt9Var, iJ, I(iJ));
            }
        }

        public int w1(int i2, lpt9 lpt9Var, e eVar) {
            return 0;
        }

        public void x(int i2) {
            y(i2, I(i2));
        }

        public boolean x0() {
            d dVar = this.f2796a;
            return dVar != null && dVar.h();
        }

        public void x1(int i2) {
        }

        public final void y(int i2, View view) {
            this.f2798a.d(i2);
        }

        public boolean y0(View view, boolean z2, boolean z3) {
            boolean z4 = this.f2800a.b(view, 24579) && this.f2803b.b(view, 24579);
            return z2 ? z4 : !z4;
        }

        public int y1(int i2, lpt9 lpt9Var, e eVar) {
            return 0;
        }

        public void z(RecyclerView recyclerView) {
            this.f2804b = true;
            G0(recyclerView);
        }

        public void z0(View view, int i2, int i3, int i4, int i5) {
            lpt3 lpt3Var = (lpt3) view.getLayoutParams();
            Rect rect = lpt3Var.f8610a;
            view.layout(i2 + rect.left + ((ViewGroup.MarginLayoutParams) lpt3Var).leftMargin, i3 + rect.top + ((ViewGroup.MarginLayoutParams) lpt3Var).topMargin, (i4 - rect.right) - ((ViewGroup.MarginLayoutParams) lpt3Var).rightMargin, (i5 - rect.bottom) - ((ViewGroup.MarginLayoutParams) lpt3Var).bottomMargin);
        }

        public void z1(RecyclerView recyclerView) {
            A1(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }
    }

    public interface lpt4 {
        void a(View view);

        void b(View view);
    }

    public static abstract class lpt5 {
        public abstract boolean a(int i2, int i3);
    }

    public interface lpt6 {
        boolean a(RecyclerView recyclerView, MotionEvent motionEvent);

        void b(boolean z2);

        void c(RecyclerView recyclerView, MotionEvent motionEvent);
    }

    public static abstract class lpt7 {
        public void a(RecyclerView recyclerView, int i2) {
        }

        public void b(RecyclerView recyclerView, int i2, int i3) {
        }
    }

    public static class lpt8 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public SparseArray<aux> f2812a = new SparseArray<>();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8612a = 0;

        public static class aux {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final ArrayList<h> f2814a = new ArrayList<>();

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public int f8613a = 5;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public long f2813a = 0;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public long f8614b = 0;
        }

        public void a() {
            this.f8612a++;
        }

        public void b() {
            for (int i2 = 0; i2 < this.f2812a.size(); i2++) {
                this.f2812a.valueAt(i2).f2814a.clear();
            }
        }

        public void c() {
            this.f8612a--;
        }

        public void d(int i2, long j2) {
            aux auxVarG = g(i2);
            auxVarG.f8614b = j(auxVarG.f8614b, j2);
        }

        public void e(int i2, long j2) {
            aux auxVarG = g(i2);
            auxVarG.f2813a = j(auxVarG.f2813a, j2);
        }

        public h f(int i2) {
            aux auxVar = this.f2812a.get(i2);
            if (auxVar == null || auxVar.f2814a.isEmpty()) {
                return null;
            }
            ArrayList<h> arrayList = auxVar.f2814a;
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                if (!arrayList.get(size).r()) {
                    return arrayList.remove(size);
                }
            }
            return null;
        }

        public final aux g(int i2) {
            aux auxVar = this.f2812a.get(i2);
            if (auxVar != null) {
                return auxVar;
            }
            aux auxVar2 = new aux();
            this.f2812a.put(i2, auxVar2);
            return auxVar2;
        }

        public void h(com3 com3Var, com3 com3Var2, boolean z2) {
            if (com3Var != null) {
                c();
            }
            if (!z2 && this.f8612a == 0) {
                b();
            }
            if (com3Var2 != null) {
                a();
            }
        }

        public void i(h hVar) {
            int iL = hVar.l();
            ArrayList<h> arrayList = g(iL).f2814a;
            if (this.f2812a.get(iL).f8613a <= arrayList.size()) {
                return;
            }
            hVar.D();
            arrayList.add(hVar);
        }

        public long j(long j2, long j3) {
            return j2 == 0 ? j3 : ((j2 / 4) * 3) + (j3 / 4);
        }

        public boolean k(int i2, long j2, long j3) {
            long j4 = g(i2).f8614b;
            return j4 == 0 || j2 + j4 < j3;
        }

        public boolean l(int i2, long j2, long j3) {
            long j4 = g(i2).f2813a;
            return j4 == 0 || j2 + j4 < j3;
        }
    }

    public final class lpt9 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8615a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public lpt8 f2815a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final ArrayList<h> f2817a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final List<h> f2818a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8616b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public ArrayList<h> f2819b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final ArrayList<h> f8617c;

        public lpt9() {
            ArrayList<h> arrayList = new ArrayList<>();
            this.f2817a = arrayList;
            this.f2819b = null;
            this.f8617c = new ArrayList<>();
            this.f2818a = Collections.unmodifiableList(arrayList);
            this.f8615a = 2;
            this.f8616b = 2;
        }

        public void A(int i2) {
            a(this.f8617c.get(i2), true);
            this.f8617c.remove(i2);
        }

        public void B(View view) {
            h hVarG0 = RecyclerView.g0(view);
            if (hVarG0.x()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (hVarG0.w()) {
                hVarG0.K();
            } else if (hVarG0.L()) {
                hVarG0.e();
            }
            C(hVarG0);
            if (RecyclerView.this.f2719a == null || hVarG0.u()) {
                return;
            }
            RecyclerView.this.f2719a.j(hVarG0);
        }

        public void C(h hVar) {
            boolean z2;
            boolean z3 = false;
            boolean z4 = true;
            if (hVar.w() || hVar.f2786a.getParent() != null) {
                StringBuilder sb = new StringBuilder();
                sb.append("Scrapped or attached views may not be recycled. isScrap:");
                sb.append(hVar.w());
                sb.append(" isAttached:");
                sb.append(hVar.f2786a.getParent() != null);
                sb.append(RecyclerView.this.P());
                throw new IllegalArgumentException(sb.toString());
            }
            if (hVar.x()) {
                throw new IllegalArgumentException("Tmp detached view should be removed from RecyclerView before it can be recycled: " + hVar + RecyclerView.this.P());
            }
            if (hVar.J()) {
                throw new IllegalArgumentException("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle." + RecyclerView.this.P());
            }
            boolean zH = hVar.h();
            com3 com3Var = RecyclerView.this.f2716a;
            if ((com3Var != null && zH && com3Var.r(hVar)) || hVar.u()) {
                if (this.f8616b <= 0 || hVar.p(526)) {
                    z2 = false;
                } else {
                    int size = this.f8617c.size();
                    if (size >= this.f8616b && size > 0) {
                        A(0);
                        size--;
                    }
                    if (RecyclerView.f8539t && size > 0 && !RecyclerView.this.f2728a.d(hVar.f8593a)) {
                        int i2 = size - 1;
                        while (i2 >= 0) {
                            if (!RecyclerView.this.f2728a.d(this.f8617c.get(i2).f8593a)) {
                                break;
                            } else {
                                i2--;
                            }
                        }
                        size = i2 + 1;
                    }
                    this.f8617c.add(size, hVar);
                    z2 = true;
                }
                if (z2) {
                    z4 = false;
                } else {
                    a(hVar, true);
                }
                z3 = z2;
            } else {
                z4 = false;
            }
            RecyclerView.this.f2733a.q(hVar);
            if (z3 || z4 || !zH) {
                return;
            }
            hVar.f2789a = null;
        }

        public void D(View view) {
            h hVarG0 = RecyclerView.g0(view);
            if (!hVarG0.p(12) && hVarG0.y() && !RecyclerView.this.p(hVarG0)) {
                if (this.f2819b == null) {
                    this.f2819b = new ArrayList<>();
                }
                hVarG0.H(this, true);
                this.f2819b.add(hVarG0);
                return;
            }
            if (!hVarG0.t() || hVarG0.v() || RecyclerView.this.f2716a.j()) {
                hVarG0.H(this, false);
                this.f2817a.add(hVarG0);
            } else {
                throw new IllegalArgumentException("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool." + RecyclerView.this.P());
            }
        }

        public void E(lpt8 lpt8Var) {
            lpt8 lpt8Var2 = this.f2815a;
            if (lpt8Var2 != null) {
                lpt8Var2.c();
            }
            this.f2815a = lpt8Var;
            if (lpt8Var == null || RecyclerView.this.getAdapter() == null) {
                return;
            }
            this.f2815a.a();
        }

        public void F(f fVar) {
        }

        public void G(int i2) {
            this.f8615a = i2;
            K();
        }

        public final boolean H(h hVar, int i2, int i3, long j2) {
            hVar.f2789a = RecyclerView.this;
            int iL = hVar.l();
            long nanoTime = RecyclerView.this.getNanoTime();
            if (j2 != Long.MAX_VALUE && !this.f2815a.k(iL, nanoTime, j2)) {
                return false;
            }
            RecyclerView.this.f2716a.d(hVar, i2);
            this.f2815a.d(hVar.l(), RecyclerView.this.getNanoTime() - nanoTime);
            b(hVar);
            if (!RecyclerView.this.f2720a.e()) {
                return true;
            }
            hVar.f8595d = i3;
            return true;
        }

        /* JADX WARN: Code duplicated, block: B:18:0x0037 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:19:0x0039  */
        /* JADX WARN: Code duplicated, block: B:21:0x0043  */
        /* JADX WARN: Code duplicated, block: B:22:0x004e  */
        /* JADX WARN: Code duplicated, block: B:24:0x0054  */
        /* JADX WARN: Code duplicated, block: B:27:0x005c  */
        /* JADX WARN: Code duplicated, block: B:29:0x005f  */
        /* JADX WARN: Code duplicated, block: B:59:0x012c A[PHI: r1 r4
          0x012c: PHI (r1v12 androidx.recyclerview.widget.RecyclerView$h) = (r1v11 androidx.recyclerview.widget.RecyclerView$h), (r1v30 androidx.recyclerview.widget.RecyclerView$h) binds: [B:28:0x005d, B:45:0x00ad] A[DONT_GENERATE, DONT_INLINE]
          0x012c: PHI (r4v3 boolean) = (r4v2 boolean), (r4v7 boolean) binds: [B:28:0x005d, B:45:0x00ad] A[DONT_GENERATE, DONT_INLINE]] */
        /* JADX WARN: Code duplicated, block: B:68:0x014d  */
        /* JADX WARN: Code duplicated, block: B:74:0x0179  */
        /* JADX WARN: Code duplicated, block: B:76:0x017f  */
        /* JADX WARN: Code duplicated, block: B:85:0x01a9  */
        /* JADX WARN: Code duplicated, block: B:86:0x01b7  */
        /* JADX WARN: Code duplicated, block: B:88:0x01bf  */
        /* JADX WARN: Code duplicated, block: B:89:0x01cd  */
        /* JADX WARN: Code duplicated, block: B:92:0x01d3 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:94:0x01d6  */
        public h I(int i2, boolean z2, long j2) {
            h hVarL;
            boolean z3;
            h hVar;
            boolean z4;
            boolean zH;
            ViewGroup.LayoutParams layoutParams;
            lpt3 lpt3Var;
            int iM;
            RecyclerView recyclerViewV;
            if (i2 < 0 || i2 >= RecyclerView.this.f2720a.b()) {
                throw new IndexOutOfBoundsException("Invalid item position " + i2 + "(" + i2 + "). Item count:" + RecyclerView.this.f2720a.b() + RecyclerView.this.P());
            }
            if (RecyclerView.this.f2720a.e()) {
                hVarL = h(i2);
                if (hVarL != null) {
                    z3 = true;
                }
                if (hVarL == null && (hVarL = m(i2, z2)) != null) {
                    if (L(hVarL)) {
                        z3 = true;
                    } else {
                        if (!z2) {
                            hVarL.b(4);
                            if (hVarL.w()) {
                                RecyclerView.this.removeDetachedView(hVarL.f2786a, false);
                                hVarL.K();
                            } else if (hVarL.L()) {
                                hVarL.e();
                            }
                            C(hVarL);
                        }
                        hVarL = null;
                    }
                }
                if (hVarL == null) {
                    hVar = hVarL;
                } else {
                    iM = RecyclerView.this.f2727a.m(i2);
                    if (iM >= 0 || iM >= RecyclerView.this.f2716a.f()) {
                        throw new IndexOutOfBoundsException("Inconsistency detected. Invalid item position " + i2 + "(offset:" + iM + ").state:" + RecyclerView.this.f2720a.b() + RecyclerView.this.P());
                    }
                    int iH = RecyclerView.this.f2716a.h(iM);
                    if (RecyclerView.this.f2716a.j() && (hVarL = l(RecyclerView.this.f2716a.g(iM), iH, z2)) != null) {
                        hVarL.f8593a = iM;
                        z3 = true;
                    }
                    if (hVarL == null) {
                        h hVarF = i().f(iH);
                        if (hVarF != null) {
                            hVarF.D();
                            if (RecyclerView.f8536q) {
                                r(hVarF);
                            }
                        }
                        hVarL = hVarF;
                    }
                    if (hVarL == null) {
                        long nanoTime = RecyclerView.this.getNanoTime();
                        if (j2 != Long.MAX_VALUE && !this.f2815a.l(iH, nanoTime, j2)) {
                            return null;
                        }
                        RecyclerView recyclerView = RecyclerView.this;
                        h hVarE = recyclerView.f2716a.e(recyclerView, iH);
                        if (RecyclerView.f8539t && (recyclerViewV = RecyclerView.V(hVarE.f2786a)) != null) {
                            hVarE.f2790a = new WeakReference<>(recyclerViewV);
                        }
                        this.f2815a.e(iH, RecyclerView.this.getNanoTime() - nanoTime);
                        hVar = hVarE;
                    } else {
                        hVar = hVarL;
                    }
                }
                z4 = z3;
                if (z4 && !RecyclerView.this.f2720a.e() && hVar.p(8192)) {
                    hVar.F(0, 8192);
                    if (RecyclerView.this.f2720a.f2779e) {
                        int iE = com8.e(hVar) | AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH;
                        RecyclerView recyclerView2 = RecyclerView.this;
                        RecyclerView.this.S0(hVar, recyclerView2.f2719a.t(recyclerView2.f2720a, hVar, iE, hVar.o()));
                    }
                }
                if (RecyclerView.this.f2720a.e() || !hVar.s()) {
                    if (hVar.s() || hVar.z() || hVar.t()) {
                        zH = H(hVar, RecyclerView.this.f2727a.m(i2), i2, j2);
                    }
                    layoutParams = hVar.f2786a.getLayoutParams();
                    if (layoutParams == null) {
                        lpt3Var = (lpt3) RecyclerView.this.generateDefaultLayoutParams();
                        hVar.f2786a.setLayoutParams(lpt3Var);
                    } else if (RecyclerView.this.checkLayoutParams(layoutParams)) {
                        lpt3Var = (lpt3) layoutParams;
                    } else {
                        lpt3Var = (lpt3) RecyclerView.this.generateLayoutParams(layoutParams);
                        hVar.f2786a.setLayoutParams(lpt3Var);
                    }
                    lpt3Var.f2810a = hVar;
                    lpt3Var.f8611b = !z4 && zH;
                    return hVar;
                }
                hVar.f8595d = i2;
                zH = false;
                layoutParams = hVar.f2786a.getLayoutParams();
                if (layoutParams == null) {
                    lpt3Var = (lpt3) RecyclerView.this.generateDefaultLayoutParams();
                    hVar.f2786a.setLayoutParams(lpt3Var);
                } else if (RecyclerView.this.checkLayoutParams(layoutParams)) {
                    lpt3Var = (lpt3) RecyclerView.this.generateLayoutParams(layoutParams);
                    hVar.f2786a.setLayoutParams(lpt3Var);
                } else {
                    lpt3Var = (lpt3) layoutParams;
                }
                lpt3Var.f2810a = hVar;
                lpt3Var.f8611b = !z4 && zH;
                return hVar;
            }
            hVarL = null;
            z3 = false;
            if (hVarL == null) {
                if (L(hVarL)) {
                    if (!z2) {
                        hVarL.b(4);
                        if (hVarL.w()) {
                            RecyclerView.this.removeDetachedView(hVarL.f2786a, false);
                            hVarL.K();
                        } else if (hVarL.L()) {
                            hVarL.e();
                        }
                        C(hVarL);
                    }
                    hVarL = null;
                } else {
                    z3 = true;
                }
            }
            if (hVarL == null) {
                iM = RecyclerView.this.f2727a.m(i2);
                if (iM >= 0) {
                }
                throw new IndexOutOfBoundsException("Inconsistency detected. Invalid item position " + i2 + "(offset:" + iM + ").state:" + RecyclerView.this.f2720a.b() + RecyclerView.this.P());
            }
            hVar = hVarL;
            z4 = z3;
            if (z4) {
                hVar.F(0, 8192);
                if (RecyclerView.this.f2720a.f2779e) {
                    int iE2 = com8.e(hVar) | AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH;
                    RecyclerView recyclerView3 = RecyclerView.this;
                    RecyclerView.this.S0(hVar, recyclerView3.f2719a.t(recyclerView3.f2720a, hVar, iE2, hVar.o()));
                }
            }
            if (RecyclerView.this.f2720a.e()) {
                if (hVar.s()) {
                }
                zH = H(hVar, RecyclerView.this.f2727a.m(i2), i2, j2);
            } else {
                if (hVar.s()) {
                }
                zH = H(hVar, RecyclerView.this.f2727a.m(i2), i2, j2);
            }
            layoutParams = hVar.f2786a.getLayoutParams();
            if (layoutParams == null) {
                lpt3Var = (lpt3) RecyclerView.this.generateDefaultLayoutParams();
                hVar.f2786a.setLayoutParams(lpt3Var);
            } else if (RecyclerView.this.checkLayoutParams(layoutParams)) {
                lpt3Var = (lpt3) RecyclerView.this.generateLayoutParams(layoutParams);
                hVar.f2786a.setLayoutParams(lpt3Var);
            } else {
                lpt3Var = (lpt3) layoutParams;
            }
            lpt3Var.f2810a = hVar;
            lpt3Var.f8611b = !z4 && zH;
            return hVar;
        }

        public void J(h hVar) {
            if (hVar.f2792a) {
                this.f2819b.remove(hVar);
            } else {
                this.f2817a.remove(hVar);
            }
            hVar.f2788a = null;
            hVar.f2792a = false;
            hVar.e();
        }

        public void K() {
            lpt2 lpt2Var = RecyclerView.this.f2722a;
            this.f8616b = this.f8615a + (lpt2Var != null ? lpt2Var.f8600a : 0);
            for (int size = this.f8617c.size() - 1; size >= 0 && this.f8617c.size() > this.f8616b; size--) {
                A(size);
            }
        }

        public boolean L(h hVar) {
            if (hVar.v()) {
                return RecyclerView.this.f2720a.e();
            }
            int i2 = hVar.f8593a;
            if (i2 >= 0 && i2 < RecyclerView.this.f2716a.f()) {
                if (RecyclerView.this.f2720a.e() || RecyclerView.this.f2716a.h(hVar.f8593a) == hVar.l()) {
                    return !RecyclerView.this.f2716a.j() || hVar.k() == RecyclerView.this.f2716a.g(hVar.f8593a);
                }
                return false;
            }
            throw new IndexOutOfBoundsException("Inconsistency detected. Invalid view holder adapter position" + hVar + RecyclerView.this.P());
        }

        public void M(int i2, int i3) {
            int i4;
            int i5 = i3 + i2;
            for (int size = this.f8617c.size() - 1; size >= 0; size--) {
                h hVar = this.f8617c.get(size);
                if (hVar != null && (i4 = hVar.f8593a) >= i2 && i4 < i5) {
                    hVar.b(2);
                    A(size);
                }
            }
        }

        public void a(h hVar, boolean z2) {
            RecyclerView.r(hVar);
            View view = hVar.f2786a;
            androidx.recyclerview.widget.com7 com7Var = RecyclerView.this.f2730a;
            if (com7Var != null) {
                p024Com2.lpt3 lpt3VarN = com7Var.n();
                y.o0(view, lpt3VarN instanceof androidx.recyclerview.widget.com7.aux ? ((androidx.recyclerview.widget.com7.aux) lpt3VarN).n(view) : null);
            }
            if (z2) {
                g(hVar);
            }
            hVar.f2789a = null;
            i().i(hVar);
        }

        public final void b(h hVar) {
            if (RecyclerView.this.u0()) {
                View view = hVar.f2786a;
                if (y.y(view) == 0) {
                    y.y0(view, 1);
                }
                androidx.recyclerview.widget.com7 com7Var = RecyclerView.this.f2730a;
                if (com7Var == null) {
                    return;
                }
                p024Com2.lpt3 lpt3VarN = com7Var.n();
                if (lpt3VarN instanceof androidx.recyclerview.widget.com7.aux) {
                    ((androidx.recyclerview.widget.com7.aux) lpt3VarN).o(view);
                }
                y.o0(view, lpt3VarN);
            }
        }

        public void c() {
            this.f2817a.clear();
            z();
        }

        public void d() {
            int size = this.f8617c.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f8617c.get(i2).c();
            }
            int size2 = this.f2817a.size();
            for (int i3 = 0; i3 < size2; i3++) {
                this.f2817a.get(i3).c();
            }
            ArrayList<h> arrayList = this.f2819b;
            if (arrayList != null) {
                int size3 = arrayList.size();
                for (int i4 = 0; i4 < size3; i4++) {
                    this.f2819b.get(i4).c();
                }
            }
        }

        public void e() {
            this.f2817a.clear();
            ArrayList<h> arrayList = this.f2819b;
            if (arrayList != null) {
                arrayList.clear();
            }
        }

        public int f(int i2) {
            if (i2 >= 0 && i2 < RecyclerView.this.f2720a.b()) {
                return !RecyclerView.this.f2720a.e() ? i2 : RecyclerView.this.f2727a.m(i2);
            }
            throw new IndexOutOfBoundsException("invalid position " + i2 + ". State item count is " + RecyclerView.this.f2720a.b() + RecyclerView.this.P());
        }

        public void g(h hVar) {
            RecyclerView.this.getClass();
            com3 com3Var = RecyclerView.this.f2716a;
            if (com3Var != null) {
                com3Var.u(hVar);
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f2720a != null) {
                recyclerView.f2733a.q(hVar);
            }
        }

        public h h(int i2) {
            int size;
            int iM;
            ArrayList<h> arrayList = this.f2819b;
            if (arrayList != null && (size = arrayList.size()) != 0) {
                for (int i3 = 0; i3 < size; i3++) {
                    h hVar = this.f2819b.get(i3);
                    if (!hVar.L() && hVar.m() == i2) {
                        hVar.b(32);
                        return hVar;
                    }
                }
                if (RecyclerView.this.f2716a.j() && (iM = RecyclerView.this.f2727a.m(i2)) > 0 && iM < RecyclerView.this.f2716a.f()) {
                    long jG = RecyclerView.this.f2716a.g(iM);
                    for (int i4 = 0; i4 < size; i4++) {
                        h hVar2 = this.f2819b.get(i4);
                        if (!hVar2.L() && hVar2.k() == jG) {
                            hVar2.b(32);
                            return hVar2;
                        }
                    }
                }
            }
            return null;
        }

        public lpt8 i() {
            if (this.f2815a == null) {
                this.f2815a = new lpt8();
            }
            return this.f2815a;
        }

        public int j() {
            return this.f2817a.size();
        }

        public List<h> k() {
            return this.f2818a;
        }

        public h l(long j2, int i2, boolean z2) {
            for (int size = this.f2817a.size() - 1; size >= 0; size--) {
                h hVar = this.f2817a.get(size);
                if (hVar.k() == j2 && !hVar.L()) {
                    if (i2 == hVar.l()) {
                        hVar.b(32);
                        if (hVar.v() && !RecyclerView.this.f2720a.e()) {
                            hVar.F(2, 14);
                        }
                        return hVar;
                    }
                    if (!z2) {
                        this.f2817a.remove(size);
                        RecyclerView.this.removeDetachedView(hVar.f2786a, false);
                        y(hVar.f2786a);
                    }
                }
            }
            int size2 = this.f8617c.size();
            while (true) {
                size2--;
                if (size2 < 0) {
                    return null;
                }
                h hVar2 = this.f8617c.get(size2);
                if (hVar2.k() == j2 && !hVar2.r()) {
                    if (i2 == hVar2.l()) {
                        if (!z2) {
                            this.f8617c.remove(size2);
                        }
                        return hVar2;
                    }
                    if (!z2) {
                        A(size2);
                        return null;
                    }
                }
            }
        }

        public h m(int i2, boolean z2) {
            View viewE;
            int size = this.f2817a.size();
            for (int i3 = 0; i3 < size; i3++) {
                h hVar = this.f2817a.get(i3);
                if (!hVar.L() && hVar.m() == i2 && !hVar.t() && (RecyclerView.this.f2720a.f2776b || !hVar.v())) {
                    hVar.b(32);
                    return hVar;
                }
            }
            if (z2 || (viewE = RecyclerView.this.f2731a.e(i2)) == null) {
                int size2 = this.f8617c.size();
                for (int i4 = 0; i4 < size2; i4++) {
                    h hVar2 = this.f8617c.get(i4);
                    if (!hVar2.t() && hVar2.m() == i2 && !hVar2.r()) {
                        if (!z2) {
                            this.f8617c.remove(i4);
                        }
                        return hVar2;
                    }
                }
                return null;
            }
            h hVarG0 = RecyclerView.g0(viewE);
            RecyclerView.this.f2731a.s(viewE);
            int iM = RecyclerView.this.f2731a.m(viewE);
            if (iM != -1) {
                RecyclerView.this.f2731a.d(iM);
                D(viewE);
                hVarG0.b(8224);
                return hVarG0;
            }
            throw new IllegalStateException("layout index should not be -1 after unhiding a view:" + hVarG0 + RecyclerView.this.P());
        }

        public View n(int i2) {
            return this.f2817a.get(i2).f2786a;
        }

        public View o(int i2) {
            return p(i2, false);
        }

        public View p(int i2, boolean z2) {
            return I(i2, z2, Long.MAX_VALUE).f2786a;
        }

        public final void q(ViewGroup viewGroup, boolean z2) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    q((ViewGroup) childAt, true);
                }
            }
            if (z2) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                } else {
                    int visibility = viewGroup.getVisibility();
                    viewGroup.setVisibility(4);
                    viewGroup.setVisibility(visibility);
                }
            }
        }

        public final void r(h hVar) {
            View view = hVar.f2786a;
            if (view instanceof ViewGroup) {
                q((ViewGroup) view, false);
            }
        }

        public void s() {
            int size = this.f8617c.size();
            for (int i2 = 0; i2 < size; i2++) {
                lpt3 lpt3Var = (lpt3) this.f8617c.get(i2).f2786a.getLayoutParams();
                if (lpt3Var != null) {
                    lpt3Var.f2811a = true;
                }
            }
        }

        public void t() {
            int size = this.f8617c.size();
            for (int i2 = 0; i2 < size; i2++) {
                h hVar = this.f8617c.get(i2);
                if (hVar != null) {
                    hVar.b(6);
                    hVar.a(null);
                }
            }
            com3 com3Var = RecyclerView.this.f2716a;
            if (com3Var == null || !com3Var.j()) {
                z();
            }
        }

        public void u(int i2, int i3) {
            int size = this.f8617c.size();
            for (int i4 = 0; i4 < size; i4++) {
                h hVar = this.f8617c.get(i4);
                if (hVar != null && hVar.f8593a >= i2) {
                    hVar.A(i3, true);
                }
            }
        }

        public void v(int i2, int i3) {
            int i4;
            int i5;
            int i6;
            int i7;
            if (i2 < i3) {
                i4 = -1;
                i6 = i2;
                i5 = i3;
            } else {
                i4 = 1;
                i5 = i2;
                i6 = i3;
            }
            int size = this.f8617c.size();
            for (int i8 = 0; i8 < size; i8++) {
                h hVar = this.f8617c.get(i8);
                if (hVar != null && (i7 = hVar.f8593a) >= i6 && i7 <= i5) {
                    if (i7 == i2) {
                        hVar.A(i3 - i2, false);
                    } else {
                        hVar.A(i4, false);
                    }
                }
            }
        }

        public void w(int i2, int i3, boolean z2) {
            int i4 = i2 + i3;
            for (int size = this.f8617c.size() - 1; size >= 0; size--) {
                h hVar = this.f8617c.get(size);
                if (hVar != null) {
                    int i5 = hVar.f8593a;
                    if (i5 >= i4) {
                        hVar.A(-i3, z2);
                    } else if (i5 >= i2) {
                        hVar.b(8);
                        A(size);
                    }
                }
            }
        }

        public void x(com3 com3Var, com3 com3Var2, boolean z2) {
            c();
            i().h(com3Var, com3Var2, z2);
        }

        public void y(View view) {
            h hVarG0 = RecyclerView.g0(view);
            hVarG0.f2788a = null;
            hVarG0.f2792a = false;
            hVarG0.e();
            C(hVarG0);
        }

        public void z() {
            for (int size = this.f8617c.size() - 1; size >= 0; size--) {
                A(size);
            }
            this.f8617c.clear();
            if (RecyclerView.f8539t) {
                RecyclerView.this.f2728a.b();
            }
        }
    }

    public static class nul implements Interpolator {
        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f2) {
            float f3 = f2 - 1.0f;
            return (f3 * f3 * f3 * f3 * f3) + 1.0f;
        }
    }

    public class prn implements androidx.recyclerview.widget.lpt3.con {
        public prn() {
        }

        @Override // androidx.recyclerview.widget.lpt3.con
        public void a(h hVar) {
            RecyclerView recyclerView = RecyclerView.this;
            recyclerView.f2722a.m1(hVar.f2786a, recyclerView.f2726a);
        }

        @Override // androidx.recyclerview.widget.lpt3.con
        public void b(h hVar, com8.nul nulVar, com8.nul nulVar2) {
            hVar.G(false);
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.f2760k) {
                if (recyclerView.f2719a.b(hVar, hVar, nulVar, nulVar2)) {
                    RecyclerView.this.N0();
                }
            } else if (recyclerView.f2719a.d(hVar, nulVar, nulVar2)) {
                RecyclerView.this.N0();
            }
        }

        @Override // androidx.recyclerview.widget.lpt3.con
        public void c(h hVar, com8.nul nulVar, com8.nul nulVar2) {
            RecyclerView.this.f2726a.J(hVar);
            RecyclerView.this.n(hVar, nulVar, nulVar2);
        }

        @Override // androidx.recyclerview.widget.lpt3.con
        public void d(h hVar, com8.nul nulVar, com8.nul nulVar2) {
            RecyclerView.this.l(hVar, nulVar, nulVar2);
        }
    }

    static {
        Class<?> cls = Integer.TYPE;
        f2705a = new Class[]{Context.class, AttributeSet.class, cls, cls};
        f8534a = new nul();
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, p073cOM4.lpt9.f8867a);
    }

    public static RecyclerView V(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            RecyclerView recyclerViewV = V(viewGroup.getChildAt(i2));
            if (recyclerViewV != null) {
                return recyclerViewV;
            }
        }
        return null;
    }

    public static h g0(View view) {
        if (view == null) {
            return null;
        }
        return ((lpt3) view.getLayoutParams()).f2810a;
    }

    private o getScrollingChildHelper() {
        if (this.f2708a == null) {
            this.f2708a = new o(this);
        }
        return this.f2708a;
    }

    public static void h0(View view, Rect rect) {
        lpt3 lpt3Var = (lpt3) view.getLayoutParams();
        Rect rect2 = lpt3Var.f8610a;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) lpt3Var).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) lpt3Var).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) lpt3Var).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) lpt3Var).bottomMargin);
    }

    public static void r(h hVar) {
        WeakReference<RecyclerView> weakReference = hVar.f2790a;
        if (weakReference != null) {
            RecyclerView recyclerView = weakReference.get();
            while (recyclerView != null) {
                if (recyclerView == hVar.f2786a) {
                    return;
                }
                Object parent = recyclerView.getParent();
                recyclerView = parent instanceof View ? (View) parent : null;
            }
            hVar.f2790a = null;
        }
    }

    public final void A() {
        int i2 = this.f2738b;
        this.f2738b = 0;
        if (i2 == 0 || !u0()) {
            return;
        }
        AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
        accessibilityEventObtain.setEventType(2048);
        v1.b(accessibilityEventObtain, i2);
        sendAccessibilityEventUnchecked(accessibilityEventObtain);
    }

    public void A0(int i2) {
        int iG = this.f2731a.g();
        for (int i3 = 0; i3 < iG; i3++) {
            this.f2731a.f(i3).offsetLeftAndRight(i2);
        }
    }

    public void B() {
        if (this.f2716a == null) {
            Log.e("RecyclerView", "No adapter attached; skipping layout");
            return;
        }
        if (this.f2722a == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
            return;
        }
        e eVar = this.f2720a;
        eVar.f2778d = false;
        if (eVar.f8583d == 1) {
            C();
            this.f2722a.z1(this);
            D();
        } else if (!this.f2727a.q() && this.f2722a.o0() == getWidth() && this.f2722a.W() == getHeight()) {
            this.f2722a.z1(this);
        } else {
            this.f2722a.z1(this);
            D();
        }
        E();
    }

    public void B0(int i2) {
        int iG = this.f2731a.g();
        for (int i3 = 0; i3 < iG; i3++) {
            this.f2731a.f(i3).offsetTopAndBottom(i2);
        }
    }

    public final void C() {
        this.f2720a.a(1);
        Q(this.f2720a);
        this.f2720a.f2778d = false;
        r1();
        this.f2733a.f();
        H0();
        P0();
        e1();
        e eVar = this.f2720a;
        eVar.f2777c = eVar.f2779e && this.f8554o;
        this.f8554o = false;
        this.f8553n = false;
        eVar.f2776b = eVar.f2780f;
        eVar.f8584e = this.f2716a.f();
        U(this.f2737a);
        if (this.f2720a.f2779e) {
            int iG = this.f2731a.g();
            for (int i2 = 0; i2 < iG; i2++) {
                h hVarG0 = g0(this.f2731a.f(i2));
                if (!hVarG0.J() && (!hVarG0.t() || this.f2716a.j())) {
                    this.f2733a.e(hVarG0, this.f2719a.t(this.f2720a, hVarG0, com8.e(hVarG0), hVarG0.o()));
                    if (this.f2720a.f2777c && hVarG0.y() && !hVarG0.v() && !hVarG0.J() && !hVarG0.t()) {
                        this.f2733a.c(c0(hVarG0), hVarG0);
                    }
                }
            }
        }
        if (this.f2720a.f2780f) {
            f1();
            e eVar2 = this.f2720a;
            boolean z2 = eVar2.f2775a;
            eVar2.f2775a = false;
            this.f2722a.X0(this.f2726a, eVar2);
            this.f2720a.f2775a = z2;
            for (int i3 = 0; i3 < this.f2731a.g(); i3++) {
                h hVarG1 = g0(this.f2731a.f(i3));
                if (!hVarG1.J() && !this.f2733a.i(hVarG1)) {
                    int iE = com8.e(hVarG1);
                    boolean zP = hVarG1.p(8192);
                    if (!zP) {
                        iE |= AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH;
                    }
                    com8.nul nulVarT = this.f2719a.t(this.f2720a, hVarG1, iE, hVarG1.o());
                    if (zP) {
                        S0(hVarG1, nulVarT);
                    } else {
                        this.f2733a.a(hVarG1, nulVarT);
                    }
                }
            }
            s();
        } else {
            s();
        }
        I0();
        t1(false);
        this.f2720a.f8583d = 2;
    }

    public void C0(int i2, int i3) {
        int iJ = this.f2731a.j();
        for (int i4 = 0; i4 < iJ; i4++) {
            h hVarG0 = g0(this.f2731a.i(i4));
            if (hVarG0 != null && !hVarG0.J() && hVarG0.f8593a >= i2) {
                hVarG0.A(i3, false);
                this.f2720a.f2775a = true;
            }
        }
        this.f2726a.u(i2, i3);
        requestLayout();
    }

    public final void D() {
        r1();
        H0();
        this.f2720a.a(6);
        this.f2727a.j();
        this.f2720a.f8584e = this.f2716a.f();
        e eVar = this.f2720a;
        eVar.f8582c = 0;
        eVar.f2776b = false;
        this.f2722a.X0(this.f2726a, eVar);
        e eVar2 = this.f2720a;
        eVar2.f2775a = false;
        this.f2715a = null;
        eVar2.f2779e = eVar2.f2779e && this.f2719a != null;
        eVar2.f8583d = 4;
        I0();
        t1(false);
    }

    public void D0(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int iJ = this.f2731a.j();
        if (i2 < i3) {
            i6 = -1;
            i5 = i2;
            i4 = i3;
        } else {
            i4 = i2;
            i5 = i3;
            i6 = 1;
        }
        for (int i8 = 0; i8 < iJ; i8++) {
            h hVarG0 = g0(this.f2731a.i(i8));
            if (hVarG0 != null && (i7 = hVarG0.f8593a) >= i5 && i7 <= i4) {
                if (i7 == i2) {
                    hVarG0.A(i3 - i2, false);
                } else {
                    hVarG0.A(i6, false);
                }
                this.f2720a.f2775a = true;
            }
        }
        this.f2726a.v(i2, i3);
        requestLayout();
    }

    public final void E() {
        this.f2720a.a(4);
        r1();
        H0();
        e eVar = this.f2720a;
        eVar.f8583d = 1;
        if (eVar.f2779e) {
            for (int iG = this.f2731a.g() - 1; iG >= 0; iG--) {
                h hVarG0 = g0(this.f2731a.f(iG));
                if (!hVarG0.J()) {
                    long jC0 = c0(hVarG0);
                    com8.nul nulVarS = this.f2719a.s(this.f2720a, hVarG0);
                    h hVarG = this.f2733a.g(jC0);
                    if (hVarG == null || hVarG.J()) {
                        this.f2733a.d(hVarG0, nulVarS);
                    } else {
                        boolean zH = this.f2733a.h(hVarG);
                        boolean zH2 = this.f2733a.h(hVarG0);
                        if (zH && hVarG == hVarG0) {
                            this.f2733a.d(hVarG0, nulVarS);
                        } else {
                            com8.nul nulVarN = this.f2733a.n(hVarG);
                            this.f2733a.d(hVarG0, nulVarS);
                            com8.nul nulVarM = this.f2733a.m(hVarG0);
                            if (nulVarN == null) {
                                l0(jC0, hVarG0, hVarG);
                            } else {
                                m(hVarG, hVarG0, nulVarN, nulVarM, zH, zH2);
                            }
                        }
                    }
                }
            }
            this.f2733a.o(this.f2732a);
        }
        this.f2722a.l1(this.f2726a);
        e eVar2 = this.f2720a;
        eVar2.f8581b = eVar2.f8584e;
        this.f2760k = false;
        this.f2761l = false;
        eVar2.f2779e = false;
        eVar2.f2780f = false;
        this.f2722a.f2801a = false;
        ArrayList<h> arrayList = this.f2726a.f2819b;
        if (arrayList != null) {
            arrayList.clear();
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var.f8605f) {
            lpt2Var.f8600a = 0;
            lpt2Var.f8605f = false;
            this.f2726a.K();
        }
        this.f2722a.Y0(this.f2720a);
        I0();
        t1(false);
        this.f2733a.f();
        int[] iArr = this.f2737a;
        if (x(iArr[0], iArr[1])) {
            I(0, 0);
        }
        T0();
        c1();
    }

    public void E0(int i2, int i3, boolean z2) {
        int i4 = i2 + i3;
        int iJ = this.f2731a.j();
        for (int i5 = 0; i5 < iJ; i5++) {
            h hVarG0 = g0(this.f2731a.i(i5));
            if (hVarG0 != null && !hVarG0.J()) {
                int i6 = hVarG0.f8593a;
                if (i6 >= i4) {
                    hVarG0.A(-i3, z2);
                    this.f2720a.f2775a = true;
                } else if (i6 >= i2) {
                    hVarG0.i(i2 - 1, -i3, z2);
                    this.f2720a.f2775a = true;
                }
            }
        }
        this.f2726a.w(i2, i3, z2);
        requestLayout();
    }

    public boolean F(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().d(i2, i3, iArr, iArr2, i4);
    }

    public void F0(View view) {
    }

    public final void G(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        getScrollingChildHelper().e(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    public void G0(View view) {
    }

    public void H(int i2) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.e1(i2);
        }
        L0(i2);
        lpt7 lpt7Var = this.f2725a;
        if (lpt7Var != null) {
            lpt7Var.a(this, i2);
        }
        List<lpt7> list = this.f2743b;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2743b.get(size).a(this, i2);
            }
        }
    }

    public void H0() {
        this.f8543c++;
    }

    public void I(int i2, int i3) {
        this.f8544d++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i2, scrollY - i3);
        M0(i2, i3);
        lpt7 lpt7Var = this.f2725a;
        if (lpt7Var != null) {
            lpt7Var.b(this, i2, i3);
        }
        List<lpt7> list = this.f2743b;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2743b.get(size).b(this, i2, i3);
            }
        }
        this.f8544d--;
    }

    public void I0() {
        J0(true);
    }

    public void J() {
        int i2;
        for (int size = this.f2747c.size() - 1; size >= 0; size--) {
            h hVar = this.f2747c.get(size);
            if (hVar.f2786a.getParent() == this && !hVar.J() && (i2 = hVar.f8599h) != -1) {
                y.y0(hVar.f2786a, i2);
                hVar.f8599h = -1;
            }
        }
        this.f2747c.clear();
    }

    public void J0(boolean z2) {
        int i2 = this.f8543c - 1;
        this.f8543c = i2;
        if (i2 < 1) {
            this.f8543c = 0;
            if (z2) {
                A();
                J();
            }
        }
    }

    public final boolean K(MotionEvent motionEvent) {
        lpt6 lpt6Var = this.f2724a;
        if (lpt6Var == null) {
            if (motionEvent.getAction() == 0) {
                return false;
            }
            return T(motionEvent);
        }
        lpt6Var.c(this, motionEvent);
        int action = motionEvent.getAction();
        if (action == 3 || action == 1) {
            this.f2724a = null;
        }
        return true;
    }

    public final void K0(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f8545f) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.f8545f = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.f8548i = x2;
            this.f8546g = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.f8549j = y2;
            this.f8547h = y2;
        }
    }

    public void L() {
        if (this.f2750d != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.f2717a.a(this, 3);
        this.f2750d = edgeEffectA;
        if (this.f2744b) {
            edgeEffectA.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffectA.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void L0(int i2) {
    }

    public void M() {
        if (this.f2713a != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.f2717a.a(this, 0);
        this.f2713a = edgeEffectA;
        if (this.f2744b) {
            edgeEffectA.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffectA.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public void M0(int i2, int i3) {
    }

    public void N() {
        if (this.f2746c != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.f2717a.a(this, 2);
        this.f2746c = edgeEffectA;
        if (this.f2744b) {
            edgeEffectA.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffectA.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public void N0() {
        if (this.f8555p || !this.f2748c) {
            return;
        }
        y.g0(this, this.f2741b);
        this.f8555p = true;
    }

    public void O() {
        if (this.f2740b != null) {
            return;
        }
        EdgeEffect edgeEffectA = this.f2717a.a(this, 1);
        this.f2740b = edgeEffectA;
        if (this.f2744b) {
            edgeEffectA.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffectA.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final boolean O0() {
        return this.f2719a != null && this.f2722a.L1();
    }

    public String P() {
        return " " + super.toString() + ", adapter:" + this.f2716a + ", layout:" + this.f2722a + ", context:" + getContext();
    }

    public final void P0() {
        boolean z2;
        if (this.f2760k) {
            this.f2727a.v();
            if (this.f2761l) {
                this.f2722a.S0(this);
            }
        }
        if (O0()) {
            this.f2727a.t();
        } else {
            this.f2727a.j();
        }
        boolean z3 = false;
        boolean z4 = this.f8553n || this.f8554o;
        this.f2720a.f2779e = this.f2755f && this.f2719a != null && ((z2 = this.f2760k) || z4 || this.f2722a.f2801a) && (!z2 || this.f2716a.j());
        e eVar = this.f2720a;
        if (eVar.f2779e && z4 && !this.f2760k && O0()) {
            z3 = true;
        }
        eVar.f2780f = z3;
    }

    public final void Q(e eVar) {
        if (getScrollState() != 2) {
            eVar.f8587h = 0;
            eVar.f8588i = 0;
        } else {
            OverScroller overScroller = this.f2721a.f2782a;
            eVar.f8587h = overScroller.getFinalX() - overScroller.getCurrX();
            eVar.f8588i = overScroller.getFinalY() - overScroller.getCurrY();
        }
    }

    public void Q0(boolean z2) {
        this.f2761l = z2 | this.f2761l;
        this.f2760k = true;
        z0();
    }

    public View R(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0040  */
    /* JADX WARN: Code duplicated, block: B:13:0x0056  */
    /* JADX WARN: Code duplicated, block: B:15:0x005a  */
    /* JADX WARN: Code duplicated, block: B:16:0x0071  */
    public final void R0(float f2, float f3, float f4, float f5) {
        boolean z2;
        boolean z3 = true;
        if (f3 >= 0.0f) {
            if (f3 > 0.0f) {
                N();
                p014CoM2.com3.c(this.f2746c, f3 / getWidth(), f4 / getHeight());
            } else {
                z2 = false;
            }
            if (f5 < 0.0f) {
                O();
                p014CoM2.com3.c(this.f2740b, (-f5) / getHeight(), f2 / getWidth());
            } else if (f5 > 0.0f) {
                L();
                p014CoM2.com3.c(this.f2750d, f5 / getHeight(), 1.0f - (f2 / getWidth()));
            } else {
                z3 = z2;
            }
            if (z3 && f3 == 0.0f && f5 == 0.0f) {
                return;
            }
            y.f0(this);
        }
        M();
        p014CoM2.com3.c(this.f2713a, (-f3) / getWidth(), 1.0f - (f4 / getHeight()));
        z2 = true;
        if (f5 < 0.0f) {
            O();
            p014CoM2.com3.c(this.f2740b, (-f5) / getHeight(), f2 / getWidth());
        } else if (f5 > 0.0f) {
            L();
            p014CoM2.com3.c(this.f2750d, f5 / getHeight(), 1.0f - (f2 / getWidth()));
        } else {
            z3 = z2;
        }
        if (z3) {
        }
        y.f0(this);
    }

    public h S(View view) {
        View viewR = R(view);
        if (viewR == null) {
            return null;
        }
        return f0(viewR);
    }

    public void S0(h hVar, com8.nul nulVar) {
        hVar.F(0, 8192);
        if (this.f2720a.f2777c && hVar.y() && !hVar.v() && !hVar.J()) {
            this.f2733a.c(c0(hVar), hVar);
        }
        this.f2733a.e(hVar, nulVar);
    }

    public final boolean T(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        int size = this.f2742b.size();
        for (int i2 = 0; i2 < size; i2++) {
            lpt6 lpt6Var = this.f2742b.get(i2);
            if (lpt6Var.a(this, motionEvent) && action != 3) {
                this.f2724a = lpt6Var;
                return true;
            }
        }
        return false;
    }

    public final void T0() {
        View viewFindViewById;
        if (!this.f2762m || this.f2716a == null || !hasFocus() || getDescendantFocusability() == 393216) {
            return;
        }
        if (getDescendantFocusability() == 131072 && isFocused()) {
            return;
        }
        if (!isFocused()) {
            View focusedChild = getFocusedChild();
            if (!f8541v || (focusedChild.getParent() != null && focusedChild.hasFocus())) {
                if (!this.f2731a.n(focusedChild)) {
                    return;
                }
            } else if (this.f2731a.g() == 0) {
                requestFocus();
                return;
            }
        }
        View viewW = null;
        h hVarY = (this.f2720a.f2773a == -1 || !this.f2716a.j()) ? null : Y(this.f2720a.f2773a);
        if (hVarY != null && !this.f2731a.n(hVarY.f2786a) && hVarY.f2786a.hasFocusable()) {
            viewW = hVarY.f2786a;
        } else if (this.f2731a.g() > 0) {
            viewW = W();
        }
        if (viewW != null) {
            int i2 = this.f2720a.f8586g;
            if (i2 != -1 && (viewFindViewById = viewW.findViewById(i2)) != null && viewFindViewById.isFocusable()) {
                viewW = viewFindViewById;
            }
            viewW.requestFocus();
        }
    }

    public final void U(int[] iArr) {
        int iG = this.f2731a.g();
        if (iG == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i2 = Preference.DEFAULT_ORDER;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < iG; i4++) {
            h hVarG0 = g0(this.f2731a.f(i4));
            if (!hVarG0.J()) {
                int iM = hVarG0.m();
                if (iM < i2) {
                    i2 = iM;
                }
                if (iM > i3) {
                    i3 = iM;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i3;
    }

    public final void U0() {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f2713a;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            zIsFinished = this.f2713a.isFinished();
        } else {
            zIsFinished = false;
        }
        EdgeEffect edgeEffect2 = this.f2740b;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            zIsFinished |= this.f2740b.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f2746c;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            zIsFinished |= this.f2746c.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f2750d;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            zIsFinished |= this.f2750d.isFinished();
        }
        if (zIsFinished) {
            y.f0(this);
        }
    }

    public void V0() {
        com8 com8Var = this.f2719a;
        if (com8Var != null) {
            com8Var.k();
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.k1(this.f2726a);
            this.f2722a.l1(this.f2726a);
        }
        this.f2726a.c();
    }

    public final View W() {
        h hVarX;
        e eVar = this.f2720a;
        int i2 = eVar.f8585f;
        if (i2 == -1) {
            i2 = 0;
        }
        int iB = eVar.b();
        for (int i3 = i2; i3 < iB; i3++) {
            h hVarX2 = X(i3);
            if (hVarX2 == null) {
                break;
            }
            if (hVarX2.f2786a.hasFocusable()) {
                return hVarX2.f2786a;
            }
        }
        int iMin = Math.min(iB, i2);
        do {
            iMin--;
            if (iMin < 0 || (hVarX = X(iMin)) == null) {
                return null;
            }
        } while (!hVarX.f2786a.hasFocusable());
        return hVarX.f2786a;
    }

    public boolean W0(View view) {
        r1();
        boolean zR = this.f2731a.r(view);
        if (zR) {
            h hVarG0 = g0(view);
            this.f2726a.J(hVarG0);
            this.f2726a.C(hVarG0);
        }
        t1(!zR);
        return zR;
    }

    public h X(int i2) {
        h hVar = null;
        if (this.f2760k) {
            return null;
        }
        int iJ = this.f2731a.j();
        for (int i3 = 0; i3 < iJ; i3++) {
            h hVarG0 = g0(this.f2731a.i(i3));
            if (hVarG0 != null && !hVarG0.v() && b0(hVarG0) == i2) {
                if (!this.f2731a.n(hVarG0.f2786a)) {
                    return hVarG0;
                }
                hVar = hVarG0;
            }
        }
        return hVar;
    }

    public void X0(lpt1 lpt1Var) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.g("Cannot remove item decoration during a scroll  or layout");
        }
        this.f2735a.remove(lpt1Var);
        if (this.f2735a.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        y0();
        requestLayout();
    }

    public h Y(long j2) {
        com3 com3Var = this.f2716a;
        h hVar = null;
        if (com3Var != null && com3Var.j()) {
            int iJ = this.f2731a.j();
            for (int i2 = 0; i2 < iJ; i2++) {
                h hVarG0 = g0(this.f2731a.i(i2));
                if (hVarG0 != null && !hVarG0.v() && hVarG0.k() == j2) {
                    if (!this.f2731a.n(hVarG0.f2786a)) {
                        return hVarG0;
                    }
                    hVar = hVarG0;
                }
            }
        }
        return hVar;
    }

    public void Y0(lpt6 lpt6Var) {
        this.f2742b.remove(lpt6Var);
        if (this.f2724a == lpt6Var) {
            this.f2724a = null;
        }
    }

    /* JADX WARN: Code duplicated, block: B:15:0x002a  */
    /* JADX WARN: Code duplicated, block: B:17:0x0034  */
    /* JADX WARN: Code duplicated, block: B:22:0x0036 A[SYNTHETIC] */
    public h Z(int i2, boolean z2) {
        int iJ = this.f2731a.j();
        h hVar = null;
        for (int i3 = 0; i3 < iJ; i3++) {
            h hVarG0 = g0(this.f2731a.i(i3));
            if (hVarG0 != null && !hVarG0.v()) {
                if (z2) {
                    if (hVarG0.f8593a != i2) {
                        continue;
                    } else {
                        if (this.f2731a.n(hVarG0.f2786a)) {
                            return hVarG0;
                        }
                        hVar = hVarG0;
                    }
                } else if (hVarG0.m() != i2) {
                    continue;
                } else {
                    if (this.f2731a.n(hVarG0.f2786a)) {
                        return hVarG0;
                    }
                    hVar = hVarG0;
                }
            }
        }
        return hVar;
    }

    public void Z0(lpt7 lpt7Var) {
        List<lpt7> list = this.f2743b;
        if (list != null) {
            list.remove(lpt7Var);
        }
    }

    public void a(int i2, int i3) {
        if (i2 < 0) {
            M();
            if (this.f2713a.isFinished()) {
                this.f2713a.onAbsorb(-i2);
            }
        } else if (i2 > 0) {
            N();
            if (this.f2746c.isFinished()) {
                this.f2746c.onAbsorb(i2);
            }
        }
        if (i3 < 0) {
            O();
            if (this.f2740b.isFinished()) {
                this.f2740b.onAbsorb(-i3);
            }
        } else if (i3 > 0) {
            L();
            if (this.f2750d.isFinished()) {
                this.f2750d.onAbsorb(i3);
            }
        }
        if (i2 == 0 && i3 == 0) {
            return;
        }
        y.f0(this);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v6 */
    public boolean a0(int i2, int i3) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            Log.e("RecyclerView", "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return false;
        }
        if (this.f2757h) {
            return false;
        }
        int iK = lpt2Var.k();
        boolean zL = this.f2722a.l();
        if (iK == 0 || Math.abs(i2) < this.f8551l) {
            i2 = 0;
        }
        if (!zL || Math.abs(i3) < this.f8551l) {
            i3 = 0;
        }
        if (i2 == 0 && i3 == 0) {
            return false;
        }
        float f2 = i2;
        float f3 = i3;
        if (!dispatchNestedPreFling(f2, f3)) {
            boolean z2 = iK != 0 || zL;
            dispatchNestedFling(f2, f3, z2);
            lpt5 lpt5Var = this.f2723a;
            if (lpt5Var != null && lpt5Var.a(i2, i3)) {
                return true;
            }
            if (z2) {
                if (zL) {
                    iK = (iK == true ? 1 : 0) | 2;
                }
                s1(iK, 1);
                int i4 = this.f8552m;
                int iMax = Math.max(-i4, Math.min(i2, i4));
                int i5 = this.f8552m;
                this.f2721a.c(iMax, Math.max(-i5, Math.min(i3, i5)));
                return true;
            }
        }
        return false;
    }

    public void a1() {
        h hVar;
        int iG = this.f2731a.g();
        for (int i2 = 0; i2 < iG; i2++) {
            View viewF = this.f2731a.f(i2);
            h hVarF0 = f0(viewF);
            if (hVarF0 != null && (hVar = hVarF0.f2793b) != null) {
                View view = hVar.f2786a;
                int left = viewF.getLeft();
                int top = viewF.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null || !lpt2Var.F0(this, arrayList, i2, i3)) {
            super.addFocusables(arrayList, i2, i3);
        }
    }

    public int b0(h hVar) {
        if (hVar.p(524) || !hVar.s()) {
            return -1;
        }
        return this.f2727a.e(hVar.f8593a);
    }

    public final void b1(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.f2709a.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof lpt3) {
            lpt3 lpt3Var = (lpt3) layoutParams;
            if (!lpt3Var.f2811a) {
                Rect rect = lpt3Var.f8610a;
                Rect rect2 = this.f2709a;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.f2709a);
            offsetRectIntoDescendantCoords(view, this.f2709a);
        }
        this.f2722a.s1(this, view, this.f2709a, !this.f2755f, view2 == null);
    }

    public long c0(h hVar) {
        return this.f2716a.j() ? hVar.k() : hVar.f8593a;
    }

    public final void c1() {
        e eVar = this.f2720a;
        eVar.f2773a = -1L;
        eVar.f8585f = -1;
        eVar.f8586g = -1;
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof lpt3) && this.f2722a.m((lpt3) layoutParams);
    }

    @Override // android.view.View
    public int computeHorizontalScrollExtent() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null && lpt2Var.k()) {
            return this.f2722a.q(this.f2720a);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollOffset() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null && lpt2Var.k()) {
            return this.f2722a.r(this.f2720a);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null && lpt2Var.k()) {
            return this.f2722a.s(this.f2720a);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null && lpt2Var.l()) {
            return this.f2722a.t(this.f2720a);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null && lpt2Var.l()) {
            return this.f2722a.u(this.f2720a);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollRange() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null && lpt2Var.l()) {
            return this.f2722a.v(this.f2720a);
        }
        return 0;
    }

    public int d0(View view) {
        h hVarG0 = g0(view);
        if (hVarG0 != null) {
            return hVarG0.j();
        }
        return -1;
    }

    public final void d1() {
        VelocityTracker velocityTracker = this.f2711a;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        u1(0);
        U0();
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return getScrollingChildHelper().a(f2, f3, z2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return getScrollingChildHelper().b(f2, f3);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i2, i3, iArr, iArr2);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().f(i2, i3, i4, i5, iArr);
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        boolean z2;
        super.draw(canvas);
        int size = this.f2735a.size();
        boolean z3 = false;
        for (int i2 = 0; i2 < size; i2++) {
            this.f2735a.get(i2).i(canvas, this, this.f2720a);
        }
        EdgeEffect edgeEffect = this.f2713a;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int iSave = canvas.save();
            int paddingBottom = this.f2744b ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.f2713a;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect3 = this.f2740b;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int iSave2 = canvas.save();
            if (this.f2744b) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f2740b;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(iSave2);
        }
        EdgeEffect edgeEffect5 = this.f2746c;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int iSave3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f2744b ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(-paddingTop, -width);
            EdgeEffect edgeEffect6 = this.f2746c;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(iSave3);
        }
        EdgeEffect edgeEffect7 = this.f2750d;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int iSave4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f2744b) {
                canvas.translate((-getWidth()) + getPaddingRight(), (-getHeight()) + getPaddingBottom());
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.f2750d;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(iSave4);
        }
        if ((z2 || this.f2719a == null || this.f2735a.size() <= 0 || !this.f2719a.p()) ? z2 : true) {
            y.f0(this);
        }
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public int e0(View view) {
        h hVarG0 = g0(view);
        if (hVarG0 != null) {
            return hVarG0.m();
        }
        return -1;
    }

    public final void e1() {
        int iJ;
        View focusedChild = (this.f2762m && hasFocus() && this.f2716a != null) ? getFocusedChild() : null;
        h hVarS = focusedChild != null ? S(focusedChild) : null;
        if (hVarS == null) {
            c1();
            return;
        }
        this.f2720a.f2773a = this.f2716a.j() ? hVarS.k() : -1L;
        e eVar = this.f2720a;
        if (this.f2760k) {
            iJ = -1;
        } else {
            iJ = hVarS.v() ? hVarS.f8594b : hVarS.j();
        }
        eVar.f8585f = iJ;
        this.f2720a.f8586g = i0(hVarS.f2786a);
    }

    public h f0(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return g0(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public void f1() {
        int iJ = this.f2731a.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            h hVarG0 = g0(this.f2731a.i(i2));
            if (!hVarG0.J()) {
                hVarG0.E();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public View focusSearch(View view, int i2) {
        View viewJ0;
        boolean z2;
        View viewQ0 = this.f2722a.Q0(view, i2);
        if (viewQ0 != null) {
            return viewQ0;
        }
        boolean z3 = (this.f2716a == null || this.f2722a == null || v0() || this.f2757h) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        if (z3 && (i2 == 2 || i2 == 1)) {
            if (this.f2722a.l()) {
                int i3 = i2 == 2 ? 130 : 33;
                z2 = focusFinder.findNextFocus(this, view, i3) == null;
                if (f8540u) {
                    i2 = i3;
                }
            } else {
                z2 = false;
            }
            if (!z2 && this.f2722a.k()) {
                int i4 = (this.f2722a.Z() == 1) ^ (i2 == 2) ? 66 : 17;
                boolean z4 = focusFinder.findNextFocus(this, view, i4) == null;
                if (f8540u) {
                    i2 = i4;
                }
                z2 = z4;
            }
            if (z2) {
                u();
                if (R(view) == null) {
                    return null;
                }
                r1();
                this.f2722a.J0(view, i2, this.f2726a, this.f2720a);
                t1(false);
            }
            viewJ0 = focusFinder.findNextFocus(this, view, i2);
        } else {
            View viewFindNextFocus = focusFinder.findNextFocus(this, view, i2);
            if (viewFindNextFocus == null && z3) {
                u();
                if (R(view) == null) {
                    return null;
                }
                r1();
                viewJ0 = this.f2722a.J0(view, i2, this.f2726a, this.f2720a);
                t1(false);
            } else {
                viewJ0 = viewFindNextFocus;
            }
        }
        if (viewJ0 == null || viewJ0.hasFocusable()) {
            return w0(view, viewJ0, i2) ? viewJ0 : super.focusSearch(view, i2);
        }
        if (getFocusedChild() == null) {
            return super.focusSearch(view, i2);
        }
        b1(viewJ0, null);
        return view;
    }

    public final void g(h hVar) {
        View view = hVar.f2786a;
        boolean z2 = view.getParent() == this;
        this.f2726a.J(f0(view));
        if (hVar.x()) {
            this.f2731a.c(view, -1, view.getLayoutParams(), true);
        } else if (z2) {
            this.f2731a.k(view);
        } else {
            this.f2731a.b(view, true);
        }
    }

    public boolean g1(int i2, int i3, MotionEvent motionEvent) {
        int i4;
        int i5;
        int i6;
        int i7;
        u();
        if (this.f2716a != null) {
            int[] iArr = this.f2752d;
            iArr[0] = 0;
            iArr[1] = 0;
            h1(i2, i3, iArr);
            int[] iArr2 = this.f2752d;
            int i8 = iArr2[0];
            int i9 = iArr2[1];
            i4 = i9;
            i5 = i8;
            i6 = i2 - i8;
            i7 = i3 - i9;
        } else {
            i4 = 0;
            i5 = 0;
            i6 = 0;
            i7 = 0;
        }
        if (!this.f2735a.isEmpty()) {
            invalidate();
        }
        int[] iArr3 = this.f2752d;
        iArr3[0] = 0;
        iArr3[1] = 0;
        G(i5, i4, i6, i7, this.f2745b, 0, iArr3);
        int[] iArr4 = this.f2752d;
        int i10 = iArr4[0];
        int i11 = i6 - i10;
        int i12 = iArr4[1];
        int i13 = i7 - i12;
        boolean z2 = (i10 == 0 && i12 == 0) ? false : true;
        int i14 = this.f8548i;
        int[] iArr5 = this.f2745b;
        int i15 = iArr5[0];
        this.f8548i = i14 - i15;
        int i16 = this.f8549j;
        int i17 = iArr5[1];
        this.f8549j = i16 - i17;
        int[] iArr6 = this.f2749c;
        iArr6[0] = iArr6[0] + i15;
        iArr6[1] = iArr6[1] + i17;
        if (getOverScrollMode() != 2) {
            if (motionEvent != null && !m.a(motionEvent, 8194)) {
                R0(motionEvent.getX(), i11, motionEvent.getY(), i13);
            }
            t(i2, i3);
        }
        if (i5 != 0 || i4 != 0) {
            I(i5, i4);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        return (!z2 && i5 == 0 && i4 == 0) ? false : true;
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            return lpt2Var.D();
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + P());
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            return lpt2Var.E(getContext(), attributeSet);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + P());
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public com3 getAdapter() {
        return this.f2716a;
    }

    @Override // android.view.View
    public int getBaseline() {
        lpt2 lpt2Var = this.f2722a;
        return lpt2Var != null ? lpt2Var.G() : super.getBaseline();
    }

    @Override // android.view.ViewGroup
    public int getChildDrawingOrder(int i2, int i3) {
        return super.getChildDrawingOrder(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f2744b;
    }

    public androidx.recyclerview.widget.com7 getCompatAccessibilityDelegate() {
        return this.f2730a;
    }

    public com7 getEdgeEffectFactory() {
        return this.f2717a;
    }

    public com8 getItemAnimator() {
        return this.f2719a;
    }

    public int getItemDecorationCount() {
        return this.f2735a.size();
    }

    public lpt2 getLayoutManager() {
        return this.f2722a;
    }

    public int getMaxFlingVelocity() {
        return this.f8552m;
    }

    public int getMinFlingVelocity() {
        return this.f8551l;
    }

    long getNanoTime() {
        if (f8539t) {
            return System.nanoTime();
        }
        return 0L;
    }

    public lpt5 getOnFlingListener() {
        return this.f2723a;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f2762m;
    }

    public lpt8 getRecycledViewPool() {
        return this.f2726a.i();
    }

    public int getScrollState() {
        return this.f2753e;
    }

    public void h(lpt1 lpt1Var) {
        i(lpt1Var, -1);
    }

    public void h1(int i2, int i3, int[] iArr) {
        r1();
        H0();
        p013CoM1.com8.a("RV Scroll");
        Q(this.f2720a);
        int iW1 = i2 != 0 ? this.f2722a.w1(i2, this.f2726a, this.f2720a) : 0;
        int iY1 = i3 != 0 ? this.f2722a.y1(i3, this.f2726a, this.f2720a) : 0;
        p013CoM1.com8.b();
        a1();
        I0();
        t1(false);
        if (iArr != null) {
            iArr[0] = iW1;
            iArr[1] = iY1;
        }
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().j();
    }

    public void i(lpt1 lpt1Var, int i2) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.g("Cannot add item decoration during a scroll  or layout");
        }
        if (this.f2735a.isEmpty()) {
            setWillNotDraw(false);
        }
        if (i2 < 0) {
            this.f2735a.add(lpt1Var);
        } else {
            this.f2735a.add(i2, lpt1Var);
        }
        y0();
        requestLayout();
    }

    public final int i0(View view) {
        int id = view.getId();
        while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
            view = ((ViewGroup) view).getFocusedChild();
            if (view.getId() != -1) {
                id = view.getId();
            }
        }
        return id;
    }

    public void i1(int i2) {
        if (this.f2757h) {
            return;
        }
        v1();
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            lpt2Var.x1(i2);
            awakenScrollBars();
        }
    }

    @Override // android.view.View
    public boolean isAttachedToWindow() {
        return this.f2748c;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f2757h;
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().l();
    }

    public void j(lpt6 lpt6Var) {
        this.f2742b.add(lpt6Var);
    }

    public final String j0(Context context, String str) {
        if (str.charAt(0) == '.') {
            return context.getPackageName() + str;
        }
        if (str.contains(".")) {
            return str;
        }
        return RecyclerView.class.getPackage().getName() + '.' + str;
    }

    public final void j1(com3 com3Var, boolean z2, boolean z3) {
        com3 com3Var2 = this.f2716a;
        if (com3Var2 != null) {
            com3Var2.x(this.f2714a);
            this.f2716a.q(this);
        }
        if (!z2 || z3) {
            V0();
        }
        this.f2727a.v();
        com3 com3Var3 = this.f2716a;
        this.f2716a = com3Var;
        if (com3Var != null) {
            com3Var.v(this.f2714a);
            com3Var.m(this);
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.E0(com3Var3, this.f2716a);
        }
        this.f2726a.x(com3Var3, this.f2716a, z2);
        this.f2720a.f2775a = true;
    }

    public void k(lpt7 lpt7Var) {
        if (this.f2743b == null) {
            this.f2743b = new ArrayList();
        }
        this.f2743b.add(lpt7Var);
    }

    public Rect k0(View view) {
        lpt3 lpt3Var = (lpt3) view.getLayoutParams();
        if (!lpt3Var.f2811a) {
            return lpt3Var.f8610a;
        }
        if (this.f2720a.e() && (lpt3Var.b() || lpt3Var.d())) {
            return lpt3Var.f8610a;
        }
        Rect rect = lpt3Var.f8610a;
        rect.set(0, 0, 0, 0);
        int size = this.f2735a.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2709a.set(0, 0, 0, 0);
            this.f2735a.get(i2).e(this.f2709a, view, this, this.f2720a);
            int i3 = rect.left;
            Rect rect2 = this.f2709a;
            rect.left = i3 + rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        lpt3Var.f2811a = false;
        return rect;
    }

    public boolean k1(h hVar, int i2) {
        if (!v0()) {
            y.y0(hVar.f2786a, i2);
            return true;
        }
        hVar.f8599h = i2;
        this.f2747c.add(hVar);
        return false;
    }

    public void l(h hVar, com8.nul nulVar, com8.nul nulVar2) {
        hVar.G(false);
        if (this.f2719a.a(hVar, nulVar, nulVar2)) {
            N0();
        }
    }

    public final void l0(long j2, h hVar, h hVar2) {
        int iG = this.f2731a.g();
        for (int i2 = 0; i2 < iG; i2++) {
            h hVarG0 = g0(this.f2731a.f(i2));
            if (hVarG0 != hVar && c0(hVarG0) == j2) {
                com3 com3Var = this.f2716a;
                if (com3Var == null || !com3Var.j()) {
                    throw new IllegalStateException("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:" + hVarG0 + " \n View Holder 2:" + hVar + P());
                }
                throw new IllegalStateException("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:" + hVarG0 + " \n View Holder 2:" + hVar + P());
            }
        }
        Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + hVar2 + " cannot be found but it is necessary for " + hVar + P());
    }

    public boolean l1(AccessibilityEvent accessibilityEvent) {
        if (!v0()) {
            return false;
        }
        int iA = accessibilityEvent != null ? v1.a(accessibilityEvent) : 0;
        this.f2738b |= iA != 0 ? iA : 0;
        return true;
    }

    public final void m(h hVar, h hVar2, com8.nul nulVar, com8.nul nulVar2, boolean z2, boolean z3) {
        hVar.G(false);
        if (z2) {
            g(hVar);
        }
        if (hVar != hVar2) {
            if (z3) {
                g(hVar2);
            }
            hVar.f2787a = hVar2;
            g(hVar);
            this.f2726a.J(hVar);
            hVar2.G(false);
            hVar2.f2793b = hVar;
        }
        if (this.f2719a.b(hVar, hVar2, nulVar, nulVar2)) {
            N0();
        }
    }

    public boolean m0() {
        return !this.f2755f || this.f2760k || this.f2727a.p();
    }

    public void m1(int i2, int i3) {
        n1(i2, i3, null);
    }

    public void n(h hVar, com8.nul nulVar, com8.nul nulVar2) {
        g(hVar);
        hVar.G(false);
        if (this.f2719a.c(hVar, nulVar, nulVar2)) {
            N0();
        }
    }

    public final boolean n0() {
        int iG = this.f2731a.g();
        for (int i2 = 0; i2 < iG; i2++) {
            h hVarG0 = g0(this.f2731a.f(i2));
            if (hVarG0 != null && !hVarG0.J() && hVarG0.y()) {
                return true;
            }
        }
        return false;
    }

    public void n1(int i2, int i3, Interpolator interpolator) {
        o1(i2, i3, interpolator, Integer.MIN_VALUE);
    }

    public void o(String str) {
        if (v0()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException("Cannot call this method while RecyclerView is computing a layout or scrolling" + P());
        }
        if (this.f8544d > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException("" + P()));
        }
    }

    public void o0() {
        this.f2727a = new androidx.recyclerview.widget.aux(new com2());
    }

    public void o1(int i2, int i3, Interpolator interpolator, int i4) {
        p1(i2, i3, interpolator, i4, false);
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004e  */
    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        float refreshRate;
        super.onAttachedToWindow();
        this.f8543c = 0;
        this.f2748c = true;
        this.f2755f = this.f2755f && !isLayoutRequested();
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.z(this);
        }
        this.f8555p = false;
        if (f8539t) {
            ThreadLocal<androidx.recyclerview.widget.com1> threadLocal = androidx.recyclerview.widget.com1.f8650a;
            androidx.recyclerview.widget.com1 com1Var = threadLocal.get();
            this.f2729a = com1Var;
            if (com1Var == null) {
                this.f2729a = new androidx.recyclerview.widget.com1();
                Display displayU = y.u(this);
                if (isInEditMode() || displayU == null) {
                    refreshRate = 60.0f;
                } else {
                    refreshRate = displayU.getRefreshRate();
                    if (refreshRate < 30.0f) {
                        refreshRate = 60.0f;
                    }
                }
                androidx.recyclerview.widget.com1 com1Var2 = this.f2729a;
                com1Var2.f8651b = (long) (1.0E9f / refreshRate);
                threadLocal.set(com1Var2);
            }
            this.f2729a.a(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        androidx.recyclerview.widget.com1 com1Var;
        super.onDetachedFromWindow();
        com8 com8Var = this.f2719a;
        if (com8Var != null) {
            com8Var.k();
        }
        v1();
        this.f2748c = false;
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.A(this, this.f2726a);
        }
        this.f2747c.clear();
        removeCallbacks(this.f2741b);
        this.f2733a.j();
        if (!f8539t || (com1Var = this.f2729a) == null) {
            return;
        }
        com1Var.j(this);
        this.f2729a = null;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.f2735a.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2735a.get(i2).g(canvas, this, this.f2720a);
        }
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0062  */
    @Override // android.view.View
    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f2;
        float axisValue;
        if (this.f2722a != null && !this.f2757h && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f2 = this.f2722a.l() ? -motionEvent.getAxisValue(9) : 0.0f;
                axisValue = this.f2722a.k() ? motionEvent.getAxisValue(10) : 0.0f;
            } else if ((motionEvent.getSource() & inet.ipaddr.format.validate.aux.KEY_INFERRED_UPPER_BOUNDARY) != 0) {
                float axisValue2 = motionEvent.getAxisValue(26);
                if (this.f2722a.l()) {
                    f2 = -axisValue2;
                } else if (this.f2722a.k()) {
                    axisValue = axisValue2;
                    f2 = 0.0f;
                } else {
                    f2 = 0.0f;
                    axisValue = 0.0f;
                }
            } else {
                f2 = 0.0f;
                axisValue = 0.0f;
            }
            if (f2 != 0.0f || axisValue != 0.0f) {
                g1((int) (axisValue * this.f2706a), (int) (f2 * this.f8542b), motionEvent);
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        if (this.f2757h) {
            return false;
        }
        this.f2724a = null;
        if (T(motionEvent)) {
            q();
            return true;
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            return false;
        }
        boolean zK = lpt2Var.k();
        boolean zL = this.f2722a.l();
        if (this.f2711a == null) {
            this.f2711a = VelocityTracker.obtain();
        }
        this.f2711a.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.f2758i) {
                this.f2758i = false;
            }
            this.f8545f = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.f8548i = x2;
            this.f8546g = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.f8549j = y2;
            this.f8547h = y2;
            if (this.f2753e == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                u1(1);
            }
            int[] iArr = this.f2749c;
            iArr[1] = 0;
            iArr[0] = 0;
            int i2 = zK;
            if (zL) {
                i2 = (zK ? 1 : 0) | 2;
            }
            s1(i2, 0);
        } else if (actionMasked == 1) {
            this.f2711a.clear();
            u1(0);
        } else if (actionMasked == 2) {
            int iFindPointerIndex = motionEvent.findPointerIndex(this.f8545f);
            if (iFindPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f8545f + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
            if (this.f2753e != 1) {
                int i3 = x3 - this.f8546g;
                int i4 = y3 - this.f8547h;
                if (!zK || Math.abs(i3) <= this.f8550k) {
                    z2 = false;
                } else {
                    this.f8548i = x3;
                    z2 = true;
                }
                if (zL && Math.abs(i4) > this.f8550k) {
                    this.f8549j = y3;
                    z2 = true;
                }
                if (z2) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            q();
        } else if (actionMasked == 5) {
            this.f8545f = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.f8548i = x4;
            this.f8546g = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.f8549j = y4;
            this.f8547h = y4;
        } else if (actionMasked == 6) {
            K0(motionEvent);
        }
        return this.f2753e == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        p013CoM1.com8.a("RV OnLayout");
        B();
        p013CoM1.com8.b();
        this.f2755f = true;
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            w(i2, i3);
            return;
        }
        boolean z2 = false;
        if (lpt2Var.s0()) {
            int mode = View.MeasureSpec.getMode(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.f2722a.Z0(this.f2726a, this.f2720a, i2, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            if (z2 || this.f2716a == null) {
                return;
            }
            if (this.f2720a.f8583d == 1) {
                C();
            }
            this.f2722a.A1(i2, i3);
            this.f2720a.f2778d = true;
            D();
            this.f2722a.D1(i2, i3);
            if (this.f2722a.G1()) {
                this.f2722a.A1(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                this.f2720a.f2778d = true;
                D();
                this.f2722a.D1(i2, i3);
                return;
            }
            return;
        }
        if (this.f2751d) {
            this.f2722a.Z0(this.f2726a, this.f2720a, i2, i3);
            return;
        }
        if (this.f2759j) {
            r1();
            H0();
            P0();
            I0();
            e eVar = this.f2720a;
            if (eVar.f2780f) {
                eVar.f2776b = true;
            } else {
                this.f2727a.j();
                this.f2720a.f2776b = false;
            }
            this.f2759j = false;
            t1(false);
        } else if (this.f2720a.f2780f) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        com3 com3Var = this.f2716a;
        if (com3Var != null) {
            this.f2720a.f8584e = com3Var.f();
        } else {
            this.f2720a.f8584e = 0;
        }
        r1();
        this.f2722a.Z0(this.f2726a, this.f2720a, i2, i3);
        t1(false);
        this.f2720a.f2776b = false;
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (v0()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        this.f2715a = cVar;
        super.onRestoreInstanceState(cVar.k());
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null || (parcelable2 = this.f2715a.f8558b) == null) {
            return;
        }
        lpt2Var.c1(parcelable2);
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        c cVar = new c(super.onSaveInstanceState());
        c cVar2 = this.f2715a;
        if (cVar2 != null) {
            cVar.m(cVar2);
        } else {
            lpt2 lpt2Var = this.f2722a;
            if (lpt2Var != null) {
                cVar.f8558b = lpt2Var.d1();
            } else {
                cVar.f8558b = null;
            }
        }
        return cVar;
    }

    @Override // android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        s0();
    }

    /* JADX WARN: Code duplicated, block: B:47:0x00df A[PHI: r0
      0x00df: PHI (r0v36 int) = (r0v26 int), (r0v40 int) binds: [B:41:0x00c8, B:45:0x00db] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int i2;
        boolean z2;
        boolean z3 = false;
        if (this.f2757h || this.f2758i) {
            return false;
        }
        if (K(motionEvent)) {
            q();
            return true;
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            return false;
        }
        boolean zK = lpt2Var.k();
        boolean zL = this.f2722a.l();
        if (this.f2711a == null) {
            this.f2711a = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            int[] iArr = this.f2749c;
            iArr[1] = 0;
            iArr[0] = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        int[] iArr2 = this.f2749c;
        motionEventObtain.offsetLocation(iArr2[0], iArr2[1]);
        if (actionMasked == 0) {
            this.f8545f = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.f8548i = x2;
            this.f8546g = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.f8549j = y2;
            this.f8547h = y2;
            if (zL) {
                i2 = zK;
                i2 = (zK ? 1 : 0) | 2;
            }
            i2 = zK;
            s1(i2, 0);
        } else if (actionMasked == 1) {
            this.f2711a.addMovement(motionEventObtain);
            this.f2711a.computeCurrentVelocity(1000, this.f8552m);
            float f2 = zK ? -this.f2711a.getXVelocity(this.f8545f) : 0.0f;
            float f3 = zL ? -this.f2711a.getYVelocity(this.f8545f) : 0.0f;
            if ((f2 == 0.0f && f3 == 0.0f) || !a0((int) f2, (int) f3)) {
                setScrollState(0);
            }
            d1();
            z3 = true;
        } else if (actionMasked == 2) {
            int iFindPointerIndex = motionEvent.findPointerIndex(this.f8545f);
            if (iFindPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f8545f + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
            int iMax = this.f8548i - x3;
            int iMax2 = this.f8549j - y3;
            if (this.f2753e != 1) {
                if (zK) {
                    iMax = iMax > 0 ? Math.max(0, iMax - this.f8550k) : Math.min(0, iMax + this.f8550k);
                    if (iMax != 0) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                } else {
                    z2 = false;
                }
                if (zL) {
                    iMax2 = iMax2 > 0 ? Math.max(0, iMax2 - this.f8550k) : Math.min(0, iMax2 + this.f8550k);
                    if (iMax2 != 0) {
                        z2 = true;
                    }
                }
                if (z2) {
                    setScrollState(1);
                }
            }
            int i3 = iMax;
            int i4 = iMax2;
            if (this.f2753e == 1) {
                int[] iArr3 = this.f2752d;
                iArr3[0] = 0;
                iArr3[1] = 0;
                if (F(zK ? i3 : 0, zL ? i4 : 0, iArr3, this.f2745b, 0)) {
                    int[] iArr4 = this.f2752d;
                    i3 -= iArr4[0];
                    i4 -= iArr4[1];
                    int[] iArr5 = this.f2749c;
                    int i5 = iArr5[0];
                    int[] iArr6 = this.f2745b;
                    iArr5[0] = i5 + iArr6[0];
                    iArr5[1] = iArr5[1] + iArr6[1];
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                int i6 = i4;
                int[] iArr7 = this.f2745b;
                this.f8548i = x3 - iArr7[0];
                this.f8549j = y3 - iArr7[1];
                if (g1(zK ? i3 : 0, zL ? i6 : 0, motionEvent)) {
                    getParent().requestDisallowInterceptTouchEvent(true);
                }
                androidx.recyclerview.widget.com1 com1Var = this.f2729a;
                if (com1Var != null && (i3 != 0 || i6 != 0)) {
                    com1Var.f(this, i3, i6);
                }
            }
        } else if (actionMasked == 3) {
            q();
        } else if (actionMasked == 5) {
            this.f8545f = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.f8548i = x4;
            this.f8546g = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.f8549j = y4;
            this.f8547h = y4;
        } else if (actionMasked == 6) {
            K0(motionEvent);
        }
        if (!z3) {
            this.f2711a.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public boolean p(h hVar) {
        com8 com8Var = this.f2719a;
        return com8Var == null || com8Var.g(hVar, hVar.o());
    }

    @SuppressLint({"InlinedApi"})
    public final void p0() {
        if (y.z(this) == 0) {
            y.z0(this, 8);
        }
    }

    public void p1(int i2, int i3, Interpolator interpolator, int i4, boolean z2) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f2757h) {
            return;
        }
        if (!lpt2Var.k()) {
            i2 = 0;
        }
        if (!this.f2722a.l()) {
            i3 = 0;
        }
        if (i2 == 0 && i3 == 0) {
            return;
        }
        if (!(i4 == Integer.MIN_VALUE || i4 > 0)) {
            scrollBy(i2, i3);
            return;
        }
        if (z2) {
            int i5 = i2 != 0 ? 1 : 0;
            if (i3 != 0) {
                i5 |= 2;
            }
            s1(i5, 1);
        }
        this.f2721a.f(i2, i3, i4, interpolator);
    }

    public final void q() {
        d1();
        setScrollState(0);
    }

    public final void q0() {
        this.f2731a = new androidx.recyclerview.widget.con(new com1());
    }

    public void q1(int i2) {
        if (this.f2757h) {
            return;
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            lpt2Var.I1(this, this.f2720a, i2);
        }
    }

    public void r0(StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2) {
        if (stateListDrawable != null && drawable != null && stateListDrawable2 != null && drawable2 != null) {
            Resources resources = getContext().getResources();
            new androidx.recyclerview.widget.prn(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(p073cOM4.a.f8852a), resources.getDimensionPixelSize(p073cOM4.a.f8854c), resources.getDimensionPixelOffset(p073cOM4.a.f8853b));
        } else {
            throw new IllegalArgumentException("Trying to set fast scroller without both required drawables." + P());
        }
    }

    public void r1() {
        int i2 = this.f2707a + 1;
        this.f2707a = i2;
        if (i2 != 1 || this.f2757h) {
            return;
        }
        this.f2756g = false;
    }

    @Override // android.view.ViewGroup
    public void removeDetachedView(View view, boolean z2) {
        h hVarG0 = g0(view);
        if (hVarG0 != null) {
            if (hVarG0.x()) {
                hVarG0.f();
            } else if (!hVarG0.J()) {
                throw new IllegalArgumentException("Called removeDetachedView with a view which is not flagged as tmp detached." + hVarG0 + P());
            }
        }
        view.clearAnimation();
        z(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        if (!this.f2722a.b1(this, this.f2720a, view, view2) && view2 != null) {
            b1(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.f2722a.r1(this, view, rect, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z2) {
        int size = this.f2742b.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f2742b.get(i2).b(z2);
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        if (this.f2707a != 0 || this.f2757h) {
            this.f2756g = true;
        } else {
            super.requestLayout();
        }
    }

    public void s() {
        int iJ = this.f2731a.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            h hVarG0 = g0(this.f2731a.i(i2));
            if (!hVarG0.J()) {
                hVarG0.c();
            }
        }
        this.f2726a.d();
    }

    public void s0() {
        this.f2750d = null;
        this.f2740b = null;
        this.f2746c = null;
        this.f2713a = null;
    }

    public boolean s1(int i2, int i3) {
        return getScrollingChildHelper().p(i2, i3);
    }

    @Override // android.view.View
    public void scrollBy(int i2, int i3) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f2757h) {
            return;
        }
        boolean zK = lpt2Var.k();
        boolean zL = this.f2722a.l();
        if (zK || zL) {
            if (!zK) {
                i2 = 0;
            }
            if (!zL) {
                i3 = 0;
            }
            g1(i2, i3, null);
        }
    }

    @Override // android.view.View
    public void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (l1(accessibilityEvent)) {
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAccessibilityDelegateCompat(androidx.recyclerview.widget.com7 com7Var) {
        this.f2730a = com7Var;
        y.o0(this, com7Var);
    }

    public void setAdapter(com3 com3Var) {
        setLayoutFrozen(false);
        j1(com3Var, false, true);
        Q0(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(com6 com6Var) {
        if (com6Var == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(false);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.f2744b) {
            s0();
        }
        this.f2744b = z2;
        super.setClipToPadding(z2);
        if (this.f2755f) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(com7 com7Var) {
        u2.f(com7Var);
        this.f2717a = com7Var;
        s0();
    }

    public void setHasFixedSize(boolean z2) {
        this.f2751d = z2;
    }

    public void setItemAnimator(com8 com8Var) {
        com8 com8Var2 = this.f2719a;
        if (com8Var2 != null) {
            com8Var2.k();
            this.f2719a.v(null);
        }
        this.f2719a = com8Var;
        if (com8Var != null) {
            com8Var.v(this.f2718a);
        }
    }

    public void setItemViewCacheSize(int i2) {
        this.f2726a.G(i2);
    }

    @Deprecated
    public void setLayoutFrozen(boolean z2) {
        suppressLayout(z2);
    }

    public void setLayoutManager(lpt2 lpt2Var) {
        if (lpt2Var == this.f2722a) {
            return;
        }
        v1();
        if (this.f2722a != null) {
            com8 com8Var = this.f2719a;
            if (com8Var != null) {
                com8Var.k();
            }
            this.f2722a.k1(this.f2726a);
            this.f2722a.l1(this.f2726a);
            this.f2726a.c();
            if (this.f2748c) {
                this.f2722a.A(this, this.f2726a);
            }
            this.f2722a.E1(null);
            this.f2722a = null;
        } else {
            this.f2726a.c();
        }
        this.f2731a.o();
        this.f2722a = lpt2Var;
        if (lpt2Var != null) {
            if (lpt2Var.f2797a != null) {
                throw new IllegalArgumentException("LayoutManager " + lpt2Var + " is already attached to a RecyclerView:" + lpt2Var.f2797a.P());
            }
            lpt2Var.E1(this);
            if (this.f2748c) {
                this.f2722a.z(this);
            }
        }
        this.f2726a.K();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        getScrollingChildHelper().m(z2);
    }

    public void setOnFlingListener(lpt5 lpt5Var) {
        this.f2723a = lpt5Var;
    }

    @Deprecated
    public void setOnScrollListener(lpt7 lpt7Var) {
        this.f2725a = lpt7Var;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.f2762m = z2;
    }

    public void setRecycledViewPool(lpt8 lpt8Var) {
        this.f2726a.E(lpt8Var);
    }

    public void setRecyclerListener(a aVar) {
    }

    void setScrollState(int i2) {
        if (i2 == this.f2753e) {
            return;
        }
        this.f2753e = i2;
        if (i2 != 2) {
            w1();
        }
        H(i2);
    }

    public void setScrollingTouchSlop(int i2) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                this.f8550k = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
        }
        this.f8550k = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(f fVar) {
        this.f2726a.F(fVar);
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().o(i2);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        getScrollingChildHelper().q();
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z2) {
        if (z2 != this.f2757h) {
            o("Do not suppressLayout in layout or scroll");
            if (z2) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0));
                this.f2757h = true;
                this.f2758i = true;
                v1();
                return;
            }
            this.f2757h = false;
            if (this.f2756g && this.f2722a != null && this.f2716a != null) {
                requestLayout();
            }
            this.f2756g = false;
        }
    }

    public void t(int i2, int i3) {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f2713a;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            zIsFinished = false;
        } else {
            this.f2713a.onRelease();
            zIsFinished = this.f2713a.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f2746c;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.f2746c.onRelease();
            zIsFinished |= this.f2746c.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f2740b;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.f2740b.onRelease();
            zIsFinished |= this.f2740b.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f2750d;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.f2750d.onRelease();
            zIsFinished |= this.f2750d.isFinished();
        }
        if (zIsFinished) {
            y.f0(this);
        }
    }

    public void t0() {
        if (this.f2735a.size() == 0) {
            return;
        }
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.g("Cannot invalidate item decorations during a scroll or layout");
        }
        y0();
        requestLayout();
    }

    public void t1(boolean z2) {
        if (this.f2707a < 1) {
            this.f2707a = 1;
        }
        if (!z2 && !this.f2757h) {
            this.f2756g = false;
        }
        if (this.f2707a == 1) {
            if (z2 && this.f2756g && !this.f2757h && this.f2722a != null && this.f2716a != null) {
                B();
            }
            if (!this.f2757h) {
                this.f2756g = false;
            }
        }
        this.f2707a--;
    }

    public void u() {
        if (!this.f2755f || this.f2760k) {
            p013CoM1.com8.a("RV FullInvalidate");
            B();
            p013CoM1.com8.b();
            return;
        }
        if (this.f2727a.p()) {
            if (!this.f2727a.o(4) || this.f2727a.o(11)) {
                if (this.f2727a.p()) {
                    p013CoM1.com8.a("RV FullInvalidate");
                    B();
                    p013CoM1.com8.b();
                    return;
                }
                return;
            }
            p013CoM1.com8.a("RV PartialInvalidate");
            r1();
            H0();
            this.f2727a.t();
            if (!this.f2756g) {
                if (n0()) {
                    B();
                } else {
                    this.f2727a.i();
                }
            }
            t1(true);
            I0();
            p013CoM1.com8.b();
        }
    }

    public boolean u0() {
        AccessibilityManager accessibilityManager = this.f2712a;
        return accessibilityManager != null && accessibilityManager.isEnabled();
    }

    public void u1(int i2) {
        getScrollingChildHelper().r(i2);
    }

    public final void v(Context context, String str, AttributeSet attributeSet, int i2, int i3) {
        Constructor constructor;
        Object[] objArr;
        if (str != null) {
            String strTrim = str.trim();
            if (strTrim.isEmpty()) {
                return;
            }
            String strJ0 = j0(context, strTrim);
            try {
                Class<? extends U> clsAsSubclass = Class.forName(strJ0, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(lpt2.class);
                try {
                    constructor = clsAsSubclass.getConstructor(f2705a);
                    objArr = new Object[]{context, attributeSet, Integer.valueOf(i2), Integer.valueOf(i3)};
                } catch (NoSuchMethodException e2) {
                    try {
                        constructor = clsAsSubclass.getConstructor(new Class[0]);
                        objArr = null;
                    } catch (NoSuchMethodException e3) {
                        e3.initCause(e2);
                        throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + strJ0, e3);
                    }
                }
                constructor.setAccessible(true);
                setLayoutManager((lpt2) constructor.newInstance(objArr));
            } catch (ClassCastException e4) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + strJ0, e4);
            } catch (ClassNotFoundException e5) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + strJ0, e5);
            } catch (IllegalAccessException e6) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + strJ0, e6);
            } catch (InstantiationException e7) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + strJ0, e7);
            } catch (InvocationTargetException e8) {
                throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + strJ0, e8);
            }
        }
    }

    public boolean v0() {
        return this.f8543c > 0;
    }

    public void v1() {
        setScrollState(0);
        w1();
    }

    public void w(int i2, int i3) {
        setMeasuredDimension(lpt2.n(i2, getPaddingLeft() + getPaddingRight(), y.C(this)), lpt2.n(i3, getPaddingTop() + getPaddingBottom(), y.B(this)));
    }

    public final boolean w0(View view, View view2, int i2) {
        int i3;
        if (view2 == null || view2 == this || R(view2) == null) {
            return false;
        }
        if (view == null || R(view) == null) {
            return true;
        }
        this.f2709a.set(0, 0, view.getWidth(), view.getHeight());
        this.f2739b.set(0, 0, view2.getWidth(), view2.getHeight());
        offsetDescendantRectToMyCoords(view, this.f2709a);
        offsetDescendantRectToMyCoords(view2, this.f2739b);
        byte b2 = -1;
        int i4 = this.f2722a.Z() == 1 ? -1 : 1;
        Rect rect = this.f2709a;
        int i5 = rect.left;
        Rect rect2 = this.f2739b;
        int i6 = rect2.left;
        if ((i5 < i6 || rect.right <= i6) && rect.right < rect2.right) {
            i3 = 1;
        } else {
            int i7 = rect.right;
            int i8 = rect2.right;
            i3 = ((i7 > i8 || i5 >= i8) && i5 > i6) ? -1 : 0;
        }
        int i9 = rect.top;
        int i10 = rect2.top;
        if ((i9 < i10 || rect.bottom <= i10) && rect.bottom < rect2.bottom) {
            b2 = 1;
        } else {
            int i11 = rect.bottom;
            int i12 = rect2.bottom;
            if ((i11 <= i12 && i9 < i12) || i9 <= i10) {
                b2 = 0;
            }
        }
        if (i2 == 1) {
            return b2 < 0 || (b2 == 0 && i3 * i4 <= 0);
        }
        if (i2 == 2) {
            return b2 > 0 || (b2 == 0 && i3 * i4 >= 0);
        }
        if (i2 == 17) {
            return i3 < 0;
        }
        if (i2 == 33) {
            return b2 < 0;
        }
        if (i2 == 66) {
            return i3 > 0;
        }
        if (i2 == 130) {
            return b2 > 0;
        }
        throw new IllegalArgumentException("Invalid direction: " + i2 + P());
    }

    public final void w1() {
        this.f2721a.g();
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            lpt2Var.K1();
        }
    }

    public final boolean x(int i2, int i3) {
        U(this.f2737a);
        int[] iArr = this.f2737a;
        return (iArr[0] == i2 && iArr[1] == i3) ? false : true;
    }

    public void x0(int i2) {
        if (this.f2722a == null) {
            return;
        }
        setScrollState(2);
        this.f2722a.x1(i2);
        awakenScrollBars();
    }

    public void x1(int i2, int i3, Object obj) {
        int i4;
        int iJ = this.f2731a.j();
        int i5 = i2 + i3;
        for (int i6 = 0; i6 < iJ; i6++) {
            View viewI = this.f2731a.i(i6);
            h hVarG0 = g0(viewI);
            if (hVarG0 != null && !hVarG0.J() && (i4 = hVarG0.f8593a) >= i2 && i4 < i5) {
                hVarG0.b(2);
                hVarG0.a(obj);
                ((lpt3) viewI.getLayoutParams()).f2811a = true;
            }
        }
        this.f2726a.M(i2, i3);
    }

    public void y(View view) {
        h hVarG0 = g0(view);
        F0(view);
        com3 com3Var = this.f2716a;
        if (com3Var != null && hVarG0 != null) {
            com3Var.s(hVarG0);
        }
        List<lpt4> list = this.f2736a;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2736a.get(size).b(view);
            }
        }
    }

    public void y0() {
        int iJ = this.f2731a.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            ((lpt3) this.f2731a.i(i2).getLayoutParams()).f2811a = true;
        }
        this.f2726a.s();
    }

    public void z(View view) {
        h hVarG0 = g0(view);
        G0(view);
        com3 com3Var = this.f2716a;
        if (com3Var != null && hVarG0 != null) {
            com3Var.t(hVarG0);
        }
        List<lpt4> list = this.f2736a;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2736a.get(size).a(view);
            }
        }
    }

    public void z0() {
        int iJ = this.f2731a.j();
        for (int i2 = 0; i2 < iJ; i2++) {
            h hVarG0 = g0(this.f2731a.i(i2));
            if (hVarG0 != null && !hVarG0.J()) {
                hVarG0.b(6);
            }
        }
        y0();
        this.f2726a.t();
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2714a = new b();
        this.f2726a = new lpt9();
        this.f2733a = new androidx.recyclerview.widget.lpt3();
        this.f2734a = new aux();
        this.f2709a = new Rect();
        this.f2739b = new Rect();
        this.f2710a = new RectF();
        this.f2735a = new ArrayList<>();
        this.f2742b = new ArrayList<>();
        this.f2707a = 0;
        this.f2760k = false;
        this.f2761l = false;
        this.f8543c = 0;
        this.f8544d = 0;
        this.f2717a = new com7();
        this.f2719a = new androidx.recyclerview.widget.nul();
        this.f2753e = 0;
        this.f8545f = -1;
        this.f2706a = Float.MIN_VALUE;
        this.f8542b = Float.MIN_VALUE;
        this.f2762m = true;
        this.f2721a = new g();
        this.f2728a = f8539t ? new androidx.recyclerview.widget.com1.con() : null;
        this.f2720a = new e();
        this.f8553n = false;
        this.f8554o = false;
        this.f2718a = new com9();
        this.f8555p = false;
        this.f2737a = new int[2];
        this.f2745b = new int[2];
        this.f2749c = new int[2];
        this.f2752d = new int[2];
        this.f2747c = new ArrayList();
        this.f2741b = new con();
        this.f2732a = new prn();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f8550k = viewConfiguration.getScaledTouchSlop();
        this.f2706a = j0.a(viewConfiguration, context);
        this.f8542b = j0.b(viewConfiguration, context);
        this.f8551l = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f8552m = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.f2719a.v(this.f2718a);
        o0();
        q0();
        p0();
        if (y.y(this) == 0) {
            y.y0(this, 1);
        }
        this.f2712a = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new androidx.recyclerview.widget.com7(this));
        int[] iArr = p073cOM4.b.f3049f;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i2, 0);
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, typedArrayObtainStyledAttributes, i2, 0);
        }
        String string = typedArrayObtainStyledAttributes.getString(p073cOM4.b.f8863i);
        if (typedArrayObtainStyledAttributes.getInt(p073cOM4.b.f8857c, -1) == -1) {
            setDescendantFocusability(inet.ipaddr.format.validate.aux.KEY_STANDARD_STR);
        }
        this.f2744b = typedArrayObtainStyledAttributes.getBoolean(p073cOM4.b.f8856b, true);
        boolean z2 = typedArrayObtainStyledAttributes.getBoolean(p073cOM4.b.f8858d, false);
        this.f2754e = z2;
        if (z2) {
            r0((StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(p073cOM4.b.f8861g), typedArrayObtainStyledAttributes.getDrawable(p073cOM4.b.f8862h), (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(p073cOM4.b.f8859e), typedArrayObtainStyledAttributes.getDrawable(p073cOM4.b.f8860f));
        }
        typedArrayObtainStyledAttributes.recycle();
        v(context, string, attributeSet, i2, 0);
        int[] iArr2 = f8535e;
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i2, 0);
        if (i3 >= 29) {
            saveAttributeDataForStyleable(context, iArr2, attributeSet, typedArrayObtainStyledAttributes2, i2, 0);
        }
        boolean z3 = typedArrayObtainStyledAttributes2.getBoolean(0, true);
        typedArrayObtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z3);
    }

    public static class c extends COM2.aux {
        public static final Parcelable.Creator<c> CREATOR = new aux();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public Parcelable f8558b;

        public static class aux implements Parcelable.ClassLoaderCreator<c> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel) {
                return new c(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public c createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new c(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public c[] newArray(int i2) {
                return new c[i2];
            }
        }

        public c(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f8558b = parcel.readParcelable(classLoader == null ? lpt2.class.getClassLoader() : classLoader);
        }

        public void m(c cVar) {
            this.f8558b = cVar.f8558b;
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeParcelable(this.f8558b, 0);
        }

        public c(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public static class lpt3 extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Rect f8610a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public h f2810a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2811a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8611b;

        public lpt3(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f8610a = new Rect();
            this.f2811a = true;
            this.f8611b = false;
        }

        public int a() {
            return this.f2810a.m();
        }

        public boolean b() {
            return this.f2810a.y();
        }

        public boolean c() {
            return this.f2810a.v();
        }

        public boolean d() {
            return this.f2810a.t();
        }

        public lpt3(int i2, int i3) {
            super(i2, i3);
            this.f8610a = new Rect();
            this.f2811a = true;
            this.f8611b = false;
        }

        public lpt3(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f8610a = new Rect();
            this.f2811a = true;
            this.f8611b = false;
        }

        public lpt3(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f8610a = new Rect();
            this.f2811a = true;
            this.f8611b = false;
        }

        public lpt3(lpt3 lpt3Var) {
            super((ViewGroup.LayoutParams) lpt3Var);
            this.f8610a = new Rect();
            this.f2811a = true;
            this.f8611b = false;
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        lpt2 lpt2Var = this.f2722a;
        if (lpt2Var != null) {
            return lpt2Var.F(layoutParams);
        }
        throw new IllegalStateException("RecyclerView has no LayoutManager" + P());
    }
}
