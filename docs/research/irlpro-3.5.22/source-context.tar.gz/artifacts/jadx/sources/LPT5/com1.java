package LPT5;

import android.content.Context;
import app.irlpro.android.R;
import com.newrelic.agent.android.payload.PayloadController;
import com.wmspanel.libstream.lpt5;
import com.wmspanel.streamer.Connection;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class com1 extends prn {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public double f6644c;

    public com1(Context context) {
        super(context);
    }

    public boolean C() {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (((prn) this).f889b.size() < 2) {
            return false;
        }
        int size = ((prn) this).f889b.size() - 1;
        aux auxVar = ((prn) this).f889b.get(size);
        aux auxVar2 = ((prn) this).f889b.get(size - 1);
        long j2 = jCurrentTimeMillis - auxVar.f6642a;
        long j3 = auxVar.f6643b;
        long j4 = auxVar2.f6643b;
        if (j3 >= j4 || j2 <= 20000) {
            return j3 > j4 && j2 > 10000;
        }
        return true;
    }

    @Override // LPT5.prn
    public void g(long j2, long j3) {
        double dMin = super.f6676c;
        for (Map.Entry<Integer, Connection> entry : ((prn) this).f890b.entrySet()) {
            Integer key = entry.getKey();
            entry.getValue();
            com7 com7Var = ((prn) this).f885a.get(key);
            if (com7Var != null) {
                double dC = com7Var.c();
                double dB = com7Var.b();
                int i2 = ((prn) this).f888b;
                double dFloor = i2;
                if (dB < ((double) (i2 / 8)) * 0.95d && dB < 0.95d * dC) {
                    dFloor = Math.floor(((((double) i2) * (dB / dC)) + 30000.0d) / 100000.0d) * 100000.0d;
                }
                if (dFloor < dMin) {
                    dMin = Math.max(dFloor, this.f6644c);
                }
            }
        }
        if (System.currentTimeMillis() - ((aux) con.c(((prn) this).f889b)).f6642a < PayloadController.PAYLOAD_COLLECTOR_TIMEOUT) {
            return;
        }
        int i3 = ((prn) this).f888b;
        if (dMin >= i3 && i3 < super.f6676c && C()) {
            dMin = Math.min(super.f6676c, ((double) ((prn) this).f888b) + Math.max(100000.0d, Math.min(500000.0d, ((double) super.f6676c) * 0.1d)));
        }
        if (Math.abs(((double) ((prn) this).f888b) - dMin) > 99000.0d) {
            e((long) dMin);
        }
    }

    @Override // LPT5.prn
    public long i() {
        return 1000L;
    }

    @Override // LPT5.prn
    public String j() {
        return ((prn) this).f879a.getString(R.string.adaptive_bitrate_hybrid);
    }

    @Override // LPT5.prn
    public void x(int i2) {
        ((prn) this).f888b = i2;
        this.f6644c = ((double) i2) * 0.25d;
        super.x(i2);
    }

    @Override // LPT5.prn
    public void z(lpt5 lpt5Var, int i2) {
        this.f6644c = ((double) i2) * 0.25d;
        super.z(lpt5Var, i2);
    }
}
