package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.com3;
import androidx.appcompat.view.menu.com5;
import androidx.appcompat.view.menu.com6;
import p022CoN.u0;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuView extends androidx.appcompat.widget.con implements androidx.appcompat.view.menu.com1.con, com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Context f7865a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.view.menu.com1.aux f1970a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.view.menu.com1 f1971a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1972a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1973a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.widget.aux f1974a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f7866d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f7867e;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f7868j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f7869k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f7870l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f7871m;

    public interface aux {
        boolean a();

        boolean c();
    }

    public interface com1 {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    public static class con implements com5.aux {
        @Override // androidx.appcompat.view.menu.com5.aux
        public void c(androidx.appcompat.view.menu.com1 com1Var, boolean z2) {
        }

        @Override // androidx.appcompat.view.menu.com5.aux
        public boolean d(androidx.appcompat.view.menu.com1 com1Var) {
            return false;
        }
    }

    public static class nul extends androidx.appcompat.widget.con.aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        @ViewDebug.ExportedProperty
        public int f7872a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        @ViewDebug.ExportedProperty
        public boolean f1975a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        @ViewDebug.ExportedProperty
        public int f7873b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        @ViewDebug.ExportedProperty
        public boolean f1976b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        @ViewDebug.ExportedProperty
        public boolean f7874c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f7875d;

        public nul(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public nul(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public nul(nul nulVar) {
            super(nulVar);
            this.f1975a = nulVar.f1975a;
        }

        public nul(int i2, int i3) {
            super(i2, i3);
            this.f1975a = false;
        }
    }

    public class prn implements androidx.appcompat.view.menu.com1.aux {
        public prn() {
        }

        @Override // androidx.appcompat.view.menu.com1.aux
        public void a(androidx.appcompat.view.menu.com1 com1Var) {
            androidx.appcompat.view.menu.com1.aux auxVar = ActionMenuView.this.f1970a;
            if (auxVar != null) {
                auxVar.a(com1Var);
            }
        }

        @Override // androidx.appcompat.view.menu.com1.aux
        public boolean b(androidx.appcompat.view.menu.com1 com1Var, MenuItem menuItem) {
            com1 com1Var2 = ActionMenuView.this.f1973a;
            return com1Var2 != null && com1Var2.onMenuItemClick(menuItem);
        }
    }

    public ActionMenuView(Context context) {
        this(context, null);
    }

    /* JADX WARN: Code duplicated, block: B:23:0x004c  */
    public static int J(View view, int i2, int i3, int i4, int i5) {
        int i6;
        nul nulVar = (nul) view.getLayoutParams();
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i4) - i5, View.MeasureSpec.getMode(i4));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean z2 = actionMenuItemView != null && actionMenuItemView.f();
        if (i3 > 0) {
            i6 = 2;
            if (!z2 || i3 >= 2) {
                view.measure(View.MeasureSpec.makeMeasureSpec(i3 * i2, Integer.MIN_VALUE), iMakeMeasureSpec);
                int measuredWidth = view.getMeasuredWidth();
                int i7 = measuredWidth / i2;
                if (measuredWidth % i2 != 0) {
                    i7++;
                }
                if (!z2 || i7 >= 2) {
                    i6 = i7;
                }
            } else {
                i6 = 0;
            }
        } else {
            i6 = 0;
        }
        nulVar.f1976b = !nulVar.f1975a && z2;
        nulVar.f7872a = i6;
        view.measure(View.MeasureSpec.makeMeasureSpec(i2 * i6, 1073741824), iMakeMeasureSpec);
        return i6;
    }

    @Override // androidx.appcompat.widget.con
    /* JADX INFO: renamed from: A, reason: merged with bridge method [inline-methods] */
    public nul generateDefaultLayoutParams() {
        nul nulVar = new nul(-2, -2);
        ((LinearLayout.LayoutParams) nulVar).gravity = 16;
        return nulVar;
    }

    @Override // androidx.appcompat.widget.con
    /* JADX INFO: renamed from: B, reason: merged with bridge method [inline-methods] */
    public nul generateLayoutParams(AttributeSet attributeSet) {
        return new nul(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.con
    /* JADX INFO: renamed from: C, reason: merged with bridge method [inline-methods] */
    public nul generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams == null) {
            return generateDefaultLayoutParams();
        }
        nul nulVar = layoutParams instanceof nul ? new nul((nul) layoutParams) : new nul(layoutParams);
        if (((LinearLayout.LayoutParams) nulVar).gravity <= 0) {
            ((LinearLayout.LayoutParams) nulVar).gravity = 16;
        }
        return nulVar;
    }

    public nul D() {
        nul nulVarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
        nulVarGenerateDefaultLayoutParams.f1975a = true;
        return nulVarGenerateDefaultLayoutParams;
    }

    public boolean E(int i2) {
        boolean zC = false;
        if (i2 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i2 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i2);
        if (i2 < getChildCount() && (childAt instanceof aux)) {
            zC = false | ((aux) childAt).c();
        }
        return (i2 <= 0 || !(childAt2 instanceof aux)) ? zC : zC | ((aux) childAt2).a();
    }

    public boolean F() {
        androidx.appcompat.widget.aux auxVar = this.f1974a;
        return auxVar != null && auxVar.B();
    }

    public boolean G() {
        androidx.appcompat.widget.aux auxVar = this.f1974a;
        return auxVar != null && auxVar.D();
    }

    public boolean H() {
        androidx.appcompat.widget.aux auxVar = this.f1974a;
        return auxVar != null && auxVar.E();
    }

    public boolean I() {
        return this.f7866d;
    }

    /* JADX WARN: Type inference failed for: r14v10 */
    /* JADX WARN: Type inference failed for: r14v11, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r14v14 */
    public final void K(int i2, int i3) {
        boolean z2;
        int i4;
        int i5;
        boolean z3;
        ?? r14;
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i2);
        int size2 = View.MeasureSpec.getSize(i3);
        int paddingLeft = getPaddingLeft() + getPaddingRight();
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i3, paddingTop, -2);
        int i6 = size - paddingLeft;
        int i7 = this.f7870l;
        int i8 = i6 / i7;
        int i9 = i6 % i7;
        if (i8 == 0) {
            setMeasuredDimension(i6, 0);
            return;
        }
        int i10 = i7 + (i9 / i8);
        int childCount = getChildCount();
        int iMax = 0;
        int i11 = 0;
        boolean z4 = false;
        int i12 = 0;
        int iMax2 = 0;
        int i13 = 0;
        long j2 = 0;
        while (i11 < childCount) {
            View childAt = getChildAt(i11);
            int i14 = size2;
            if (childAt.getVisibility() != 8) {
                boolean z5 = childAt instanceof ActionMenuItemView;
                int i15 = i12 + 1;
                if (z5) {
                    int i16 = this.f7871m;
                    r14 = 0;
                    childAt.setPadding(i16, 0, i16, 0);
                } else {
                    r14 = 0;
                }
                nul nulVar = (nul) childAt.getLayoutParams();
                nulVar.f7875d = r14;
                nulVar.f7873b = r14;
                nulVar.f7872a = r14;
                nulVar.f1976b = r14;
                ((LinearLayout.LayoutParams) nulVar).leftMargin = r14;
                ((LinearLayout.LayoutParams) nulVar).rightMargin = r14;
                nulVar.f7874c = z5 && ((ActionMenuItemView) childAt).f();
                int iJ = J(childAt, i10, nulVar.f1975a ? 1 : i8, childMeasureSpec, paddingTop);
                iMax2 = Math.max(iMax2, iJ);
                if (nulVar.f1976b) {
                    i13++;
                }
                if (nulVar.f1975a) {
                    z4 = true;
                }
                i8 -= iJ;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (iJ == 1) {
                    j2 |= (long) (1 << i11);
                    iMax = iMax;
                }
                i12 = i15;
            }
            i11++;
            size2 = i14;
        }
        int i17 = size2;
        boolean z6 = z4 && i12 == 2;
        boolean z7 = false;
        while (true) {
            if (i13 <= 0 || i8 <= 0) {
                z2 = z7;
                i4 = iMax;
                break;
            }
            int i18 = Integer.MAX_VALUE;
            int i19 = 0;
            int i20 = 0;
            long j3 = 0;
            while (i20 < childCount) {
                boolean z8 = z7;
                nul nulVar2 = (nul) getChildAt(i20).getLayoutParams();
                int i21 = iMax;
                if (nulVar2.f1976b) {
                    int i22 = nulVar2.f7872a;
                    if (i22 < i18) {
                        j3 = 1 << i20;
                        i18 = i22;
                        i19 = 1;
                    } else if (i22 == i18) {
                        i19++;
                        j3 |= 1 << i20;
                    }
                }
                i20++;
                iMax = i21;
                z7 = z8;
            }
            z2 = z7;
            i4 = iMax;
            j2 |= j3;
            if (i19 > i8) {
                break;
            }
            int i23 = i18 + 1;
            int i24 = 0;
            while (i24 < childCount) {
                View childAt2 = getChildAt(i24);
                nul nulVar3 = (nul) childAt2.getLayoutParams();
                int i25 = i6;
                int i26 = mode;
                long j4 = 1 << i24;
                if ((j3 & j4) == 0) {
                    if (nulVar3.f7872a == i23) {
                        j2 |= j4;
                    }
                    z6 = z6;
                } else {
                    if (z6 && nulVar3.f7874c && i8 == 1) {
                        int i27 = this.f7871m;
                        childAt2.setPadding(i27 + i10, 0, i27, 0);
                    }
                    nulVar3.f7872a++;
                    nulVar3.f7875d = true;
                    i8--;
                }
                i24++;
                mode = i26;
                i6 = i25;
                z6 = z6;
            }
            iMax = i4;
            z7 = true;
        }
        boolean z9 = !z4 && i12 == 1;
        if (i8 <= 0 || j2 == 0 || (i8 >= i12 - 1 && !z9 && iMax2 <= 1)) {
            i5 = 0;
            z3 = z2;
        } else {
            float fBitCount = Long.bitCount(j2);
            if (z9) {
                i5 = 0;
            } else {
                i5 = 0;
                if ((j2 & 1) != 0 && !((nul) getChildAt(0).getLayoutParams()).f7874c) {
                    fBitCount -= 0.5f;
                }
                int i28 = childCount - 1;
                if ((j2 & ((long) (1 << i28))) != 0 && !((nul) getChildAt(i28).getLayoutParams()).f7874c) {
                    fBitCount -= 0.5f;
                }
            }
            int i29 = fBitCount > 0.0f ? (int) ((i8 * i10) / fBitCount) : i5;
            z3 = z2;
            for (int i30 = i5; i30 < childCount; i30++) {
                if ((j2 & ((long) (1 << i30))) != 0) {
                    View childAt3 = getChildAt(i30);
                    nul nulVar4 = (nul) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        nulVar4.f7873b = i29;
                        nulVar4.f7875d = true;
                        if (i30 == 0 && !nulVar4.f7874c) {
                            ((LinearLayout.LayoutParams) nulVar4).leftMargin = (-i29) / 2;
                        }
                        z3 = true;
                    } else if (nulVar4.f1975a) {
                        nulVar4.f7873b = i29;
                        nulVar4.f7875d = true;
                        ((LinearLayout.LayoutParams) nulVar4).rightMargin = (-i29) / 2;
                        z3 = true;
                    } else {
                        if (i30 != 0) {
                            ((LinearLayout.LayoutParams) nulVar4).leftMargin = i29 / 2;
                        }
                        if (i30 != childCount - 1) {
                            ((LinearLayout.LayoutParams) nulVar4).rightMargin = i29 / 2;
                        }
                    }
                }
            }
        }
        if (z3) {
            for (int i31 = i5; i31 < childCount; i31++) {
                View childAt4 = getChildAt(i31);
                nul nulVar5 = (nul) childAt4.getLayoutParams();
                if (nulVar5.f7875d) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((nulVar5.f7872a * i10) + nulVar5.f7873b, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i6, mode != 1073741824 ? i4 : i17);
    }

    public androidx.appcompat.view.menu.com1 L() {
        return this.f1971a;
    }

    public void M(com5.aux auxVar, androidx.appcompat.view.menu.com1.aux auxVar2) {
        this.f1972a = auxVar;
        this.f1970a = auxVar2;
    }

    public boolean N() {
        androidx.appcompat.widget.aux auxVar = this.f1974a;
        return auxVar != null && auxVar.K();
    }

    @Override // androidx.appcompat.view.menu.com1.con
    public boolean a(com3 com3Var) {
        return this.f1971a.L(com3Var, 0);
    }

    @Override // androidx.appcompat.view.menu.com6
    public void c(androidx.appcompat.view.menu.com1 com1Var) {
        this.f1971a = com1Var;
    }

    @Override // androidx.appcompat.widget.con, android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof nul;
    }

    @Override // android.view.View
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    public Menu getMenu() {
        if (this.f1971a == null) {
            Context context = getContext();
            androidx.appcompat.view.menu.com1 com1Var = new androidx.appcompat.view.menu.com1(context);
            this.f1971a = com1Var;
            com1Var.R(new prn());
            androidx.appcompat.widget.aux auxVar = new androidx.appcompat.widget.aux(context);
            this.f1974a = auxVar;
            auxVar.J(true);
            androidx.appcompat.widget.aux auxVar2 = this.f1974a;
            com5.aux conVar = this.f1972a;
            if (conVar == null) {
                conVar = new con();
            }
            auxVar2.g(conVar);
            this.f1971a.c(this.f1974a, this.f7865a);
            this.f1974a.H(this);
        }
        return this.f1971a;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        return this.f1974a.A();
    }

    public int getPopupTheme() {
        return this.f7868j;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        androidx.appcompat.widget.aux auxVar = this.f1974a;
        if (auxVar != null) {
            auxVar.e(false);
            if (this.f1974a.E()) {
                this.f1974a.B();
                this.f1974a.K();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        z();
    }

    @Override // androidx.appcompat.widget.con, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int width;
        int paddingLeft;
        if (!this.f7867e) {
            super.onLayout(z2, i2, i3, i4, i5);
            return;
        }
        int childCount = getChildCount();
        int i6 = (i5 - i3) / 2;
        int dividerWidth = getDividerWidth();
        int i7 = i4 - i2;
        int paddingRight = (i7 - getPaddingRight()) - getPaddingLeft();
        boolean zB = u0.b(this);
        int i8 = 0;
        int i9 = 0;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                nul nulVar = (nul) childAt.getLayoutParams();
                if (nulVar.f1975a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (E(i10)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (zB) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) nulVar).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) nulVar).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i11 = i6 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i11, width, measuredHeight + i11);
                    paddingRight -= measuredWidth;
                    i8 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) nulVar).leftMargin) + ((LinearLayout.LayoutParams) nulVar).rightMargin;
                    E(i10);
                    i9++;
                }
            }
        }
        if (childCount == 1 && i8 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i12 = (i7 / 2) - (measuredWidth2 / 2);
            int i13 = i6 - (measuredHeight2 / 2);
            childAt2.layout(i12, i13, measuredWidth2 + i12, measuredHeight2 + i13);
            return;
        }
        int i14 = i9 - (i8 ^ 1);
        int iMax = Math.max(0, i14 > 0 ? paddingRight / i14 : 0);
        if (zB) {
            int width2 = getWidth() - getPaddingRight();
            for (int i15 = 0; i15 < childCount; i15++) {
                View childAt3 = getChildAt(i15);
                nul nulVar2 = (nul) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !nulVar2.f1975a) {
                    int i16 = width2 - ((LinearLayout.LayoutParams) nulVar2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i17 = i6 - (measuredHeight3 / 2);
                    childAt3.layout(i16 - measuredWidth3, i17, i16, measuredHeight3 + i17);
                    width2 = i16 - ((measuredWidth3 + ((LinearLayout.LayoutParams) nulVar2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i18 = 0; i18 < childCount; i18++) {
            View childAt4 = getChildAt(i18);
            nul nulVar3 = (nul) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !nulVar3.f1975a) {
                int i19 = paddingLeft2 + ((LinearLayout.LayoutParams) nulVar3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i20 = i6 - (measuredHeight4 / 2);
                childAt4.layout(i19, i20, i19 + measuredWidth4, measuredHeight4 + i20);
                paddingLeft2 = i19 + measuredWidth4 + ((LinearLayout.LayoutParams) nulVar3).rightMargin + iMax;
            }
        }
    }

    @Override // androidx.appcompat.widget.con, android.view.View
    public void onMeasure(int i2, int i3) {
        androidx.appcompat.view.menu.com1 com1Var;
        boolean z2 = this.f7867e;
        boolean z3 = View.MeasureSpec.getMode(i2) == 1073741824;
        this.f7867e = z3;
        if (z2 != z3) {
            this.f7869k = 0;
        }
        int size = View.MeasureSpec.getSize(i2);
        if (this.f7867e && (com1Var = this.f1971a) != null && size != this.f7869k) {
            this.f7869k = size;
            com1Var.K(true);
        }
        int childCount = getChildCount();
        if (this.f7867e && childCount > 0) {
            K(i2, i3);
            return;
        }
        for (int i4 = 0; i4 < childCount; i4++) {
            nul nulVar = (nul) getChildAt(i4).getLayoutParams();
            ((LinearLayout.LayoutParams) nulVar).rightMargin = 0;
            ((LinearLayout.LayoutParams) nulVar).leftMargin = 0;
        }
        super.onMeasure(i2, i3);
    }

    public void setExpandedActionViewsExclusive(boolean z2) {
        this.f1974a.G(z2);
    }

    public void setOnMenuItemClickListener(com1 com1Var) {
        this.f1973a = com1Var;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        this.f1974a.I(drawable);
    }

    public void setOverflowReserved(boolean z2) {
        this.f7866d = z2;
    }

    public void setPopupTheme(int i2) {
        if (this.f7868j != i2) {
            this.f7868j = i2;
            if (i2 == 0) {
                this.f7865a = getContext();
            } else {
                this.f7865a = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setPresenter(androidx.appcompat.widget.aux auxVar) {
        this.f1974a = auxVar;
        auxVar.H(this);
    }

    public void z() {
        androidx.appcompat.widget.aux auxVar = this.f1974a;
        if (auxVar != null) {
            auxVar.y();
        }
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f2 = context.getResources().getDisplayMetrics().density;
        this.f7870l = (int) (56.0f * f2);
        this.f7871m = (int) (f2 * 4.0f);
        this.f7865a = context;
        this.f7868j = 0;
    }
}
