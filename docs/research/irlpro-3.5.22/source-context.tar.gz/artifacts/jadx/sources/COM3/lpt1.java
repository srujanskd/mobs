package COM3;

import androidx.lifecycle.LiveData;

/* JADX INFO: loaded from: classes.dex */
public class lpt1<T> extends LiveData<T> {
    @Override // androidx.lifecycle.LiveData
    public void i(T t2) {
        super.i(t2);
    }
}
