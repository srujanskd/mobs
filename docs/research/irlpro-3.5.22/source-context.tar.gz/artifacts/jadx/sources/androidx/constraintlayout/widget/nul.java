package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.newrelic.agent.android.distributedtracing.DistributedTracing;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import p065Prn.com6;
import p065Prn.lpt6;
import p113lPT4.lpt4;
import p148nuL.g0;
import p151pRn.h0;

/* JADX INFO: loaded from: classes.dex */
public class nul {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f2215a = {0, 4, 8};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static SparseIntArray f8083a = new SparseIntArray();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static SparseIntArray f8084b = new SparseIntArray();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2217a = "";

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2216a = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public HashMap<String, androidx.constraintlayout.widget.aux> f2218a = new HashMap<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2219a = true;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public HashMap<Integer, aux> f2220b = new HashMap<>();

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8085a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public C0029aux f2221a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f2226a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final prn f2225a = new prn();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final C0030nul f2224a = new C0030nul();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final con f2223a = new con();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com1 f2222a = new com1();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public HashMap<String, androidx.constraintlayout.widget.aux> f2227a = new HashMap<>();

        /* JADX INFO: renamed from: androidx.constraintlayout.widget.nul$aux$aux, reason: collision with other inner class name */
        public static class C0029aux {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public int[] f2229a = new int[10];

            /* JADX INFO: renamed from: b, reason: collision with other field name */
            public int[] f2232b = new int[10];

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public int f8086a = 0;

            /* JADX INFO: renamed from: c, reason: collision with other field name */
            public int[] f2233c = new int[10];

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public float[] f2228a = new float[10];

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public int f8087b = 0;

            /* JADX INFO: renamed from: d, reason: collision with other field name */
            public int[] f2234d = new int[5];

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public String[] f2230a = new String[5];

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            public int f8088c = 0;

            /* JADX INFO: renamed from: e, reason: collision with root package name */
            public int[] f8090e = new int[4];

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public boolean[] f2231a = new boolean[4];

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            public int f8089d = 0;

            public void a(int i2, float f2) {
                int i3 = this.f8087b;
                int[] iArr = this.f2233c;
                if (i3 >= iArr.length) {
                    this.f2233c = Arrays.copyOf(iArr, iArr.length * 2);
                    float[] fArr = this.f2228a;
                    this.f2228a = Arrays.copyOf(fArr, fArr.length * 2);
                }
                int[] iArr2 = this.f2233c;
                int i4 = this.f8087b;
                iArr2[i4] = i2;
                float[] fArr2 = this.f2228a;
                this.f8087b = i4 + 1;
                fArr2[i4] = f2;
            }

            public void b(int i2, int i3) {
                int i4 = this.f8086a;
                int[] iArr = this.f2229a;
                if (i4 >= iArr.length) {
                    this.f2229a = Arrays.copyOf(iArr, iArr.length * 2);
                    int[] iArr2 = this.f2232b;
                    this.f2232b = Arrays.copyOf(iArr2, iArr2.length * 2);
                }
                int[] iArr3 = this.f2229a;
                int i5 = this.f8086a;
                iArr3[i5] = i2;
                int[] iArr4 = this.f2232b;
                this.f8086a = i5 + 1;
                iArr4[i5] = i3;
            }

            public void c(int i2, String str) {
                int i3 = this.f8088c;
                int[] iArr = this.f2234d;
                if (i3 >= iArr.length) {
                    this.f2234d = Arrays.copyOf(iArr, iArr.length * 2);
                    String[] strArr = this.f2230a;
                    this.f2230a = (String[]) Arrays.copyOf(strArr, strArr.length * 2);
                }
                int[] iArr2 = this.f2234d;
                int i4 = this.f8088c;
                iArr2[i4] = i2;
                String[] strArr2 = this.f2230a;
                this.f8088c = i4 + 1;
                strArr2[i4] = str;
            }

            public void d(int i2, boolean z2) {
                int i3 = this.f8089d;
                int[] iArr = this.f8090e;
                if (i3 >= iArr.length) {
                    this.f8090e = Arrays.copyOf(iArr, iArr.length * 2);
                    boolean[] zArr = this.f2231a;
                    this.f2231a = Arrays.copyOf(zArr, zArr.length * 2);
                }
                int[] iArr2 = this.f8090e;
                int i4 = this.f8089d;
                iArr2[i4] = i2;
                boolean[] zArr2 = this.f2231a;
                this.f8089d = i4 + 1;
                zArr2[i4] = z2;
            }
        }

        public void d(ConstraintLayout.con conVar) {
            con conVar2 = this.f2223a;
            conVar.f2178c = conVar2.f2252e;
            conVar.f2180d = conVar2.f2254f;
            conVar.f2182e = conVar2.f2256g;
            conVar.f2184f = conVar2.f2258h;
            conVar.f2186g = conVar2.f8110i;
            conVar.f2188h = conVar2.f8111j;
            conVar.f2190i = conVar2.f8112k;
            conVar.f2192j = conVar2.f8113l;
            conVar.f2194k = conVar2.f8114m;
            conVar.f8045l = conVar2.f8115n;
            conVar.f8046m = conVar2.f8116o;
            conVar.f8049p = conVar2.f8117p;
            conVar.f8050q = conVar2.f8118q;
            conVar.f8051r = conVar2.f8119r;
            conVar.f8052s = conVar2.f8120s;
            ((ViewGroup.MarginLayoutParams) conVar).leftMargin = conVar2.f8126y;
            ((ViewGroup.MarginLayoutParams) conVar).rightMargin = conVar2.f8127z;
            ((ViewGroup.MarginLayoutParams) conVar).topMargin = conVar2.A;
            ((ViewGroup.MarginLayoutParams) conVar).bottomMargin = conVar2.B;
            conVar.f8057x = conVar2.K;
            conVar.f8058y = conVar2.J;
            conVar.f8054u = conVar2.G;
            conVar.f8056w = conVar2.I;
            conVar.f8036c = conVar2.f8103b;
            conVar.f8037d = conVar2.f8104c;
            conVar.f8047n = conVar2.f8121t;
            conVar.f8048o = conVar2.f8122u;
            conVar.f8035b = conVar2.f8105d;
            conVar.f2172a = conVar2.f2241a;
            conVar.K = conVar2.f8123v;
            conVar.L = conVar2.f8124w;
            conVar.f8040g = conVar2.f8106e;
            conVar.f8039f = conVar2.f8107f;
            conVar.D = conVar2.N;
            conVar.C = conVar2.M;
            conVar.f2181d = conVar2.f2253e;
            conVar.f2183e = conVar2.f2255f;
            conVar.E = conVar2.O;
            conVar.F = conVar2.P;
            conVar.I = conVar2.Q;
            conVar.J = conVar2.R;
            conVar.G = conVar2.S;
            conVar.H = conVar2.T;
            conVar.f8041h = conVar2.f8108g;
            conVar.f8042i = conVar2.f8109h;
            conVar.M = conVar2.f8125x;
            conVar.f8034a = conVar2.f2239a;
            conVar.f2171a = conVar2.f2247c;
            conVar.f2175b = conVar2.f2250d;
            ((ViewGroup.MarginLayoutParams) conVar).width = conVar2.f2240a;
            ((ViewGroup.MarginLayoutParams) conVar).height = conVar2.f2244b;
            String str = conVar2.f2248c;
            if (str != null) {
                conVar.f2176b = str;
            }
            conVar.N = conVar2.X;
            conVar.setMarginStart(conVar2.D);
            conVar.setMarginEnd(this.f2223a.C);
            conVar.a();
        }

        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public aux clone() {
            aux auxVar = new aux();
            auxVar.f2223a.a(this.f2223a);
            auxVar.f2224a.a(this.f2224a);
            auxVar.f2225a.a(this.f2225a);
            auxVar.f2222a.a(this.f2222a);
            auxVar.f8085a = this.f8085a;
            auxVar.f2221a = this.f2221a;
            return auxVar;
        }

        public final void f(int i2, ConstraintLayout.con conVar) {
            this.f8085a = i2;
            con conVar2 = this.f2223a;
            conVar2.f2252e = conVar.f2178c;
            conVar2.f2254f = conVar.f2180d;
            conVar2.f2256g = conVar.f2182e;
            conVar2.f2258h = conVar.f2184f;
            conVar2.f8110i = conVar.f2186g;
            conVar2.f8111j = conVar.f2188h;
            conVar2.f8112k = conVar.f2190i;
            conVar2.f8113l = conVar.f2192j;
            conVar2.f8114m = conVar.f2194k;
            conVar2.f8115n = conVar.f8045l;
            conVar2.f8116o = conVar.f8046m;
            conVar2.f8117p = conVar.f8049p;
            conVar2.f8118q = conVar.f8050q;
            conVar2.f8119r = conVar.f8051r;
            conVar2.f8120s = conVar.f8052s;
            conVar2.f8103b = conVar.f8036c;
            conVar2.f8104c = conVar.f8037d;
            conVar2.f2241a = conVar.f2172a;
            conVar2.f8121t = conVar.f8047n;
            conVar2.f8122u = conVar.f8048o;
            conVar2.f8105d = conVar.f8035b;
            conVar2.f8123v = conVar.K;
            conVar2.f8124w = conVar.L;
            conVar2.f8125x = conVar.M;
            conVar2.f2239a = conVar.f8034a;
            conVar2.f2247c = conVar.f2171a;
            conVar2.f2250d = conVar.f2175b;
            conVar2.f2240a = ((ViewGroup.MarginLayoutParams) conVar).width;
            conVar2.f2244b = ((ViewGroup.MarginLayoutParams) conVar).height;
            conVar2.f8126y = ((ViewGroup.MarginLayoutParams) conVar).leftMargin;
            conVar2.f8127z = ((ViewGroup.MarginLayoutParams) conVar).rightMargin;
            conVar2.A = ((ViewGroup.MarginLayoutParams) conVar).topMargin;
            conVar2.B = ((ViewGroup.MarginLayoutParams) conVar).bottomMargin;
            conVar2.E = conVar.A;
            conVar2.f8106e = conVar.f8040g;
            conVar2.f8107f = conVar.f8039f;
            conVar2.N = conVar.D;
            conVar2.M = conVar.C;
            conVar2.f2253e = conVar.f2181d;
            conVar2.f2255f = conVar.f2183e;
            conVar2.O = conVar.E;
            conVar2.P = conVar.F;
            conVar2.Q = conVar.I;
            conVar2.R = conVar.J;
            conVar2.S = conVar.G;
            conVar2.T = conVar.H;
            conVar2.f8108g = conVar.f8041h;
            conVar2.f8109h = conVar.f8042i;
            conVar2.f2248c = conVar.f2176b;
            conVar2.G = conVar.f8054u;
            conVar2.I = conVar.f8056w;
            conVar2.F = conVar.f8053t;
            conVar2.H = conVar.f8055v;
            conVar2.K = conVar.f8057x;
            conVar2.J = conVar.f8058y;
            conVar2.L = conVar.f8059z;
            conVar2.X = conVar.N;
            conVar2.C = conVar.getMarginEnd();
            this.f2223a.D = conVar.getMarginStart();
        }

        public final void g(int i2, androidx.constraintlayout.widget.prn.aux auxVar) {
            f(i2, auxVar);
            this.f2225a.f8136a = auxVar.f8139l;
            com1 com1Var = this.f2222a;
            com1Var.f2235a = auxVar.f8141n;
            com1Var.f8092b = auxVar.f8142o;
            com1Var.f8093c = auxVar.f8143p;
            com1Var.f8094d = auxVar.f8144q;
            com1Var.f8095e = auxVar.f8145r;
            com1Var.f8096f = auxVar.f8146s;
            com1Var.f8097g = auxVar.f8147t;
            com1Var.f8098h = auxVar.f8148u;
            com1Var.f8099i = auxVar.f8149v;
            com1Var.f8100j = auxVar.f8150w;
            com1Var.f8101k = auxVar.f8140m;
            com1Var.f2238b = auxVar.f2269n;
        }

        public final void h(androidx.constraintlayout.widget.con conVar, int i2, androidx.constraintlayout.widget.prn.aux auxVar) {
            g(i2, auxVar);
            if (conVar instanceof Barrier) {
                con conVar2 = this.f2223a;
                conVar2.W = 1;
                Barrier barrier = (Barrier) conVar;
                conVar2.U = barrier.getType();
                this.f2223a.f2243a = barrier.getReferencedIds();
                this.f2223a.V = barrier.getMargin();
            }
        }
    }

    public static class com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static SparseIntArray f8091a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2237a = false;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public float f2235a = 0.0f;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f8092b = 0.0f;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f8093c = 0.0f;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f8094d = 1.0f;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f8095e = 1.0f;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f8096f = Float.NaN;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f8097g = Float.NaN;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2236a = -1;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public float f8098h = 0.0f;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public float f8099i = 0.0f;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public float f8100j = 0.0f;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2238b = false;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public float f8101k = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f8091a = sparseIntArray;
            sparseIntArray.append(h0.R5, 1);
            f8091a.append(h0.S5, 2);
            f8091a.append(h0.T5, 3);
            f8091a.append(h0.P5, 4);
            f8091a.append(h0.Q5, 5);
            f8091a.append(h0.L5, 6);
            f8091a.append(h0.M5, 7);
            f8091a.append(h0.N5, 8);
            f8091a.append(h0.O5, 9);
            f8091a.append(h0.U5, 10);
            f8091a.append(h0.V5, 11);
            f8091a.append(h0.W5, 12);
        }

        public void a(com1 com1Var) {
            this.f2237a = com1Var.f2237a;
            this.f2235a = com1Var.f2235a;
            this.f8092b = com1Var.f8092b;
            this.f8093c = com1Var.f8093c;
            this.f8094d = com1Var.f8094d;
            this.f8095e = com1Var.f8095e;
            this.f8096f = com1Var.f8096f;
            this.f8097g = com1Var.f8097g;
            this.f2236a = com1Var.f2236a;
            this.f8098h = com1Var.f8098h;
            this.f8099i = com1Var.f8099i;
            this.f8100j = com1Var.f8100j;
            this.f2238b = com1Var.f2238b;
            this.f8101k = com1Var.f8101k;
        }

        public void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h0.f5223t0);
            this.f2237a = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                switch (f8091a.get(index)) {
                    case 1:
                        this.f2235a = typedArrayObtainStyledAttributes.getFloat(index, this.f2235a);
                        break;
                    case 2:
                        this.f8092b = typedArrayObtainStyledAttributes.getFloat(index, this.f8092b);
                        break;
                    case 3:
                        this.f8093c = typedArrayObtainStyledAttributes.getFloat(index, this.f8093c);
                        break;
                    case 4:
                        this.f8094d = typedArrayObtainStyledAttributes.getFloat(index, this.f8094d);
                        break;
                    case 5:
                        this.f8095e = typedArrayObtainStyledAttributes.getFloat(index, this.f8095e);
                        break;
                    case 6:
                        this.f8096f = typedArrayObtainStyledAttributes.getDimension(index, this.f8096f);
                        break;
                    case 7:
                        this.f8097g = typedArrayObtainStyledAttributes.getDimension(index, this.f8097g);
                        break;
                    case 8:
                        this.f8098h = typedArrayObtainStyledAttributes.getDimension(index, this.f8098h);
                        break;
                    case 9:
                        this.f8099i = typedArrayObtainStyledAttributes.getDimension(index, this.f8099i);
                        break;
                    case 10:
                        this.f8100j = typedArrayObtainStyledAttributes.getDimension(index, this.f8100j);
                        break;
                    case 11:
                        this.f2238b = true;
                        this.f8101k = typedArrayObtainStyledAttributes.getDimension(index, this.f8101k);
                        break;
                    case 12:
                        this.f2236a = nul.p(typedArrayObtainStyledAttributes, index, this.f2236a);
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public static class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static SparseIntArray f8102a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2240a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int[] f2243a;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public int f2244b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public String f2245b;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public String f2248c;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2242a = false;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2246b = false;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2249c = false;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public int f2247c = -1;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public int f2250d = -1;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public float f2239a = -1.0f;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f2251d = true;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public int f2252e = -1;

        /* JADX INFO: renamed from: f, reason: collision with other field name */
        public int f2254f = -1;

        /* JADX INFO: renamed from: g, reason: collision with other field name */
        public int f2256g = -1;

        /* JADX INFO: renamed from: h, reason: collision with other field name */
        public int f2258h = -1;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public int f8110i = -1;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public int f8111j = -1;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public int f8112k = -1;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public int f8113l = -1;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public int f8114m = -1;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public int f8115n = -1;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public int f8116o = -1;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public int f8117p = -1;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public int f8118q = -1;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public int f8119r = -1;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public int f8120s = -1;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f8103b = 0.5f;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f8104c = 0.5f;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f2241a = null;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public int f8121t = -1;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public int f8122u = 0;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f8105d = 0.0f;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public int f8123v = -1;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public int f8124w = -1;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public int f8125x = -1;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        public int f8126y = 0;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        public int f8127z = 0;
        public int A = 0;
        public int B = 0;
        public int C = 0;
        public int D = 0;
        public int E = 0;
        public int F = Integer.MIN_VALUE;
        public int G = Integer.MIN_VALUE;
        public int H = Integer.MIN_VALUE;
        public int I = Integer.MIN_VALUE;
        public int J = Integer.MIN_VALUE;
        public int K = Integer.MIN_VALUE;
        public int L = Integer.MIN_VALUE;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f8106e = -1.0f;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f8107f = -1.0f;
        public int M = 0;
        public int N = 0;
        public int O = 0;
        public int P = 0;
        public int Q = 0;
        public int R = 0;
        public int S = 0;
        public int T = 0;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f8108g = 1.0f;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public float f8109h = 1.0f;
        public int U = -1;
        public int V = 0;
        public int W = -1;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public boolean f2253e = false;

        /* JADX INFO: renamed from: f, reason: collision with other field name */
        public boolean f2255f = false;

        /* JADX INFO: renamed from: g, reason: collision with other field name */
        public boolean f2257g = true;
        public int X = 0;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f8102a = sparseIntArray;
            sparseIntArray.append(h0.V4, 24);
            f8102a.append(h0.W4, 25);
            f8102a.append(h0.Y4, 28);
            f8102a.append(h0.Z4, 29);
            f8102a.append(h0.e5, 35);
            f8102a.append(h0.d5, 34);
            f8102a.append(h0.F4, 4);
            f8102a.append(h0.E4, 3);
            f8102a.append(h0.C4, 1);
            f8102a.append(h0.k5, 6);
            f8102a.append(h0.l5, 7);
            f8102a.append(h0.M4, 17);
            f8102a.append(h0.N4, 18);
            f8102a.append(h0.O4, 19);
            f8102a.append(h0.y4, 90);
            f8102a.append(h0.k4, 26);
            f8102a.append(h0.a5, 31);
            f8102a.append(h0.b5, 32);
            f8102a.append(h0.L4, 10);
            f8102a.append(h0.K4, 9);
            f8102a.append(h0.o5, 13);
            f8102a.append(h0.r5, 16);
            f8102a.append(h0.p5, 14);
            f8102a.append(h0.m5, 11);
            f8102a.append(h0.q5, 15);
            f8102a.append(h0.n5, 12);
            f8102a.append(h0.h5, 38);
            f8102a.append(h0.T4, 37);
            f8102a.append(h0.S4, 39);
            f8102a.append(h0.g5, 40);
            f8102a.append(h0.R4, 20);
            f8102a.append(h0.f5, 36);
            f8102a.append(h0.J4, 5);
            f8102a.append(h0.U4, 91);
            f8102a.append(h0.c5, 91);
            f8102a.append(h0.X4, 91);
            f8102a.append(h0.D4, 91);
            f8102a.append(h0.B4, 91);
            f8102a.append(h0.n4, 23);
            f8102a.append(h0.p4, 27);
            f8102a.append(h0.r4, 30);
            f8102a.append(h0.s4, 8);
            f8102a.append(h0.o4, 33);
            f8102a.append(h0.q4, 2);
            f8102a.append(h0.l4, 22);
            f8102a.append(h0.m4, 21);
            f8102a.append(h0.i5, 41);
            f8102a.append(h0.P4, 42);
            f8102a.append(h0.A4, 41);
            f8102a.append(h0.z4, 42);
            f8102a.append(h0.s5, 76);
            f8102a.append(h0.G4, 61);
            f8102a.append(h0.I4, 62);
            f8102a.append(h0.H4, 63);
            f8102a.append(h0.j5, 69);
            f8102a.append(h0.Q4, 70);
            f8102a.append(h0.w4, 71);
            f8102a.append(h0.u4, 72);
            f8102a.append(h0.v4, 73);
            f8102a.append(h0.x4, 74);
            f8102a.append(h0.t4, 75);
        }

        public void a(con conVar) {
            this.f2242a = conVar.f2242a;
            this.f2240a = conVar.f2240a;
            this.f2246b = conVar.f2246b;
            this.f2244b = conVar.f2244b;
            this.f2247c = conVar.f2247c;
            this.f2250d = conVar.f2250d;
            this.f2239a = conVar.f2239a;
            this.f2251d = conVar.f2251d;
            this.f2252e = conVar.f2252e;
            this.f2254f = conVar.f2254f;
            this.f2256g = conVar.f2256g;
            this.f2258h = conVar.f2258h;
            this.f8110i = conVar.f8110i;
            this.f8111j = conVar.f8111j;
            this.f8112k = conVar.f8112k;
            this.f8113l = conVar.f8113l;
            this.f8114m = conVar.f8114m;
            this.f8115n = conVar.f8115n;
            this.f8116o = conVar.f8116o;
            this.f8117p = conVar.f8117p;
            this.f8118q = conVar.f8118q;
            this.f8119r = conVar.f8119r;
            this.f8120s = conVar.f8120s;
            this.f8103b = conVar.f8103b;
            this.f8104c = conVar.f8104c;
            this.f2241a = conVar.f2241a;
            this.f8121t = conVar.f8121t;
            this.f8122u = conVar.f8122u;
            this.f8105d = conVar.f8105d;
            this.f8123v = conVar.f8123v;
            this.f8124w = conVar.f8124w;
            this.f8125x = conVar.f8125x;
            this.f8126y = conVar.f8126y;
            this.f8127z = conVar.f8127z;
            this.A = conVar.A;
            this.B = conVar.B;
            this.C = conVar.C;
            this.D = conVar.D;
            this.E = conVar.E;
            this.F = conVar.F;
            this.G = conVar.G;
            this.H = conVar.H;
            this.I = conVar.I;
            this.J = conVar.J;
            this.K = conVar.K;
            this.L = conVar.L;
            this.f8106e = conVar.f8106e;
            this.f8107f = conVar.f8107f;
            this.M = conVar.M;
            this.N = conVar.N;
            this.O = conVar.O;
            this.P = conVar.P;
            this.Q = conVar.Q;
            this.R = conVar.R;
            this.S = conVar.S;
            this.T = conVar.T;
            this.f8108g = conVar.f8108g;
            this.f8109h = conVar.f8109h;
            this.U = conVar.U;
            this.V = conVar.V;
            this.W = conVar.W;
            this.f2248c = conVar.f2248c;
            int[] iArr = conVar.f2243a;
            if (iArr == null || conVar.f2245b != null) {
                this.f2243a = null;
            } else {
                this.f2243a = Arrays.copyOf(iArr, iArr.length);
            }
            this.f2245b = conVar.f2245b;
            this.f2253e = conVar.f2253e;
            this.f2255f = conVar.f2255f;
            this.f2257g = conVar.f2257g;
            this.X = conVar.X;
        }

        public void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h0.f5172O);
            this.f2246b = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                int i3 = f8102a.get(index);
                switch (i3) {
                    case 1:
                        this.f8114m = nul.p(typedArrayObtainStyledAttributes, index, this.f8114m);
                        break;
                    case 2:
                        this.B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.B);
                        break;
                    case 3:
                        this.f8113l = nul.p(typedArrayObtainStyledAttributes, index, this.f8113l);
                        break;
                    case 4:
                        this.f8112k = nul.p(typedArrayObtainStyledAttributes, index, this.f8112k);
                        break;
                    case 5:
                        this.f2241a = typedArrayObtainStyledAttributes.getString(index);
                        break;
                    case 6:
                        this.f8123v = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f8123v);
                        break;
                    case 7:
                        this.f8124w = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f8124w);
                        break;
                    case 8:
                        this.C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.C);
                        break;
                    case 9:
                        this.f8120s = nul.p(typedArrayObtainStyledAttributes, index, this.f8120s);
                        break;
                    case 10:
                        this.f8119r = nul.p(typedArrayObtainStyledAttributes, index, this.f8119r);
                        break;
                    case 11:
                        this.I = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.I);
                        break;
                    case 12:
                        this.J = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.J);
                        break;
                    case 13:
                        this.F = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.F);
                        break;
                    case 14:
                        this.H = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.H);
                        break;
                    case 15:
                        this.K = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.K);
                        break;
                    case 16:
                        this.G = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.G);
                        break;
                    case 17:
                        this.f2247c = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2247c);
                        break;
                    case 18:
                        this.f2250d = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2250d);
                        break;
                    case 19:
                        this.f2239a = typedArrayObtainStyledAttributes.getFloat(index, this.f2239a);
                        break;
                    case 20:
                        this.f8103b = typedArrayObtainStyledAttributes.getFloat(index, this.f8103b);
                        break;
                    case 21:
                        this.f2244b = typedArrayObtainStyledAttributes.getLayoutDimension(index, this.f2244b);
                        break;
                    case 22:
                        this.f2240a = typedArrayObtainStyledAttributes.getLayoutDimension(index, this.f2240a);
                        break;
                    case 23:
                        this.f8126y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8126y);
                        break;
                    case 24:
                        this.f2252e = nul.p(typedArrayObtainStyledAttributes, index, this.f2252e);
                        break;
                    case 25:
                        this.f2254f = nul.p(typedArrayObtainStyledAttributes, index, this.f2254f);
                        break;
                    case 26:
                        this.f8125x = typedArrayObtainStyledAttributes.getInt(index, this.f8125x);
                        break;
                    case 27:
                        this.f8127z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8127z);
                        break;
                    case 28:
                        this.f2256g = nul.p(typedArrayObtainStyledAttributes, index, this.f2256g);
                        break;
                    case 29:
                        this.f2258h = nul.p(typedArrayObtainStyledAttributes, index, this.f2258h);
                        break;
                    case 30:
                        this.D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.D);
                        break;
                    case 31:
                        this.f8117p = nul.p(typedArrayObtainStyledAttributes, index, this.f8117p);
                        break;
                    case 32:
                        this.f8118q = nul.p(typedArrayObtainStyledAttributes, index, this.f8118q);
                        break;
                    case 33:
                        this.A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.A);
                        break;
                    case 34:
                        this.f8111j = nul.p(typedArrayObtainStyledAttributes, index, this.f8111j);
                        break;
                    case 35:
                        this.f8110i = nul.p(typedArrayObtainStyledAttributes, index, this.f8110i);
                        break;
                    case 36:
                        this.f8104c = typedArrayObtainStyledAttributes.getFloat(index, this.f8104c);
                        break;
                    case lpt4.AppCompatTheme_alertDialogStyle /* 37 */:
                        this.f8107f = typedArrayObtainStyledAttributes.getFloat(index, this.f8107f);
                        break;
                    case lpt4.AppCompatTheme_alertDialogTheme /* 38 */:
                        this.f8106e = typedArrayObtainStyledAttributes.getFloat(index, this.f8106e);
                        break;
                    case lpt4.AppCompatTheme_autoCompleteTextViewStyle /* 39 */:
                        this.M = typedArrayObtainStyledAttributes.getInt(index, this.M);
                        break;
                    case lpt4.AppCompatTheme_borderlessButtonStyle /* 40 */:
                        this.N = typedArrayObtainStyledAttributes.getInt(index, this.N);
                        break;
                    case lpt4.AppCompatTheme_buttonBarButtonStyle /* 41 */:
                        nul.q(this, typedArrayObtainStyledAttributes, index, 0);
                        break;
                    case lpt4.AppCompatTheme_buttonBarNegativeButtonStyle /* 42 */:
                        nul.q(this, typedArrayObtainStyledAttributes, index, 1);
                        break;
                    default:
                        switch (i3) {
                            case lpt4.AppCompatTheme_dialogCornerRadius /* 61 */:
                                this.f8121t = nul.p(typedArrayObtainStyledAttributes, index, this.f8121t);
                                break;
                            case lpt4.AppCompatTheme_dialogPreferredPadding /* 62 */:
                                this.f8122u = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8122u);
                                break;
                            case lpt4.AppCompatTheme_dialogTheme /* 63 */:
                                this.f8105d = typedArrayObtainStyledAttributes.getFloat(index, this.f8105d);
                                break;
                            default:
                                switch (i3) {
                                    case lpt4.AppCompatTheme_editTextColor /* 69 */:
                                        this.f8108g = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                                        break;
                                    case lpt4.AppCompatTheme_editTextStyle /* 70 */:
                                        this.f8109h = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                                        break;
                                    case lpt4.AppCompatTheme_homeAsUpIndicator /* 71 */:
                                        Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                        break;
                                    case lpt4.AppCompatTheme_imageButtonStyle /* 72 */:
                                        this.U = typedArrayObtainStyledAttributes.getInt(index, this.U);
                                        break;
                                    case lpt4.AppCompatTheme_listChoiceBackgroundIndicator /* 73 */:
                                        this.V = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.V);
                                        break;
                                    case lpt4.AppCompatTheme_listChoiceIndicatorMultipleAnimated /* 74 */:
                                        this.f2245b = typedArrayObtainStyledAttributes.getString(index);
                                        break;
                                    case lpt4.AppCompatTheme_listChoiceIndicatorSingleAnimated /* 75 */:
                                        this.f2257g = typedArrayObtainStyledAttributes.getBoolean(index, this.f2257g);
                                        break;
                                    case lpt4.AppCompatTheme_listDividerAlertDialog /* 76 */:
                                        this.X = typedArrayObtainStyledAttributes.getInt(index, this.X);
                                        break;
                                    case lpt4.AppCompatTheme_listMenuViewStyle /* 77 */:
                                        this.f8115n = nul.p(typedArrayObtainStyledAttributes, index, this.f8115n);
                                        break;
                                    case lpt4.AppCompatTheme_listPopupWindowStyle /* 78 */:
                                        this.f8116o = nul.p(typedArrayObtainStyledAttributes, index, this.f8116o);
                                        break;
                                    case lpt4.AppCompatTheme_listPreferredItemHeight /* 79 */:
                                        this.L = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.L);
                                        break;
                                    case lpt4.AppCompatTheme_listPreferredItemHeightLarge /* 80 */:
                                        this.E = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.E);
                                        break;
                                    case lpt4.AppCompatTheme_listPreferredItemHeightSmall /* 81 */:
                                        this.O = typedArrayObtainStyledAttributes.getInt(index, this.O);
                                        break;
                                    case lpt4.AppCompatTheme_listPreferredItemPaddingEnd /* 82 */:
                                        this.P = typedArrayObtainStyledAttributes.getInt(index, this.P);
                                        break;
                                    case lpt4.AppCompatTheme_listPreferredItemPaddingLeft /* 83 */:
                                        this.R = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.R);
                                        break;
                                    case lpt4.AppCompatTheme_listPreferredItemPaddingRight /* 84 */:
                                        this.Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.Q);
                                        break;
                                    case 85:
                                        this.T = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.T);
                                        break;
                                    case lpt4.AppCompatTheme_panelBackground /* 86 */:
                                        this.S = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.S);
                                        break;
                                    case lpt4.AppCompatTheme_panelMenuListTheme /* 87 */:
                                        this.f2253e = typedArrayObtainStyledAttributes.getBoolean(index, this.f2253e);
                                        break;
                                    case lpt4.AppCompatTheme_panelMenuListWidth /* 88 */:
                                        this.f2255f = typedArrayObtainStyledAttributes.getBoolean(index, this.f2255f);
                                        break;
                                    case lpt4.AppCompatTheme_popupMenuStyle /* 89 */:
                                        this.f2248c = typedArrayObtainStyledAttributes.getString(index);
                                        break;
                                    case lpt4.AppCompatTheme_popupWindowStyle /* 90 */:
                                        this.f2251d = typedArrayObtainStyledAttributes.getBoolean(index, this.f2251d);
                                        break;
                                    case lpt4.AppCompatTheme_radioButtonStyle /* 91 */:
                                        Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + f8102a.get(index));
                                        break;
                                    default:
                                        Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + f8102a.get(index));
                                        break;
                                }
                                break;
                        }
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: renamed from: androidx.constraintlayout.widget.nul$nul, reason: collision with other inner class name */
    public static class C0030nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static SparseIntArray f8128a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2262a = false;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2260a = -1;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public int f2263b = 0;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f2261a = null;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public int f2265c = -1;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8131d = 0;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public float f2259a = Float.NaN;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8132e = -1;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f8129b = Float.NaN;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f8130c = Float.NaN;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f8133f = -1;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public String f2264b = null;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f8134g = -3;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f8135h = -1;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f8128a = sparseIntArray;
            sparseIntArray.append(h0.w5, 1);
            f8128a.append(h0.y5, 2);
            f8128a.append(h0.C5, 3);
            f8128a.append(h0.v5, 4);
            f8128a.append(h0.u5, 5);
            f8128a.append(h0.t5, 6);
            f8128a.append(h0.x5, 7);
            f8128a.append(h0.B5, 8);
            f8128a.append(h0.A5, 9);
            f8128a.append(h0.z5, 10);
        }

        public void a(C0030nul c0030nul) {
            this.f2262a = c0030nul.f2262a;
            this.f2260a = c0030nul.f2260a;
            this.f2261a = c0030nul.f2261a;
            this.f2265c = c0030nul.f2265c;
            this.f8131d = c0030nul.f8131d;
            this.f8129b = c0030nul.f8129b;
            this.f2259a = c0030nul.f2259a;
            this.f8132e = c0030nul.f8132e;
        }

        public void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h0.f5180W);
            this.f2262a = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                switch (f8128a.get(index)) {
                    case 1:
                        this.f8129b = typedArrayObtainStyledAttributes.getFloat(index, this.f8129b);
                        break;
                    case 2:
                        this.f2265c = typedArrayObtainStyledAttributes.getInt(index, this.f2265c);
                        break;
                    case 3:
                        if (typedArrayObtainStyledAttributes.peekValue(index).type == 3) {
                            this.f2261a = typedArrayObtainStyledAttributes.getString(index);
                        } else {
                            this.f2261a = g0.f5029a[typedArrayObtainStyledAttributes.getInteger(index, 0)];
                        }
                        break;
                    case 4:
                        this.f8131d = typedArrayObtainStyledAttributes.getInt(index, 0);
                        break;
                    case 5:
                        this.f2260a = nul.p(typedArrayObtainStyledAttributes, index, this.f2260a);
                        break;
                    case 6:
                        this.f2263b = typedArrayObtainStyledAttributes.getInteger(index, this.f2263b);
                        break;
                    case 7:
                        this.f2259a = typedArrayObtainStyledAttributes.getFloat(index, this.f2259a);
                        break;
                    case 8:
                        this.f8133f = typedArrayObtainStyledAttributes.getInteger(index, this.f8133f);
                        break;
                    case 9:
                        this.f8130c = typedArrayObtainStyledAttributes.getFloat(index, this.f8130c);
                        break;
                    case 10:
                        int i3 = typedArrayObtainStyledAttributes.peekValue(index).type;
                        if (i3 == 1) {
                            int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                            this.f8135h = resourceId;
                            if (resourceId != -1) {
                                this.f8134g = -2;
                            }
                        } else if (i3 == 3) {
                            String string = typedArrayObtainStyledAttributes.getString(index);
                            this.f2264b = string;
                            if (string.indexOf("/") > 0) {
                                this.f8135h = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                                this.f8134g = -2;
                            } else {
                                this.f8134g = -1;
                            }
                        } else {
                            this.f8134g = typedArrayObtainStyledAttributes.getInteger(index, this.f8135h);
                        }
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public static class prn {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2267a = false;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2266a = 0;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public int f2268b = 0;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f8136a = 1.0f;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f8137b = Float.NaN;

        public void a(prn prnVar) {
            this.f2267a = prnVar.f2267a;
            this.f2266a = prnVar.f2266a;
            this.f8136a = prnVar.f8136a;
            this.f8137b = prnVar.f8137b;
            this.f2268b = prnVar.f2268b;
        }

        public void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h0.f5199h0);
            this.f2267a = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                if (index == h0.G5) {
                    this.f8136a = typedArrayObtainStyledAttributes.getFloat(index, this.f8136a);
                } else if (index == h0.F5) {
                    this.f2266a = typedArrayObtainStyledAttributes.getInt(index, this.f2266a);
                    this.f2266a = nul.f2215a[this.f2266a];
                } else if (index == h0.I5) {
                    this.f2268b = typedArrayObtainStyledAttributes.getInt(index, this.f2268b);
                } else if (index == h0.H5) {
                    this.f8137b = typedArrayObtainStyledAttributes.getFloat(index, this.f8137b);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    static {
        f8083a.append(h0.f11671g0, 25);
        f8083a.append(h0.f11673h0, 26);
        f8083a.append(h0.f11677j0, 29);
        f8083a.append(h0.f11679k0, 30);
        f8083a.append(h0.q0, 36);
        f8083a.append(h0.p0, 35);
        f8083a.append(h0.N, 4);
        f8083a.append(h0.M, 3);
        f8083a.append(h0.I, 1);
        f8083a.append(h0.K, 91);
        f8083a.append(h0.J, 92);
        f8083a.append(h0.z0, 6);
        f8083a.append(h0.A0, 7);
        f8083a.append(h0.U, 17);
        f8083a.append(h0.V, 18);
        f8083a.append(h0.W, 19);
        f8083a.append(h0.E, 99);
        f8083a.append(h0.f11658a, 27);
        f8083a.append(h0.f11681l0, 32);
        f8083a.append(h0.f11683m0, 33);
        f8083a.append(h0.T, 10);
        f8083a.append(h0.S, 9);
        f8083a.append(h0.D0, 13);
        f8083a.append(h0.G0, 16);
        f8083a.append(h0.E0, 14);
        f8083a.append(h0.B0, 11);
        f8083a.append(h0.F0, 15);
        f8083a.append(h0.C0, 12);
        f8083a.append(h0.t0, 40);
        f8083a.append(h0.f11667e0, 39);
        f8083a.append(h0.f11665d0, 41);
        f8083a.append(h0.s0, 42);
        f8083a.append(h0.f11663c0, 20);
        f8083a.append(h0.r0, 37);
        f8083a.append(h0.R, 5);
        f8083a.append(h0.f11669f0, 87);
        f8083a.append(h0.f11687o0, 87);
        f8083a.append(h0.f11675i0, 87);
        f8083a.append(h0.L, 87);
        f8083a.append(h0.H, 87);
        f8083a.append(h0.f11668f, 24);
        f8083a.append(h0.f11672h, 28);
        f8083a.append(h0.f11692t, 31);
        f8083a.append(h0.f11693u, 8);
        f8083a.append(h0.f11670g, 34);
        f8083a.append(h0.f11674i, 2);
        f8083a.append(h0.f11664d, 23);
        f8083a.append(h0.f11666e, 21);
        f8083a.append(h0.u0, 95);
        f8083a.append(h0.X, 96);
        f8083a.append(h0.f11662c, 22);
        f8083a.append(h0.f11676j, 43);
        f8083a.append(h0.f11695w, 44);
        f8083a.append(h0.f11690r, 45);
        f8083a.append(h0.f11691s, 46);
        f8083a.append(h0.f11689q, 60);
        f8083a.append(h0.f11686o, 47);
        f8083a.append(h0.f11688p, 48);
        f8083a.append(h0.f11678k, 49);
        f8083a.append(h0.f11680l, 50);
        f8083a.append(h0.f11682m, 51);
        f8083a.append(h0.f11684n, 52);
        f8083a.append(h0.f11694v, 53);
        f8083a.append(h0.v0, 54);
        f8083a.append(h0.Y, 55);
        f8083a.append(h0.w0, 56);
        f8083a.append(h0.Z, 57);
        f8083a.append(h0.x0, 58);
        f8083a.append(h0.f11659a0, 59);
        f8083a.append(h0.O, 61);
        f8083a.append(h0.Q, 62);
        f8083a.append(h0.P, 63);
        f8083a.append(h0.f11696x, 64);
        f8083a.append(h0.Q0, 65);
        f8083a.append(h0.D, 66);
        f8083a.append(h0.R0, 67);
        f8083a.append(h0.J0, 79);
        f8083a.append(h0.f11660b, 38);
        f8083a.append(h0.I0, 68);
        f8083a.append(h0.y0, 69);
        f8083a.append(h0.f11661b0, 70);
        f8083a.append(h0.H0, 97);
        f8083a.append(h0.B, 71);
        f8083a.append(h0.f11698z, 72);
        f8083a.append(h0.A, 73);
        f8083a.append(h0.C, 74);
        f8083a.append(h0.f11697y, 75);
        f8083a.append(h0.K0, 76);
        f8083a.append(h0.f11685n0, 77);
        f8083a.append(h0.S0, 78);
        f8083a.append(h0.G, 80);
        f8083a.append(h0.F, 81);
        f8083a.append(h0.L0, 82);
        f8083a.append(h0.P0, 83);
        f8083a.append(h0.O0, 84);
        f8083a.append(h0.N0, 85);
        f8083a.append(h0.M0, 86);
        SparseIntArray sparseIntArray = f8084b;
        int i2 = h0.t3;
        sparseIntArray.append(i2, 6);
        f8084b.append(i2, 7);
        f8084b.append(h0.o2, 27);
        f8084b.append(h0.w3, 13);
        f8084b.append(h0.z3, 16);
        f8084b.append(h0.x3, 14);
        f8084b.append(h0.u3, 11);
        f8084b.append(h0.y3, 15);
        f8084b.append(h0.v3, 12);
        f8084b.append(h0.n3, 40);
        f8084b.append(h0.g3, 39);
        f8084b.append(h0.f3, 41);
        f8084b.append(h0.m3, 42);
        f8084b.append(h0.e3, 20);
        f8084b.append(h0.l3, 37);
        f8084b.append(h0.Y2, 5);
        f8084b.append(h0.h3, 87);
        f8084b.append(h0.k3, 87);
        f8084b.append(h0.i3, 87);
        f8084b.append(h0.V2, 87);
        f8084b.append(h0.U2, 87);
        f8084b.append(h0.t2, 24);
        f8084b.append(h0.v2, 28);
        f8084b.append(h0.H2, 31);
        f8084b.append(h0.I2, 8);
        f8084b.append(h0.u2, 34);
        f8084b.append(h0.w2, 2);
        f8084b.append(h0.r2, 23);
        f8084b.append(h0.s2, 21);
        f8084b.append(h0.o3, 95);
        f8084b.append(h0.Z2, 96);
        f8084b.append(h0.q2, 22);
        f8084b.append(h0.x2, 43);
        f8084b.append(h0.K2, 44);
        f8084b.append(h0.F2, 45);
        f8084b.append(h0.G2, 46);
        f8084b.append(h0.E2, 60);
        f8084b.append(h0.C2, 47);
        f8084b.append(h0.D2, 48);
        f8084b.append(h0.y2, 49);
        f8084b.append(h0.z2, 50);
        f8084b.append(h0.A2, 51);
        f8084b.append(h0.B2, 52);
        f8084b.append(h0.J2, 53);
        f8084b.append(h0.p3, 54);
        f8084b.append(h0.a3, 55);
        f8084b.append(h0.q3, 56);
        f8084b.append(h0.b3, 57);
        f8084b.append(h0.r3, 58);
        f8084b.append(h0.c3, 59);
        f8084b.append(h0.X2, 62);
        f8084b.append(h0.W2, 63);
        f8084b.append(h0.L2, 64);
        f8084b.append(h0.K3, 65);
        f8084b.append(h0.R2, 66);
        f8084b.append(h0.L3, 67);
        f8084b.append(h0.C3, 79);
        f8084b.append(h0.p2, 38);
        f8084b.append(h0.D3, 98);
        f8084b.append(h0.B3, 68);
        f8084b.append(h0.s3, 69);
        f8084b.append(h0.d3, 70);
        f8084b.append(h0.P2, 71);
        f8084b.append(h0.N2, 72);
        f8084b.append(h0.O2, 73);
        f8084b.append(h0.Q2, 74);
        f8084b.append(h0.M2, 75);
        f8084b.append(h0.E3, 76);
        f8084b.append(h0.j3, 77);
        f8084b.append(h0.M3, 78);
        f8084b.append(h0.T2, 80);
        f8084b.append(h0.S2, 81);
        f8084b.append(h0.F3, 82);
        f8084b.append(h0.J3, 83);
        f8084b.append(h0.I3, 84);
        f8084b.append(h0.H3, 85);
        f8084b.append(h0.G3, 86);
        f8084b.append(h0.A3, 97);
    }

    public static int p(TypedArray typedArray, int i2, int i3) {
        int resourceId = typedArray.getResourceId(i2, i3);
        return resourceId == -1 ? typedArray.getInt(i2, -1) : resourceId;
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0031  */
    /* JADX WARN: Code duplicated, block: B:23:0x0035  */
    /* JADX WARN: Code duplicated, block: B:24:0x003a  */
    /* JADX WARN: Code duplicated, block: B:25:0x003f  */
    /* JADX WARN: Code duplicated, block: B:27:0x0043  */
    /* JADX WARN: Code duplicated, block: B:29:0x0047  */
    /* JADX WARN: Code duplicated, block: B:30:0x004c  */
    /* JADX WARN: Code duplicated, block: B:31:0x0051  */
    /* JADX WARN: Code duplicated, block: B:33:0x0055  */
    /* JADX WARN: Code duplicated, block: B:35:0x0059  */
    /* JADX WARN: Code duplicated, block: B:36:0x0064  */
    /* JADX WARN: Code duplicated, block: B:44:? A[RETURN, SYNTHETIC] */
    public static void q(Object obj, TypedArray typedArray, int i2, int i3) {
        int dimensionPixelSize;
        boolean z2;
        aux.C0029aux c0029aux;
        con conVar;
        ConstraintLayout.con conVar2;
        if (obj == null) {
            return;
        }
        int i4 = typedArray.peekValue(i2).type;
        if (i4 == 3) {
            r(obj, typedArray.getString(i2), i3);
            return;
        }
        int i5 = 0;
        if (i4 != 5) {
            dimensionPixelSize = typedArray.getInt(i2, 0);
            if (dimensionPixelSize == -4) {
                z2 = true;
                i5 = -2;
            } else if (dimensionPixelSize == -3 || (dimensionPixelSize != -2 && dimensionPixelSize != -1)) {
                z2 = false;
            }
            if (obj instanceof ConstraintLayout.con) {
                conVar2 = (ConstraintLayout.con) obj;
                if (i3 == 0) {
                    ((ViewGroup.MarginLayoutParams) conVar2).width = i5;
                    conVar2.f2181d = z2;
                    return;
                } else {
                    ((ViewGroup.MarginLayoutParams) conVar2).height = i5;
                    conVar2.f2183e = z2;
                    return;
                }
            }
            if (obj instanceof con) {
                conVar = (con) obj;
                if (i3 == 0) {
                    conVar.f2240a = i5;
                    conVar.f2253e = z2;
                    return;
                } else {
                    conVar.f2244b = i5;
                    conVar.f2255f = z2;
                    return;
                }
            }
            if (obj instanceof aux.C0029aux) {
                c0029aux = (aux.C0029aux) obj;
                if (i3 == 0) {
                    c0029aux.b(23, i5);
                    c0029aux.d(80, z2);
                } else {
                    c0029aux.b(21, i5);
                    c0029aux.d(81, z2);
                }
            }
        }
        dimensionPixelSize = typedArray.getDimensionPixelSize(i2, 0);
        i5 = dimensionPixelSize;
        z2 = false;
        if (obj instanceof ConstraintLayout.con) {
            conVar2 = (ConstraintLayout.con) obj;
            if (i3 == 0) {
                ((ViewGroup.MarginLayoutParams) conVar2).width = i5;
                conVar2.f2181d = z2;
                return;
            } else {
                ((ViewGroup.MarginLayoutParams) conVar2).height = i5;
                conVar2.f2183e = z2;
                return;
            }
        }
        if (obj instanceof con) {
            conVar = (con) obj;
            if (i3 == 0) {
                conVar.f2240a = i5;
                conVar.f2253e = z2;
                return;
            } else {
                conVar.f2244b = i5;
                conVar.f2255f = z2;
                return;
            }
        }
        if (obj instanceof aux.C0029aux) {
            c0029aux = (aux.C0029aux) obj;
            if (i3 == 0) {
                c0029aux.b(23, i5);
                c0029aux.d(80, z2);
            } else {
                c0029aux.b(21, i5);
                c0029aux.d(81, z2);
            }
        }
    }

    public static void r(Object obj, String str, int i2) {
        if (str == null) {
            return;
        }
        int iIndexOf = str.indexOf(61);
        int length = str.length();
        if (iIndexOf <= 0 || iIndexOf >= length - 1) {
            return;
        }
        String strSubstring = str.substring(0, iIndexOf);
        String strSubstring2 = str.substring(iIndexOf + 1);
        if (strSubstring2.length() > 0) {
            String strTrim = strSubstring.trim();
            String strTrim2 = strSubstring2.trim();
            if ("ratio".equalsIgnoreCase(strTrim)) {
                if (obj instanceof ConstraintLayout.con) {
                    ConstraintLayout.con conVar = (ConstraintLayout.con) obj;
                    if (i2 == 0) {
                        ((ViewGroup.MarginLayoutParams) conVar).width = 0;
                    } else {
                        ((ViewGroup.MarginLayoutParams) conVar).height = 0;
                    }
                    s(conVar, strTrim2);
                    return;
                }
                if (obj instanceof con) {
                    ((con) obj).f2241a = strTrim2;
                    return;
                } else {
                    if (obj instanceof aux.C0029aux) {
                        ((aux.C0029aux) obj).c(5, strTrim2);
                        return;
                    }
                    return;
                }
            }
            try {
                if ("weight".equalsIgnoreCase(strTrim)) {
                    float f2 = Float.parseFloat(strTrim2);
                    if (obj instanceof ConstraintLayout.con) {
                        ConstraintLayout.con conVar2 = (ConstraintLayout.con) obj;
                        if (i2 == 0) {
                            ((ViewGroup.MarginLayoutParams) conVar2).width = 0;
                            conVar2.f8039f = f2;
                        } else {
                            ((ViewGroup.MarginLayoutParams) conVar2).height = 0;
                            conVar2.f8040g = f2;
                        }
                    } else if (obj instanceof con) {
                        con conVar3 = (con) obj;
                        if (i2 == 0) {
                            conVar3.f2240a = 0;
                            conVar3.f8107f = f2;
                        } else {
                            conVar3.f2244b = 0;
                            conVar3.f8106e = f2;
                        }
                    } else if (obj instanceof aux.C0029aux) {
                        aux.C0029aux c0029aux = (aux.C0029aux) obj;
                        if (i2 == 0) {
                            c0029aux.b(23, 0);
                            c0029aux.a(39, f2);
                        } else {
                            c0029aux.b(21, 0);
                            c0029aux.a(40, f2);
                        }
                    }
                } else {
                    if (!"parent".equalsIgnoreCase(strTrim)) {
                        return;
                    }
                    float fMax = Math.max(0.0f, Math.min(1.0f, Float.parseFloat(strTrim2)));
                    if (obj instanceof ConstraintLayout.con) {
                        ConstraintLayout.con conVar4 = (ConstraintLayout.con) obj;
                        if (i2 == 0) {
                            ((ViewGroup.MarginLayoutParams) conVar4).width = 0;
                            conVar4.f8041h = fMax;
                            conVar4.E = 2;
                        } else {
                            ((ViewGroup.MarginLayoutParams) conVar4).height = 0;
                            conVar4.f8042i = fMax;
                            conVar4.F = 2;
                        }
                    } else if (obj instanceof con) {
                        con conVar5 = (con) obj;
                        if (i2 == 0) {
                            conVar5.f2240a = 0;
                            conVar5.f8108g = fMax;
                            conVar5.O = 2;
                        } else {
                            conVar5.f2244b = 0;
                            conVar5.f8109h = fMax;
                            conVar5.P = 2;
                        }
                    } else if (obj instanceof aux.C0029aux) {
                        aux.C0029aux c0029aux2 = (aux.C0029aux) obj;
                        if (i2 == 0) {
                            c0029aux2.b(23, 0);
                            c0029aux2.b(54, 2);
                        } else {
                            c0029aux2.b(21, 0);
                            c0029aux2.b(55, 2);
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
        }
    }

    public static void s(ConstraintLayout.con conVar, String str) {
        float fAbs = Float.NaN;
        int i2 = -1;
        if (str != null) {
            int length = str.length();
            int iIndexOf = str.indexOf(44);
            int i3 = 0;
            if (iIndexOf > 0 && iIndexOf < length - 1) {
                String strSubstring = str.substring(0, iIndexOf);
                if (strSubstring.equalsIgnoreCase("W")) {
                    i2 = 0;
                } else if (strSubstring.equalsIgnoreCase("H")) {
                    i2 = 1;
                }
                i3 = iIndexOf + 1;
            }
            int iIndexOf2 = str.indexOf(58);
            try {
                if (iIndexOf2 < 0 || iIndexOf2 >= length - 1) {
                    String strSubstring2 = str.substring(i3);
                    if (strSubstring2.length() > 0) {
                        fAbs = Float.parseFloat(strSubstring2);
                    }
                } else {
                    String strSubstring3 = str.substring(i3, iIndexOf2);
                    String strSubstring4 = str.substring(iIndexOf2 + 1);
                    if (strSubstring3.length() > 0 && strSubstring4.length() > 0) {
                        float f2 = Float.parseFloat(strSubstring3);
                        float f3 = Float.parseFloat(strSubstring4);
                        if (f2 > 0.0f && f3 > 0.0f) {
                            fAbs = i2 == 1 ? Math.abs(f3 / f2) : Math.abs(f2 / f3);
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
        }
        conVar.f2172a = str;
        conVar.f8038e = fAbs;
        conVar.B = i2;
    }

    public static void u(Context context, aux auxVar, TypedArray typedArray) {
        int indexCount = typedArray.getIndexCount();
        aux.C0029aux c0029aux = new aux.C0029aux();
        auxVar.f2221a = c0029aux;
        auxVar.f2224a.f2262a = false;
        auxVar.f2223a.f2246b = false;
        auxVar.f2225a.f2267a = false;
        auxVar.f2222a.f2237a = false;
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArray.getIndex(i2);
            switch (f8084b.get(index)) {
                case 2:
                    c0029aux.b(2, typedArray.getDimensionPixelSize(index, auxVar.f2223a.B));
                    break;
                case 3:
                case 4:
                case 9:
                case 10:
                case 25:
                case 26:
                case 29:
                case 30:
                case 32:
                case 33:
                case 35:
                case 36:
                case lpt4.AppCompatTheme_dialogCornerRadius /* 61 */:
                case lpt4.AppCompatTheme_panelMenuListWidth /* 88 */:
                case lpt4.AppCompatTheme_popupMenuStyle /* 89 */:
                case lpt4.AppCompatTheme_popupWindowStyle /* 90 */:
                case lpt4.AppCompatTheme_radioButtonStyle /* 91 */:
                case lpt4.AppCompatTheme_ratingBarStyle /* 92 */:
                default:
                    Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + f8083a.get(index));
                    break;
                case 5:
                    c0029aux.c(5, typedArray.getString(index));
                    break;
                case 6:
                    c0029aux.b(6, typedArray.getDimensionPixelOffset(index, auxVar.f2223a.f8123v));
                    break;
                case 7:
                    c0029aux.b(7, typedArray.getDimensionPixelOffset(index, auxVar.f2223a.f8124w));
                    break;
                case 8:
                    c0029aux.b(8, typedArray.getDimensionPixelSize(index, auxVar.f2223a.C));
                    break;
                case 11:
                    c0029aux.b(11, typedArray.getDimensionPixelSize(index, auxVar.f2223a.I));
                    break;
                case 12:
                    c0029aux.b(12, typedArray.getDimensionPixelSize(index, auxVar.f2223a.J));
                    break;
                case 13:
                    c0029aux.b(13, typedArray.getDimensionPixelSize(index, auxVar.f2223a.F));
                    break;
                case 14:
                    c0029aux.b(14, typedArray.getDimensionPixelSize(index, auxVar.f2223a.H));
                    break;
                case 15:
                    c0029aux.b(15, typedArray.getDimensionPixelSize(index, auxVar.f2223a.K));
                    break;
                case 16:
                    c0029aux.b(16, typedArray.getDimensionPixelSize(index, auxVar.f2223a.G));
                    break;
                case 17:
                    c0029aux.b(17, typedArray.getDimensionPixelOffset(index, auxVar.f2223a.f2247c));
                    break;
                case 18:
                    c0029aux.b(18, typedArray.getDimensionPixelOffset(index, auxVar.f2223a.f2250d));
                    break;
                case 19:
                    c0029aux.a(19, typedArray.getFloat(index, auxVar.f2223a.f2239a));
                    break;
                case 20:
                    c0029aux.a(20, typedArray.getFloat(index, auxVar.f2223a.f8103b));
                    break;
                case 21:
                    c0029aux.b(21, typedArray.getLayoutDimension(index, auxVar.f2223a.f2244b));
                    break;
                case 22:
                    c0029aux.b(22, f2215a[typedArray.getInt(index, auxVar.f2225a.f2266a)]);
                    break;
                case 23:
                    c0029aux.b(23, typedArray.getLayoutDimension(index, auxVar.f2223a.f2240a));
                    break;
                case 24:
                    c0029aux.b(24, typedArray.getDimensionPixelSize(index, auxVar.f2223a.f8126y));
                    break;
                case 27:
                    c0029aux.b(27, typedArray.getInt(index, auxVar.f2223a.f8125x));
                    break;
                case 28:
                    c0029aux.b(28, typedArray.getDimensionPixelSize(index, auxVar.f2223a.f8127z));
                    break;
                case 31:
                    c0029aux.b(31, typedArray.getDimensionPixelSize(index, auxVar.f2223a.D));
                    break;
                case 34:
                    c0029aux.b(34, typedArray.getDimensionPixelSize(index, auxVar.f2223a.A));
                    break;
                case lpt4.AppCompatTheme_alertDialogStyle /* 37 */:
                    c0029aux.a(37, typedArray.getFloat(index, auxVar.f2223a.f8104c));
                    break;
                case lpt4.AppCompatTheme_alertDialogTheme /* 38 */:
                    int resourceId = typedArray.getResourceId(index, auxVar.f8085a);
                    auxVar.f8085a = resourceId;
                    c0029aux.b(38, resourceId);
                    break;
                case lpt4.AppCompatTheme_autoCompleteTextViewStyle /* 39 */:
                    c0029aux.a(39, typedArray.getFloat(index, auxVar.f2223a.f8107f));
                    break;
                case lpt4.AppCompatTheme_borderlessButtonStyle /* 40 */:
                    c0029aux.a(40, typedArray.getFloat(index, auxVar.f2223a.f8106e));
                    break;
                case lpt4.AppCompatTheme_buttonBarButtonStyle /* 41 */:
                    c0029aux.b(41, typedArray.getInt(index, auxVar.f2223a.M));
                    break;
                case lpt4.AppCompatTheme_buttonBarNegativeButtonStyle /* 42 */:
                    c0029aux.b(42, typedArray.getInt(index, auxVar.f2223a.N));
                    break;
                case lpt4.AppCompatTheme_buttonBarNeutralButtonStyle /* 43 */:
                    c0029aux.a(43, typedArray.getFloat(index, auxVar.f2225a.f8136a));
                    break;
                case lpt4.AppCompatTheme_buttonBarPositiveButtonStyle /* 44 */:
                    c0029aux.d(44, true);
                    c0029aux.a(44, typedArray.getDimension(index, auxVar.f2222a.f8101k));
                    break;
                case lpt4.AppCompatTheme_buttonBarStyle /* 45 */:
                    c0029aux.a(45, typedArray.getFloat(index, auxVar.f2222a.f8092b));
                    break;
                case lpt4.AppCompatTheme_buttonStyle /* 46 */:
                    c0029aux.a(46, typedArray.getFloat(index, auxVar.f2222a.f8093c));
                    break;
                case lpt4.AppCompatTheme_buttonStyleSmall /* 47 */:
                    c0029aux.a(47, typedArray.getFloat(index, auxVar.f2222a.f8094d));
                    break;
                case 48:
                    c0029aux.a(48, typedArray.getFloat(index, auxVar.f2222a.f8095e));
                    break;
                case lpt4.AppCompatTheme_checkedTextViewStyle /* 49 */:
                    c0029aux.a(49, typedArray.getDimension(index, auxVar.f2222a.f8096f));
                    break;
                case 50:
                    c0029aux.a(50, typedArray.getDimension(index, auxVar.f2222a.f8097g));
                    break;
                case lpt4.AppCompatTheme_colorBackgroundFloating /* 51 */:
                    c0029aux.a(51, typedArray.getDimension(index, auxVar.f2222a.f8098h));
                    break;
                case lpt4.AppCompatTheme_colorButtonNormal /* 52 */:
                    c0029aux.a(52, typedArray.getDimension(index, auxVar.f2222a.f8099i));
                    break;
                case lpt4.AppCompatTheme_colorControlActivated /* 53 */:
                    c0029aux.a(53, typedArray.getDimension(index, auxVar.f2222a.f8100j));
                    break;
                case lpt4.AppCompatTheme_colorControlHighlight /* 54 */:
                    c0029aux.b(54, typedArray.getInt(index, auxVar.f2223a.O));
                    break;
                case lpt4.AppCompatTheme_colorControlNormal /* 55 */:
                    c0029aux.b(55, typedArray.getInt(index, auxVar.f2223a.P));
                    break;
                case lpt4.AppCompatTheme_colorError /* 56 */:
                    c0029aux.b(56, typedArray.getDimensionPixelSize(index, auxVar.f2223a.Q));
                    break;
                case lpt4.AppCompatTheme_colorPrimary /* 57 */:
                    c0029aux.b(57, typedArray.getDimensionPixelSize(index, auxVar.f2223a.R));
                    break;
                case lpt4.AppCompatTheme_colorPrimaryDark /* 58 */:
                    c0029aux.b(58, typedArray.getDimensionPixelSize(index, auxVar.f2223a.S));
                    break;
                case lpt4.AppCompatTheme_colorSwitchThumbNormal /* 59 */:
                    c0029aux.b(59, typedArray.getDimensionPixelSize(index, auxVar.f2223a.T));
                    break;
                case 60:
                    c0029aux.a(60, typedArray.getFloat(index, auxVar.f2222a.f2235a));
                    break;
                case lpt4.AppCompatTheme_dialogPreferredPadding /* 62 */:
                    c0029aux.b(62, typedArray.getDimensionPixelSize(index, auxVar.f2223a.f8122u));
                    break;
                case lpt4.AppCompatTheme_dialogTheme /* 63 */:
                    c0029aux.a(63, typedArray.getFloat(index, auxVar.f2223a.f8105d));
                    break;
                case 64:
                    c0029aux.b(64, p(typedArray, index, auxVar.f2224a.f2260a));
                    break;
                case lpt4.AppCompatTheme_dividerVertical /* 65 */:
                    if (typedArray.peekValue(index).type == 3) {
                        c0029aux.c(65, typedArray.getString(index));
                    } else {
                        c0029aux.c(65, g0.f5029a[typedArray.getInteger(index, 0)]);
                    }
                    break;
                case lpt4.AppCompatTheme_dropDownListViewStyle /* 66 */:
                    c0029aux.b(66, typedArray.getInt(index, 0));
                    break;
                case lpt4.AppCompatTheme_dropdownListPreferredItemHeight /* 67 */:
                    c0029aux.a(67, typedArray.getFloat(index, auxVar.f2224a.f8129b));
                    break;
                case lpt4.AppCompatTheme_editTextBackground /* 68 */:
                    c0029aux.a(68, typedArray.getFloat(index, auxVar.f2225a.f8137b));
                    break;
                case lpt4.AppCompatTheme_editTextColor /* 69 */:
                    c0029aux.a(69, typedArray.getFloat(index, 1.0f));
                    break;
                case lpt4.AppCompatTheme_editTextStyle /* 70 */:
                    c0029aux.a(70, typedArray.getFloat(index, 1.0f));
                    break;
                case lpt4.AppCompatTheme_homeAsUpIndicator /* 71 */:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    break;
                case lpt4.AppCompatTheme_imageButtonStyle /* 72 */:
                    c0029aux.b(72, typedArray.getInt(index, auxVar.f2223a.U));
                    break;
                case lpt4.AppCompatTheme_listChoiceBackgroundIndicator /* 73 */:
                    c0029aux.b(73, typedArray.getDimensionPixelSize(index, auxVar.f2223a.V));
                    break;
                case lpt4.AppCompatTheme_listChoiceIndicatorMultipleAnimated /* 74 */:
                    c0029aux.c(74, typedArray.getString(index));
                    break;
                case lpt4.AppCompatTheme_listChoiceIndicatorSingleAnimated /* 75 */:
                    c0029aux.d(75, typedArray.getBoolean(index, auxVar.f2223a.f2257g));
                    break;
                case lpt4.AppCompatTheme_listDividerAlertDialog /* 76 */:
                    c0029aux.b(76, typedArray.getInt(index, auxVar.f2224a.f2265c));
                    break;
                case lpt4.AppCompatTheme_listMenuViewStyle /* 77 */:
                    c0029aux.c(77, typedArray.getString(index));
                    break;
                case lpt4.AppCompatTheme_listPopupWindowStyle /* 78 */:
                    c0029aux.b(78, typedArray.getInt(index, auxVar.f2225a.f2268b));
                    break;
                case lpt4.AppCompatTheme_listPreferredItemHeight /* 79 */:
                    c0029aux.a(79, typedArray.getFloat(index, auxVar.f2224a.f2259a));
                    break;
                case lpt4.AppCompatTheme_listPreferredItemHeightLarge /* 80 */:
                    c0029aux.d(80, typedArray.getBoolean(index, auxVar.f2223a.f2253e));
                    break;
                case lpt4.AppCompatTheme_listPreferredItemHeightSmall /* 81 */:
                    c0029aux.d(81, typedArray.getBoolean(index, auxVar.f2223a.f2255f));
                    break;
                case lpt4.AppCompatTheme_listPreferredItemPaddingEnd /* 82 */:
                    c0029aux.b(82, typedArray.getInteger(index, auxVar.f2224a.f2263b));
                    break;
                case lpt4.AppCompatTheme_listPreferredItemPaddingLeft /* 83 */:
                    c0029aux.b(83, p(typedArray, index, auxVar.f2222a.f2236a));
                    break;
                case lpt4.AppCompatTheme_listPreferredItemPaddingRight /* 84 */:
                    c0029aux.b(84, typedArray.getInteger(index, auxVar.f2224a.f8133f));
                    break;
                case 85:
                    c0029aux.a(85, typedArray.getFloat(index, auxVar.f2224a.f8130c));
                    break;
                case lpt4.AppCompatTheme_panelBackground /* 86 */:
                    int i3 = typedArray.peekValue(index).type;
                    if (i3 == 1) {
                        auxVar.f2224a.f8135h = typedArray.getResourceId(index, -1);
                        c0029aux.b(89, auxVar.f2224a.f8135h);
                        C0030nul c0030nul = auxVar.f2224a;
                        if (c0030nul.f8135h != -1) {
                            c0030nul.f8134g = -2;
                            c0029aux.b(88, -2);
                        }
                    } else if (i3 == 3) {
                        auxVar.f2224a.f2264b = typedArray.getString(index);
                        c0029aux.c(90, auxVar.f2224a.f2264b);
                        if (auxVar.f2224a.f2264b.indexOf("/") > 0) {
                            auxVar.f2224a.f8135h = typedArray.getResourceId(index, -1);
                            c0029aux.b(89, auxVar.f2224a.f8135h);
                            auxVar.f2224a.f8134g = -2;
                            c0029aux.b(88, -2);
                        } else {
                            auxVar.f2224a.f8134g = -1;
                            c0029aux.b(88, -1);
                        }
                    } else {
                        C0030nul c0030nul2 = auxVar.f2224a;
                        c0030nul2.f8134g = typedArray.getInteger(index, c0030nul2.f8135h);
                        c0029aux.b(88, auxVar.f2224a.f8134g);
                    }
                    break;
                case lpt4.AppCompatTheme_panelMenuListTheme /* 87 */:
                    Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + f8083a.get(index));
                    break;
                case lpt4.AppCompatTheme_ratingBarStyleIndicator /* 93 */:
                    c0029aux.b(93, typedArray.getDimensionPixelSize(index, auxVar.f2223a.E));
                    break;
                case lpt4.AppCompatTheme_ratingBarStyleSmall /* 94 */:
                    c0029aux.b(94, typedArray.getDimensionPixelSize(index, auxVar.f2223a.L));
                    break;
                case lpt4.AppCompatTheme_searchViewStyle /* 95 */:
                    q(c0029aux, typedArray, index, 0);
                    break;
                case lpt4.AppCompatTheme_seekBarStyle /* 96 */:
                    q(c0029aux, typedArray, index, 1);
                    break;
                case lpt4.AppCompatTheme_selectableItemBackground /* 97 */:
                    c0029aux.b(97, typedArray.getInt(index, auxVar.f2223a.X));
                    break;
                case lpt4.AppCompatTheme_selectableItemBackgroundBorderless /* 98 */:
                    if (lpt6.f7551n) {
                        int resourceId2 = typedArray.getResourceId(index, auxVar.f8085a);
                        auxVar.f8085a = resourceId2;
                        if (resourceId2 == -1) {
                            auxVar.f2226a = typedArray.getString(index);
                        }
                    } else if (typedArray.peekValue(index).type == 3) {
                        auxVar.f2226a = typedArray.getString(index);
                    } else {
                        auxVar.f8085a = typedArray.getResourceId(index, auxVar.f8085a);
                    }
                    break;
                case lpt4.AppCompatTheme_spinnerDropDownItemStyle /* 99 */:
                    c0029aux.d(99, typedArray.getBoolean(index, auxVar.f2223a.f2251d));
                    break;
            }
        }
    }

    public void c(ConstraintLayout constraintLayout) {
        d(constraintLayout, true);
        constraintLayout.setConstraintSet(null);
        constraintLayout.requestLayout();
    }

    public void d(ConstraintLayout constraintLayout, boolean z2) {
        int childCount = constraintLayout.getChildCount();
        HashSet<Integer> hashSet = new HashSet(this.f2220b.keySet());
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            int id = childAt.getId();
            if (!this.f2220b.containsKey(Integer.valueOf(id))) {
                Log.w("ConstraintSet", "id unknown " + com6.b(childAt));
            } else {
                if (this.f2219a && id == -1) {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
                if (id != -1) {
                    if (this.f2220b.containsKey(Integer.valueOf(id))) {
                        hashSet.remove(Integer.valueOf(id));
                        aux auxVar = this.f2220b.get(Integer.valueOf(id));
                        if (auxVar != null) {
                            if (childAt instanceof Barrier) {
                                auxVar.f2223a.W = 1;
                                Barrier barrier = (Barrier) childAt;
                                barrier.setId(id);
                                barrier.setType(auxVar.f2223a.U);
                                barrier.setMargin(auxVar.f2223a.V);
                                barrier.setAllowsGoneWidget(auxVar.f2223a.f2257g);
                                con conVar = auxVar.f2223a;
                                int[] iArr = conVar.f2243a;
                                if (iArr != null) {
                                    barrier.setReferencedIds(iArr);
                                } else {
                                    String str = conVar.f2245b;
                                    if (str != null) {
                                        conVar.f2243a = k(barrier, str);
                                        barrier.setReferencedIds(auxVar.f2223a.f2243a);
                                    }
                                }
                            }
                            ConstraintLayout.con conVar2 = (ConstraintLayout.con) childAt.getLayoutParams();
                            conVar2.a();
                            auxVar.d(conVar2);
                            if (z2) {
                                androidx.constraintlayout.widget.aux.e(childAt, auxVar.f2227a);
                            }
                            childAt.setLayoutParams(conVar2);
                            prn prnVar = auxVar.f2225a;
                            if (prnVar.f2268b == 0) {
                                childAt.setVisibility(prnVar.f2266a);
                            }
                            childAt.setAlpha(auxVar.f2225a.f8136a);
                            childAt.setRotation(auxVar.f2222a.f2235a);
                            childAt.setRotationX(auxVar.f2222a.f8092b);
                            childAt.setRotationY(auxVar.f2222a.f8093c);
                            childAt.setScaleX(auxVar.f2222a.f8094d);
                            childAt.setScaleY(auxVar.f2222a.f8095e);
                            com1 com1Var = auxVar.f2222a;
                            if (com1Var.f2236a != -1) {
                                View viewFindViewById = ((View) childAt.getParent()).findViewById(auxVar.f2222a.f2236a);
                                if (viewFindViewById != null) {
                                    float top = (viewFindViewById.getTop() + viewFindViewById.getBottom()) / 2.0f;
                                    float left = (viewFindViewById.getLeft() + viewFindViewById.getRight()) / 2.0f;
                                    if (childAt.getRight() - childAt.getLeft() > 0 && childAt.getBottom() - childAt.getTop() > 0) {
                                        float left2 = left - childAt.getLeft();
                                        float top2 = top - childAt.getTop();
                                        childAt.setPivotX(left2);
                                        childAt.setPivotY(top2);
                                    }
                                }
                            } else {
                                if (!Float.isNaN(com1Var.f8096f)) {
                                    childAt.setPivotX(auxVar.f2222a.f8096f);
                                }
                                if (!Float.isNaN(auxVar.f2222a.f8097g)) {
                                    childAt.setPivotY(auxVar.f2222a.f8097g);
                                }
                            }
                            childAt.setTranslationX(auxVar.f2222a.f8098h);
                            childAt.setTranslationY(auxVar.f2222a.f8099i);
                            childAt.setTranslationZ(auxVar.f2222a.f8100j);
                            com1 com1Var2 = auxVar.f2222a;
                            if (com1Var2.f2238b) {
                                childAt.setElevation(com1Var2.f8101k);
                            }
                        }
                    } else {
                        Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                    }
                }
            }
        }
        for (Integer num : hashSet) {
            aux auxVar2 = this.f2220b.get(num);
            if (auxVar2 != null) {
                if (auxVar2.f2223a.W == 1) {
                    Barrier barrier2 = new Barrier(constraintLayout.getContext());
                    barrier2.setId(num.intValue());
                    con conVar3 = auxVar2.f2223a;
                    int[] iArr2 = conVar3.f2243a;
                    if (iArr2 != null) {
                        barrier2.setReferencedIds(iArr2);
                    } else {
                        String str2 = conVar3.f2245b;
                        if (str2 != null) {
                            conVar3.f2243a = k(barrier2, str2);
                            barrier2.setReferencedIds(auxVar2.f2223a.f2243a);
                        }
                    }
                    barrier2.setType(auxVar2.f2223a.U);
                    barrier2.setMargin(auxVar2.f2223a.V);
                    ConstraintLayout.con conVarGenerateDefaultLayoutParams = constraintLayout.generateDefaultLayoutParams();
                    barrier2.s();
                    auxVar2.d(conVarGenerateDefaultLayoutParams);
                    constraintLayout.addView(barrier2, conVarGenerateDefaultLayoutParams);
                }
                if (auxVar2.f2223a.f2242a) {
                    View guideline = new Guideline(constraintLayout.getContext());
                    guideline.setId(num.intValue());
                    ConstraintLayout.con conVarGenerateDefaultLayoutParams2 = constraintLayout.generateDefaultLayoutParams();
                    auxVar2.d(conVarGenerateDefaultLayoutParams2);
                    constraintLayout.addView(guideline, conVarGenerateDefaultLayoutParams2);
                }
            }
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = constraintLayout.getChildAt(i3);
            if (childAt2 instanceof androidx.constraintlayout.widget.con) {
                ((androidx.constraintlayout.widget.con) childAt2).i(constraintLayout);
            }
        }
    }

    public void e(int i2, int i3) {
        aux auxVar;
        if (!this.f2220b.containsKey(Integer.valueOf(i2)) || (auxVar = this.f2220b.get(Integer.valueOf(i2))) == null) {
            return;
        }
        switch (i3) {
            case 1:
                con conVar = auxVar.f2223a;
                conVar.f2254f = -1;
                conVar.f2252e = -1;
                conVar.f8126y = -1;
                conVar.F = Integer.MIN_VALUE;
                return;
            case 2:
                con conVar2 = auxVar.f2223a;
                conVar2.f2258h = -1;
                conVar2.f2256g = -1;
                conVar2.f8127z = -1;
                conVar2.H = Integer.MIN_VALUE;
                return;
            case 3:
                con conVar3 = auxVar.f2223a;
                conVar3.f8111j = -1;
                conVar3.f8110i = -1;
                conVar3.A = 0;
                conVar3.G = Integer.MIN_VALUE;
                return;
            case 4:
                con conVar4 = auxVar.f2223a;
                conVar4.f8112k = -1;
                conVar4.f8113l = -1;
                conVar4.B = 0;
                conVar4.I = Integer.MIN_VALUE;
                return;
            case 5:
                con conVar5 = auxVar.f2223a;
                conVar5.f8114m = -1;
                conVar5.f8115n = -1;
                conVar5.f8116o = -1;
                conVar5.E = 0;
                conVar5.L = Integer.MIN_VALUE;
                return;
            case 6:
                con conVar6 = auxVar.f2223a;
                conVar6.f8117p = -1;
                conVar6.f8118q = -1;
                conVar6.D = 0;
                conVar6.K = Integer.MIN_VALUE;
                return;
            case 7:
                con conVar7 = auxVar.f2223a;
                conVar7.f8119r = -1;
                conVar7.f8120s = -1;
                conVar7.C = 0;
                conVar7.J = Integer.MIN_VALUE;
                return;
            case 8:
                con conVar8 = auxVar.f2223a;
                conVar8.f8105d = -1.0f;
                conVar8.f8122u = -1;
                conVar8.f8121t = -1;
                return;
            default:
                throw new IllegalArgumentException("unknown constraint");
        }
    }

    public void f(Context context, int i2) {
        g((ConstraintLayout) LayoutInflater.from(context).inflate(i2, (ViewGroup) null));
    }

    public void g(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        this.f2220b.clear();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = constraintLayout.getChildAt(i2);
            ConstraintLayout.con conVar = (ConstraintLayout.con) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f2219a && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f2220b.containsKey(Integer.valueOf(id))) {
                this.f2220b.put(Integer.valueOf(id), new aux());
            }
            aux auxVar = this.f2220b.get(Integer.valueOf(id));
            if (auxVar != null) {
                auxVar.f2227a = androidx.constraintlayout.widget.aux.a(this.f2218a, childAt);
                auxVar.f(id, conVar);
                auxVar.f2225a.f2266a = childAt.getVisibility();
                auxVar.f2225a.f8136a = childAt.getAlpha();
                auxVar.f2222a.f2235a = childAt.getRotation();
                auxVar.f2222a.f8092b = childAt.getRotationX();
                auxVar.f2222a.f8093c = childAt.getRotationY();
                auxVar.f2222a.f8094d = childAt.getScaleX();
                auxVar.f2222a.f8095e = childAt.getScaleY();
                float pivotX = childAt.getPivotX();
                float pivotY = childAt.getPivotY();
                if (pivotX != 0.0d || pivotY != 0.0d) {
                    com1 com1Var = auxVar.f2222a;
                    com1Var.f8096f = pivotX;
                    com1Var.f8097g = pivotY;
                }
                auxVar.f2222a.f8098h = childAt.getTranslationX();
                auxVar.f2222a.f8099i = childAt.getTranslationY();
                auxVar.f2222a.f8100j = childAt.getTranslationZ();
                com1 com1Var2 = auxVar.f2222a;
                if (com1Var2.f2238b) {
                    com1Var2.f8101k = childAt.getElevation();
                }
                if (childAt instanceof Barrier) {
                    Barrier barrier = (Barrier) childAt;
                    auxVar.f2223a.f2257g = barrier.getAllowsGoneWidget();
                    auxVar.f2223a.f2243a = barrier.getReferencedIds();
                    auxVar.f2223a.U = barrier.getType();
                    auxVar.f2223a.V = barrier.getMargin();
                }
            }
        }
    }

    public void h(androidx.constraintlayout.widget.prn prnVar) {
        int childCount = prnVar.getChildCount();
        this.f2220b.clear();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = prnVar.getChildAt(i2);
            androidx.constraintlayout.widget.prn.aux auxVar = (androidx.constraintlayout.widget.prn.aux) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f2219a && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f2220b.containsKey(Integer.valueOf(id))) {
                this.f2220b.put(Integer.valueOf(id), new aux());
            }
            aux auxVar2 = this.f2220b.get(Integer.valueOf(id));
            if (auxVar2 != null) {
                if (childAt instanceof androidx.constraintlayout.widget.con) {
                    auxVar2.h((androidx.constraintlayout.widget.con) childAt, id, auxVar);
                }
                auxVar2.g(id, auxVar);
            }
        }
    }

    public void i(int i2, int i3, int i4, int i5, int i6) {
        if (!this.f2220b.containsKey(Integer.valueOf(i2))) {
            this.f2220b.put(Integer.valueOf(i2), new aux());
        }
        aux auxVar = this.f2220b.get(Integer.valueOf(i2));
        if (auxVar == null) {
            return;
        }
        switch (i3) {
            case 1:
                if (i5 == 1) {
                    con conVar = auxVar.f2223a;
                    conVar.f2252e = i4;
                    conVar.f2254f = -1;
                } else {
                    if (i5 != 2) {
                        throw new IllegalArgumentException("Left to " + v(i5) + " undefined");
                    }
                    con conVar2 = auxVar.f2223a;
                    conVar2.f2254f = i4;
                    conVar2.f2252e = -1;
                }
                auxVar.f2223a.f8126y = i6;
                return;
            case 2:
                if (i5 == 1) {
                    con conVar3 = auxVar.f2223a;
                    conVar3.f2256g = i4;
                    conVar3.f2258h = -1;
                } else {
                    if (i5 != 2) {
                        throw new IllegalArgumentException("right to " + v(i5) + " undefined");
                    }
                    con conVar4 = auxVar.f2223a;
                    conVar4.f2258h = i4;
                    conVar4.f2256g = -1;
                }
                auxVar.f2223a.f8127z = i6;
                return;
            case 3:
                if (i5 == 3) {
                    con conVar5 = auxVar.f2223a;
                    conVar5.f8110i = i4;
                    conVar5.f8111j = -1;
                    conVar5.f8114m = -1;
                    conVar5.f8115n = -1;
                    conVar5.f8116o = -1;
                } else {
                    if (i5 != 4) {
                        throw new IllegalArgumentException("right to " + v(i5) + " undefined");
                    }
                    con conVar6 = auxVar.f2223a;
                    conVar6.f8111j = i4;
                    conVar6.f8110i = -1;
                    conVar6.f8114m = -1;
                    conVar6.f8115n = -1;
                    conVar6.f8116o = -1;
                }
                auxVar.f2223a.A = i6;
                return;
            case 4:
                if (i5 == 4) {
                    con conVar7 = auxVar.f2223a;
                    conVar7.f8113l = i4;
                    conVar7.f8112k = -1;
                    conVar7.f8114m = -1;
                    conVar7.f8115n = -1;
                    conVar7.f8116o = -1;
                } else {
                    if (i5 != 3) {
                        throw new IllegalArgumentException("right to " + v(i5) + " undefined");
                    }
                    con conVar8 = auxVar.f2223a;
                    conVar8.f8112k = i4;
                    conVar8.f8113l = -1;
                    conVar8.f8114m = -1;
                    conVar8.f8115n = -1;
                    conVar8.f8116o = -1;
                }
                auxVar.f2223a.B = i6;
                return;
            case 5:
                if (i5 == 5) {
                    con conVar9 = auxVar.f2223a;
                    conVar9.f8114m = i4;
                    conVar9.f8113l = -1;
                    conVar9.f8112k = -1;
                    conVar9.f8110i = -1;
                    conVar9.f8111j = -1;
                    return;
                }
                if (i5 == 3) {
                    con conVar10 = auxVar.f2223a;
                    conVar10.f8115n = i4;
                    conVar10.f8113l = -1;
                    conVar10.f8112k = -1;
                    conVar10.f8110i = -1;
                    conVar10.f8111j = -1;
                    return;
                }
                if (i5 != 4) {
                    throw new IllegalArgumentException("right to " + v(i5) + " undefined");
                }
                con conVar11 = auxVar.f2223a;
                conVar11.f8116o = i4;
                conVar11.f8113l = -1;
                conVar11.f8112k = -1;
                conVar11.f8110i = -1;
                conVar11.f8111j = -1;
                return;
            case 6:
                if (i5 == 6) {
                    con conVar12 = auxVar.f2223a;
                    conVar12.f8118q = i4;
                    conVar12.f8117p = -1;
                } else {
                    if (i5 != 7) {
                        throw new IllegalArgumentException("right to " + v(i5) + " undefined");
                    }
                    con conVar13 = auxVar.f2223a;
                    conVar13.f8117p = i4;
                    conVar13.f8118q = -1;
                }
                auxVar.f2223a.D = i6;
                return;
            case 7:
                if (i5 == 7) {
                    con conVar14 = auxVar.f2223a;
                    conVar14.f8120s = i4;
                    conVar14.f8119r = -1;
                } else {
                    if (i5 != 6) {
                        throw new IllegalArgumentException("right to " + v(i5) + " undefined");
                    }
                    con conVar15 = auxVar.f2223a;
                    conVar15.f8119r = i4;
                    conVar15.f8120s = -1;
                }
                auxVar.f2223a.C = i6;
                return;
            default:
                throw new IllegalArgumentException(v(i3) + " to " + v(i5) + " unknown");
        }
    }

    public void j(int i2, int i3, int i4, float f2) {
        con conVar = m(i2).f2223a;
        conVar.f8121t = i3;
        conVar.f8122u = i4;
        conVar.f8105d = f2;
    }

    public final int[] k(View view, String str) {
        int iIntValue;
        Object objG;
        String[] strArrSplit = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[strArrSplit.length];
        int i2 = 0;
        int i3 = 0;
        while (i2 < strArrSplit.length) {
            String strTrim = strArrSplit[i2].trim();
            try {
                iIntValue = p151pRn.g0.class.getField(strTrim).getInt(null);
            } catch (Exception unused) {
                iIntValue = 0;
            }
            if (iIntValue == 0) {
                iIntValue = context.getResources().getIdentifier(strTrim, DistributedTracing.NR_ID_ATTRIBUTE, context.getPackageName());
            }
            if (iIntValue == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (objG = ((ConstraintLayout) view.getParent()).g(0, strTrim)) != null && (objG instanceof Integer)) {
                iIntValue = ((Integer) objG).intValue();
            }
            iArr[i3] = iIntValue;
            i2++;
            i3++;
        }
        return i3 != strArrSplit.length ? Arrays.copyOf(iArr, i3) : iArr;
    }

    public final aux l(Context context, AttributeSet attributeSet, boolean z2) {
        aux auxVar = new aux();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z2 ? h0.f5230x : h0.f5222t);
        t(context, auxVar, typedArrayObtainStyledAttributes, z2);
        typedArrayObtainStyledAttributes.recycle();
        return auxVar;
    }

    public final aux m(int i2) {
        if (!this.f2220b.containsKey(Integer.valueOf(i2))) {
            this.f2220b.put(Integer.valueOf(i2), new aux());
        }
        return this.f2220b.get(Integer.valueOf(i2));
    }

    public void n(Context context, int i2) {
        XmlResourceParser xml = context.getResources().getXml(i2);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    aux auxVarL = l(context, Xml.asAttributeSet(xml), false);
                    if (name.equalsIgnoreCase("Guideline")) {
                        auxVarL.f2223a.f2242a = true;
                    }
                    this.f2220b.put(Integer.valueOf(auxVarL.f8085a), auxVarL);
                }
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public void o(Context context, XmlPullParser xmlPullParser) {
        aux auxVarL;
        try {
            int eventType = xmlPullParser.getEventType();
            aux auxVar = null;
            while (eventType != 1) {
                if (eventType == 0) {
                    xmlPullParser.getName();
                } else if (eventType == 2) {
                    switch (xmlPullParser.getName()) {
                        case "Constraint":
                            auxVarL = l(context, Xml.asAttributeSet(xmlPullParser), false);
                            break;
                        case "ConstraintOverride":
                            auxVarL = l(context, Xml.asAttributeSet(xmlPullParser), true);
                            break;
                        case "Guideline":
                            auxVarL = l(context, Xml.asAttributeSet(xmlPullParser), false);
                            con conVar = auxVarL.f2223a;
                            conVar.f2242a = true;
                            conVar.f2246b = true;
                            break;
                        case "Barrier":
                            auxVarL = l(context, Xml.asAttributeSet(xmlPullParser), false);
                            auxVarL.f2223a.W = 1;
                            break;
                        case "PropertySet":
                            if (auxVar == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                            }
                            auxVar.f2225a.b(context, Xml.asAttributeSet(xmlPullParser));
                            continue;
                            break;
                            break;
                        case "Transform":
                            if (auxVar == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                            }
                            auxVar.f2222a.b(context, Xml.asAttributeSet(xmlPullParser));
                            continue;
                            break;
                            break;
                        case "Layout":
                            if (auxVar == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                            }
                            auxVar.f2223a.b(context, Xml.asAttributeSet(xmlPullParser));
                            continue;
                            break;
                            break;
                        case "Motion":
                            if (auxVar == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                            }
                            auxVar.f2224a.b(context, Xml.asAttributeSet(xmlPullParser));
                            continue;
                            break;
                            break;
                        case "CustomAttribute":
                        case "CustomMethod":
                            if (auxVar == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                            }
                            androidx.constraintlayout.widget.aux.d(context, xmlPullParser, auxVar.f2227a);
                            continue;
                            break;
                            break;
                        default:
                            continue;
                            break;
                    }
                    auxVar = auxVarL;
                } else if (eventType == 3) {
                    String lowerCase = xmlPullParser.getName().toLowerCase(Locale.ROOT);
                    switch (lowerCase.hashCode()) {
                        case -2075718416:
                            if (lowerCase.equals("guideline")) {
                            }
                            break;
                        case -190376483:
                            if (lowerCase.equals("constraint")) {
                            }
                            break;
                        case 426575017:
                            if (lowerCase.equals("constraintoverride")) {
                            }
                            break;
                        case 2146106725:
                            if (lowerCase.equals("constraintset")) {
                            }
                            break;
                    }
                    if (r4 == 0) {
                        return;
                    }
                    if (r4 == 1 || r4 == 2 || r4 == 3) {
                        this.f2220b.put(Integer.valueOf(auxVar.f8085a), auxVar);
                        auxVar = null;
                    }
                }
                eventType = xmlPullParser.next();
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        } catch (XmlPullParserException e3) {
            e3.printStackTrace();
        }
    }

    public final void t(Context context, aux auxVar, TypedArray typedArray, boolean z2) {
        if (z2) {
            u(context, auxVar, typedArray);
            return;
        }
        int indexCount = typedArray.getIndexCount();
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArray.getIndex(i2);
            if (index != h0.f11660b && h0.f11692t != index && h0.f11693u != index) {
                auxVar.f2224a.f2262a = true;
                auxVar.f2223a.f2246b = true;
                auxVar.f2225a.f2267a = true;
                auxVar.f2222a.f2237a = true;
            }
            switch (f8083a.get(index)) {
                case 1:
                    con conVar = auxVar.f2223a;
                    conVar.f8114m = p(typedArray, index, conVar.f8114m);
                    break;
                case 2:
                    con conVar2 = auxVar.f2223a;
                    conVar2.B = typedArray.getDimensionPixelSize(index, conVar2.B);
                    break;
                case 3:
                    con conVar3 = auxVar.f2223a;
                    conVar3.f8113l = p(typedArray, index, conVar3.f8113l);
                    break;
                case 4:
                    con conVar4 = auxVar.f2223a;
                    conVar4.f8112k = p(typedArray, index, conVar4.f8112k);
                    break;
                case 5:
                    auxVar.f2223a.f2241a = typedArray.getString(index);
                    break;
                case 6:
                    con conVar5 = auxVar.f2223a;
                    conVar5.f8123v = typedArray.getDimensionPixelOffset(index, conVar5.f8123v);
                    break;
                case 7:
                    con conVar6 = auxVar.f2223a;
                    conVar6.f8124w = typedArray.getDimensionPixelOffset(index, conVar6.f8124w);
                    break;
                case 8:
                    con conVar7 = auxVar.f2223a;
                    conVar7.C = typedArray.getDimensionPixelSize(index, conVar7.C);
                    break;
                case 9:
                    con conVar8 = auxVar.f2223a;
                    conVar8.f8120s = p(typedArray, index, conVar8.f8120s);
                    break;
                case 10:
                    con conVar9 = auxVar.f2223a;
                    conVar9.f8119r = p(typedArray, index, conVar9.f8119r);
                    break;
                case 11:
                    con conVar10 = auxVar.f2223a;
                    conVar10.I = typedArray.getDimensionPixelSize(index, conVar10.I);
                    break;
                case 12:
                    con conVar11 = auxVar.f2223a;
                    conVar11.J = typedArray.getDimensionPixelSize(index, conVar11.J);
                    break;
                case 13:
                    con conVar12 = auxVar.f2223a;
                    conVar12.F = typedArray.getDimensionPixelSize(index, conVar12.F);
                    break;
                case 14:
                    con conVar13 = auxVar.f2223a;
                    conVar13.H = typedArray.getDimensionPixelSize(index, conVar13.H);
                    break;
                case 15:
                    con conVar14 = auxVar.f2223a;
                    conVar14.K = typedArray.getDimensionPixelSize(index, conVar14.K);
                    break;
                case 16:
                    con conVar15 = auxVar.f2223a;
                    conVar15.G = typedArray.getDimensionPixelSize(index, conVar15.G);
                    break;
                case 17:
                    con conVar16 = auxVar.f2223a;
                    conVar16.f2247c = typedArray.getDimensionPixelOffset(index, conVar16.f2247c);
                    break;
                case 18:
                    con conVar17 = auxVar.f2223a;
                    conVar17.f2250d = typedArray.getDimensionPixelOffset(index, conVar17.f2250d);
                    break;
                case 19:
                    con conVar18 = auxVar.f2223a;
                    conVar18.f2239a = typedArray.getFloat(index, conVar18.f2239a);
                    break;
                case 20:
                    con conVar19 = auxVar.f2223a;
                    conVar19.f8103b = typedArray.getFloat(index, conVar19.f8103b);
                    break;
                case 21:
                    con conVar20 = auxVar.f2223a;
                    conVar20.f2244b = typedArray.getLayoutDimension(index, conVar20.f2244b);
                    break;
                case 22:
                    prn prnVar = auxVar.f2225a;
                    prnVar.f2266a = typedArray.getInt(index, prnVar.f2266a);
                    prn prnVar2 = auxVar.f2225a;
                    prnVar2.f2266a = f2215a[prnVar2.f2266a];
                    break;
                case 23:
                    con conVar21 = auxVar.f2223a;
                    conVar21.f2240a = typedArray.getLayoutDimension(index, conVar21.f2240a);
                    break;
                case 24:
                    con conVar22 = auxVar.f2223a;
                    conVar22.f8126y = typedArray.getDimensionPixelSize(index, conVar22.f8126y);
                    break;
                case 25:
                    con conVar23 = auxVar.f2223a;
                    conVar23.f2252e = p(typedArray, index, conVar23.f2252e);
                    break;
                case 26:
                    con conVar24 = auxVar.f2223a;
                    conVar24.f2254f = p(typedArray, index, conVar24.f2254f);
                    break;
                case 27:
                    con conVar25 = auxVar.f2223a;
                    conVar25.f8125x = typedArray.getInt(index, conVar25.f8125x);
                    break;
                case 28:
                    con conVar26 = auxVar.f2223a;
                    conVar26.f8127z = typedArray.getDimensionPixelSize(index, conVar26.f8127z);
                    break;
                case 29:
                    con conVar27 = auxVar.f2223a;
                    conVar27.f2256g = p(typedArray, index, conVar27.f2256g);
                    break;
                case 30:
                    con conVar28 = auxVar.f2223a;
                    conVar28.f2258h = p(typedArray, index, conVar28.f2258h);
                    break;
                case 31:
                    con conVar29 = auxVar.f2223a;
                    conVar29.D = typedArray.getDimensionPixelSize(index, conVar29.D);
                    break;
                case 32:
                    con conVar30 = auxVar.f2223a;
                    conVar30.f8117p = p(typedArray, index, conVar30.f8117p);
                    break;
                case 33:
                    con conVar31 = auxVar.f2223a;
                    conVar31.f8118q = p(typedArray, index, conVar31.f8118q);
                    break;
                case 34:
                    con conVar32 = auxVar.f2223a;
                    conVar32.A = typedArray.getDimensionPixelSize(index, conVar32.A);
                    break;
                case 35:
                    con conVar33 = auxVar.f2223a;
                    conVar33.f8111j = p(typedArray, index, conVar33.f8111j);
                    break;
                case 36:
                    con conVar34 = auxVar.f2223a;
                    conVar34.f8110i = p(typedArray, index, conVar34.f8110i);
                    break;
                case lpt4.AppCompatTheme_alertDialogStyle /* 37 */:
                    con conVar35 = auxVar.f2223a;
                    conVar35.f8104c = typedArray.getFloat(index, conVar35.f8104c);
                    break;
                case lpt4.AppCompatTheme_alertDialogTheme /* 38 */:
                    auxVar.f8085a = typedArray.getResourceId(index, auxVar.f8085a);
                    break;
                case lpt4.AppCompatTheme_autoCompleteTextViewStyle /* 39 */:
                    con conVar36 = auxVar.f2223a;
                    conVar36.f8107f = typedArray.getFloat(index, conVar36.f8107f);
                    break;
                case lpt4.AppCompatTheme_borderlessButtonStyle /* 40 */:
                    con conVar37 = auxVar.f2223a;
                    conVar37.f8106e = typedArray.getFloat(index, conVar37.f8106e);
                    break;
                case lpt4.AppCompatTheme_buttonBarButtonStyle /* 41 */:
                    con conVar38 = auxVar.f2223a;
                    conVar38.M = typedArray.getInt(index, conVar38.M);
                    break;
                case lpt4.AppCompatTheme_buttonBarNegativeButtonStyle /* 42 */:
                    con conVar39 = auxVar.f2223a;
                    conVar39.N = typedArray.getInt(index, conVar39.N);
                    break;
                case lpt4.AppCompatTheme_buttonBarNeutralButtonStyle /* 43 */:
                    prn prnVar3 = auxVar.f2225a;
                    prnVar3.f8136a = typedArray.getFloat(index, prnVar3.f8136a);
                    break;
                case lpt4.AppCompatTheme_buttonBarPositiveButtonStyle /* 44 */:
                    com1 com1Var = auxVar.f2222a;
                    com1Var.f2238b = true;
                    com1Var.f8101k = typedArray.getDimension(index, com1Var.f8101k);
                    break;
                case lpt4.AppCompatTheme_buttonBarStyle /* 45 */:
                    com1 com1Var2 = auxVar.f2222a;
                    com1Var2.f8092b = typedArray.getFloat(index, com1Var2.f8092b);
                    break;
                case lpt4.AppCompatTheme_buttonStyle /* 46 */:
                    com1 com1Var3 = auxVar.f2222a;
                    com1Var3.f8093c = typedArray.getFloat(index, com1Var3.f8093c);
                    break;
                case lpt4.AppCompatTheme_buttonStyleSmall /* 47 */:
                    com1 com1Var4 = auxVar.f2222a;
                    com1Var4.f8094d = typedArray.getFloat(index, com1Var4.f8094d);
                    break;
                case 48:
                    com1 com1Var5 = auxVar.f2222a;
                    com1Var5.f8095e = typedArray.getFloat(index, com1Var5.f8095e);
                    break;
                case lpt4.AppCompatTheme_checkedTextViewStyle /* 49 */:
                    com1 com1Var6 = auxVar.f2222a;
                    com1Var6.f8096f = typedArray.getDimension(index, com1Var6.f8096f);
                    break;
                case 50:
                    com1 com1Var7 = auxVar.f2222a;
                    com1Var7.f8097g = typedArray.getDimension(index, com1Var7.f8097g);
                    break;
                case lpt4.AppCompatTheme_colorBackgroundFloating /* 51 */:
                    com1 com1Var8 = auxVar.f2222a;
                    com1Var8.f8098h = typedArray.getDimension(index, com1Var8.f8098h);
                    break;
                case lpt4.AppCompatTheme_colorButtonNormal /* 52 */:
                    com1 com1Var9 = auxVar.f2222a;
                    com1Var9.f8099i = typedArray.getDimension(index, com1Var9.f8099i);
                    break;
                case lpt4.AppCompatTheme_colorControlActivated /* 53 */:
                    com1 com1Var10 = auxVar.f2222a;
                    com1Var10.f8100j = typedArray.getDimension(index, com1Var10.f8100j);
                    break;
                case lpt4.AppCompatTheme_colorControlHighlight /* 54 */:
                    con conVar40 = auxVar.f2223a;
                    conVar40.O = typedArray.getInt(index, conVar40.O);
                    break;
                case lpt4.AppCompatTheme_colorControlNormal /* 55 */:
                    con conVar41 = auxVar.f2223a;
                    conVar41.P = typedArray.getInt(index, conVar41.P);
                    break;
                case lpt4.AppCompatTheme_colorError /* 56 */:
                    con conVar42 = auxVar.f2223a;
                    conVar42.Q = typedArray.getDimensionPixelSize(index, conVar42.Q);
                    break;
                case lpt4.AppCompatTheme_colorPrimary /* 57 */:
                    con conVar43 = auxVar.f2223a;
                    conVar43.R = typedArray.getDimensionPixelSize(index, conVar43.R);
                    break;
                case lpt4.AppCompatTheme_colorPrimaryDark /* 58 */:
                    con conVar44 = auxVar.f2223a;
                    conVar44.S = typedArray.getDimensionPixelSize(index, conVar44.S);
                    break;
                case lpt4.AppCompatTheme_colorSwitchThumbNormal /* 59 */:
                    con conVar45 = auxVar.f2223a;
                    conVar45.T = typedArray.getDimensionPixelSize(index, conVar45.T);
                    break;
                case 60:
                    com1 com1Var11 = auxVar.f2222a;
                    com1Var11.f2235a = typedArray.getFloat(index, com1Var11.f2235a);
                    break;
                case lpt4.AppCompatTheme_dialogCornerRadius /* 61 */:
                    con conVar46 = auxVar.f2223a;
                    conVar46.f8121t = p(typedArray, index, conVar46.f8121t);
                    break;
                case lpt4.AppCompatTheme_dialogPreferredPadding /* 62 */:
                    con conVar47 = auxVar.f2223a;
                    conVar47.f8122u = typedArray.getDimensionPixelSize(index, conVar47.f8122u);
                    break;
                case lpt4.AppCompatTheme_dialogTheme /* 63 */:
                    con conVar48 = auxVar.f2223a;
                    conVar48.f8105d = typedArray.getFloat(index, conVar48.f8105d);
                    break;
                case 64:
                    C0030nul c0030nul = auxVar.f2224a;
                    c0030nul.f2260a = p(typedArray, index, c0030nul.f2260a);
                    break;
                case lpt4.AppCompatTheme_dividerVertical /* 65 */:
                    if (typedArray.peekValue(index).type == 3) {
                        auxVar.f2224a.f2261a = typedArray.getString(index);
                    } else {
                        auxVar.f2224a.f2261a = g0.f5029a[typedArray.getInteger(index, 0)];
                    }
                    break;
                case lpt4.AppCompatTheme_dropDownListViewStyle /* 66 */:
                    auxVar.f2224a.f8131d = typedArray.getInt(index, 0);
                    break;
                case lpt4.AppCompatTheme_dropdownListPreferredItemHeight /* 67 */:
                    C0030nul c0030nul2 = auxVar.f2224a;
                    c0030nul2.f8129b = typedArray.getFloat(index, c0030nul2.f8129b);
                    break;
                case lpt4.AppCompatTheme_editTextBackground /* 68 */:
                    prn prnVar4 = auxVar.f2225a;
                    prnVar4.f8137b = typedArray.getFloat(index, prnVar4.f8137b);
                    break;
                case lpt4.AppCompatTheme_editTextColor /* 69 */:
                    auxVar.f2223a.f8108g = typedArray.getFloat(index, 1.0f);
                    break;
                case lpt4.AppCompatTheme_editTextStyle /* 70 */:
                    auxVar.f2223a.f8109h = typedArray.getFloat(index, 1.0f);
                    break;
                case lpt4.AppCompatTheme_homeAsUpIndicator /* 71 */:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    break;
                case lpt4.AppCompatTheme_imageButtonStyle /* 72 */:
                    con conVar49 = auxVar.f2223a;
                    conVar49.U = typedArray.getInt(index, conVar49.U);
                    break;
                case lpt4.AppCompatTheme_listChoiceBackgroundIndicator /* 73 */:
                    con conVar50 = auxVar.f2223a;
                    conVar50.V = typedArray.getDimensionPixelSize(index, conVar50.V);
                    break;
                case lpt4.AppCompatTheme_listChoiceIndicatorMultipleAnimated /* 74 */:
                    auxVar.f2223a.f2245b = typedArray.getString(index);
                    break;
                case lpt4.AppCompatTheme_listChoiceIndicatorSingleAnimated /* 75 */:
                    con conVar51 = auxVar.f2223a;
                    conVar51.f2257g = typedArray.getBoolean(index, conVar51.f2257g);
                    break;
                case lpt4.AppCompatTheme_listDividerAlertDialog /* 76 */:
                    C0030nul c0030nul3 = auxVar.f2224a;
                    c0030nul3.f2265c = typedArray.getInt(index, c0030nul3.f2265c);
                    break;
                case lpt4.AppCompatTheme_listMenuViewStyle /* 77 */:
                    auxVar.f2223a.f2248c = typedArray.getString(index);
                    break;
                case lpt4.AppCompatTheme_listPopupWindowStyle /* 78 */:
                    prn prnVar5 = auxVar.f2225a;
                    prnVar5.f2268b = typedArray.getInt(index, prnVar5.f2268b);
                    break;
                case lpt4.AppCompatTheme_listPreferredItemHeight /* 79 */:
                    C0030nul c0030nul4 = auxVar.f2224a;
                    c0030nul4.f2259a = typedArray.getFloat(index, c0030nul4.f2259a);
                    break;
                case lpt4.AppCompatTheme_listPreferredItemHeightLarge /* 80 */:
                    con conVar52 = auxVar.f2223a;
                    conVar52.f2253e = typedArray.getBoolean(index, conVar52.f2253e);
                    break;
                case lpt4.AppCompatTheme_listPreferredItemHeightSmall /* 81 */:
                    con conVar53 = auxVar.f2223a;
                    conVar53.f2255f = typedArray.getBoolean(index, conVar53.f2255f);
                    break;
                case lpt4.AppCompatTheme_listPreferredItemPaddingEnd /* 82 */:
                    C0030nul c0030nul5 = auxVar.f2224a;
                    c0030nul5.f2263b = typedArray.getInteger(index, c0030nul5.f2263b);
                    break;
                case lpt4.AppCompatTheme_listPreferredItemPaddingLeft /* 83 */:
                    com1 com1Var12 = auxVar.f2222a;
                    com1Var12.f2236a = p(typedArray, index, com1Var12.f2236a);
                    break;
                case lpt4.AppCompatTheme_listPreferredItemPaddingRight /* 84 */:
                    C0030nul c0030nul6 = auxVar.f2224a;
                    c0030nul6.f8133f = typedArray.getInteger(index, c0030nul6.f8133f);
                    break;
                case 85:
                    C0030nul c0030nul7 = auxVar.f2224a;
                    c0030nul7.f8130c = typedArray.getFloat(index, c0030nul7.f8130c);
                    break;
                case lpt4.AppCompatTheme_panelBackground /* 86 */:
                    int i3 = typedArray.peekValue(index).type;
                    if (i3 == 1) {
                        auxVar.f2224a.f8135h = typedArray.getResourceId(index, -1);
                        C0030nul c0030nul8 = auxVar.f2224a;
                        if (c0030nul8.f8135h != -1) {
                            c0030nul8.f8134g = -2;
                        }
                    } else if (i3 == 3) {
                        auxVar.f2224a.f2264b = typedArray.getString(index);
                        if (auxVar.f2224a.f2264b.indexOf("/") > 0) {
                            auxVar.f2224a.f8135h = typedArray.getResourceId(index, -1);
                            auxVar.f2224a.f8134g = -2;
                        } else {
                            auxVar.f2224a.f8134g = -1;
                        }
                    } else {
                        C0030nul c0030nul9 = auxVar.f2224a;
                        c0030nul9.f8134g = typedArray.getInteger(index, c0030nul9.f8135h);
                    }
                    break;
                case lpt4.AppCompatTheme_panelMenuListTheme /* 87 */:
                    Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + f8083a.get(index));
                    break;
                case lpt4.AppCompatTheme_panelMenuListWidth /* 88 */:
                case lpt4.AppCompatTheme_popupMenuStyle /* 89 */:
                case lpt4.AppCompatTheme_popupWindowStyle /* 90 */:
                default:
                    Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + f8083a.get(index));
                    break;
                case lpt4.AppCompatTheme_radioButtonStyle /* 91 */:
                    con conVar54 = auxVar.f2223a;
                    conVar54.f8115n = p(typedArray, index, conVar54.f8115n);
                    break;
                case lpt4.AppCompatTheme_ratingBarStyle /* 92 */:
                    con conVar55 = auxVar.f2223a;
                    conVar55.f8116o = p(typedArray, index, conVar55.f8116o);
                    break;
                case lpt4.AppCompatTheme_ratingBarStyleIndicator /* 93 */:
                    con conVar56 = auxVar.f2223a;
                    conVar56.E = typedArray.getDimensionPixelSize(index, conVar56.E);
                    break;
                case lpt4.AppCompatTheme_ratingBarStyleSmall /* 94 */:
                    con conVar57 = auxVar.f2223a;
                    conVar57.L = typedArray.getDimensionPixelSize(index, conVar57.L);
                    break;
                case lpt4.AppCompatTheme_searchViewStyle /* 95 */:
                    q(auxVar.f2223a, typedArray, index, 0);
                    break;
                case lpt4.AppCompatTheme_seekBarStyle /* 96 */:
                    q(auxVar.f2223a, typedArray, index, 1);
                    break;
                case lpt4.AppCompatTheme_selectableItemBackground /* 97 */:
                    con conVar58 = auxVar.f2223a;
                    conVar58.X = typedArray.getInt(index, conVar58.X);
                    break;
            }
        }
        con conVar59 = auxVar.f2223a;
        if (conVar59.f2245b != null) {
            conVar59.f2243a = null;
        }
    }

    public final String v(int i2) {
        switch (i2) {
            case 1:
                return "left";
            case 2:
                return "right";
            case 3:
                return "top";
            case 4:
                return "bottom";
            case 5:
                return "baseline";
            case 6:
                return "start";
            case 7:
                return "end";
            default:
                return "undefined";
        }
    }
}
