package LPT2;

import inet.ipaddr.com4;
import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Pattern;
import p115lPT6.p3;

/* JADX INFO: loaded from: classes.dex */
public class nul implements Closeable, Flushable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Pattern f6616a = Pattern.compile("-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?");

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final String[] f847a = new String[128];

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String[] f6617b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Writer f849a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f850a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public String f852b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f853b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String f6618c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f854c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f6619d;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f851a = new int[32];

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f848a = 0;

    static {
        for (int i2 = 0; i2 <= 31; i2++) {
            f847a[i2] = String.format("\\u%04x", Integer.valueOf(i2));
        }
        String[] strArr = f847a;
        strArr[34] = "\\\"";
        strArr[92] = "\\\\";
        strArr[9] = "\\t";
        strArr[8] = "\\b";
        strArr[10] = "\\n";
        strArr[13] = "\\r";
        strArr[12] = "\\f";
        String[] strArr2 = (String[]) strArr.clone();
        f6617b = strArr2;
        strArr2[60] = "\\u003c";
        strArr2[62] = "\\u003e";
        strArr2[38] = "\\u0026";
        strArr2[61] = "\\u003d";
        strArr2[39] = "\\u0027";
    }

    public nul(Writer writer) {
        M(6);
        this.f852b = ":";
        this.f6619d = true;
        if (writer == null) {
            throw new NullPointerException("out == null");
        }
        this.f849a = writer;
    }

    public static boolean C(Class<? extends Number> cls) {
        return cls == Integer.class || cls == Long.class || cls == Double.class || cls == Float.class || cls == Byte.class || cls == Short.class || cls == BigDecimal.class || cls == BigInteger.class || cls == AtomicInteger.class || cls == AtomicLong.class;
    }

    public nul E(String str) throws IOException {
        if (str == null) {
            throw new NullPointerException("name == null");
        }
        if (this.f6618c != null) {
            throw new IllegalStateException();
        }
        if (this.f848a == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        this.f6618c = str;
        return this;
    }

    public final void F() throws IOException {
        if (this.f850a == null) {
            return;
        }
        this.f849a.write(10);
        int i2 = this.f848a;
        for (int i3 = 1; i3 < i2; i3++) {
            this.f849a.write(this.f850a);
        }
    }

    public nul G() throws IOException {
        if (this.f6618c != null) {
            if (!this.f6619d) {
                this.f6618c = null;
                return this;
            }
            e0();
        }
        c();
        this.f849a.write("null");
        return this;
    }

    public final nul H(int i2, char c2) throws IOException {
        c();
        M(i2);
        this.f849a.write(c2);
        return this;
    }

    public final int L() {
        int i2 = this.f848a;
        if (i2 != 0) {
            return this.f851a[i2 - 1];
        }
        throw new IllegalStateException("JsonWriter is closed.");
    }

    public final void M(int i2) {
        int i3 = this.f848a;
        int[] iArr = this.f851a;
        if (i3 == iArr.length) {
            this.f851a = Arrays.copyOf(iArr, i3 * 2);
        }
        int[] iArr2 = this.f851a;
        int i4 = this.f848a;
        this.f848a = i4 + 1;
        iArr2[i4] = i2;
    }

    public final void N(int i2) {
        this.f851a[this.f848a - 1] = i2;
    }

    public final void O(boolean z2) {
        this.f854c = z2;
    }

    public final void V(String str) {
        if (str.length() == 0) {
            this.f850a = null;
            this.f852b = ":";
        } else {
            this.f850a = str;
            this.f852b = ": ";
        }
    }

    public final void W(boolean z2) {
        this.f853b = z2;
    }

    public final void X(boolean z2) {
        this.f6619d = z2;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0034  */
    public final void Y(String str) throws IOException {
        String str2;
        String[] strArr = this.f854c ? f6617b : f847a;
        this.f849a.write(34);
        int length = str.length();
        int i2 = 0;
        for (int i3 = 0; i3 < length; i3++) {
            char cCharAt = str.charAt(i3);
            if (cCharAt < 128) {
                str2 = strArr[cCharAt];
                if (str2 != null) {
                    if (i2 < i3) {
                        this.f849a.write(str, i2, i3 - i2);
                    }
                    this.f849a.write(str2);
                    i2 = i3 + 1;
                }
            } else {
                if (cCharAt == 8232) {
                    str2 = "\\u2028";
                } else if (cCharAt == 8233) {
                    str2 = "\\u2029";
                }
                if (i2 < i3) {
                    this.f849a.write(str, i2, i3 - i2);
                }
                this.f849a.write(str2);
                i2 = i3 + 1;
            }
        }
        if (i2 < length) {
            this.f849a.write(str, i2, length - i2);
        }
        this.f849a.write(34);
    }

    public nul Z(long j2) throws IOException {
        e0();
        c();
        this.f849a.write(Long.toString(j2));
        return this;
    }

    public final void a() throws IOException {
        int iL = L();
        if (iL == 5) {
            this.f849a.write(44);
        } else if (iL != 3) {
            throw new IllegalStateException("Nesting problem.");
        }
        F();
        N(4);
    }

    public nul a0(Boolean bool) throws IOException {
        if (bool == null) {
            return G();
        }
        e0();
        c();
        this.f849a.write(bool.booleanValue() ? "true" : "false");
        return this;
    }

    public nul b0(Number number) throws IOException {
        if (number == null) {
            return G();
        }
        e0();
        String string = number.toString();
        if (!string.equals("-Infinity") && !string.equals("Infinity") && !string.equals("NaN")) {
            Class<?> cls = number.getClass();
            if (!C(cls) && !f6616a.matcher(string).matches()) {
                throw new IllegalArgumentException("String created by " + cls + " is not a valid JSON number: " + string);
            }
        } else if (!this.f853b) {
            throw new IllegalArgumentException("Numeric values must be finite, but was " + string);
        }
        c();
        this.f849a.append((CharSequence) string);
        return this;
    }

    public final void c() throws IOException {
        int iL = L();
        if (iL == 1) {
            N(2);
            F();
            return;
        }
        if (iL == 2) {
            this.f849a.append(p3.SEGMENT_VALUE_DELIMITER);
            F();
        } else {
            if (iL == 4) {
                this.f849a.append((CharSequence) this.f852b);
                N(5);
                return;
            }
            if (iL != 6) {
                if (iL != 7) {
                    throw new IllegalStateException("Nesting problem.");
                }
                if (!this.f853b) {
                    throw new IllegalStateException("JSON must have only one top-level value.");
                }
            }
            N(7);
        }
    }

    public nul c0(String str) throws IOException {
        if (str == null) {
            return G();
        }
        e0();
        c();
        Y(str);
        return this;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        this.f849a.close();
        int i2 = this.f848a;
        if (i2 > 1 || (i2 == 1 && this.f851a[i2 - 1] != 7)) {
            throw new IOException("Incomplete document");
        }
        this.f848a = 0;
    }

    public nul d() throws IOException {
        e0();
        return H(1, com4.IPV6_START_BRACKET);
    }

    public nul d0(boolean z2) throws IOException {
        e0();
        c();
        this.f849a.write(z2 ? "true" : "false");
        return this;
    }

    public final void e0() throws IOException {
        if (this.f6618c != null) {
            a();
            Y(this.f6618c);
            this.f6618c = null;
        }
    }

    public nul f() throws IOException {
        e0();
        return H(3, '{');
    }

    @Override // java.io.Flushable
    public void flush() throws IOException {
        if (this.f848a == 0) {
            throw new IllegalStateException("JsonWriter is closed.");
        }
        this.f849a.flush();
    }

    public final nul l(int i2, int i3, char c2) throws IOException {
        int iL = L();
        if (iL != i3 && iL != i2) {
            throw new IllegalStateException("Nesting problem.");
        }
        if (this.f6618c != null) {
            throw new IllegalStateException("Dangling name: " + this.f6618c);
        }
        this.f848a--;
        if (iL == i3) {
            F();
        }
        this.f849a.write(c2);
        return this;
    }

    public nul n() throws IOException {
        return l(1, 2, com4.IPV6_END_BRACKET);
    }

    public nul o() throws IOException {
        return l(3, 5, '}');
    }

    public final boolean p() {
        return this.f6619d;
    }

    public final boolean s() {
        return this.f854c;
    }

    public boolean y() {
        return this.f853b;
    }
}
