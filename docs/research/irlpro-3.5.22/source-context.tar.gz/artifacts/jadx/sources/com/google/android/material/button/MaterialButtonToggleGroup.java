package com.google.android.material.button;

import COM9.com7;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import p024Com2.i;
import p024Com2.lpt3;
import p024Com2.y;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p081cOm2.e2;
import p108com9.t;
import p108com9.v;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
public class MaterialButtonToggleGroup extends LinearLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f9382a = "MaterialButtonToggleGroup";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int f9383b = g4.f8976u;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f3386a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com1 f3387a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Comparator<MaterialButton> f3388a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinkedHashSet<prn> f3389a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<nul> f3390a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Set<Integer> f3391a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Integer[] f3392a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3393b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f9384c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f9385d;

    public class aux implements Comparator<MaterialButton> {
        public aux() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(MaterialButton materialButton, MaterialButton materialButton2) {
            int iCompareTo = Boolean.valueOf(materialButton.isChecked()).compareTo(Boolean.valueOf(materialButton2.isChecked()));
            if (iCompareTo != 0) {
                return iCompareTo;
            }
            int iCompareTo2 = Boolean.valueOf(materialButton.isPressed()).compareTo(Boolean.valueOf(materialButton2.isPressed()));
            return iCompareTo2 != 0 ? iCompareTo2 : Integer.valueOf(MaterialButtonToggleGroup.this.indexOfChild(materialButton)).compareTo(Integer.valueOf(MaterialButtonToggleGroup.this.indexOfChild(materialButton2)));
        }
    }

    public class com1 implements MaterialButton.con {
        public com1() {
        }

        @Override // com.google.android.material.button.MaterialButton.con
        public void a(MaterialButton materialButton, boolean z2) {
            MaterialButtonToggleGroup.this.invalidate();
        }

        public /* synthetic */ com1(MaterialButtonToggleGroup materialButtonToggleGroup, aux auxVar) {
            this();
        }
    }

    public class con extends lpt3 {
        public con() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.W(e2.nul.a(0, 1, MaterialButtonToggleGroup.this.j(view), 1, false, ((MaterialButton) view).isChecked()));
        }
    }

    public static class nul {

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public static final COM9.nul f9389e = new COM9.aux(0.0f);

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public COM9.nul f9390a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public COM9.nul f9391b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public COM9.nul f9392c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public COM9.nul f9393d;

        public nul(COM9.nul nulVar, COM9.nul nulVar2, COM9.nul nulVar3, COM9.nul nulVar4) {
            this.f9390a = nulVar;
            this.f9391b = nulVar3;
            this.f9392c = nulVar4;
            this.f9393d = nulVar2;
        }

        public static nul a(nul nulVar) {
            COM9.nul nulVar2 = f9389e;
            return new nul(nulVar2, nulVar.f9393d, nulVar2, nulVar.f9392c);
        }

        public static nul b(nul nulVar, View view) {
            return v.e(view) ? c(nulVar) : d(nulVar);
        }

        public static nul c(nul nulVar) {
            COM9.nul nulVar2 = nulVar.f9390a;
            COM9.nul nulVar3 = nulVar.f9393d;
            COM9.nul nulVar4 = f9389e;
            return new nul(nulVar2, nulVar3, nulVar4, nulVar4);
        }

        public static nul d(nul nulVar) {
            COM9.nul nulVar2 = f9389e;
            return new nul(nulVar2, nulVar2, nulVar.f9391b, nulVar.f9392c);
        }

        public static nul e(nul nulVar, View view) {
            return v.e(view) ? d(nulVar) : c(nulVar);
        }

        public static nul f(nul nulVar) {
            COM9.nul nulVar2 = nulVar.f9390a;
            COM9.nul nulVar3 = f9389e;
            return new nul(nulVar2, nulVar3, nulVar.f9391b, nulVar3);
        }
    }

    public interface prn {
        void a(MaterialButtonToggleGroup materialButtonToggleGroup, int i2, boolean z2);
    }

    public MaterialButtonToggleGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.f9046u);
    }

    private int getFirstVisibleChildIndex() {
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            if (l(i2)) {
                return i2;
            }
        }
        return -1;
    }

    private int getLastVisibleChildIndex() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            if (l(childCount)) {
                return childCount;
            }
        }
        return -1;
    }

    private int getVisibleButtonCount() {
        int i2 = 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            if ((getChildAt(i3) instanceof MaterialButton) && l(i3)) {
                i2++;
            }
        }
        return i2;
    }

    public static void q(com7.con conVar, nul nulVar) {
        if (nulVar == null) {
            conVar.o(0.0f);
        } else {
            conVar.B(nulVar.f9390a).t(nulVar.f9393d).F(nulVar.f9391b).x(nulVar.f9392c);
        }
    }

    private void setGeneratedIdIfNeeded(MaterialButton materialButton) {
        if (materialButton.getId() == -1) {
            materialButton.setId(y.j());
        }
    }

    private void setupButtonChild(MaterialButton materialButton) {
        materialButton.setMaxLines(1);
        materialButton.setEllipsize(TextUtils.TruncateAt.END);
        materialButton.setCheckable(true);
        materialButton.setOnPressedChangeListenerInternal(this.f3387a);
        materialButton.setShouldDrawSurfaceColorStroke(true);
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        if (!(view instanceof MaterialButton)) {
            Log.e(f9382a, "Child views must be of type MaterialButton.");
            return;
        }
        super.addView(view, i2, layoutParams);
        MaterialButton materialButton = (MaterialButton) view;
        setGeneratedIdIfNeeded(materialButton);
        setupButtonChild(materialButton);
        f(materialButton.getId(), materialButton.isChecked());
        com7 shapeAppearanceModel = materialButton.getShapeAppearanceModel();
        this.f3390a.add(new nul(shapeAppearanceModel.r(), shapeAppearanceModel.j(), shapeAppearanceModel.t(), shapeAppearanceModel.l()));
        y.o0(materialButton, new con());
    }

    public void b(prn prnVar) {
        this.f3389a.add(prnVar);
    }

    public final void c() {
        int firstVisibleChildIndex = getFirstVisibleChildIndex();
        if (firstVisibleChildIndex == -1) {
            return;
        }
        for (int i2 = firstVisibleChildIndex + 1; i2 < getChildCount(); i2++) {
            MaterialButton materialButtonI = i(i2);
            int iMin = Math.min(materialButtonI.getStrokeWidth(), i(i2 - 1).getStrokeWidth());
            LinearLayout.LayoutParams layoutParamsD = d(materialButtonI);
            if (getOrientation() == 0) {
                i.c(layoutParamsD, 0);
                i.d(layoutParamsD, -iMin);
                layoutParamsD.topMargin = 0;
            } else {
                layoutParamsD.bottomMargin = 0;
                layoutParamsD.topMargin = -iMin;
                i.d(layoutParamsD, 0);
            }
            materialButtonI.setLayoutParams(layoutParamsD);
        }
        o(firstVisibleChildIndex);
    }

    public final LinearLayout.LayoutParams d(View view) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        return layoutParams instanceof LinearLayout.LayoutParams ? (LinearLayout.LayoutParams) layoutParams : new LinearLayout.LayoutParams(layoutParams.width, layoutParams.height);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        s();
        super.dispatchDraw(canvas);
    }

    public void e(int i2) {
        f(i2, true);
    }

    public final void f(int i2, boolean z2) {
        if (i2 == -1) {
            Log.e(f9382a, "Button ID is not valid: " + i2);
            return;
        }
        HashSet hashSet = new HashSet(this.f3391a);
        if (z2 && !hashSet.contains(Integer.valueOf(i2))) {
            if (this.f9384c && !hashSet.isEmpty()) {
                hashSet.clear();
            }
            hashSet.add(Integer.valueOf(i2));
        } else {
            if (z2 || !hashSet.contains(Integer.valueOf(i2))) {
                return;
            }
            if (!this.f9385d || hashSet.size() > 1) {
                hashSet.remove(Integer.valueOf(i2));
            }
        }
        r(hashSet);
    }

    public void g() {
        r(new HashSet());
    }

    public int getCheckedButtonId() {
        if (!this.f9384c || this.f3391a.isEmpty()) {
            return -1;
        }
        return this.f3391a.iterator().next().intValue();
    }

    public List<Integer> getCheckedButtonIds() {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            int id = i(i2).getId();
            if (this.f3391a.contains(Integer.valueOf(id))) {
                arrayList.add(Integer.valueOf(id));
            }
        }
        return arrayList;
    }

    @Override // android.view.ViewGroup
    public int getChildDrawingOrder(int i2, int i3) {
        Integer[] numArr = this.f3392a;
        if (numArr != null && i3 < numArr.length) {
            return numArr[i3].intValue();
        }
        Log.w(f9382a, "Child order wasn't updated");
        return i3;
    }

    public final void h(int i2, boolean z2) {
        Iterator<prn> it = this.f3389a.iterator();
        while (it.hasNext()) {
            it.next().a(this, i2, z2);
        }
    }

    public final MaterialButton i(int i2) {
        return (MaterialButton) getChildAt(i2);
    }

    public final int j(View view) {
        if (!(view instanceof MaterialButton)) {
            return -1;
        }
        int i2 = 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            if (getChildAt(i3) == view) {
                return i2;
            }
            if ((getChildAt(i3) instanceof MaterialButton) && l(i3)) {
                i2++;
            }
        }
        return -1;
    }

    public final nul k(int i2, int i3, int i4) {
        nul nulVar = this.f3390a.get(i2);
        if (i3 == i4) {
            return nulVar;
        }
        boolean z2 = getOrientation() == 0;
        if (i2 == i3) {
            return z2 ? nul.e(nulVar, this) : nul.f(nulVar);
        }
        if (i2 == i4) {
            return z2 ? nul.b(nulVar, this) : nul.a(nulVar);
        }
        return null;
    }

    public final boolean l(int i2) {
        return getChildAt(i2).getVisibility() != 8;
    }

    public boolean m() {
        return this.f9384c;
    }

    public void n(MaterialButton materialButton, boolean z2) {
        if (this.f3393b) {
            return;
        }
        f(materialButton.getId(), z2);
    }

    public final void o(int i2) {
        if (getChildCount() == 0 || i2 == -1) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) i(i2).getLayoutParams();
        if (getOrientation() == 1) {
            layoutParams.topMargin = 0;
            layoutParams.bottomMargin = 0;
        } else {
            i.c(layoutParams, 0);
            i.d(layoutParams, 0);
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = 0;
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        int i2 = this.f3386a;
        if (i2 != -1) {
            r(Collections.singleton(Integer.valueOf(i2)));
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        e2.z0(accessibilityNodeInfo).V(e2.con.a(1, getVisibleButtonCount(), false, m() ? 1 : 2));
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        t();
        c();
        super.onMeasure(i2, i3);
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        if (view instanceof MaterialButton) {
            ((MaterialButton) view).setOnPressedChangeListenerInternal(null);
        }
        int iIndexOfChild = indexOfChild(view);
        if (iIndexOfChild >= 0) {
            this.f3390a.remove(iIndexOfChild);
        }
        t();
        c();
    }

    public final void p(int i2, boolean z2) {
        View viewFindViewById = findViewById(i2);
        if (viewFindViewById instanceof MaterialButton) {
            this.f3393b = true;
            ((MaterialButton) viewFindViewById).setChecked(z2);
            this.f3393b = false;
        }
    }

    public final void r(Set<Integer> set) {
        Set<Integer> set2 = this.f3391a;
        this.f3391a = new HashSet(set);
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            int id = i(i2).getId();
            p(id, set.contains(Integer.valueOf(id)));
            if (set2.contains(Integer.valueOf(id)) != set.contains(Integer.valueOf(id))) {
                h(id, set.contains(Integer.valueOf(id)));
            }
        }
        invalidate();
    }

    public final void s() {
        TreeMap treeMap = new TreeMap(this.f3388a);
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            treeMap.put(i(i2), Integer.valueOf(i2));
        }
        this.f3392a = (Integer[]) treeMap.values().toArray(new Integer[0]);
    }

    public void setSelectionRequired(boolean z2) {
        this.f9385d = z2;
    }

    public void setSingleSelection(boolean z2) {
        if (this.f9384c != z2) {
            this.f9384c = z2;
            g();
        }
    }

    public void t() {
        int childCount = getChildCount();
        int firstVisibleChildIndex = getFirstVisibleChildIndex();
        int lastVisibleChildIndex = getLastVisibleChildIndex();
        for (int i2 = 0; i2 < childCount; i2++) {
            MaterialButton materialButtonI = i(i2);
            if (materialButtonI.getVisibility() != 8) {
                com7.con conVarV = materialButtonI.getShapeAppearanceModel().v();
                q(conVarV, k(i2, firstVisibleChildIndex, lastVisibleChildIndex));
                materialButtonI.setShapeAppearanceModel(conVarV.m());
            }
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public MaterialButtonToggleGroup(Context context, AttributeSet attributeSet, int i2) {
        int i3 = f9383b;
        super(u.c(context, attributeSet, i2, i3), attributeSet, i2);
        this.f3390a = new ArrayList();
        this.f3387a = new com1(this, null);
        this.f3389a = new LinkedHashSet<>();
        this.f3388a = new aux();
        this.f3393b = false;
        this.f3391a = new HashSet();
        TypedArray typedArrayH = t.h(getContext(), attributeSet, h4.f3165t0, i2, i3, new int[0]);
        setSingleSelection(typedArrayH.getBoolean(h4.q1, false));
        this.f3386a = typedArrayH.getResourceId(h4.o1, -1);
        this.f9385d = typedArrayH.getBoolean(h4.p1, false);
        setChildrenDrawingOrderEnabled(true);
        typedArrayH.recycle();
        y.y0(this, 1);
    }

    public void setSingleSelection(int i2) {
        setSingleSelection(getResources().getBoolean(i2));
    }
}
