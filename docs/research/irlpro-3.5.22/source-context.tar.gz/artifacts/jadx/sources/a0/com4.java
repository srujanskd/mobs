package a0;

import f.com8;
import java.util.LinkedHashSet;
import java.util.Set;
import v.i;

/* JADX INFO: loaded from: classes.dex */
public final class com4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Set<i> f7612a = new LinkedHashSet();

    public final synchronized void a(i iVar) {
        com8.e(iVar, "route");
        this.f7612a.remove(iVar);
    }

    public final synchronized void b(i iVar) {
        com8.e(iVar, "failedRoute");
        this.f7612a.add(iVar);
    }

    public final synchronized boolean c(i iVar) {
        com8.e(iVar, "route");
        return this.f7612a.contains(iVar);
    }
}
