package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.preference.Preference;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class LinearLayoutManager extends RecyclerView.lpt2 implements RecyclerView.d.con {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux f8510a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final con f2688a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f2689a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f2690a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5 f2691a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f2692a;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8511f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8512g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f2693g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8513h;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public boolean f2694h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8514i;

    /* JADX INFO: renamed from: i, reason: collision with other field name */
    public boolean f2695i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f8515j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f8516k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f8517l;

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8518a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public com5 f2696a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2697a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8519b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2698b;

        public aux() {
            e();
        }

        public void a() {
            this.f8519b = this.f2697a ? this.f2696a.i() : this.f2696a.m();
        }

        public void b(View view, int i2) {
            if (this.f2697a) {
                this.f8519b = this.f2696a.d(view) + this.f2696a.o();
            } else {
                this.f8519b = this.f2696a.g(view);
            }
            this.f8518a = i2;
        }

        public void c(View view, int i2) {
            int iO = this.f2696a.o();
            if (iO >= 0) {
                b(view, i2);
                return;
            }
            this.f8518a = i2;
            if (this.f2697a) {
                int i3 = (this.f2696a.i() - iO) - this.f2696a.d(view);
                this.f8519b = this.f2696a.i() - i3;
                if (i3 > 0) {
                    int iE = this.f8519b - this.f2696a.e(view);
                    int iM = this.f2696a.m();
                    int iMin = iE - (iM + Math.min(this.f2696a.g(view) - iM, 0));
                    if (iMin < 0) {
                        this.f8519b += Math.min(i3, -iMin);
                        return;
                    }
                    return;
                }
                return;
            }
            int iG = this.f2696a.g(view);
            int iM2 = iG - this.f2696a.m();
            this.f8519b = iG;
            if (iM2 > 0) {
                int i4 = (this.f2696a.i() - Math.min(0, (this.f2696a.i() - iO) - this.f2696a.d(view))) - (iG + this.f2696a.e(view));
                if (i4 < 0) {
                    this.f8519b -= Math.min(iM2, -i4);
                }
            }
        }

        public boolean d(View view, RecyclerView.e eVar) {
            RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
            return !lpt3Var.c() && lpt3Var.a() >= 0 && lpt3Var.a() < eVar.b();
        }

        public void e() {
            this.f8518a = -1;
            this.f8519b = Integer.MIN_VALUE;
            this.f2697a = false;
            this.f2698b = false;
        }

        public String toString() {
            return "AnchorInfo{mPosition=" + this.f8518a + ", mCoordinate=" + this.f8519b + ", mLayoutFromEnd=" + this.f2697a + ", mValid=" + this.f2698b + '}';
        }
    }

    public static class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8520a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2699a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8521b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f8522c;

        public void a() {
            this.f8520a = 0;
            this.f2699a = false;
            this.f8521b = false;
            this.f8522c = false;
        }
    }

    public static class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8523a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8524b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8525c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2703c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8526d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8527e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f8528f;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public int f8531i;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2701a = true;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f8529g = 0;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f8530h = 0;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2702b = false;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public List<RecyclerView.h> f2700a = null;

        public void a() {
            b(null);
        }

        public void b(View view) {
            View viewF = f(view);
            if (viewF == null) {
                this.f8525c = -1;
            } else {
                this.f8525c = ((RecyclerView.lpt3) viewF.getLayoutParams()).a();
            }
        }

        public boolean c(RecyclerView.e eVar) {
            int i2 = this.f8525c;
            return i2 >= 0 && i2 < eVar.b();
        }

        public View d(RecyclerView.lpt9 lpt9Var) {
            if (this.f2700a != null) {
                return e();
            }
            View viewO = lpt9Var.o(this.f8525c);
            this.f8525c += this.f8526d;
            return viewO;
        }

        public final View e() {
            int size = this.f2700a.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = this.f2700a.get(i2).f2786a;
                RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view.getLayoutParams();
                if (!lpt3Var.c() && this.f8525c == lpt3Var.a()) {
                    b(view);
                    return view;
                }
            }
            return null;
        }

        public View f(View view) {
            int iA;
            int size = this.f2700a.size();
            View view2 = null;
            int i2 = Preference.DEFAULT_ORDER;
            for (int i3 = 0; i3 < size; i3++) {
                View view3 = this.f2700a.get(i3).f2786a;
                RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) view3.getLayoutParams();
                if (view3 != view && !lpt3Var.c() && (iA = (lpt3Var.a() - this.f8525c) * this.f8526d) >= 0 && iA < i2) {
                    view2 = view3;
                    if (iA == 0) {
                        break;
                    }
                    i2 = iA;
                }
            }
            return view2;
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class prn implements Parcelable {
        public static final Parcelable.Creator<prn> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8532a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8533b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2704b;

        public static class aux implements Parcelable.Creator<prn> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public prn createFromParcel(Parcel parcel) {
                return new prn(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public prn[] newArray(int i2) {
                return new prn[i2];
            }
        }

        public prn() {
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public boolean k() {
            return this.f8532a >= 0;
        }

        public void m() {
            this.f8532a = -1;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeInt(this.f8532a);
            parcel.writeInt(this.f8533b);
            parcel.writeInt(this.f2704b ? 1 : 0);
        }

        public prn(Parcel parcel) {
            this.f8532a = parcel.readInt();
            this.f8533b = parcel.readInt();
            this.f2704b = parcel.readInt() == 1;
        }

        public prn(prn prnVar) {
            this.f8532a = prnVar.f8532a;
            this.f8533b = prnVar.f8533b;
            this.f2704b = prnVar.f2704b;
        }
    }

    public LinearLayoutManager(Context context) {
        this(context, 1, false);
    }

    public final void A2() {
        if (this.f8511f == 1 || !q2()) {
            this.f2695i = this.f2694h;
        } else {
            this.f2695i = !this.f2694h;
        }
    }

    public int B2(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (J() == 0 || i2 == 0) {
            return 0;
        }
        T1();
        this.f2689a.f2701a = true;
        int i3 = i2 > 0 ? 1 : -1;
        int iAbs = Math.abs(i2);
        I2(i3, iAbs, true, eVar);
        nul nulVar = this.f2689a;
        int iU1 = nulVar.f8528f + U1(lpt9Var, nulVar, eVar, false);
        if (iU1 < 0) {
            return 0;
        }
        if (iAbs > iU1) {
            i2 = i3 * iU1;
        }
        this.f2691a.r(-i2);
        this.f2689a.f8531i = i2;
        return i2;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public View C(int i2) {
        int iJ = J();
        if (iJ == 0) {
            return null;
        }
        int iH0 = i2 - h0(I(0));
        if (iH0 >= 0 && iH0 < iJ) {
            View viewI = I(iH0);
            if (h0(viewI) == i2) {
                return viewI;
            }
        }
        return super.C(i2);
    }

    public void C2(int i2) {
        if (i2 != 0 && i2 != 1) {
            throw new IllegalArgumentException("invalid orientation:" + i2);
        }
        g(null);
        if (i2 != this.f8511f || this.f2691a == null) {
            com5 com5VarB = com5.b(this, i2);
            this.f2691a = com5VarB;
            this.f8510a.f2696a = com5VarB;
            this.f8511f = i2;
            t1();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public RecyclerView.lpt3 D() {
        return new RecyclerView.lpt3(-2, -2);
    }

    public void D2(boolean z2) {
        g(null);
        if (z2 == this.f2694h) {
            return;
        }
        this.f2694h = z2;
        t1();
    }

    public void E2(boolean z2) {
        g(null);
        if (this.f8515j == z2) {
            return;
        }
        this.f8515j = z2;
        t1();
    }

    public final boolean F2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, aux auxVar) {
        if (J() == 0) {
            return false;
        }
        View viewV = V();
        if (viewV != null && auxVar.d(viewV, eVar)) {
            auxVar.c(viewV, h0(viewV));
            return true;
        }
        if (this.f2693g != this.f8515j) {
            return false;
        }
        View viewI2 = auxVar.f2697a ? i2(lpt9Var, eVar) : j2(lpt9Var, eVar);
        if (viewI2 == null) {
            return false;
        }
        auxVar.b(viewI2, h0(viewI2));
        if (!eVar.e() && L1()) {
            if (this.f2691a.g(viewI2) >= this.f2691a.i() || this.f2691a.d(viewI2) < this.f2691a.m()) {
                auxVar.f8519b = auxVar.f2697a ? this.f2691a.i() : this.f2691a.m();
            }
        }
        return true;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean G1() {
        return (X() == 1073741824 || p0() == 1073741824 || !q0()) ? false : true;
    }

    public final boolean G2(RecyclerView.e eVar, aux auxVar) {
        int i2;
        if (!eVar.e() && (i2 = this.f8512g) != -1) {
            if (i2 >= 0 && i2 < eVar.b()) {
                auxVar.f8518a = this.f8512g;
                prn prnVar = this.f2690a;
                if (prnVar != null && prnVar.k()) {
                    boolean z2 = this.f2690a.f2704b;
                    auxVar.f2697a = z2;
                    if (z2) {
                        auxVar.f8519b = this.f2691a.i() - this.f2690a.f8533b;
                    } else {
                        auxVar.f8519b = this.f2691a.m() + this.f2690a.f8533b;
                    }
                    return true;
                }
                if (this.f8513h != Integer.MIN_VALUE) {
                    boolean z3 = this.f2695i;
                    auxVar.f2697a = z3;
                    if (z3) {
                        auxVar.f8519b = this.f2691a.i() - this.f8513h;
                    } else {
                        auxVar.f8519b = this.f2691a.m() + this.f8513h;
                    }
                    return true;
                }
                View viewC = C(this.f8512g);
                if (viewC == null) {
                    if (J() > 0) {
                        auxVar.f2697a = (this.f8512g < h0(I(0))) == this.f2695i;
                    }
                    auxVar.a();
                } else {
                    if (this.f2691a.e(viewC) > this.f2691a.n()) {
                        auxVar.a();
                        return true;
                    }
                    if (this.f2691a.g(viewC) - this.f2691a.m() < 0) {
                        auxVar.f8519b = this.f2691a.m();
                        auxVar.f2697a = false;
                        return true;
                    }
                    if (this.f2691a.i() - this.f2691a.d(viewC) < 0) {
                        auxVar.f8519b = this.f2691a.i();
                        auxVar.f2697a = true;
                        return true;
                    }
                    auxVar.f8519b = auxVar.f2697a ? this.f2691a.d(viewC) + this.f2691a.o() : this.f2691a.g(viewC);
                }
                return true;
            }
            this.f8512g = -1;
            this.f8513h = Integer.MIN_VALUE;
        }
        return false;
    }

    public final void H2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, aux auxVar) {
        if (G2(eVar, auxVar) || F2(lpt9Var, eVar, auxVar)) {
            return;
        }
        auxVar.a();
        auxVar.f8518a = this.f8515j ? eVar.b() - 1 : 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void I0(RecyclerView recyclerView, RecyclerView.lpt9 lpt9Var) {
        super.I0(recyclerView, lpt9Var);
        if (this.f8517l) {
            k1(lpt9Var);
            lpt9Var.c();
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void I1(RecyclerView recyclerView, RecyclerView.e eVar, int i2) {
        com3 com3Var = new com3(recyclerView.getContext());
        com3Var.p(i2);
        J1(com3Var);
    }

    public final void I2(int i2, int i3, boolean z2, RecyclerView.e eVar) {
        int iM;
        this.f2689a.f2703c = z2();
        this.f2689a.f8527e = i2;
        int[] iArr = this.f2692a;
        iArr[0] = 0;
        iArr[1] = 0;
        M1(eVar, iArr);
        int iMax = Math.max(0, this.f2692a[0]);
        int iMax2 = Math.max(0, this.f2692a[1]);
        boolean z3 = i2 == 1;
        nul nulVar = this.f2689a;
        int i4 = z3 ? iMax2 : iMax;
        nulVar.f8529g = i4;
        if (!z3) {
            iMax = iMax2;
        }
        nulVar.f8530h = iMax;
        if (z3) {
            nulVar.f8529g = i4 + this.f2691a.j();
            View viewM2 = m2();
            nul nulVar2 = this.f2689a;
            nulVar2.f8526d = this.f2695i ? -1 : 1;
            int iH0 = h0(viewM2);
            nul nulVar3 = this.f2689a;
            nulVar2.f8525c = iH0 + nulVar3.f8526d;
            nulVar3.f8523a = this.f2691a.d(viewM2);
            iM = this.f2691a.d(viewM2) - this.f2691a.i();
        } else {
            View viewN2 = n2();
            this.f2689a.f8529g += this.f2691a.m();
            nul nulVar4 = this.f2689a;
            nulVar4.f8526d = this.f2695i ? 1 : -1;
            int iH1 = h0(viewN2);
            nul nulVar5 = this.f2689a;
            nulVar4.f8525c = iH1 + nulVar5.f8526d;
            nulVar5.f8523a = this.f2691a.g(viewN2);
            iM = (-this.f2691a.g(viewN2)) + this.f2691a.m();
        }
        nul nulVar6 = this.f2689a;
        nulVar6.f8524b = i3;
        if (z2) {
            nulVar6.f8524b = i3 - iM;
        }
        nulVar6.f8528f = iM;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public View J0(View view, int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        int iR1;
        A2();
        if (J() == 0 || (iR1 = R1(i2)) == Integer.MIN_VALUE) {
            return null;
        }
        T1();
        I2(iR1, (int) (this.f2691a.n() * 0.33333334f), false, eVar);
        nul nulVar = this.f2689a;
        nulVar.f8528f = Integer.MIN_VALUE;
        nulVar.f2701a = false;
        U1(lpt9Var, nulVar, eVar, true);
        View viewG2 = iR1 == -1 ? g2() : f2();
        View viewN2 = iR1 == -1 ? n2() : m2();
        if (!viewN2.hasFocusable()) {
            return viewG2;
        }
        if (viewG2 == null) {
            return null;
        }
        return viewN2;
    }

    public final void J2(int i2, int i3) {
        this.f2689a.f8524b = this.f2691a.i() - i3;
        nul nulVar = this.f2689a;
        nulVar.f8526d = this.f2695i ? -1 : 1;
        nulVar.f8525c = i2;
        nulVar.f8527e = 1;
        nulVar.f8523a = i3;
        nulVar.f8528f = Integer.MIN_VALUE;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void K0(AccessibilityEvent accessibilityEvent) {
        super.K0(accessibilityEvent);
        if (J() > 0) {
            accessibilityEvent.setFromIndex(Z1());
            accessibilityEvent.setToIndex(c2());
        }
    }

    public final void K2(aux auxVar) {
        J2(auxVar.f8518a, auxVar.f8519b);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean L1() {
        return this.f2690a == null && this.f2693g == this.f8515j;
    }

    public final void L2(int i2, int i3) {
        this.f2689a.f8524b = i3 - this.f2691a.m();
        nul nulVar = this.f2689a;
        nulVar.f8525c = i2;
        nulVar.f8526d = this.f2695i ? 1 : -1;
        nulVar.f8527e = -1;
        nulVar.f8523a = i3;
        nulVar.f8528f = Integer.MIN_VALUE;
    }

    public void M1(RecyclerView.e eVar, int[] iArr) {
        int i2;
        int iO2 = o2(eVar);
        if (this.f2689a.f8527e == -1) {
            i2 = 0;
        } else {
            i2 = iO2;
            iO2 = 0;
        }
        iArr[0] = iO2;
        iArr[1] = i2;
    }

    public final void M2(aux auxVar) {
        L2(auxVar.f8518a, auxVar.f8519b);
    }

    public void N1(RecyclerView.e eVar, nul nulVar, RecyclerView.lpt2.nul nulVar2) {
        int i2 = nulVar.f8525c;
        if (i2 < 0 || i2 >= eVar.b()) {
            return;
        }
        nulVar2.a(i2, Math.max(0, nulVar.f8528f));
    }

    public final int O1(RecyclerView.e eVar) {
        if (J() == 0) {
            return 0;
        }
        T1();
        return com8.a(eVar, this.f2691a, Y1(!this.f8516k, true), X1(!this.f8516k, true), this, this.f8516k);
    }

    public final int P1(RecyclerView.e eVar) {
        if (J() == 0) {
            return 0;
        }
        T1();
        return com8.b(eVar, this.f2691a, Y1(!this.f8516k, true), X1(!this.f8516k, true), this, this.f8516k, this.f2695i);
    }

    public final int Q1(RecyclerView.e eVar) {
        if (J() == 0) {
            return 0;
        }
        T1();
        return com8.c(eVar, this.f2691a, Y1(!this.f8516k, true), X1(!this.f8516k, true), this, this.f8516k);
    }

    public int R1(int i2) {
        if (i2 == 1) {
            return (this.f8511f != 1 && q2()) ? 1 : -1;
        }
        if (i2 == 2) {
            return (this.f8511f != 1 && q2()) ? -1 : 1;
        }
        if (i2 == 17) {
            return this.f8511f == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i2 == 33) {
            return this.f8511f == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i2 != 66) {
            return (i2 == 130 && this.f8511f == 1) ? 1 : Integer.MIN_VALUE;
        }
        return this.f8511f == 0 ? 1 : Integer.MIN_VALUE;
    }

    public nul S1() {
        return new nul();
    }

    public void T1() {
        if (this.f2689a == null) {
            this.f2689a = S1();
        }
    }

    public int U1(RecyclerView.lpt9 lpt9Var, nul nulVar, RecyclerView.e eVar, boolean z2) {
        int i2 = nulVar.f8524b;
        int i3 = nulVar.f8528f;
        if (i3 != Integer.MIN_VALUE) {
            if (i2 < 0) {
                nulVar.f8528f = i3 + i2;
            }
            v2(lpt9Var, nulVar);
        }
        int i4 = nulVar.f8524b + nulVar.f8529g;
        con conVar = this.f2688a;
        while (true) {
            if ((!nulVar.f2703c && i4 <= 0) || !nulVar.c(eVar)) {
                break;
            }
            conVar.a();
            s2(lpt9Var, eVar, nulVar, conVar);
            if (!conVar.f2699a) {
                nulVar.f8523a += conVar.f8520a * nulVar.f8527e;
                if (!conVar.f8521b || nulVar.f2700a != null || !eVar.e()) {
                    int i5 = nulVar.f8524b;
                    int i6 = conVar.f8520a;
                    nulVar.f8524b = i5 - i6;
                    i4 -= i6;
                }
                int i7 = nulVar.f8528f;
                if (i7 != Integer.MIN_VALUE) {
                    int i8 = i7 + conVar.f8520a;
                    nulVar.f8528f = i8;
                    int i9 = nulVar.f8524b;
                    if (i9 < 0) {
                        nulVar.f8528f = i8 + i9;
                    }
                    v2(lpt9Var, nulVar);
                }
                if (z2 && conVar.f8522c) {
                    break;
                }
            } else {
                break;
            }
        }
        return i2 - nulVar.f8524b;
    }

    public final View V1() {
        return d2(0, J());
    }

    public final View W1(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return h2(lpt9Var, eVar, 0, J(), eVar.b());
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void X0(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        int i2;
        int i3;
        int i4;
        int i5;
        int iK2;
        int i6;
        View viewC;
        int iG;
        int i7;
        int i8 = -1;
        if (!(this.f2690a == null && this.f8512g == -1) && eVar.b() == 0) {
            k1(lpt9Var);
            return;
        }
        prn prnVar = this.f2690a;
        if (prnVar != null && prnVar.k()) {
            this.f8512g = this.f2690a.f8532a;
        }
        T1();
        this.f2689a.f2701a = false;
        A2();
        View viewV = V();
        aux auxVar = this.f8510a;
        if (!auxVar.f2698b || this.f8512g != -1 || this.f2690a != null) {
            auxVar.e();
            aux auxVar2 = this.f8510a;
            auxVar2.f2697a = this.f2695i ^ this.f8515j;
            H2(lpt9Var, eVar, auxVar2);
            this.f8510a.f2698b = true;
        } else if (viewV != null && (this.f2691a.g(viewV) >= this.f2691a.i() || this.f2691a.d(viewV) <= this.f2691a.m())) {
            this.f8510a.c(viewV, h0(viewV));
        }
        nul nulVar = this.f2689a;
        nulVar.f8527e = nulVar.f8531i >= 0 ? 1 : -1;
        int[] iArr = this.f2692a;
        iArr[0] = 0;
        iArr[1] = 0;
        M1(eVar, iArr);
        int iMax = Math.max(0, this.f2692a[0]) + this.f2691a.m();
        int iMax2 = Math.max(0, this.f2692a[1]) + this.f2691a.j();
        if (eVar.e() && (i6 = this.f8512g) != -1 && this.f8513h != Integer.MIN_VALUE && (viewC = C(i6)) != null) {
            if (this.f2695i) {
                i7 = this.f2691a.i() - this.f2691a.d(viewC);
                iG = this.f8513h;
            } else {
                iG = this.f2691a.g(viewC) - this.f2691a.m();
                i7 = this.f8513h;
            }
            int i9 = i7 - iG;
            if (i9 > 0) {
                iMax += i9;
            } else {
                iMax2 -= i9;
            }
        }
        aux auxVar3 = this.f8510a;
        if (!auxVar3.f2697a ? !this.f2695i : this.f2695i) {
            i8 = 1;
        }
        u2(lpt9Var, eVar, auxVar3, i8);
        w(lpt9Var);
        this.f2689a.f2703c = z2();
        this.f2689a.f2702b = eVar.e();
        this.f2689a.f8530h = 0;
        aux auxVar4 = this.f8510a;
        if (auxVar4.f2697a) {
            M2(auxVar4);
            nul nulVar2 = this.f2689a;
            nulVar2.f8529g = iMax;
            U1(lpt9Var, nulVar2, eVar, false);
            nul nulVar3 = this.f2689a;
            i3 = nulVar3.f8523a;
            int i10 = nulVar3.f8525c;
            int i11 = nulVar3.f8524b;
            if (i11 > 0) {
                iMax2 += i11;
            }
            K2(this.f8510a);
            nul nulVar4 = this.f2689a;
            nulVar4.f8529g = iMax2;
            nulVar4.f8525c += nulVar4.f8526d;
            U1(lpt9Var, nulVar4, eVar, false);
            nul nulVar5 = this.f2689a;
            i2 = nulVar5.f8523a;
            int i12 = nulVar5.f8524b;
            if (i12 > 0) {
                L2(i10, i3);
                nul nulVar6 = this.f2689a;
                nulVar6.f8529g = i12;
                U1(lpt9Var, nulVar6, eVar, false);
                i3 = this.f2689a.f8523a;
            }
        } else {
            K2(auxVar4);
            nul nulVar7 = this.f2689a;
            nulVar7.f8529g = iMax2;
            U1(lpt9Var, nulVar7, eVar, false);
            nul nulVar8 = this.f2689a;
            i2 = nulVar8.f8523a;
            int i13 = nulVar8.f8525c;
            int i14 = nulVar8.f8524b;
            if (i14 > 0) {
                iMax += i14;
            }
            M2(this.f8510a);
            nul nulVar9 = this.f2689a;
            nulVar9.f8529g = iMax;
            nulVar9.f8525c += nulVar9.f8526d;
            U1(lpt9Var, nulVar9, eVar, false);
            nul nulVar10 = this.f2689a;
            i3 = nulVar10.f8523a;
            int i15 = nulVar10.f8524b;
            if (i15 > 0) {
                J2(i13, i2);
                nul nulVar11 = this.f2689a;
                nulVar11.f8529g = i15;
                U1(lpt9Var, nulVar11, eVar, false);
                i2 = this.f2689a.f8523a;
            }
        }
        if (J() > 0) {
            if (this.f2695i ^ this.f8515j) {
                int iK3 = k2(i2, lpt9Var, eVar, true);
                i4 = i3 + iK3;
                i5 = i2 + iK3;
                iK2 = l2(i4, lpt9Var, eVar, false);
            } else {
                int iL2 = l2(i3, lpt9Var, eVar, true);
                i4 = i3 + iL2;
                i5 = i2 + iL2;
                iK2 = k2(i5, lpt9Var, eVar, false);
            }
            i3 = i4 + iK2;
            i2 = i5 + iK2;
        }
        t2(lpt9Var, eVar, i3, i2);
        if (eVar.e()) {
            this.f8510a.e();
        } else {
            this.f2691a.s();
        }
        this.f2693g = this.f8515j;
    }

    public View X1(boolean z2, boolean z3) {
        return this.f2695i ? e2(0, J(), z2, z3) : e2(J() - 1, -1, z2, z3);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void Y0(RecyclerView.e eVar) {
        super.Y0(eVar);
        this.f2690a = null;
        this.f8512g = -1;
        this.f8513h = Integer.MIN_VALUE;
        this.f8510a.e();
    }

    public View Y1(boolean z2, boolean z3) {
        return this.f2695i ? e2(J() - 1, -1, z2, z3) : e2(0, J(), z2, z3);
    }

    public int Z1() {
        View viewE2 = e2(0, J(), false, true);
        if (viewE2 == null) {
            return -1;
        }
        return h0(viewE2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.d.con
    public PointF a(int i2) {
        if (J() == 0) {
            return null;
        }
        int i3 = (i2 < h0(I(0))) != this.f2695i ? -1 : 1;
        return this.f8511f == 0 ? new PointF(i3, 0.0f) : new PointF(0.0f, i3);
    }

    public final View a2() {
        return d2(J() - 1, -1);
    }

    public final View b2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return h2(lpt9Var, eVar, J() - 1, -1, eVar.b());
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void c1(Parcelable parcelable) {
        if (parcelable instanceof prn) {
            this.f2690a = (prn) parcelable;
            t1();
        }
    }

    public int c2() {
        View viewE2 = e2(J() - 1, -1, false, true);
        if (viewE2 == null) {
            return -1;
        }
        return h0(viewE2);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public Parcelable d1() {
        if (this.f2690a != null) {
            return new prn(this.f2690a);
        }
        prn prnVar = new prn();
        if (J() > 0) {
            T1();
            boolean z2 = this.f2693g ^ this.f2695i;
            prnVar.f2704b = z2;
            if (z2) {
                View viewM2 = m2();
                prnVar.f8533b = this.f2691a.i() - this.f2691a.d(viewM2);
                prnVar.f8532a = h0(viewM2);
            } else {
                View viewN2 = n2();
                prnVar.f8532a = h0(viewN2);
                prnVar.f8533b = this.f2691a.g(viewN2) - this.f2691a.m();
            }
        } else {
            prnVar.m();
        }
        return prnVar;
    }

    public View d2(int i2, int i3) {
        byte b2;
        int i4;
        int i5;
        T1();
        if (i3 > i2) {
            b2 = 1;
        } else {
            b2 = i3 < i2 ? (byte) -1 : (byte) 0;
        }
        if (b2 == 0) {
            return I(i2);
        }
        if (this.f2691a.g(I(i2)) < this.f2691a.m()) {
            i4 = 16644;
            i5 = 16388;
        } else {
            i4 = 4161;
            i5 = 4097;
        }
        return this.f8511f == 0 ? ((RecyclerView.lpt2) this).f2800a.a(i2, i3, i4, i5) : ((RecyclerView.lpt2) this).f2803b.a(i2, i3, i4, i5);
    }

    public View e2(int i2, int i3, boolean z2, boolean z3) {
        T1();
        int i4 = z2 ? 24579 : 320;
        int i5 = z3 ? 320 : 0;
        return this.f8511f == 0 ? ((RecyclerView.lpt2) this).f2800a.a(i2, i3, i4, i5) : ((RecyclerView.lpt2) this).f2803b.a(i2, i3, i4, i5);
    }

    public final View f2() {
        return this.f2695i ? V1() : a2();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void g(String str) {
        if (this.f2690a == null) {
            super.g(str);
        }
    }

    public final View g2() {
        return this.f2695i ? a2() : V1();
    }

    public View h2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2, int i3, int i4) {
        T1();
        int iM = this.f2691a.m();
        int i5 = this.f2691a.i();
        int i6 = i3 > i2 ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i2 != i3) {
            View viewI = I(i2);
            int iH0 = h0(viewI);
            if (iH0 >= 0 && iH0 < i4) {
                if (((RecyclerView.lpt3) viewI.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = viewI;
                    }
                } else {
                    if (this.f2691a.g(viewI) < i5 && this.f2691a.d(viewI) >= iM) {
                        return viewI;
                    }
                    if (view == null) {
                        view = viewI;
                    }
                }
            }
            i2 += i6;
        }
        return view != null ? view : view2;
    }

    public final View i2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return this.f2695i ? W1(lpt9Var, eVar) : b2(lpt9Var, eVar);
    }

    public final View j2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        return this.f2695i ? b2(lpt9Var, eVar) : W1(lpt9Var, eVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean k() {
        return this.f8511f == 0;
    }

    public final int k2(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, boolean z2) {
        int i3;
        int i4 = this.f2691a.i() - i2;
        if (i4 <= 0) {
            return 0;
        }
        int i5 = -B2(-i4, lpt9Var, eVar);
        int i6 = i2 + i5;
        if (!z2 || (i3 = this.f2691a.i() - i6) <= 0) {
            return i5;
        }
        this.f2691a.r(i3);
        return i3 + i5;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean l() {
        return this.f8511f == 1;
    }

    public final int l2(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, boolean z2) {
        int iM;
        int iM2 = i2 - this.f2691a.m();
        if (iM2 <= 0) {
            return 0;
        }
        int i3 = -B2(iM2, lpt9Var, eVar);
        int i4 = i2 + i3;
        if (!z2 || (iM = i4 - this.f2691a.m()) <= 0) {
            return i3;
        }
        this.f2691a.r(-iM);
        return i3 - iM;
    }

    public final View m2() {
        return I(this.f2695i ? 0 : J() - 1);
    }

    public final View n2() {
        return I(this.f2695i ? J() - 1 : 0);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void o(int i2, int i3, RecyclerView.e eVar, RecyclerView.lpt2.nul nulVar) {
        if (this.f8511f != 0) {
            i2 = i3;
        }
        if (J() == 0 || i2 == 0) {
            return;
        }
        T1();
        I2(i2 > 0 ? 1 : -1, Math.abs(i2), true, eVar);
        N1(eVar, this.f2689a, nulVar);
    }

    @Deprecated
    public int o2(RecyclerView.e eVar) {
        if (eVar.d()) {
            return this.f2691a.n();
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void p(int i2, RecyclerView.lpt2.nul nulVar) {
        boolean z2;
        int i3;
        prn prnVar = this.f2690a;
        if (prnVar == null || !prnVar.k()) {
            A2();
            z2 = this.f2695i;
            i3 = this.f8512g;
            if (i3 == -1) {
                i3 = z2 ? i2 - 1 : 0;
            }
        } else {
            prn prnVar2 = this.f2690a;
            z2 = prnVar2.f2704b;
            i3 = prnVar2.f8532a;
        }
        int i4 = z2 ? -1 : 1;
        for (int i5 = 0; i5 < this.f8514i && i3 >= 0 && i3 < i2; i5++) {
            nulVar.a(i3, 0);
            i3 += i4;
        }
    }

    public int p2() {
        return this.f8511f;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int q(RecyclerView.e eVar) {
        return O1(eVar);
    }

    public boolean q2() {
        return Z() == 1;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int r(RecyclerView.e eVar) {
        return P1(eVar);
    }

    public boolean r2() {
        return this.f8516k;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int s(RecyclerView.e eVar) {
        return Q1(eVar);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public boolean s0() {
        return true;
    }

    public void s2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, nul nulVar, con conVar) {
        int i2;
        int i3;
        int i4;
        int iE0;
        int iF;
        View viewD = nulVar.d(lpt9Var);
        if (viewD == null) {
            conVar.f2699a = true;
            return;
        }
        RecyclerView.lpt3 lpt3Var = (RecyclerView.lpt3) viewD.getLayoutParams();
        if (nulVar.f2700a == null) {
            if (this.f2695i == (nulVar.f8527e == -1)) {
                d(viewD);
            } else {
                e(viewD, 0);
            }
        } else {
            if (this.f2695i == (nulVar.f8527e == -1)) {
                b(viewD);
            } else {
                c(viewD, 0);
            }
        }
        A0(viewD, 0, 0);
        conVar.f8520a = this.f2691a.e(viewD);
        if (this.f8511f == 1) {
            if (q2()) {
                iF = o0() - f0();
                iE0 = iF - this.f2691a.f(viewD);
            } else {
                iE0 = e0();
                iF = this.f2691a.f(viewD) + iE0;
            }
            if (nulVar.f8527e == -1) {
                int i5 = nulVar.f8523a;
                i4 = i5;
                i3 = iF;
                i2 = i5 - conVar.f8520a;
            } else {
                int i6 = nulVar.f8523a;
                i2 = i6;
                i3 = iF;
                i4 = conVar.f8520a + i6;
            }
        } else {
            int iG0 = g0();
            int iF2 = this.f2691a.f(viewD) + iG0;
            if (nulVar.f8527e == -1) {
                int i7 = nulVar.f8523a;
                i3 = i7;
                i2 = iG0;
                i4 = iF2;
                iE0 = i7 - conVar.f8520a;
            } else {
                int i8 = nulVar.f8523a;
                i2 = iG0;
                i3 = conVar.f8520a + i8;
                i4 = iF2;
                iE0 = i8;
            }
        }
        z0(viewD, iE0, i2, i3, i4);
        if (lpt3Var.c() || lpt3Var.b()) {
            conVar.f8521b = true;
        }
        conVar.f8522c = viewD.hasFocusable();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int t(RecyclerView.e eVar) {
        return O1(eVar);
    }

    public final void t2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, int i2, int i3) {
        if (!eVar.g() || J() == 0 || eVar.e() || !L1()) {
            return;
        }
        List<RecyclerView.h> listK = lpt9Var.k();
        int size = listK.size();
        int iH0 = h0(I(0));
        int iE = 0;
        int iE2 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            RecyclerView.h hVar = listK.get(i4);
            if (!hVar.v()) {
                if (((hVar.m() < iH0) != this.f2695i ? (byte) -1 : (byte) 1) == -1) {
                    iE += this.f2691a.e(hVar.f2786a);
                } else {
                    iE2 += this.f2691a.e(hVar.f2786a);
                }
            }
        }
        this.f2689a.f2700a = listK;
        if (iE > 0) {
            L2(h0(n2()), i2);
            nul nulVar = this.f2689a;
            nulVar.f8529g = iE;
            nulVar.f8524b = 0;
            nulVar.a();
            U1(lpt9Var, this.f2689a, eVar, false);
        }
        if (iE2 > 0) {
            J2(h0(m2()), i3);
            nul nulVar2 = this.f2689a;
            nulVar2.f8529g = iE2;
            nulVar2.f8524b = 0;
            nulVar2.a();
            U1(lpt9Var, this.f2689a, eVar, false);
        }
        this.f2689a.f2700a = null;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int u(RecyclerView.e eVar) {
        return P1(eVar);
    }

    public void u2(RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar, aux auxVar, int i2) {
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int v(RecyclerView.e eVar) {
        return Q1(eVar);
    }

    public final void v2(RecyclerView.lpt9 lpt9Var, nul nulVar) {
        if (!nulVar.f2701a || nulVar.f2703c) {
            return;
        }
        int i2 = nulVar.f8528f;
        int i3 = nulVar.f8530h;
        if (nulVar.f8527e == -1) {
            x2(lpt9Var, i2, i3);
        } else {
            y2(lpt9Var, i2, i3);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int w1(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (this.f8511f == 1) {
            return 0;
        }
        return B2(i2, lpt9Var, eVar);
    }

    public final void w2(RecyclerView.lpt9 lpt9Var, int i2, int i3) {
        if (i2 == i3) {
            return;
        }
        if (i3 <= i2) {
            while (i2 > i3) {
                n1(i2, lpt9Var);
                i2--;
            }
        } else {
            for (int i4 = i3 - 1; i4 >= i2; i4--) {
                n1(i4, lpt9Var);
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public void x1(int i2) {
        this.f8512g = i2;
        this.f8513h = Integer.MIN_VALUE;
        prn prnVar = this.f2690a;
        if (prnVar != null) {
            prnVar.m();
        }
        t1();
    }

    public final void x2(RecyclerView.lpt9 lpt9Var, int i2, int i3) {
        int iJ = J();
        if (i2 < 0) {
            return;
        }
        int iH = (this.f2691a.h() - i2) + i3;
        if (this.f2695i) {
            for (int i4 = 0; i4 < iJ; i4++) {
                View viewI = I(i4);
                if (this.f2691a.g(viewI) < iH || this.f2691a.q(viewI) < iH) {
                    w2(lpt9Var, 0, i4);
                    return;
                }
            }
            return;
        }
        int i5 = iJ - 1;
        for (int i6 = i5; i6 >= 0; i6--) {
            View viewI2 = I(i6);
            if (this.f2691a.g(viewI2) < iH || this.f2691a.q(viewI2) < iH) {
                w2(lpt9Var, i5, i6);
                return;
            }
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt2
    public int y1(int i2, RecyclerView.lpt9 lpt9Var, RecyclerView.e eVar) {
        if (this.f8511f == 0) {
            return 0;
        }
        return B2(i2, lpt9Var, eVar);
    }

    public final void y2(RecyclerView.lpt9 lpt9Var, int i2, int i3) {
        if (i2 < 0) {
            return;
        }
        int i4 = i2 - i3;
        int iJ = J();
        if (!this.f2695i) {
            for (int i5 = 0; i5 < iJ; i5++) {
                View viewI = I(i5);
                if (this.f2691a.d(viewI) > i4 || this.f2691a.p(viewI) > i4) {
                    w2(lpt9Var, 0, i5);
                    return;
                }
            }
            return;
        }
        int i6 = iJ - 1;
        for (int i7 = i6; i7 >= 0; i7--) {
            View viewI2 = I(i7);
            if (this.f2691a.d(viewI2) > i4 || this.f2691a.p(viewI2) > i4) {
                w2(lpt9Var, i6, i7);
                return;
            }
        }
    }

    public boolean z2() {
        return this.f2691a.k() == 0 && this.f2691a.h() == 0;
    }

    public LinearLayoutManager(Context context, int i2, boolean z2) {
        this.f8511f = 1;
        this.f2694h = false;
        this.f2695i = false;
        this.f8515j = false;
        this.f8516k = true;
        this.f8512g = -1;
        this.f8513h = Integer.MIN_VALUE;
        this.f2690a = null;
        this.f8510a = new aux();
        this.f2688a = new con();
        this.f8514i = 2;
        this.f2692a = new int[2];
        C2(i2);
        D2(z2);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f8511f = 1;
        this.f2694h = false;
        this.f2695i = false;
        this.f8515j = false;
        this.f8516k = true;
        this.f8512g = -1;
        this.f8513h = Integer.MIN_VALUE;
        this.f2690a = null;
        this.f8510a = new aux();
        this.f2688a = new con();
        this.f8514i = 2;
        this.f2692a = new int[2];
        RecyclerView.lpt2.prn prnVarI0 = RecyclerView.lpt2.i0(context, attributeSet, i2, i3);
        C2(prnVarI0.f8608a);
        D2(prnVarI0.f2808a);
        E2(prnVarI0.f2809b);
    }
}
