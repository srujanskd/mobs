package LPT6;

import inet.ipaddr.lpt9;
import java.io.Serializable;
import java.math.BigInteger;

/* JADX INFO: loaded from: classes.dex */
public interface com3 extends Comparable<com3>, Serializable {
    default boolean containsPrefixBlock(int i2) {
        if (i2 == 0) {
            return isFullRange();
        }
        BigInteger upperValue = getUpperValue();
        return inet.ipaddr.format.aux.testRange(getValue(), upperValue, upperValue, getBitCount(), i2);
    }

    default boolean containsSinglePrefixBlock(int i2) {
        if (i2 == 0) {
            return isFullRange();
        }
        BigInteger value = getValue();
        return inet.ipaddr.format.aux.testRange(value, value, getUpperValue(), getBitCount(), i2);
    }

    int getBitCount();

    default int getByteCount() {
        return (getBitCount() + 7) >>> 3;
    }

    byte[] getBytes();

    byte[] getBytes(byte[] bArr);

    byte[] getBytes(byte[] bArr, int i2);

    default BigInteger getCount() {
        return getUpperValue().subtract(getValue()).add(BigInteger.ONE);
    }

    default int getMinPrefixLengthForBlock() {
        int iNumberOfTrailingZeros;
        int bitCount = getBitCount();
        BigInteger value = getValue();
        BigInteger upperValue = getUpperValue();
        if (!value.equals(upperValue)) {
            do {
                int iNumberOfTrailingZeros2 = Long.numberOfTrailingZeros(value.longValue());
                if (iNumberOfTrailingZeros2 == 0 || (iNumberOfTrailingZeros = Long.numberOfTrailingZeros(~upperValue.longValue())) == 0) {
                    break;
                }
                int iMin = Math.min(iNumberOfTrailingZeros2, iNumberOfTrailingZeros);
                bitCount -= iMin;
                if (iMin < 64) {
                    break;
                }
                value = value.shiftRight(64);
                upperValue = upperValue.shiftRight(64);
            } while (!upperValue.equals(BigInteger.ZERO));
        }
        return bitCount;
    }

    default BigInteger getPrefixCount(int i2) {
        if (i2 < 0) {
            throw new lpt9(this, i2);
        }
        int bitCount = getBitCount();
        if (bitCount <= i2) {
            return getCount();
        }
        int i3 = bitCount - i2;
        return getUpperValue().shiftRight(i3).subtract(getValue().shiftRight(i3)).add(BigInteger.ONE);
    }

    default Integer getPrefixLengthForSingleBlock() {
        int minPrefixLengthForBlock = getMinPrefixLengthForBlock();
        BigInteger value = getValue();
        BigInteger upperValue = getUpperValue();
        int bitCount = getBitCount();
        if (minPrefixLengthForBlock == bitCount) {
            if (value.equals(upperValue)) {
                return inet.ipaddr.format.con.cacheBits(minPrefixLengthForBlock);
            }
            return null;
        }
        int i2 = bitCount - minPrefixLengthForBlock;
        if (value.shiftRight(i2).equals(upperValue.shiftRight(i2))) {
            return inet.ipaddr.format.con.cacheBits(minPrefixLengthForBlock);
        }
        return null;
    }

    byte[] getUpperBytes();

    byte[] getUpperBytes(byte[] bArr);

    byte[] getUpperBytes(byte[] bArr, int i2);

    BigInteger getUpperValue();

    BigInteger getValue();

    boolean includesMax();

    boolean includesZero();

    default boolean isFullRange() {
        return includesZero() && includesMax();
    }

    boolean isMax();

    default boolean isMultiple() {
        return !getCount().equals(BigInteger.ONE);
    }

    boolean isZero();

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.lang.Comparable
    default int compareTo(com3 com3Var) {
        return inet.ipaddr.aux.DEFAULT_ADDRESS_COMPARATOR.compare(this, com3Var);
    }
}
