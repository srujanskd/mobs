package androidx.viewpager2.adapter;

import COM3.com7;
import android.os.Handler;
import androidx.lifecycle.nul;
import androidx.lifecycle.prn;

/* JADX INFO: loaded from: classes.dex */
class FragmentStateAdapter$5 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Handler f8776a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final /* synthetic */ Runnable f2973a;

    @Override // androidx.lifecycle.prn
    public void f(com7 com7Var, nul.con conVar) {
        if (conVar == nul.con.ON_DESTROY) {
            this.f8776a.removeCallbacks(this.f2973a);
            com7Var.getLifecycle().c(this);
        }
    }
}
