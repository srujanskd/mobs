package LPT1;

/* JADX INFO: loaded from: classes.dex */
public final class com8 extends com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final com8 f6581a = new com8();

    @Deprecated
    public com8() {
    }

    public boolean equals(Object obj) {
        return this == obj || (obj instanceof com8);
    }

    public int hashCode() {
        return com8.class.hashCode();
    }
}
