package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import p151pRn.h0;

/* JADX INFO: loaded from: classes.dex */
public class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f8068a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2200a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f2201a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public String f2202a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2203a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8069b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public String f2204b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2205b;

    /* JADX INFO: renamed from: androidx.constraintlayout.widget.aux$aux, reason: collision with other inner class name */
    public static /* synthetic */ class C0028aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8070a;

        static {
            int[] iArr = new int[con.values().length];
            f8070a = iArr;
            try {
                iArr[con.REFERENCE_TYPE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8070a[con.BOOLEAN_TYPE.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8070a[con.STRING_TYPE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f8070a[con.COLOR_TYPE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f8070a[con.COLOR_DRAWABLE_TYPE.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f8070a[con.INT_TYPE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f8070a[con.FLOAT_TYPE.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f8070a[con.DIMENSION_TYPE.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
        }
    }

    public enum con {
        INT_TYPE,
        FLOAT_TYPE,
        COLOR_TYPE,
        COLOR_DRAWABLE_TYPE,
        STRING_TYPE,
        BOOLEAN_TYPE,
        DIMENSION_TYPE,
        REFERENCE_TYPE
    }

    public aux(String str, con conVar, Object obj, boolean z2) {
        this.f2202a = str;
        this.f2201a = conVar;
        this.f2203a = z2;
        f(obj);
    }

    public static HashMap<String, aux> a(HashMap<String, aux> map, View view) {
        HashMap<String, aux> map2 = new HashMap<>();
        Class<?> cls = view.getClass();
        for (String str : map.keySet()) {
            aux auxVar = map.get(str);
            try {
                if (str.equals("BackgroundColor")) {
                    map2.put(str, new aux(auxVar, Integer.valueOf(((ColorDrawable) view.getBackground()).getColor())));
                } else {
                    map2.put(str, new aux(auxVar, cls.getMethod("getMap" + str, new Class[0]).invoke(view, new Object[0])));
                }
            } catch (IllegalAccessException e2) {
                e2.printStackTrace();
            } catch (NoSuchMethodException e3) {
                e3.printStackTrace();
            } catch (InvocationTargetException e4) {
                e4.printStackTrace();
            }
        }
        return map2;
    }

    public static void d(Context context, XmlPullParser xmlPullParser, HashMap<String, aux> map) {
        con conVar;
        Object objValueOf;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), h0.f5234z);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        String string = null;
        Object objValueOf2 = null;
        con conVar2 = null;
        boolean z2 = false;
        for (int i2 = 0; i2 < indexCount; i2++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i2);
            if (index == h0.Z3) {
                string = typedArrayObtainStyledAttributes.getString(index);
                if (string != null && string.length() > 0) {
                    string = Character.toUpperCase(string.charAt(0)) + string.substring(1);
                }
            } else if (index == h0.j4) {
                string = typedArrayObtainStyledAttributes.getString(index);
                z2 = true;
            } else if (index == h0.a4) {
                objValueOf2 = Boolean.valueOf(typedArrayObtainStyledAttributes.getBoolean(index, false));
                conVar2 = con.BOOLEAN_TYPE;
            } else {
                if (index == h0.c4) {
                    conVar = con.COLOR_TYPE;
                    objValueOf = Integer.valueOf(typedArrayObtainStyledAttributes.getColor(index, 0));
                } else if (index == h0.b4) {
                    conVar = con.COLOR_DRAWABLE_TYPE;
                    objValueOf = Integer.valueOf(typedArrayObtainStyledAttributes.getColor(index, 0));
                } else if (index == h0.g4) {
                    conVar = con.DIMENSION_TYPE;
                    objValueOf = Float.valueOf(TypedValue.applyDimension(1, typedArrayObtainStyledAttributes.getDimension(index, 0.0f), context.getResources().getDisplayMetrics()));
                } else if (index == h0.d4) {
                    conVar = con.DIMENSION_TYPE;
                    objValueOf = Float.valueOf(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == h0.e4) {
                    conVar = con.FLOAT_TYPE;
                    objValueOf = Float.valueOf(typedArrayObtainStyledAttributes.getFloat(index, Float.NaN));
                } else if (index == h0.f4) {
                    conVar = con.INT_TYPE;
                    objValueOf = Integer.valueOf(typedArrayObtainStyledAttributes.getInteger(index, -1));
                } else if (index == h0.i4) {
                    conVar = con.STRING_TYPE;
                    objValueOf = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == h0.h4) {
                    conVar = con.REFERENCE_TYPE;
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                    if (resourceId == -1) {
                        resourceId = typedArrayObtainStyledAttributes.getInt(index, -1);
                    }
                    objValueOf = Integer.valueOf(resourceId);
                }
                Object obj = objValueOf;
                conVar2 = conVar;
                objValueOf2 = obj;
            }
        }
        if (string != null && objValueOf2 != null) {
            map.put(string, new aux(string, conVar2, objValueOf2, z2));
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public static void e(View view, HashMap<String, aux> map) {
        Class<?> cls = view.getClass();
        for (String str : map.keySet()) {
            aux auxVar = map.get(str);
            String str2 = auxVar.f2203a ? str : "set" + str;
            try {
                switch (C0028aux.f8070a[auxVar.f2201a.ordinal()]) {
                    case 1:
                        cls.getMethod(str2, Integer.TYPE).invoke(view, Integer.valueOf(auxVar.f2200a));
                        break;
                    case 2:
                        cls.getMethod(str2, Boolean.TYPE).invoke(view, Boolean.valueOf(auxVar.f2205b));
                        break;
                    case 3:
                        cls.getMethod(str2, CharSequence.class).invoke(view, auxVar.f2204b);
                        break;
                    case 4:
                        cls.getMethod(str2, Integer.TYPE).invoke(view, Integer.valueOf(auxVar.f8069b));
                        break;
                    case 5:
                        Method method = cls.getMethod(str2, Drawable.class);
                        ColorDrawable colorDrawable = new ColorDrawable();
                        colorDrawable.setColor(auxVar.f8069b);
                        method.invoke(view, colorDrawable);
                        break;
                    case 6:
                        cls.getMethod(str2, Integer.TYPE).invoke(view, Integer.valueOf(auxVar.f2200a));
                        break;
                    case 7:
                        cls.getMethod(str2, Float.TYPE).invoke(view, Float.valueOf(auxVar.f8068a));
                        break;
                    case 8:
                        cls.getMethod(str2, Float.TYPE).invoke(view, Float.valueOf(auxVar.f8068a));
                        break;
                }
            } catch (IllegalAccessException e2) {
                Log.e("TransitionLayout", " Custom Attribute \"" + str + "\" not found on " + cls.getName());
                e2.printStackTrace();
            } catch (NoSuchMethodException e3) {
                Log.e("TransitionLayout", e3.getMessage());
                Log.e("TransitionLayout", " Custom Attribute \"" + str + "\" not found on " + cls.getName());
                StringBuilder sb = new StringBuilder();
                sb.append(cls.getName());
                sb.append(" must have a method ");
                sb.append(str2);
                Log.e("TransitionLayout", sb.toString());
            } catch (InvocationTargetException e4) {
                Log.e("TransitionLayout", " Custom Attribute \"" + str + "\" not found on " + cls.getName());
                e4.printStackTrace();
            }
        }
    }

    public String b() {
        return this.f2202a;
    }

    public con c() {
        return this.f2201a;
    }

    public void f(Object obj) {
        switch (C0028aux.f8070a[this.f2201a.ordinal()]) {
            case 1:
            case 6:
                this.f2200a = ((Integer) obj).intValue();
                break;
            case 2:
                this.f2205b = ((Boolean) obj).booleanValue();
                break;
            case 3:
                this.f2204b = (String) obj;
                break;
            case 4:
            case 5:
                this.f8069b = ((Integer) obj).intValue();
                break;
            case 7:
                this.f8068a = ((Float) obj).floatValue();
                break;
            case 8:
                this.f8068a = ((Float) obj).floatValue();
                break;
        }
    }

    public aux(aux auxVar, Object obj) {
        this.f2203a = false;
        this.f2202a = auxVar.f2202a;
        this.f2201a = auxVar.f2201a;
        f(obj);
    }
}
