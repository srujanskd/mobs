package androidx.recyclerview.widget;

import p101com2.r2;
import p101com2.s2;
import p147nUl.a0;
import p147nUl.d0;

/* JADX INFO: loaded from: classes.dex */
public class lpt3 {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final d0<RecyclerView.h, aux> f2882a = new d0<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a0<RecyclerView.h> f8686a = new a0<>();

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static r2<aux> f8687a = new s2(20);

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2883a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView.com8.nul f2884a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public RecyclerView.com8.nul f8688b;

        public static void a() {
            while (f8687a.b() != null) {
            }
        }

        public static aux b() {
            aux auxVarB = f8687a.b();
            return auxVarB == null ? new aux() : auxVarB;
        }

        public static void c(aux auxVar) {
            auxVar.f2883a = 0;
            auxVar.f2884a = null;
            auxVar.f8688b = null;
            f8687a.a(auxVar);
        }
    }

    public interface con {
        void a(RecyclerView.h hVar);

        void b(RecyclerView.h hVar, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2);

        void c(RecyclerView.h hVar, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2);

        void d(RecyclerView.h hVar, RecyclerView.com8.nul nulVar, RecyclerView.com8.nul nulVar2);
    }

    public void a(RecyclerView.h hVar, RecyclerView.com8.nul nulVar) {
        aux auxVarB = this.f2882a.get(hVar);
        if (auxVarB == null) {
            auxVarB = aux.b();
            this.f2882a.put(hVar, auxVarB);
        }
        auxVarB.f2883a |= 2;
        auxVarB.f2884a = nulVar;
    }

    public void b(RecyclerView.h hVar) {
        aux auxVarB = this.f2882a.get(hVar);
        if (auxVarB == null) {
            auxVarB = aux.b();
            this.f2882a.put(hVar, auxVarB);
        }
        auxVarB.f2883a |= 1;
    }

    public void c(long j2, RecyclerView.h hVar) {
        this.f8686a.h(j2, hVar);
    }

    public void d(RecyclerView.h hVar, RecyclerView.com8.nul nulVar) {
        aux auxVarB = this.f2882a.get(hVar);
        if (auxVarB == null) {
            auxVarB = aux.b();
            this.f2882a.put(hVar, auxVarB);
        }
        auxVarB.f8688b = nulVar;
        auxVarB.f2883a |= 8;
    }

    public void e(RecyclerView.h hVar, RecyclerView.com8.nul nulVar) {
        aux auxVarB = this.f2882a.get(hVar);
        if (auxVarB == null) {
            auxVarB = aux.b();
            this.f2882a.put(hVar, auxVarB);
        }
        auxVarB.f2884a = nulVar;
        auxVarB.f2883a |= 4;
    }

    public void f() {
        this.f2882a.clear();
        this.f8686a.a();
    }

    public RecyclerView.h g(long j2) {
        return this.f8686a.d(j2);
    }

    public boolean h(RecyclerView.h hVar) {
        aux auxVar = this.f2882a.get(hVar);
        return (auxVar == null || (auxVar.f2883a & 1) == 0) ? false : true;
    }

    public boolean i(RecyclerView.h hVar) {
        aux auxVar = this.f2882a.get(hVar);
        return (auxVar == null || (auxVar.f2883a & 4) == 0) ? false : true;
    }

    public void j() {
        aux.a();
    }

    public void k(RecyclerView.h hVar) {
        p(hVar);
    }

    public final RecyclerView.com8.nul l(RecyclerView.h hVar, int i2) {
        aux auxVarM;
        RecyclerView.com8.nul nulVar;
        int iF = this.f2882a.f(hVar);
        if (iF >= 0 && (auxVarM = this.f2882a.m(iF)) != null) {
            int i3 = auxVarM.f2883a;
            if ((i3 & i2) != 0) {
                int i4 = (~i2) & i3;
                auxVarM.f2883a = i4;
                if (i2 == 4) {
                    nulVar = auxVarM.f2884a;
                } else {
                    if (i2 != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    nulVar = auxVarM.f8688b;
                }
                if ((i4 & 12) == 0) {
                    this.f2882a.k(iF);
                    aux.c(auxVarM);
                }
                return nulVar;
            }
        }
        return null;
    }

    public RecyclerView.com8.nul m(RecyclerView.h hVar) {
        return l(hVar, 8);
    }

    public RecyclerView.com8.nul n(RecyclerView.h hVar) {
        return l(hVar, 4);
    }

    public void o(con conVar) {
        for (int size = this.f2882a.size() - 1; size >= 0; size--) {
            RecyclerView.h hVarI = this.f2882a.i(size);
            aux auxVarK = this.f2882a.k(size);
            int i2 = auxVarK.f2883a;
            if ((i2 & 3) == 3) {
                conVar.a(hVarI);
            } else if ((i2 & 1) != 0) {
                RecyclerView.com8.nul nulVar = auxVarK.f2884a;
                if (nulVar == null) {
                    conVar.a(hVarI);
                } else {
                    conVar.c(hVarI, nulVar, auxVarK.f8688b);
                }
            } else if ((i2 & 14) == 14) {
                conVar.d(hVarI, auxVarK.f2884a, auxVarK.f8688b);
            } else if ((i2 & 12) == 12) {
                conVar.b(hVarI, auxVarK.f2884a, auxVarK.f8688b);
            } else if ((i2 & 4) != 0) {
                conVar.c(hVarI, auxVarK.f2884a, null);
            } else if ((i2 & 8) != 0) {
                conVar.d(hVarI, auxVarK.f2884a, auxVarK.f8688b);
            }
            aux.c(auxVarK);
        }
    }

    public void p(RecyclerView.h hVar) {
        aux auxVar = this.f2882a.get(hVar);
        if (auxVar == null) {
            return;
        }
        auxVar.f2883a &= -2;
    }

    public void q(RecyclerView.h hVar) {
        for (int iK = this.f8686a.k() - 1; iK >= 0; iK--) {
            if (hVar == this.f8686a.l(iK)) {
                this.f8686a.j(iK);
                break;
            }
        }
        aux auxVarRemove = this.f2882a.remove(hVar);
        if (auxVarRemove != null) {
            aux.c(auxVarRemove);
        }
    }
}
