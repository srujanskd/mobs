package androidx.fragment.app;

import COM3.lpt6;
import COM3.lpt7;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import p015CoM3.i;
import p015CoM3.l;
import p015CoM3.p;
import p015CoM3.q;
import p068auX.k;
import p068auX.m;
import p068auX.n;
import p092coM3.l0;
import p147nUl.y;

/* JADX INFO: loaded from: classes.dex */
public abstract class com6 {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static boolean f8251g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static boolean f8252h = true;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p000AUx.prn<Intent> f2434a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public i f2436a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public OnBackPressedDispatcher f2438a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Fragment f2439a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.fragment.app.com3<?> f2441a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.fragment.app.com8 f2444a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2453a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public p000AUx.prn<p000AUx.com2> f8254b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Fragment f2455b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ArrayList<androidx.fragment.app.aux> f2457b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2459b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public p000AUx.prn<String[]> f8255c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ArrayList<Fragment> f2460c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2462c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<lpt1> f8256d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2463d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public ArrayList<androidx.fragment.app.aux> f8257e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2464e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public ArrayList<Boolean> f8258f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f2465f;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public ArrayList<Fragment> f2466g;

    /* JADX INFO: renamed from: h, reason: collision with other field name */
    public ArrayList<lpt4> f2467h;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<lpt2> f2449a = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.fragment.app.lpt2 f2445a = new androidx.fragment.app.lpt2();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.fragment.app.com4 f2442a = new androidx.fragment.app.com4(this);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final p002Aux.lpt5 f2435a = new nul(false);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AtomicInteger f2452a = new AtomicInteger();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<String, Bundle> f2450a = Collections.synchronizedMap(new HashMap());

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Map<String, Object> f2458b = Collections.synchronizedMap(new HashMap());

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public Map<Fragment, HashSet<p013CoM1.com7>> f2461c = Collections.synchronizedMap(new HashMap());

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.fragment.app.lpt4.com3 f2446a = new prn();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.fragment.app.com5 f2443a = new androidx.fragment.app.com5(this);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CopyOnWriteArrayList<l> f2451a = new CopyOnWriteArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8253a = -1;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.fragment.app.com2 f2440a = null;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public androidx.fragment.app.com2 f2456b = new com1();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public q f2437a = null;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public q f2454b = new com2();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayDeque<com9> f2448a = new ArrayDeque<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Runnable f2447a = new com3();

    public class aux implements p000AUx.nul<p000AUx.con> {
        public aux() {
        }

        @Override // p000AUx.nul
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(p000AUx.con conVar) {
            com9 com9VarPollFirst = com6.this.f2448a.pollFirst();
            if (com9VarPollFirst == null) {
                Log.w("FragmentManager", "No IntentSenders were started for " + this);
                return;
            }
            String str = com9VarPollFirst.f2472a;
            int i2 = com9VarPollFirst.f8266a;
            Fragment fragmentI = com6.this.f2445a.i(str);
            if (fragmentI != null) {
                fragmentI.onActivityResult(i2, conVar.m(), conVar.k());
                return;
            }
            Log.w("FragmentManager", "Intent Sender result delivered for unknown Fragment " + str);
        }
    }

    public class com1 extends androidx.fragment.app.com2 {
        public com1() {
        }

        @Override // androidx.fragment.app.com2
        public Fragment a(ClassLoader classLoader, String str) {
            return com6.this.v0().b(com6.this.v0().f(), str, null);
        }
    }

    public class com2 implements q {
        public com2() {
        }

        @Override // p015CoM3.q
        public lpt5 a(ViewGroup viewGroup) {
            return new androidx.fragment.app.nul(viewGroup);
        }
    }

    public class com3 implements Runnable {
        public com3() {
        }

        @Override // java.lang.Runnable
        public void run() {
            com6.this.b0(true);
        }
    }

    public class com4 extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8263a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ViewGroup f2468a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2469a;

        public com4(ViewGroup viewGroup, View view, Fragment fragment) {
            this.f2468a = viewGroup;
            this.f8263a = view;
            this.f2469a = fragment;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2468a.endViewTransition(this.f8263a);
            animator.removeListener(this);
            Fragment fragment = this.f2469a;
            View view = fragment.mView;
            if (view == null || !fragment.mHidden) {
                return;
            }
            view.setVisibility(8);
        }
    }

    public class com5 implements l {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Fragment f8264a;

        public com5(Fragment fragment) {
            this.f8264a = fragment;
        }

        @Override // p015CoM3.l
        public void a(com6 com6Var, Fragment fragment) {
            this.f8264a.onAttachFragment(fragment);
        }
    }

    /* JADX INFO: renamed from: androidx.fragment.app.com6$com6, reason: collision with other inner class name */
    public class C0036com6 implements p000AUx.nul<p000AUx.con> {
        public C0036com6() {
        }

        @Override // p000AUx.nul
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(p000AUx.con conVar) {
            com9 com9VarPollFirst = com6.this.f2448a.pollFirst();
            if (com9VarPollFirst == null) {
                Log.w("FragmentManager", "No Activities were started for result for " + this);
                return;
            }
            String str = com9VarPollFirst.f2472a;
            int i2 = com9VarPollFirst.f8266a;
            Fragment fragmentI = com6.this.f2445a.i(str);
            if (fragmentI != null) {
                fragmentI.onActivityResult(i2, conVar.m(), conVar.k());
                return;
            }
            Log.w("FragmentManager", "Activity result delivered for unknown Fragment " + str);
        }
    }

    public interface com7 {
        int getId();
    }

    public static class com8 extends k<p000AUx.com2, p000AUx.con> {
        @Override // p068auX.k
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public Intent a(Context context, p000AUx.com2 com2Var) {
            Bundle bundleExtra;
            Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
            Intent intentK = com2Var.k();
            if (intentK != null && (bundleExtra = intentK.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                intentK.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                if (intentK.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                    com2Var = new AUx.com2.con(com2Var.o()).b(null).c(com2Var.n(), com2Var.m()).a();
                }
            }
            intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", com2Var);
            if (com6.H0(2)) {
                Log.v("FragmentManager", "CreateIntent created the following intent: " + intent);
            }
            return intent;
        }

        @Override // p068auX.k
        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public p000AUx.con c(int i2, Intent intent) {
            return new p000AUx.con(i2, intent);
        }
    }

    public class con implements p000AUx.nul<Map<String, Boolean>> {
        public con() {
        }

        @Override // p000AUx.nul
        @SuppressLint({"SyntheticAccessor"})
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void a(Map<String, Boolean> map) {
            String[] strArr = (String[]) map.keySet().toArray(new String[0]);
            ArrayList arrayList = new ArrayList(map.values());
            int[] iArr = new int[arrayList.size()];
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                iArr[i2] = ((Boolean) arrayList.get(i2)).booleanValue() ? 0 : -1;
            }
            com9 com9VarPollFirst = com6.this.f2448a.pollFirst();
            if (com9VarPollFirst == null) {
                Log.w("FragmentManager", "No permissions were requested for " + this);
                return;
            }
            String str = com9VarPollFirst.f2472a;
            int i3 = com9VarPollFirst.f8266a;
            Fragment fragmentI = com6.this.f2445a.i(str);
            if (fragmentI != null) {
                fragmentI.onRequestPermissionsResult(i3, strArr, iArr);
                return;
            }
            Log.w("FragmentManager", "Permission request result delivered for unknown Fragment " + str);
        }
    }

    public interface lpt1 {
        void onBackStackChanged();
    }

    public interface lpt2 {
        boolean a(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2);
    }

    public class lpt3 implements lpt2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final int f8268a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final String f2474a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final int f8269b;

        public lpt3(String str, int i2, int i3) {
            this.f2474a = str;
            this.f8268a = i2;
            this.f8269b = i3;
        }

        @Override // androidx.fragment.app.com6.lpt2
        public boolean a(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2) {
            Fragment fragment = com6.this.f2455b;
            if (fragment == null || this.f8268a >= 0 || this.f2474a != null || !fragment.getChildFragmentManager().a1()) {
                return com6.this.c1(arrayList, arrayList2, this.f2474a, this.f8268a, this.f8269b);
            }
            return false;
        }
    }

    public static class lpt4 implements Fragment.com8 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8270a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final androidx.fragment.app.aux f2475a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final boolean f2476a;

        public lpt4(androidx.fragment.app.aux auxVar, boolean z2) {
            this.f2476a = z2;
            this.f2475a = auxVar;
        }

        @Override // androidx.fragment.app.Fragment.com8
        public void a() {
            this.f8270a++;
        }

        @Override // androidx.fragment.app.Fragment.com8
        public void b() {
            int i2 = this.f8270a - 1;
            this.f8270a = i2;
            if (i2 != 0) {
                return;
            }
            this.f2475a.f8233a.m1();
        }

        public void c() {
            androidx.fragment.app.aux auxVar = this.f2475a;
            auxVar.f8233a.u(auxVar, this.f2476a, false, false);
        }

        public void d() {
            boolean z2 = this.f8270a > 0;
            for (Fragment fragment : this.f2475a.f8233a.u0()) {
                fragment.setOnStartEnterTransitionListener(null);
                if (z2 && fragment.isPostponed()) {
                    fragment.startPostponedEnterTransition();
                }
            }
            androidx.fragment.app.aux auxVar = this.f2475a;
            auxVar.f8233a.u(auxVar, this.f2476a, !z2, true);
        }

        public boolean e() {
            return this.f8270a == 0;
        }
    }

    public class nul extends p002Aux.lpt5 {
        public nul(boolean z2) {
            super(z2);
        }

        @Override // p002Aux.lpt5
        public void e() {
            com6.this.D0();
        }
    }

    public class prn implements androidx.fragment.app.lpt4.com3 {
        public prn() {
        }

        @Override // androidx.fragment.app.lpt4.com3
        public void a(Fragment fragment, p013CoM1.com7 com7Var) {
            com6.this.f(fragment, com7Var);
        }

        @Override // androidx.fragment.app.lpt4.com3
        public void b(Fragment fragment, p013CoM1.com7 com7Var) {
            if (com7Var.b()) {
                return;
            }
            com6.this.e1(fragment, com7Var);
        }
    }

    public static Fragment B0(View view) {
        Object tag = view.getTag(l0.f9199a);
        if (tag instanceof Fragment) {
            return (Fragment) tag;
        }
        return null;
    }

    public static boolean H0(int i2) {
        return f8251g || Log.isLoggable("FragmentManager", i2);
    }

    public static void d0(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3) {
        while (i2 < i3) {
            androidx.fragment.app.aux auxVar = arrayList.get(i2);
            if (arrayList2.get(i2).booleanValue()) {
                auxVar.v(-1);
                auxVar.A(i2 == i3 + (-1));
            } else {
                auxVar.v(1);
                auxVar.z();
            }
            i2++;
        }
    }

    public static int k1(int i2) {
        if (i2 == 4097) {
            return 8194;
        }
        if (i2 != 4099) {
            return i2 != 8194 ? 0 : 4097;
        }
        return 4099;
    }

    public void A() {
        this.f2462c = false;
        this.f2463d = false;
        this.f2444a.o(false);
        T(0);
    }

    public q A0() {
        q qVar = this.f2437a;
        if (qVar != null) {
            return qVar;
        }
        Fragment fragment = this.f2439a;
        return fragment != null ? fragment.mFragmentManager.A0() : this.f2454b;
    }

    public void B(Configuration configuration) {
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null) {
                fragment.performConfigurationChanged(configuration);
            }
        }
    }

    public boolean C(MenuItem menuItem) {
        if (this.f8253a < 1) {
            return false;
        }
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null && fragment.performContextItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public lpt6 C0(Fragment fragment) {
        return this.f2444a.l(fragment);
    }

    public void D() {
        this.f2462c = false;
        this.f2463d = false;
        this.f2444a.o(false);
        T(1);
    }

    public void D0() {
        b0(true);
        if (this.f2435a.f()) {
            a1();
        } else {
            this.f2438a.c();
        }
    }

    public boolean E(Menu menu, MenuInflater menuInflater) {
        if (this.f8253a < 1) {
            return false;
        }
        ArrayList<Fragment> arrayList = null;
        boolean z2 = false;
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null && J0(fragment) && fragment.performCreateOptionsMenu(menu, menuInflater)) {
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                }
                arrayList.add(fragment);
                z2 = true;
            }
        }
        if (this.f2460c != null) {
            for (int i2 = 0; i2 < this.f2460c.size(); i2++) {
                Fragment fragment2 = this.f2460c.get(i2);
                if (arrayList == null || !arrayList.contains(fragment2)) {
                    fragment2.onDestroyOptionsMenu();
                }
            }
        }
        this.f2460c = arrayList;
        return z2;
    }

    public void E0(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "hide: " + fragment);
        }
        if (fragment.mHidden) {
            return;
        }
        fragment.mHidden = true;
        fragment.mHiddenChanged = true ^ fragment.mHiddenChanged;
        q1(fragment);
    }

    public void F() {
        this.f2464e = true;
        b0(true);
        Y();
        T(-1);
        this.f2441a = null;
        this.f2436a = null;
        this.f2439a = null;
        if (this.f2438a != null) {
            this.f2435a.g();
            this.f2438a = null;
        }
        p000AUx.prn<Intent> prnVar = this.f2434a;
        if (prnVar != null) {
            prnVar.c();
            this.f8254b.c();
            this.f8255c.c();
        }
    }

    public void F0(Fragment fragment) {
        if (fragment.mAdded && I0(fragment)) {
            this.f2459b = true;
        }
    }

    public void G() {
        T(1);
    }

    public boolean G0() {
        return this.f2464e;
    }

    public void H() {
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null) {
                fragment.performLowMemory();
            }
        }
    }

    public void I(boolean z2) {
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null) {
                fragment.performMultiWindowModeChanged(z2);
            }
        }
    }

    public final boolean I0(Fragment fragment) {
        return (fragment.mHasMenu && fragment.mMenuVisible) || fragment.mChildFragmentManager.p();
    }

    public void J(Fragment fragment) {
        Iterator<l> it = this.f2451a.iterator();
        while (it.hasNext()) {
            it.next().a(this, fragment);
        }
    }

    public boolean J0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        return fragment.isMenuVisible();
    }

    public boolean K(MenuItem menuItem) {
        if (this.f8253a < 1) {
            return false;
        }
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null && fragment.performOptionsItemSelected(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public boolean K0(Fragment fragment) {
        if (fragment == null) {
            return true;
        }
        com6 com6Var = fragment.mFragmentManager;
        return fragment.equals(com6Var.z0()) && K0(com6Var.f2439a);
    }

    public void L(Menu menu) {
        if (this.f8253a < 1) {
            return;
        }
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null) {
                fragment.performOptionsMenuClosed(menu);
            }
        }
    }

    public boolean L0(int i2) {
        return this.f8253a >= i2;
    }

    public final void M(Fragment fragment) {
        if (fragment == null || !fragment.equals(h0(fragment.mWho))) {
            return;
        }
        fragment.performPrimaryNavigationFragmentChanged();
    }

    public boolean M0() {
        return this.f2462c || this.f2463d;
    }

    public void N() {
        T(5);
    }

    public void N0(Fragment fragment, String[] strArr, int i2) {
        if (this.f8255c == null) {
            this.f2441a.j(fragment, strArr, i2);
            return;
        }
        this.f2448a.addLast(new com9(fragment.mWho, i2));
        this.f8255c.a(strArr);
    }

    public void O(boolean z2) {
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null) {
                fragment.performPictureInPictureModeChanged(z2);
            }
        }
    }

    public void O0(Fragment fragment, @SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        if (this.f2434a == null) {
            this.f2441a.m(fragment, intent, i2, bundle);
            return;
        }
        this.f2448a.addLast(new com9(fragment.mWho, i2));
        if (intent != null && bundle != null) {
            intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
        }
        this.f2434a.a(intent);
    }

    public boolean P(Menu menu) {
        boolean z2 = false;
        if (this.f8253a < 1) {
            return false;
        }
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null && J0(fragment) && fragment.performPrepareOptionsMenu(menu)) {
                z2 = true;
            }
        }
        return z2;
    }

    public void P0(Fragment fragment, @SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) throws IntentSender.SendIntentException {
        Intent intent2;
        if (this.f8254b == null) {
            this.f2441a.n(fragment, intentSender, i2, intent, i3, i4, i5, bundle);
            return;
        }
        if (bundle != null) {
            if (intent == null) {
                intent2 = new Intent();
                intent2.putExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", true);
            } else {
                intent2 = intent;
            }
            if (H0(2)) {
                Log.v("FragmentManager", "ActivityOptions " + bundle + " were added to fillInIntent " + intent2 + " for fragment " + fragment);
            }
            intent2.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
        } else {
            intent2 = intent;
        }
        p000AUx.com2 com2VarA = new AUx.com2.con(intentSender).b(intent2).c(i4, i3).a();
        this.f2448a.addLast(new com9(fragment.mWho, i2));
        if (H0(2)) {
            Log.v("FragmentManager", "Fragment " + fragment + "is launching an IntentSender for result ");
        }
        this.f8254b.a(com2VarA);
    }

    public void Q() {
        t1();
        M(this.f2455b);
    }

    public final void Q0(y<Fragment> yVar) {
        int size = yVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment fragmentH = yVar.h(i2);
            if (!fragmentH.mAdded) {
                View viewRequireView = fragmentH.requireView();
                fragmentH.mPostponedAlpha = viewRequireView.getAlpha();
                viewRequireView.setAlpha(0.0f);
            }
        }
    }

    public void R() {
        this.f2462c = false;
        this.f2463d = false;
        this.f2444a.o(false);
        T(7);
    }

    public void R0(Fragment fragment) {
        if (!this.f2445a.c(fragment.mWho)) {
            if (H0(3)) {
                Log.d("FragmentManager", "Ignoring moving " + fragment + " to state " + this.f8253a + "since it is not added to " + this);
                return;
            }
            return;
        }
        T0(fragment);
        View view = fragment.mView;
        if (view != null && fragment.mIsNewlyAdded && fragment.mContainer != null) {
            float f2 = fragment.mPostponedAlpha;
            if (f2 > 0.0f) {
                view.setAlpha(f2);
            }
            fragment.mPostponedAlpha = 0.0f;
            fragment.mIsNewlyAdded = false;
            androidx.fragment.app.com1.prn prnVarC = androidx.fragment.app.com1.c(this.f2441a.f(), fragment, true, fragment.getPopDirection());
            if (prnVarC != null) {
                Animation animation = prnVarC.f2427a;
                if (animation != null) {
                    fragment.mView.startAnimation(animation);
                } else {
                    prnVarC.f8244a.setTarget(fragment.mView);
                    prnVarC.f8244a.start();
                }
            }
        }
        if (fragment.mHiddenChanged) {
            v(fragment);
        }
    }

    public void S() {
        this.f2462c = false;
        this.f2463d = false;
        this.f2444a.o(false);
        T(5);
    }

    public void S0(int i2, boolean z2) {
        androidx.fragment.app.com3<?> com3Var;
        if (this.f2441a == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z2 || i2 != this.f8253a) {
            this.f8253a = i2;
            if (f8252h) {
                this.f2445a.r();
            } else {
                Iterator<Fragment> it = this.f2445a.n().iterator();
                while (it.hasNext()) {
                    R0(it.next());
                }
                for (androidx.fragment.app.lpt1 lpt1Var : this.f2445a.k()) {
                    Fragment fragmentK = lpt1Var.k();
                    if (!fragmentK.mIsNewlyAdded) {
                        R0(fragmentK);
                    }
                    if (fragmentK.mRemoving && !fragmentK.isInBackStack()) {
                        this.f2445a.q(lpt1Var);
                    }
                }
            }
            s1();
            if (this.f2459b && (com3Var = this.f2441a) != null && this.f8253a == 7) {
                com3Var.o();
                this.f2459b = false;
            }
        }
    }

    public final void T(int i2) {
        try {
            this.f2453a = true;
            this.f2445a.d(i2);
            S0(i2, false);
            if (f8252h) {
                Iterator<lpt5> it = s().iterator();
                while (it.hasNext()) {
                    it.next().j();
                }
            }
            this.f2453a = false;
            b0(true);
        } catch (Throwable th) {
            this.f2453a = false;
            throw th;
        }
    }

    public void T0(Fragment fragment) {
        U0(fragment, this.f8253a);
    }

    public void U() {
        this.f2463d = true;
        this.f2444a.o(true);
        T(4);
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0161  */
    /* JADX WARN: Code duplicated, block: B:31:0x0063  */
    /* JADX WARN: Code duplicated, block: B:33:0x0068  */
    /* JADX WARN: Code duplicated, block: B:35:0x006d  */
    /* JADX WARN: Code duplicated, block: B:37:0x0072  */
    /* JADX WARN: Code duplicated, block: B:39:0x0077  */
    /* JADX WARN: Code duplicated, block: B:98:0x015e  */
    public void U0(Fragment fragment, int i2) {
        ViewGroup viewGroup;
        androidx.fragment.app.lpt1 lpt1VarM = this.f2445a.m(fragment.mWho);
        int i3 = 1;
        if (lpt1VarM == null) {
            lpt1VarM = new androidx.fragment.app.lpt1(this.f2443a, this.f2445a, fragment);
            lpt1VarM.t(1);
        }
        if (fragment.mFromLayout && fragment.mInLayout && fragment.mState == 2) {
            i2 = Math.max(i2, 2);
        }
        int iMin = Math.min(i2, lpt1VarM.d());
        int i4 = fragment.mState;
        if (i4 <= iMin) {
            if (i4 < iMin && !this.f2461c.isEmpty()) {
                o(fragment);
            }
            int i5 = fragment.mState;
            if (i5 != -1) {
                if (i5 != 0) {
                    if (i5 != 1) {
                        if (i5 != 2) {
                            if (i5 != 4) {
                                if (i5 == 5) {
                                }
                            }
                            if (iMin > 5) {
                                lpt1VarM.p();
                            }
                        }
                        if (iMin > 4) {
                            lpt1VarM.u();
                        }
                        if (iMin > 5) {
                            lpt1VarM.p();
                        }
                    }
                    if (iMin > 2) {
                        lpt1VarM.a();
                    }
                    if (iMin > 4) {
                        lpt1VarM.u();
                    }
                    if (iMin > 5) {
                        lpt1VarM.p();
                    }
                }
                if (iMin > -1) {
                    lpt1VarM.j();
                }
                if (iMin > 1) {
                    lpt1VarM.f();
                }
                if (iMin > 2) {
                    lpt1VarM.a();
                }
                if (iMin > 4) {
                    lpt1VarM.u();
                }
                if (iMin > 5) {
                    lpt1VarM.p();
                }
            } else if (iMin > -1) {
                lpt1VarM.c();
            }
            if (iMin > 0) {
                lpt1VarM.e();
            }
            if (iMin > -1) {
                lpt1VarM.j();
            }
            if (iMin > 1) {
                lpt1VarM.f();
            }
            if (iMin > 2) {
                lpt1VarM.a();
            }
            if (iMin > 4) {
                lpt1VarM.u();
            }
            if (iMin > 5) {
                lpt1VarM.p();
            }
        } else if (i4 > iMin) {
            if (i4 == 0) {
                i3 = iMin;
                if (i3 < 0) {
                    lpt1VarM.i();
                }
                iMin = i3;
            } else {
                if (i4 != 1) {
                    if (i4 != 2) {
                        if (i4 != 4) {
                            if (i4 != 5) {
                                if (i4 == 7) {
                                    if (iMin < 7) {
                                        lpt1VarM.n();
                                    }
                                }
                            }
                            if (iMin < 5) {
                                lpt1VarM.v();
                            }
                        }
                        if (iMin < 4) {
                            if (H0(3)) {
                                Log.d("FragmentManager", "movefrom ACTIVITY_CREATED: " + fragment);
                            }
                            if (fragment.mView != null && this.f2441a.k(fragment) && fragment.mSavedViewState == null) {
                                lpt1VarM.s();
                            }
                        }
                    }
                    if (iMin < 2) {
                        View view = fragment.mView;
                        if (view != null && (viewGroup = fragment.mContainer) != null) {
                            viewGroup.endViewTransition(view);
                            fragment.mView.clearAnimation();
                            if (!fragment.isRemovingParent()) {
                                androidx.fragment.app.com1.prn prnVarC = (this.f8253a <= -1 || this.f2464e || fragment.mView.getVisibility() != 0 || fragment.mPostponedAlpha < 0.0f) ? null : androidx.fragment.app.com1.c(this.f2441a.f(), fragment, false, fragment.getPopDirection());
                                fragment.mPostponedAlpha = 0.0f;
                                ViewGroup viewGroup2 = fragment.mContainer;
                                View view2 = fragment.mView;
                                if (prnVarC != null) {
                                    androidx.fragment.app.com1.a(fragment, prnVarC, this.f2446a);
                                }
                                viewGroup2.removeView(view2);
                                if (H0(2)) {
                                    Log.v("FragmentManager", "Removing view " + view2 + " for fragment " + fragment + " from container " + viewGroup2);
                                }
                                if (viewGroup2 != fragment.mContainer) {
                                    return;
                                }
                            }
                        }
                        if (this.f2461c.get(fragment) == null) {
                            lpt1VarM.h();
                        }
                    }
                }
                if (iMin >= 1) {
                    i3 = iMin;
                } else if (this.f2461c.get(fragment) == null) {
                    lpt1VarM.g();
                    i3 = iMin;
                }
                if (i3 < 0) {
                    lpt1VarM.i();
                }
                iMin = i3;
            }
        }
        if (fragment.mState != iMin) {
            if (H0(3)) {
                Log.d("FragmentManager", "moveToState: Fragment state for " + fragment + " not updated inline; expected state " + iMin + " found " + fragment.mState);
            }
            fragment.mState = iMin;
        }
    }

    public void V() {
        T(2);
    }

    public void V0() {
        if (this.f2441a == null) {
            return;
        }
        this.f2462c = false;
        this.f2463d = false;
        this.f2444a.o(false);
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment != null) {
                fragment.noteStateNotSaved();
            }
        }
    }

    public final void W() {
        if (this.f2465f) {
            this.f2465f = false;
            s1();
        }
    }

    public void W0(FragmentContainerView fragmentContainerView) {
        View view;
        for (androidx.fragment.app.lpt1 lpt1Var : this.f2445a.k()) {
            Fragment fragmentK = lpt1Var.k();
            if (fragmentK.mContainerId == fragmentContainerView.getId() && (view = fragmentK.mView) != null && view.getParent() == null) {
                fragmentK.mContainer = fragmentContainerView;
                lpt1Var.b();
            }
        }
    }

    public void X(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String str2 = str + "    ";
        this.f2445a.e(str, fileDescriptor, printWriter, strArr);
        ArrayList<Fragment> arrayList = this.f2460c;
        if (arrayList != null && (size2 = arrayList.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i2 = 0; i2 < size2; i2++) {
                Fragment fragment = this.f2460c.get(i2);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i2);
                printWriter.print(": ");
                printWriter.println(fragment.toString());
            }
        }
        ArrayList<androidx.fragment.app.aux> arrayList2 = this.f2457b;
        if (arrayList2 != null && (size = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i3 = 0; i3 < size; i3++) {
                androidx.fragment.app.aux auxVar = this.f2457b.get(i3);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i3);
                printWriter.print(": ");
                printWriter.println(auxVar.toString());
                auxVar.x(str2, printWriter);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f2452a.get());
        synchronized (this.f2449a) {
            int size3 = this.f2449a.size();
            if (size3 > 0) {
                printWriter.print(str);
                printWriter.println("Pending Actions:");
                for (int i4 = 0; i4 < size3; i4++) {
                    lpt2 lpt2Var = this.f2449a.get(i4);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(i4);
                    printWriter.print(": ");
                    printWriter.println(lpt2Var);
                }
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f2441a);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f2436a);
        if (this.f2439a != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f2439a);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f8253a);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f2462c);
        printWriter.print(" mStopped=");
        printWriter.print(this.f2463d);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f2464e);
        if (this.f2459b) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f2459b);
        }
    }

    public void X0(androidx.fragment.app.lpt1 lpt1Var) {
        Fragment fragmentK = lpt1Var.k();
        if (fragmentK.mDeferStart) {
            if (this.f2453a) {
                this.f2465f = true;
                return;
            }
            fragmentK.mDeferStart = false;
            if (f8252h) {
                lpt1Var.m();
            } else {
                T0(fragmentK);
            }
        }
    }

    public final void Y() {
        if (f8252h) {
            Iterator<lpt5> it = s().iterator();
            while (it.hasNext()) {
                it.next().j();
            }
        } else {
            if (this.f2461c.isEmpty()) {
                return;
            }
            for (Fragment fragment : this.f2461c.keySet()) {
                o(fragment);
                T0(fragment);
            }
        }
    }

    public void Y0() {
        Z(new lpt3(null, -1, 0), false);
    }

    public void Z(lpt2 lpt2Var, boolean z2) {
        if (!z2) {
            if (this.f2441a == null) {
                if (!this.f2464e) {
                    throw new IllegalStateException("FragmentManager has not been attached to a host.");
                }
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            q();
        }
        synchronized (this.f2449a) {
            if (this.f2441a == null) {
                if (!z2) {
                    throw new IllegalStateException("Activity has been destroyed");
                }
            } else {
                this.f2449a.add(lpt2Var);
                m1();
            }
        }
    }

    public void Z0(int i2, int i3) {
        if (i2 >= 0) {
            Z(new lpt3(null, i2, i3), false);
            return;
        }
        throw new IllegalArgumentException("Bad id: " + i2);
    }

    public final void a0(boolean z2) {
        if (this.f2453a) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.f2441a == null) {
            if (!this.f2464e) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        }
        if (Looper.myLooper() != this.f2441a.g().getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z2) {
            q();
        }
        if (this.f8257e == null) {
            this.f8257e = new ArrayList<>();
            this.f8258f = new ArrayList<>();
        }
        this.f2453a = true;
        try {
            g0(null, null);
        } finally {
            this.f2453a = false;
        }
    }

    public boolean a1() {
        return b1(null, -1, 0);
    }

    public boolean b0(boolean z2) {
        a0(z2);
        boolean z3 = false;
        while (m0(this.f8257e, this.f8258f)) {
            z3 = true;
            this.f2453a = true;
            try {
                g1(this.f8257e, this.f8258f);
                r();
            } catch (Throwable th) {
                r();
                throw th;
            }
        }
        t1();
        W();
        this.f2445a.b();
        return z3;
    }

    public final boolean b1(String str, int i2, int i3) {
        b0(false);
        a0(true);
        Fragment fragment = this.f2455b;
        if (fragment != null && i2 < 0 && str == null && fragment.getChildFragmentManager().a1()) {
            return true;
        }
        boolean zC1 = c1(this.f8257e, this.f8258f, str, i2, i3);
        if (zC1) {
            this.f2453a = true;
            try {
                g1(this.f8257e, this.f8258f);
                r();
            } catch (Throwable th) {
                r();
                throw th;
            }
        }
        t1();
        W();
        this.f2445a.b();
        return zC1;
    }

    public void c0(lpt2 lpt2Var, boolean z2) {
        if (z2 && (this.f2441a == null || this.f2464e)) {
            return;
        }
        a0(z2);
        if (lpt2Var.a(this.f8257e, this.f8258f)) {
            this.f2453a = true;
            try {
                g1(this.f8257e, this.f8258f);
                r();
            } catch (Throwable th) {
                r();
                throw th;
            }
        }
        t1();
        W();
        this.f2445a.b();
    }

    public boolean c1(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2, String str, int i2, int i3) {
        int i4;
        ArrayList<androidx.fragment.app.aux> arrayList3 = this.f2457b;
        if (arrayList3 == null) {
            return false;
        }
        if (str == null && i2 < 0 && (i3 & 1) == 0) {
            int size = arrayList3.size() - 1;
            if (size < 0) {
                return false;
            }
            arrayList.add(this.f2457b.remove(size));
            arrayList2.add(Boolean.TRUE);
        } else {
            if (str != null || i2 >= 0) {
                int size2 = arrayList3.size() - 1;
                while (size2 >= 0) {
                    androidx.fragment.app.aux auxVar = this.f2457b.get(size2);
                    if ((str != null && str.equals(auxVar.C())) || (i2 >= 0 && i2 == auxVar.f8235h)) {
                        break;
                    }
                    size2--;
                }
                if (size2 < 0) {
                    return false;
                }
                if ((i3 & 1) != 0) {
                    while (true) {
                        size2--;
                        if (size2 < 0) {
                            break;
                        }
                        androidx.fragment.app.aux auxVar2 = this.f2457b.get(size2);
                        if (str == null || !str.equals(auxVar2.C())) {
                            if (i2 < 0 || i2 != auxVar2.f8235h) {
                                break;
                            }
                        }
                    }
                }
                i4 = size2;
            } else {
                i4 = -1;
            }
            if (i4 == this.f2457b.size() - 1) {
                return false;
            }
            for (int size3 = this.f2457b.size() - 1; size3 > i4; size3--) {
                arrayList.add(this.f2457b.remove(size3));
                arrayList2.add(Boolean.TRUE);
            }
        }
        return true;
    }

    public final void d(y<Fragment> yVar) {
        int i2 = this.f8253a;
        if (i2 < 1) {
            return;
        }
        int iMin = Math.min(i2, 5);
        for (Fragment fragment : this.f2445a.n()) {
            if (fragment.mState < iMin) {
                U0(fragment, iMin);
                if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded) {
                    yVar.add(fragment);
                }
            }
        }
    }

    public final int d1(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3, y<Fragment> yVar) {
        int i4 = i3;
        for (int i5 = i3 - 1; i5 >= i2; i5--) {
            androidx.fragment.app.aux auxVar = arrayList.get(i5);
            boolean zBooleanValue = arrayList2.get(i5).booleanValue();
            if (auxVar.G() && !auxVar.E(arrayList, i5 + 1, i3)) {
                if (this.f2467h == null) {
                    this.f2467h = new ArrayList<>();
                }
                lpt4 lpt4Var = new lpt4(auxVar, zBooleanValue);
                this.f2467h.add(lpt4Var);
                auxVar.I(lpt4Var);
                if (zBooleanValue) {
                    auxVar.z();
                } else {
                    auxVar.A(false);
                }
                i4--;
                if (i5 != i4) {
                    arrayList.remove(i5);
                    arrayList.add(i4, auxVar);
                }
                d(yVar);
            }
        }
        return i4;
    }

    public void e(androidx.fragment.app.aux auxVar) {
        if (this.f2457b == null) {
            this.f2457b = new ArrayList<>();
        }
        this.f2457b.add(auxVar);
    }

    /* JADX WARN: Failed to calculate best type for var: r17v0 'this'  ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r17v0 'this'  ??, new type: androidx.fragment.app.com6
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 7 more
     */
    /* JADX WARN: Failed to calculate best type for var: r8v10 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v10 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.calculateFromBounds(FixTypesVisitor.java:159)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.setBestType(FixTypesVisitor.java:136)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.deduceType(FixTypesVisitor.java:241)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryDeduceTypes(FixTypesVisitor.java:224)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 6 more
     */
    /* JADX WARN: Failed to calculate best type for var: r8v10 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v10 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 7 more
     */
    /* JADX WARN: Failed to calculate best type for var: r8v11 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v11 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 7 more
     */
    /* JADX WARN: Failed to calculate best type for var: r8v12 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v12 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 7 more
     */
    /* JADX WARN: Failed to calculate best type for var: r8v13 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v13 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 7 more
     */
    /* JADX WARN: Failed to set immutable type for var: r17v0 'this'  ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r17v0 'this'  ??, new type: androidx.fragment.app.com6
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.applyWithWiderIgnSame(TypeUpdate.java:73)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setImmutableType(TypeInferenceVisitor.java:111)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$1(TypeInferenceVisitor.java:102)
    	at java.base/java.util.ArrayList.forEach(Unknown Source)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:102)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
    	... 6 more
     */
    /*  JADX ERROR: Types fix failed
        jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v10 ??, new type: int
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryPossibleTypes(FixTypesVisitor.java:186)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.deduceType(FixTypesVisitor.java:245)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryDeduceTypes(FixTypesVisitor.java:224)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
        Caused by: java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.InsnArg.getType()" because "arg" is null
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.verifyType(TypeUpdate.java:210)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.queueTypeUpdate(TypeUpdate.java:171)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.sameFirstArgListener(TypeUpdate.java:454)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.requestUpdate(TypeUpdate.java:310)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.runUpdate(TypeUpdate.java:124)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:91)
        	... 5 more
        */
    public final void e0(java.util.ArrayList<androidx.fragment.app.aux> r18, java.util.ArrayList<java.lang.Boolean> r19, int r20, int r21) {
        /*
            Method dump skipped, instruction units count: 450
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.com6.e0(java.util.ArrayList, java.util.ArrayList, int, int):void");
    }

    public void e1(Fragment fragment, p013CoM1.com7 com7Var) {
        HashSet<p013CoM1.com7> hashSet = this.f2461c.get(fragment);
        if (hashSet != null && hashSet.remove(com7Var) && hashSet.isEmpty()) {
            this.f2461c.remove(fragment);
            if (fragment.mState < 5) {
                x(fragment);
                T0(fragment);
            }
        }
    }

    public void f(Fragment fragment, p013CoM1.com7 com7Var) {
        if (this.f2461c.get(fragment) == null) {
            this.f2461c.put(fragment, new HashSet<>());
        }
        this.f2461c.get(fragment).add(com7Var);
    }

    public boolean f0() {
        boolean zB0 = b0(true);
        l0();
        return zB0;
    }

    public void f1(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "remove: " + fragment + " nesting=" + fragment.mBackStackNesting);
        }
        boolean z2 = !fragment.isInBackStack();
        if (!fragment.mDetached || z2) {
            this.f2445a.s(fragment);
            if (I0(fragment)) {
                this.f2459b = true;
            }
            fragment.mRemoving = true;
            q1(fragment);
        }
    }

    public androidx.fragment.app.lpt1 g(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "add: " + fragment);
        }
        androidx.fragment.app.lpt1 lpt1VarW = w(fragment);
        fragment.mFragmentManager = this;
        this.f2445a.p(lpt1VarW);
        if (!fragment.mDetached) {
            this.f2445a.a(fragment);
            fragment.mRemoving = false;
            if (fragment.mView == null) {
                fragment.mHiddenChanged = false;
            }
            if (I0(fragment)) {
                this.f2459b = true;
            }
        }
        return lpt1VarW;
    }

    public final void g0(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2) {
        int iIndexOf;
        int iIndexOf2;
        ArrayList<lpt4> arrayList3 = this.f2467h;
        int size = arrayList3 == null ? 0 : arrayList3.size();
        int i2 = 0;
        while (i2 < size) {
            lpt4 lpt4Var = this.f2467h.get(i2);
            if (arrayList != null && !lpt4Var.f2476a && (iIndexOf2 = arrayList.indexOf(lpt4Var.f2475a)) != -1 && arrayList2 != null && arrayList2.get(iIndexOf2).booleanValue()) {
                this.f2467h.remove(i2);
                i2--;
                size--;
                lpt4Var.c();
            } else if (lpt4Var.e() || (arrayList != null && lpt4Var.f2475a.E(arrayList, 0, arrayList.size()))) {
                this.f2467h.remove(i2);
                i2--;
                size--;
                if (arrayList == null || lpt4Var.f2476a || (iIndexOf = arrayList.indexOf(lpt4Var.f2475a)) == -1 || arrayList2 == null || !arrayList2.get(iIndexOf).booleanValue()) {
                    lpt4Var.d();
                } else {
                    lpt4Var.c();
                }
            }
            i2++;
        }
    }

    public final void g1(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        g0(arrayList, arrayList2);
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            if (!((androidx.fragment.app.lpt3) arrayList.get(i2)).f2517c) {
                if (i3 != i2) {
                    e0(arrayList, arrayList2, i3, i2);
                }
                i3 = i2 + 1;
                if (arrayList2.get(i2).booleanValue()) {
                    while (i3 < size && arrayList2.get(i3).booleanValue() && !((androidx.fragment.app.lpt3) arrayList.get(i3)).f2517c) {
                        i3++;
                    }
                }
                e0(arrayList, arrayList2, i2, i3);
                i2 = i3 - 1;
            }
            i2++;
        }
        if (i3 != size) {
            e0(arrayList, arrayList2, i3, size);
        }
    }

    public void h(l lVar) {
        this.f2451a.add(lVar);
    }

    public Fragment h0(String str) {
        return this.f2445a.f(str);
    }

    public void h1(Fragment fragment) {
        this.f2444a.n(fragment);
    }

    public void i(lpt1 lpt1Var) {
        if (this.f8256d == null) {
            this.f8256d = new ArrayList<>();
        }
        this.f8256d.add(lpt1Var);
    }

    public Fragment i0(int i2) {
        return this.f2445a.g(i2);
    }

    public final void i1() {
        if (this.f8256d != null) {
            for (int i2 = 0; i2 < this.f8256d.size(); i2++) {
                this.f8256d.get(i2).onBackStackChanged();
            }
        }
    }

    public void j(Fragment fragment) {
        this.f2444a.f(fragment);
    }

    public Fragment j0(String str) {
        return this.f2445a.h(str);
    }

    public void j1(Parcelable parcelable) {
        androidx.fragment.app.lpt1 lpt1Var;
        if (parcelable == null) {
            return;
        }
        androidx.fragment.app.com7 com7Var = (androidx.fragment.app.com7) parcelable;
        if (com7Var.f2478a == null) {
            return;
        }
        this.f2445a.t();
        for (androidx.fragment.app.com9 com9Var : com7Var.f2478a) {
            if (com9Var != null) {
                Fragment fragmentH = this.f2444a.h(com9Var.f2486b);
                if (fragmentH != null) {
                    if (H0(2)) {
                        Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + fragmentH);
                    }
                    lpt1Var = new androidx.fragment.app.lpt1(this.f2443a, this.f2445a, fragmentH, com9Var);
                } else {
                    lpt1Var = new androidx.fragment.app.lpt1(this.f2443a, this.f2445a, this.f2441a.f().getClassLoader(), s0(), com9Var);
                }
                Fragment fragmentK = lpt1Var.k();
                fragmentK.mFragmentManager = this;
                if (H0(2)) {
                    Log.v("FragmentManager", "restoreSaveState: active (" + fragmentK.mWho + "): " + fragmentK);
                }
                lpt1Var.o(this.f2441a.f().getClassLoader());
                this.f2445a.p(lpt1Var);
                lpt1Var.t(this.f8253a);
            }
        }
        for (Fragment fragment : this.f2444a.k()) {
            if (!this.f2445a.c(fragment.mWho)) {
                if (H0(2)) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + fragment + " that was not found in the set of active Fragments " + com7Var.f2478a);
                }
                this.f2444a.n(fragment);
                fragment.mFragmentManager = this;
                androidx.fragment.app.lpt1 lpt1Var2 = new androidx.fragment.app.lpt1(this.f2443a, this.f2445a, fragment);
                lpt1Var2.t(1);
                lpt1Var2.m();
                fragment.mRemoving = true;
                lpt1Var2.m();
            }
        }
        this.f2445a.u(com7Var.f8274b);
        if (com7Var.f2479a != null) {
            this.f2457b = new ArrayList<>(com7Var.f2479a.length);
            int i2 = 0;
            while (true) {
                androidx.fragment.app.con[] conVarArr = com7Var.f2479a;
                if (i2 >= conVarArr.length) {
                    break;
                }
                androidx.fragment.app.aux auxVarK = conVarArr[i2].k(this);
                if (H0(2)) {
                    Log.v("FragmentManager", "restoreAllState: back stack #" + i2 + " (index " + auxVarK.f8235h + "): " + auxVarK);
                    PrintWriter printWriter = new PrintWriter(new p("FragmentManager"));
                    auxVarK.y("  ", printWriter, false);
                    printWriter.close();
                }
                this.f2457b.add(auxVarK);
                i2++;
            }
        } else {
            this.f2457b = null;
        }
        this.f2452a.set(com7Var.f8273a);
        String str = com7Var.f2477a;
        if (str != null) {
            Fragment fragmentH0 = h0(str);
            this.f2455b = fragmentH0;
            M(fragmentH0);
        }
        ArrayList<String> arrayList = com7Var.f8275c;
        if (arrayList != null) {
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                Bundle bundle = com7Var.f8276d.get(i3);
                bundle.setClassLoader(this.f2441a.f().getClassLoader());
                this.f2450a.put(arrayList.get(i3), bundle);
            }
        }
        this.f2448a = new ArrayDeque<>(com7Var.f8277e);
    }

    public int k() {
        return this.f2452a.getAndIncrement();
    }

    public Fragment k0(String str) {
        return this.f2445a.i(str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @SuppressLint({"SyntheticAccessor"})
    public void l(androidx.fragment.app.com3<?> com3Var, i iVar, Fragment fragment) {
        String str;
        COM3.com7 com7Var;
        if (this.f2441a != null) {
            throw new IllegalStateException("Already attached");
        }
        this.f2441a = com3Var;
        this.f2436a = iVar;
        this.f2439a = fragment;
        if (fragment != null) {
            h(new com5(fragment));
        } else if (com3Var instanceof l) {
            h((l) com3Var);
        }
        if (this.f2439a != null) {
            t1();
        }
        if (com3Var instanceof p002Aux.lpt6) {
            p002Aux.lpt6 lpt6Var = (p002Aux.lpt6) com3Var;
            OnBackPressedDispatcher onBackPressedDispatcherG = lpt6Var.G();
            this.f2438a = onBackPressedDispatcherG;
            if (fragment != null) {
                com7Var = lpt6Var;
                com7Var = fragment;
            }
            com7Var = lpt6Var;
            onBackPressedDispatcherG.a(com7Var, this.f2435a);
        }
        if (fragment != null) {
            this.f2444a = fragment.mFragmentManager.p0(fragment);
        } else if (com3Var instanceof lpt7) {
            this.f2444a = androidx.fragment.app.com8.j(((lpt7) com3Var).getViewModelStore());
        } else {
            this.f2444a = new androidx.fragment.app.com8(false);
        }
        this.f2444a.o(M0());
        this.f2445a.x(this.f2444a);
        Object obj = this.f2441a;
        if (obj instanceof p000AUx.com1) {
            ActivityResultRegistry activityResultRegistryE = ((p000AUx.com1) obj).E();
            if (fragment != null) {
                str = fragment.mWho + ":";
            } else {
                str = "";
            }
            String str2 = "FragmentManager:" + str;
            this.f2434a = activityResultRegistryE.j(str2 + "StartActivityForResult", new n(), new C0036com6());
            this.f8254b = activityResultRegistryE.j(str2 + "StartIntentSenderForResult", new com8(), new aux());
            this.f8255c = activityResultRegistryE.j(str2 + "RequestPermissions", new m(), new con());
        }
    }

    public final void l0() {
        if (f8252h) {
            Iterator<lpt5> it = s().iterator();
            while (it.hasNext()) {
                it.next().k();
            }
        } else if (this.f2467h != null) {
            while (!this.f2467h.isEmpty()) {
                this.f2467h.remove(0).d();
            }
        }
    }

    public Parcelable l1() {
        int size;
        l0();
        Y();
        b0(true);
        this.f2462c = true;
        this.f2444a.o(true);
        ArrayList<androidx.fragment.app.com9> arrayListV = this.f2445a.v();
        androidx.fragment.app.con[] conVarArr = null;
        if (arrayListV.isEmpty()) {
            if (H0(2)) {
                Log.v("FragmentManager", "saveAllState: no fragments!");
            }
            return null;
        }
        ArrayList<String> arrayListW = this.f2445a.w();
        ArrayList<androidx.fragment.app.aux> arrayList = this.f2457b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            conVarArr = new androidx.fragment.app.con[size];
            for (int i2 = 0; i2 < size; i2++) {
                conVarArr[i2] = new androidx.fragment.app.con(this.f2457b.get(i2));
                if (H0(2)) {
                    Log.v("FragmentManager", "saveAllState: adding back stack #" + i2 + ": " + this.f2457b.get(i2));
                }
            }
        }
        androidx.fragment.app.com7 com7Var = new androidx.fragment.app.com7();
        com7Var.f2478a = arrayListV;
        com7Var.f8274b = arrayListW;
        com7Var.f2479a = conVarArr;
        com7Var.f8273a = this.f2452a.get();
        Fragment fragment = this.f2455b;
        if (fragment != null) {
            com7Var.f2477a = fragment.mWho;
        }
        com7Var.f8275c.addAll(this.f2450a.keySet());
        com7Var.f8276d.addAll(this.f2450a.values());
        com7Var.f8277e = new ArrayList<>(this.f2448a);
        return com7Var;
    }

    public void m(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "attach: " + fragment);
        }
        if (fragment.mDetached) {
            fragment.mDetached = false;
            if (fragment.mAdded) {
                return;
            }
            this.f2445a.a(fragment);
            if (H0(2)) {
                Log.v("FragmentManager", "add from attach: " + fragment);
            }
            if (I0(fragment)) {
                this.f2459b = true;
            }
        }
    }

    public final boolean m0(ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2) {
        synchronized (this.f2449a) {
            if (this.f2449a.isEmpty()) {
                return false;
            }
            int size = this.f2449a.size();
            boolean zA = false;
            for (int i2 = 0; i2 < size; i2++) {
                zA |= this.f2449a.get(i2).a(arrayList, arrayList2);
            }
            this.f2449a.clear();
            this.f2441a.g().removeCallbacks(this.f2447a);
            return zA;
        }
    }

    public void m1() {
        synchronized (this.f2449a) {
            ArrayList<lpt4> arrayList = this.f2467h;
            boolean z2 = (arrayList == null || arrayList.isEmpty()) ? false : true;
            boolean z3 = this.f2449a.size() == 1;
            if (z2 || z3) {
                this.f2441a.g().removeCallbacks(this.f2447a);
                this.f2441a.g().post(this.f2447a);
                t1();
            }
        }
    }

    public androidx.fragment.app.lpt3 n() {
        return new androidx.fragment.app.aux(this);
    }

    public com7 n0(int i2) {
        return this.f2457b.get(i2);
    }

    public void n1(Fragment fragment, boolean z2) {
        ViewGroup viewGroupR0 = r0(fragment);
        if (viewGroupR0 == null || !(viewGroupR0 instanceof FragmentContainerView)) {
            return;
        }
        ((FragmentContainerView) viewGroupR0).setDrawDisappearingViewsLast(!z2);
    }

    public final void o(Fragment fragment) {
        HashSet<p013CoM1.com7> hashSet = this.f2461c.get(fragment);
        if (hashSet != null) {
            Iterator<p013CoM1.com7> it = hashSet.iterator();
            while (it.hasNext()) {
                it.next().a();
            }
            hashSet.clear();
            x(fragment);
            this.f2461c.remove(fragment);
        }
    }

    public int o0() {
        ArrayList<androidx.fragment.app.aux> arrayList = this.f2457b;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    public void o1(Fragment fragment, androidx.lifecycle.nul.EnumC0039nul enumC0039nul) {
        if (fragment.equals(h0(fragment.mWho)) && (fragment.mHost == null || fragment.mFragmentManager == this)) {
            fragment.mMaxState = enumC0039nul;
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    public boolean p() {
        boolean zI0 = false;
        for (Fragment fragment : this.f2445a.l()) {
            if (fragment != null) {
                zI0 = I0(fragment);
            }
            if (zI0) {
                return true;
            }
        }
        return false;
    }

    public final androidx.fragment.app.com8 p0(Fragment fragment) {
        return this.f2444a.i(fragment);
    }

    public void p1(Fragment fragment) {
        if (fragment == null || (fragment.equals(h0(fragment.mWho)) && (fragment.mHost == null || fragment.mFragmentManager == this))) {
            Fragment fragment2 = this.f2455b;
            this.f2455b = fragment;
            M(fragment2);
            M(this.f2455b);
            return;
        }
        throw new IllegalArgumentException("Fragment " + fragment + " is not an active fragment of FragmentManager " + this);
    }

    public final void q() {
        if (M0()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
    }

    public i q0() {
        return this.f2436a;
    }

    public final void q1(Fragment fragment) {
        ViewGroup viewGroupR0 = r0(fragment);
        if (viewGroupR0 == null || fragment.getEnterAnim() + fragment.getExitAnim() + fragment.getPopEnterAnim() + fragment.getPopExitAnim() <= 0) {
            return;
        }
        int i2 = l0.f9201c;
        if (viewGroupR0.getTag(i2) == null) {
            viewGroupR0.setTag(i2, fragment);
        }
        ((Fragment) viewGroupR0.getTag(i2)).setPopDirection(fragment.getPopDirection());
    }

    public final void r() {
        this.f2453a = false;
        this.f8258f.clear();
        this.f8257e.clear();
    }

    public final ViewGroup r0(Fragment fragment) {
        ViewGroup viewGroup = fragment.mContainer;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (fragment.mContainerId > 0 && this.f2436a.d()) {
            View viewC = this.f2436a.c(fragment.mContainerId);
            if (viewC instanceof ViewGroup) {
                return (ViewGroup) viewC;
            }
        }
        return null;
    }

    public void r1(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "show: " + fragment);
        }
        if (fragment.mHidden) {
            fragment.mHidden = false;
            fragment.mHiddenChanged = !fragment.mHiddenChanged;
        }
    }

    public final Set<lpt5> s() {
        HashSet hashSet = new HashSet();
        Iterator<androidx.fragment.app.lpt1> it = this.f2445a.k().iterator();
        while (it.hasNext()) {
            ViewGroup viewGroup = it.next().k().mContainer;
            if (viewGroup != null) {
                hashSet.add(lpt5.n(viewGroup, A0()));
            }
        }
        return hashSet;
    }

    public androidx.fragment.app.com2 s0() {
        androidx.fragment.app.com2 com2Var = this.f2440a;
        if (com2Var != null) {
            return com2Var;
        }
        Fragment fragment = this.f2439a;
        return fragment != null ? fragment.mFragmentManager.s0() : this.f2456b;
    }

    public final void s1() {
        Iterator<androidx.fragment.app.lpt1> it = this.f2445a.k().iterator();
        while (it.hasNext()) {
            X0(it.next());
        }
    }

    public final Set<lpt5> t(ArrayList<androidx.fragment.app.aux> arrayList, int i2, int i3) {
        ViewGroup viewGroup;
        HashSet hashSet = new HashSet();
        while (i2 < i3) {
            Iterator<androidx.fragment.app.lpt3.aux> it = ((androidx.fragment.app.lpt3) arrayList.get(i2)).f2511a.iterator();
            while (it.hasNext()) {
                Fragment fragment = it.next().f2519a;
                if (fragment != null && (viewGroup = fragment.mContainer) != null) {
                    hashSet.add(lpt5.o(viewGroup, this));
                }
            }
            i2++;
        }
        return hashSet;
    }

    public androidx.fragment.app.lpt2 t0() {
        return this.f2445a;
    }

    public final void t1() {
        synchronized (this.f2449a) {
            if (this.f2449a.isEmpty()) {
                this.f2435a.i(o0() > 0 && K0(this.f2439a));
            } else {
                this.f2435a.i(true);
            }
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        Fragment fragment = this.f2439a;
        if (fragment != null) {
            sb.append(fragment.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.f2439a)));
            sb.append("}");
        } else {
            androidx.fragment.app.com3<?> com3Var = this.f2441a;
            if (com3Var != null) {
                sb.append(com3Var.getClass().getSimpleName());
                sb.append("{");
                sb.append(Integer.toHexString(System.identityHashCode(this.f2441a)));
                sb.append("}");
            } else {
                sb.append("null");
            }
        }
        sb.append("}}");
        return sb.toString();
    }

    public void u(androidx.fragment.app.aux auxVar, boolean z2, boolean z3, boolean z4) {
        if (z2) {
            auxVar.A(z4);
        } else {
            auxVar.z();
        }
        ArrayList arrayList = new ArrayList(1);
        ArrayList arrayList2 = new ArrayList(1);
        arrayList.add(auxVar);
        arrayList2.add(Boolean.valueOf(z2));
        if (z3 && this.f8253a >= 1) {
            androidx.fragment.app.lpt4.B(this.f2441a.f(), this.f2436a, arrayList, arrayList2, 0, 1, true, this.f2446a);
        }
        if (z4) {
            S0(this.f8253a, true);
        }
        for (Fragment fragment : this.f2445a.l()) {
            if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && auxVar.D(fragment.mContainerId)) {
                float f2 = fragment.mPostponedAlpha;
                if (f2 > 0.0f) {
                    fragment.mView.setAlpha(f2);
                }
                if (z4) {
                    fragment.mPostponedAlpha = 0.0f;
                } else {
                    fragment.mPostponedAlpha = -1.0f;
                    fragment.mIsNewlyAdded = false;
                }
            }
        }
    }

    public List<Fragment> u0() {
        return this.f2445a.n();
    }

    public final void v(Fragment fragment) {
        Animator animator;
        if (fragment.mView != null) {
            androidx.fragment.app.com1.prn prnVarC = androidx.fragment.app.com1.c(this.f2441a.f(), fragment, !fragment.mHidden, fragment.getPopDirection());
            if (prnVarC == null || (animator = prnVarC.f8244a) == null) {
                if (prnVarC != null) {
                    fragment.mView.startAnimation(prnVarC.f2427a);
                    prnVarC.f2427a.start();
                }
                fragment.mView.setVisibility((!fragment.mHidden || fragment.isHideReplaced()) ? 0 : 8);
                if (fragment.isHideReplaced()) {
                    fragment.setHideReplaced(false);
                }
            } else {
                animator.setTarget(fragment.mView);
                if (!fragment.mHidden) {
                    fragment.mView.setVisibility(0);
                } else if (fragment.isHideReplaced()) {
                    fragment.setHideReplaced(false);
                } else {
                    ViewGroup viewGroup = fragment.mContainer;
                    View view = fragment.mView;
                    viewGroup.startViewTransition(view);
                    prnVarC.f8244a.addListener(new com4(viewGroup, view, fragment));
                }
                prnVarC.f8244a.start();
            }
        }
        F0(fragment);
        fragment.mHiddenChanged = false;
        fragment.onHiddenChanged(fragment.mHidden);
    }

    public androidx.fragment.app.com3<?> v0() {
        return this.f2441a;
    }

    public androidx.fragment.app.lpt1 w(Fragment fragment) {
        androidx.fragment.app.lpt1 lpt1VarM = this.f2445a.m(fragment.mWho);
        if (lpt1VarM != null) {
            return lpt1VarM;
        }
        androidx.fragment.app.lpt1 lpt1Var = new androidx.fragment.app.lpt1(this.f2443a, this.f2445a, fragment);
        lpt1Var.o(this.f2441a.f().getClassLoader());
        lpt1Var.t(this.f8253a);
        return lpt1Var;
    }

    public LayoutInflater.Factory2 w0() {
        return this.f2442a;
    }

    public final void x(Fragment fragment) {
        fragment.performDestroyView();
        this.f2443a.n(fragment, false);
        fragment.mContainer = null;
        fragment.mView = null;
        fragment.mViewLifecycleOwner = null;
        fragment.mViewLifecycleOwnerLiveData.i(null);
        fragment.mInLayout = false;
    }

    public androidx.fragment.app.com5 x0() {
        return this.f2443a;
    }

    public void y(Fragment fragment) {
        if (H0(2)) {
            Log.v("FragmentManager", "detach: " + fragment);
        }
        if (fragment.mDetached) {
            return;
        }
        fragment.mDetached = true;
        if (fragment.mAdded) {
            if (H0(2)) {
                Log.v("FragmentManager", "remove from detach: " + fragment);
            }
            this.f2445a.s(fragment);
            if (I0(fragment)) {
                this.f2459b = true;
            }
            q1(fragment);
        }
    }

    public Fragment y0() {
        return this.f2439a;
    }

    public void z() {
        this.f2462c = false;
        this.f2463d = false;
        this.f2444a.o(false);
        T(4);
    }

    public Fragment z0() {
        return this.f2455b;
    }

    @SuppressLint({"BanParcelableUsage"})
    public static class com9 implements Parcelable {
        public static final Parcelable.Creator<com9> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8266a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f2472a;

        public class aux implements Parcelable.Creator<com9> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com9 createFromParcel(Parcel parcel) {
                return new com9(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com9[] newArray(int i2) {
                return new com9[i2];
            }
        }

        public com9(String str, int i2) {
            this.f2472a = str;
            this.f8266a = i2;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            parcel.writeString(this.f2472a);
            parcel.writeInt(this.f8266a);
        }

        public com9(Parcel parcel) {
            this.f2472a = parcel.readString();
            this.f8266a = parcel.readInt();
        }
    }
}
