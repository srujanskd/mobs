package COM5;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public abstract class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final DataSetObservable f5699a = new DataSetObservable();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public DataSetObserver f63a;

    public abstract void a(ViewGroup viewGroup, int i2, Object obj);

    public abstract void b(ViewGroup viewGroup);

    public abstract int c();

    public abstract int d(Object obj);

    public abstract CharSequence e(int i2);

    public float f(int i2) {
        return 1.0f;
    }

    public abstract Object g(ViewGroup viewGroup, int i2);

    public abstract boolean h(View view, Object obj);

    public void i() {
        synchronized (this) {
            DataSetObserver dataSetObserver = this.f63a;
            if (dataSetObserver != null) {
                dataSetObserver.onChanged();
            }
        }
        this.f5699a.notifyChanged();
    }

    public void j(DataSetObserver dataSetObserver) {
        this.f5699a.registerObserver(dataSetObserver);
    }

    public abstract void k(Parcelable parcelable, ClassLoader classLoader);

    public abstract Parcelable l();

    public abstract void m(ViewGroup viewGroup, int i2, Object obj);

    public void n(DataSetObserver dataSetObserver) {
        synchronized (this) {
            this.f63a = dataSetObserver;
        }
    }

    public abstract void o(ViewGroup viewGroup);

    public void p(DataSetObserver dataSetObserver) {
        this.f5699a.unregisterObserver(dataSetObserver);
    }
}
