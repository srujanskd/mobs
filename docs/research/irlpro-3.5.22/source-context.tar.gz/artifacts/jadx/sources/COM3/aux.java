package COM3;

/* JADX INFO: loaded from: classes.dex */
public class aux extends lpt5 {
}
