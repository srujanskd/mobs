package a0;

import f.com8;
import java.lang.ref.Reference;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import p059Lpt9.a;
import v.i;

/* JADX INFO: loaded from: classes.dex */
public final class com3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f7610a = new aux(null);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f1578a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final long f1579a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final con f1580a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ConcurrentLinkedQueue<com2> f1581a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final z.prn f1582a;

    public static final class aux {
        public aux() {
        }

        public /* synthetic */ aux(f.com3 com3Var) {
            this();
        }
    }

    public static final class con extends z.aux {
        public con(String str) {
            super(str, false, 2, null);
        }

        @Override // z.aux
        public long f() {
            return com3.this.b(System.nanoTime());
        }
    }

    public com3(z.com1 com1Var, int i2, long j2, TimeUnit timeUnit) {
        com8.e(com1Var, "taskRunner");
        com8.e(timeUnit, "timeUnit");
        this.f1578a = i2;
        this.f1579a = timeUnit.toNanos(j2);
        this.f1582a = com1Var.i();
        this.f1580a = new con(com8.k(w.com1.f5452a, " ConnectionPool"));
        this.f1581a = new ConcurrentLinkedQueue<>();
        if (!(j2 > 0)) {
            throw new IllegalArgumentException(com8.k("keepAliveDuration <= 0: ", Long.valueOf(j2)).toString());
        }
    }

    public final boolean a(v.aux auxVar, com1 com1Var, List<i> list, boolean z2) {
        com8.e(auxVar, "address");
        com8.e(com1Var, "call");
        for (com2 com2Var : this.f1581a) {
            com8.d(com2Var, "connection");
            synchronized (com2Var) {
                if (z2) {
                    if (!com2Var.v()) {
                    }
                    a aVar = a.f7353a;
                }
                if (com2Var.t(auxVar, list)) {
                    com1Var.c(com2Var);
                    return true;
                }
                a aVar2 = a.f7353a;
            }
        }
        return false;
    }

    public final long b(long j2) {
        int i2 = 0;
        long j3 = Long.MIN_VALUE;
        com2 com2Var = null;
        int i3 = 0;
        for (com2 com2Var2 : this.f1581a) {
            com8.d(com2Var2, "connection");
            synchronized (com2Var2) {
                if (d(com2Var2, j2) > 0) {
                    i3++;
                } else {
                    i2++;
                    long jO = j2 - com2Var2.o();
                    if (jO > j3) {
                        com2Var = com2Var2;
                        j3 = jO;
                    }
                    a aVar = a.f7353a;
                }
            }
        }
        long j4 = this.f1579a;
        if (j3 < j4 && i2 <= this.f1578a) {
            if (i2 > 0) {
                return j4 - j3;
            }
            if (i3 > 0) {
                return j4;
            }
            return -1L;
        }
        com8.b(com2Var);
        synchronized (com2Var) {
            if (!com2Var.n().isEmpty()) {
                return 0L;
            }
            if (com2Var.o() + j3 != j2) {
                return 0L;
            }
            com2Var.C(true);
            this.f1581a.remove(com2Var);
            w.com1.n(com2Var.D());
            if (this.f1581a.isEmpty()) {
                this.f1582a.a();
            }
            return 0L;
        }
    }

    public final boolean c(com2 com2Var) {
        com8.e(com2Var, "connection");
        if (w.com1.f5458a && !Thread.holdsLock(com2Var)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + com2Var);
        }
        if (!com2Var.p() && this.f1578a != 0) {
            z.prn.j(this.f1582a, this.f1580a, 0L, 2, null);
            return false;
        }
        com2Var.C(true);
        this.f1581a.remove(com2Var);
        if (this.f1581a.isEmpty()) {
            this.f1582a.a();
        }
        return true;
    }

    public final int d(com2 com2Var, long j2) {
        if (w.com1.f5458a && !Thread.holdsLock(com2Var)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + com2Var);
        }
        List<Reference<com1>> listN = com2Var.n();
        int i2 = 0;
        while (i2 < listN.size()) {
            Reference<com1> reference = listN.get(i2);
            if (reference.get() != null) {
                i2++;
            } else {
                e0.com6.f10703a.g().l("A connection to " + com2Var.z().a().l() + " was leaked. Did you forget to close a response body?", ((com1.con) reference).a());
                listN.remove(i2);
                com2Var.C(true);
                if (listN.isEmpty()) {
                    com2Var.B(j2 - this.f1579a);
                    return 0;
                }
            }
        }
        return listN.size();
    }

    public final void e(com2 com2Var) {
        com8.e(com2Var, "connection");
        if (!w.com1.f5458a || Thread.holdsLock(com2Var)) {
            this.f1581a.add(com2Var);
            z.prn.j(this.f1582a, this.f1580a, 0L, 2, null);
            return;
        }
        throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + com2Var);
    }
}
