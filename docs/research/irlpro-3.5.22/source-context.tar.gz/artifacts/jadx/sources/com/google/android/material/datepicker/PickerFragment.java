package com.google.android.material.datepicker;

import androidx.fragment.app.Fragment;
import com.newrelic.agent.android.api.v2.TraceFieldInterface;
import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.tracing.Trace;
import java.util.LinkedHashSet;
import p087cOm8.com9;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
abstract class PickerFragment extends Fragment implements TraceFieldInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Trace f9460a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinkedHashSet<com9<Object>> f3506a = new LinkedHashSet<>();

    @Override // com.newrelic.agent.android.api.v2.TraceFieldInterface
    public void _nr_setTrace(Trace trace) {
        try {
            this.f9460a = trace;
        } catch (Exception unused) {
        }
    }

    public boolean j(com9<Object> com9Var) {
        return this.f3506a.add(com9Var);
    }

    public void k() {
        this.f3506a.clear();
    }
}
