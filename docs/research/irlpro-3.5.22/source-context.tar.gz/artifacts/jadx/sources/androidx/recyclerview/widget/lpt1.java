package androidx.recyclerview.widget;

import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt1 extends RecyclerView.lpt5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Scroller f8678a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RecyclerView.lpt7 f2878a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public RecyclerView f2879a;

    public class aux extends RecyclerView.lpt7 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2880a = false;

        public aux() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt7
        public void a(RecyclerView recyclerView, int i2) {
            super.a(recyclerView, i2);
            if (i2 == 0 && this.f2880a) {
                this.f2880a = false;
                lpt1.this.k();
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt7
        public void b(RecyclerView recyclerView, int i2, int i3) {
            if (i2 == 0 && i3 == 0) {
                return;
            }
            this.f2880a = true;
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.lpt5
    public boolean a(int i2, int i3) {
        RecyclerView.lpt2 layoutManager = this.f2879a.getLayoutManager();
        if (layoutManager == null || this.f2879a.getAdapter() == null) {
            return false;
        }
        int minFlingVelocity = this.f2879a.getMinFlingVelocity();
        return (Math.abs(i3) > minFlingVelocity || Math.abs(i2) > minFlingVelocity) && j(layoutManager, i2, i3);
    }

    public void b(RecyclerView recyclerView) throws IllegalStateException {
        RecyclerView recyclerView2 = this.f2879a;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            f();
        }
        this.f2879a = recyclerView;
        if (recyclerView != null) {
            i();
            this.f8678a = new Scroller(this.f2879a.getContext(), new DecelerateInterpolator());
            k();
        }
    }

    public abstract int[] c(RecyclerView.lpt2 lpt2Var, View view);

    public RecyclerView.d d(RecyclerView.lpt2 lpt2Var) {
        return e(lpt2Var);
    }

    @Deprecated
    public abstract com3 e(RecyclerView.lpt2 lpt2Var);

    public final void f() {
        this.f2879a.Z0(this.f2878a);
        this.f2879a.setOnFlingListener(null);
    }

    public abstract View g(RecyclerView.lpt2 lpt2Var);

    public abstract int h(RecyclerView.lpt2 lpt2Var, int i2, int i3);

    public final void i() throws IllegalStateException {
        if (this.f2879a.getOnFlingListener() != null) {
            throw new IllegalStateException("An instance of OnFlingListener already set.");
        }
        this.f2879a.k(this.f2878a);
        this.f2879a.setOnFlingListener(this);
    }

    public final boolean j(RecyclerView.lpt2 lpt2Var, int i2, int i3) {
        RecyclerView.d dVarD;
        int iH;
        if (!(lpt2Var instanceof RecyclerView.d.con) || (dVarD = d(lpt2Var)) == null || (iH = h(lpt2Var, i2, i3)) == -1) {
            return false;
        }
        dVarD.p(iH);
        lpt2Var.J1(dVarD);
        return true;
    }

    public void k() {
        RecyclerView.lpt2 layoutManager;
        View viewG;
        RecyclerView recyclerView = this.f2879a;
        if (recyclerView == null || (layoutManager = recyclerView.getLayoutManager()) == null || (viewG = g(layoutManager)) == null) {
            return;
        }
        int[] iArrC = c(layoutManager, viewG);
        int i2 = iArrC[0];
        if (i2 == 0 && iArrC[1] == 0) {
            return;
        }
        this.f2879a.m1(i2, iArrC[1]);
    }
}
