package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public abstract class aux implements com5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7786a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Context f1825a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public LayoutInflater f1826a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1827a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1828a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com6 f1829a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7787b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Context f1830b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public LayoutInflater f1831b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7788c;

    public aux(Context context, int i2, int i3) {
        this.f1825a = context;
        this.f1826a = LayoutInflater.from(context);
        this.f7786a = i2;
        this.f7787b = i3;
    }

    public void a(View view, int i2) {
        ViewGroup viewGroup = (ViewGroup) view.getParent();
        if (viewGroup != null) {
            viewGroup.removeView(view);
        }
        ((ViewGroup) this.f1829a).addView(view, i2);
    }

    public abstract void b(com3 com3Var, com6.aux auxVar);

    @Override // androidx.appcompat.view.menu.com5
    public void c(com1 com1Var, boolean z2) {
        com5.aux auxVar = this.f1828a;
        if (auxVar != null) {
            auxVar.c(com1Var, z2);
        }
    }

    public com6.aux d(ViewGroup viewGroup) {
        return (com6.aux) this.f1826a.inflate(this.f7787b, viewGroup, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.appcompat.view.menu.com5
    public void e(boolean z2) {
        ViewGroup viewGroup = (ViewGroup) this.f1829a;
        if (viewGroup == null) {
            return;
        }
        com1 com1Var = this.f1827a;
        int i2 = 0;
        if (com1Var != null) {
            com1Var.r();
            ArrayList<com3> arrayListE = this.f1827a.E();
            int size = arrayListE.size();
            int i3 = 0;
            for (int i4 = 0; i4 < size; i4++) {
                com3 com3Var = arrayListE.get(i4);
                if (q(i3, com3Var)) {
                    View childAt = viewGroup.getChildAt(i3);
                    com3 itemData = childAt instanceof com6.aux ? ((com6.aux) childAt).getItemData() : null;
                    View viewN = n(com3Var, childAt, viewGroup);
                    if (com3Var != itemData) {
                        viewN.setPressed(false);
                        viewN.jumpDrawablesToCurrentState();
                    }
                    if (viewN != childAt) {
                        a(viewN, i3);
                    }
                    i3++;
                }
            }
            i2 = i3;
        }
        while (i2 < viewGroup.getChildCount()) {
            if (!l(viewGroup, i2)) {
                i2++;
            }
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public void g(com5.aux auxVar) {
        this.f1828a = auxVar;
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean h(com1 com1Var, com3 com3Var) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.com5
    public void i(Context context, com1 com1Var) {
        this.f1830b = context;
        this.f1831b = LayoutInflater.from(context);
        this.f1827a = com1Var;
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    @Override // androidx.appcompat.view.menu.com5
    public boolean j(com8 com8Var) {
        com5.aux auxVar = this.f1828a;
        com1 com1Var = com8Var;
        if (auxVar == null) {
            return false;
        }
        if (com8Var == null) {
            com1Var = this.f1827a;
        }
        return auxVar.d(com1Var);
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean k(com1 com1Var, com3 com3Var) {
        return false;
    }

    public boolean l(ViewGroup viewGroup, int i2) {
        viewGroup.removeViewAt(i2);
        return true;
    }

    public com5.aux m() {
        return this.f1828a;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public View n(com3 com3Var, View view, ViewGroup viewGroup) {
        com6.aux auxVarD = view instanceof com6.aux ? (com6.aux) view : d(viewGroup);
        b(com3Var, auxVarD);
        return (View) auxVarD;
    }

    public com6 o(ViewGroup viewGroup) {
        if (this.f1829a == null) {
            com6 com6Var = (com6) this.f1826a.inflate(this.f7786a, viewGroup, false);
            this.f1829a = com6Var;
            com6Var.c(this.f1827a);
            e(true);
        }
        return this.f1829a;
    }

    public void p(int i2) {
        this.f7788c = i2;
    }

    public abstract boolean q(int i2, com3 com3Var);
}
