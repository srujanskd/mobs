package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;
import p022CoN.l0;
import p022CoN.lpt2;
import p022CoN.lpt9;
import p022CoN.m;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatToggleButton extends ToggleButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt2 f7898a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt9 f2003a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final m f2004a;

    public AppCompatToggleButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.buttonStyleToggle);
    }

    private lpt9 getEmojiTextViewHelper() {
        if (this.f2003a == null) {
            this.f2003a = new lpt9(this);
        }
        return this.f2003a;
    }

    @Override // android.widget.ToggleButton, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            lpt2Var.b();
        }
        m mVar = this.f2004a;
        if (mVar != null) {
            mVar.b();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            return lpt2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            return lpt2Var.d();
        }
        return null;
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.ToggleButton, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            lpt2Var.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            lpt2Var.g(i2);
        }
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().e(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            lpt2Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        lpt2 lpt2Var = this.f7898a;
        if (lpt2Var != null) {
            lpt2Var.j(mode);
        }
    }

    public AppCompatToggleButton(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        l0.a(this, getContext());
        lpt2 lpt2Var = new lpt2(this);
        this.f7898a = lpt2Var;
        lpt2Var.e(attributeSet, i2);
        m mVar = new m(this);
        this.f2004a = mVar;
        mVar.m(attributeSet, i2);
        getEmojiTextViewHelper().c(attributeSet, i2);
    }
}
