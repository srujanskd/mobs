package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import p146nUL.p;

/* JADX INFO: loaded from: classes.dex */
public class com1 extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8079a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f2207a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8080b;

    public void a(ConstraintLayout constraintLayout) {
        if (this.f2207a == null) {
            return;
        }
        ConstraintLayout.con conVar = (ConstraintLayout.con) getLayoutParams();
        ConstraintLayout.con conVar2 = (ConstraintLayout.con) this.f2207a.getLayoutParams();
        conVar2.f2173a.g1(0);
        p.con conVarY = conVar.f2173a.y();
        p.con conVar3 = p.con.FIXED;
        if (conVarY != conVar3) {
            conVar.f2173a.h1(conVar2.f2173a.U());
        }
        if (conVar.f2173a.R() != conVar3) {
            conVar.f2173a.I0(conVar2.f2173a.v());
        }
        conVar2.f2173a.g1(8);
    }

    public void b(ConstraintLayout constraintLayout) {
        if (this.f8079a == -1 && !isInEditMode()) {
            setVisibility(this.f8080b);
        }
        View viewFindViewById = constraintLayout.findViewById(this.f8079a);
        this.f2207a = viewFindViewById;
        if (viewFindViewById != null) {
            ((ConstraintLayout.con) viewFindViewById.getLayoutParams()).f2195k = true;
            this.f2207a.setVisibility(0);
            setVisibility(0);
        }
    }

    public View getContent() {
        return this.f2207a;
    }

    public int getEmptyVisibility() {
        return this.f8080b;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        if (isInEditMode()) {
            canvas.drawRGB(223, 223, 223);
            Paint paint = new Paint();
            paint.setARGB(255, 210, 210, 210);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
            Rect rect = new Rect();
            canvas.getClipBounds(rect);
            paint.setTextSize(rect.height());
            int iHeight = rect.height();
            int iWidth = rect.width();
            paint.setTextAlign(Paint.Align.LEFT);
            paint.getTextBounds("?", 0, 1, rect);
            canvas.drawText("?", ((iWidth / 2.0f) - (rect.width() / 2.0f)) - rect.left, ((iHeight / 2.0f) + (rect.height() / 2.0f)) - rect.bottom, paint);
        }
    }

    public void setContentId(int i2) {
        View viewFindViewById;
        if (this.f8079a == i2) {
            return;
        }
        View view = this.f2207a;
        if (view != null) {
            view.setVisibility(0);
            ((ConstraintLayout.con) this.f2207a.getLayoutParams()).f2195k = false;
            this.f2207a = null;
        }
        this.f8079a = i2;
        if (i2 == -1 || (viewFindViewById = ((View) getParent()).findViewById(i2)) == null) {
            return;
        }
        viewFindViewById.setVisibility(8);
    }

    public void setEmptyVisibility(int i2) {
        this.f8080b = i2;
    }
}
