package COM3;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public interface com8 extends com7 {
    androidx.lifecycle.com1 u();
}
