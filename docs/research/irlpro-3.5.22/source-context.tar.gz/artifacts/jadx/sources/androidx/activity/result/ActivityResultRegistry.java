package androidx.activity.result;

import COM3.com7;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import p068auX.k;
import p150pRN.a;

/* JADX INFO: loaded from: classes.dex */
public abstract class ActivityResultRegistry {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Random f1720a = new Random();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Map<Integer, String> f1719a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Map<String, Integer> f7733b = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Map<String, prn> f7734c = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<String> f1718a = new ArrayList<>();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final transient Map<String, nul<?>> f7735d = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Map<String, Object> f7736e = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Bundle f7732a = new Bundle();

    /* JADX INFO: Add missing generic type declarations: [I] */
    public class aux<I> extends p000AUx.prn<I> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f7738a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ k f1725a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ String f1726a;

        public aux(String str, int i2, k kVar) {
            this.f1726a = str;
            this.f7738a = i2;
            this.f1725a = kVar;
        }

        @Override // p000AUx.prn
        public void b(I i2, a aVar) {
            ActivityResultRegistry.this.f1718a.add(this.f1726a);
            Integer num = ActivityResultRegistry.this.f7733b.get(this.f1726a);
            ActivityResultRegistry.this.f(num != null ? num.intValue() : this.f7738a, this.f1725a, i2, aVar);
        }

        @Override // p000AUx.prn
        public void c() {
            ActivityResultRegistry.this.l(this.f1726a);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [I] */
    public class con<I> extends p000AUx.prn<I> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f7739a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ k f1728a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ String f1729a;

        public con(String str, int i2, k kVar) {
            this.f1729a = str;
            this.f7739a = i2;
            this.f1728a = kVar;
        }

        @Override // p000AUx.prn
        public void b(I i2, a aVar) {
            ActivityResultRegistry.this.f1718a.add(this.f1729a);
            Integer num = ActivityResultRegistry.this.f7733b.get(this.f1729a);
            ActivityResultRegistry.this.f(num != null ? num.intValue() : this.f7739a, this.f1728a, i2, aVar);
        }

        @Override // p000AUx.prn
        public void c() {
            ActivityResultRegistry.this.l(this.f1729a);
        }
    }

    public static class nul<O> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final p000AUx.nul<O> f7740a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final k<?, O> f1730a;

        public nul(p000AUx.nul<O> nulVar, k<?, O> kVar) {
            this.f7740a = nulVar;
            this.f1730a = kVar;
        }
    }

    public static class prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final androidx.lifecycle.nul f7741a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final ArrayList<androidx.lifecycle.prn> f1731a = new ArrayList<>();

        public prn(androidx.lifecycle.nul nulVar) {
            this.f7741a = nulVar;
        }

        public void a(androidx.lifecycle.prn prnVar) {
            this.f7741a.a(prnVar);
            this.f1731a.add(prnVar);
        }

        public void b() {
            Iterator<androidx.lifecycle.prn> it = this.f1731a.iterator();
            while (it.hasNext()) {
                this.f7741a.c(it.next());
            }
            this.f1731a.clear();
        }
    }

    public final void a(int i2, String str) {
        this.f1719a.put(Integer.valueOf(i2), str);
        this.f7733b.put(str, Integer.valueOf(i2));
    }

    public final boolean b(int i2, int i3, Intent intent) {
        String str = this.f1719a.get(Integer.valueOf(i2));
        if (str == null) {
            return false;
        }
        this.f1718a.remove(str);
        d(str, i3, intent, this.f7735d.get(str));
        return true;
    }

    public final <O> boolean c(int i2, @SuppressLint({"UnknownNullness"}) O o2) {
        p000AUx.nul<?> nulVar;
        String str = this.f1719a.get(Integer.valueOf(i2));
        if (str == null) {
            return false;
        }
        this.f1718a.remove(str);
        nul<?> nulVar2 = this.f7735d.get(str);
        if (nulVar2 != null && (nulVar = nulVar2.f7740a) != null) {
            nulVar.a(o2);
            return true;
        }
        this.f7732a.remove(str);
        this.f7736e.put(str, o2);
        return true;
    }

    public final <O> void d(String str, int i2, Intent intent, nul<O> nulVar) {
        p000AUx.nul<O> nulVar2;
        if (nulVar != null && (nulVar2 = nulVar.f7740a) != null) {
            nulVar2.a(nulVar.f1730a.c(i2, intent));
        } else {
            this.f7736e.remove(str);
            this.f7732a.putParcelable(str, new p000AUx.con(i2, intent));
        }
    }

    public final int e() {
        int iNextInt = this.f1720a.nextInt(2147418112);
        while (true) {
            int i2 = iNextInt + 65536;
            if (!this.f1719a.containsKey(Integer.valueOf(i2))) {
                return i2;
            }
            iNextInt = this.f1720a.nextInt(2147418112);
        }
    }

    public abstract <I, O> void f(int i2, k<I, O> kVar, @SuppressLint({"UnknownNullness"}) I i3, a aVar);

    public final void g(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (stringArrayList == null || integerArrayList == null) {
            return;
        }
        this.f1718a = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        this.f1720a = (Random) bundle.getSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT");
        this.f7732a.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
        for (int i2 = 0; i2 < stringArrayList.size(); i2++) {
            String str = stringArrayList.get(i2);
            if (this.f7733b.containsKey(str)) {
                Integer numRemove = this.f7733b.remove(str);
                if (!this.f7732a.containsKey(str)) {
                    this.f1719a.remove(numRemove);
                }
            }
            a(integerArrayList.get(i2).intValue(), stringArrayList.get(i2));
        }
    }

    public final void h(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(this.f7733b.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(this.f7733b.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(this.f1718a));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.f7732a.clone());
        bundle.putSerializable("KEY_COMPONENT_ACTIVITY_RANDOM_OBJECT", this.f1720a);
    }

    public final <I, O> p000AUx.prn<I> i(final String str, com7 com7Var, final k<I, O> kVar, final p000AUx.nul<O> nulVar) {
        androidx.lifecycle.nul lifecycle = com7Var.getLifecycle();
        if (lifecycle.b().a(androidx.lifecycle.nul.EnumC0039nul.STARTED)) {
            throw new IllegalStateException("LifecycleOwner " + com7Var + " is attempting to register while current state is " + lifecycle.b() + ". LifecycleOwners must call register before they are STARTED.");
        }
        int iK = k(str);
        prn prnVar = this.f7734c.get(str);
        if (prnVar == null) {
            prnVar = new prn(lifecycle);
        }
        prnVar.a(new androidx.lifecycle.prn() { // from class: androidx.activity.result.ActivityResultRegistry.1
            @Override // androidx.lifecycle.prn
            public void f(com7 com7Var2, androidx.lifecycle.nul.con conVar) {
                if (!androidx.lifecycle.nul.con.ON_START.equals(conVar)) {
                    if (androidx.lifecycle.nul.con.ON_STOP.equals(conVar)) {
                        ActivityResultRegistry.this.f7735d.remove(str);
                        return;
                    } else {
                        if (androidx.lifecycle.nul.con.ON_DESTROY.equals(conVar)) {
                            ActivityResultRegistry.this.l(str);
                            return;
                        }
                        return;
                    }
                }
                ActivityResultRegistry.this.f7735d.put(str, new nul<>(nulVar, kVar));
                if (ActivityResultRegistry.this.f7736e.containsKey(str)) {
                    Object obj = ActivityResultRegistry.this.f7736e.get(str);
                    ActivityResultRegistry.this.f7736e.remove(str);
                    nulVar.a(obj);
                }
                p000AUx.con conVar2 = (p000AUx.con) ActivityResultRegistry.this.f7732a.getParcelable(str);
                if (conVar2 != null) {
                    ActivityResultRegistry.this.f7732a.remove(str);
                    nulVar.a(kVar.c(conVar2.m(), conVar2.k()));
                }
            }
        });
        this.f7734c.put(str, prnVar);
        return new aux(str, iK, kVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final <I, O> p000AUx.prn<I> j(String str, k<I, O> kVar, p000AUx.nul<O> nulVar) {
        int iK = k(str);
        this.f7735d.put(str, new nul<>(nulVar, kVar));
        if (this.f7736e.containsKey(str)) {
            Object obj = this.f7736e.get(str);
            this.f7736e.remove(str);
            nulVar.a(obj);
        }
        p000AUx.con conVar = (p000AUx.con) this.f7732a.getParcelable(str);
        if (conVar != null) {
            this.f7732a.remove(str);
            nulVar.a(kVar.c(conVar.m(), conVar.k()));
        }
        return new con(str, iK, kVar);
    }

    public final int k(String str) {
        Integer num = this.f7733b.get(str);
        if (num != null) {
            return num.intValue();
        }
        int iE = e();
        a(iE, str);
        return iE;
    }

    public final void l(String str) {
        Integer numRemove;
        if (!this.f1718a.contains(str) && (numRemove = this.f7733b.remove(str)) != null) {
            this.f1719a.remove(numRemove);
        }
        this.f7735d.remove(str);
        if (this.f7736e.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f7736e.get(str));
            this.f7736e.remove(str);
        }
        if (this.f7732a.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f7732a.getParcelable(str));
            this.f7732a.remove(str);
        }
        prn prnVar = this.f7734c.get(str);
        if (prnVar != null) {
            prnVar.b();
            this.f7734c.remove(str);
        }
    }
}
