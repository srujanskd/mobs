package com.google.android.material.button;

import COM9.com4;
import COM9.com7;
import COM9.lpt1;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import androidx.appcompat.widget.AppCompatButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import p009COm7.com1;
import p024Com2.y;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p098coM9.b;
import p108com9.t;
import p108com9.v;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
public class MaterialButton extends AppCompatButton implements Checkable, lpt1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f9375a = {R.attr.state_checkable};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f9376b = {R.attr.state_checked};

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int f9377f = g4.f8969n;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3376a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com1 f3377a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f3378a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f3379a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f3380a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f3381a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LinkedHashSet<aux> f3382a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3383b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3384b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f9378c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3385c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9379d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9380e;

    public interface aux {
        void a(MaterialButton materialButton, boolean z2);
    }

    public interface con {
        void a(MaterialButton materialButton, boolean z2);
    }

    public static class nul extends COM2.aux {
        public static final Parcelable.Creator<nul> CREATOR = new aux();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9381b;

        public class aux implements Parcelable.ClassLoaderCreator<nul> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public nul createFromParcel(Parcel parcel) {
                return new nul(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public nul createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new nul(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public nul[] newArray(int i2) {
                return new nul[i2];
            }
        }

        public nul(Parcelable parcelable) {
            super(parcelable);
        }

        public final void m(Parcel parcel) {
            this.f9381b = parcel.readInt() == 1;
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f9381b ? 1 : 0);
        }

        public nul(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                getClass().getClassLoader();
            }
            m(parcel);
        }
    }

    public MaterialButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.f9045t);
    }

    private String getA11yClassName() {
        return (a() ? CompoundButton.class : Button.class).getName();
    }

    private Layout.Alignment getActualTextAlignment() {
        int textAlignment = getTextAlignment();
        if (textAlignment == 1) {
            return getGravityTextAlignment();
        }
        if (textAlignment == 6 || textAlignment == 3) {
            return Layout.Alignment.ALIGN_OPPOSITE;
        }
        return textAlignment != 4 ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER;
    }

    private Layout.Alignment getGravityTextAlignment() {
        int gravity = getGravity() & 8388615;
        if (gravity != 1) {
            return (gravity == 5 || gravity == 8388613) ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
        }
        return Layout.Alignment.ALIGN_CENTER;
    }

    private int getTextHeight() {
        TextPaint paint = getPaint();
        String string = getText().toString();
        if (getTransformationMethod() != null) {
            string = getTransformationMethod().getTransformation(string, this).toString();
        }
        Rect rect = new Rect();
        paint.getTextBounds(string, 0, string.length(), rect);
        return Math.min(rect.height(), getLayout().getHeight());
    }

    private int getTextWidth() {
        TextPaint paint = getPaint();
        String string = getText().toString();
        if (getTransformationMethod() != null) {
            string = getTransformationMethod().getTransformation(string, this).toString();
        }
        return Math.min((int) paint.measureText(string), getLayout().getEllipsizedWidth());
    }

    public boolean a() {
        com1 com1Var = this.f3377a;
        return com1Var != null && com1Var.p();
    }

    public final boolean b() {
        int i2 = this.f9380e;
        return i2 == 3 || i2 == 4;
    }

    public final boolean c() {
        int i2 = this.f9380e;
        return i2 == 1 || i2 == 2;
    }

    public final boolean d() {
        int i2 = this.f9380e;
        return i2 == 16 || i2 == 32;
    }

    public final boolean e() {
        return y.A(this) == 1;
    }

    public final boolean f() {
        com1 com1Var = this.f3377a;
        return (com1Var == null || com1Var.o()) ? false : true;
    }

    public final void g() {
        if (c()) {
            p014CoM2.lpt1.i(this, this.f3380a, null, null, null);
        } else if (b()) {
            p014CoM2.lpt1.i(this, null, null, this.f3380a, null);
        } else if (d()) {
            p014CoM2.lpt1.i(this, null, this.f3380a, null, null);
        }
    }

    @Override // android.view.View
    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    @Override // android.view.View
    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (f()) {
            return this.f3377a.b();
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.f3380a;
    }

    public int getIconGravity() {
        return this.f9380e;
    }

    public int getIconPadding() {
        return this.f9379d;
    }

    public int getIconSize() {
        return this.f3376a;
    }

    public ColorStateList getIconTint() {
        return this.f3378a;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f3379a;
    }

    public int getInsetBottom() {
        return this.f3377a.c();
    }

    public int getInsetTop() {
        return this.f3377a.d();
    }

    public ColorStateList getRippleColor() {
        if (f()) {
            return this.f3377a.h();
        }
        return null;
    }

    public com7 getShapeAppearanceModel() {
        if (f()) {
            return this.f3377a.i();
        }
        throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
    }

    public ColorStateList getStrokeColor() {
        if (f()) {
            return this.f3377a.j();
        }
        return null;
    }

    public int getStrokeWidth() {
        if (f()) {
            return this.f3377a.k();
        }
        return 0;
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public ColorStateList getSupportBackgroundTintList() {
        return f() ? this.f3377a.l() : super.getSupportBackgroundTintList();
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return f() ? this.f3377a.m() : super.getSupportBackgroundTintMode();
    }

    public final void h(boolean z2) {
        Drawable drawable = this.f3380a;
        boolean z3 = true;
        if (drawable != null) {
            Drawable drawableMutate = p080cOm1.y.l(drawable).mutate();
            this.f3380a = drawableMutate;
            p080cOm1.y.i(drawableMutate, this.f3378a);
            PorterDuff.Mode mode = this.f3379a;
            if (mode != null) {
                p080cOm1.y.j(this.f3380a, mode);
            }
            int intrinsicWidth = this.f3376a;
            if (intrinsicWidth == 0) {
                intrinsicWidth = this.f3380a.getIntrinsicWidth();
            }
            int intrinsicHeight = this.f3376a;
            if (intrinsicHeight == 0) {
                intrinsicHeight = this.f3380a.getIntrinsicHeight();
            }
            Drawable drawable2 = this.f3380a;
            int i2 = this.f3383b;
            int i3 = this.f9378c;
            drawable2.setBounds(i2, i3, intrinsicWidth + i2, intrinsicHeight + i3);
            this.f3380a.setVisible(true, z2);
        }
        if (z2) {
            g();
            return;
        }
        Drawable[] drawableArrA = p014CoM2.lpt1.a(this);
        Drawable drawable3 = drawableArrA[0];
        Drawable drawable4 = drawableArrA[1];
        Drawable drawable5 = drawableArrA[2];
        if ((!c() || drawable3 == this.f3380a) && ((!b() || drawable5 == this.f3380a) && (!d() || drawable4 == this.f3380a))) {
            z3 = false;
        }
        if (z3) {
            g();
        }
    }

    public final void i(int i2, int i3) {
        if (this.f3380a == null || getLayout() == null) {
            return;
        }
        if (!c() && !b()) {
            if (d()) {
                this.f3383b = 0;
                if (this.f9380e == 16) {
                    this.f9378c = 0;
                    h(false);
                    return;
                }
                int intrinsicHeight = this.f3376a;
                if (intrinsicHeight == 0) {
                    intrinsicHeight = this.f3380a.getIntrinsicHeight();
                }
                int textHeight = (((((i3 - getTextHeight()) - getPaddingTop()) - intrinsicHeight) - this.f9379d) - getPaddingBottom()) / 2;
                if (this.f9378c != textHeight) {
                    this.f9378c = textHeight;
                    h(false);
                    return;
                }
                return;
            }
            return;
        }
        this.f9378c = 0;
        Layout.Alignment actualTextAlignment = getActualTextAlignment();
        int i4 = this.f9380e;
        if (i4 == 1 || i4 == 3 || ((i4 == 2 && actualTextAlignment == Layout.Alignment.ALIGN_NORMAL) || (i4 == 4 && actualTextAlignment == Layout.Alignment.ALIGN_OPPOSITE))) {
            this.f3383b = 0;
            h(false);
            return;
        }
        int intrinsicWidth = this.f3376a;
        if (intrinsicWidth == 0) {
            intrinsicWidth = this.f3380a.getIntrinsicWidth();
        }
        int textWidth = ((((i2 - getTextWidth()) - y.E(this)) - intrinsicWidth) - this.f9379d) - y.F(this);
        if (actualTextAlignment == Layout.Alignment.ALIGN_CENTER) {
            textWidth /= 2;
        }
        if (e() != (this.f9380e == 4)) {
            textWidth = -textWidth;
        }
        if (this.f3383b != textWidth) {
            this.f3383b = textWidth;
            h(false);
        }
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.f3384b;
    }

    @Override // android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (f()) {
            com4.f(this, this.f3377a.f());
        }
    }

    @Override // android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i2 + 2);
        if (a()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f9375a);
        }
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f9376b);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(isChecked());
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        accessibilityNodeInfo.setCheckable(a());
        accessibilityNodeInfo.setChecked(isChecked());
        accessibilityNodeInfo.setClickable(isClickable());
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.widget.TextView, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        i(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof nul)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        nul nulVar = (nul) parcelable;
        super.onRestoreInstanceState(nulVar.k());
        setChecked(nulVar.f9381b);
    }

    @Override // android.widget.TextView, android.view.View
    public Parcelable onSaveInstanceState() {
        nul nulVar = new nul(super.onSaveInstanceState());
        nulVar.f9381b = this.f3384b;
        return nulVar;
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        i(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.view.View
    public boolean performClick() {
        toggle();
        return super.performClick();
    }

    @Override // android.view.View
    public void refreshDrawableState() {
        super.refreshDrawableState();
        if (this.f3380a != null) {
            if (this.f3380a.setState(getDrawableState())) {
                invalidate();
            }
        }
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        if (f()) {
            this.f3377a.r(i2);
        } else {
            super.setBackgroundColor(i2);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (!f()) {
            super.setBackgroundDrawable(drawable);
        } else {
            if (drawable == getBackground()) {
                getBackground().setState(drawable.getState());
                return;
            }
            Log.w("MaterialButton", "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled");
            this.f3377a.s();
            super.setBackgroundDrawable(drawable);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton, android.view.View
    public void setBackgroundResource(int i2) {
        setBackgroundDrawable(i2 != 0 ? AUX.aux.b(getContext(), i2) : null);
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z2) {
        if (f()) {
            this.f3377a.t(z2);
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z2) {
        if (a() && isEnabled() && this.f3384b != z2) {
            this.f3384b = z2;
            refreshDrawableState();
            if (getParent() instanceof MaterialButtonToggleGroup) {
                ((MaterialButtonToggleGroup) getParent()).n(this, this.f3384b);
            }
            if (this.f3385c) {
                return;
            }
            this.f3385c = true;
            Iterator<aux> it = this.f3382a.iterator();
            while (it.hasNext()) {
                it.next().a(this, this.f3384b);
            }
            this.f3385c = false;
        }
    }

    public void setCornerRadius(int i2) {
        if (f()) {
            this.f3377a.u(i2);
        }
    }

    public void setCornerRadiusResource(int i2) {
        if (f()) {
            setCornerRadius(getResources().getDimensionPixelSize(i2));
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        if (f()) {
            this.f3377a.f().X(f2);
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.f3380a != drawable) {
            this.f3380a = drawable;
            h(true);
            i(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconGravity(int i2) {
        if (this.f9380e != i2) {
            this.f9380e = i2;
            i(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public void setIconPadding(int i2) {
        if (this.f9379d != i2) {
            this.f9379d = i2;
            setCompoundDrawablePadding(i2);
        }
    }

    public void setIconResource(int i2) {
        setIcon(i2 != 0 ? AUX.aux.b(getContext(), i2) : null);
    }

    public void setIconSize(int i2) {
        if (i2 < 0) {
            throw new IllegalArgumentException("iconSize cannot be less than 0");
        }
        if (this.f3376a != i2) {
            this.f3376a = i2;
            h(true);
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.f3378a != colorStateList) {
            this.f3378a = colorStateList;
            h(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.f3379a != mode) {
            this.f3379a = mode;
            h(false);
        }
    }

    public void setIconTintResource(int i2) {
        setIconTint(AUX.aux.a(getContext(), i2));
    }

    public void setInsetBottom(int i2) {
        this.f3377a.v(i2);
    }

    public void setInsetTop(int i2) {
        this.f3377a.w(i2);
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOnPressedChangeListenerInternal(con conVar) {
        this.f3381a = conVar;
    }

    @Override // android.view.View
    public void setPressed(boolean z2) {
        con conVar = this.f3381a;
        if (conVar != null) {
            conVar.a(this, z2);
        }
        super.setPressed(z2);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (f()) {
            this.f3377a.x(colorStateList);
        }
    }

    public void setRippleColorResource(int i2) {
        if (f()) {
            setRippleColor(AUX.aux.a(getContext(), i2));
        }
    }

    @Override // COM9.lpt1
    public void setShapeAppearanceModel(com7 com7Var) {
        if (!f()) {
            throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
        }
        this.f3377a.y(com7Var);
    }

    public void setShouldDrawSurfaceColorStroke(boolean z2) {
        if (f()) {
            this.f3377a.z(z2);
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (f()) {
            this.f3377a.A(colorStateList);
        }
    }

    public void setStrokeColorResource(int i2) {
        if (f()) {
            setStrokeColor(AUX.aux.a(getContext(), i2));
        }
    }

    public void setStrokeWidth(int i2) {
        if (f()) {
            this.f3377a.B(i2);
        }
    }

    public void setStrokeWidthResource(int i2) {
        if (f()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i2));
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (f()) {
            this.f3377a.C(colorStateList);
        } else {
            super.setSupportBackgroundTintList(colorStateList);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatButton
    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (f()) {
            this.f3377a.D(mode);
        } else {
            super.setSupportBackgroundTintMode(mode);
        }
    }

    @Override // android.view.View
    public void setTextAlignment(int i2) {
        super.setTextAlignment(i2);
        i(getMeasuredWidth(), getMeasuredHeight());
    }

    @Override // android.widget.Checkable
    public void toggle() {
        setChecked(!this.f3384b);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public MaterialButton(Context context, AttributeSet attributeSet, int i2) {
        int i3 = f9377f;
        super(u.c(context, attributeSet, i2, i3), attributeSet, i2);
        this.f3382a = new LinkedHashSet<>();
        this.f3384b = false;
        this.f3385c = false;
        Context context2 = getContext();
        TypedArray typedArrayH = t.h(context2, attributeSet, h4.f3162s0, i2, i3, new int[0]);
        this.f9379d = typedArrayH.getDimensionPixelSize(h4.h1, 0);
        this.f3379a = v.f(typedArrayH.getInt(h4.k1, -1), PorterDuff.Mode.SRC_IN);
        this.f3378a = b.b(getContext(), typedArrayH, h4.j1);
        this.f3380a = b.d(getContext(), typedArrayH, h4.f1);
        this.f9380e = typedArrayH.getInteger(h4.g1, 1);
        this.f3376a = typedArrayH.getDimensionPixelSize(h4.i1, 0);
        com1 com1Var = new com1(this, com7.e(context2, attributeSet, i2, i3).m());
        this.f3377a = com1Var;
        com1Var.q(typedArrayH);
        typedArrayH.recycle();
        setCompoundDrawablePadding(this.f9379d);
        h(this.f3380a != null);
    }
}
