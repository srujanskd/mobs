package b0;

import f.com8;
import java.io.IOException;
import java.util.List;
import v.a;
import v.e;
import v.g;

/* JADX INFO: loaded from: classes.dex */
public final class com3 implements a.aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f8791a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final a0.com1 f2988a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final a0.nul f2989a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<a> f2990a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final e f2991a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f8792b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f8793c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f8794d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f8795e;

    /* JADX WARN: Multi-variable type inference failed */
    public com3(a0.com1 com1Var, List<? extends a> list, int i2, a0.nul nulVar, e eVar, int i3, int i4, int i5) {
        com8.e(com1Var, "call");
        com8.e(list, "interceptors");
        com8.e(eVar, "request");
        this.f2988a = com1Var;
        this.f2990a = list;
        this.f8791a = i2;
        this.f2989a = nulVar;
        this.f2991a = eVar;
        this.f8792b = i3;
        this.f8793c = i4;
        this.f8794d = i5;
    }

    public static /* synthetic */ com3 d(com3 com3Var, int i2, a0.nul nulVar, e eVar, int i3, int i4, int i5, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i2 = com3Var.f8791a;
        }
        if ((i6 & 2) != 0) {
            nulVar = com3Var.f2989a;
        }
        a0.nul nulVar2 = nulVar;
        if ((i6 & 4) != 0) {
            eVar = com3Var.f2991a;
        }
        e eVar2 = eVar;
        if ((i6 & 8) != 0) {
            i3 = com3Var.f8792b;
        }
        int i7 = i3;
        if ((i6 & 16) != 0) {
            i4 = com3Var.f8793c;
        }
        int i8 = i4;
        if ((i6 & 32) != 0) {
            i5 = com3Var.f8794d;
        }
        return com3Var.c(i2, nulVar2, eVar2, i7, i8, i5);
    }

    @Override // v.a.aux
    public v.com1 a() {
        return this.f2988a;
    }

    @Override // v.a.aux
    public g b(e eVar) throws IOException {
        com8.e(eVar, "request");
        if (!(this.f8791a < this.f2990a.size())) {
            throw new IllegalStateException("Check failed.".toString());
        }
        this.f8795e++;
        a0.nul nulVar = this.f2989a;
        if (nulVar != null) {
            if (!nulVar.j().g(eVar.i())) {
                throw new IllegalStateException(("network interceptor " + this.f2990a.get(this.f8791a - 1) + " must retain the same host and port").toString());
            }
            if (!(this.f8795e == 1)) {
                throw new IllegalStateException(("network interceptor " + this.f2990a.get(this.f8791a - 1) + " must call proceed() exactly once").toString());
            }
        }
        com3 com3VarD = d(this, this.f8791a + 1, null, eVar, 0, 0, 0, 58, null);
        a aVar = this.f2990a.get(this.f8791a);
        g gVarA = aVar.a(com3VarD);
        if (gVarA == null) {
            throw new NullPointerException("interceptor " + aVar + " returned null");
        }
        if (this.f2989a != null) {
            if (!(this.f8791a + 1 >= this.f2990a.size() || com3VarD.f8795e == 1)) {
                throw new IllegalStateException(("network interceptor " + aVar + " must call proceed() exactly once").toString());
            }
        }
        if (gVarA.a() != null) {
            return gVarA;
        }
        throw new IllegalStateException(("interceptor " + aVar + " returned a response with no body").toString());
    }

    public final com3 c(int i2, a0.nul nulVar, e eVar, int i3, int i4, int i5) {
        com8.e(eVar, "request");
        return new com3(this.f2988a, this.f2990a, i2, nulVar, eVar, i3, i4, i5);
    }

    public final a0.com1 e() {
        return this.f2988a;
    }

    public final int f() {
        return this.f8792b;
    }

    public final a0.nul g() {
        return this.f2989a;
    }

    public final int h() {
        return this.f8793c;
    }

    public final e i() {
        return this.f2991a;
    }

    public final int j() {
        return this.f8794d;
    }

    public int k() {
        return this.f8793c;
    }

    @Override // v.a.aux
    public e request() {
        return this.f2991a;
    }
}
