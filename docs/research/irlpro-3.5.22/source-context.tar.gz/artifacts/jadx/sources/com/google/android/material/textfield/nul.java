package com.google.android.material.textfield;

import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.EditText;
import p033LPt1.d;
import p075cOM6.a4;
import p075cOM6.f4;
import p108com9.s;

/* JADX INFO: loaded from: classes.dex */
public class nul extends d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextWatcher f9669a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout.com2 f3741a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextInputLayout.com3 f3742a;

    public class aux extends s {
        public aux() {
        }

        @Override // p108com9.s, android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            nul nulVar = nul.this;
            ((d) nulVar).f957a.setChecked(!nulVar.g());
        }
    }

    public class con implements TextInputLayout.com2 {
        public con() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com2
        public void a(TextInputLayout textInputLayout) {
            EditText editText = textInputLayout.getEditText();
            nul nulVar = nul.this;
            ((d) nulVar).f957a.setChecked(!nulVar.g());
            editText.removeTextChangedListener(nul.this.f9669a);
            editText.addTextChangedListener(nul.this.f9669a);
        }
    }

    /* JADX INFO: renamed from: com.google.android.material.textfield.nul$nul, reason: collision with other inner class name */
    public class C0064nul implements TextInputLayout.com3 {

        /* JADX INFO: renamed from: com.google.android.material.textfield.nul$nul$aux */
        public class aux implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ EditText f9673a;

            public aux(EditText editText) {
                this.f9673a = editText;
            }

            @Override // java.lang.Runnable
            public void run() {
                this.f9673a.removeTextChangedListener(nul.this.f9669a);
            }
        }

        public C0064nul() {
        }

        @Override // com.google.android.material.textfield.TextInputLayout.com3
        public void a(TextInputLayout textInputLayout, int i2) {
            EditText editText = textInputLayout.getEditText();
            if (editText == null || i2 != 1) {
                return;
            }
            editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
            editText.post(new aux(editText));
        }
    }

    public class prn implements View.OnClickListener {
        public prn() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            EditText editText = ((d) nul.this).f958a.getEditText();
            if (editText == null) {
                return;
            }
            int selectionEnd = editText.getSelectionEnd();
            if (nul.this.g()) {
                editText.setTransformationMethod(null);
            } else {
                editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
            if (selectionEnd >= 0) {
                editText.setSelection(selectionEnd);
            }
            ((d) nul.this).f958a.U();
        }
    }

    public nul(TextInputLayout textInputLayout, int i2) {
        super(textInputLayout, i2);
        this.f9669a = new aux();
        this.f3741a = new con();
        this.f3742a = new C0064nul();
    }

    public static boolean h(EditText editText) {
        return editText != null && (editText.getInputType() == 16 || editText.getInputType() == 128 || editText.getInputType() == 144 || editText.getInputType() == 224);
    }

    @Override // p033LPt1.d
    public void a() {
        TextInputLayout textInputLayout = ((d) this).f958a;
        int i2 = ((d) this).f6824a;
        if (i2 == 0) {
            i2 = a4.f8868a;
        }
        textInputLayout.setEndIconDrawable(i2);
        TextInputLayout textInputLayout2 = ((d) this).f958a;
        textInputLayout2.setEndIconContentDescription(textInputLayout2.getResources().getText(f4.B));
        ((d) this).f958a.setEndIconVisible(true);
        ((d) this).f958a.setEndIconCheckable(true);
        ((d) this).f958a.setEndIconOnClickListener(new prn());
        ((d) this).f958a.g(this.f3741a);
        ((d) this).f958a.h(this.f3742a);
        EditText editText = ((d) this).f958a.getEditText();
        if (h(editText)) {
            editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
        }
    }

    public final boolean g() {
        EditText editText = ((d) this).f958a.getEditText();
        return editText != null && (editText.getTransformationMethod() instanceof PasswordTransformationMethod);
    }
}
