package COM9;

/* JADX INFO: loaded from: classes.dex */
public interface lpt1 {
    void setShapeAppearanceModel(com7 com7Var);
}
