package NUL;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import p060NUl.lpt7;
import p146nUL.m;
import p146nUL.p;
import p146nUL.q;

/* JADX INFO: loaded from: classes.dex */
public class lpt2 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static int f7397d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7398a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7399b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<p> f1375a = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1376a = false;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ArrayList<aux> f1377b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7400c = -1;

    public class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7401a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public WeakReference<p> f1379a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f7402b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f7403c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f7404d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f7405e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f7406f;

        public aux(p pVar, lpt7 lpt7Var, int i2) {
            this.f1379a = new WeakReference<>(pVar);
            this.f7401a = lpt7Var.x(pVar.f4944a);
            this.f7402b = lpt7Var.x(pVar.f4957b);
            this.f7403c = lpt7Var.x(pVar.f4965c);
            this.f7404d = lpt7Var.x(pVar.f4969d);
            this.f7405e = lpt7Var.x(pVar.f4972e);
            this.f7406f = i2;
        }
    }

    public lpt2(int i2) {
        int i3 = f7397d;
        f7397d = i3 + 1;
        this.f7398a = i3;
        this.f7399b = i2;
    }

    public boolean a(p pVar) {
        if (this.f1375a.contains(pVar)) {
            return false;
        }
        this.f1375a.add(pVar);
        return true;
    }

    public void b(ArrayList<lpt2> arrayList) {
        int size = this.f1375a.size();
        if (this.f7400c != -1 && size > 0) {
            for (int i2 = 0; i2 < arrayList.size(); i2++) {
                lpt2 lpt2Var = arrayList.get(i2);
                if (this.f7400c == lpt2Var.f7398a) {
                    g(this.f7399b, lpt2Var);
                }
            }
        }
        if (size == 0) {
            arrayList.remove(this);
        }
    }

    public int c() {
        return this.f7398a;
    }

    public int d() {
        return this.f7399b;
    }

    public final String e() {
        int i2 = this.f7399b;
        if (i2 == 0) {
            return "Horizontal";
        }
        if (i2 == 1) {
            return "Vertical";
        }
        return i2 == 2 ? "Both" : "Unknown";
    }

    public int f(lpt7 lpt7Var, int i2) {
        if (this.f1375a.size() == 0) {
            return 0;
        }
        return j(lpt7Var, this.f1375a, i2);
    }

    public void g(int i2, lpt2 lpt2Var) {
        for (p pVar : this.f1375a) {
            lpt2Var.a(pVar);
            if (i2 == 0) {
                pVar.E = lpt2Var.c();
            } else {
                pVar.F = lpt2Var.c();
            }
        }
        this.f7400c = lpt2Var.f7398a;
    }

    public void h(boolean z2) {
        this.f1376a = z2;
    }

    public void i(int i2) {
        this.f7399b = i2;
    }

    public final int j(lpt7 lpt7Var, ArrayList<p> arrayList, int i2) {
        int iX;
        int iX2;
        q qVar = (q) arrayList.get(0).I();
        lpt7Var.D();
        qVar.g(lpt7Var, false);
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            arrayList.get(i3).g(lpt7Var, false);
        }
        if (i2 == 0 && qVar.L > 0) {
            m.b(qVar, lpt7Var, arrayList, 0);
        }
        if (i2 == 1 && qVar.M > 0) {
            m.b(qVar, lpt7Var, arrayList, 1);
        }
        try {
            lpt7Var.z();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        this.f1377b = new ArrayList<>();
        for (int i4 = 0; i4 < arrayList.size(); i4++) {
            this.f1377b.add(new aux(arrayList.get(i4), lpt7Var, i2));
        }
        if (i2 == 0) {
            iX = lpt7Var.x(((p) qVar).f4944a);
            iX2 = lpt7Var.x(((p) qVar).f4965c);
            lpt7Var.D();
        } else {
            iX = lpt7Var.x(((p) qVar).f4957b);
            iX2 = lpt7Var.x(((p) qVar).f4969d);
            lpt7Var.D();
        }
        return iX2 - iX;
    }

    public String toString() {
        String str = e() + " [" + this.f7398a + "] <";
        Iterator<p> it = this.f1375a.iterator();
        while (it.hasNext()) {
            str = str + " " + it.next().r();
        }
        return str + " >";
    }
}
