package COM9;

/* JADX INFO: loaded from: classes.dex */
public class com1 extends prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f5726a = -1.0f;

    @Override // COM9.prn
    public void a(com9 com9Var, float f2, float f3, float f4) {
        com9Var.o(0.0f, f4 * f3, 180.0f, 180.0f - f2);
        double d2 = f4;
        double d3 = f3;
        com9Var.m((float) (Math.sin(Math.toRadians(f2)) * d2 * d3), (float) (Math.sin(Math.toRadians(90.0f - f2)) * d2 * d3));
    }
}
