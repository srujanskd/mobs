package COM7;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.widget.FrameLayout;

/* JADX INFO: loaded from: classes.dex */
public class con extends FrameLayout implements prn {
    @Override // COM7.prn
    public void a() {
        throw null;
    }

    @Override // COM7.prn
    public void b() {
        throw null;
    }

    @Override // android.view.View
    @SuppressLint({"MissingSuperCall"})
    public void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public Drawable getCircularRevealOverlayDrawable() {
        throw null;
    }

    @Override // COM7.prn
    public int getCircularRevealScrimColor() {
        throw null;
    }

    @Override // COM7.prn
    public prn.com1 getRevealInfo() {
        throw null;
    }

    @Override // android.view.View
    public boolean isOpaque() {
        return super.isOpaque();
    }

    @Override // COM7.prn
    public void setCircularRevealOverlayDrawable(Drawable drawable) {
        throw null;
    }

    @Override // COM7.prn
    public void setCircularRevealScrimColor(int i2) {
        throw null;
    }

    @Override // COM7.prn
    public void setRevealInfo(prn.com1 com1Var) {
        throw null;
    }
}
