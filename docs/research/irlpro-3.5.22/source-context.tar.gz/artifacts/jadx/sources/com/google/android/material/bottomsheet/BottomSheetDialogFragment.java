package com.google.android.material.bottomsheet;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatDialogFragment;
import com.newrelic.agent.android.api.v2.TraceFieldInterface;
import com.newrelic.agent.android.instrumentation.Instrumented;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public class BottomSheetDialogFragment extends AppCompatDialogFragment implements TraceFieldInterface {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f9360b;

    public class con extends BottomSheetBehavior.com2 {
        public con() {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void b(View view, float f2) {
        }

        @Override // com.google.android.material.bottomsheet.BottomSheetBehavior.com2
        public void c(View view, int i2) {
            if (i2 == 5) {
                BottomSheetDialogFragment.this.k();
            }
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    public void dismiss() {
        if (m(false)) {
            return;
        }
        super.dismiss();
    }

    @Override // androidx.fragment.app.DialogFragment
    public void dismissAllowingStateLoss() {
        if (m(true)) {
            return;
        }
        super.dismissAllowingStateLoss();
    }

    public final void k() {
        if (this.f9360b) {
            super.dismissAllowingStateLoss();
        } else {
            super.dismiss();
        }
    }

    public final void l(BottomSheetBehavior<?> bottomSheetBehavior, boolean z2) {
        this.f9360b = z2;
        if (bottomSheetBehavior.j0() == 5) {
            k();
            return;
        }
        if (getDialog() instanceof com.google.android.material.bottomsheet.aux) {
            ((com.google.android.material.bottomsheet.aux) getDialog()).n();
        }
        bottomSheetBehavior.W(new con());
        bottomSheetBehavior.H0(5);
    }

    public final boolean m(boolean z2) {
        Dialog dialog = getDialog();
        if (!(dialog instanceof com.google.android.material.bottomsheet.aux)) {
            return false;
        }
        com.google.android.material.bottomsheet.aux auxVar = (com.google.android.material.bottomsheet.aux) dialog;
        BottomSheetBehavior<FrameLayout> bottomSheetBehaviorL = auxVar.l();
        if (!bottomSheetBehaviorL.n0() || !auxVar.m()) {
            return false;
        }
        l(bottomSheetBehaviorL, z2);
        return true;
    }

    @Override // androidx.appcompat.app.AppCompatDialogFragment, androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        return new com.google.android.material.bottomsheet.aux(getContext(), getTheme());
    }
}
