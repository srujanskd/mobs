package LPT1;

import java.math.BigInteger;

/* JADX INFO: loaded from: classes.dex */
public final class lpt2 extends com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f6584a;

    public lpt2(Boolean bool) {
        this.f6584a = p052Lpt2.com6.b(bool);
    }

    public static boolean o(lpt2 lpt2Var) {
        Object obj = lpt2Var.f6584a;
        if (!(obj instanceof Number)) {
            return false;
        }
        Number number = (Number) obj;
        return (number instanceof BigInteger) || (number instanceof Long) || (number instanceof Integer) || (number instanceof Short) || (number instanceof Byte);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || lpt2.class != obj.getClass()) {
            return false;
        }
        lpt2 lpt2Var = (lpt2) obj;
        if (this.f6584a == null) {
            return lpt2Var.f6584a == null;
        }
        if (o(this) && o(lpt2Var)) {
            return l().longValue() == lpt2Var.l().longValue();
        }
        Object obj2 = this.f6584a;
        if (!(obj2 instanceof Number) || !(lpt2Var.f6584a instanceof Number)) {
            return obj2.equals(lpt2Var.f6584a);
        }
        double dDoubleValue = l().doubleValue();
        double dDoubleValue2 = lpt2Var.l().doubleValue();
        if (dDoubleValue != dDoubleValue2) {
            return Double.isNaN(dDoubleValue) && Double.isNaN(dDoubleValue2);
        }
        return true;
    }

    public boolean h() {
        return n() ? ((Boolean) this.f6584a).booleanValue() : Boolean.parseBoolean(m());
    }

    public int hashCode() {
        long jDoubleToLongBits;
        if (this.f6584a == null) {
            return 31;
        }
        if (o(this)) {
            jDoubleToLongBits = l().longValue();
        } else {
            Object obj = this.f6584a;
            if (!(obj instanceof Number)) {
                return obj.hashCode();
            }
            jDoubleToLongBits = Double.doubleToLongBits(l().doubleValue());
        }
        return (int) ((jDoubleToLongBits >>> 32) ^ jDoubleToLongBits);
    }

    public double i() {
        return p() ? l().doubleValue() : Double.parseDouble(m());
    }

    public int j() {
        return p() ? l().intValue() : Integer.parseInt(m());
    }

    public long k() {
        return p() ? l().longValue() : Long.parseLong(m());
    }

    public Number l() {
        Object obj = this.f6584a;
        return obj instanceof String ? new p052Lpt2.lpt3((String) obj) : (Number) obj;
    }

    public String m() {
        if (p()) {
            return l().toString();
        }
        return n() ? ((Boolean) this.f6584a).toString() : (String) this.f6584a;
    }

    public boolean n() {
        return this.f6584a instanceof Boolean;
    }

    public boolean p() {
        return this.f6584a instanceof Number;
    }

    public boolean q() {
        return this.f6584a instanceof String;
    }

    public lpt2(Number number) {
        this.f6584a = p052Lpt2.com6.b(number);
    }

    public lpt2(String str) {
        this.f6584a = p052Lpt2.com6.b(str);
    }
}
