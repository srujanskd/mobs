package androidx.lifecycle;

import COM3.lpt5;
import COM3.lpt6;
import android.app.Application;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public class com7 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt6 f8406a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final con f2624a;

    public static class aux extends prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static aux f8407a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Application f2625a;

        public aux(Application application) {
            this.f2625a = application;
        }

        public static aux c(Application application) {
            if (f8407a == null) {
                f8407a = new aux(application);
            }
            return f8407a;
        }

        @Override // androidx.lifecycle.com7.prn, androidx.lifecycle.com7.con
        public <T extends lpt5> T a(Class<T> cls) {
            if (!COM3.aux.class.isAssignableFrom(cls)) {
                return (T) super.a(cls);
            }
            try {
                return cls.getConstructor(Application.class).newInstance(this.f2625a);
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            } catch (NoSuchMethodException e4) {
                throw new RuntimeException("Cannot create an instance of " + cls, e4);
            } catch (InvocationTargetException e5) {
                throw new RuntimeException("Cannot create an instance of " + cls, e5);
            }
        }
    }

    public static class com1 {
        public void b(lpt5 lpt5Var) {
        }
    }

    public interface con {
        <T extends lpt5> T a(Class<T> cls);
    }

    public static abstract class nul extends com1 implements con {
        public <T extends lpt5> T a(Class<T> cls) {
            throw new UnsupportedOperationException("create(String, Class<?>) must be called on implementaions of KeyedFactory");
        }

        public abstract <T extends lpt5> T c(String str, Class<T> cls);
    }

    public static class prn implements con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static prn f8408a;

        public static prn b() {
            if (f8408a == null) {
                f8408a = new prn();
            }
            return f8408a;
        }

        @Override // androidx.lifecycle.com7.con
        public <T extends lpt5> T a(Class<T> cls) {
            try {
                return cls.newInstance();
            } catch (IllegalAccessException e2) {
                throw new RuntimeException("Cannot create an instance of " + cls, e2);
            } catch (InstantiationException e3) {
                throw new RuntimeException("Cannot create an instance of " + cls, e3);
            }
        }
    }

    public com7(lpt6 lpt6Var, con conVar) {
        this.f2624a = conVar;
        this.f8406a = lpt6Var;
    }

    public <T extends lpt5> T a(Class<T> cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName == null) {
            throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
        }
        return (T) b("androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName, cls);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public <T extends lpt5> T b(String str, Class<T> cls) {
        T t2 = (T) this.f8406a.b(str);
        if (cls.isInstance(t2)) {
            Object obj = this.f2624a;
            if (obj instanceof com1) {
                ((com1) obj).b(t2);
            }
            return t2;
        }
        con conVar = this.f2624a;
        T t3 = conVar instanceof nul ? (T) ((nul) conVar).c(str, cls) : (T) conVar.a(cls);
        this.f8406a.d(str, t3);
        return t3;
    }
}
