package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class com8 {
    public static int a(RecyclerView.e eVar, com5 com5Var, View view, View view2, RecyclerView.lpt2 lpt2Var, boolean z2) {
        if (lpt2Var.J() == 0 || eVar.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z2) {
            return Math.abs(lpt2Var.h0(view) - lpt2Var.h0(view2)) + 1;
        }
        return Math.min(com5Var.n(), com5Var.d(view2) - com5Var.g(view));
    }

    public static int b(RecyclerView.e eVar, com5 com5Var, View view, View view2, RecyclerView.lpt2 lpt2Var, boolean z2, boolean z3) {
        if (lpt2Var.J() == 0 || eVar.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        int iMax = z3 ? Math.max(0, (eVar.b() - Math.max(lpt2Var.h0(view), lpt2Var.h0(view2))) - 1) : Math.max(0, Math.min(lpt2Var.h0(view), lpt2Var.h0(view2)));
        if (z2) {
            return Math.round((iMax * (Math.abs(com5Var.d(view2) - com5Var.g(view)) / (Math.abs(lpt2Var.h0(view) - lpt2Var.h0(view2)) + 1))) + (com5Var.m() - com5Var.g(view)));
        }
        return iMax;
    }

    public static int c(RecyclerView.e eVar, com5 com5Var, View view, View view2, RecyclerView.lpt2 lpt2Var, boolean z2) {
        if (lpt2Var.J() == 0 || eVar.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z2) {
            return eVar.b();
        }
        return (int) (((com5Var.d(view2) - com5Var.g(view)) / (Math.abs(lpt2Var.h0(view) - lpt2Var.h0(view2)) + 1)) * eVar.b());
    }
}
