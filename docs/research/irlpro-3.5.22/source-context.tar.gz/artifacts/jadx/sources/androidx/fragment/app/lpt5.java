package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import p015CoM3.q;
import p024Com2.y;
import p092coM3.l0;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ViewGroup f8323a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<com1> f2551a = new ArrayList<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList<com1> f8324b = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2552a = false;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2553b = false;

    public class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ prn f8325a;

        public aux(prn prnVar) {
            this.f8325a = prnVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (lpt5.this.f2551a.contains(this.f8325a)) {
                this.f8325a.e().a(this.f8325a.f().mView);
            }
        }
    }

    public static class com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Fragment f8326a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public con f2555a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public nul f2556a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final List<Runnable> f2558a = new ArrayList();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final HashSet<p013CoM1.com7> f2557a = new HashSet<>();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2559a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f8327b = false;

        public class aux implements CoM1.com7.con {
            public aux() {
            }

            @Override // CoM1.com7.con
            public void onCancel() {
                com1.this.b();
            }
        }

        public enum con {
            NONE,
            ADDING,
            REMOVING
        }

        public enum nul {
            REMOVED,
            VISIBLE,
            GONE,
            INVISIBLE;

            public static nul c(int i2) {
                if (i2 == 0) {
                    return VISIBLE;
                }
                if (i2 == 4) {
                    return INVISIBLE;
                }
                if (i2 == 8) {
                    return GONE;
                }
                throw new IllegalArgumentException("Unknown visibility " + i2);
            }

            public static nul d(View view) {
                return (view.getAlpha() == 0.0f && view.getVisibility() == 0) ? INVISIBLE : c(view.getVisibility());
            }

            public void a(View view) {
                int i2 = nul.f8337a[ordinal()];
                if (i2 == 1) {
                    ViewGroup viewGroup = (ViewGroup) view.getParent();
                    if (viewGroup != null) {
                        if (com6.H0(2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Removing view " + view + " from container " + viewGroup);
                        }
                        viewGroup.removeView(view);
                        return;
                    }
                    return;
                }
                if (i2 == 2) {
                    if (com6.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to VISIBLE");
                    }
                    view.setVisibility(0);
                    return;
                }
                if (i2 == 3) {
                    if (com6.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to GONE");
                    }
                    view.setVisibility(8);
                    return;
                }
                if (i2 != 4) {
                    return;
                }
                if (com6.H0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: Setting view " + view + " to INVISIBLE");
                }
                view.setVisibility(4);
            }
        }

        public com1(nul nulVar, con conVar, Fragment fragment, p013CoM1.com7 com7Var) {
            this.f2556a = nulVar;
            this.f2555a = conVar;
            this.f8326a = fragment;
            com7Var.c(new aux());
        }

        public final void a(Runnable runnable) {
            this.f2558a.add(runnable);
        }

        public final void b() {
            if (h()) {
                return;
            }
            this.f2559a = true;
            if (this.f2557a.isEmpty()) {
                c();
                return;
            }
            Iterator it = new ArrayList(this.f2557a).iterator();
            while (it.hasNext()) {
                ((p013CoM1.com7) it.next()).a();
            }
        }

        public void c() {
            if (this.f8327b) {
                return;
            }
            if (com6.H0(2)) {
                Log.v("FragmentManager", "SpecialEffectsController: " + this + " has called complete.");
            }
            this.f8327b = true;
            Iterator<Runnable> it = this.f2558a.iterator();
            while (it.hasNext()) {
                it.next().run();
            }
        }

        public final void d(p013CoM1.com7 com7Var) {
            if (this.f2557a.remove(com7Var) && this.f2557a.isEmpty()) {
                c();
            }
        }

        public nul e() {
            return this.f2556a;
        }

        public final Fragment f() {
            return this.f8326a;
        }

        public con g() {
            return this.f2555a;
        }

        public final boolean h() {
            return this.f2559a;
        }

        public final boolean i() {
            return this.f8327b;
        }

        public final void j(p013CoM1.com7 com7Var) {
            l();
            this.f2557a.add(com7Var);
        }

        public final void k(nul nulVar, con conVar) {
            int i2 = nul.f8338b[conVar.ordinal()];
            if (i2 == 1) {
                if (this.f2556a == nul.REMOVED) {
                    if (com6.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.f8326a + " mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = " + this.f2555a + " to ADDING.");
                    }
                    this.f2556a = nul.VISIBLE;
                    this.f2555a = con.ADDING;
                    return;
                }
                return;
            }
            if (i2 == 2) {
                if (com6.H0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.f8326a + " mFinalState = " + this.f2556a + " -> REMOVED. mLifecycleImpact  = " + this.f2555a + " to REMOVING.");
                }
                this.f2556a = nul.REMOVED;
                this.f2555a = con.REMOVING;
                return;
            }
            if (i2 == 3 && this.f2556a != nul.REMOVED) {
                if (com6.H0(2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + this.f8326a + " mFinalState = " + this.f2556a + " -> " + nulVar + ". ");
                }
                this.f2556a = nulVar;
            }
        }

        public void l() {
        }

        public String toString() {
            return "Operation {" + Integer.toHexString(System.identityHashCode(this)) + "} {mFinalState = " + this.f2556a + "} {mLifecycleImpact = " + this.f2555a + "} {mFragment = " + this.f8326a + "}";
        }
    }

    public class con implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ prn f8336a;

        public con(prn prnVar) {
            this.f8336a = prnVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            lpt5.this.f2551a.remove(this.f8336a);
            lpt5.this.f8324b.remove(this.f8336a);
        }
    }

    public static /* synthetic */ class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8337a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public static final /* synthetic */ int[] f8338b;

        static {
            int[] iArr = new int[com1.con.values().length];
            f8338b = iArr;
            try {
                iArr[com1.con.ADDING.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8338b[com1.con.REMOVING.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8338b[com1.con.NONE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            int[] iArr2 = new int[com1.nul.values().length];
            f8337a = iArr2;
            try {
                iArr2[com1.nul.REMOVED.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f8337a[com1.nul.VISIBLE.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f8337a[com1.nul.GONE.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f8337a[com1.nul.INVISIBLE.ordinal()] = 4;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    public static class prn extends com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final lpt1 f8339a;

        public prn(com1.nul nulVar, com1.con conVar, lpt1 lpt1Var, p013CoM1.com7 com7Var) {
            super(nulVar, conVar, lpt1Var.k(), com7Var);
            this.f8339a = lpt1Var;
        }

        @Override // androidx.fragment.app.lpt5.com1
        public void c() {
            super.c();
            this.f8339a.m();
        }

        @Override // androidx.fragment.app.lpt5.com1
        public void l() {
            if (g() == com1.con.ADDING) {
                Fragment fragmentK = this.f8339a.k();
                View viewFindFocus = fragmentK.mView.findFocus();
                if (viewFindFocus != null) {
                    fragmentK.setFocusedView(viewFindFocus);
                    if (com6.H0(2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + fragmentK);
                    }
                }
                View viewRequireView = f().requireView();
                if (viewRequireView.getParent() == null) {
                    this.f8339a.b();
                    viewRequireView.setAlpha(0.0f);
                }
                if (viewRequireView.getAlpha() == 0.0f && viewRequireView.getVisibility() == 0) {
                    viewRequireView.setVisibility(4);
                }
                viewRequireView.setAlpha(fragmentK.getPostOnViewCreatedAlpha());
            }
        }
    }

    public lpt5(ViewGroup viewGroup) {
        this.f8323a = viewGroup;
    }

    public static lpt5 n(ViewGroup viewGroup, q qVar) {
        int i2 = l0.f9200b;
        Object tag = viewGroup.getTag(i2);
        if (tag instanceof lpt5) {
            return (lpt5) tag;
        }
        lpt5 lpt5VarA = qVar.a(viewGroup);
        viewGroup.setTag(i2, lpt5VarA);
        return lpt5VarA;
    }

    public static lpt5 o(ViewGroup viewGroup, com6 com6Var) {
        return n(viewGroup, com6Var.A0());
    }

    public final void a(com1.nul nulVar, com1.con conVar, lpt1 lpt1Var) {
        synchronized (this.f2551a) {
            p013CoM1.com7 com7Var = new p013CoM1.com7();
            com1 com1VarH = h(lpt1Var.k());
            if (com1VarH != null) {
                com1VarH.k(nulVar, conVar);
                return;
            }
            prn prnVar = new prn(nulVar, conVar, lpt1Var, com7Var);
            this.f2551a.add(prnVar);
            prnVar.a(new aux(prnVar));
            prnVar.a(new con(prnVar));
        }
    }

    public void b(com1.nul nulVar, lpt1 lpt1Var) {
        if (com6.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing add operation for fragment " + lpt1Var.k());
        }
        a(nulVar, com1.con.ADDING, lpt1Var);
    }

    public void c(lpt1 lpt1Var) {
        if (com6.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing hide operation for fragment " + lpt1Var.k());
        }
        a(com1.nul.GONE, com1.con.NONE, lpt1Var);
    }

    public void d(lpt1 lpt1Var) {
        if (com6.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing remove operation for fragment " + lpt1Var.k());
        }
        a(com1.nul.REMOVED, com1.con.REMOVING, lpt1Var);
    }

    public void e(lpt1 lpt1Var) {
        if (com6.H0(2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing show operation for fragment " + lpt1Var.k());
        }
        a(com1.nul.VISIBLE, com1.con.NONE, lpt1Var);
    }

    public abstract void f(List<com1> list, boolean z2);

    public void g() {
        if (this.f2553b) {
            return;
        }
        if (!y.R(this.f8323a)) {
            j();
            this.f2552a = false;
            return;
        }
        synchronized (this.f2551a) {
            if (!this.f2551a.isEmpty()) {
                ArrayList<com1> arrayList = new ArrayList(this.f8324b);
                this.f8324b.clear();
                for (com1 com1Var : arrayList) {
                    if (com6.H0(2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Cancelling operation " + com1Var);
                    }
                    com1Var.b();
                    if (!com1Var.i()) {
                        this.f8324b.add(com1Var);
                    }
                }
                q();
                ArrayList arrayList2 = new ArrayList(this.f2551a);
                this.f2551a.clear();
                this.f8324b.addAll(arrayList2);
                Iterator it = arrayList2.iterator();
                while (it.hasNext()) {
                    ((com1) it.next()).l();
                }
                f(arrayList2, this.f2552a);
                this.f2552a = false;
            }
        }
    }

    public final com1 h(Fragment fragment) {
        for (com1 com1Var : this.f2551a) {
            if (com1Var.f().equals(fragment) && !com1Var.h()) {
                return com1Var;
            }
        }
        return null;
    }

    public final com1 i(Fragment fragment) {
        for (com1 com1Var : this.f8324b) {
            if (com1Var.f().equals(fragment) && !com1Var.h()) {
                return com1Var;
            }
        }
        return null;
    }

    public void j() {
        boolean zR = y.R(this.f8323a);
        synchronized (this.f2551a) {
            q();
            Iterator<com1> it = this.f2551a.iterator();
            while (it.hasNext()) {
                it.next().l();
            }
            for (com1 com1Var : new ArrayList(this.f8324b)) {
                if (com6.H0(2)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("SpecialEffectsController: ");
                    sb.append(zR ? "" : "Container " + this.f8323a + " is not attached to window. ");
                    sb.append("Cancelling running operation ");
                    sb.append(com1Var);
                    Log.v("FragmentManager", sb.toString());
                }
                com1Var.b();
            }
            for (com1 com1Var2 : new ArrayList(this.f2551a)) {
                if (com6.H0(2)) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("SpecialEffectsController: ");
                    sb2.append(zR ? "" : "Container " + this.f8323a + " is not attached to window. ");
                    sb2.append("Cancelling pending operation ");
                    sb2.append(com1Var2);
                    Log.v("FragmentManager", sb2.toString());
                }
                com1Var2.b();
            }
        }
    }

    public void k() {
        if (this.f2553b) {
            this.f2553b = false;
            g();
        }
    }

    public com1.con l(lpt1 lpt1Var) {
        com1 com1VarH = h(lpt1Var.k());
        com1.con conVarG = com1VarH != null ? com1VarH.g() : null;
        com1 com1VarI = i(lpt1Var.k());
        return (com1VarI == null || !(conVarG == null || conVarG == com1.con.NONE)) ? conVarG : com1VarI.g();
    }

    public ViewGroup m() {
        return this.f8323a;
    }

    public void p() {
        synchronized (this.f2551a) {
            q();
            this.f2553b = false;
            for (int size = this.f2551a.size() - 1; size >= 0; size--) {
                com1 com1Var = this.f2551a.get(size);
                com1.nul nulVarD = com1.nul.d(com1Var.f().mView);
                com1.nul nulVarE = com1Var.e();
                com1.nul nulVar = com1.nul.VISIBLE;
                if (nulVarE == nulVar && nulVarD != nulVar) {
                    this.f2553b = com1Var.f().isPostponed();
                    break;
                }
            }
        }
    }

    public final void q() {
        for (com1 com1Var : this.f2551a) {
            if (com1Var.g() == com1.con.ADDING) {
                com1Var.k(com1.nul.c(com1Var.f().requireView().getVisibility()), com1.con.NONE);
            }
        }
    }

    public void r(boolean z2) {
        this.f2552a = z2;
    }
}
