package COM6;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public interface com7<T extends View> {
}
