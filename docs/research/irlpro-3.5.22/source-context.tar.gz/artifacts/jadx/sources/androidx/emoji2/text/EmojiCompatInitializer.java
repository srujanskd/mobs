package androidx.emoji2.text;

import COM3.com7;
import android.content.Context;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import p013CoM1.com8;
import p025Com3.t;
import p027Com5.x;
import p027Com5.y;

/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements y<Boolean> {

    public static class aux extends androidx.emoji2.text.con.nul {
        public aux(Context context) {
            super(new con(context));
            b(1);
        }
    }

    public static class con implements androidx.emoji2.text.con.com3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Context f8182a;

        public class aux extends androidx.emoji2.text.con.com4 {

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ androidx.emoji2.text.con.com4 f2334a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ ThreadPoolExecutor f2335a;

            public aux(androidx.emoji2.text.con.com4 com4Var, ThreadPoolExecutor threadPoolExecutor) {
                this.f2334a = com4Var;
                this.f2335a = threadPoolExecutor;
            }

            @Override // androidx.emoji2.text.con.com4
            public void a(Throwable th) {
                try {
                    this.f2334a.a(th);
                } finally {
                    this.f2335a.shutdown();
                }
            }

            @Override // androidx.emoji2.text.con.com4
            public void b(com1 com1Var) {
                try {
                    this.f2334a.b(com1Var);
                } finally {
                    this.f2335a.shutdown();
                }
            }
        }

        public con(Context context) {
            this.f8182a = context.getApplicationContext();
        }

        @Override // androidx.emoji2.text.con.com3
        public void a(final androidx.emoji2.text.con.com4 com4Var) {
            final ThreadPoolExecutor threadPoolExecutorB = t.b("EmojiCompatInitializer");
            threadPoolExecutorB.execute(new Runnable() { // from class: Com3.u
                @Override // java.lang.Runnable
                public final void run() {
                    this.f6492a.d(com4Var, threadPoolExecutorB);
                }
            });
        }

        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public void d(androidx.emoji2.text.con.com4 com4Var, ThreadPoolExecutor threadPoolExecutor) {
            try {
                prn prnVarA = androidx.emoji2.text.aux.a(this.f8182a);
                if (prnVarA == null) {
                    throw new RuntimeException("EmojiCompat font provider not available on this device.");
                }
                prnVarA.c(threadPoolExecutor);
                prnVarA.a().a(new aux(com4Var, threadPoolExecutor));
            } catch (Throwable th) {
                com4Var.a(th);
                threadPoolExecutor.shutdown();
            }
        }
    }

    public static class nul implements Runnable {
        @Override // java.lang.Runnable
        public void run() {
            try {
                com8.a("EmojiCompat.EmojiCompatInitializer.run");
                if (androidx.emoji2.text.con.h()) {
                    androidx.emoji2.text.con.b().k();
                }
            } finally {
                com8.b();
            }
        }
    }

    @Override // p027Com5.y
    public List<Class<? extends y<?>>> a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // p027Com5.y
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Boolean b(Context context) {
        androidx.emoji2.text.con.g(new aux(context));
        d(context);
        return Boolean.TRUE;
    }

    public void d(Context context) {
        final androidx.lifecycle.nul lifecycle = ((com7) x.c(context).d(ProcessLifecycleInitializer.class)).getLifecycle();
        lifecycle.a(new COM3.con() { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // COM3.com1
            public void g(com7 com7Var) {
                EmojiCompatInitializer.this.e();
                lifecycle.c(this);
            }
        });
    }

    public void e() {
        t.d().postDelayed(new nul(), 500L);
    }
}
