package androidx.appcompat.view.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class prn extends BaseAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7843a = -1;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final LayoutInflater f1927a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1928a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f7844b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1929b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f7845c;

    public prn(com1 com1Var, LayoutInflater layoutInflater, boolean z2, int i2) {
        this.f7845c = z2;
        this.f1927a = layoutInflater;
        this.f1928a = com1Var;
        this.f7844b = i2;
        a();
    }

    public void a() {
        com3 com3VarV = this.f1928a.v();
        if (com3VarV != null) {
            ArrayList<com3> arrayListZ = this.f1928a.z();
            int size = arrayListZ.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (arrayListZ.get(i2) == com3VarV) {
                    this.f7843a = i2;
                    return;
                }
            }
        }
        this.f7843a = -1;
    }

    public com1 b() {
        return this.f1928a;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public com3 getItem(int i2) {
        ArrayList<com3> arrayListZ = this.f7845c ? this.f1928a.z() : this.f1928a.E();
        int i3 = this.f7843a;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return arrayListZ.get(i2);
    }

    public void d(boolean z2) {
        this.f1929b = z2;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ArrayList<com3> arrayListZ = this.f7845c ? this.f1928a.z() : this.f1928a.E();
        return this.f7843a < 0 ? arrayListZ.size() : arrayListZ.size() - 1;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f1927a.inflate(this.f7844b, viewGroup, false);
        }
        int groupId = getItem(i2).getGroupId();
        int i3 = i2 - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f1928a.F() && groupId != (i3 >= 0 ? getItem(i3).getGroupId() : groupId));
        com6.aux auxVar = (com6.aux) view;
        if (this.f1929b) {
            listMenuItemView.setForceShowIcon(true);
        }
        auxVar.b(getItem(i2), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
