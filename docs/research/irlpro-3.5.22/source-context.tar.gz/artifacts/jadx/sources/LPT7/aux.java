package LPT7;

import java.util.function.UnaryOperator;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class aux implements UnaryOperator {
    @Override // java.util.function.Function
    public final Object apply(Object obj) {
        return ((inet.ipaddr.ipv6.aux) obj).getLower();
    }
}
