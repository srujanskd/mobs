package com.newrelic.agent.android;

import com.newrelic.agent.android.api.common.TransactionData;
import com.newrelic.agent.android.api.v1.Defaults;
import com.newrelic.agent.android.harvest.ApplicationInformation;
import com.newrelic.agent.android.harvest.DeviceInformation;
import com.newrelic.agent.android.harvest.EnvironmentInformation;
import com.newrelic.agent.android.stats.TicToc;
import com.newrelic.agent.android.util.Encoder;
import inet.ipaddr.aux;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class NullAgentImpl implements AgentImpl {
    public static final NullAgentImpl instance = new NullAgentImpl();
    private int responseBodyLimit = Defaults.RESPONSE_BODY_LIMIT;
    private TicToc sessionDurationMillis = new TicToc();

    @Override // com.newrelic.agent.android.AgentImpl
    public void addTransactionData(TransactionData transactionData) {
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public void disable() {
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public List<TransactionData> getAndClearTransactionData() {
        return new ArrayList();
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public ApplicationInformation getApplicationInformation() {
        return new ApplicationInformation("null", "0.0", "null", aux.OCTAL_PREFIX);
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public String getCrossProcessId() {
        return null;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public DeviceInformation getDeviceInformation() {
        DeviceInformation deviceInformation = new DeviceInformation();
        deviceInformation.setOsName("Android");
        deviceInformation.setOsVersion("2.3");
        deviceInformation.setOsBuild("a.b.c");
        deviceInformation.setManufacturer("Fake");
        deviceInformation.setModel("NullAgent");
        deviceInformation.setAgentName("AndroidAgent");
        deviceInformation.setAgentVersion("2.123");
        deviceInformation.setDeviceId("389C9738-A761-44DE-8A66-1668CFD67DA1");
        deviceInformation.setArchitecture("Fake Arch");
        deviceInformation.setRunTime("1.8.0");
        deviceInformation.setSize("Fake Size");
        return deviceInformation;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public Encoder getEncoder() {
        return new Encoder() { // from class: com.newrelic.agent.android.NullAgentImpl.1
            @Override // com.newrelic.agent.android.util.Encoder
            public String encode(byte[] bArr) {
                return new String(bArr);
            }

            @Override // com.newrelic.agent.android.util.Encoder
            public String encodeNoWrap(byte[] bArr) {
                return encode(bArr);
            }
        };
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public EnvironmentInformation getEnvironmentInformation() {
        return new EnvironmentInformation(0L, 1, "none", "none", new long[]{0, 0});
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public String getNetworkCarrier() {
        return "unknown";
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public String getNetworkWanType() {
        return "unknown";
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public int getResponseBodyLimit() {
        return this.responseBodyLimit;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public long getSessionDurationMillis() {
        return this.sessionDurationMillis.peek();
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public int getStackTraceLimit() {
        return 0;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public boolean hasReachableNetworkConnection(String str) {
        return true;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public boolean isDisabled() {
        return true;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public boolean isInstantApp() {
        return false;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public void mergeTransactionData(List<TransactionData> list) {
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public void setLocation(String str, String str2) {
    }

    public void setResponseBodyLimit(int i2) {
        this.responseBodyLimit = i2;
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public void start() {
        this.sessionDurationMillis.tic();
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public void stop() {
        this.sessionDurationMillis.toc();
    }

    @Override // com.newrelic.agent.android.AgentImpl
    public boolean updateSavedConnectInformation() {
        return false;
    }
}
