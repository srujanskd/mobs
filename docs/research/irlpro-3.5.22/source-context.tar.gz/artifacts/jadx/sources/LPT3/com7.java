package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;
import p139lpt3.d0;

/* JADX INFO: loaded from: classes.dex */
public final class com7 extends lpt4 {
    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int length = str.length();
        if (length == 7) {
            try {
                str = str + lpt3.b(str);
            } catch (d0 e2) {
                throw new IllegalArgumentException(e2);
            }
        } else {
            if (length != 8) {
                throw new IllegalArgumentException("Requested contents should be 7 or 8 digits long, but got ".concat(String.valueOf(length)));
            }
            try {
                if (!lpt3.a(str)) {
                    throw new IllegalArgumentException("Contents do not pass checksum");
                }
            } catch (d0 unused) {
                throw new IllegalArgumentException("Illegal contents");
            }
        }
        lpt1.c(str);
        boolean[] zArr = new boolean[67];
        int iB = lpt1.b(zArr, 0, lpt3.f6632a, true) + 0;
        for (int i2 = 0; i2 <= 3; i2++) {
            iB += lpt1.b(zArr, iB, lpt3.f860a[Character.digit(str.charAt(i2), 10)], false);
        }
        int iB2 = iB + lpt1.b(zArr, iB, lpt3.f6633b, false);
        for (int i3 = 4; i3 <= 7; i3++) {
            iB2 += lpt1.b(zArr, iB2, lpt3.f860a[Character.digit(str.charAt(i3), 10)], true);
        }
        lpt1.b(zArr, iB2, lpt3.f6632a, true);
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.EAN_8);
    }
}
