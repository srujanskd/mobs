package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public class lpt2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public aux f8680a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final con f2881a;

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8681a = 0;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8682b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8683c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8684d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8685e;

        public void a(int i2) {
            this.f8681a = i2 | this.f8681a;
        }

        public boolean b() {
            int i2 = this.f8681a;
            if ((i2 & 7) != 0 && (i2 & (c(this.f8684d, this.f8682b) << 0)) == 0) {
                return false;
            }
            int i3 = this.f8681a;
            if ((i3 & 112) != 0 && (i3 & (c(this.f8684d, this.f8683c) << 4)) == 0) {
                return false;
            }
            int i4 = this.f8681a;
            if ((i4 & inet.ipaddr.ipv6.nul.com4.COMPRESSION_LARGEST) != 0 && (i4 & (c(this.f8685e, this.f8682b) << 8)) == 0) {
                return false;
            }
            int i5 = this.f8681a;
            return (i5 & 28672) == 0 || (i5 & (c(this.f8685e, this.f8683c) << 12)) != 0;
        }

        public int c(int i2, int i3) {
            if (i2 > i3) {
                return 1;
            }
            return i2 == i3 ? 2 : 4;
        }

        public void d() {
            this.f8681a = 0;
        }

        public void e(int i2, int i3, int i4, int i5) {
            this.f8682b = i2;
            this.f8683c = i3;
            this.f8684d = i4;
            this.f8685e = i5;
        }
    }

    public interface con {
        View a(int i2);

        int b(View view);

        int c();

        int d();

        int e(View view);
    }

    public lpt2(con conVar) {
        this.f2881a = conVar;
    }

    public View a(int i2, int i3, int i4, int i5) {
        int iC = this.f2881a.c();
        int iD = this.f2881a.d();
        int i6 = i3 > i2 ? 1 : -1;
        View view = null;
        while (i2 != i3) {
            View viewA = this.f2881a.a(i2);
            this.f8680a.e(iC, iD, this.f2881a.b(viewA), this.f2881a.e(viewA));
            if (i4 != 0) {
                this.f8680a.d();
                this.f8680a.a(i4);
                if (this.f8680a.b()) {
                    return viewA;
                }
            }
            if (i5 != 0) {
                this.f8680a.d();
                this.f8680a.a(i5);
                if (this.f8680a.b()) {
                    view = viewA;
                }
            }
            i2 += i6;
        }
        return view;
    }

    public boolean b(View view, int i2) {
        this.f8680a.e(this.f2881a.c(), this.f2881a.d(), this.f2881a.b(view), this.f2881a.e(view));
        if (i2 == 0) {
            return false;
        }
        this.f8680a.d();
        this.f8680a.a(i2);
        return this.f8680a.b();
    }
}
