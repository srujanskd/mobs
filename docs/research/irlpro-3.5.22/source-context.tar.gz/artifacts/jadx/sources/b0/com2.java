package b0;

import f.com8;

/* JADX INFO: loaded from: classes.dex */
public final class com2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final com2 f8790a = new com2();

    public static final boolean a(String str) {
        com8.e(str, "method");
        return (com8.a(str, "GET") || com8.a(str, "HEAD")) ? false : true;
    }

    public static final boolean d(String str) {
        com8.e(str, "method");
        return com8.a(str, "POST") || com8.a(str, "PUT") || com8.a(str, "PATCH") || com8.a(str, "PROPPATCH") || com8.a(str, "REPORT");
    }

    public final boolean b(String str) {
        com8.e(str, "method");
        return !com8.a(str, "PROPFIND");
    }

    public final boolean c(String str) {
        com8.e(str, "method");
        return com8.a(str, "PROPFIND");
    }
}
