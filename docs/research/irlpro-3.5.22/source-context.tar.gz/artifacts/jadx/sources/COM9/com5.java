package COM9;

import android.graphics.RectF;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class com5 implements nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f5738a;

    public com5(float f2) {
        this.f5738a = f2;
    }

    @Override // COM9.nul
    public float a(RectF rectF) {
        return this.f5738a * rectF.height();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof com5) && this.f5738a == ((com5) obj).f5738a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f5738a)});
    }
}
