package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import p013CoM1.com8;
import p023Com1.p;
import p025Com3.t;
import p070cOM1.u;
import p070cOM1.w;
import p101com2.u2;

/* JADX INFO: loaded from: classes.dex */
public class prn extends androidx.emoji2.text.con.nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f8202a = new aux();

    public static class aux {
        public Typeface a(Context context, w.con conVar) throws PackageManager.NameNotFoundException {
            return w.a(context, null, new w.con[]{conVar});
        }

        public w.aux b(Context context, u uVar) throws PackageManager.NameNotFoundException {
            return w.b(context, null, uVar);
        }

        public void c(Context context, ContentObserver contentObserver) {
            context.getContentResolver().unregisterContentObserver(contentObserver);
        }
    }

    public static class con implements androidx.emoji2.text.con.com3 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Context f8203a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ContentObserver f2372a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Handler f2373a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.emoji2.text.con.com4 f2374a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final aux f2375a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final u f2376a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Object f2377a = new Object();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Runnable f2378a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Executor f2379a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ThreadPoolExecutor f2380a;

        public con(Context context, u uVar, aux auxVar) {
            u2.g(context, "Context cannot be null");
            u2.g(uVar, "FontRequest cannot be null");
            this.f8203a = context.getApplicationContext();
            this.f2376a = uVar;
            this.f2375a = auxVar;
        }

        @Override // androidx.emoji2.text.con.com3
        public void a(androidx.emoji2.text.con.com4 com4Var) {
            u2.g(com4Var, "LoaderCallback cannot be null");
            synchronized (this.f2377a) {
                this.f2374a = com4Var;
            }
            d();
        }

        public final void b() {
            synchronized (this.f2377a) {
                this.f2374a = null;
                ContentObserver contentObserver = this.f2372a;
                if (contentObserver != null) {
                    this.f2375a.c(this.f8203a, contentObserver);
                    this.f2372a = null;
                }
                Handler handler = this.f2373a;
                if (handler != null) {
                    handler.removeCallbacks(this.f2378a);
                }
                this.f2373a = null;
                ThreadPoolExecutor threadPoolExecutor = this.f2380a;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f2379a = null;
                this.f2380a = null;
            }
        }

        public void c() {
            synchronized (this.f2377a) {
                if (this.f2374a == null) {
                    return;
                }
                try {
                    w.con conVarE = e();
                    int iB = conVarE.b();
                    if (iB == 2) {
                        synchronized (this.f2377a) {
                        }
                    }
                    if (iB != 0) {
                        throw new RuntimeException("fetchFonts result is not OK. (" + iB + ")");
                    }
                    try {
                        com8.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                        Typeface typefaceA = this.f2375a.a(this.f8203a, conVarE);
                        ByteBuffer byteBufferE = p.e(this.f8203a, null, conVarE.d());
                        if (byteBufferE == null || typefaceA == null) {
                            throw new RuntimeException("Unable to open file.");
                        }
                        com1 com1VarB = com1.b(typefaceA, byteBufferE);
                        com8.b();
                        synchronized (this.f2377a) {
                            androidx.emoji2.text.con.com4 com4Var = this.f2374a;
                            if (com4Var != null) {
                                com4Var.b(com1VarB);
                            }
                        }
                        b();
                    } catch (Throwable th) {
                        com8.b();
                        throw th;
                    }
                } catch (Throwable th2) {
                    synchronized (this.f2377a) {
                        androidx.emoji2.text.con.com4 com4Var2 = this.f2374a;
                        if (com4Var2 != null) {
                            com4Var2.a(th2);
                        }
                        b();
                    }
                }
            }
        }

        public void d() {
            synchronized (this.f2377a) {
                if (this.f2374a == null) {
                    return;
                }
                if (this.f2379a == null) {
                    ThreadPoolExecutor threadPoolExecutorB = t.b("emojiCompat");
                    this.f2380a = threadPoolExecutorB;
                    this.f2379a = threadPoolExecutorB;
                }
                this.f2379a.execute(new Runnable() { // from class: Com3.x
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f6497a.c();
                    }
                });
            }
        }

        public final w.con e() {
            try {
                w.aux auxVarB = this.f2375a.b(this.f8203a, this.f2376a);
                if (auxVarB.c() == 0) {
                    w.con[] conVarArrB = auxVarB.b();
                    if (conVarArrB == null || conVarArrB.length == 0) {
                        throw new RuntimeException("fetchFonts failed (empty result)");
                    }
                    return conVarArrB[0];
                }
                throw new RuntimeException("fetchFonts failed (" + auxVarB.c() + ")");
            } catch (PackageManager.NameNotFoundException e2) {
                throw new RuntimeException("provider not found", e2);
            }
        }

        public void f(Executor executor) {
            synchronized (this.f2377a) {
                this.f2379a = executor;
            }
        }
    }

    public prn(Context context, u uVar) {
        super(new con(context, uVar, f8202a));
    }

    public prn c(Executor executor) {
        ((con) a()).f(executor);
        return this;
    }
}
