package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public class com4 implements COM3.com7 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final com4 f8398a = new com4();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Handler f2614a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2613a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8399b = 0;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2618b = true;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f8400c = true;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com1 f2615a = new com1(this);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Runnable f2617a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f2616a = new con();

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            com4.this.f();
            com4.this.g();
        }
    }

    public class con implements com5.aux {
        public con() {
        }

        @Override // androidx.lifecycle.com5.aux
        public void a() {
            com4.this.c();
        }

        @Override // androidx.lifecycle.com5.aux
        public void b() {
        }

        @Override // androidx.lifecycle.com5.aux
        public void c() {
            com4.this.b();
        }
    }

    public class nul extends COM3.prn {

        public class aux extends COM3.prn {
            public aux() {
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPostResumed(Activity activity) {
                com4.this.b();
            }

            @Override // android.app.Application.ActivityLifecycleCallbacks
            public void onActivityPostStarted(Activity activity) {
                com4.this.c();
            }
        }

        public nul() {
        }

        @Override // COM3.prn, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            if (Build.VERSION.SDK_INT < 29) {
                com5.f(activity).h(com4.this.f2616a);
            }
        }

        @Override // COM3.prn, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            com4.this.a();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreCreated(Activity activity, Bundle bundle) {
            activity.registerActivityLifecycleCallbacks(new aux());
        }

        @Override // COM3.prn, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            com4.this.d();
        }
    }

    public static COM3.com7 h() {
        return f8398a;
    }

    public static void i(Context context) {
        f8398a.e(context);
    }

    public void a() {
        int i2 = this.f8399b - 1;
        this.f8399b = i2;
        if (i2 == 0) {
            this.f2614a.postDelayed(this.f2617a, 700L);
        }
    }

    public void b() {
        int i2 = this.f8399b + 1;
        this.f8399b = i2;
        if (i2 == 1) {
            if (!this.f2618b) {
                this.f2614a.removeCallbacks(this.f2617a);
            } else {
                this.f2615a.h(androidx.lifecycle.nul.con.ON_RESUME);
                this.f2618b = false;
            }
        }
    }

    public void c() {
        int i2 = this.f2613a + 1;
        this.f2613a = i2;
        if (i2 == 1 && this.f8400c) {
            this.f2615a.h(androidx.lifecycle.nul.con.ON_START);
            this.f8400c = false;
        }
    }

    public void d() {
        this.f2613a--;
        g();
    }

    public void e(Context context) {
        this.f2614a = new Handler();
        this.f2615a.h(androidx.lifecycle.nul.con.ON_CREATE);
        ((Application) context.getApplicationContext()).registerActivityLifecycleCallbacks(new nul());
    }

    public void f() {
        if (this.f8399b == 0) {
            this.f2618b = true;
            this.f2615a.h(androidx.lifecycle.nul.con.ON_PAUSE);
        }
    }

    public void g() {
        if (this.f2613a == 0 && this.f2618b) {
            this.f2615a.h(androidx.lifecycle.nul.con.ON_STOP);
            this.f8400c = true;
        }
    }

    @Override // COM3.com7
    public androidx.lifecycle.nul getLifecycle() {
        return this.f2615a;
    }
}
