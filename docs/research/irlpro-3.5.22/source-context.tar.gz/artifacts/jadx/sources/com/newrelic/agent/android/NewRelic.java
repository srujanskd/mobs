package com.newrelic.agent.android;

import android.content.Context;
import android.text.TextUtils;
import com.newrelic.agent.android.agentdata.AgentDataController;
import com.newrelic.agent.android.analytics.AnalyticsAttribute;
import com.newrelic.agent.android.analytics.AnalyticsControllerImpl;
import com.newrelic.agent.android.analytics.EventListener;
import com.newrelic.agent.android.api.common.TransactionData;
import com.newrelic.agent.android.distributedtracing.DistributedTracing;
import com.newrelic.agent.android.distributedtracing.TraceListener;
import com.newrelic.agent.android.instrumentation.TransactionState;
import com.newrelic.agent.android.instrumentation.TransactionStateUtil;
import com.newrelic.agent.android.logging.AgentLog;
import com.newrelic.agent.android.logging.AgentLogManager;
import com.newrelic.agent.android.logging.AndroidAgentLog;
import com.newrelic.agent.android.logging.NullAgentLog;
import com.newrelic.agent.android.measurement.http.HttpTransactionMeasurement;
import com.newrelic.agent.android.metric.MetricNames;
import com.newrelic.agent.android.metric.MetricUnit;
import com.newrelic.agent.android.stats.StatsEngine;
import com.newrelic.agent.android.tracing.TraceMachine;
import com.newrelic.agent.android.tracing.TracingInactiveException;
import com.newrelic.agent.android.util.Constants;
import com.newrelic.agent.android.util.NetworkFailure;
import inet.ipaddr.aux;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import org.apache.http.Header;
import org.apache.http.HttpResponse;

/* JADX INFO: loaded from: classes.dex */
public final class NewRelic {
    private static final String UNKNOWN_HTTP_REQUEST_TYPE = "unknown";
    protected static final AgentLog log = AgentLogManager.getAgentLog();
    protected static final AgentConfiguration agentConfiguration = new AgentConfiguration();
    protected static boolean started = false;
    protected boolean loggingEnabled = true;
    protected int logLevel = 3;

    public NewRelic(String str) {
        agentConfiguration.setApplicationToken(str);
    }

    public static void _noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5, String str3, Map<String, String> map, String str4) {
        checkEmpty(str, "noticeHttpTransaction: url must not be empty.");
        checkEmpty(str2, "noticeHttpTransaction: httpMethod must not be empty.");
        try {
            new URL(str);
            double d2 = j3 - j2;
            if (checkNegative((int) d2, "noticeHttpTransaction: the startTimeMs is later than the endTimeMs, resulting in a negative total time.")) {
                return;
            }
            TaskQueue.queue(new HttpTransactionMeasurement(str, str2, i2, 0, j2, d2 / 1000.0d, j4, j5, str4));
            if (i2 >= 400) {
                Measurements.addHttpError(str, str2, i2, str3, map);
            }
        } catch (MalformedURLException unused) {
            throw new IllegalArgumentException("noticeHttpTransaction: URL is malformed: " + str);
        }
    }

    private static void checkEmpty(String str, String str2) {
        checkNull(str, str2);
        if (str.length() == 0) {
            throw new IllegalArgumentException(str2);
        }
    }

    private static boolean checkNegative(int i2, String str) {
        if (i2 >= 0) {
            return false;
        }
        log.error(str);
        return true;
    }

    private static void checkNull(Object obj, String str) {
        if (obj == null) {
            throw new IllegalArgumentException(str);
        }
    }

    public static void crashNow() {
        crashNow("This is a demonstration crash courtesy of New Relic");
    }

    public static String currentSessionId() {
        return agentConfiguration.getSessionID();
    }

    public static void disableFeature(FeatureFlag featureFlag) {
        log.debug("Disable feature: " + featureFlag.name());
        FeatureFlag.disableFeature(featureFlag);
    }

    public static void enableFeature(FeatureFlag featureFlag) {
        log.debug("Enable feature: " + featureFlag.name());
        FeatureFlag.enableFeature(featureFlag);
    }

    public static void endInteraction(String str) {
        log.debug("NewRelic.endInteraction invoked. id: " + str);
        TraceMachine.endTrace(str);
    }

    public static void endMethodTrace() {
        log.debug("NewRelic.endMethodTrace invoked.");
        TraceMachine.exitMethod();
    }

    public static boolean incrementAttribute(String str) {
        return AnalyticsControllerImpl.getInstance().incrementAttribute(str, 1.0d);
    }

    private boolean isInstrumented() {
        return true;
    }

    public static boolean isStarted() {
        return started;
    }

    private void logRecourse() {
        log.error("Failed to detect New Relic instrumentation. The current runtime variant may be excluded from instrumentation, or instrumentation failed during your build process. Please visit http://support.newrelic.com.");
    }

    public static void noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5) {
        _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, null, null, null);
    }

    public static void noticeNetworkFailure(String str, String str2, long j2, long j3, NetworkFailure networkFailure, String str3) {
        noticeNetworkFailureDelegate(str, str2, j2, j3, networkFailure, str3);
    }

    private static void noticeNetworkFailureDelegate(String str, String str2, long j2, long j3, NetworkFailure networkFailure, String str3) {
        TransactionState transactionState = new TransactionState();
        TransactionStateUtil.inspectAndInstrument(transactionState, str, str2);
        transactionState.setErrorCode(networkFailure.getErrorCode());
        TransactionData transactionDataEnd = transactionState.end();
        TreeMap treeMap = new TreeMap();
        treeMap.put(Constants.Transactions.CONTENT_LENGTH, aux.OCTAL_PREFIX);
        treeMap.put(Constants.Transactions.CONTENT_TYPE, "text/html");
        transactionDataEnd.setResponseBody(str3);
        transactionDataEnd.setParams(treeMap);
        TaskQueue.queue(new HttpTransactionMeasurement(transactionDataEnd));
        Measurements.addHttpError(transactionDataEnd);
    }

    public static boolean recordBreadcrumb(String str) {
        return recordBreadcrumb(str, null);
    }

    public static boolean recordCustomEvent(String str, Map<String, Object> map) {
        if (map == null) {
            map = new HashMap<>();
        }
        return AnalyticsControllerImpl.getInstance().recordCustomEvent(str, map);
    }

    @Deprecated
    public static boolean recordEvent(String str, Map<String, Object> map) {
        if (map == null) {
            map = new HashMap<>();
        }
        return AnalyticsControllerImpl.getInstance().recordEvent(str, map);
    }

    public static boolean recordHandledException(Exception exc) {
        return recordHandledException(exc, (Map<String, Object>) null);
    }

    public static void recordMetric(String str, String str2, int i2, double d2, double d3) {
        recordMetric(str, str2, i2, d2, d3, null, null);
    }

    public static boolean removeAllAttributes() {
        return AnalyticsControllerImpl.getInstance().removeAllAttributes();
    }

    public static boolean removeAttribute(String str) {
        return AnalyticsControllerImpl.getInstance().removeAttribute(str);
    }

    public static boolean setAttribute(String str, String str2) {
        return AnalyticsControllerImpl.getInstance().setAttribute(str, str2);
    }

    public static void setEventListener(EventListener eventListener) {
        AnalyticsControllerImpl.getInstance().getEventManager().setEventListener(eventListener);
    }

    public static void setInteractionName(String str) {
        TraceMachine.setRootDisplayName(str);
    }

    public static void setMaxEventBufferTime(int i2) {
        AnalyticsControllerImpl.getInstance().setMaxEventBufferTime(i2);
    }

    public static void setMaxEventPoolSize(int i2) {
        AnalyticsControllerImpl.getInstance().setMaxEventPoolSize(i2);
    }

    public static boolean setUserId(String str) {
        return AnalyticsControllerImpl.getInstance().setAttribute(AnalyticsAttribute.USER_ID_ATTRIBUTE, str);
    }

    @Deprecated
    public static void shutdown() {
        StatsEngine.get().inc("Supportability/AgentHealth/Deprecated/Shutdown");
        if (started) {
            try {
                Agent.getImpl().stop();
            } finally {
                Agent.setImpl(NullAgentImpl.instance);
                started = false;
            }
        }
    }

    public static String startInteraction(String str) {
        checkNull(str, "startInteraction: actionName must be an action/method name.");
        log.debug("NewRelic.startInteraction invoked with actionName: " + str);
        TraceMachine.startTracing(str.replace("/", "."), true, FeatureFlag.featureEnabled(FeatureFlag.InteractionTracing));
        try {
            return TraceMachine.getActivityTrace().getId();
        } catch (TracingInactiveException unused) {
            return null;
        }
    }

    public static void startMethodTrace(String str) {
        checkNull(str, "startMethodTrace: actionName must be an action/method name.");
        TraceMachine.enterMethod(str);
    }

    public static NewRelic withApplicationToken(String str) {
        return new NewRelic(str);
    }

    public void start(Context context) {
        if (started) {
            log.debug("NewRelic is already running.");
            return;
        }
        try {
            AgentLogManager.setAgentLog(this.loggingEnabled ? new AndroidAgentLog() : new NullAgentLog());
            AgentLog agentLog = log;
            agentLog.setLevel(this.logLevel);
            if (!InstantApps.isInstantApp(context) && !isInstrumented()) {
                logRecourse();
                return;
            }
            AndroidAgentImpl.init(context, agentConfiguration);
            started = true;
            if (agentLog.getLevel() >= 6) {
                StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
                if (stackTrace.length > 3) {
                    StackTraceElement stackTraceElement = stackTrace[3];
                    agentLog.audit("Agent started from " + stackTraceElement.getClassName() + "." + stackTraceElement.getMethodName() + ":" + stackTraceElement.getLineNumber());
                }
            }
        } catch (Throwable th) {
            log.error("Error occurred while starting the New Relic agent!", th);
            logRecourse();
        }
    }

    public NewRelic usingCollectorAddress(String str) {
        agentConfiguration.setCollectorHost(str);
        return this;
    }

    public NewRelic usingCrashCollectorAddress(String str) {
        agentConfiguration.setCrashCollectorHost(str);
        return this;
    }

    public NewRelic usingSsl(boolean z2) {
        agentConfiguration.setUseSsl(z2);
        return this;
    }

    @Deprecated
    public NewRelic withAnalyticsEvents(boolean z2) {
        agentConfiguration.setEnableAnalyticsEvents(z2);
        if (z2) {
            enableFeature(FeatureFlag.AnalyticsEvents);
        } else {
            disableFeature(FeatureFlag.AnalyticsEvents);
        }
        return this;
    }

    public NewRelic withApplicationBuild(String str) {
        if (!TextUtils.isEmpty(str)) {
            agentConfiguration.setCustomBuildIdentifier(str);
        }
        return this;
    }

    @Deprecated
    public NewRelic withApplicationFramework(ApplicationFramework applicationFramework) {
        if (applicationFramework != null) {
            agentConfiguration.setApplicationFramework(applicationFramework);
        }
        return this;
    }

    public NewRelic withApplicationVersion(String str) {
        if (str != null) {
            agentConfiguration.setCustomApplicationVersion(str);
        }
        return this;
    }

    @Deprecated
    public NewRelic withBuildIdentifier(String str) {
        StatsEngine.get().inc("Supportability/AgentHealth/Deprecated/WithBuildIdentifier");
        return withApplicationBuild(str);
    }

    public NewRelic withCrashReportingEnabled(boolean z2) {
        agentConfiguration.setReportCrashes(z2);
        return this;
    }

    @Deprecated
    public NewRelic withDefaultInteractions(boolean z2) {
        if (z2) {
            enableFeature(FeatureFlag.DefaultInteractions);
        } else {
            disableFeature(FeatureFlag.DefaultInteractions);
        }
        return this;
    }

    public NewRelic withDistributedTraceListener(TraceListener traceListener) {
        if (FeatureFlag.featureEnabled(FeatureFlag.DistributedTracing)) {
            DistributedTracing.setDistributedTraceListener(traceListener);
        }
        return this;
    }

    @Deprecated
    public NewRelic withHttpResponseBodyCaptureEnabled(boolean z2) {
        if (z2) {
            enableFeature(FeatureFlag.HttpResponseBodyCapture);
        } else {
            disableFeature(FeatureFlag.HttpResponseBodyCapture);
        }
        return this;
    }

    @Deprecated
    public NewRelic withInteractionTracing(boolean z2) {
        if (z2) {
            enableFeature(FeatureFlag.InteractionTracing);
        } else {
            disableFeature(FeatureFlag.InteractionTracing);
        }
        return this;
    }

    @Deprecated
    public NewRelic withLocationServiceEnabled(boolean z2) {
        agentConfiguration.setUseLocationService(z2);
        return this;
    }

    public NewRelic withLogLevel(int i2) {
        this.logLevel = i2;
        return this;
    }

    public NewRelic withLoggingEnabled(boolean z2) {
        this.loggingEnabled = z2;
        return this;
    }

    public static void crashNow(String str) {
        throw new RuntimeException(str);
    }

    public static boolean incrementAttribute(String str, double d2) {
        return AnalyticsControllerImpl.getInstance().incrementAttribute(str, d2);
    }

    public static void noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5, String str3) {
        _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, null, null);
    }

    public static void noticeNetworkFailure(String str, String str2, long j2, long j3, NetworkFailure networkFailure) {
        noticeNetworkFailure(str, str2, j2, j3, networkFailure, "");
    }

    public static boolean recordBreadcrumb(String str, Map<String, Object> map) {
        if (map == null) {
            map = new HashMap<>();
        }
        if (str != null && !str.isEmpty()) {
            map.put("name", str);
        }
        return AnalyticsControllerImpl.getInstance().recordBreadcrumb(str, map);
    }

    public static boolean recordHandledException(Exception exc, Map<String, Object> map) {
        StatsEngine.get().inc(MetricNames.SUPPORTABILITY_SDK_RECORD_HEX);
        if (map == null) {
            map = new HashMap<>();
        }
        return recordHandledException((Throwable) exc, map);
    }

    public static void recordMetric(String str, String str2, int i2, double d2, double d3, MetricUnit metricUnit, MetricUnit metricUnit2) {
        log.debug("NewRelic.recordMetric invoked for name " + str + ", category: " + str2 + ", count: " + i2 + ", totalValue " + d2 + ", exclusiveValue: " + d3 + ", countUnit: " + metricUnit + ", valueUnit: " + metricUnit2);
        checkNull(str2, "recordMetric: category must not be null. If no MetricCategory is applicable, use MetricCategory.NONE.");
        checkEmpty(str, "recordMetric: name must not be empty.");
        if (checkNegative(i2, "recordMetric: count must not be negative.")) {
            return;
        }
        Measurements.addCustomMetric(str, str2, i2, d2, d3, metricUnit, metricUnit2);
    }

    public static boolean setAttribute(String str, double d2) {
        return AnalyticsControllerImpl.getInstance().setAttribute(str, d2);
    }

    public static void noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5, String str3, Map<String, String> map) {
        _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, map, null);
    }

    public static void noticeNetworkFailure(String str, String str2, long j2, long j3, Exception exc) {
        checkEmpty(str, "noticeHttpException: url must not be empty.");
        noticeNetworkFailure(str, str2, j2, j3, NetworkFailure.exceptionToNetworkFailure(exc), exc.getMessage());
    }

    public static boolean recordCustomEvent(String str, String str2, Map<String, Object> map) {
        if (map == null) {
            map = new HashMap<>();
        }
        if (str2 != null && !str2.isEmpty()) {
            map.put("name", str2);
        }
        return recordCustomEvent(str, map);
    }

    public static boolean setAttribute(String str, boolean z2) {
        return AnalyticsControllerImpl.getInstance().setAttribute(str, z2);
    }

    public static void noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5, String str3, Map<String, String> map, String str4) {
        _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, map, str4);
    }

    public static void noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5, String str3, Map<String, String> map, URLConnection uRLConnection) {
        String headerField;
        if (uRLConnection != null && (headerField = uRLConnection.getHeaderField(Constants.Network.CROSS_PROCESS_ID_HEADER)) != null && headerField.length() > 0) {
            _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, map, headerField);
        } else {
            _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, map, null);
        }
    }

    public static boolean recordHandledException(Throwable th) {
        return recordHandledException(th, (Map<String, Object>) null);
    }

    public static String startInteraction(Context context, String str) {
        checkNull(context, "startInteraction: context must be an Activity instance.");
        checkNull(str, "startInteraction: actionName must be an action/method name.");
        log.debug("NewRelic.startInteraction invoked with actionName: " + str);
        TraceMachine.startTracing(context.getClass().getSimpleName() + "#" + str.replace("/", "."), false, FeatureFlag.featureEnabled(FeatureFlag.InteractionTracing));
        try {
            return TraceMachine.getActivityTrace().getId();
        } catch (TracingInactiveException unused) {
            return null;
        }
    }

    @Deprecated
    public static void noticeNetworkFailure(String str, long j2, long j3, NetworkFailure networkFailure) {
        noticeNetworkFailure(str, "unknown", j2, j3, networkFailure);
    }

    public static boolean recordHandledException(Throwable th, Map<String, Object> map) {
        StatsEngine.get().inc(MetricNames.SUPPORTABILITY_SDK_RECORD_THROWABLE);
        if (map == null) {
            map = new HashMap<>();
        }
        return AgentDataController.sendAgentData(th, map);
    }

    @Deprecated
    public static void noticeNetworkFailure(String str, long j2, long j3, Exception exc) {
        noticeNetworkFailure(str, "unknown", j2, j3, exc);
    }

    public static void recordMetric(String str, String str2, double d2) {
        recordMetric(str, str2, 1, d2, d2, null, null);
    }

    public static void recordMetric(String str, String str2) {
        recordMetric(str, str2, 1.0d);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, String str2, int i2, long j2, long j3, long j4, long j5, String str3, Map<String, String> map, HttpResponse httpResponse) {
        Header firstHeader;
        if (httpResponse != null && (firstHeader = httpResponse.getFirstHeader(Constants.Network.CROSS_PROCESS_ID_HEADER)) != null && firstHeader.getValue() != null && firstHeader.getValue().length() > 0) {
            _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, map, firstHeader.getValue());
        } else {
            _noticeHttpTransaction(str, str2, i2, j2, j3, j4, j5, str3, map, null);
        }
    }

    @Deprecated
    public static String startInteraction(Context context, String str, boolean z2) {
        if (TraceMachine.isTracingActive() && !z2) {
            log.warning("startInteraction: An interaction is already being traced, and invalidateActiveTrace is false. This interaction will not be traced.");
            return null;
        }
        return startInteraction(context, str);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, int i2, long j2, long j3, long j4, long j5, String str2, Map<String, String> map, HttpResponse httpResponse) {
        noticeHttpTransaction(str, "unknown", i2, j2, j3, j4, j5, str2, map, httpResponse);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, int i2, long j2, long j3, long j4, long j5, String str2, Map<String, String> map, URLConnection uRLConnection) {
        noticeHttpTransaction(str, "unknown", i2, j2, j3, j4, j5, str2, map, uRLConnection);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, int i2, long j2, long j3, long j4, long j5) {
        _noticeHttpTransaction(str, "unknown", i2, j2, j3, j4, j5, null, null, null);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, int i2, long j2, long j3, long j4, long j5, String str2) {
        _noticeHttpTransaction(str, "unknown", i2, j2, j3, j4, j5, str2, null, null);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, int i2, long j2, long j3, long j4, long j5, String str2, Map<String, String> map) {
        _noticeHttpTransaction(str, "unknown", i2, j2, j3, j4, j5, str2, map, null);
    }

    @Deprecated
    public static void noticeHttpTransaction(String str, int i2, long j2, long j3, long j4, long j5, String str2, Map<String, String> map, String str3) {
        _noticeHttpTransaction(str, "unknown", i2, j2, j3, j4, j5, str2, map, str3);
    }
}
