package com.google.android.material.chip;

import COM6.com4;
import COM9.com7;
import COM9.lpt1;
import android.R;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Bundle;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.util.List;
import p021CoM9.lpt4;
import p022CoN.lpt3;
import p024Com2.y;
import p075cOM6.f4;
import p075cOM6.g4;
import p075cOM6.h4;
import p075cOM6.x3;
import p081cOm2.e2;
import p098coM9.c;
import p098coM9.e;
import p102com3.n0;
import p108com9.o;
import p108com9.t;
import p108com9.v;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
public class Chip extends lpt3 implements com.google.android.material.chip.aux.InterfaceC0056aux, lpt1, o<Chip> {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3395a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f3396a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final RectF f3397a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public InsetDrawable f3398a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public RippleDrawable f3399a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View.OnClickListener f3400a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CompoundButton.OnCheckedChangeListener f3401a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final e f3402a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final prn f3403a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.chip.aux f3404a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public o.aux<Chip> f3405a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f3406a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f3407b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3408b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f3409c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f9397d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9398e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9399f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f9400g;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int f9396c = g4.f8972q;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Rect f9395b = new Rect();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f9394a = {R.attr.state_selected};

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public static final int[] f3394b = {R.attr.state_checkable};

    public class aux extends e {
        public aux() {
        }

        @Override // p098coM9.e
        public void a(int i2) {
        }

        @Override // p098coM9.e
        public void b(Typeface typeface, boolean z2) {
            Chip chip = Chip.this;
            chip.setText(chip.f3404a.K2() ? Chip.this.f3404a.g1() : Chip.this.getText());
            Chip.this.requestLayout();
            Chip.this.invalidate();
        }
    }

    public class con implements CompoundButton.OnCheckedChangeListener {
        public con() {
        }

        @Override // android.widget.CompoundButton.OnCheckedChangeListener
        public void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
            if (Chip.this.f3405a != null) {
                Chip.this.f3405a.a(Chip.this, z2);
            }
            if (Chip.this.f3401a != null) {
                Chip.this.f3401a.onCheckedChanged(compoundButton, z2);
            }
        }
    }

    public class nul extends ViewOutlineProvider {
        public nul() {
        }

        @Override // android.view.ViewOutlineProvider
        @TargetApi(21)
        public void getOutline(View view, Outline outline) {
            if (Chip.this.f3404a != null) {
                Chip.this.f3404a.getOutline(outline);
            } else {
                outline.setAlpha(0.0f);
            }
        }
    }

    public class prn extends n0 {
        public prn(Chip chip) {
            super(chip);
        }

        @Override // p102com3.n0
        public int B(float f2, float f3) {
            return (Chip.this.o() && Chip.this.getCloseIconTouchBounds().contains(f2, f3)) ? 1 : 0;
        }

        @Override // p102com3.n0
        public void C(List<Integer> list) {
            list.add(0);
            if (Chip.this.o() && Chip.this.t() && Chip.this.f3400a != null) {
                list.add(1);
            }
        }

        @Override // p102com3.n0
        public boolean J(int i2, int i3, Bundle bundle) {
            if (i3 != 16) {
                return false;
            }
            if (i2 == 0) {
                return Chip.this.performClick();
            }
            if (i2 == 1) {
                return Chip.this.u();
            }
            return false;
        }

        @Override // p102com3.n0
        public void M(e2 e2Var) {
            e2Var.R(Chip.this.s());
            e2Var.U(Chip.this.isClickable());
            e2Var.T(Chip.this.getAccessibilityClassName());
            e2Var.v0(Chip.this.getText());
        }

        @Override // p102com3.n0
        public void N(int i2, e2 e2Var) {
            if (i2 != 1) {
                e2Var.X("");
                e2Var.P(Chip.f9395b);
                return;
            }
            CharSequence closeIconContentDescription = Chip.this.getCloseIconContentDescription();
            if (closeIconContentDescription != null) {
                e2Var.X(closeIconContentDescription);
            } else {
                CharSequence text = Chip.this.getText();
                Context context = Chip.this.getContext();
                int i3 = f4.f8947r;
                Object[] objArr = new Object[1];
                objArr[0] = TextUtils.isEmpty(text) ? "" : text;
                e2Var.X(context.getString(i3, objArr).trim());
            }
            e2Var.P(Chip.this.getCloseIconTouchBoundsInt());
            e2Var.b(e2.aux.f9101e);
            e2Var.Z(Chip.this.isEnabled());
        }

        @Override // p102com3.n0
        public void O(int i2, boolean z2) {
            if (i2 == 1) {
                Chip.this.f9398e = z2;
                Chip.this.refreshDrawableState();
            }
        }
    }

    public Chip(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, x3.f9032g);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public RectF getCloseIconTouchBounds() {
        this.f3397a.setEmpty();
        if (o() && this.f3400a != null) {
            this.f3404a.X0(this.f3397a);
        }
        return this.f3397a;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Rect getCloseIconTouchBoundsInt() {
        RectF closeIconTouchBounds = getCloseIconTouchBounds();
        this.f3396a.set((int) closeIconTouchBounds.left, (int) closeIconTouchBounds.top, (int) closeIconTouchBounds.right, (int) closeIconTouchBounds.bottom);
        return this.f3396a;
    }

    private c getTextAppearance() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.h1();
        }
        return null;
    }

    private void setCloseIconHovered(boolean z2) {
        if (this.f9397d != z2) {
            this.f9397d = z2;
            refreshDrawableState();
        }
    }

    private void setCloseIconPressed(boolean z2) {
        if (this.f3409c != z2) {
            this.f3409c = z2;
            refreshDrawableState();
        }
    }

    public final void A() {
        this.f3399a = new RippleDrawable(lpt4.d(this.f3404a.e1()), getBackgroundDrawable(), null);
        this.f3404a.J2(false);
        y.s0(this, this.f3399a);
        B();
    }

    public final void B() {
        com.google.android.material.chip.aux auxVar;
        if (TextUtils.isEmpty(getText()) || (auxVar = this.f3404a) == null) {
            return;
        }
        int iI0 = (int) (auxVar.I0() + this.f3404a.i1() + this.f3404a.p0());
        int iN0 = (int) (this.f3404a.N0() + this.f3404a.j1() + this.f3404a.l0());
        if (this.f3398a != null) {
            Rect rect = new Rect();
            this.f3398a.getPadding(rect);
            iN0 += rect.left;
            iI0 += rect.right;
        }
        y.C0(this, iN0, getPaddingTop(), iI0, getPaddingBottom());
    }

    public final void C() {
        TextPaint paint = getPaint();
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            paint.drawableState = auxVar.getState();
        }
        c textAppearance = getTextAppearance();
        if (textAppearance != null) {
            textAppearance.n(getContext(), paint, this.f3402a);
        }
    }

    public final void D(AttributeSet attributeSet) {
        if (attributeSet == null) {
            return;
        }
        if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "background") != null) {
            Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
        }
        if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableLeft") != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        }
        if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableStart") != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableEnd") != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        if (attributeSet.getAttributeValue("http://schemas.android.com/apk/res/android", "drawableRight") != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        if (!attributeSet.getAttributeBooleanValue("http://schemas.android.com/apk/res/android", "singleLine", true) || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "lines", 1) != 1 || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "minLines", 1) != 1 || attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "maxLines", 1) != 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        if (attributeSet.getAttributeIntValue("http://schemas.android.com/apk/res/android", "gravity", 8388627) != 8388627) {
            Log.w("Chip", "Chip text must be vertically center and start aligned");
        }
    }

    @Override // com.google.android.material.chip.aux.InterfaceC0056aux
    public void a() {
        m(this.f3407b);
        requestLayout();
        invalidateOutline();
    }

    @Override // android.view.View
    public boolean dispatchHoverEvent(MotionEvent motionEvent) {
        if (this.f9400g) {
            return this.f3403a.v(motionEvent) || super.dispatchHoverEvent(motionEvent);
        }
        return super.dispatchHoverEvent(motionEvent);
    }

    @Override // android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!this.f9400g) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (!this.f3403a.w(keyEvent) || this.f3403a.A() == Integer.MIN_VALUE) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    @Override // p022CoN.lpt3, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if ((auxVar == null || !auxVar.o1()) ? false : this.f3404a.k2(l())) {
            invalidate();
        }
    }

    @Override // android.widget.CheckBox, android.widget.CompoundButton, android.widget.Button, android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        if (!TextUtils.isEmpty(this.f3406a)) {
            return this.f3406a;
        }
        if (!s()) {
            return isClickable() ? "android.widget.Button" : "android.view.View";
        }
        ViewParent parent = getParent();
        return ((parent instanceof ChipGroup) && ((ChipGroup) parent).h()) ? "android.widget.RadioButton" : "android.widget.CompoundButton";
    }

    public Drawable getBackgroundDrawable() {
        InsetDrawable insetDrawable = this.f3398a;
        return insetDrawable == null ? this.f3404a : insetDrawable;
    }

    public Drawable getCheckedIcon() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.E0();
        }
        return null;
    }

    public ColorStateList getCheckedIconTint() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.F0();
        }
        return null;
    }

    public ColorStateList getChipBackgroundColor() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.G0();
        }
        return null;
    }

    public float getChipCornerRadius() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return Math.max(0.0f, auxVar.H0());
        }
        return 0.0f;
    }

    public Drawable getChipDrawable() {
        return this.f3404a;
    }

    public float getChipEndPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.I0();
        }
        return 0.0f;
    }

    public Drawable getChipIcon() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.J0();
        }
        return null;
    }

    public float getChipIconSize() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.K0();
        }
        return 0.0f;
    }

    public ColorStateList getChipIconTint() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.L0();
        }
        return null;
    }

    public float getChipMinHeight() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.M0();
        }
        return 0.0f;
    }

    public float getChipStartPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.N0();
        }
        return 0.0f;
    }

    public ColorStateList getChipStrokeColor() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.O0();
        }
        return null;
    }

    public float getChipStrokeWidth() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.P0();
        }
        return 0.0f;
    }

    @Deprecated
    public CharSequence getChipText() {
        return getText();
    }

    public Drawable getCloseIcon() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.Q0();
        }
        return null;
    }

    public CharSequence getCloseIconContentDescription() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.R0();
        }
        return null;
    }

    public float getCloseIconEndPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.S0();
        }
        return 0.0f;
    }

    public float getCloseIconSize() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.T0();
        }
        return 0.0f;
    }

    public float getCloseIconStartPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.U0();
        }
        return 0.0f;
    }

    public ColorStateList getCloseIconTint() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.W0();
        }
        return null;
    }

    @Override // android.widget.TextView
    public TextUtils.TruncateAt getEllipsize() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.a1();
        }
        return null;
    }

    @Override // android.widget.TextView, android.view.View
    public void getFocusedRect(Rect rect) {
        if (this.f9400g && (this.f3403a.A() == 1 || this.f3403a.x() == 1)) {
            rect.set(getCloseIconTouchBoundsInt());
        } else {
            super.getFocusedRect(rect);
        }
    }

    public com4 getHideMotionSpec() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.b1();
        }
        return null;
    }

    public float getIconEndPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.c1();
        }
        return 0.0f;
    }

    public float getIconStartPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.d1();
        }
        return 0.0f;
    }

    public ColorStateList getRippleColor() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.e1();
        }
        return null;
    }

    public com7 getShapeAppearanceModel() {
        return this.f3404a.D();
    }

    public com4 getShowMotionSpec() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.f1();
        }
        return null;
    }

    public float getTextEndPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.i1();
        }
        return 0.0f;
    }

    public float getTextStartPadding() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            return auxVar.j1();
        }
        return 0.0f;
    }

    public final void k(com.google.android.material.chip.aux auxVar) {
        auxVar.o2(this);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean, int] */
    public final int[] l() {
        ?? IsEnabled = isEnabled();
        int i2 = IsEnabled;
        if (this.f9398e) {
            i2 = IsEnabled + 1;
        }
        int i3 = i2;
        if (this.f9397d) {
            i3 = i2 + 1;
        }
        int i4 = i3;
        if (this.f3409c) {
            i4 = i3 + 1;
        }
        int i5 = i4;
        if (isChecked()) {
            i5 = i4 + 1;
        }
        int[] iArr = new int[i5];
        int i6 = 0;
        if (isEnabled()) {
            iArr[0] = 16842910;
            i6 = 1;
        }
        if (this.f9398e) {
            iArr[i6] = 16842908;
            i6++;
        }
        if (this.f9397d) {
            iArr[i6] = 16843623;
            i6++;
        }
        if (this.f3409c) {
            iArr[i6] = 16842919;
            i6++;
        }
        if (isChecked()) {
            iArr[i6] = 16842913;
        }
        return iArr;
    }

    public boolean m(int i2) {
        this.f3407b = i2;
        if (!w()) {
            if (this.f3398a != null) {
                v();
            } else {
                z();
            }
            return false;
        }
        int iMax = Math.max(0, i2 - this.f3404a.getIntrinsicHeight());
        int iMax2 = Math.max(0, i2 - this.f3404a.getIntrinsicWidth());
        if (iMax2 <= 0 && iMax <= 0) {
            if (this.f3398a != null) {
                v();
            } else {
                z();
            }
            return false;
        }
        int i3 = iMax2 > 0 ? iMax2 / 2 : 0;
        int i4 = iMax > 0 ? iMax / 2 : 0;
        if (this.f3398a != null) {
            Rect rect = new Rect();
            this.f3398a.getPadding(rect);
            if (rect.top == i4 && rect.bottom == i4 && rect.left == i3 && rect.right == i3) {
                z();
                return true;
            }
        }
        if (getMinHeight() != i2) {
            setMinHeight(i2);
        }
        if (getMinWidth() != i2) {
            setMinWidth(i2);
        }
        r(i3, i4, i3, i4);
        z();
        return true;
    }

    public final void n() {
        if (getBackgroundDrawable() == this.f3398a && this.f3404a.getCallback() == null) {
            this.f3404a.setCallback(this.f3398a);
        }
    }

    public final boolean o() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        return (auxVar == null || auxVar.Q0() == null) ? false : true;
    }

    @Override // android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        COM9.com4.f(this, this.f3404a);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i2 + 2);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f9394a);
        }
        if (s()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f3394b);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.TextView, android.view.View
    public void onFocusChanged(boolean z2, int i2, Rect rect) {
        super.onFocusChanged(z2, i2, rect);
        if (this.f9400g) {
            this.f3403a.I(z2, i2, rect);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 7) {
            setCloseIconHovered(getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()));
        } else if (actionMasked == 10) {
            setCloseIconHovered(false);
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getAccessibilityClassName());
        accessibilityNodeInfo.setCheckable(s());
        accessibilityNodeInfo.setClickable(isClickable());
        if (getParent() instanceof ChipGroup) {
            ChipGroup chipGroup = (ChipGroup) getParent();
            e2.z0(accessibilityNodeInfo).W(e2.nul.a(chipGroup.b(this), 1, chipGroup.c() ? chipGroup.g(this) : -1, 1, false, isChecked()));
        }
    }

    @Override // android.widget.Button, android.widget.TextView, android.view.View
    @TargetApi(24)
    public PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i2) {
        if (getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()) && isEnabled()) {
            return PointerIcon.getSystemIcon(getContext(), 1002);
        }
        return null;
    }

    @Override // android.widget.TextView, android.view.View
    @TargetApi(17)
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        if (this.f3395a != i2) {
            this.f3395a = i2;
            B();
        }
    }

    @Override // android.widget.TextView, android.view.View
    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        int actionMasked = motionEvent.getActionMasked();
        boolean zContains = getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY());
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                    if (actionMasked != 3) {
                    }
                } else if (this.f3409c) {
                    if (!zContains) {
                        setCloseIconPressed(false);
                    }
                    z2 = true;
                }
                z2 = false;
            } else {
                if (this.f3409c) {
                    u();
                    z2 = true;
                }
                setCloseIconPressed(false);
            }
            z2 = false;
            setCloseIconPressed(false);
        } else if (zContains) {
            setCloseIconPressed(true);
            z2 = true;
        } else {
            z2 = false;
        }
        return z2 || super.onTouchEvent(motionEvent);
    }

    public final void p(Context context, AttributeSet attributeSet, int i2) {
        TypedArray typedArrayH = t.h(context, attributeSet, h4.f3182z, i2, f9396c, new int[0]);
        this.f9399f = typedArrayH.getBoolean(h4.p0, false);
        this.f3407b = (int) Math.ceil(typedArrayH.getDimension(h4.f8988d0, (float) Math.ceil(v.b(getContext(), 48))));
        typedArrayH.recycle();
    }

    public final void q() {
        setOutlineProvider(new nul());
    }

    public final void r(int i2, int i3, int i4, int i5) {
        this.f3398a = new InsetDrawable((Drawable) this.f3404a, i2, i3, i4, i5);
    }

    public boolean s() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        return auxVar != null && auxVar.n1();
    }

    public void setAccessibilityClassName(CharSequence charSequence) {
        this.f3406a = charSequence;
    }

    @Override // android.view.View
    public void setBackground(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f3399a) {
            super.setBackground(drawable);
        } else {
            Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
        }
    }

    @Override // android.view.View
    public void setBackgroundColor(int i2) {
        Log.w("Chip", "Do not set the background color; Chip manages its own background drawable.");
    }

    @Override // p022CoN.lpt3, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f3399a) {
            super.setBackgroundDrawable(drawable);
        } else {
            Log.w("Chip", "Do not set the background drawable; Chip manages its own background drawable.");
        }
    }

    @Override // p022CoN.lpt3, android.view.View
    public void setBackgroundResource(int i2) {
        Log.w("Chip", "Do not set the background resource; Chip manages its own background drawable.");
    }

    @Override // android.view.View
    public void setBackgroundTintList(ColorStateList colorStateList) {
        Log.w("Chip", "Do not set the background tint list; Chip manages its own background drawable.");
    }

    @Override // android.view.View
    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        Log.w("Chip", "Do not set the background tint mode; Chip manages its own background drawable.");
    }

    public void setCheckable(boolean z2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.w1(z2);
        }
    }

    public void setCheckableResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.x1(i2);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar == null) {
            this.f3408b = z2;
        } else if (auxVar.n1()) {
            super.setChecked(z2);
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.y1(drawable);
        }
    }

    @Deprecated
    public void setCheckedIconEnabled(boolean z2) {
        setCheckedIconVisible(z2);
    }

    @Deprecated
    public void setCheckedIconEnabledResource(int i2) {
        setCheckedIconVisible(i2);
    }

    public void setCheckedIconResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.z1(i2);
        }
    }

    public void setCheckedIconTint(ColorStateList colorStateList) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.A1(colorStateList);
        }
    }

    public void setCheckedIconTintResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.B1(i2);
        }
    }

    public void setCheckedIconVisible(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.C1(i2);
        }
    }

    public void setChipBackgroundColor(ColorStateList colorStateList) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.E1(colorStateList);
        }
    }

    public void setChipBackgroundColorResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.F1(i2);
        }
    }

    @Deprecated
    public void setChipCornerRadius(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.G1(f2);
        }
    }

    @Deprecated
    public void setChipCornerRadiusResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.H1(i2);
        }
    }

    public void setChipDrawable(com.google.android.material.chip.aux auxVar) {
        com.google.android.material.chip.aux auxVar2 = this.f3404a;
        if (auxVar2 != auxVar) {
            x(auxVar2);
            this.f3404a = auxVar;
            auxVar.z2(false);
            k(this.f3404a);
            m(this.f3407b);
        }
    }

    public void setChipEndPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.I1(f2);
        }
    }

    public void setChipEndPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.J1(i2);
        }
    }

    public void setChipIcon(Drawable drawable) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.K1(drawable);
        }
    }

    @Deprecated
    public void setChipIconEnabled(boolean z2) {
        setChipIconVisible(z2);
    }

    @Deprecated
    public void setChipIconEnabledResource(int i2) {
        setChipIconVisible(i2);
    }

    public void setChipIconResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.L1(i2);
        }
    }

    public void setChipIconSize(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.M1(f2);
        }
    }

    public void setChipIconSizeResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.N1(i2);
        }
    }

    public void setChipIconTint(ColorStateList colorStateList) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.O1(colorStateList);
        }
    }

    public void setChipIconTintResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.P1(i2);
        }
    }

    public void setChipIconVisible(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.Q1(i2);
        }
    }

    public void setChipMinHeight(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.S1(f2);
        }
    }

    public void setChipMinHeightResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.T1(i2);
        }
    }

    public void setChipStartPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.U1(f2);
        }
    }

    public void setChipStartPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.V1(i2);
        }
    }

    public void setChipStrokeColor(ColorStateList colorStateList) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.W1(colorStateList);
        }
    }

    public void setChipStrokeColorResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.X1(i2);
        }
    }

    public void setChipStrokeWidth(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.Y1(f2);
        }
    }

    public void setChipStrokeWidthResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.Z1(i2);
        }
    }

    @Deprecated
    public void setChipText(CharSequence charSequence) {
        setText(charSequence);
    }

    @Deprecated
    public void setChipTextResource(int i2) {
        setText(getResources().getString(i2));
    }

    public void setCloseIcon(Drawable drawable) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.b2(drawable);
        }
        y();
    }

    public void setCloseIconContentDescription(CharSequence charSequence) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.c2(charSequence);
        }
    }

    @Deprecated
    public void setCloseIconEnabled(boolean z2) {
        setCloseIconVisible(z2);
    }

    @Deprecated
    public void setCloseIconEnabledResource(int i2) {
        setCloseIconVisible(i2);
    }

    public void setCloseIconEndPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.d2(f2);
        }
    }

    public void setCloseIconEndPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.e2(i2);
        }
    }

    public void setCloseIconResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.f2(i2);
        }
        y();
    }

    public void setCloseIconSize(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.g2(f2);
        }
    }

    public void setCloseIconSizeResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.h2(i2);
        }
    }

    public void setCloseIconStartPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.i2(f2);
        }
    }

    public void setCloseIconStartPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.j2(i2);
        }
    }

    public void setCloseIconTint(ColorStateList colorStateList) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.l2(colorStateList);
        }
    }

    public void setCloseIconTintResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.m2(i2);
        }
    }

    public void setCloseIconVisible(int i2) {
        setCloseIconVisible(getResources().getBoolean(i2));
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 != null) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (i4 != 0) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(i2, i3, i4, i5);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i2, int i3, int i4, int i5) {
        if (i2 != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (i4 != 0) {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
        super.setCompoundDrawablesWithIntrinsicBounds(i2, i3, i4, i5);
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        super.setElevation(f2);
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.X(f2);
        }
    }

    @Override // android.widget.TextView
    public void setEllipsize(TextUtils.TruncateAt truncateAt) {
        if (this.f3404a == null) {
            return;
        }
        if (truncateAt == TextUtils.TruncateAt.MARQUEE) {
            throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
        }
        super.setEllipsize(truncateAt);
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.p2(truncateAt);
        }
    }

    public void setEnsureMinTouchTargetSize(boolean z2) {
        this.f9399f = z2;
        m(this.f3407b);
    }

    @Override // android.widget.TextView
    public void setGravity(int i2) {
        if (i2 != 8388627) {
            Log.w("Chip", "Chip text must be vertically center and start aligned");
        } else {
            super.setGravity(i2);
        }
    }

    public void setHideMotionSpec(com4 com4Var) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.q2(com4Var);
        }
    }

    public void setHideMotionSpecResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.r2(i2);
        }
    }

    public void setIconEndPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.s2(f2);
        }
    }

    public void setIconEndPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.t2(i2);
        }
    }

    public void setIconStartPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.u2(f2);
        }
    }

    public void setIconStartPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.v2(i2);
        }
    }

    @Override // p108com9.o
    public void setInternalOnCheckedChangeListener(o.aux<Chip> auxVar) {
        this.f3405a = auxVar;
    }

    @Override // android.view.View
    public void setLayoutDirection(int i2) {
        if (this.f3404a == null) {
            return;
        }
        super.setLayoutDirection(i2);
    }

    @Override // android.widget.TextView
    public void setLines(int i2) {
        if (i2 > 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setLines(i2);
    }

    @Override // android.widget.TextView
    public void setMaxLines(int i2) {
        if (i2 > 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setMaxLines(i2);
    }

    @Override // android.widget.TextView
    public void setMaxWidth(int i2) {
        super.setMaxWidth(i2);
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.w2(i2);
        }
    }

    @Override // android.widget.TextView
    public void setMinLines(int i2) {
        if (i2 > 1) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setMinLines(i2);
    }

    @Override // android.widget.CompoundButton
    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f3401a = onCheckedChangeListener;
    }

    public void setOnCloseIconClickListener(View.OnClickListener onClickListener) {
        this.f3400a = onClickListener;
        y();
    }

    public void setRippleColor(ColorStateList colorStateList) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.x2(colorStateList);
        }
        if (this.f3404a.l1()) {
            return;
        }
        A();
    }

    public void setRippleColorResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.y2(i2);
            if (this.f3404a.l1()) {
                return;
            }
            A();
        }
    }

    @Override // COM9.lpt1
    public void setShapeAppearanceModel(com7 com7Var) {
        this.f3404a.setShapeAppearanceModel(com7Var);
    }

    public void setShowMotionSpec(com4 com4Var) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.A2(com4Var);
        }
    }

    public void setShowMotionSpecResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.B2(i2);
        }
    }

    @Override // android.widget.TextView
    public void setSingleLine(boolean z2) {
        if (!z2) {
            throw new UnsupportedOperationException("Chip does not support multi-line text");
        }
        super.setSingleLine(z2);
    }

    @Override // android.widget.TextView
    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar == null) {
            return;
        }
        if (charSequence == null) {
            charSequence = "";
        }
        super.setText(auxVar.K2() ? null : charSequence, bufferType);
        com.google.android.material.chip.aux auxVar2 = this.f3404a;
        if (auxVar2 != null) {
            auxVar2.C2(charSequence);
        }
    }

    public void setTextAppearance(c cVar) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.D2(cVar);
        }
        C();
    }

    public void setTextAppearanceResource(int i2) {
        setTextAppearance(getContext(), i2);
    }

    public void setTextEndPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.F2(f2);
        }
    }

    public void setTextEndPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.G2(i2);
        }
    }

    public void setTextStartPadding(float f2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.H2(f2);
        }
    }

    public void setTextStartPaddingResource(int i2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.I2(i2);
        }
    }

    public boolean t() {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        return auxVar != null && auxVar.p1();
    }

    public boolean u() {
        boolean z2 = false;
        playSoundEffect(0);
        View.OnClickListener onClickListener = this.f3400a;
        if (onClickListener != null) {
            onClickListener.onClick(this);
            z2 = true;
        }
        if (this.f9400g) {
            this.f3403a.U(1, 1);
        }
        return z2;
    }

    public final void v() {
        if (this.f3398a != null) {
            this.f3398a = null;
            setMinWidth(0);
            setMinHeight((int) getChipMinHeight());
            z();
        }
    }

    public boolean w() {
        return this.f9399f;
    }

    public final void x(com.google.android.material.chip.aux auxVar) {
        if (auxVar != null) {
            auxVar.o2(null);
        }
    }

    public final void y() {
        if (o() && t() && this.f3400a != null) {
            y.o0(this, this.f3403a);
            this.f9400g = true;
        } else {
            y.o0(this, null);
            this.f9400g = false;
        }
    }

    public final void z() {
        if (lpt4.f551a) {
            A();
            return;
        }
        this.f3404a.J2(true);
        y.s0(this, getBackgroundDrawable());
        B();
        n();
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public Chip(Context context, AttributeSet attributeSet, int i2) {
        int i3 = f9396c;
        super(u.c(context, attributeSet, i2, i3), attributeSet, i2);
        this.f3396a = new Rect();
        this.f3397a = new RectF();
        this.f3402a = new aux();
        Context context2 = getContext();
        D(attributeSet);
        com.google.android.material.chip.aux auxVarU0 = com.google.android.material.chip.aux.u0(context2, attributeSet, i2, i3);
        p(context2, attributeSet, i2);
        setChipDrawable(auxVarU0);
        auxVarU0.X(y.v(this));
        TypedArray typedArrayH = t.h(context2, attributeSet, h4.f3182z, i2, i3, new int[0]);
        boolean zHasValue = typedArrayH.hasValue(h4.u0);
        typedArrayH.recycle();
        this.f3403a = new prn(this);
        y();
        if (!zHasValue) {
            q();
        }
        setChecked(this.f3408b);
        setText(auxVarU0.g1());
        setEllipsize(auxVarU0.a1());
        C();
        if (!this.f3404a.K2()) {
            setLines(1);
            setHorizontallyScrolling(true);
        }
        setGravity(8388627);
        B();
        if (w()) {
            setMinHeight(this.f3407b);
        }
        this.f3395a = y.A(this);
        super.setOnCheckedChangeListener(new con());
    }

    public void setCloseIconVisible(boolean z2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.n2(z2);
        }
        y();
    }

    public void setCheckedIconVisible(boolean z2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.D1(z2);
        }
    }

    public void setChipIconVisible(boolean z2) {
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.R1(z2);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        }
        if (drawable3 == null) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
            return;
        }
        throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        }
        if (drawable3 == null) {
            super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
            return;
        }
        throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.E2(i2);
        }
        C();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(int i2) {
        super.setTextAppearance(i2);
        com.google.android.material.chip.aux auxVar = this.f3404a;
        if (auxVar != null) {
            auxVar.E2(i2);
        }
        C();
    }
}
