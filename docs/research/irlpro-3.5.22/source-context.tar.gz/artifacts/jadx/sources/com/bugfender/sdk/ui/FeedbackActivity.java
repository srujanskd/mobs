package com.bugfender.sdk.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.newrelic.agent.android.api.v2.TraceFieldInterface;
import com.newrelic.agent.android.background.ApplicationStateMonitor;
import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.tracing.Trace;
import com.newrelic.agent.android.tracing.TraceMachine;
import java.io.Serializable;
import java.net.URL;
import p008COm6.com8;
import p008COm6.t;
import p018CoM6.u2;
import p085cOm6.j4;
import p085cOm6.k4;
import p085cOm6.l4;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public class FeedbackActivity extends Activity implements TraceFieldInterface {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public EditText f9246a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ImageView f3274a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f3275a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Trace f3276a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public EditText f9247b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public TextView f3277b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TextView f9248c;

    public class aux implements View.OnClickListener {
        public aux() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            FeedbackActivity.this.setResult(0);
            FeedbackActivity.this.finish();
        }
    }

    public class con implements View.OnClickListener {
        public con() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            URL urlH = com8.h(FeedbackActivity.this.f9246a.getText().toString(), FeedbackActivity.this.f9247b.getText().toString());
            if (urlH != null) {
                Intent intent = new Intent();
                intent.putExtra("result.feedback.url", urlH.toString());
                FeedbackActivity.this.setResult(-1, intent);
            }
            FeedbackActivity.this.finish();
        }
    }

    public static class nul implements Serializable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final String f9251a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final String f9252b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final String f9253c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final String f9254d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public final String f9255e;

        public nul() {
            this.f9251a = "Feedback";
            this.f9252b = "Please insert your feedback here and click send";
            this.f9253c = "Feedback subject";
            this.f9254d = "Feedback message";
            this.f9255e = "Send";
        }

        public /* synthetic */ nul(aux auxVar) {
            this();
        }
    }

    public final void b() {
        u2 u2Var = getIntent().hasExtra("extra.style") ? (u2) getIntent().getSerializableExtra("extra.style") : new u2();
        findViewById(k4.f9151a).setBackgroundResource(u2Var.f6252a);
        this.f3274a.setColorFilter(getResources().getColor(u2Var.f6254c), PorterDuff.Mode.SRC_ATOP);
        this.f3275a.setTextColor(getResources().getColor(u2Var.f6253b));
        this.f3277b.setTextColor(getResources().getColor(u2Var.f6255d));
        findViewById(k4.f9158h).setBackgroundResource(u2Var.f6256e);
        this.f9248c.setTextColor(getResources().getColor(u2Var.f6257f));
        TextView textView = (TextView) findViewById(k4.f9152b);
        Drawable drawable = getResources().getDrawable(j4.f9150a);
        drawable.setColorFilter(getResources().getColor(u2Var.f6257f), PorterDuff.Mode.SRC_ATOP);
        textView.setCompoundDrawablesWithIntrinsicBounds(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
        textView.setTextColor(getResources().getColor(u2Var.f6257f));
        this.f9246a.setTextColor(getResources().getColor(u2Var.f6259h));
        this.f9246a.setHintTextColor(getResources().getColor(u2Var.f6260i));
        this.f9246a.setBackgroundResource(u2Var.f6258g);
        this.f9247b.setTextColor(getResources().getColor(u2Var.f6259h));
        this.f9247b.setHintTextColor(getResources().getColor(u2Var.f6260i));
        this.f9247b.setBackgroundResource(u2Var.f6258g);
    }

    public final void d() {
        nul nulVar = getIntent().hasExtra("extra.texts") ? (nul) getIntent().getSerializableExtra("extra.texts") : new nul(null);
        this.f3275a.setText(nulVar.f9251a);
        this.f3277b.setText(nulVar.f9255e);
        this.f9248c.setText(nulVar.f9252b);
        this.f9246a.setHint(nulVar.f9253c);
        this.f9247b.setHint(nulVar.f9254d);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        TraceMachine.startTracing("FeedbackActivity");
        try {
            TraceMachine.enterMethod(this.f3276a, "FeedbackActivity#onCreate", null);
        } catch (NoSuchFieldError unused) {
            TraceMachine.enterMethod(null, "FeedbackActivity#onCreate", null);
        }
        super.onCreate(bundle);
        try {
            setContentView(l4.f9160a);
            this.f3274a = (ImageView) findViewById(k4.f9153c);
            this.f3275a = (TextView) findViewById(k4.f9159i);
            this.f3277b = (TextView) findViewById(k4.f9157g);
            this.f9248c = (TextView) findViewById(k4.f9156f);
            this.f9246a = (EditText) findViewById(k4.f9155e);
            this.f9247b = (EditText) findViewById(k4.f9154d);
            d();
            b();
            this.f3274a.setOnClickListener(new aux());
            this.f3277b.setOnClickListener(new con());
        } catch (RuntimeException e2) {
            t.b("FeedbackActivity", "Error inflating view. This is known to happen when performing Google Play pre-launch tests but it doesn't occur during app real usage", e2);
            finish();
        }
        TraceMachine.exitMethod();
    }

    @Override // android.app.Activity
    public void onStart() {
        super.onStart();
        ApplicationStateMonitor.getInstance().activityStarted();
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        ApplicationStateMonitor.getInstance().activityStopped();
    }
}
