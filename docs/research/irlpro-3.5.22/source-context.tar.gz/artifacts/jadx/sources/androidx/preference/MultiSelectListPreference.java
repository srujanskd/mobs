package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import p016CoM4.com8;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public class MultiSelectListPreference extends DialogPreference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Set<String> f8439a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence[] f2638a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence[] f8440b;

    public MultiSelectListPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f8439a = new HashSet();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f533f, i2, i3);
        this.f2638a = l0.h(typedArrayObtainStyledAttributes, lpt7.B, lpt7.f6243z);
        this.f8440b = l0.h(typedArrayObtainStyledAttributes, lpt7.C, lpt7.A);
        typedArrayObtainStyledAttributes.recycle();
    }

    public CharSequence[] a() {
        return this.f2638a;
    }

    public CharSequence[] b() {
        return this.f8440b;
    }

    public Set<String> c() {
        return this.f8439a;
    }

    public void d(CharSequence[] charSequenceArr) {
        this.f2638a = charSequenceArr;
    }

    public void e(CharSequence[] charSequenceArr) {
        this.f8440b = charSequenceArr;
    }

    public void f(Set<String> set) {
        this.f8439a.clear();
        this.f8439a.addAll(set);
        persistStringSet(set);
        notifyChanged();
    }

    @Override // androidx.preference.Preference
    public Object onGetDefaultValue(TypedArray typedArray, int i2) {
        CharSequence[] textArray = typedArray.getTextArray(i2);
        HashSet hashSet = new HashSet();
        for (CharSequence charSequence : textArray) {
            hashSet.add(charSequence.toString());
        }
        return hashSet;
    }

    @Override // androidx.preference.Preference
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(aux.class)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        aux auxVar = (aux) parcelable;
        super.onRestoreInstanceState(auxVar.getSuperState());
        f(auxVar.f8441a);
    }

    @Override // androidx.preference.Preference
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState = super.onSaveInstanceState();
        if (isPersistent()) {
            return parcelableOnSaveInstanceState;
        }
        aux auxVar = new aux(parcelableOnSaveInstanceState);
        auxVar.f8441a = c();
        return auxVar;
    }

    @Override // androidx.preference.Preference
    public void onSetInitialValue(Object obj) {
        f(getPersistedStringSet((Set) obj));
    }

    public static class aux extends Preference.con {
        public static final Parcelable.Creator<aux> CREATOR = new C0041aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public Set<String> f8441a;

        /* JADX INFO: renamed from: androidx.preference.MultiSelectListPreference$aux$aux, reason: collision with other inner class name */
        public class C0041aux implements Parcelable.Creator<aux> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public aux createFromParcel(Parcel parcel) {
                return new aux(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public aux[] newArray(int i2) {
                return new aux[i2];
            }
        }

        public aux(Parcel parcel) {
            super(parcel);
            int i2 = parcel.readInt();
            this.f8441a = new HashSet();
            String[] strArr = new String[i2];
            parcel.readStringArray(strArr);
            Collections.addAll(this.f8441a, strArr);
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f8441a.size());
            Set<String> set = this.f8441a;
            parcel.writeStringArray((String[]) set.toArray(new String[set.size()]));
        }

        public aux(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public MultiSelectListPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public MultiSelectListPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6168b, R.attr.dialogPreferenceStyle));
    }

    public MultiSelectListPreference(Context context) {
        this(context, null);
    }
}
