package com.google.android.material.timepicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Checkable;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.chip.Chip;
import java.util.Locale;
import p024Com2.lpt3;
import p024Com2.y;
import p075cOM6.b4;
import p075cOM6.d4;

/* JADX INFO: loaded from: classes.dex */
class TimePickerView extends ConstraintLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View.OnClickListener f9701a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final MaterialButtonToggleGroup f3785a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Chip f3786a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ClockFaceView f3787a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ClockHandView f3788a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f3789a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com2 f3790a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f3791a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Chip f9702b;

    public class aux implements View.OnClickListener {
        public aux() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (TimePickerView.this.f3791a != null) {
                TimePickerView.this.f3791a.c(((Integer) view.getTag(b4.S)).intValue());
            }
        }
    }

    public interface com1 {
        void b();
    }

    public interface com2 {
        void f(int i2);
    }

    public interface com3 {
        void c(int i2);
    }

    public class con implements MaterialButtonToggleGroup.prn {
        public con() {
        }

        @Override // com.google.android.material.button.MaterialButtonToggleGroup.prn
        public void a(MaterialButtonToggleGroup materialButtonToggleGroup, int i2, boolean z2) {
            int i3 = i2 == b4.f8891n ? 1 : 0;
            if (TimePickerView.this.f3790a == null || !z2) {
                return;
            }
            TimePickerView.this.f3790a.f(i3);
        }
    }

    public class nul extends GestureDetector.SimpleOnGestureListener {
        public nul() {
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnDoubleTapListener
        public boolean onDoubleTap(MotionEvent motionEvent) {
            com1 com1Var = TimePickerView.this.f3789a;
            if (com1Var == null) {
                return false;
            }
            com1Var.b();
            return true;
        }
    }

    public class prn implements View.OnTouchListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ GestureDetector f9706a;

        public prn(GestureDetector gestureDetector) {
            this.f9706a = gestureDetector;
        }

        /* JADX WARN: Multi-variable type inference failed */
        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (((Checkable) view).isChecked()) {
                return this.f9706a.onTouchEvent(motionEvent);
            }
            return false;
        }
    }

    public TimePickerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public void E(ClockHandView.prn prnVar) {
        this.f3788a.b(prnVar);
    }

    public void F(int i2) {
        S(this.f3786a, i2 == 12);
        S(this.f9702b, i2 == 10);
    }

    public void G(boolean z2) {
        this.f3788a.j(z2);
    }

    public void H(float f2, boolean z2) {
        this.f3788a.m(f2, z2);
    }

    public void I(lpt3 lpt3Var) {
        y.o0(this.f3786a, lpt3Var);
    }

    public void J(lpt3 lpt3Var) {
        y.o0(this.f9702b, lpt3Var);
    }

    public void K(ClockHandView.nul nulVar) {
        this.f3788a.o(nulVar);
    }

    public void L(com1 com1Var) {
        this.f3789a = com1Var;
    }

    public void M(com2 com2Var) {
        this.f3790a = com2Var;
    }

    public void N(com3 com3Var) {
        this.f3791a = com3Var;
    }

    public final void O() {
        Chip chip = this.f3786a;
        int i2 = b4.S;
        chip.setTag(i2, 12);
        this.f9702b.setTag(i2, 10);
        this.f3786a.setOnClickListener(this.f9701a);
        this.f9702b.setOnClickListener(this.f9701a);
        this.f3786a.setAccessibilityClassName("android.view.View");
        this.f9702b.setAccessibilityClassName("android.view.View");
    }

    public void P(String[] strArr, int i2) {
        this.f3787a.N(strArr, i2);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public final void Q() {
        prn prnVar = new prn(new GestureDetector(getContext(), new nul()));
        this.f3786a.setOnTouchListener(prnVar);
        this.f9702b.setOnTouchListener(prnVar);
    }

    public void R() {
        this.f3785a.setVisibility(0);
    }

    public final void S(Chip chip, boolean z2) {
        chip.setChecked(z2);
        y.q0(chip, z2 ? 2 : 0);
    }

    @SuppressLint({"DefaultLocale"})
    public void T(int i2, int i3, int i4) {
        this.f3785a.e(i2 == 1 ? b4.f8891n : b4.f8890m);
        Locale locale = getResources().getConfiguration().locale;
        String str = String.format(locale, "%02d", Integer.valueOf(i4));
        String str2 = String.format(locale, "%02d", Integer.valueOf(i3));
        if (!TextUtils.equals(this.f3786a.getText(), str)) {
            this.f3786a.setText(str);
        }
        if (TextUtils.equals(this.f9702b.getText(), str2)) {
            return;
        }
        this.f9702b.setText(str2);
    }

    public final void U() {
        if (this.f3785a.getVisibility() == 0) {
            androidx.constraintlayout.widget.nul nulVar = new androidx.constraintlayout.widget.nul();
            nulVar.g(this);
            nulVar.e(b4.f8887j, y.A(this) == 0 ? 2 : 1);
            nulVar.c(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        U();
    }

    @Override // android.view.View
    public void onVisibilityChanged(View view, int i2) {
        super.onVisibilityChanged(view, i2);
        if (view == this && i2 == 0) {
            U();
        }
    }

    public TimePickerView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f9701a = new aux();
        LayoutInflater.from(context).inflate(d4.f8918l, this);
        this.f3787a = (ClockFaceView) findViewById(b4.f8888k);
        MaterialButtonToggleGroup materialButtonToggleGroup = (MaterialButtonToggleGroup) findViewById(b4.f8892o);
        this.f3785a = materialButtonToggleGroup;
        materialButtonToggleGroup.b(new con());
        this.f3786a = (Chip) findViewById(b4.f8897t);
        this.f9702b = (Chip) findViewById(b4.f8894q);
        this.f3788a = (ClockHandView) findViewById(b4.f8889l);
        Q();
        O();
    }
}
