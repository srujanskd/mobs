package androidx.lifecycle;

import COM3.lpt4;
import COM3.lpt5;
import COM3.lpt6;
import COM3.lpt7;
import android.os.Bundle;
import androidx.savedstate.SavedStateRegistry;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
final class SavedStateHandleController implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt4 f8382a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final String f2600a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f8383b = false;

    public static final class aux implements SavedStateRegistry.aux {
        @Override // androidx.savedstate.SavedStateRegistry.aux
        public void a(COM4.con conVar) {
            if (!(conVar instanceof lpt7)) {
                throw new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
            }
            lpt6 viewModelStore = ((lpt7) conVar).getViewModelStore();
            SavedStateRegistry savedStateRegistry = conVar.getSavedStateRegistry();
            Iterator<String> it = viewModelStore.c().iterator();
            while (it.hasNext()) {
                SavedStateHandleController.h(viewModelStore.b(it.next()), savedStateRegistry, conVar.getLifecycle());
            }
            if (viewModelStore.c().isEmpty()) {
                return;
            }
            savedStateRegistry.e(aux.class);
        }
    }

    public SavedStateHandleController(String str, lpt4 lpt4Var) {
        this.f2600a = str;
        this.f8382a = lpt4Var;
    }

    public static void h(lpt5 lpt5Var, SavedStateRegistry savedStateRegistry, nul nulVar) {
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) lpt5Var.c("androidx.lifecycle.savedstate.vm.tag");
        if (savedStateHandleController == null || savedStateHandleController.l()) {
            return;
        }
        savedStateHandleController.i(savedStateRegistry, nulVar);
        m(savedStateRegistry, nulVar);
    }

    public static SavedStateHandleController j(SavedStateRegistry savedStateRegistry, nul nulVar, String str, Bundle bundle) {
        SavedStateHandleController savedStateHandleController = new SavedStateHandleController(str, lpt4.a(savedStateRegistry.a(str), bundle));
        savedStateHandleController.i(savedStateRegistry, nulVar);
        m(savedStateRegistry, nulVar);
        return savedStateHandleController;
    }

    public static void m(final SavedStateRegistry savedStateRegistry, final nul nulVar) {
        nul.EnumC0039nul enumC0039nulB = nulVar.b();
        if (enumC0039nulB == nul.EnumC0039nul.INITIALIZED || enumC0039nulB.a(nul.EnumC0039nul.STARTED)) {
            savedStateRegistry.e(aux.class);
        } else {
            nulVar.a(new prn() { // from class: androidx.lifecycle.SavedStateHandleController.1
                @Override // androidx.lifecycle.prn
                public void f(COM3.com7 com7Var, nul.con conVar) {
                    if (conVar == nul.con.ON_START) {
                        nulVar.c(this);
                        savedStateRegistry.e(aux.class);
                    }
                }
            });
        }
    }

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        if (conVar == nul.con.ON_DESTROY) {
            this.f8383b = false;
            com7Var.getLifecycle().c(this);
        }
    }

    public void i(SavedStateRegistry savedStateRegistry, nul nulVar) {
        if (this.f8383b) {
            throw new IllegalStateException("Already attached to lifecycleOwner");
        }
        this.f8383b = true;
        nulVar.a(this);
        savedStateRegistry.d(this.f2600a, this.f8382a.b());
    }

    public lpt4 k() {
        return this.f8382a;
    }

    public boolean l() {
        return this.f8383b;
    }
}
