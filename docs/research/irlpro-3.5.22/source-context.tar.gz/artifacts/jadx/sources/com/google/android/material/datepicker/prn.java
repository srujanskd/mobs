package com.google.android.material.datepicker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import p024Com2.y;
import p075cOM6.b4;
import p075cOM6.d4;
import p087cOm8.com4;
import p087cOm8.com8;

/* JADX INFO: loaded from: classes.dex */
public class prn extends RecyclerView.com3<con> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f9473a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com4<?> f3518a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final MaterialCalendar.com8 f3519a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com.google.android.material.datepicker.aux f3520a;

    public class aux implements AdapterView.OnItemClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ MaterialCalendarGridView f9474a;

        public aux(MaterialCalendarGridView materialCalendarGridView) {
            this.f9474a = materialCalendarGridView;
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
            if (this.f9474a.getAdapter().n(i2)) {
                prn.this.f3519a.a(this.f9474a.getAdapter().getItem(i2).longValue());
            }
        }
    }

    public static class con extends RecyclerView.h {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final TextView f9475a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final MaterialCalendarGridView f3522a;

        public con(LinearLayout linearLayout, boolean z2) {
            super(linearLayout);
            TextView textView = (TextView) linearLayout.findViewById(b4.E);
            this.f9475a = textView;
            y.p0(textView, true);
            this.f3522a = (MaterialCalendarGridView) linearLayout.findViewById(b4.A);
            if (z2) {
                return;
            }
            textView.setVisibility(8);
        }
    }

    public prn(Context context, com4<?> com4Var, com.google.android.material.datepicker.aux auxVar, MaterialCalendar.com8 com8Var) {
        com8 com8VarU = auxVar.u();
        com8 com8VarR = auxVar.r();
        com8 com8VarT = auxVar.t();
        if (com8VarU.compareTo(com8VarT) > 0) {
            throw new IllegalArgumentException("firstPage cannot be after currentPage");
        }
        if (com8VarT.compareTo(com8VarR) > 0) {
            throw new IllegalArgumentException("currentPage cannot be after lastPage");
        }
        this.f9473a = (nul.f9472a * MaterialCalendar.z(context)) + (MaterialDatePicker.A(context) ? MaterialCalendar.z(context) : 0);
        this.f3520a = auxVar;
        this.f3518a = com4Var;
        this.f3519a = com8Var;
        w(true);
    }

    public CharSequence A(int i2) {
        return z(i2).t();
    }

    public int B(com8 com8Var) {
        return this.f3520a.u().x(com8Var);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    /* JADX INFO: renamed from: C, reason: merged with bridge method [inline-methods] */
    public void n(con conVar, int i2) {
        com8 com8VarW = this.f3520a.u().w(i2);
        conVar.f9475a.setText(com8VarW.t());
        MaterialCalendarGridView materialCalendarGridView = (MaterialCalendarGridView) conVar.f3522a.findViewById(b4.A);
        if (materialCalendarGridView.getAdapter() == null || !com8VarW.equals(materialCalendarGridView.getAdapter().f3515a)) {
            nul nulVar = new nul(com8VarW, this.f3518a, this.f3520a);
            materialCalendarGridView.setNumColumns(com8VarW.f9182c);
            materialCalendarGridView.setAdapter((ListAdapter) nulVar);
        } else {
            materialCalendarGridView.invalidate();
            materialCalendarGridView.getAdapter().m(materialCalendarGridView);
        }
        materialCalendarGridView.setOnItemClickListener(new aux(materialCalendarGridView));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    /* JADX INFO: renamed from: D, reason: merged with bridge method [inline-methods] */
    public con p(ViewGroup viewGroup, int i2) {
        LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(viewGroup.getContext()).inflate(d4.f8924r, viewGroup, false);
        if (!MaterialDatePicker.A(viewGroup.getContext())) {
            return new con(linearLayout, false);
        }
        linearLayout.setLayoutParams(new RecyclerView.lpt3(-1, this.f9473a));
        return new con(linearLayout, true);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    public int f() {
        return this.f3520a.s();
    }

    @Override // androidx.recyclerview.widget.RecyclerView.com3
    public long g(int i2) {
        return this.f3520a.u().w(i2).u();
    }

    public com8 z(int i2) {
        return this.f3520a.u().w(i2);
    }
}
