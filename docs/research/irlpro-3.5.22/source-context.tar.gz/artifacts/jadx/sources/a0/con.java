package a0;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.UnknownServiceException;
import java.security.cert.CertificateException;
import java.util.Arrays;
import java.util.List;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSocket;
import v.com8;

/* JADX INFO: loaded from: classes.dex */
public final class con {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7619a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<com8> f1590a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1591a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f7620b;

    public con(List<com8> list) {
        f.com8.e(list, "connectionSpecs");
        this.f1590a = list;
    }

    public final com8 a(SSLSocket sSLSocket) throws IOException {
        com8 com8Var;
        f.com8.e(sSLSocket, "sslSocket");
        int i2 = this.f7619a;
        int size = this.f1590a.size();
        while (true) {
            if (i2 >= size) {
                com8Var = null;
                break;
            }
            int i3 = i2 + 1;
            com8Var = this.f1590a.get(i2);
            if (com8Var.e(sSLSocket)) {
                this.f7619a = i3;
                break;
            }
            i2 = i3;
        }
        if (com8Var != null) {
            this.f1591a = c(sSLSocket);
            com8Var.c(sSLSocket, this.f7620b);
            return com8Var;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Unable to find acceptable protocols. isFallback=");
        sb.append(this.f7620b);
        sb.append(", modes=");
        sb.append(this.f1590a);
        sb.append(", supported protocols=");
        String[] enabledProtocols = sSLSocket.getEnabledProtocols();
        f.com8.b(enabledProtocols);
        String string = Arrays.toString(enabledProtocols);
        f.com8.d(string, "toString(this)");
        sb.append(string);
        throw new UnknownServiceException(sb.toString());
    }

    public final boolean b(IOException iOException) {
        f.com8.e(iOException, "e");
        this.f7620b = true;
        return (!this.f1591a || (iOException instanceof ProtocolException) || (iOException instanceof InterruptedIOException) || ((iOException instanceof SSLHandshakeException) && (iOException.getCause() instanceof CertificateException)) || (iOException instanceof SSLPeerUnverifiedException) || !(iOException instanceof SSLException)) ? false : true;
    }

    public final boolean c(SSLSocket sSLSocket) {
        int i2 = this.f7619a;
        int size = this.f1590a.size();
        while (i2 < size) {
            int i3 = i2 + 1;
            if (this.f1590a.get(i2).e(sSLSocket)) {
                return true;
            }
            i2 = i3;
        }
        return false;
    }
}
