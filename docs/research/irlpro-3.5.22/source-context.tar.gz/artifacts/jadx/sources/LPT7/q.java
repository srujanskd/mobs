package LPT7;

import java.util.function.UnaryOperator;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class q implements UnaryOperator {
    @Override // java.util.function.Function
    public final Object apply(Object obj) {
        return ((inet.ipaddr.ipv6.nul) obj).getUpper();
    }
}
