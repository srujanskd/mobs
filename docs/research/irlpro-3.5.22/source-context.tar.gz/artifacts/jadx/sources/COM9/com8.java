package COM9;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;

/* JADX INFO: loaded from: classes.dex */
public class com8 {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com9[] f130a = new com9[4];

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Matrix[] f131a = new Matrix[4];

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final Matrix[] f133b = new Matrix[4];

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final PointF f127a = new PointF();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Path f126a = new Path();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Path f5750b = new Path();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com9 f5749a = new com9();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final float[] f129a = new float[2];

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final float[] f132b = new float[2];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Path f5751c = new Path();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Path f5752d = new Path();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f128a = true;

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final com8 f5753a = new com8();
    }

    public interface con {
        void a(com9 com9Var, Matrix matrix, int i2);

        void b(com9 com9Var, Matrix matrix, int i2);
    }

    public static final class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final float f5754a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com7 f134a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final con f135a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Path f136a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final RectF f137a;

        public nul(com7 com7Var, float f2, RectF rectF, con conVar, Path path) {
            this.f135a = conVar;
            this.f134a = com7Var;
            this.f5754a = f2;
            this.f137a = rectF;
            this.f136a = path;
        }
    }

    public com8() {
        for (int i2 = 0; i2 < 4; i2++) {
            this.f130a[i2] = new com9();
            this.f131a[i2] = new Matrix();
            this.f133b[i2] = new Matrix();
        }
    }

    public static com8 k() {
        return aux.f5753a;
    }

    public final float a(int i2) {
        return (i2 + 1) * 90;
    }

    public final void b(nul nulVar, int i2) {
        this.f129a[0] = this.f130a[i2].k();
        this.f129a[1] = this.f130a[i2].l();
        this.f131a[i2].mapPoints(this.f129a);
        if (i2 == 0) {
            Path path = nulVar.f136a;
            float[] fArr = this.f129a;
            path.moveTo(fArr[0], fArr[1]);
        } else {
            Path path2 = nulVar.f136a;
            float[] fArr2 = this.f129a;
            path2.lineTo(fArr2[0], fArr2[1]);
        }
        this.f130a[i2].d(this.f131a[i2], nulVar.f136a);
        con conVar = nulVar.f135a;
        if (conVar != null) {
            conVar.a(this.f130a[i2], this.f131a[i2], i2);
        }
    }

    public final void c(nul nulVar, int i2) {
        int i3 = (i2 + 1) % 4;
        this.f129a[0] = this.f130a[i2].i();
        this.f129a[1] = this.f130a[i2].j();
        this.f131a[i2].mapPoints(this.f129a);
        this.f132b[0] = this.f130a[i3].k();
        this.f132b[1] = this.f130a[i3].l();
        this.f131a[i3].mapPoints(this.f132b);
        float[] fArr = this.f129a;
        float f2 = fArr[0];
        float[] fArr2 = this.f132b;
        float fMax = Math.max(((float) Math.hypot(f2 - fArr2[0], fArr[1] - fArr2[1])) - 0.001f, 0.0f);
        float fI = i(nulVar.f137a, i2);
        this.f5749a.n(0.0f, 0.0f);
        com2 com2VarJ = j(i2, nulVar.f134a);
        com2VarJ.b(fMax, fI, nulVar.f5754a, this.f5749a);
        this.f5751c.reset();
        this.f5749a.d(this.f133b[i2], this.f5751c);
        if (this.f128a && (com2VarJ.a() || l(this.f5751c, i2) || l(this.f5751c, i3))) {
            Path path = this.f5751c;
            path.op(path, this.f5750b, Path.Op.DIFFERENCE);
            this.f129a[0] = this.f5749a.k();
            this.f129a[1] = this.f5749a.l();
            this.f133b[i2].mapPoints(this.f129a);
            Path path2 = this.f126a;
            float[] fArr3 = this.f129a;
            path2.moveTo(fArr3[0], fArr3[1]);
            this.f5749a.d(this.f133b[i2], this.f126a);
        } else {
            this.f5749a.d(this.f133b[i2], nulVar.f136a);
        }
        con conVar = nulVar.f135a;
        if (conVar != null) {
            conVar.b(this.f5749a, this.f133b[i2], i2);
        }
    }

    public void d(com7 com7Var, float f2, RectF rectF, con conVar, Path path) {
        path.rewind();
        this.f126a.rewind();
        this.f5750b.rewind();
        this.f5750b.addRect(rectF, Path.Direction.CW);
        nul nulVar = new nul(com7Var, f2, rectF, conVar, path);
        for (int i2 = 0; i2 < 4; i2++) {
            m(nulVar, i2);
            n(i2);
        }
        for (int i3 = 0; i3 < 4; i3++) {
            b(nulVar, i3);
            c(nulVar, i3);
        }
        path.close();
        this.f126a.close();
        if (this.f126a.isEmpty()) {
            return;
        }
        path.op(this.f126a, Path.Op.UNION);
    }

    public void e(com7 com7Var, float f2, RectF rectF, Path path) {
        d(com7Var, f2, rectF, null, path);
    }

    public final void f(int i2, RectF rectF, PointF pointF) {
        if (i2 == 1) {
            pointF.set(rectF.right, rectF.bottom);
            return;
        }
        if (i2 == 2) {
            pointF.set(rectF.left, rectF.bottom);
        } else if (i2 != 3) {
            pointF.set(rectF.right, rectF.top);
        } else {
            pointF.set(rectF.left, rectF.top);
        }
    }

    public final COM9.nul g(int i2, com7 com7Var) {
        if (i2 == 1) {
            return com7Var.l();
        }
        if (i2 != 2) {
            return i2 != 3 ? com7Var.t() : com7Var.r();
        }
        return com7Var.j();
    }

    public final prn h(int i2, com7 com7Var) {
        if (i2 == 1) {
            return com7Var.k();
        }
        if (i2 != 2) {
            return i2 != 3 ? com7Var.s() : com7Var.q();
        }
        return com7Var.i();
    }

    public final float i(RectF rectF, int i2) {
        float[] fArr = this.f129a;
        com9 com9Var = this.f130a[i2];
        fArr[0] = com9Var.f5757c;
        fArr[1] = com9Var.f5758d;
        this.f131a[i2].mapPoints(fArr);
        return (i2 == 1 || i2 == 3) ? Math.abs(rectF.centerX() - this.f129a[0]) : Math.abs(rectF.centerY() - this.f129a[1]);
    }

    public final com2 j(int i2, com7 com7Var) {
        if (i2 == 1) {
            return com7Var.h();
        }
        if (i2 != 2) {
            return i2 != 3 ? com7Var.o() : com7Var.p();
        }
        return com7Var.n();
    }

    public final boolean l(Path path, int i2) {
        this.f5752d.reset();
        this.f130a[i2].d(this.f131a[i2], this.f5752d);
        RectF rectF = new RectF();
        path.computeBounds(rectF, true);
        this.f5752d.computeBounds(rectF, true);
        path.op(this.f5752d, Path.Op.INTERSECT);
        path.computeBounds(rectF, true);
        if (rectF.isEmpty()) {
            return rectF.width() > 1.0f && rectF.height() > 1.0f;
        }
        return true;
    }

    public final void m(nul nulVar, int i2) {
        h(i2, nulVar.f134a).b(this.f130a[i2], 90.0f, nulVar.f5754a, nulVar.f137a, g(i2, nulVar.f134a));
        float fA = a(i2);
        this.f131a[i2].reset();
        f(i2, nulVar.f137a, this.f127a);
        Matrix matrix = this.f131a[i2];
        PointF pointF = this.f127a;
        matrix.setTranslate(pointF.x, pointF.y);
        this.f131a[i2].preRotate(fA);
    }

    public final void n(int i2) {
        this.f129a[0] = this.f130a[i2].i();
        this.f129a[1] = this.f130a[i2].j();
        this.f131a[i2].mapPoints(this.f129a);
        float fA = a(i2);
        this.f133b[i2].reset();
        Matrix matrix = this.f133b[i2];
        float[] fArr = this.f129a;
        matrix.setTranslate(fArr[0], fArr[1]);
        this.f133b[i2].preRotate(fA);
    }
}
