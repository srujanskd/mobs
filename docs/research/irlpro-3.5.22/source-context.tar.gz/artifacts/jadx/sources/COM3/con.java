package COM3;

/* JADX INFO: loaded from: classes.dex */
public interface con extends com1 {
    @Override // COM3.com1
    default void a(com7 com7Var) {
    }

    @Override // COM3.com1
    default void b(com7 com7Var) {
    }

    @Override // COM3.com1
    default void c(com7 com7Var) {
    }

    @Override // COM3.com1
    default void d(com7 com7Var) {
    }

    @Override // COM3.com1
    default void e(com7 com7Var) {
    }
}
