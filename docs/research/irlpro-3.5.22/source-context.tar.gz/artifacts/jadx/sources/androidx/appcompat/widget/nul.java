package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import p001AuX.com3;
import p022CoN.c;
import p022CoN.q0;
import p022CoN.s0;
import p066aUX.lpt7;

/* JADX INFO: loaded from: classes.dex */
public class nul extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Interpolator f8002a = new DecelerateInterpolator();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2133a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Spinner f2134a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.widget.con f2135a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ViewOnClickListenerC0027nul f2136a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Runnable f2137a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8003b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2138b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8004c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8005d;

    public class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ View f8006a;

        public aux(View view) {
            this.f8006a = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            nul.this.smoothScrollTo(this.f8006a.getLeft() - ((nul.this.getWidth() - this.f8006a.getWidth()) / 2), 0);
            nul.this.f2137a = null;
        }
    }

    public class con extends BaseAdapter {
        public con() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return nul.this.f2135a.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i2) {
            return ((prn) nul.this.f2135a.getChildAt(i2)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                return nul.this.c((lpt7.nul) getItem(i2), true);
            }
            ((prn) view).a((lpt7.nul) getItem(i2));
            return view;
        }
    }

    /* JADX INFO: renamed from: androidx.appcompat.widget.nul$nul, reason: collision with other inner class name */
    public class ViewOnClickListenerC0027nul implements View.OnClickListener {
        public ViewOnClickListenerC0027nul() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((prn) view).b().e();
            int childCount = nul.this.f2135a.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = nul.this.f2135a.getChildAt(i2);
                childAt.setSelected(childAt == view);
            }
        }
    }

    public class prn extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public lpt7.nul f8009a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public View f2140a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ImageView f2141a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public TextView f2142a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final int[] f2144a;

        /* JADX WARN: Illegal instructions before constructor call */
        public prn(Context context, lpt7.nul nulVar, boolean z2) {
            int i2 = com3.f5496d;
            super(context, null, i2);
            int[] iArr = {R.attr.background};
            this.f2144a = iArr;
            this.f8009a = nulVar;
            q0 q0VarV = q0.v(context, null, iArr, i2, 0);
            if (q0VarV.s(0)) {
                setBackgroundDrawable(q0VarV.g(0));
            }
            q0VarV.w();
            if (z2) {
                setGravity(8388627);
            }
            c();
        }

        public void a(lpt7.nul nulVar) {
            this.f8009a = nulVar;
            c();
        }

        public lpt7.nul b() {
            return this.f8009a;
        }

        public void c() {
            lpt7.nul nulVar = this.f8009a;
            View viewB = nulVar.b();
            if (viewB != null) {
                ViewParent parent = viewB.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(viewB);
                    }
                    addView(viewB);
                }
                this.f2140a = viewB;
                TextView textView = this.f2142a;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.f2141a;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.f2141a.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.f2140a;
            if (view != null) {
                removeView(view);
                this.f2140a = null;
            }
            Drawable drawableC = nulVar.c();
            CharSequence charSequenceD = nulVar.d();
            if (drawableC != null) {
                if (this.f2141a == null) {
                    c cVar = new c(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    cVar.setLayoutParams(layoutParams);
                    addView(cVar, 0);
                    this.f2141a = cVar;
                }
                this.f2141a.setImageDrawable(drawableC);
                this.f2141a.setVisibility(0);
            } else {
                ImageView imageView2 = this.f2141a;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.f2141a.setImageDrawable(null);
                }
            }
            boolean z2 = !TextUtils.isEmpty(charSequenceD);
            if (z2) {
                if (this.f2142a == null) {
                    AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, com3.f5497e);
                    appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    appCompatTextView.setLayoutParams(layoutParams2);
                    addView(appCompatTextView);
                    this.f2142a = appCompatTextView;
                }
                this.f2142a.setText(charSequenceD);
                this.f2142a.setVisibility(0);
            } else {
                TextView textView2 = this.f2142a;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.f2142a.setText((CharSequence) null);
                }
            }
            ImageView imageView3 = this.f2141a;
            if (imageView3 != null) {
                imageView3.setContentDescription(nulVar.a());
            }
            s0.a(this, z2 ? null : nulVar.a());
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("aUX.lpt7$nul");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("aUX.lpt7$nul");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (nul.this.f2133a > 0) {
                int measuredWidth = getMeasuredWidth();
                int i4 = nul.this.f2133a;
                if (measuredWidth > i4) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z2) {
            boolean z3 = isSelected() != z2;
            super.setSelected(z2);
            if (z3 && z2) {
                sendAccessibilityEvent(4);
            }
        }
    }

    public void a(int i2) {
        View childAt = this.f2135a.getChildAt(i2);
        Runnable runnable = this.f2137a;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        aux auxVar = new aux(childAt);
        this.f2137a = auxVar;
        post(auxVar);
    }

    public final Spinner b() {
        AppCompatSpinner appCompatSpinner = new AppCompatSpinner(getContext(), null, com3.f5500h);
        appCompatSpinner.setLayoutParams(new androidx.appcompat.widget.con.aux(-2, -1));
        appCompatSpinner.setOnItemSelectedListener(this);
        return appCompatSpinner;
    }

    public prn c(lpt7.nul nulVar, boolean z2) {
        prn prnVar = new prn(getContext(), nulVar, z2);
        if (z2) {
            prnVar.setBackgroundDrawable(null);
            prnVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.f8004c));
        } else {
            prnVar.setFocusable(true);
            if (this.f2136a == null) {
                this.f2136a = new ViewOnClickListenerC0027nul();
            }
            prnVar.setOnClickListener(this.f2136a);
        }
        return prnVar;
    }

    public final boolean d() {
        Spinner spinner = this.f2134a;
        return spinner != null && spinner.getParent() == this;
    }

    public final void e() {
        if (d()) {
            return;
        }
        if (this.f2134a == null) {
            this.f2134a = b();
        }
        removeView(this.f2135a);
        addView(this.f2134a, new ViewGroup.LayoutParams(-2, -1));
        if (this.f2134a.getAdapter() == null) {
            this.f2134a.setAdapter((SpinnerAdapter) new con());
        }
        Runnable runnable = this.f2137a;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.f2137a = null;
        }
        this.f2134a.setSelection(this.f8005d);
    }

    public final boolean f() {
        if (!d()) {
            return false;
        }
        removeView(this.f2134a);
        addView(this.f2135a, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.f2134a.getSelectedItemPosition());
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.f2137a;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        p012COn.nul nulVarB = p012COn.nul.b(getContext());
        setContentHeight(nulVarB.f());
        this.f8003b = nulVarB.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.f2137a;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i2, long j2) {
        ((prn) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        boolean z2 = mode == 1073741824;
        setFillViewport(z2);
        int childCount = this.f2135a.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            this.f2133a = -1;
        } else {
            if (childCount > 2) {
                this.f2133a = (int) (View.MeasureSpec.getSize(i2) * 0.4f);
            } else {
                this.f2133a = View.MeasureSpec.getSize(i2) / 2;
            }
            this.f2133a = Math.min(this.f2133a, this.f8003b);
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.f8004c, 1073741824);
        if (!z2 && this.f2138b) {
            this.f2135a.measure(0, iMakeMeasureSpec);
            if (this.f2135a.getMeasuredWidth() > View.MeasureSpec.getSize(i2)) {
                e();
            } else {
                f();
            }
        } else {
            f();
        }
        int measuredWidth = getMeasuredWidth();
        super.onMeasure(i2, iMakeMeasureSpec);
        int measuredWidth2 = getMeasuredWidth();
        if (!z2 || measuredWidth == measuredWidth2) {
            return;
        }
        setTabSelected(this.f8005d);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void setAllowCollapse(boolean z2) {
        this.f2138b = z2;
    }

    public void setContentHeight(int i2) {
        this.f8004c = i2;
        requestLayout();
    }

    public void setTabSelected(int i2) {
        this.f8005d = i2;
        int childCount = this.f2135a.getChildCount();
        int i3 = 0;
        while (i3 < childCount) {
            View childAt = this.f2135a.getChildAt(i3);
            boolean z2 = i3 == i2;
            childAt.setSelected(z2);
            if (z2) {
                a(i2);
            }
            i3++;
        }
        Spinner spinner = this.f2134a;
        if (spinner == null || i2 < 0) {
            return;
        }
        spinner.setSelection(i2);
    }
}
