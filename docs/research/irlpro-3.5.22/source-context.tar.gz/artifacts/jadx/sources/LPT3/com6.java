package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;
import p139lpt3.d0;

/* JADX INFO: loaded from: classes.dex */
public final class com6 extends lpt4 {
    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int length = str.length();
        if (length == 12) {
            try {
                str = str + lpt3.b(str);
            } catch (d0 e2) {
                throw new IllegalArgumentException(e2);
            }
        } else {
            if (length != 13) {
                throw new IllegalArgumentException("Requested contents should be 12 or 13 digits long, but got ".concat(String.valueOf(length)));
            }
            try {
                if (!lpt3.a(str)) {
                    throw new IllegalArgumentException("Contents do not pass checksum");
                }
            } catch (d0 unused) {
                throw new IllegalArgumentException("Illegal contents");
            }
        }
        lpt1.c(str);
        int i2 = com5.f6624d[Character.digit(str.charAt(0), 10)];
        boolean[] zArr = new boolean[95];
        int iB = lpt1.b(zArr, 0, lpt3.f6632a, true) + 0;
        for (int i3 = 1; i3 <= 6; i3++) {
            int iDigit = Character.digit(str.charAt(i3), 10);
            if (((i2 >> (6 - i3)) & 1) == 1) {
                iDigit += 10;
            }
            iB += lpt1.b(zArr, iB, lpt3.f861b[iDigit], false);
        }
        int iB2 = iB + lpt1.b(zArr, iB, lpt3.f6633b, false);
        for (int i4 = 7; i4 <= 12; i4++) {
            iB2 += lpt1.b(zArr, iB2, lpt3.f860a[Character.digit(str.charAt(i4), 10)], true);
        }
        lpt1.b(zArr, iB2, lpt3.f6632a, true);
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.EAN_13);
    }
}
