package a;

import com.newrelic.agent.android.agentdata.HexAttribute;
import f.com8;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public class aux extends LPT9.aux {

    /* JADX INFO: renamed from: a.aux$aux, reason: collision with other inner class name */
    public static final class C0020aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final C0020aux f7591a = new C0020aux();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public static final Integer f1548a;

        static {
            Integer num;
            Integer num2 = null;
            try {
                Object obj = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get(null);
                num = obj instanceof Integer ? (Integer) obj : null;
            } catch (Throwable unused) {
            }
            if (num != null) {
                if (num.intValue() > 0) {
                    num2 = num;
                }
            }
            f1548a = num2;
        }
    }

    @Override // LPT9.aux
    public void a(Throwable th, Throwable th2) throws IllegalAccessException, InvocationTargetException {
        com8.e(th, HexAttribute.HEX_ATTR_CAUSE);
        com8.e(th2, "exception");
        if (c(19)) {
            th.addSuppressed(th2);
        } else {
            super.a(th, th2);
        }
    }

    public final boolean c(int i2) {
        Integer num = C0020aux.f1548a;
        return num == null || num.intValue() >= i2;
    }
}
