package LPT5;

import android.content.Context;
import app.irlpro.android.R;
import com.newrelic.agent.android.harvest.HarvestTimer;
import com.wmspanel.libstream.lpt5;

/* JADX INFO: loaded from: classes.dex */
public class com4 extends prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final double[] f6663a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final long[] f871a = {15000, HarvestTimer.DEFAULT_HARVEST_PERIOD, 180000};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long f6664b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f6665d;

    static {
        double[] dArr = {0.2d, 0.25d, 0.3333333333333333d, 0.45d, 0.6d, 0.78d, 1.0d};
        f6663a = dArr;
        f6664b = ((long) dArr.length) * 2000 * 2;
    }

    public com4(Context context) {
        super(context);
    }

    public final boolean C() {
        long jCurrentTimeMillis = System.currentTimeMillis();
        int size = ((prn) this).f889b.size();
        int length = f871a.length;
        boolean z2 = true;
        int i2 = size - 1;
        long j2 = 0;
        int i3 = 0;
        while (i2 > 0) {
            aux auxVar = ((prn) this).f889b.get(i2);
            aux auxVar2 = ((prn) this).f889b.get(i2 - 1);
            long j3 = auxVar.f6642a;
            long j4 = jCurrentTimeMillis - j3;
            if (auxVar.f6643b < auxVar2.f6643b) {
                if (j2 == 0 || j2 - j3 >= f6664b) {
                    if (j4 <= f871a[i3]) {
                        return false;
                    }
                    i3++;
                    j2 = j3;
                }
                i2--;
                z2 = true;
            }
            if (i3 == length || jCurrentTimeMillis - j3 >= f871a[length - 1]) {
                return true;
            }
            i2--;
            z2 = true;
        }
        return z2;
    }

    @Override // LPT5.prn
    public void g(long j2, long j3) {
        long jCurrentTimeMillis = System.currentTimeMillis();
        nul nulVar = (nul) con.c(((prn) this).f884a);
        aux auxVar = (aux) con.c(((prn) this).f889b);
        if (nulVar.f6672b == j2 && nulVar.f6673c == j3) {
            if (auxVar.f6643b >= this.f6676c || !C()) {
                return;
            }
            double d2 = this.f6676c;
            double[] dArr = f6663a;
            int i2 = this.f6665d + 1;
            this.f6665d = i2;
            e(Math.round(d2 * dArr[i2]));
            return;
        }
        long j4 = jCurrentTimeMillis - auxVar.f6642a;
        ((prn) this).f884a.add(new nul(jCurrentTimeMillis, j2, j3));
        if (this.f6665d == 0 || j4 < 2000) {
            return;
        }
        if (m(Math.max(auxVar.f6642a + 2000, jCurrentTimeMillis - 10000)) >= auxVar.f6643b / 300000) {
            double d3 = this.f6676c;
            double[] dArr2 = f6663a;
            int i3 = this.f6665d - 1;
            this.f6665d = i3;
            e(Math.round(d3 * dArr2[i3]));
        }
    }

    @Override // LPT5.prn
    public long h() {
        return 2000L;
    }

    @Override // LPT5.prn
    public long i() {
        return 2000L;
    }

    @Override // LPT5.prn
    public String j() {
        return ((prn) this).f879a.getString(R.string.adaptive_bitrate_ladder_ascend);
    }

    @Override // LPT5.prn
    public void x(int i2) {
        ((prn) this).f888b = i2;
        super.x(i2);
        this.f6665d = 2;
    }

    @Override // LPT5.prn
    public void z(lpt5 lpt5Var, int i2) {
        this.f6665d = 2;
        int iRound = (int) Math.round(((double) i2) * f6663a[2]);
        super.z(lpt5Var, iRound);
        f(iRound);
    }
}
