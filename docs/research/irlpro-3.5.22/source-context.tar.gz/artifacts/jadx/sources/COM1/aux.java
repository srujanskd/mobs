package COM1;

import android.text.SpannableStringBuilder;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f5669a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final String f40a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final aux f5670b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public static final prn f41b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public static final String f42b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f43a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final prn f44a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final boolean f45a;

    /* JADX INFO: renamed from: COM1.aux$aux, reason: collision with other inner class name */
    public static final class C0000aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f5671a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public prn f46a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f47a;

        public C0000aux() {
            c(aux.e(Locale.getDefault()));
        }

        public static aux b(boolean z2) {
            return z2 ? aux.f5670b : aux.f5669a;
        }

        public aux a() {
            return (this.f5671a == 2 && this.f46a == aux.f41b) ? b(this.f47a) : new aux(this.f47a, this.f5671a, this.f46a);
        }

        public final void c(boolean z2) {
            this.f47a = z2;
            this.f46a = aux.f41b;
            this.f5671a = 2;
        }
    }

    public static class con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final byte[] f5672a = new byte[inet.ipaddr.ipv6.nul.com4.COMPRESSION_LARGEST];

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public char f48a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final int f49a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final CharSequence f50a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final boolean f51a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f5673b;

        static {
            for (int i2 = 0; i2 < 1792; i2++) {
                f5672a[i2] = Character.getDirectionality(i2);
            }
        }

        public con(CharSequence charSequence, boolean z2) {
            this.f50a = charSequence;
            this.f51a = z2;
            this.f49a = charSequence.length();
        }

        public static byte c(char c2) {
            return c2 < 1792 ? f5672a[c2] : Character.getDirectionality(c2);
        }

        public byte a() {
            char cCharAt = this.f50a.charAt(this.f5673b - 1);
            this.f48a = cCharAt;
            if (Character.isLowSurrogate(cCharAt)) {
                int iCodePointBefore = Character.codePointBefore(this.f50a, this.f5673b);
                this.f5673b -= Character.charCount(iCodePointBefore);
                return Character.getDirectionality(iCodePointBefore);
            }
            this.f5673b--;
            byte bC = c(this.f48a);
            if (!this.f51a) {
                return bC;
            }
            char c2 = this.f48a;
            if (c2 == '>') {
                return h();
            }
            return c2 == ';' ? f() : bC;
        }

        public byte b() {
            char cCharAt = this.f50a.charAt(this.f5673b);
            this.f48a = cCharAt;
            if (Character.isHighSurrogate(cCharAt)) {
                int iCodePointAt = Character.codePointAt(this.f50a, this.f5673b);
                this.f5673b += Character.charCount(iCodePointAt);
                return Character.getDirectionality(iCodePointAt);
            }
            this.f5673b++;
            byte bC = c(this.f48a);
            if (!this.f51a) {
                return bC;
            }
            char c2 = this.f48a;
            if (c2 == '<') {
                return i();
            }
            return c2 == '&' ? g() : bC;
        }

        public int d() {
            this.f5673b = 0;
            int i2 = 0;
            int i3 = 0;
            int i4 = 0;
            while (this.f5673b < this.f49a && i2 == 0) {
                byte b2 = b();
                if (b2 != 0) {
                    if (b2 == 1 || b2 == 2) {
                        if (i4 == 0) {
                            return 1;
                        }
                    } else if (b2 != 9) {
                        switch (b2) {
                            case 14:
                            case 15:
                                i4++;
                                i3 = -1;
                                continue;
                            case 16:
                            case 17:
                                i4++;
                                i3 = 1;
                                continue;
                            case 18:
                                i4--;
                                i3 = 0;
                                continue;
                        }
                    }
                } else if (i4 == 0) {
                    return -1;
                }
                i2 = i4;
            }
            if (i2 == 0) {
                return 0;
            }
            if (i3 != 0) {
                return i3;
            }
            while (this.f5673b > 0) {
                switch (a()) {
                    case 14:
                    case 15:
                        if (i2 == i4) {
                            return -1;
                        }
                        break;
                    case 16:
                    case 17:
                        if (i2 == i4) {
                            return 1;
                        }
                        break;
                    case 18:
                        i4++;
                        continue;
                    default:
                        continue;
                }
                i4--;
            }
            return 0;
        }

        public int e() {
            this.f5673b = this.f49a;
            int i2 = 0;
            while (true) {
                int i3 = i2;
                while (this.f5673b > 0) {
                    byte bA = a();
                    if (bA == 0) {
                        if (i2 == 0) {
                            return -1;
                        }
                        if (i3 == 0) {
                        }
                    } else if (bA == 1 || bA == 2) {
                        if (i2 == 0) {
                            return 1;
                        }
                        if (i3 == 0) {
                        }
                    } else if (bA != 9) {
                        switch (bA) {
                            case 14:
                            case 15:
                                if (i3 == i2) {
                                    return -1;
                                }
                                i2--;
                                break;
                            case 16:
                            case 17:
                                if (i3 == i2) {
                                    return 1;
                                }
                                i2--;
                                break;
                            case 18:
                                i2++;
                                break;
                            default:
                                if (i3 != 0) {
                                }
                                break;
                        }
                    } else {
                        continue;
                    }
                }
                return 0;
            }
        }

        public final byte f() {
            char cCharAt;
            int i2 = this.f5673b;
            do {
                int i3 = this.f5673b;
                if (i3 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f50a;
                int i4 = i3 - 1;
                this.f5673b = i4;
                cCharAt = charSequence.charAt(i4);
                this.f48a = cCharAt;
                if (cCharAt == '&') {
                    return (byte) 12;
                }
            } while (cCharAt != ';');
            this.f5673b = i2;
            this.f48a = ';';
            return (byte) 13;
        }

        public final byte g() {
            char cCharAt;
            do {
                int i2 = this.f5673b;
                if (i2 >= this.f49a) {
                    return (byte) 12;
                }
                CharSequence charSequence = this.f50a;
                this.f5673b = i2 + 1;
                cCharAt = charSequence.charAt(i2);
                this.f48a = cCharAt;
            } while (cCharAt != ';');
            return (byte) 12;
        }

        public final byte h() {
            char cCharAt;
            int i2 = this.f5673b;
            while (true) {
                int i3 = this.f5673b;
                if (i3 <= 0) {
                    break;
                }
                CharSequence charSequence = this.f50a;
                int i4 = i3 - 1;
                this.f5673b = i4;
                char cCharAt2 = charSequence.charAt(i4);
                this.f48a = cCharAt2;
                if (cCharAt2 == '<') {
                    return (byte) 12;
                }
                if (cCharAt2 == '>') {
                    break;
                }
                if (cCharAt2 == '\"' || cCharAt2 == '\'') {
                    do {
                        int i5 = this.f5673b;
                        if (i5 <= 0) {
                            break;
                        }
                        CharSequence charSequence2 = this.f50a;
                        int i6 = i5 - 1;
                        this.f5673b = i6;
                        cCharAt = charSequence2.charAt(i6);
                        this.f48a = cCharAt;
                    } while (cCharAt != cCharAt2);
                }
            }
            this.f5673b = i2;
            this.f48a = '>';
            return (byte) 13;
        }

        public final byte i() {
            char cCharAt;
            int i2 = this.f5673b;
            while (true) {
                int i3 = this.f5673b;
                if (i3 >= this.f49a) {
                    this.f5673b = i2;
                    this.f48a = '<';
                    return (byte) 13;
                }
                CharSequence charSequence = this.f50a;
                this.f5673b = i3 + 1;
                char cCharAt2 = charSequence.charAt(i3);
                this.f48a = cCharAt2;
                if (cCharAt2 == '>') {
                    return (byte) 12;
                }
                if (cCharAt2 == '\"' || cCharAt2 == '\'') {
                    do {
                        int i4 = this.f5673b;
                        if (i4 >= this.f49a) {
                            break;
                        }
                        CharSequence charSequence2 = this.f50a;
                        this.f5673b = i4 + 1;
                        cCharAt = charSequence2.charAt(i4);
                        this.f48a = cCharAt;
                    } while (cCharAt != cCharAt2);
                }
            }
        }
    }

    static {
        prn prnVar = com1.f5676c;
        f41b = prnVar;
        f40a = Character.toString((char) 8206);
        f42b = Character.toString((char) 8207);
        f5669a = new aux(false, 2, prnVar);
        f5670b = new aux(true, 2, prnVar);
    }

    public aux(boolean z2, int i2, prn prnVar) {
        this.f45a = z2;
        this.f43a = i2;
        this.f44a = prnVar;
    }

    public static int a(CharSequence charSequence) {
        return new con(charSequence, false).d();
    }

    public static int b(CharSequence charSequence) {
        return new con(charSequence, false).e();
    }

    public static aux c() {
        return new C0000aux().a();
    }

    public static boolean e(Locale locale) {
        return com2.a(locale) == 1;
    }

    public boolean d() {
        return (this.f43a & 2) != 0;
    }

    public final String f(CharSequence charSequence, prn prnVar) {
        boolean zIsRtl = prnVar.isRtl(charSequence, 0, charSequence.length());
        if (!this.f45a && (zIsRtl || b(charSequence) == 1)) {
            return f40a;
        }
        if (this.f45a) {
            return (!zIsRtl || b(charSequence) == -1) ? f42b : "";
        }
        return "";
    }

    public final String g(CharSequence charSequence, prn prnVar) {
        boolean zIsRtl = prnVar.isRtl(charSequence, 0, charSequence.length());
        if (!this.f45a && (zIsRtl || a(charSequence) == 1)) {
            return f40a;
        }
        if (this.f45a) {
            return (!zIsRtl || a(charSequence) == -1) ? f42b : "";
        }
        return "";
    }

    public CharSequence h(CharSequence charSequence) {
        return i(charSequence, this.f44a, true);
    }

    public CharSequence i(CharSequence charSequence, prn prnVar, boolean z2) {
        if (charSequence == null) {
            return null;
        }
        boolean zIsRtl = prnVar.isRtl(charSequence, 0, charSequence.length());
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        if (d() && z2) {
            spannableStringBuilder.append((CharSequence) g(charSequence, zIsRtl ? com1.f5675b : com1.f5674a));
        }
        if (zIsRtl != this.f45a) {
            spannableStringBuilder.append(zIsRtl ? (char) 8235 : (char) 8234);
            spannableStringBuilder.append(charSequence);
            spannableStringBuilder.append((char) 8236);
        } else {
            spannableStringBuilder.append(charSequence);
        }
        if (z2) {
            spannableStringBuilder.append((CharSequence) f(charSequence, zIsRtl ? com1.f5675b : com1.f5674a));
        }
        return spannableStringBuilder;
    }

    public String j(String str) {
        return k(str, this.f44a, true);
    }

    public String k(String str, prn prnVar, boolean z2) {
        if (str == null) {
            return null;
        }
        return i(str, prnVar, z2).toString();
    }
}
