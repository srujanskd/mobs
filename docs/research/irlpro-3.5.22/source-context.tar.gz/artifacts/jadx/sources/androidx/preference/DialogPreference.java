package androidx.preference;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import p016CoM4.com8;
import p016CoM4.lpt7;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public abstract class DialogPreference extends Preference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8419a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2627a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2628a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f8420b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f8421c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f8422d;

    public interface aux {
        <T extends Preference> T a(CharSequence charSequence);
    }

    public DialogPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f530c, i2, i3);
        String strF = l0.f(typedArrayObtainStyledAttributes, lpt7.f6234q, lpt7.f6217h);
        this.f2628a = strF;
        if (strF == null) {
            this.f2628a = getTitle();
        }
        this.f8420b = l0.f(typedArrayObtainStyledAttributes, lpt7.f6233p, lpt7.f6219i);
        this.f2627a = l0.c(typedArrayObtainStyledAttributes, lpt7.f6229n, lpt7.f6221j);
        this.f8421c = l0.f(typedArrayObtainStyledAttributes, lpt7.f6236s, lpt7.f6223k);
        this.f8422d = l0.f(typedArrayObtainStyledAttributes, lpt7.f6235r, lpt7.f6225l);
        this.f8419a = l0.e(typedArrayObtainStyledAttributes, lpt7.f6231o, lpt7.f6227m, 0);
        typedArrayObtainStyledAttributes.recycle();
    }

    public Drawable getDialogIcon() {
        return this.f2627a;
    }

    public int getDialogLayoutResource() {
        return this.f8419a;
    }

    public CharSequence getDialogMessage() {
        return this.f8420b;
    }

    public CharSequence getDialogTitle() {
        return this.f2628a;
    }

    public CharSequence getNegativeButtonText() {
        return this.f8422d;
    }

    public CharSequence getPositiveButtonText() {
        return this.f8421c;
    }

    @Override // androidx.preference.Preference
    public void onClick() {
        getPreferenceManager().v(this);
    }

    public DialogPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public DialogPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, l0.a(context, com8.f6168b, R.attr.dialogPreferenceStyle));
    }

    public DialogPreference(Context context) {
        this(context, null);
    }
}
