package a0;

import com.newrelic.agent.android.util.Constants;
import f.com8;
import i0.b;
import i0.com7;
import i0.lpt9;
import java.io.IOException;
import java.net.ProtocolException;
import v.e;
import v.f;
import v.g;
import v.h;
import v.lpt5;

/* JADX INFO: loaded from: classes.dex */
public final class nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com1 f7621a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com2 f1592a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final prn f1593a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final b0.prn f1594a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt5 f1595a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1596a;

    public final class aux extends i0.com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final long f7622a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ nul f1597a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public long f7623b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f1598b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f7624c;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public aux(nul nulVar, lpt9 lpt9Var, long j2) {
            super(lpt9Var);
            com8.e(nulVar, "this$0");
            com8.e(lpt9Var, "delegate");
            this.f1597a = nulVar;
            this.f7622a = j2;
        }

        public final <E extends IOException> E a(E e2) {
            if (this.f1598b) {
                return e2;
            }
            this.f1598b = true;
            return (E) this.f1597a.a(this.f7623b, false, true, e2);
        }

        @Override // i0.com1, i0.lpt9, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            if (this.f7624c) {
                return;
            }
            this.f7624c = true;
            long j2 = this.f7622a;
            if (j2 != -1 && this.f7623b != j2) {
                throw new ProtocolException("unexpected end of stream");
            }
            try {
                super.close();
                a(null);
            } catch (IOException e2) {
                throw a(e2);
            }
        }

        @Override // i0.com1, i0.lpt9
        public void e(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "source");
            if (!(!this.f7624c)) {
                throw new IllegalStateException("closed".toString());
            }
            long j3 = this.f7622a;
            if (j3 == -1 || this.f7623b + j2 <= j3) {
                try {
                    super.e(conVar, j2);
                    this.f7623b += j2;
                    return;
                } catch (IOException e2) {
                    throw a(e2);
                }
            }
            throw new ProtocolException("expected " + this.f7622a + " bytes but received " + (this.f7623b + j2));
        }

        @Override // i0.com1, i0.lpt9, java.io.Flushable
        public void flush() throws IOException {
            try {
                super.flush();
            } catch (IOException e2) {
                throw a(e2);
            }
        }
    }

    public final class con extends i0.com2 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final long f7625a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ nul f1599a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public long f7626b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f1600b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f7627c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f7628d;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public con(nul nulVar, b bVar, long j2) {
            super(bVar);
            com8.e(nulVar, "this$0");
            com8.e(bVar, "delegate");
            this.f1599a = nulVar;
            this.f7625a = j2;
            this.f1600b = true;
            if (j2 == 0) {
                c(null);
            }
        }

        @Override // i0.b
        public long A(i0.con conVar, long j2) throws IOException {
            com8.e(conVar, "sink");
            if (!(!this.f7628d)) {
                throw new IllegalStateException("closed".toString());
            }
            try {
                long jA = a().A(conVar, j2);
                if (this.f1600b) {
                    this.f1600b = false;
                    this.f1599a.i().v(this.f1599a.g());
                }
                if (jA == -1) {
                    c(null);
                    return -1L;
                }
                long j3 = this.f7626b + jA;
                long j4 = this.f7625a;
                if (j4 != -1 && j3 > j4) {
                    throw new ProtocolException("expected " + this.f7625a + " bytes but received " + j3);
                }
                this.f7626b = j3;
                if (j3 == j4) {
                    c(null);
                }
                return jA;
            } catch (IOException e2) {
                throw c(e2);
            }
        }

        public final <E extends IOException> E c(E e2) {
            if (this.f7627c) {
                return e2;
            }
            this.f7627c = true;
            if (e2 == null && this.f1600b) {
                this.f1600b = false;
                this.f1599a.i().v(this.f1599a.g());
            }
            return (E) this.f1599a.a(this.f7626b, true, false, e2);
        }

        @Override // i0.com2, i0.b, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            if (this.f7628d) {
                return;
            }
            this.f7628d = true;
            try {
                super.close();
                c(null);
            } catch (IOException e2) {
                throw c(e2);
            }
        }
    }

    public nul(com1 com1Var, lpt5 lpt5Var, prn prnVar, b0.prn prnVar2) {
        com8.e(com1Var, "call");
        com8.e(lpt5Var, "eventListener");
        com8.e(prnVar, "finder");
        com8.e(prnVar2, "codec");
        this.f7621a = com1Var;
        this.f1595a = lpt5Var;
        this.f1593a = prnVar;
        this.f1594a = prnVar2;
        this.f1592a = prnVar2.b();
    }

    public final <E extends IOException> E a(long j2, boolean z2, boolean z3, E e2) {
        if (e2 != null) {
            s(e2);
        }
        if (z3) {
            if (e2 != null) {
                this.f1595a.r(this.f7621a, e2);
            } else {
                this.f1595a.p(this.f7621a, j2);
            }
        }
        if (z2) {
            if (e2 != null) {
                this.f1595a.w(this.f7621a, e2);
            } else {
                this.f1595a.u(this.f7621a, j2);
            }
        }
        return (E) this.f7621a.r(this, z3, z2, e2);
    }

    public final void b() {
        this.f1594a.cancel();
    }

    public final lpt9 c(e eVar, boolean z2) throws IOException {
        com8.e(eVar, "request");
        this.f1596a = z2;
        f fVarA = eVar.a();
        com8.b(fVarA);
        long jA = fVarA.a();
        this.f1595a.q(this.f7621a);
        return new aux(this, this.f1594a.c(eVar, jA), jA);
    }

    public final void d() {
        this.f1594a.cancel();
        this.f7621a.r(this, true, true, null);
    }

    public final void e() throws IOException {
        try {
            this.f1594a.a();
        } catch (IOException e2) {
            this.f1595a.r(this.f7621a, e2);
            s(e2);
            throw e2;
        }
    }

    public final void f() throws IOException {
        try {
            this.f1594a.f();
        } catch (IOException e2) {
            this.f1595a.r(this.f7621a, e2);
            s(e2);
            throw e2;
        }
    }

    public final com1 g() {
        return this.f7621a;
    }

    public final com2 h() {
        return this.f1592a;
    }

    public final lpt5 i() {
        return this.f1595a;
    }

    public final prn j() {
        return this.f1593a;
    }

    public final boolean k() {
        return !com8.a(this.f1593a.d().l().h(), this.f1592a.z().a().l().h());
    }

    public final boolean l() {
        return this.f1596a;
    }

    public final void m() {
        this.f1594a.b().y();
    }

    public final void n() {
        this.f7621a.r(this, true, false, null);
    }

    public final h o(g gVar) throws IOException {
        com8.e(gVar, "response");
        try {
            String strY = g.y(gVar, Constants.Network.CONTENT_TYPE_HEADER, null, 2, null);
            long jE = this.f1594a.e(gVar);
            return new b0.com4(strY, jE, com7.b(new con(this, this.f1594a.h(gVar), jE)));
        } catch (IOException e2) {
            this.f1595a.w(this.f7621a, e2);
            s(e2);
            throw e2;
        }
    }

    public final g.aux p(boolean z2) throws IOException {
        try {
            g.aux auxVarG = this.f1594a.g(z2);
            if (auxVarG != null) {
                auxVarG.initExchange$okhttp(this);
            }
            return auxVarG;
        } catch (IOException e2) {
            this.f1595a.w(this.f7621a, e2);
            s(e2);
            throw e2;
        }
    }

    public final void q(g gVar) {
        com8.e(gVar, "response");
        this.f1595a.x(this.f7621a, gVar);
    }

    public final void r() {
        this.f1595a.y(this.f7621a);
    }

    public final void s(IOException iOException) {
        this.f1593a.h(iOException);
        this.f1594a.b().G(this.f7621a, iOException);
    }

    public final void t(e eVar) throws IOException {
        com8.e(eVar, "request");
        try {
            this.f1595a.t(this.f7621a);
            this.f1594a.d(eVar);
            this.f1595a.s(this.f7621a, eVar);
        } catch (IOException e2) {
            this.f1595a.r(this.f7621a, e2);
            s(e2);
            throw e2;
        }
    }
}
