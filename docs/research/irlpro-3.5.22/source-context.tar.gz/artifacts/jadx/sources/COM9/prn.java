package COM9;

import android.graphics.RectF;

/* JADX INFO: loaded from: classes.dex */
public class prn {
    public void a(com9 com9Var, float f2, float f3, float f4) {
        throw null;
    }

    public void b(com9 com9Var, float f2, float f3, RectF rectF, nul nulVar) {
        a(com9Var, f2, f3, nulVar.a(rectF));
    }
}
