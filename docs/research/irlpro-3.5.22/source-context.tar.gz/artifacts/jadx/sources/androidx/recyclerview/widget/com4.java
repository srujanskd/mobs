package androidx.recyclerview.widget;

import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class com4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux f8668a;

    public interface aux {
        androidx.recyclerview.widget.aux.con a(int i2, int i3, int i4, Object obj);

        void b(androidx.recyclerview.widget.aux.con conVar);
    }

    public com4(aux auxVar) {
        this.f8668a = auxVar;
    }

    public final int a(List<androidx.recyclerview.widget.aux.con> list) {
        boolean z2 = false;
        for (int size = list.size() - 1; size >= 0; size--) {
            if (list.get(size).f8647a != 8) {
                z2 = true;
            } else if (z2) {
                return size;
            }
        }
        return -1;
    }

    public void b(List<androidx.recyclerview.widget.aux.con> list) {
        while (true) {
            int iA = a(list);
            if (iA == -1) {
                return;
            } else {
                d(list, iA, iA + 1);
            }
        }
    }

    public final void c(List<androidx.recyclerview.widget.aux.con> list, int i2, androidx.recyclerview.widget.aux.con conVar, int i3, androidx.recyclerview.widget.aux.con conVar2) {
        int i4 = conVar.f8649c;
        int i5 = conVar2.f8648b;
        int i6 = i4 < i5 ? -1 : 0;
        int i7 = conVar.f8648b;
        if (i7 < i5) {
            i6++;
        }
        if (i5 <= i7) {
            conVar.f8648b = i7 + conVar2.f8649c;
        }
        int i8 = conVar2.f8648b;
        if (i8 <= i4) {
            conVar.f8649c = i4 + conVar2.f8649c;
        }
        conVar2.f8648b = i8 + i6;
        list.set(i2, conVar2);
        list.set(i3, conVar);
    }

    public final void d(List<androidx.recyclerview.widget.aux.con> list, int i2, int i3) {
        androidx.recyclerview.widget.aux.con conVar = list.get(i2);
        androidx.recyclerview.widget.aux.con conVar2 = list.get(i3);
        int i4 = conVar2.f8647a;
        if (i4 == 1) {
            c(list, i2, conVar, i3, conVar2);
        } else if (i4 == 2) {
            e(list, i2, conVar, i3, conVar2);
        } else {
            if (i4 != 4) {
                return;
            }
            f(list, i2, conVar, i3, conVar2);
        }
    }

    public void e(List<androidx.recyclerview.widget.aux.con> list, int i2, androidx.recyclerview.widget.aux.con conVar, int i3, androidx.recyclerview.widget.aux.con conVar2) {
        boolean z2;
        int i4 = conVar.f8648b;
        int i5 = conVar.f8649c;
        boolean z3 = false;
        if (i4 < i5) {
            if (conVar2.f8648b == i4 && conVar2.f8649c == i5 - i4) {
                z2 = false;
                z3 = true;
            } else {
                z2 = false;
            }
        } else if (conVar2.f8648b == i5 + 1 && conVar2.f8649c == i4 - i5) {
            z2 = true;
            z3 = true;
        } else {
            z2 = true;
        }
        int i6 = conVar2.f8648b;
        if (i5 < i6) {
            conVar2.f8648b = i6 - 1;
        } else {
            int i7 = conVar2.f8649c;
            if (i5 < i6 + i7) {
                conVar2.f8649c = i7 - 1;
                conVar.f8647a = 2;
                conVar.f8649c = 1;
                if (conVar2.f8649c == 0) {
                    list.remove(i3);
                    this.f8668a.b(conVar2);
                    return;
                }
                return;
            }
        }
        int i8 = conVar.f8648b;
        int i9 = conVar2.f8648b;
        androidx.recyclerview.widget.aux.con conVarA = null;
        if (i8 <= i9) {
            conVar2.f8648b = i9 + 1;
        } else {
            int i10 = conVar2.f8649c;
            if (i8 < i9 + i10) {
                conVarA = this.f8668a.a(2, i8 + 1, (i9 + i10) - i8, null);
                conVar2.f8649c = conVar.f8648b - conVar2.f8648b;
            }
        }
        if (z3) {
            list.set(i2, conVar2);
            list.remove(i3);
            this.f8668a.b(conVar);
            return;
        }
        if (z2) {
            if (conVarA != null) {
                int i11 = conVar.f8648b;
                if (i11 > conVarA.f8648b) {
                    conVar.f8648b = i11 - conVarA.f8649c;
                }
                int i12 = conVar.f8649c;
                if (i12 > conVarA.f8648b) {
                    conVar.f8649c = i12 - conVarA.f8649c;
                }
            }
            int i13 = conVar.f8648b;
            if (i13 > conVar2.f8648b) {
                conVar.f8648b = i13 - conVar2.f8649c;
            }
            int i14 = conVar.f8649c;
            if (i14 > conVar2.f8648b) {
                conVar.f8649c = i14 - conVar2.f8649c;
            }
        } else {
            if (conVarA != null) {
                int i15 = conVar.f8648b;
                if (i15 >= conVarA.f8648b) {
                    conVar.f8648b = i15 - conVarA.f8649c;
                }
                int i16 = conVar.f8649c;
                if (i16 >= conVarA.f8648b) {
                    conVar.f8649c = i16 - conVarA.f8649c;
                }
            }
            int i17 = conVar.f8648b;
            if (i17 >= conVar2.f8648b) {
                conVar.f8648b = i17 - conVar2.f8649c;
            }
            int i18 = conVar.f8649c;
            if (i18 >= conVar2.f8648b) {
                conVar.f8649c = i18 - conVar2.f8649c;
            }
        }
        list.set(i2, conVar2);
        if (conVar.f8648b != conVar.f8649c) {
            list.set(i3, conVar);
        } else {
            list.remove(i3);
        }
        if (conVarA != null) {
            list.add(i2, conVarA);
        }
    }

    /* JADX WARN: Code duplicated, block: B:11:0x0027  */
    /* JADX WARN: Code duplicated, block: B:12:0x002b  */
    /* JADX WARN: Code duplicated, block: B:14:0x0031  */
    /* JADX WARN: Code duplicated, block: B:17:0x0048  */
    /* JADX WARN: Code duplicated, block: B:18:0x004c  */
    /* JADX WARN: Code duplicated, block: B:20:0x0056  */
    /* JADX WARN: Code duplicated, block: B:22:0x005b  */
    /* JADX WARN: Code duplicated, block: B:24:? A[RETURN, SYNTHETIC] */
    public void f(List<androidx.recyclerview.widget.aux.con> list, int i2, androidx.recyclerview.widget.aux.con conVar, int i3, androidx.recyclerview.widget.aux.con conVar2) {
        androidx.recyclerview.widget.aux.con conVarA;
        int i4;
        int i5;
        int i6;
        int i7 = conVar.f8649c;
        int i8 = conVar2.f8648b;
        androidx.recyclerview.widget.aux.con conVarA2 = null;
        if (i7 >= i8) {
            int i9 = conVar2.f8649c;
            if (i7 < i8 + i9) {
                conVar2.f8649c = i9 - 1;
                conVarA = this.f8668a.a(4, conVar.f8648b, 1, conVar2.f2856a);
            }
            i4 = conVar.f8648b;
            i5 = conVar2.f8648b;
            if (i4 <= i5) {
                conVar2.f8648b = i5 + 1;
            } else {
                i6 = conVar2.f8649c;
                if (i4 < i5 + i6) {
                    int i10 = (i5 + i6) - i4;
                    conVarA2 = this.f8668a.a(4, i4 + 1, i10, conVar2.f2856a);
                    conVar2.f8649c -= i10;
                }
            }
            list.set(i3, conVar);
            if (conVar2.f8649c > 0) {
                list.set(i2, conVar2);
            } else {
                list.remove(i2);
                this.f8668a.b(conVar2);
            }
            if (conVarA != null) {
                list.add(i2, conVarA);
            }
            if (conVarA2 != null) {
                list.add(i2, conVarA2);
            }
        }
        conVar2.f8648b = i8 - 1;
        conVarA = null;
        i4 = conVar.f8648b;
        i5 = conVar2.f8648b;
        if (i4 <= i5) {
            conVar2.f8648b = i5 + 1;
        } else {
            i6 = conVar2.f8649c;
            if (i4 < i5 + i6) {
                int i11 = (i5 + i6) - i4;
                conVarA2 = this.f8668a.a(4, i4 + 1, i11, conVar2.f2856a);
                conVar2.f8649c -= i11;
            }
        }
        list.set(i3, conVar);
        if (conVar2.f8649c > 0) {
            list.set(i2, conVar2);
        } else {
            list.remove(i2);
            this.f8668a.b(conVar2);
        }
        if (conVarA != null) {
            list.add(i2, conVarA);
        }
        if (conVarA2 != null) {
            list.add(i2, conVarA2);
        }
    }
}
