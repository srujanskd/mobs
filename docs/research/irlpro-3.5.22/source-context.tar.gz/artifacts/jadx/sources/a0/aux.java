package a0;

import f.com8;
import java.io.IOException;
import v.a;
import v.g;

/* JADX INFO: loaded from: classes.dex */
public final class aux implements a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final aux f7592a = new aux();

    @Override // v.a
    public g a(a.aux auxVar) throws IOException {
        com8.e(auxVar, "chain");
        b0.com3 com3Var = (b0.com3) auxVar;
        return b0.com3.d(com3Var, 0, com3Var.e().q(com3Var), null, 0, 0, 0, 61, null).b(com3Var.i());
    }
}
