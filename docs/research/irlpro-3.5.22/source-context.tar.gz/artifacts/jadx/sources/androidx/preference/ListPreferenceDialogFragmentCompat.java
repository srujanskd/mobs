package androidx.preference;

import android.content.DialogInterface;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class ListPreferenceDialogFragmentCompat extends PreferenceDialogFragmentCompat {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CharSequence[] f8435a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence[] f8436b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8437c;

    public class aux implements DialogInterface.OnClickListener {
        public aux() {
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialogInterface, int i2) {
            ListPreferenceDialogFragmentCompat listPreferenceDialogFragmentCompat = ListPreferenceDialogFragmentCompat.this;
            listPreferenceDialogFragmentCompat.f8437c = i2;
            listPreferenceDialogFragmentCompat.onClick(dialogInterface, -1);
            dialogInterface.dismiss();
        }
    }

    public static ListPreferenceDialogFragmentCompat s(String str) {
        ListPreferenceDialogFragmentCompat listPreferenceDialogFragmentCompat = new ListPreferenceDialogFragmentCompat();
        Bundle bundle = new Bundle(1);
        bundle.putString("key", str);
        listPreferenceDialogFragmentCompat.setArguments(bundle);
        return listPreferenceDialogFragmentCompat;
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void n(boolean z2) {
        int i2;
        if (!z2 || (i2 = this.f8437c) < 0) {
            return;
        }
        String string = this.f8436b[i2].toString();
        ListPreference listPreferenceR = r();
        if (listPreferenceR.callChangeListener(string)) {
            listPreferenceR.l(string);
        }
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void o(androidx.appcompat.app.aux.C0023aux c0023aux) {
        super.o(c0023aux);
        c0023aux.q(this.f8435a, this.f8437c, new aux());
        c0023aux.o(null, null);
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.f8437c = bundle.getInt("ListPreferenceDialogFragment.index", 0);
            this.f8435a = bundle.getCharSequenceArray("ListPreferenceDialogFragment.entries");
            this.f8436b = bundle.getCharSequenceArray("ListPreferenceDialogFragment.entryValues");
            return;
        }
        ListPreference listPreferenceR = r();
        if (listPreferenceR.b() == null || listPreferenceR.d() == null) {
            throw new IllegalStateException("ListPreference requires an entries array and an entryValues array.");
        }
        this.f8437c = listPreferenceR.a(listPreferenceR.e());
        this.f8435a = listPreferenceR.b();
        this.f8436b = listPreferenceR.d();
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("ListPreferenceDialogFragment.index", this.f8437c);
        bundle.putCharSequenceArray("ListPreferenceDialogFragment.entries", this.f8435a);
        bundle.putCharSequenceArray("ListPreferenceDialogFragment.entryValues", this.f8436b);
    }

    public final ListPreference r() {
        return (ListPreference) j();
    }
}
