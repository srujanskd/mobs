package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;
import p001AuX.com9;

/* JADX INFO: loaded from: classes.dex */
public class nul implements com5, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7839a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Context f1920a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public LayoutInflater f1921a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ExpandedMenuView f1922a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1923a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1924a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public aux f1925a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7840b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7841c;

    public class aux extends BaseAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7842a = -1;

        public aux() {
            a();
        }

        public void a() {
            com3 com3VarV = nul.this.f1923a.v();
            if (com3VarV != null) {
                ArrayList<com3> arrayListZ = nul.this.f1923a.z();
                int size = arrayListZ.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (arrayListZ.get(i2) == com3VarV) {
                        this.f7842a = i2;
                        return;
                    }
                }
            }
            this.f7842a = -1;
        }

        @Override // android.widget.Adapter
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public com3 getItem(int i2) {
            ArrayList<com3> arrayListZ = nul.this.f1923a.z();
            int i3 = i2 + nul.this.f7839a;
            int i4 = this.f7842a;
            if (i4 >= 0 && i3 >= i4) {
                i3++;
            }
            return arrayListZ.get(i3);
        }

        @Override // android.widget.Adapter
        public int getCount() {
            int size = nul.this.f1923a.z().size() - nul.this.f7839a;
            return this.f7842a < 0 ? size : size - 1;
        }

        @Override // android.widget.Adapter
        public long getItemId(int i2) {
            return i2;
        }

        @Override // android.widget.Adapter
        public View getView(int i2, View view, ViewGroup viewGroup) {
            if (view == null) {
                nul nulVar = nul.this;
                view = nulVar.f1921a.inflate(nulVar.f7841c, viewGroup, false);
            }
            ((com6.aux) view).b(getItem(i2), 0);
            return view;
        }

        @Override // android.widget.BaseAdapter
        public void notifyDataSetChanged() {
            a();
            super.notifyDataSetChanged();
        }
    }

    public nul(Context context, int i2) {
        this(i2, 0);
        this.f1920a = context;
        this.f1921a = LayoutInflater.from(context);
    }

    public ListAdapter a() {
        if (this.f1925a == null) {
            this.f1925a = new aux();
        }
        return this.f1925a;
    }

    public com6 b(ViewGroup viewGroup) {
        if (this.f1922a == null) {
            this.f1922a = (ExpandedMenuView) this.f1921a.inflate(com9.f5597g, viewGroup, false);
            if (this.f1925a == null) {
                this.f1925a = new aux();
            }
            this.f1922a.setAdapter((ListAdapter) this.f1925a);
            this.f1922a.setOnItemClickListener(this);
        }
        return this.f1922a;
    }

    @Override // androidx.appcompat.view.menu.com5
    public void c(com1 com1Var, boolean z2) {
        com5.aux auxVar = this.f1924a;
        if (auxVar != null) {
            auxVar.c(com1Var, z2);
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public void e(boolean z2) {
        aux auxVar = this.f1925a;
        if (auxVar != null) {
            auxVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean f() {
        return false;
    }

    @Override // androidx.appcompat.view.menu.com5
    public void g(com5.aux auxVar) {
        this.f1924a = auxVar;
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean h(com1 com1Var, com3 com3Var) {
        return false;
    }

    @Override // androidx.appcompat.view.menu.com5
    public void i(Context context, com1 com1Var) {
        if (this.f7840b != 0) {
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, this.f7840b);
            this.f1920a = contextThemeWrapper;
            this.f1921a = LayoutInflater.from(contextThemeWrapper);
        } else if (this.f1920a != null) {
            this.f1920a = context;
            if (this.f1921a == null) {
                this.f1921a = LayoutInflater.from(context);
            }
        }
        this.f1923a = com1Var;
        aux auxVar = this.f1925a;
        if (auxVar != null) {
            auxVar.notifyDataSetChanged();
        }
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean j(com8 com8Var) {
        if (!com8Var.hasVisibleItems()) {
            return false;
        }
        new com2(com8Var).b(null);
        com5.aux auxVar = this.f1924a;
        if (auxVar == null) {
            return true;
        }
        auxVar.d(com8Var);
        return true;
    }

    @Override // androidx.appcompat.view.menu.com5
    public boolean k(com1 com1Var, com3 com3Var) {
        return false;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i2, long j2) {
        this.f1923a.M(this.f1925a.getItem(i2), this, 0);
    }

    public nul(int i2, int i3) {
        this.f7841c = i2;
        this.f7840b = i3;
    }
}
