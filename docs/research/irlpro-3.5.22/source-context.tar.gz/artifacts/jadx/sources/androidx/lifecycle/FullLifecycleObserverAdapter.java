package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
class FullLifecycleObserverAdapter implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final COM3.com1 f8366a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final prn f2588a;

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8367a;

        static {
            int[] iArr = new int[nul.con.values().length];
            f8367a = iArr;
            try {
                iArr[nul.con.ON_CREATE.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8367a[nul.con.ON_START.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8367a[nul.con.ON_RESUME.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f8367a[nul.con.ON_PAUSE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f8367a[nul.con.ON_STOP.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f8367a[nul.con.ON_DESTROY.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f8367a[nul.con.ON_ANY.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    public FullLifecycleObserverAdapter(COM3.com1 com1Var, prn prnVar) {
        this.f8366a = com1Var;
        this.f2588a = prnVar;
    }

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        switch (aux.f8367a[conVar.ordinal()]) {
            case 1:
                this.f8366a.d(com7Var);
                break;
            case 2:
                this.f8366a.c(com7Var);
                break;
            case 3:
                this.f8366a.g(com7Var);
                break;
            case 4:
                this.f8366a.a(com7Var);
                break;
            case 5:
                this.f8366a.b(com7Var);
                break;
            case 6:
                this.f8366a.e(com7Var);
                break;
            case 7:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        prn prnVar = this.f2588a;
        if (prnVar != null) {
            prnVar.f(com7Var, conVar);
        }
    }
}
