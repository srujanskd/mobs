package com.google.android.material.timepicker;

import android.content.Context;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import p042LpT1.j;
import p042LpT1.m;
import p042LpT1.n;
import p075cOM6.f4;
import p081cOm2.e2;

/* JADX INFO: loaded from: classes.dex */
public class aux implements ClockHandView.prn, TimePickerView.com3, TimePickerView.com2, ClockHandView.nul, n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String[] f9707a = {"12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final String[] f9708b = {"00", "2", "4", "6", "8", "10", "12", "14", "16", "18", "20", "22"};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final String[] f9709c = {"00", "5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55"};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f3793a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final m f3794a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TimePickerView f3795a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public float f3796b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3797b = false;

    /* JADX INFO: renamed from: com.google.android.material.timepicker.aux$aux, reason: collision with other inner class name */
    public class C0065aux extends j {
        public C0065aux(Context context, int i2) {
            super(context, i2);
        }

        @Override // p042LpT1.j, p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.X(view.getResources().getString(f4.f8939j, String.valueOf(aux.this.f3794a.n())));
        }
    }

    public class con extends j {
        public con(Context context, int i2) {
            super(context, i2);
        }

        @Override // p042LpT1.j, p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.X(view.getResources().getString(f4.f8941l, String.valueOf(aux.this.f3794a.f7039c)));
        }
    }

    public aux(TimePickerView timePickerView, m mVar) {
        this.f3795a = timePickerView;
        this.f3794a = mVar;
        j();
    }

    @Override // p042LpT1.n
    public void a() {
        this.f3795a.setVisibility(0);
    }

    @Override // p042LpT1.n
    public void b() {
        this.f3795a.setVisibility(8);
    }

    @Override // com.google.android.material.timepicker.TimePickerView.com3
    public void c(int i2) {
        l(i2, true);
    }

    @Override // com.google.android.material.timepicker.ClockHandView.prn
    public void d(float f2, boolean z2) {
        if (this.f3797b) {
            return;
        }
        m mVar = this.f3794a;
        int i2 = mVar.f7038b;
        int i3 = mVar.f7039c;
        int iRound = Math.round(f2);
        m mVar2 = this.f3794a;
        if (mVar2.f7040d == 12) {
            mVar2.s((iRound + 3) / 6);
            this.f3793a = (float) Math.floor(this.f3794a.f7039c * 6);
        } else {
            this.f3794a.r((iRound + (h() / 2)) / h());
            this.f3796b = this.f3794a.n() * h();
        }
        if (z2) {
            return;
        }
        m();
        k(i2, i3);
    }

    @Override // com.google.android.material.timepicker.ClockHandView.nul
    public void e(float f2, boolean z2) {
        this.f3797b = true;
        m mVar = this.f3794a;
        int i2 = mVar.f7039c;
        int i3 = mVar.f7038b;
        if (mVar.f7040d == 10) {
            this.f3795a.H(this.f3796b, false);
            AccessibilityManager accessibilityManager = (AccessibilityManager) PRN.aux.g(this.f3795a.getContext(), AccessibilityManager.class);
            if (!(accessibilityManager != null && accessibilityManager.isTouchExplorationEnabled())) {
                l(12, true);
            }
        } else {
            int iRound = Math.round(f2);
            if (!z2) {
                this.f3794a.s(((iRound + 15) / 30) * 5);
                this.f3793a = this.f3794a.f7039c * 6;
            }
            this.f3795a.H(this.f3793a, z2);
        }
        this.f3797b = false;
        m();
        k(i3, i2);
    }

    @Override // com.google.android.material.timepicker.TimePickerView.com2
    public void f(int i2) {
        this.f3794a.t(i2);
    }

    public final int h() {
        return this.f3794a.f7037a == 1 ? 15 : 30;
    }

    public final String[] i() {
        return this.f3794a.f7037a == 1 ? f9708b : f9707a;
    }

    @Override // p042LpT1.n
    public void invalidate() {
        this.f3796b = this.f3794a.n() * h();
        m mVar = this.f3794a;
        this.f3793a = mVar.f7039c * 6;
        l(mVar.f7040d, false);
        m();
    }

    public void j() {
        if (this.f3794a.f7037a == 0) {
            this.f3795a.R();
        }
        this.f3795a.E(this);
        this.f3795a.N(this);
        this.f3795a.M(this);
        this.f3795a.K(this);
        n();
        invalidate();
    }

    public final void k(int i2, int i3) {
        m mVar = this.f3794a;
        if (mVar.f7039c == i3 && mVar.f7038b == i2) {
            return;
        }
        this.f3795a.performHapticFeedback(4);
    }

    public void l(int i2, boolean z2) {
        boolean z3 = i2 == 12;
        this.f3795a.G(z3);
        this.f3794a.f7040d = i2;
        this.f3795a.P(z3 ? f9709c : i(), z3 ? f4.f8941l : f4.f8939j);
        this.f3795a.H(z3 ? this.f3793a : this.f3796b, z2);
        this.f3795a.F(i2);
        this.f3795a.J(new C0065aux(this.f3795a.getContext(), f4.f8938i));
        this.f3795a.I(new con(this.f3795a.getContext(), f4.f8940k));
    }

    public final void m() {
        TimePickerView timePickerView = this.f3795a;
        m mVar = this.f3794a;
        timePickerView.T(mVar.f7041e, mVar.n(), this.f3794a.f7039c);
    }

    public final void n() {
        o(f9707a, "%d");
        o(f9708b, "%d");
        o(f9709c, "%02d");
    }

    public final void o(String[] strArr, String str) {
        for (int i2 = 0; i2 < strArr.length; i2++) {
            strArr[i2] = m.m(this.f3795a.getResources(), strArr[i2], str);
        }
    }
}
