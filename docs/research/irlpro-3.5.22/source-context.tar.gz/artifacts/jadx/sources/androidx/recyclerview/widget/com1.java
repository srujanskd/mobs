package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: classes.dex */
public final class com1 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ThreadLocal<com1> f8650a = new ThreadLocal<>();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static Comparator<nul> f2857a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f2858a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f8651b;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<RecyclerView> f2859a = new ArrayList<>();

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ArrayList<nul> f2860b = new ArrayList<>();

    public static class aux implements Comparator<nul> {
        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(nul nulVar, nul nulVar2) {
            RecyclerView recyclerView = nulVar.f2862a;
            if ((recyclerView == null) != (nulVar2.f2862a == null)) {
                return recyclerView == null ? 1 : -1;
            }
            boolean z2 = nulVar.f2863a;
            if (z2 != nulVar2.f2863a) {
                return z2 ? -1 : 1;
            }
            int i2 = nulVar2.f8655a - nulVar.f8655a;
            if (i2 != 0) {
                return i2;
            }
            int i3 = nulVar.f8656b - nulVar2.f8656b;
            if (i3 != 0) {
                return i3;
            }
            return 0;
        }
    }

    @SuppressLint({"VisibleForTests"})
    public static class con implements RecyclerView.lpt2.nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8652a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int[] f2861a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8653b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8654c;

        @Override // androidx.recyclerview.widget.RecyclerView.lpt2.nul
        public void a(int i2, int i3) {
            if (i2 < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            }
            if (i3 < 0) {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
            int i4 = this.f8654c * 2;
            int[] iArr = this.f2861a;
            if (iArr == null) {
                int[] iArr2 = new int[4];
                this.f2861a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i4 >= iArr.length) {
                int[] iArr3 = new int[i4 * 2];
                this.f2861a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            }
            int[] iArr4 = this.f2861a;
            iArr4[i4] = i2;
            iArr4[i4 + 1] = i3;
            this.f8654c++;
        }

        public void b() {
            int[] iArr = this.f2861a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f8654c = 0;
        }

        public void c(RecyclerView recyclerView, boolean z2) {
            this.f8654c = 0;
            int[] iArr = this.f2861a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            RecyclerView.lpt2 lpt2Var = recyclerView.f2722a;
            if (recyclerView.f2716a == null || lpt2Var == null || !lpt2Var.u0()) {
                return;
            }
            if (z2) {
                if (!recyclerView.f2727a.p()) {
                    lpt2Var.p(recyclerView.f2716a.f(), this);
                }
            } else if (!recyclerView.m0()) {
                lpt2Var.o(this.f8652a, this.f8653b, recyclerView.f2720a, this);
            }
            int i2 = this.f8654c;
            if (i2 > lpt2Var.f8600a) {
                lpt2Var.f8600a = i2;
                lpt2Var.f8605f = z2;
                recyclerView.f2726a.K();
            }
        }

        public boolean d(int i2) {
            if (this.f2861a != null) {
                int i3 = this.f8654c * 2;
                for (int i4 = 0; i4 < i3; i4 += 2) {
                    if (this.f2861a[i4] == i2) {
                        return true;
                    }
                }
            }
            return false;
        }

        public void e(int i2, int i3) {
            this.f8652a = i2;
            this.f8653b = i3;
        }
    }

    public static class nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8655a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public RecyclerView f2862a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2863a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8656b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8657c;

        public void a() {
            this.f2863a = false;
            this.f8655a = 0;
            this.f8656b = 0;
            this.f2862a = null;
            this.f8657c = 0;
        }
    }

    public static boolean e(RecyclerView recyclerView, int i2) {
        int iJ = recyclerView.f2731a.j();
        for (int i3 = 0; i3 < iJ; i3++) {
            RecyclerView.h hVarG0 = RecyclerView.g0(recyclerView.f2731a.i(i3));
            if (hVarG0.f8593a == i2 && !hVarG0.t()) {
                return true;
            }
        }
        return false;
    }

    public void a(RecyclerView recyclerView) {
        this.f2859a.add(recyclerView);
    }

    public final void b() {
        nul nulVar;
        int size = this.f2859a.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            RecyclerView recyclerView = this.f2859a.get(i3);
            if (recyclerView.getWindowVisibility() == 0) {
                recyclerView.f2728a.c(recyclerView, false);
                i2 += recyclerView.f2728a.f8654c;
            }
        }
        this.f2860b.ensureCapacity(i2);
        int i4 = 0;
        for (int i5 = 0; i5 < size; i5++) {
            RecyclerView recyclerView2 = this.f2859a.get(i5);
            if (recyclerView2.getWindowVisibility() == 0) {
                con conVar = recyclerView2.f2728a;
                int iAbs = Math.abs(conVar.f8652a) + Math.abs(conVar.f8653b);
                for (int i6 = 0; i6 < conVar.f8654c * 2; i6 += 2) {
                    if (i4 >= this.f2860b.size()) {
                        nulVar = new nul();
                        this.f2860b.add(nulVar);
                    } else {
                        nulVar = this.f2860b.get(i4);
                    }
                    int[] iArr = conVar.f2861a;
                    int i7 = iArr[i6 + 1];
                    nulVar.f2863a = i7 <= iAbs;
                    nulVar.f8655a = iAbs;
                    nulVar.f8656b = i7;
                    nulVar.f2862a = recyclerView2;
                    nulVar.f8657c = iArr[i6];
                    i4++;
                }
            }
        }
        Collections.sort(this.f2860b, f2857a);
    }

    public final void c(nul nulVar, long j2) {
        RecyclerView.h hVarI = i(nulVar.f2862a, nulVar.f8657c, nulVar.f2863a ? Long.MAX_VALUE : j2);
        if (hVarI == null || hVarI.f2790a == null || !hVarI.s() || hVarI.t()) {
            return;
        }
        h(hVarI.f2790a.get(), j2);
    }

    public final void d(long j2) {
        for (int i2 = 0; i2 < this.f2860b.size(); i2++) {
            nul nulVar = this.f2860b.get(i2);
            if (nulVar.f2862a == null) {
                return;
            }
            c(nulVar, j2);
            nulVar.a();
        }
    }

    public void f(RecyclerView recyclerView, int i2, int i3) {
        if (recyclerView.isAttachedToWindow() && this.f2858a == 0) {
            this.f2858a = recyclerView.getNanoTime();
            recyclerView.post(this);
        }
        recyclerView.f2728a.e(i2, i3);
    }

    public void g(long j2) {
        b();
        d(j2);
    }

    public final void h(RecyclerView recyclerView, long j2) {
        if (recyclerView == null) {
            return;
        }
        if (recyclerView.f2760k && recyclerView.f2731a.j() != 0) {
            recyclerView.V0();
        }
        con conVar = recyclerView.f2728a;
        conVar.c(recyclerView, true);
        if (conVar.f8654c != 0) {
            try {
                p013CoM1.com8.a("RV Nested Prefetch");
                recyclerView.f2720a.f(recyclerView.f2716a);
                for (int i2 = 0; i2 < conVar.f8654c * 2; i2 += 2) {
                    i(recyclerView, conVar.f2861a[i2], j2);
                }
                p013CoM1.com8.b();
            } catch (Throwable th) {
                p013CoM1.com8.b();
                throw th;
            }
        }
    }

    public final RecyclerView.h i(RecyclerView recyclerView, int i2, long j2) {
        if (e(recyclerView, i2)) {
            return null;
        }
        RecyclerView.lpt9 lpt9Var = recyclerView.f2726a;
        try {
            recyclerView.H0();
            RecyclerView.h hVarI = lpt9Var.I(i2, false, j2);
            if (hVarI != null) {
                if (!hVarI.s() || hVarI.t()) {
                    lpt9Var.a(hVarI, false);
                } else {
                    lpt9Var.B(hVarI.f2786a);
                }
            }
            return hVarI;
        } finally {
            recyclerView.J0(false);
        }
    }

    public void j(RecyclerView recyclerView) {
        this.f2859a.remove(recyclerView);
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            p013CoM1.com8.a("RV Prefetch");
            if (!this.f2859a.isEmpty()) {
                int size = this.f2859a.size();
                long jMax = 0;
                for (int i2 = 0; i2 < size; i2++) {
                    RecyclerView recyclerView = this.f2859a.get(i2);
                    if (recyclerView.getWindowVisibility() == 0) {
                        jMax = Math.max(recyclerView.getDrawingTime(), jMax);
                    }
                }
                if (jMax != 0) {
                    g(TimeUnit.MILLISECONDS.toNanos(jMax) + this.f8651b);
                }
            }
        } finally {
            this.f2858a = 0L;
            p013CoM1.com8.b();
        }
    }
}
