package com.google.android.material.theme;

import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import p011COm9.lpt2;
import p022CoN.lpt1;
import p022CoN.lpt3;
import p033LPt1.g;
import p066aUX.d;
import p076cOM7.com6;

/* JADX INFO: loaded from: classes.dex */
public class MaterialComponentsViewInflater extends d {
    @Override // p066aUX.d
    public lpt1 c(Context context, AttributeSet attributeSet) {
        return new g(context, attributeSet);
    }

    @Override // p066aUX.d
    public AppCompatButton d(Context context, AttributeSet attributeSet) {
        return new MaterialButton(context, attributeSet);
    }

    @Override // p066aUX.d
    public lpt3 e(Context context, AttributeSet attributeSet) {
        return new com6(context, attributeSet);
    }

    @Override // p066aUX.d
    public p022CoN.g k(Context context, AttributeSet attributeSet) {
        return new lpt2(context, attributeSet);
    }

    @Override // p066aUX.d
    public AppCompatTextView o(Context context, AttributeSet attributeSet) {
        return new MaterialTextView(context, attributeSet);
    }
}
