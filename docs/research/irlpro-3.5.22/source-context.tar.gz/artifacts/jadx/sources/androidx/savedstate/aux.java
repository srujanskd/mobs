package androidx.savedstate;

import COM4.con;
import android.os.Bundle;
import androidx.lifecycle.nul;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final con f8743a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SavedStateRegistry f2926a = new SavedStateRegistry();

    public aux(con conVar) {
        this.f8743a = conVar;
    }

    public static aux a(con conVar) {
        return new aux(conVar);
    }

    public SavedStateRegistry b() {
        return this.f2926a;
    }

    public void c(Bundle bundle) {
        nul lifecycle = this.f8743a.getLifecycle();
        if (lifecycle.b() != nul.EnumC0039nul.INITIALIZED) {
            throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
        }
        lifecycle.a(new Recreator(this.f8743a));
        this.f2926a.b(lifecycle, bundle);
    }

    public void d(Bundle bundle) {
        this.f2926a.c(bundle);
    }
}
