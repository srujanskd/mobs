package androidx.preference;

import android.R;
import android.content.Context;
import android.util.AttributeSet;
import p016CoM4.com8;
import p100com1.l0;

/* JADX INFO: loaded from: classes.dex */
public final class PreferenceScreen extends PreferenceGroup {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8465d;

    public PreferenceScreen(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, l0.a(context, com8.f6173g, R.attr.preferenceScreenStyle));
        this.f8465d = true;
    }

    @Override // androidx.preference.PreferenceGroup
    public boolean h() {
        return false;
    }

    @Override // androidx.preference.Preference
    public void onClick() {
        nul.con conVarH;
        if (getIntent() != null || getFragment() != null || g() == 0 || (conVarH = getPreferenceManager().h()) == null) {
            return;
        }
        conVarH.e(this);
    }

    public boolean p() {
        return this.f8465d;
    }
}
