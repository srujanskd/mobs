package COM3;

/* JADX INFO: loaded from: classes.dex */
public interface com7 {
    androidx.lifecycle.nul getLifecycle();
}
