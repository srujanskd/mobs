package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.view.menu.com5;
import androidx.appcompat.view.menu.com8;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p001AuX.lpt3;
import p022CoN.c;
import p022CoN.j0;
import p022CoN.q0;
import p022CoN.r;
import p022CoN.s0;
import p022CoN.u0;
import p024Com2.f;
import p024Com2.i;
import p024Com2.j;
import p024Com2.y;
import p066aUX.lpt7;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7957a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public j0 f2079a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final j f2080a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Context f2081a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f2082a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2083a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f2084a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ImageButton f2085a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ImageView f2086a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f2087a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.view.menu.com1.aux f2088a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f2089a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ActionMenuView.com1 f2090a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ActionMenuView f2091a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f2092a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.widget.aux f2093a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.appcompat.widget.prn f2094a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2095a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2096a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<View> f2097a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int[] f2098a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7958b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f2099b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ImageButton f2100b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public TextView f2101b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f2102b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final ArrayList<View> f2103b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2104b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7959c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f2105c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ArrayList<MenuItem> f2106c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2107c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7960d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2108d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7961e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7962f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7963g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f7964h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f7965i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f7966j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f7967k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f7968l;

    public class aux implements ActionMenuView.com1 {
        public aux() {
        }

        @Override // androidx.appcompat.widget.ActionMenuView.com1
        public boolean onMenuItemClick(MenuItem menuItem) {
            if (Toolbar.this.f2080a.b(menuItem)) {
                return true;
            }
            Toolbar.this.getClass();
            return false;
        }
    }

    public interface com2 {
    }

    public class con implements Runnable {
        public con() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.P();
        }
    }

    public class nul implements View.OnClickListener {
        public nul() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Toolbar.this.e();
        }
    }

    public class prn implements com5 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public androidx.appcompat.view.menu.com1 f7975a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.appcompat.view.menu.com3 f2109a;

        public prn() {
        }

        @Override // androidx.appcompat.view.menu.com5
        public void c(androidx.appcompat.view.menu.com1 com1Var, boolean z2) {
        }

        @Override // androidx.appcompat.view.menu.com5
        public void e(boolean z2) {
            if (this.f2109a != null) {
                androidx.appcompat.view.menu.com1 com1Var = this.f7975a;
                boolean z3 = false;
                if (com1Var != null) {
                    int size = com1Var.size();
                    for (int i2 = 0; i2 < size; i2++) {
                        if (this.f7975a.getItem(i2) == this.f2109a) {
                            z3 = true;
                            break;
                        }
                    }
                }
                if (z3) {
                    return;
                }
                h(this.f7975a, this.f2109a);
            }
        }

        @Override // androidx.appcompat.view.menu.com5
        public boolean f() {
            return false;
        }

        @Override // androidx.appcompat.view.menu.com5
        public boolean h(androidx.appcompat.view.menu.com1 com1Var, androidx.appcompat.view.menu.com3 com3Var) {
            KeyEvent.Callback callback = Toolbar.this.f2084a;
            if (callback instanceof p012COn.com1) {
                ((p012COn.com1) callback).onActionViewCollapsed();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.f2084a);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.f2100b);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.f2084a = null;
            toolbar3.a();
            this.f2109a = null;
            Toolbar.this.requestLayout();
            com3Var.t(false);
            return true;
        }

        @Override // androidx.appcompat.view.menu.com5
        public void i(Context context, androidx.appcompat.view.menu.com1 com1Var) {
            androidx.appcompat.view.menu.com3 com3Var;
            androidx.appcompat.view.menu.com1 com1Var2 = this.f7975a;
            if (com1Var2 != null && (com3Var = this.f2109a) != null) {
                com1Var2.f(com3Var);
            }
            this.f7975a = com1Var;
        }

        @Override // androidx.appcompat.view.menu.com5
        public boolean j(com8 com8Var) {
            return false;
        }

        @Override // androidx.appcompat.view.menu.com5
        public boolean k(androidx.appcompat.view.menu.com1 com1Var, androidx.appcompat.view.menu.com3 com3Var) {
            Toolbar.this.g();
            ViewParent parent = Toolbar.this.f2100b.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.f2100b);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.f2100b);
            }
            Toolbar.this.f2084a = com3Var.getActionView();
            this.f2109a = com3Var;
            ViewParent parent2 = Toolbar.this.f2084a.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.f2084a);
                }
                com1 com1VarGenerateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                com1VarGenerateDefaultLayoutParams.f7709a = (toolbar4.f7960d & 112) | 8388611;
                com1VarGenerateDefaultLayoutParams.f7970b = 2;
                toolbar4.f2084a.setLayoutParams(com1VarGenerateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.f2084a);
            }
            Toolbar.this.I();
            Toolbar.this.requestLayout();
            com3Var.t(true);
            KeyEvent.Callback callback = Toolbar.this.f2084a;
            if (callback instanceof p012COn.com1) {
                ((p012COn.com1) callback).onActionViewExpanded();
            }
            return true;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, p001AuX.com3.O);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i2 = 0; i2 < menu.size(); i2++) {
            arrayList.add(menu.getItem(i2));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new p012COn.com5(getContext());
    }

    public boolean A() {
        ActionMenuView actionMenuView = this.f2091a;
        return actionMenuView != null && actionMenuView.G();
    }

    public boolean B() {
        ActionMenuView actionMenuView = this.f2091a;
        return actionMenuView != null && actionMenuView.H();
    }

    public final int C(View view, int i2, int[] iArr, int i3) {
        com1 com1Var = (com1) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) com1Var).leftMargin - iArr[0];
        int iMax = i2 + Math.max(0, i4);
        iArr[0] = Math.max(0, -i4);
        int iQ = q(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iQ, iMax + measuredWidth, view.getMeasuredHeight() + iQ);
        return iMax + measuredWidth + ((ViewGroup.MarginLayoutParams) com1Var).rightMargin;
    }

    public final int D(View view, int i2, int[] iArr, int i3) {
        com1 com1Var = (com1) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) com1Var).rightMargin - iArr[1];
        int iMax = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int iQ = q(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iQ, iMax, view.getMeasuredHeight() + iQ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) com1Var).leftMargin);
    }

    public final int E(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i6) + Math.max(0, i7);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + iMax + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public final void F(View view, int i2, int i3, int i4, int i5, int i6) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i6 >= 0) {
            if (mode != 0) {
                i6 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i6);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i6, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final void G() {
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        this.f2080a.a(getMenu(), getMenuInflater());
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f2106c = currentMenuItems2;
    }

    public final void H() {
        removeCallbacks(this.f2096a);
        post(this.f2096a);
    }

    public void I() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            if (((com1) childAt.getLayoutParams()).f7970b != 2 && childAt != this.f2091a) {
                removeViewAt(childCount);
                this.f2103b.add(childAt);
            }
        }
    }

    public void J(int i2, int i3) {
        h();
        this.f2079a.g(i2, i3);
    }

    public void K(androidx.appcompat.view.menu.com1 com1Var, androidx.appcompat.widget.aux auxVar) {
        if (com1Var == null && this.f2091a == null) {
            return;
        }
        k();
        androidx.appcompat.view.menu.com1 com1VarL = this.f2091a.L();
        if (com1VarL == com1Var) {
            return;
        }
        if (com1VarL != null) {
            com1VarL.O(this.f2093a);
            com1VarL.O(this.f2092a);
        }
        if (this.f2092a == null) {
            this.f2092a = new prn();
        }
        auxVar.G(true);
        if (com1Var != null) {
            com1Var.c(auxVar, this.f2081a);
            com1Var.c(this.f2092a, this.f2081a);
        } else {
            auxVar.i(this.f2081a, null);
            this.f2092a.i(this.f2081a, null);
            auxVar.e(true);
            this.f2092a.e(true);
        }
        this.f2091a.setPopupTheme(this.f7957a);
        this.f2091a.setPresenter(auxVar);
        this.f2093a = auxVar;
    }

    public void L(Context context, int i2) {
        this.f7959c = i2;
        TextView textView = this.f2101b;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public void M(Context context, int i2) {
        this.f7958b = i2;
        TextView textView = this.f2087a;
        if (textView != null) {
            textView.setTextAppearance(context, i2);
        }
    }

    public final boolean N() {
        if (!this.f2108d) {
            return false;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            if (O(childAt) && childAt.getMeasuredWidth() > 0 && childAt.getMeasuredHeight() > 0) {
                return false;
            }
        }
        return true;
    }

    public final boolean O(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public boolean P() {
        ActionMenuView actionMenuView = this.f2091a;
        return actionMenuView != null && actionMenuView.N();
    }

    public void a() {
        for (int size = this.f2103b.size() - 1; size >= 0; size--) {
            addView(this.f2103b.get(size));
        }
        this.f2103b.clear();
    }

    public final void b(List<View> list, int i2) {
        boolean z2 = y.A(this) == 1;
        int childCount = getChildCount();
        int iB = f.b(i2, y.A(this));
        list.clear();
        if (!z2) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                com1 com1Var = (com1) childAt.getLayoutParams();
                if (com1Var.f7970b == 0 && O(childAt) && p(com1Var.f7709a) == iB) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i4 = childCount - 1; i4 >= 0; i4--) {
            View childAt2 = getChildAt(i4);
            com1 com1Var2 = (com1) childAt2.getLayoutParams();
            if (com1Var2.f7970b == 0 && O(childAt2) && p(com1Var2.f7709a) == iB) {
                list.add(childAt2);
            }
        }
    }

    public final void c(View view, boolean z2) {
        com1 com1VarGenerateLayoutParams;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            com1VarGenerateLayoutParams = generateDefaultLayoutParams();
        } else {
            com1VarGenerateLayoutParams = !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (com1) layoutParams;
        }
        com1VarGenerateLayoutParams.f7970b = 1;
        if (!z2 || this.f2084a == null) {
            addView(view, com1VarGenerateLayoutParams);
        } else {
            view.setLayoutParams(com1VarGenerateLayoutParams);
            this.f2103b.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof com1);
    }

    public boolean d() {
        ActionMenuView actionMenuView;
        return getVisibility() == 0 && (actionMenuView = this.f2091a) != null && actionMenuView.I();
    }

    public void e() {
        prn prnVar = this.f2092a;
        androidx.appcompat.view.menu.com3 com3Var = prnVar == null ? null : prnVar.f2109a;
        if (com3Var != null) {
            com3Var.collapseActionView();
        }
    }

    public void f() {
        ActionMenuView actionMenuView = this.f2091a;
        if (actionMenuView != null) {
            actionMenuView.z();
        }
    }

    public void g() {
        if (this.f2100b == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, p001AuX.com3.N);
            this.f2100b = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f2083a);
            this.f2100b.setContentDescription(this.f2095a);
            com1 com1VarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            com1VarGenerateDefaultLayoutParams.f7709a = (this.f7960d & 112) | 8388611;
            com1VarGenerateDefaultLayoutParams.f7970b = 2;
            this.f2100b.setLayoutParams(com1VarGenerateDefaultLayoutParams);
            this.f2100b.setOnClickListener(new nul());
        }
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.f2100b;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.f2100b;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        j0 j0Var = this.f2079a;
        if (j0Var != null) {
            return j0Var.a();
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.f7967k;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        j0 j0Var = this.f2079a;
        if (j0Var != null) {
            return j0Var.b();
        }
        return 0;
    }

    public int getContentInsetRight() {
        j0 j0Var = this.f2079a;
        if (j0Var != null) {
            return j0Var.c();
        }
        return 0;
    }

    public int getContentInsetStart() {
        j0 j0Var = this.f2079a;
        if (j0Var != null) {
            return j0Var.d();
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.f7966j;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        androidx.appcompat.view.menu.com1 com1VarL;
        ActionMenuView actionMenuView = this.f2091a;
        return actionMenuView != null && (com1VarL = actionMenuView.L()) != null && com1VarL.hasVisibleItems() ? Math.max(getContentInsetEnd(), Math.max(this.f7967k, 0)) : getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        return y.A(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return y.A(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f7966j, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f2086a;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f2086a;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        j();
        return this.f2091a.getMenu();
    }

    public View getNavButtonView() {
        return this.f2085a;
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.f2085a;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.f2085a;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public androidx.appcompat.widget.aux getOuterActionMenuPresenter() {
        return this.f2093a;
    }

    public Drawable getOverflowIcon() {
        j();
        return this.f2091a.getOverflowIcon();
    }

    Context getPopupContext() {
        return this.f2081a;
    }

    public int getPopupTheme() {
        return this.f7957a;
    }

    public CharSequence getSubtitle() {
        return this.f2105c;
    }

    public final TextView getSubtitleTextView() {
        return this.f2101b;
    }

    public CharSequence getTitle() {
        return this.f2102b;
    }

    public int getTitleMarginBottom() {
        return this.f7965i;
    }

    public int getTitleMarginEnd() {
        return this.f7963g;
    }

    public int getTitleMarginStart() {
        return this.f7962f;
    }

    public int getTitleMarginTop() {
        return this.f7964h;
    }

    public final TextView getTitleTextView() {
        return this.f2087a;
    }

    public r getWrapper() {
        if (this.f2094a == null) {
            this.f2094a = new androidx.appcompat.widget.prn(this, true);
        }
        return this.f2094a;
    }

    public final void h() {
        if (this.f2079a == null) {
            this.f2079a = new j0();
        }
    }

    public final void i() {
        if (this.f2086a == null) {
            this.f2086a = new c(getContext());
        }
    }

    public final void j() {
        k();
        if (this.f2091a.L() == null) {
            androidx.appcompat.view.menu.com1 com1Var = (androidx.appcompat.view.menu.com1) this.f2091a.getMenu();
            if (this.f2092a == null) {
                this.f2092a = new prn();
            }
            this.f2091a.setExpandedActionViewsExclusive(true);
            com1Var.c(this.f2092a, this.f2081a);
        }
    }

    public final void k() {
        if (this.f2091a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.f2091a = actionMenuView;
            actionMenuView.setPopupTheme(this.f7957a);
            this.f2091a.setOnMenuItemClickListener(this.f2090a);
            this.f2091a.M(this.f2089a, this.f2088a);
            com1 com1VarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            com1VarGenerateDefaultLayoutParams.f7709a = (this.f7960d & 112) | 8388613;
            this.f2091a.setLayoutParams(com1VarGenerateDefaultLayoutParams);
            c(this.f2091a, false);
        }
    }

    public final void l() {
        if (this.f2085a == null) {
            this.f2085a = new AppCompatImageButton(getContext(), null, p001AuX.com3.N);
            com1 com1VarGenerateDefaultLayoutParams = generateDefaultLayoutParams();
            com1VarGenerateDefaultLayoutParams.f7709a = (this.f7960d & 112) | 8388611;
            this.f2085a.setLayoutParams(com1VarGenerateDefaultLayoutParams);
        }
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public com1 generateDefaultLayoutParams() {
        return new com1(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: n, reason: merged with bridge method [inline-methods] */
    public com1 generateLayoutParams(AttributeSet attributeSet) {
        return new com1(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: o, reason: merged with bridge method [inline-methods] */
    public com1 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof com1) {
            return new com1((com1) layoutParams);
        }
        if (layoutParams instanceof lpt7.aux) {
            return new com1((lpt7.aux) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new com1((ViewGroup.MarginLayoutParams) layoutParams) : new com1(layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f2096a);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f2107c = false;
        }
        if (!this.f2107c) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f2107c = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f2107c = false;
        }
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0289  */
    /* JADX WARN: Code duplicated, block: B:102:0x028c  */
    /* JADX WARN: Code duplicated, block: B:105:0x029f A[LOOP:0: B:104:0x029d->B:105:0x029f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:108:0x02c1 A[LOOP:1: B:107:0x02bf->B:108:0x02c1, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:112:0x02eb A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:113:0x02ed  */
    /* JADX WARN: Code duplicated, block: B:114:0x02f1  */
    /* JADX WARN: Code duplicated, block: B:117:0x02fa A[LOOP:2: B:116:0x02f8->B:117:0x02fa, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:19:0x005f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0061  */
    /* JADX WARN: Code duplicated, block: B:21:0x0068  */
    /* JADX WARN: Code duplicated, block: B:24:0x0076 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:25:0x0078  */
    /* JADX WARN: Code duplicated, block: B:26:0x007f  */
    /* JADX WARN: Code duplicated, block: B:29:0x00b3 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:31:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:34:0x00ca A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d3  */
    /* JADX WARN: Code duplicated, block: B:39:0x00e7  */
    /* JADX WARN: Code duplicated, block: B:40:0x0100  */
    /* JADX WARN: Code duplicated, block: B:42:0x0105  */
    /* JADX WARN: Code duplicated, block: B:43:0x011d  */
    /* JADX WARN: Code duplicated, block: B:49:0x012b A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:50:0x012d  */
    /* JADX WARN: Code duplicated, block: B:51:0x0130  */
    /* JADX WARN: Code duplicated, block: B:53:0x0134  */
    /* JADX WARN: Code duplicated, block: B:54:0x0137  */
    /* JADX WARN: Code duplicated, block: B:57:0x0147  */
    /* JADX WARN: Code duplicated, block: B:59:0x014f A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:66:0x0168  */
    /* JADX WARN: Code duplicated, block: B:68:0x016c  */
    /* JADX WARN: Code duplicated, block: B:70:0x017e  */
    /* JADX WARN: Code duplicated, block: B:71:0x0181  */
    /* JADX WARN: Code duplicated, block: B:73:0x018c  */
    /* JADX WARN: Code duplicated, block: B:75:0x0198  */
    /* JADX WARN: Code duplicated, block: B:76:0x01a6  */
    /* JADX WARN: Code duplicated, block: B:78:0x01b7 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:79:0x01b9  */
    /* JADX WARN: Code duplicated, block: B:80:0x01bc  */
    /* JADX WARN: Code duplicated, block: B:83:0x01d0  */
    /* JADX WARN: Code duplicated, block: B:84:0x01f4  */
    /* JADX WARN: Code duplicated, block: B:86:0x01f7  */
    /* JADX WARN: Code duplicated, block: B:87:0x021b  */
    /* JADX WARN: Code duplicated, block: B:89:0x021e  */
    /* JADX WARN: Code duplicated, block: B:91:0x0227 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:92:0x0229  */
    /* JADX WARN: Code duplicated, block: B:93:0x022d  */
    /* JADX WARN: Code duplicated, block: B:96:0x0241  */
    /* JADX WARN: Code duplicated, block: B:97:0x0264  */
    /* JADX WARN: Code duplicated, block: B:99:0x0267  */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int iC;
        int iD;
        int iMax;
        int iMin;
        boolean zO;
        boolean zO2;
        int measuredHeight;
        TextView textView;
        TextView textView2;
        com1 com1Var;
        com1 com1Var2;
        boolean z3;
        int i6;
        int i7;
        int paddingTop;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int iMax2;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        int size;
        int i20;
        int i21;
        int size2;
        int i22;
        int i23;
        int i24;
        int size3;
        boolean z4 = y.A(this) == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i25 = width - paddingRight;
        int[] iArr = this.f2098a;
        iArr[1] = 0;
        iArr[0] = 0;
        int iB = y.B(this);
        int iMin2 = iB >= 0 ? Math.min(iB, i5 - i3) : 0;
        if (O(this.f2085a)) {
            if (z4) {
                iD = D(this.f2085a, i25, iArr, iMin2);
                iC = paddingLeft;
            } else {
                iC = C(this.f2085a, paddingLeft, iArr, iMin2);
            }
            if (O(this.f2100b)) {
                if (z4) {
                    iD = D(this.f2100b, iD, iArr, iMin2);
                } else {
                    iC = C(this.f2100b, iC, iArr, iMin2);
                }
            }
            if (O(this.f2091a)) {
                if (z4) {
                    iC = C(this.f2091a, iC, iArr, iMin2);
                } else {
                    iD = D(this.f2091a, iD, iArr, iMin2);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iC);
            iArr[1] = Math.max(0, currentContentInsetRight - (i25 - iD));
            iMax = Math.max(iC, currentContentInsetLeft);
            iMin = Math.min(iD, i25 - currentContentInsetRight);
            if (O(this.f2084a)) {
                if (z4) {
                    iMin = D(this.f2084a, iMin, iArr, iMin2);
                } else {
                    iMax = C(this.f2084a, iMax, iArr, iMin2);
                }
            }
            if (O(this.f2086a)) {
                if (z4) {
                    iMin = D(this.f2086a, iMin, iArr, iMin2);
                } else {
                    iMax = C(this.f2086a, iMax, iArr, iMin2);
                }
            }
            zO = O(this.f2087a);
            zO2 = O(this.f2101b);
            if (zO) {
                com1 com1Var3 = (com1) this.f2087a.getLayoutParams();
                measuredHeight = ((ViewGroup.MarginLayoutParams) com1Var3).topMargin + this.f2087a.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com1Var3).bottomMargin + 0;
            } else {
                measuredHeight = 0;
            }
            if (zO2) {
                com1 com1Var4 = (com1) this.f2101b.getLayoutParams();
                measuredHeight += ((ViewGroup.MarginLayoutParams) com1Var4).topMargin + this.f2101b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com1Var4).bottomMargin;
            }
            if (!zO || zO2) {
                if (zO) {
                    textView = this.f2087a;
                } else {
                    textView = this.f2101b;
                }
                if (zO2) {
                    textView2 = this.f2101b;
                } else {
                    textView2 = this.f2087a;
                }
                com1Var = (com1) textView.getLayoutParams();
                com1Var2 = (com1) textView2.getLayoutParams();
                z3 = (!zO && this.f2087a.getMeasuredWidth() > 0) || (zO2 && this.f2101b.getMeasuredWidth() > 0);
                i6 = this.f7968l & 112;
                i7 = paddingLeft;
                if (i6 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) com1Var).topMargin + this.f7964h;
                } else if (i6 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                    i15 = ((ViewGroup.MarginLayoutParams) com1Var).topMargin;
                    i16 = this.f7964h;
                    if (iMax2 < i15 + i16) {
                        iMax2 = i15 + i16;
                    } else {
                        i17 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                        i18 = ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin;
                        i19 = this.f7965i;
                        if (i17 < i18 + i19) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin + i19) - i17));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin) - this.f7965i) - measuredHeight;
                }
                if (z4) {
                    if (z3) {
                        i12 = this.f7962f;
                    } else {
                        i12 = 0;
                    }
                    int i26 = i12 - iArr[1];
                    iMin -= Math.max(0, i26);
                    iArr[1] = Math.max(0, -i26);
                    if (zO) {
                        com1 com1Var5 = (com1) this.f2087a.getLayoutParams();
                        int measuredWidth = iMin - this.f2087a.getMeasuredWidth();
                        int measuredHeight2 = this.f2087a.getMeasuredHeight() + paddingTop;
                        this.f2087a.layout(measuredWidth, paddingTop, iMin, measuredHeight2);
                        i13 = measuredWidth - this.f7963g;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) com1Var5).bottomMargin;
                    } else {
                        i13 = iMin;
                    }
                    if (zO2) {
                        int i27 = paddingTop + ((ViewGroup.MarginLayoutParams) ((com1) this.f2101b.getLayoutParams())).topMargin;
                        this.f2101b.layout(iMin - this.f2101b.getMeasuredWidth(), i27, iMin, this.f2101b.getMeasuredHeight() + i27);
                        i14 = iMin - this.f7963g;
                    } else {
                        i14 = iMin;
                    }
                    if (z3) {
                        iMin = Math.min(i13, i14);
                    }
                    iMax = iMax;
                } else {
                    if (z3) {
                        i9 = this.f7962f;
                        i8 = 0;
                    } else {
                        i8 = 0;
                        i9 = 0;
                    }
                    int i28 = i9 - iArr[i8];
                    iMax += Math.max(i8, i28);
                    iArr[i8] = Math.max(i8, -i28);
                    if (zO) {
                        com1 com1Var6 = (com1) this.f2087a.getLayoutParams();
                        int measuredWidth2 = this.f2087a.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.f2087a.getMeasuredHeight() + paddingTop;
                        this.f2087a.layout(iMax, paddingTop, measuredWidth2, measuredHeight3);
                        i10 = measuredWidth2 + this.f7963g;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) com1Var6).bottomMargin;
                    } else {
                        i10 = iMax;
                    }
                    if (zO2) {
                        int i29 = paddingTop + ((ViewGroup.MarginLayoutParams) ((com1) this.f2101b.getLayoutParams())).topMargin;
                        int measuredWidth3 = this.f2101b.getMeasuredWidth() + iMax;
                        this.f2101b.layout(iMax, i29, measuredWidth3, this.f2101b.getMeasuredHeight() + i29);
                        i11 = measuredWidth3 + this.f7963g;
                    } else {
                        i11 = iMax;
                    }
                    if (z3) {
                        iMax = Math.max(i10, i11);
                    }
                }
                b(this.f2097a, 3);
                size = this.f2097a.size();
                for (i20 = i8; i20 < size; i20++) {
                    iMax = C(this.f2097a.get(i20), iMax, iArr, iMin2);
                }
                i21 = iMin2;
                b(this.f2097a, 5);
                size2 = this.f2097a.size();
                for (i22 = i8; i22 < size2; i22++) {
                    iMin = D(this.f2097a.get(i22), iMin, iArr, i21);
                }
                b(this.f2097a, 1);
                int iU = u(this.f2097a, iArr);
                i23 = (i7 + (((width - i7) - paddingRight) / 2)) - (iU / 2);
                i24 = iU + i23;
                if (i23 >= iMax) {
                    if (i24 > iMin) {
                        iMax = i23 - (i24 - iMin);
                    } else {
                        iMax = i23;
                    }
                }
                size3 = this.f2097a.size();
                while (i8 < size3) {
                    iMax = C(this.f2097a.get(i8), iMax, iArr, i21);
                    i8++;
                }
                this.f2097a.clear();
            }
            i7 = paddingLeft;
            iMin2 = iMin2;
            i8 = 0;
            b(this.f2097a, 3);
            size = this.f2097a.size();
            while (i20 < size) {
                iMax = C(this.f2097a.get(i20), iMax, iArr, iMin2);
            }
            i21 = iMin2;
            b(this.f2097a, 5);
            size2 = this.f2097a.size();
            while (i22 < size2) {
                iMin = D(this.f2097a.get(i22), iMin, iArr, i21);
            }
            b(this.f2097a, 1);
            int iU2 = u(this.f2097a, iArr);
            i23 = (i7 + (((width - i7) - paddingRight) / 2)) - (iU2 / 2);
            i24 = iU2 + i23;
            if (i23 >= iMax) {
                if (i24 > iMin) {
                    iMax = i23 - (i24 - iMin);
                } else {
                    iMax = i23;
                }
            }
            size3 = this.f2097a.size();
            while (i8 < size3) {
                iMax = C(this.f2097a.get(i8), iMax, iArr, i21);
                i8++;
            }
            this.f2097a.clear();
        }
        iC = paddingLeft;
        iD = i25;
        if (O(this.f2100b)) {
            if (z4) {
                iD = D(this.f2100b, iD, iArr, iMin2);
            } else {
                iC = C(this.f2100b, iC, iArr, iMin2);
            }
        }
        if (O(this.f2091a)) {
            if (z4) {
                iC = C(this.f2091a, iC, iArr, iMin2);
            } else {
                iD = D(this.f2091a, iD, iArr, iMin2);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iC);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i25 - iD));
        iMax = Math.max(iC, currentContentInsetLeft2);
        iMin = Math.min(iD, i25 - currentContentInsetRight2);
        if (O(this.f2084a)) {
            if (z4) {
                iMin = D(this.f2084a, iMin, iArr, iMin2);
            } else {
                iMax = C(this.f2084a, iMax, iArr, iMin2);
            }
        }
        if (O(this.f2086a)) {
            if (z4) {
                iMin = D(this.f2086a, iMin, iArr, iMin2);
            } else {
                iMax = C(this.f2086a, iMax, iArr, iMin2);
            }
        }
        zO = O(this.f2087a);
        zO2 = O(this.f2101b);
        if (zO) {
            com1 com1Var7 = (com1) this.f2087a.getLayoutParams();
            measuredHeight = ((ViewGroup.MarginLayoutParams) com1Var7).topMargin + this.f2087a.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com1Var7).bottomMargin + 0;
        } else {
            measuredHeight = 0;
        }
        if (zO2) {
            com1 com1Var8 = (com1) this.f2101b.getLayoutParams();
            measuredHeight += ((ViewGroup.MarginLayoutParams) com1Var8).topMargin + this.f2101b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) com1Var8).bottomMargin;
        }
        if (zO) {
            if (zO) {
                textView = this.f2087a;
            } else {
                textView = this.f2101b;
            }
            if (zO2) {
                textView2 = this.f2101b;
            } else {
                textView2 = this.f2087a;
            }
            com1Var = (com1) textView.getLayoutParams();
            com1Var2 = (com1) textView2.getLayoutParams();
            if (zO) {
            }
            i6 = this.f7968l & 112;
            i7 = paddingLeft;
            if (i6 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) com1Var).topMargin + this.f7964h;
            } else if (i6 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                i15 = ((ViewGroup.MarginLayoutParams) com1Var).topMargin;
                i16 = this.f7964h;
                if (iMax2 < i15 + i16) {
                    iMax2 = i15 + i16;
                } else {
                    i17 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                    i18 = ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin;
                    i19 = this.f7965i;
                    if (i17 < i18 + i19) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin + i19) - i17));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin) - this.f7965i) - measuredHeight;
            }
            if (z4) {
                if (z3) {
                    i12 = this.f7962f;
                } else {
                    i12 = 0;
                }
                int i210 = i12 - iArr[1];
                iMin -= Math.max(0, i210);
                iArr[1] = Math.max(0, -i210);
                if (zO) {
                    com1 com1Var9 = (com1) this.f2087a.getLayoutParams();
                    int measuredWidth4 = iMin - this.f2087a.getMeasuredWidth();
                    int measuredHeight4 = this.f2087a.getMeasuredHeight() + paddingTop;
                    this.f2087a.layout(measuredWidth4, paddingTop, iMin, measuredHeight4);
                    i13 = measuredWidth4 - this.f7963g;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) com1Var9).bottomMargin;
                } else {
                    i13 = iMin;
                }
                if (zO2) {
                    int i211 = paddingTop + ((ViewGroup.MarginLayoutParams) ((com1) this.f2101b.getLayoutParams())).topMargin;
                    this.f2101b.layout(iMin - this.f2101b.getMeasuredWidth(), i211, iMin, this.f2101b.getMeasuredHeight() + i211);
                    i14 = iMin - this.f7963g;
                } else {
                    i14 = iMin;
                }
                if (z3) {
                    iMin = Math.min(i13, i14);
                }
                iMax = iMax;
                i8 = 0;
            } else {
                if (z3) {
                    i9 = this.f7962f;
                    i8 = 0;
                } else {
                    i8 = 0;
                    i9 = 0;
                }
                int i212 = i9 - iArr[i8];
                iMax += Math.max(i8, i212);
                iArr[i8] = Math.max(i8, -i212);
                if (zO) {
                    com1 com1Var10 = (com1) this.f2087a.getLayoutParams();
                    int measuredWidth5 = this.f2087a.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.f2087a.getMeasuredHeight() + paddingTop;
                    this.f2087a.layout(iMax, paddingTop, measuredWidth5, measuredHeight5);
                    i10 = measuredWidth5 + this.f7963g;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) com1Var10).bottomMargin;
                } else {
                    i10 = iMax;
                }
                if (zO2) {
                    int i213 = paddingTop + ((ViewGroup.MarginLayoutParams) ((com1) this.f2101b.getLayoutParams())).topMargin;
                    int measuredWidth6 = this.f2101b.getMeasuredWidth() + iMax;
                    this.f2101b.layout(iMax, i213, measuredWidth6, this.f2101b.getMeasuredHeight() + i213);
                    i11 = measuredWidth6 + this.f7963g;
                } else {
                    i11 = iMax;
                }
                if (z3) {
                    iMax = Math.max(i10, i11);
                }
            }
        } else {
            if (zO) {
                textView = this.f2087a;
            } else {
                textView = this.f2101b;
            }
            if (zO2) {
                textView2 = this.f2101b;
            } else {
                textView2 = this.f2087a;
            }
            com1Var = (com1) textView.getLayoutParams();
            com1Var2 = (com1) textView2.getLayoutParams();
            if (zO) {
            }
            i6 = this.f7968l & 112;
            i7 = paddingLeft;
            if (i6 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) com1Var).topMargin + this.f7964h;
            } else if (i6 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - measuredHeight) / 2;
                i15 = ((ViewGroup.MarginLayoutParams) com1Var).topMargin;
                i16 = this.f7964h;
                if (iMax2 < i15 + i16) {
                    iMax2 = i15 + i16;
                } else {
                    i17 = (((height - paddingBottom) - measuredHeight) - iMax2) - paddingTop2;
                    i18 = ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin;
                    i19 = this.f7965i;
                    if (i17 < i18 + i19) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin + i19) - i17));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) com1Var2).bottomMargin) - this.f7965i) - measuredHeight;
            }
            if (z4) {
                if (z3) {
                    i12 = this.f7962f;
                } else {
                    i12 = 0;
                }
                int i214 = i12 - iArr[1];
                iMin -= Math.max(0, i214);
                iArr[1] = Math.max(0, -i214);
                if (zO) {
                    com1 com1Var11 = (com1) this.f2087a.getLayoutParams();
                    int measuredWidth7 = iMin - this.f2087a.getMeasuredWidth();
                    int measuredHeight6 = this.f2087a.getMeasuredHeight() + paddingTop;
                    this.f2087a.layout(measuredWidth7, paddingTop, iMin, measuredHeight6);
                    i13 = measuredWidth7 - this.f7963g;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) com1Var11).bottomMargin;
                } else {
                    i13 = iMin;
                }
                if (zO2) {
                    int i215 = paddingTop + ((ViewGroup.MarginLayoutParams) ((com1) this.f2101b.getLayoutParams())).topMargin;
                    this.f2101b.layout(iMin - this.f2101b.getMeasuredWidth(), i215, iMin, this.f2101b.getMeasuredHeight() + i215);
                    i14 = iMin - this.f7963g;
                } else {
                    i14 = iMin;
                }
                if (z3) {
                    iMin = Math.min(i13, i14);
                }
                iMax = iMax;
                i8 = 0;
            } else {
                if (z3) {
                    i9 = this.f7962f;
                    i8 = 0;
                } else {
                    i8 = 0;
                    i9 = 0;
                }
                int i216 = i9 - iArr[i8];
                iMax += Math.max(i8, i216);
                iArr[i8] = Math.max(i8, -i216);
                if (zO) {
                    com1 com1Var12 = (com1) this.f2087a.getLayoutParams();
                    int measuredWidth8 = this.f2087a.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.f2087a.getMeasuredHeight() + paddingTop;
                    this.f2087a.layout(iMax, paddingTop, measuredWidth8, measuredHeight7);
                    i10 = measuredWidth8 + this.f7963g;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) com1Var12).bottomMargin;
                } else {
                    i10 = iMax;
                }
                if (zO2) {
                    int i217 = paddingTop + ((ViewGroup.MarginLayoutParams) ((com1) this.f2101b.getLayoutParams())).topMargin;
                    int measuredWidth9 = this.f2101b.getMeasuredWidth() + iMax;
                    this.f2101b.layout(iMax, i217, measuredWidth9, this.f2101b.getMeasuredHeight() + i217);
                    i11 = measuredWidth9 + this.f7963g;
                } else {
                    i11 = iMax;
                }
                if (z3) {
                    iMax = Math.max(i10, i11);
                }
            }
        }
        b(this.f2097a, 3);
        size = this.f2097a.size();
        while (i20 < size) {
            iMax = C(this.f2097a.get(i20), iMax, iArr, iMin2);
        }
        i21 = iMin2;
        b(this.f2097a, 5);
        size2 = this.f2097a.size();
        while (i22 < size2) {
            iMin = D(this.f2097a.get(i22), iMin, iArr, i21);
        }
        b(this.f2097a, 1);
        int iU3 = u(this.f2097a, iArr);
        i23 = (i7 + (((width - i7) - paddingRight) / 2)) - (iU3 / 2);
        i24 = iU3 + i23;
        if (i23 >= iMax) {
            if (i24 > iMin) {
                iMax = i23 - (i24 - iMin);
            } else {
                iMax = i23;
            }
        }
        size3 = this.f2097a.size();
        while (i8 < size3) {
            iMax = C(this.f2097a.get(i8), iMax, iArr, i21);
            i8++;
        }
        this.f2097a.clear();
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        int measuredWidth;
        int iMax;
        int iCombineMeasuredStates;
        int measuredWidth2;
        int measuredHeight;
        int iCombineMeasuredStates2;
        int iMax2;
        int[] iArr = this.f2098a;
        boolean zB = u0.b(this);
        int i4 = !zB ? 1 : 0;
        if (O(this.f2085a)) {
            F(this.f2085a, i2, 0, i3, 0, this.f7961e);
            measuredWidth = this.f2085a.getMeasuredWidth() + s(this.f2085a);
            iMax = Math.max(0, this.f2085a.getMeasuredHeight() + t(this.f2085a));
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f2085a.getMeasuredState());
        } else {
            measuredWidth = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (O(this.f2100b)) {
            F(this.f2100b, i2, 0, i3, 0, this.f7961e);
            measuredWidth = this.f2100b.getMeasuredWidth() + s(this.f2100b);
            iMax = Math.max(iMax, this.f2100b.getMeasuredHeight() + t(this.f2100b));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f2100b.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = 0 + Math.max(currentContentInsetStart, measuredWidth);
        iArr[zB ? 1 : 0] = Math.max(0, currentContentInsetStart - measuredWidth);
        if (O(this.f2091a)) {
            F(this.f2091a, i2, iMax3, i3, 0, this.f7961e);
            measuredWidth2 = this.f2091a.getMeasuredWidth() + s(this.f2091a);
            iMax = Math.max(iMax, this.f2091a.getMeasuredHeight() + t(this.f2091a));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f2091a.getMeasuredState());
        } else {
            measuredWidth2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax4 = iMax3 + Math.max(currentContentInsetEnd, measuredWidth2);
        iArr[i4] = Math.max(0, currentContentInsetEnd - measuredWidth2);
        if (O(this.f2084a)) {
            iMax4 += E(this.f2084a, i2, iMax4, i3, 0, iArr);
            iMax = Math.max(iMax, this.f2084a.getMeasuredHeight() + t(this.f2084a));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f2084a.getMeasuredState());
        }
        if (O(this.f2086a)) {
            iMax4 += E(this.f2086a, i2, iMax4, i3, 0, iArr);
            iMax = Math.max(iMax, this.f2086a.getMeasuredHeight() + t(this.f2086a));
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f2086a.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (((com1) childAt.getLayoutParams()).f7970b == 0 && O(childAt)) {
                iMax4 += E(childAt, i2, iMax4, i3, 0, iArr);
                iMax = Math.max(iMax, childAt.getMeasuredHeight() + t(childAt));
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
            }
        }
        int i6 = this.f7964h + this.f7965i;
        int i7 = this.f7962f + this.f7963g;
        if (O(this.f2087a)) {
            E(this.f2087a, i2, iMax4 + i7, i3, i6, iArr);
            int measuredWidth3 = this.f2087a.getMeasuredWidth() + s(this.f2087a);
            measuredHeight = this.f2087a.getMeasuredHeight() + t(this.f2087a);
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f2087a.getMeasuredState());
            iMax2 = measuredWidth3;
        } else {
            measuredHeight = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (O(this.f2101b)) {
            iMax2 = Math.max(iMax2, E(this.f2101b, i2, iMax4 + i7, i3, measuredHeight + i6, iArr));
            measuredHeight += this.f2101b.getMeasuredHeight() + t(this.f2101b);
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f2101b.getMeasuredState());
        }
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax4 + iMax2 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, (-16777216) & iCombineMeasuredStates2), N() ? 0 : View.resolveSizeAndState(Math.max(Math.max(iMax, measuredHeight) + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof com3)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        com3 com3Var = (com3) parcelable;
        super.onRestoreInstanceState(com3Var.k());
        ActionMenuView actionMenuView = this.f2091a;
        androidx.appcompat.view.menu.com1 com1VarL = actionMenuView != null ? actionMenuView.L() : null;
        int i2 = com3Var.f7971a;
        if (i2 != 0 && this.f2092a != null && com1VarL != null && (menuItemFindItem = com1VarL.findItem(i2)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (com3Var.f7972b) {
            H();
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        h();
        this.f2079a.f(i2 == 1);
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        androidx.appcompat.view.menu.com3 com3Var;
        com3 com3Var2 = new com3(super.onSaveInstanceState());
        prn prnVar = this.f2092a;
        if (prnVar != null && (com3Var = prnVar.f2109a) != null) {
            com3Var2.f7971a = com3Var.getItemId();
        }
        com3Var2.f7972b = B();
        return com3Var2;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f2104b = false;
        }
        if (!this.f2104b) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f2104b = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f2104b = false;
        }
        return true;
    }

    public final int p(int i2) {
        int iA = y.A(this);
        int iB = f.b(i2, iA) & 7;
        if (iB == 1 || iB == 3 || iB == 5) {
            return iB;
        }
        return iA == 1 ? 5 : 3;
    }

    public final int q(View view, int i2) {
        com1 com1Var = (com1) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int iR = r(com1Var.f7709a);
        if (iR == 48) {
            return getPaddingTop() - i3;
        }
        if (iR == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i4 = ((ViewGroup.MarginLayoutParams) com1Var).topMargin;
        if (iMax < i4) {
            iMax = i4;
        } else {
            int i5 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i6 = ((ViewGroup.MarginLayoutParams) com1Var).bottomMargin;
            if (i5 < i6) {
                iMax = Math.max(0, iMax - (i6 - i5));
            }
        }
        return paddingTop + iMax;
    }

    public final int r(int i2) {
        int i3 = i2 & 112;
        return (i3 == 16 || i3 == 48 || i3 == 80) ? i3 : this.f7968l & 112;
    }

    public final int s(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return i.b(marginLayoutParams) + i.a(marginLayoutParams);
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(AUX.aux.b(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.f2108d = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f7967k) {
            this.f7967k = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f7966j) {
            this.f7966j = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(AUX.aux.b(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(AUX.aux.b(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        l();
        this.f2085a.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(com2 com2Var) {
    }

    public void setOverflowIcon(Drawable drawable) {
        j();
        this.f2091a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.f7957a != i2) {
            this.f7957a = i2;
            if (i2 == 0) {
                this.f2081a = getContext();
            } else {
                this.f2081a = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.f7965i = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.f7963g = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.f7962f = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.f7964h = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public final int t(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final int u(List<View> list, int[] iArr) {
        int i2 = iArr[0];
        int i3 = iArr[1];
        int size = list.size();
        int i4 = 0;
        int measuredWidth = 0;
        while (i4 < size) {
            View view = list.get(i4);
            com1 com1Var = (com1) view.getLayoutParams();
            int i5 = ((ViewGroup.MarginLayoutParams) com1Var).leftMargin - i2;
            int i6 = ((ViewGroup.MarginLayoutParams) com1Var).rightMargin - i3;
            int iMax = Math.max(0, i5);
            int iMax2 = Math.max(0, i6);
            int iMax3 = Math.max(0, -i5);
            int iMax4 = Math.max(0, -i6);
            measuredWidth += iMax + view.getMeasuredWidth() + iMax2;
            i4++;
            i3 = iMax4;
            i2 = iMax3;
        }
        return measuredWidth;
    }

    public boolean v() {
        prn prnVar = this.f2092a;
        return (prnVar == null || prnVar.f2109a == null) ? false : true;
    }

    public boolean w() {
        ActionMenuView actionMenuView = this.f2091a;
        return actionMenuView != null && actionMenuView.F();
    }

    public void x(int i2) {
        getMenuInflater().inflate(i2, getMenu());
    }

    public void y() {
        Iterator<MenuItem> it = this.f2106c.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(it.next().getItemId());
        }
        G();
    }

    public final boolean z(View view) {
        return view.getParent() == this || this.f2103b.contains(view);
    }

    public static class com1 extends lpt7.aux {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f7970b;

        public com1(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f7970b = 0;
        }

        public void a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }

        public com1(int i2, int i3) {
            super(i2, i3);
            this.f7970b = 0;
            this.f7709a = 8388627;
        }

        public com1(com1 com1Var) {
            super((lpt7.aux) com1Var);
            this.f7970b = 0;
            this.f7970b = com1Var.f7970b;
        }

        public com1(lpt7.aux auxVar) {
            super(auxVar);
            this.f7970b = 0;
        }

        public com1(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f7970b = 0;
            a(marginLayoutParams);
        }

        public com1(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f7970b = 0;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f7968l = 8388627;
        this.f2097a = new ArrayList<>();
        this.f2103b = new ArrayList<>();
        this.f2098a = new int[2];
        this.f2080a = new j(new Runnable() { // from class: CoN.r0
            @Override // java.lang.Runnable
            public final void run() {
                this.f6397a.y();
            }
        });
        this.f2106c = new ArrayList<>();
        this.f2090a = new aux();
        this.f2096a = new con();
        Context context2 = getContext();
        int[] iArr = lpt3.f9E;
        q0 q0VarV = q0.v(context2, attributeSet, iArr, i2, 0);
        y.m0(this, context, iArr, attributeSet, q0VarV.r(), i2, 0);
        this.f7958b = q0VarV.n(lpt3.a3, 0);
        this.f7959c = q0VarV.n(lpt3.R2, 0);
        this.f7968l = q0VarV.l(lpt3.z2, this.f7968l);
        this.f7960d = q0VarV.l(lpt3.A2, 48);
        int iE = q0VarV.e(lpt3.U2, 0);
        int i3 = lpt3.Z2;
        iE = q0VarV.s(i3) ? q0VarV.e(i3, iE) : iE;
        this.f7965i = iE;
        this.f7964h = iE;
        this.f7963g = iE;
        this.f7962f = iE;
        int iE2 = q0VarV.e(lpt3.X2, -1);
        if (iE2 >= 0) {
            this.f7962f = iE2;
        }
        int iE3 = q0VarV.e(lpt3.W2, -1);
        if (iE3 >= 0) {
            this.f7963g = iE3;
        }
        int iE4 = q0VarV.e(lpt3.Y2, -1);
        if (iE4 >= 0) {
            this.f7964h = iE4;
        }
        int iE5 = q0VarV.e(lpt3.V2, -1);
        if (iE5 >= 0) {
            this.f7965i = iE5;
        }
        this.f7961e = q0VarV.f(lpt3.L2, -1);
        int iE6 = q0VarV.e(lpt3.H2, Integer.MIN_VALUE);
        int iE7 = q0VarV.e(lpt3.D2, Integer.MIN_VALUE);
        int iF = q0VarV.f(lpt3.F2, 0);
        int iF2 = q0VarV.f(lpt3.G2, 0);
        h();
        this.f2079a.e(iF, iF2);
        if (iE6 != Integer.MIN_VALUE || iE7 != Integer.MIN_VALUE) {
            this.f2079a.g(iE6, iE7);
        }
        this.f7966j = q0VarV.e(lpt3.I2, Integer.MIN_VALUE);
        this.f7967k = q0VarV.e(lpt3.E2, Integer.MIN_VALUE);
        this.f2083a = q0VarV.g(lpt3.C2);
        this.f2095a = q0VarV.p(lpt3.B2);
        CharSequence charSequenceP = q0VarV.p(lpt3.T2);
        if (!TextUtils.isEmpty(charSequenceP)) {
            setTitle(charSequenceP);
        }
        CharSequence charSequenceP2 = q0VarV.p(lpt3.Q2);
        if (!TextUtils.isEmpty(charSequenceP2)) {
            setSubtitle(charSequenceP2);
        }
        this.f2081a = getContext();
        setPopupTheme(q0VarV.n(lpt3.P2, 0));
        Drawable drawableG = q0VarV.g(lpt3.O2);
        if (drawableG != null) {
            setNavigationIcon(drawableG);
        }
        CharSequence charSequenceP3 = q0VarV.p(lpt3.N2);
        if (!TextUtils.isEmpty(charSequenceP3)) {
            setNavigationContentDescription(charSequenceP3);
        }
        Drawable drawableG2 = q0VarV.g(lpt3.J2);
        if (drawableG2 != null) {
            setLogo(drawableG2);
        }
        CharSequence charSequenceP4 = q0VarV.p(lpt3.K2);
        if (!TextUtils.isEmpty(charSequenceP4)) {
            setLogoDescription(charSequenceP4);
        }
        int i4 = lpt3.b3;
        if (q0VarV.s(i4)) {
            setTitleTextColor(q0VarV.c(i4));
        }
        int i5 = lpt3.S2;
        if (q0VarV.s(i5)) {
            setSubtitleTextColor(q0VarV.c(i5));
        }
        int i6 = lpt3.M2;
        if (q0VarV.s(i6)) {
            x(q0VarV.n(i6, 0));
        }
        q0VarV.w();
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        ImageButton imageButton = this.f2100b;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            this.f2100b.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.f2100b;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.f2083a);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            i();
            if (!z(this.f2086a)) {
                c(this.f2086a, true);
            }
        } else {
            ImageView imageView = this.f2086a;
            if (imageView != null && z(imageView)) {
                removeView(this.f2086a);
                this.f2103b.remove(this.f2086a);
            }
        }
        ImageView imageView2 = this.f2086a;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            i();
        }
        ImageView imageView = this.f2086a;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            l();
        }
        ImageButton imageButton = this.f2085a;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
            s0.a(this.f2085a, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            l();
            if (!z(this.f2085a)) {
                c(this.f2085a, true);
            }
        } else {
            ImageButton imageButton = this.f2085a;
            if (imageButton != null && z(imageButton)) {
                removeView(this.f2085a);
                this.f2103b.remove(this.f2085a);
            }
        }
        ImageButton imageButton2 = this.f2085a;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f2101b;
            if (textView != null && z(textView)) {
                removeView(this.f2101b);
                this.f2103b.remove(this.f2101b);
            }
        } else {
            if (this.f2101b == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context);
                this.f2101b = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f2101b.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f7959c;
                if (i2 != 0) {
                    this.f2101b.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f2099b;
                if (colorStateList != null) {
                    this.f2101b.setTextColor(colorStateList);
                }
            }
            if (!z(this.f2101b)) {
                c(this.f2101b, true);
            }
        }
        TextView textView2 = this.f2101b;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f2105c = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f2099b = colorStateList;
        TextView textView = this.f2101b;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f2087a;
            if (textView != null && z(textView)) {
                removeView(this.f2087a);
                this.f2103b.remove(this.f2087a);
            }
        } else {
            if (this.f2087a == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context);
                this.f2087a = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f2087a.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f7958b;
                if (i2 != 0) {
                    this.f2087a.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f2082a;
                if (colorStateList != null) {
                    this.f2087a.setTextColor(colorStateList);
                }
            }
            if (!z(this.f2087a)) {
                c(this.f2087a, true);
            }
        }
        TextView textView2 = this.f2087a;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f2102b = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f2082a = colorStateList;
        TextView textView = this.f2087a;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public static class com3 extends COM2.aux {
        public static final Parcelable.Creator<com3> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7971a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f7972b;

        public class aux implements Parcelable.ClassLoaderCreator<com3> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com3 createFromParcel(Parcel parcel) {
                return new com3(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com3 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com3(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com3[] newArray(int i2) {
                return new com3[i2];
            }
        }

        public com3(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f7971a = parcel.readInt();
            this.f7972b = parcel.readInt() != 0;
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f7971a);
            parcel.writeInt(this.f7972b ? 1 : 0);
        }

        public com3(Parcelable parcelable) {
            super(parcelable);
        }
    }
}
