package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import p001AuX.lpt3;
import p022CoN.a0;
import p022CoN.s0;
import p099coN.h1;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends AppCompatTextView implements com6.aux, View.OnClickListener, ActionMenuView.aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7776a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public a0 f1803a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1804a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f1805a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1.con f1806a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com3 f1807a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f1808a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7777b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7778c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1809c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f7779d;

    public class aux extends a0 {
        public aux() {
            super(ActionMenuItemView.this);
        }

        @Override // p022CoN.a0
        public h1 b() {
            con conVar = ActionMenuItemView.this.f1805a;
            if (conVar != null) {
                return conVar.a();
            }
            return null;
        }

        @Override // p022CoN.a0
        public boolean c() {
            h1 h1VarB;
            ActionMenuItemView actionMenuItemView = ActionMenuItemView.this;
            com1.con conVar = actionMenuItemView.f1806a;
            return conVar != null && conVar.a(actionMenuItemView.f1807a) && (h1VarB = b()) != null && h1VarB.b();
        }
    }

    public static abstract class con {
        public abstract h1 a();
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // androidx.appcompat.widget.ActionMenuView.aux
    public boolean a() {
        return f() && this.f1807a.getIcon() == null;
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public void b(com3 com3Var, int i2) {
        this.f1807a = com3Var;
        setIcon(com3Var.getIcon());
        setTitle(com3Var.k(this));
        setId(com3Var.getItemId());
        setVisibility(com3Var.isVisible() ? 0 : 8);
        setEnabled(com3Var.isEnabled());
        if (com3Var.hasSubMenu() && this.f1803a == null) {
            this.f1803a = new aux();
        }
    }

    @Override // androidx.appcompat.widget.ActionMenuView.aux
    public boolean c() {
        return f();
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public boolean d() {
        return true;
    }

    public boolean f() {
        return !TextUtils.isEmpty(getText());
    }

    public final boolean g() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        return i2 >= 480 || (i2 >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    @Override // androidx.appcompat.view.menu.com6.aux
    public com3 getItemData() {
        return this.f1807a;
    }

    public final void h() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f1808a);
        if (this.f1804a != null && (!this.f1807a.D() || (!this.f1809c && !this.f7779d))) {
            z2 = false;
        }
        boolean z4 = z3 & z2;
        setText(z4 ? this.f1808a : null);
        CharSequence contentDescription = this.f1807a.getContentDescription();
        if (TextUtils.isEmpty(contentDescription)) {
            setContentDescription(z4 ? null : this.f1807a.getTitle());
        } else {
            setContentDescription(contentDescription);
        }
        CharSequence tooltipText = this.f1807a.getTooltipText();
        if (TextUtils.isEmpty(tooltipText)) {
            s0.a(this, z4 ? null : this.f1807a.getTitle());
        } else {
            s0.a(this, tooltipText);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        com1.con conVar = this.f1806a;
        if (conVar != null) {
            conVar.a(this.f1807a);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1809c = g();
        h();
    }

    @Override // androidx.appcompat.widget.AppCompatTextView, android.widget.TextView, android.view.View
    public void onMeasure(int i2, int i3) {
        int i4;
        boolean zF = f();
        if (zF && (i4 = this.f7777b) >= 0) {
            super.setPadding(i4, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int measuredWidth = getMeasuredWidth();
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, this.f7776a) : this.f7776a;
        if (mode != 1073741824 && this.f7776a > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i3);
        }
        if (zF || this.f1804a == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f1804a.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        a0 a0Var;
        if (this.f1807a.hasSubMenu() && (a0Var = this.f1803a) != null && a0Var.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z2) {
    }

    public void setChecked(boolean z2) {
    }

    public void setExpandedFormat(boolean z2) {
        if (this.f7779d != z2) {
            this.f7779d = z2;
            com3 com3Var = this.f1807a;
            if (com3Var != null) {
                com3Var.e();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f1804a = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i2 = this.f7778c;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (intrinsicHeight * (i2 / intrinsicWidth));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (intrinsicWidth * (i2 / intrinsicHeight));
            } else {
                i2 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(drawable, null, null, null);
        h();
    }

    public void setItemInvoker(com1.con conVar) {
        this.f1806a = conVar;
    }

    @Override // android.widget.TextView, android.view.View
    public void setPadding(int i2, int i3, int i4, int i5) {
        this.f7777b = i2;
        super.setPadding(i2, i3, i4, i5);
    }

    public void setPopupCallback(con conVar) {
        this.f1805a = conVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f1808a = charSequence;
        h();
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        Resources resources = context.getResources();
        this.f1809c = g();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt3.f15c, i2, 0);
        this.f7776a = typedArrayObtainStyledAttributes.getDimensionPixelSize(lpt3.f5661t, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f7778c = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f7777b = -1;
        setSaveEnabled(false);
    }
}
