package COM9;

import android.graphics.RectF;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class aux implements nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f5725a;

    public aux(float f2) {
        this.f5725a = f2;
    }

    @Override // COM9.nul
    public float a(RectF rectF) {
        return this.f5725a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof aux) && this.f5725a == ((aux) obj).f5725a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Float.valueOf(this.f5725a)});
    }
}
