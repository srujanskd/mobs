package androidx.activity;

import COM3.com7;
import android.annotation.SuppressLint;
import androidx.lifecycle.nul;
import androidx.lifecycle.prn;
import java.util.ArrayDeque;
import java.util.Iterator;
import p002Aux.lpt4;
import p002Aux.lpt5;

/* JADX INFO: loaded from: classes.dex */
public final class OnBackPressedDispatcher {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Runnable f7729a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayDeque<lpt5> f1713a = new ArrayDeque<>();

    public class LifecycleOnBackPressedCancellable implements prn, lpt4 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public lpt4 f7730a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final lpt5 f1714a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final nul f1716a;

        public LifecycleOnBackPressedCancellable(nul nulVar, lpt5 lpt5Var) {
            this.f1716a = nulVar;
            this.f1714a = lpt5Var;
            nulVar.a(this);
        }

        @Override // p002Aux.lpt4
        public void cancel() {
            this.f1716a.c(this);
            this.f1714a.h(this);
            lpt4 lpt4Var = this.f7730a;
            if (lpt4Var != null) {
                lpt4Var.cancel();
                this.f7730a = null;
            }
        }

        @Override // androidx.lifecycle.prn
        public void f(com7 com7Var, nul.con conVar) {
            if (conVar == nul.con.ON_START) {
                this.f7730a = OnBackPressedDispatcher.this.b(this.f1714a);
                return;
            }
            if (conVar != nul.con.ON_STOP) {
                if (conVar == nul.con.ON_DESTROY) {
                    cancel();
                }
            } else {
                lpt4 lpt4Var = this.f7730a;
                if (lpt4Var != null) {
                    lpt4Var.cancel();
                }
            }
        }
    }

    public class aux implements lpt4 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final lpt5 f7731a;

        public aux(lpt5 lpt5Var) {
            this.f7731a = lpt5Var;
        }

        @Override // p002Aux.lpt4
        public void cancel() {
            OnBackPressedDispatcher.this.f1713a.remove(this.f7731a);
            this.f7731a.h(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f7729a = runnable;
    }

    @SuppressLint({"LambdaLast"})
    public void a(com7 com7Var, lpt5 lpt5Var) {
        nul lifecycle = com7Var.getLifecycle();
        if (lifecycle.b() == nul.EnumC0039nul.DESTROYED) {
            return;
        }
        lpt5Var.d(new LifecycleOnBackPressedCancellable(lifecycle, lpt5Var));
    }

    public lpt4 b(lpt5 lpt5Var) {
        this.f1713a.add(lpt5Var);
        aux auxVar = new aux(lpt5Var);
        lpt5Var.d(auxVar);
        return auxVar;
    }

    public void c() {
        Iterator<lpt5> itDescendingIterator = this.f1713a.descendingIterator();
        while (itDescendingIterator.hasNext()) {
            lpt5 next = itDescendingIterator.next();
            if (next.f()) {
                next.e();
                return;
            }
        }
        Runnable runnable = this.f7729a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
