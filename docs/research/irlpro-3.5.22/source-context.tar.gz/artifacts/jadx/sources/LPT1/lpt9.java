package LPT1;

import java.io.IOException;
import p120lPt2.h;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt9<T> {

    public class aux extends lpt9<T> {
        public aux() {
        }

        @Override // LPT1.lpt9
        public T b(LPT2.aux auxVar) throws IOException {
            if (auxVar.b0() != LPT2.con.NULL) {
                return (T) lpt9.this.b(auxVar);
            }
            auxVar.X();
            return null;
        }

        @Override // LPT1.lpt9
        public void d(LPT2.nul nulVar, T t2) throws IOException {
            if (t2 == null) {
                nulVar.G();
            } else {
                lpt9.this.d(nulVar, t2);
            }
        }
    }

    public final lpt9<T> a() {
        return new aux();
    }

    public abstract T b(LPT2.aux auxVar) throws IOException;

    public final com6 c(T t2) {
        try {
            h hVar = new h();
            d(hVar, t2);
            return hVar.f0();
        } catch (IOException e2) {
            throw new com7(e2);
        }
    }

    public abstract void d(LPT2.nul nulVar, T t2) throws IOException;
}
