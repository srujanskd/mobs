package COM3;

/* JADX INFO: loaded from: classes.dex */
public interface lpt7 {
    lpt6 getViewModelStore();
}
