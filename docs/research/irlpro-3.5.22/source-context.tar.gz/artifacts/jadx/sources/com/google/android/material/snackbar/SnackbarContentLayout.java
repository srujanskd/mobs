package com.google.android.material.snackbar;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import p024Com2.y;
import p075cOM6.b4;
import p075cOM6.z3;
import p137lpt1.v;

/* JADX INFO: loaded from: classes.dex */
public class SnackbarContentLayout extends LinearLayout implements v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9563a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Button f3605a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f3606a;

    public SnackbarContentLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public static void c(View view, int i2, int i3) {
        if (y.U(view)) {
            y.C0(view, y.F(view), i2, y.E(view), i3);
        } else {
            view.setPadding(view.getPaddingLeft(), i2, view.getPaddingRight(), i3);
        }
    }

    @Override // p137lpt1.v
    public void a(int i2, int i3) {
        this.f3606a.setAlpha(1.0f);
        long j2 = i3;
        long j3 = i2;
        this.f3606a.animate().alpha(0.0f).setDuration(j2).setStartDelay(j3).start();
        if (this.f3605a.getVisibility() == 0) {
            this.f3605a.setAlpha(1.0f);
            this.f3605a.animate().alpha(0.0f).setDuration(j2).setStartDelay(j3).start();
        }
    }

    @Override // p137lpt1.v
    public void b(int i2, int i3) {
        this.f3606a.setAlpha(0.0f);
        long j2 = i3;
        long j3 = i2;
        this.f3606a.animate().alpha(1.0f).setDuration(j2).setStartDelay(j3).start();
        if (this.f3605a.getVisibility() == 0) {
            this.f3605a.setAlpha(0.0f);
            this.f3605a.animate().alpha(1.0f).setDuration(j2).setStartDelay(j3).start();
        }
    }

    public final boolean d(int i2, int i3, int i4) {
        boolean z2;
        if (i2 != getOrientation()) {
            setOrientation(i2);
            z2 = true;
        } else {
            z2 = false;
        }
        if (this.f3606a.getPaddingTop() == i3 && this.f3606a.getPaddingBottom() == i4) {
            return z2;
        }
        c(this.f3606a, i3, i4);
        return true;
    }

    public Button getActionView() {
        return this.f3605a;
    }

    public TextView getMessageView() {
        return this.f3606a;
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f3606a = (TextView) findViewById(b4.U);
        this.f3605a = (Button) findViewById(b4.T);
    }

    /* JADX WARN: Code duplicated, block: B:23:0x0053  */
    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        boolean z2 = true;
        if (getOrientation() == 1) {
            return;
        }
        int dimensionPixelSize = getResources().getDimensionPixelSize(z3.f9064g);
        int dimensionPixelSize2 = getResources().getDimensionPixelSize(z3.f9063f);
        boolean z3 = this.f3606a.getLayout().getLineCount() > 1;
        if (!z3 || this.f9563a <= 0 || this.f3605a.getMeasuredWidth() <= this.f9563a) {
            if (!z3) {
                dimensionPixelSize = dimensionPixelSize2;
            }
            if (!d(0, dimensionPixelSize, dimensionPixelSize)) {
                z2 = false;
            }
        } else if (!d(1, dimensionPixelSize, dimensionPixelSize - dimensionPixelSize2)) {
            z2 = false;
        }
        if (z2) {
            super.onMeasure(i2, i3);
        }
    }

    public void setMaxInlineActionWidth(int i2) {
        this.f9563a = i2;
    }
}
