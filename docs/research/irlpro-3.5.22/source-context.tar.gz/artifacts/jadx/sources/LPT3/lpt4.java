package LPT3;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt4 extends lpt1 {
    @Override // LPT3.lpt1
    public int e() {
        return 9;
    }
}
