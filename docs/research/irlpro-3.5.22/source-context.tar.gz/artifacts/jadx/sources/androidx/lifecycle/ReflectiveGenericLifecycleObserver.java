package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
class ReflectiveGenericLifecycleObserver implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux.C0038aux f8381a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Object f2599a;

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f2599a = obj;
        this.f8381a = aux.f8387a.c(obj.getClass());
    }

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        this.f8381a.a(com7Var, conVar, this.f2599a);
    }
}
