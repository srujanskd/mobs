package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class con {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final InterfaceC0047con f2875a;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final aux f8676a = new aux();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<View> f2876a = new ArrayList();

    public static class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public long f8677a = 0;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public aux f2877a;

        public void a(int i2) {
            if (i2 < 64) {
                this.f8677a &= ~(1 << i2);
                return;
            }
            aux auxVar = this.f2877a;
            if (auxVar != null) {
                auxVar.a(i2 - 64);
            }
        }

        public int b(int i2) {
            aux auxVar = this.f2877a;
            if (auxVar == null) {
                return i2 >= 64 ? Long.bitCount(this.f8677a) : Long.bitCount(this.f8677a & ((1 << i2) - 1));
            }
            return i2 < 64 ? Long.bitCount(this.f8677a & ((1 << i2) - 1)) : auxVar.b(i2 - 64) + Long.bitCount(this.f8677a);
        }

        public final void c() {
            if (this.f2877a == null) {
                this.f2877a = new aux();
            }
        }

        public boolean d(int i2) {
            if (i2 < 64) {
                return (this.f8677a & (1 << i2)) != 0;
            }
            c();
            return this.f2877a.d(i2 - 64);
        }

        public void e(int i2, boolean z2) {
            if (i2 >= 64) {
                c();
                this.f2877a.e(i2 - 64, z2);
                return;
            }
            long j2 = this.f8677a;
            boolean z3 = (Long.MIN_VALUE & j2) != 0;
            long j3 = (1 << i2) - 1;
            this.f8677a = ((j2 & (~j3)) << 1) | (j2 & j3);
            if (z2) {
                h(i2);
            } else {
                a(i2);
            }
            if (z3 || this.f2877a != null) {
                c();
                this.f2877a.e(0, z3);
            }
        }

        public boolean f(int i2) {
            if (i2 >= 64) {
                c();
                return this.f2877a.f(i2 - 64);
            }
            long j2 = 1 << i2;
            long j3 = this.f8677a;
            boolean z2 = (j3 & j2) != 0;
            long j4 = j3 & (~j2);
            this.f8677a = j4;
            long j5 = j2 - 1;
            this.f8677a = (j4 & j5) | Long.rotateRight((~j5) & j4, 1);
            aux auxVar = this.f2877a;
            if (auxVar != null) {
                if (auxVar.d(0)) {
                    h(63);
                }
                this.f2877a.f(0);
            }
            return z2;
        }

        public void g() {
            this.f8677a = 0L;
            aux auxVar = this.f2877a;
            if (auxVar != null) {
                auxVar.g();
            }
        }

        public void h(int i2) {
            if (i2 < 64) {
                this.f8677a |= 1 << i2;
            } else {
                c();
                this.f2877a.h(i2 - 64);
            }
        }

        public String toString() {
            if (this.f2877a == null) {
                return Long.toBinaryString(this.f8677a);
            }
            return this.f2877a.toString() + "xx" + Long.toBinaryString(this.f8677a);
        }
    }

    /* JADX INFO: renamed from: androidx.recyclerview.widget.con$con, reason: collision with other inner class name */
    public interface InterfaceC0047con {
        View a(int i2);

        void b(int i2);

        int c();

        void d(View view);

        int e(View view);

        void f(int i2);

        RecyclerView.h g(View view);

        void h(View view);

        void i(View view, int i2, ViewGroup.LayoutParams layoutParams);

        void j();

        void k(View view, int i2);
    }

    public con(InterfaceC0047con interfaceC0047con) {
        this.f2875a = interfaceC0047con;
    }

    public void a(View view, int i2, boolean z2) {
        int iC = i2 < 0 ? this.f2875a.c() : h(i2);
        this.f8676a.e(iC, z2);
        if (z2) {
            l(view);
        }
        this.f2875a.k(view, iC);
    }

    public void b(View view, boolean z2) {
        a(view, -1, z2);
    }

    public void c(View view, int i2, ViewGroup.LayoutParams layoutParams, boolean z2) {
        int iC = i2 < 0 ? this.f2875a.c() : h(i2);
        this.f8676a.e(iC, z2);
        if (z2) {
            l(view);
        }
        this.f2875a.i(view, iC, layoutParams);
    }

    public void d(int i2) {
        int iH = h(i2);
        this.f8676a.f(iH);
        this.f2875a.f(iH);
    }

    public View e(int i2) {
        int size = this.f2876a.size();
        for (int i3 = 0; i3 < size; i3++) {
            View view = this.f2876a.get(i3);
            RecyclerView.h hVarG = this.f2875a.g(view);
            if (hVarG.m() == i2 && !hVarG.t() && !hVarG.v()) {
                return view;
            }
        }
        return null;
    }

    public View f(int i2) {
        return this.f2875a.a(h(i2));
    }

    public int g() {
        return this.f2875a.c() - this.f2876a.size();
    }

    public final int h(int i2) {
        if (i2 < 0) {
            return -1;
        }
        int iC = this.f2875a.c();
        int i3 = i2;
        while (i3 < iC) {
            int iB = i2 - (i3 - this.f8676a.b(i3));
            if (iB == 0) {
                while (this.f8676a.d(i3)) {
                    i3++;
                }
                return i3;
            }
            i3 += iB;
        }
        return -1;
    }

    public View i(int i2) {
        return this.f2875a.a(i2);
    }

    public int j() {
        return this.f2875a.c();
    }

    public void k(View view) {
        int iE = this.f2875a.e(view);
        if (iE >= 0) {
            this.f8676a.h(iE);
            l(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    public final void l(View view) {
        this.f2876a.add(view);
        this.f2875a.d(view);
    }

    public int m(View view) {
        int iE = this.f2875a.e(view);
        if (iE == -1 || this.f8676a.d(iE)) {
            return -1;
        }
        return iE - this.f8676a.b(iE);
    }

    public boolean n(View view) {
        return this.f2876a.contains(view);
    }

    public void o() {
        this.f8676a.g();
        for (int size = this.f2876a.size() - 1; size >= 0; size--) {
            this.f2875a.h(this.f2876a.get(size));
            this.f2876a.remove(size);
        }
        this.f2875a.j();
    }

    public void p(View view) {
        int iE = this.f2875a.e(view);
        if (iE < 0) {
            return;
        }
        if (this.f8676a.f(iE)) {
            t(view);
        }
        this.f2875a.b(iE);
    }

    public void q(int i2) {
        int iH = h(i2);
        View viewA = this.f2875a.a(iH);
        if (viewA == null) {
            return;
        }
        if (this.f8676a.f(iH)) {
            t(viewA);
        }
        this.f2875a.b(iH);
    }

    public boolean r(View view) {
        int iE = this.f2875a.e(view);
        if (iE == -1) {
            t(view);
            return true;
        }
        if (!this.f8676a.d(iE)) {
            return false;
        }
        this.f8676a.f(iE);
        t(view);
        this.f2875a.b(iE);
        return true;
    }

    public void s(View view) {
        int iE = this.f2875a.e(view);
        if (iE < 0) {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
        if (this.f8676a.d(iE)) {
            this.f8676a.a(iE);
            t(view);
        } else {
            throw new RuntimeException("trying to unhide a view that was not hidden" + view);
        }
    }

    public final boolean t(View view) {
        if (!this.f2876a.remove(view)) {
            return false;
        }
        this.f2875a.h(view);
        return true;
    }

    public String toString() {
        return this.f8676a.toString() + ", hidden list:" + this.f2876a.size();
    }
}
