package COM7;

import android.animation.TypeEvaluator;
import android.graphics.drawable.Drawable;
import android.util.Property;
import p031Com9.lpt5;

/* JADX INFO: loaded from: classes.dex */
public interface prn {

    public static class com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f5719a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f5720b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f5721c;

        public com1() {
        }

        public void a(float f2, float f3, float f4) {
            this.f5719a = f2;
            this.f5720b = f3;
            this.f5721c = f4;
        }

        public com1(float f2, float f3, float f4) {
            this.f5719a = f2;
            this.f5720b = f3;
            this.f5721c = f4;
        }
    }

    public static class con implements TypeEvaluator<com1> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final TypeEvaluator<com1> f5722a = new con();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final com1 f70a = new com1();

        @Override // android.animation.TypeEvaluator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public com1 evaluate(float f2, com1 com1Var, com1 com1Var2) {
            this.f70a.a(lpt5.c(com1Var.f5719a, com1Var2.f5719a, f2), lpt5.c(com1Var.f5720b, com1Var2.f5720b, f2), lpt5.c(com1Var.f5721c, com1Var2.f5721c, f2));
            return this.f70a;
        }
    }

    public static class nul extends Property<prn, com1> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final Property<prn, com1> f5723a = new nul("circularReveal");

        public nul(String str) {
            super(com1.class, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public com1 get(prn prnVar) {
            return prnVar.getRevealInfo();
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(prn prnVar, com1 com1Var) {
            prnVar.setRevealInfo(com1Var);
        }
    }

    /* JADX INFO: renamed from: COM7.prn$prn, reason: collision with other inner class name */
    public static class C0004prn extends Property<prn, Integer> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final Property<prn, Integer> f5724a = new C0004prn("circularRevealScrimColor");

        public C0004prn(String str) {
            super(Integer.class, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Integer get(prn prnVar) {
            return Integer.valueOf(prnVar.getCircularRevealScrimColor());
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(prn prnVar, Integer num) {
            prnVar.setCircularRevealScrimColor(num.intValue());
        }
    }

    void a();

    void b();

    int getCircularRevealScrimColor();

    com1 getRevealInfo();

    void setCircularRevealOverlayDrawable(Drawable drawable);

    void setCircularRevealScrimColor(int i2);

    void setRevealInfo(com1 com1Var);
}
