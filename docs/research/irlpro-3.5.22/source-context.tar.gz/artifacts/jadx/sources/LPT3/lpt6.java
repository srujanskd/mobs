package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;
import p139lpt3.d0;

/* JADX INFO: loaded from: classes.dex */
public final class lpt6 extends lpt4 {
    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int length = str.length();
        if (length == 7) {
            try {
                str = str + lpt3.b(lpt5.c(str));
            } catch (d0 e2) {
                throw new IllegalArgumentException(e2);
            }
        } else {
            if (length != 8) {
                throw new IllegalArgumentException("Requested contents should be 7 or 8 digits long, but got ".concat(String.valueOf(length)));
            }
            try {
                if (!lpt3.a(lpt5.c(str))) {
                    throw new IllegalArgumentException("Contents do not pass checksum");
                }
            } catch (d0 unused) {
                throw new IllegalArgumentException("Illegal contents");
            }
        }
        lpt1.c(str);
        int iDigit = Character.digit(str.charAt(0), 10);
        if (iDigit != 0 && iDigit != 1) {
            throw new IllegalArgumentException("Number system must be 0 or 1");
        }
        int i2 = lpt5.f6635c[iDigit][Character.digit(str.charAt(7), 10)];
        boolean[] zArr = new boolean[51];
        int iB = lpt1.b(zArr, 0, lpt3.f6632a, true);
        for (int i3 = 1; i3 <= 6; i3++) {
            int iDigit2 = Character.digit(str.charAt(i3), 10);
            if (((i2 >> (6 - i3)) & 1) == 1) {
                iDigit2 += 10;
            }
            iB += lpt1.b(zArr, iB, lpt3.f861b[iDigit2], false);
        }
        lpt1.b(zArr, iB, lpt3.f6634c, false);
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.UPC_E);
    }
}
