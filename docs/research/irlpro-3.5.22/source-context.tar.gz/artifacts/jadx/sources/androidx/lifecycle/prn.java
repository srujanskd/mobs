package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface prn extends COM3.com6 {
    void f(COM3.com7 com7Var, nul.con conVar);
}
