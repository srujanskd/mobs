package COM3;

import java.io.Closeable;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Map<String, Object> f5696a = new HashMap();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public volatile boolean f62a = false;

    public static void b(Object obj) {
        if (obj instanceof Closeable) {
            try {
                ((Closeable) obj).close();
            } catch (IOException e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    public final void a() {
        this.f62a = true;
        Map<String, Object> map = this.f5696a;
        if (map != null) {
            synchronized (map) {
                Iterator<Object> it = this.f5696a.values().iterator();
                while (it.hasNext()) {
                    b(it.next());
                }
            }
        }
        d();
    }

    public <T> T c(String str) {
        T t2;
        Map<String, Object> map = this.f5696a;
        if (map == null) {
            return null;
        }
        synchronized (map) {
            t2 = (T) this.f5696a.get(str);
        }
        return t2;
    }

    public void d() {
    }

    public <T> T e(String str, T t2) {
        Object obj;
        synchronized (this.f5696a) {
            obj = this.f5696a.get(str);
            if (obj == null) {
                this.f5696a.put(str, t2);
            }
        }
        if (obj != null) {
            t2 = (T) obj;
        }
        if (this.f62a) {
            b(t2);
        }
        return t2;
    }
}
