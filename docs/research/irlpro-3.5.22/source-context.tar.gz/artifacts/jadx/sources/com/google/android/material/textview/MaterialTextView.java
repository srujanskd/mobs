package com.google.android.material.textview;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatTextView;
import p075cOM6.h4;
import p075cOM6.x3;
import p098coM9.a;
import p098coM9.b;
import p128lpT1.u;

/* JADX INFO: loaded from: classes.dex */
public class MaterialTextView extends AppCompatTextView {
    public MaterialTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    public static boolean g(Context context) {
        return a.b(context, x3.L, true);
    }

    public static int h(Resources.Theme theme, AttributeSet attributeSet, int i2, int i3) {
        TypedArray typedArrayObtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, h4.f3057C0, i2, i3);
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(h4.T1, -1);
        typedArrayObtainStyledAttributes.recycle();
        return resourceId;
    }

    public static int i(Context context, TypedArray typedArray, int... iArr) {
        int iC = -1;
        for (int i2 = 0; i2 < iArr.length && iC < 0; i2++) {
            iC = b.c(context, typedArray, iArr[i2], -1);
        }
        return iC;
    }

    public static boolean j(Context context, Resources.Theme theme, AttributeSet attributeSet, int i2, int i3) {
        TypedArray typedArrayObtainStyledAttributes = theme.obtainStyledAttributes(attributeSet, h4.f3057C0, i2, i3);
        int i4 = i(context, typedArrayObtainStyledAttributes, h4.U1, h4.V1);
        typedArrayObtainStyledAttributes.recycle();
        return i4 != -1;
    }

    public final void f(Resources.Theme theme, int i2) {
        TypedArray typedArrayObtainStyledAttributes = theme.obtainStyledAttributes(i2, h4.f3054B0);
        int i3 = i(getContext(), typedArrayObtainStyledAttributes, h4.R1, h4.S1);
        typedArrayObtainStyledAttributes.recycle();
        if (i3 >= 0) {
            setLineHeight(i3);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatTextView, android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        if (g(context)) {
            f(context.getTheme(), i2);
        }
    }

    public MaterialTextView(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public MaterialTextView(Context context, AttributeSet attributeSet, int i2, int i3) {
        int iH;
        super(u.c(context, attributeSet, i2, i3), attributeSet, i2);
        Context context2 = getContext();
        if (g(context2)) {
            Resources.Theme theme = context2.getTheme();
            if (j(context2, theme, attributeSet, i2, i3) || (iH = h(theme, attributeSet, i2, i3)) == -1) {
                return;
            }
            f(theme, iH);
        }
    }
}
