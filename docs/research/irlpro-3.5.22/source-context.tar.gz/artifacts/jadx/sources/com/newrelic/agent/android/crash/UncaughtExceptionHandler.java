package com.newrelic.agent.android.crash;

import com.newrelic.agent.android.Agent;
import com.newrelic.agent.android.AgentConfiguration;
import com.newrelic.agent.android.FeatureFlag;
import com.newrelic.agent.android.analytics.AnalyticsAttribute;
import com.newrelic.agent.android.analytics.AnalyticsControllerImpl;
import com.newrelic.agent.android.background.ApplicationStateMonitor;
import com.newrelic.agent.android.harvest.Harvest;
import com.newrelic.agent.android.logging.AgentLog;
import com.newrelic.agent.android.logging.AgentLogManager;
import com.newrelic.agent.android.payload.PayloadController;
import com.newrelic.agent.android.stats.StatsEngine;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
public class UncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
    protected static final AgentLog log = AgentLogManager.getAgentLog();
    static Thread.UncaughtExceptionHandler previousExceptionHandler = null;
    private final CrashReporter crashReporter;
    protected final AtomicBoolean handledException = new AtomicBoolean(false);

    public UncaughtExceptionHandler(CrashReporter crashReporter) {
        this.crashReporter = crashReporter;
    }

    public void chainExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler, Thread thread, Throwable th) {
        if (uncaughtExceptionHandler != null) {
            log.debug("Chaining crash reporting duties to " + uncaughtExceptionHandler.getClass().getSimpleName());
            uncaughtExceptionHandler.uncaughtException(thread, th);
        }
    }

    public Thread.UncaughtExceptionHandler getPreviousExceptionHandler() {
        return previousExceptionHandler;
    }

    public void installExceptionHandler() {
        Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        if (defaultUncaughtExceptionHandler == null) {
            log.debug("Installing New Relic crash handler.");
        } else {
            if (defaultUncaughtExceptionHandler instanceof UncaughtExceptionHandler) {
                log.debug("New Relic crash handler already installed.");
                return;
            }
            Thread.UncaughtExceptionHandler uncaughtExceptionHandler = previousExceptionHandler;
            if (uncaughtExceptionHandler != null) {
                if (!(uncaughtExceptionHandler instanceof UncaughtExceptionHandler)) {
                    log.warning("Previous uncaught exception handler[" + previousExceptionHandler.getClass().getName() + "] exists. Assuming it delegates to [" + UncaughtExceptionHandler.class.getName() + "]");
                    return;
                }
                log.warning("Previous uncaught exception handler[" + previousExceptionHandler.getClass().getName() + "] exists, and it is us! Replace it.");
            }
            log.debug("Installing New Relic crash handler and chaining to " + defaultUncaughtExceptionHandler.getClass().getName());
        }
        previousExceptionHandler = defaultUncaughtExceptionHandler;
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    public void resetExceptionHandler() {
        Thread.UncaughtExceptionHandler defaultUncaughtExceptionHandler;
        if (previousExceptionHandler != null && (defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler()) != null) {
            if (defaultUncaughtExceptionHandler instanceof UncaughtExceptionHandler) {
                Thread.setDefaultUncaughtExceptionHandler(previousExceptionHandler);
                previousExceptionHandler = null;
            } else {
                log.warning("Previous uncaught exception handler[" + defaultUncaughtExceptionHandler.getClass().getName() + "] was set after agent start. Let it be...");
            }
        }
        this.handledException.set(false);
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th) {
        boolean zEquals;
        if (!Agent.getUnityInstrumentationFlag().equals("YES") && !this.handledException.compareAndSet(false, true)) {
            StatsEngine.get().inc("Supportability/AgentHealth/Recursion/UncaughtExceptionHandler");
            return;
        }
        try {
            AgentConfiguration agentConfiguration = this.crashReporter.getAgentConfiguration();
            if (this.crashReporter.isEnabled() && FeatureFlag.featureEnabled(FeatureFlag.CrashReporting)) {
                AgentLog agentLog = log;
                agentLog.debug("A crash has been detected in " + thread.getStackTrace()[0].getClassName() + " and will be reported ASAP.");
                StringBuilder sb = new StringBuilder();
                sb.append("Analytics data is currently ");
                sb.append(agentConfiguration.getEnableAnalyticsEvents() ? "enabled " : "disabled");
                agentLog.debug(sb.toString());
                AnalyticsControllerImpl analyticsControllerImpl = AnalyticsControllerImpl.getInstance();
                analyticsControllerImpl.setEnabled(true);
                long millisSinceStart = Harvest.getMillisSinceStart();
                if (millisSinceStart != 0) {
                    analyticsControllerImpl.setAttribute(AnalyticsAttribute.SESSION_DURATION_ATTRIBUTE, millisSinceStart / 1000.0f, false);
                }
                this.crashReporter.storeAndReportCrash(new Crash(th, analyticsControllerImpl.getSessionAttributes(), analyticsControllerImpl.getEventManager().getQueuedEvents(), agentConfiguration.getEnableAnalyticsEvents()));
                if (zEquals) {
                    return;
                } else {
                    return;
                }
            }
            log.debug("A crash has been detected but crash reporting is disabled!");
        } finally {
            if (Agent.isInstantApp()) {
                Harvest.shutdown();
                ApplicationStateMonitor.getInstance().uiHidden();
            }
            Thread.UncaughtExceptionHandler uncaughtExceptionHandler = previousExceptionHandler;
            PayloadController.shutdown();
            if (!Agent.getUnityInstrumentationFlag().equals("YES")) {
                chainExceptionHandler(uncaughtExceptionHandler, thread, th);
            }
        }
    }
}
