package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import p016CoM4.com7;
import p016CoM4.com8;
import p016CoM4.lpt2;
import p016CoM4.lpt7;

/* JADX INFO: loaded from: classes.dex */
public class SeekBarPreference extends Preference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8466a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final View.OnKeyListener f2659a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final SeekBar.OnSeekBarChangeListener f2660a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public SeekBar f2661a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TextView f2662a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8467b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2663b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8468c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2664c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8469d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2665d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f8470e;

    public class aux implements SeekBar.OnSeekBarChangeListener {
        public aux() {
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onProgressChanged(SeekBar seekBar, int i2, boolean z2) {
            if (z2) {
                SeekBarPreference seekBarPreference = SeekBarPreference.this;
                if (seekBarPreference.f8470e || !seekBarPreference.f2663b) {
                    seekBarPreference.f(seekBar);
                    return;
                }
            }
            SeekBarPreference seekBarPreference2 = SeekBarPreference.this;
            seekBarPreference2.g(i2 + seekBarPreference2.f8467b);
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStartTrackingTouch(SeekBar seekBar) {
            SeekBarPreference.this.f2663b = true;
        }

        @Override // android.widget.SeekBar.OnSeekBarChangeListener
        public void onStopTrackingTouch(SeekBar seekBar) {
            SeekBarPreference.this.f2663b = false;
            int progress = seekBar.getProgress();
            SeekBarPreference seekBarPreference = SeekBarPreference.this;
            if (progress + seekBarPreference.f8467b != seekBarPreference.f8466a) {
                seekBarPreference.f(seekBar);
            }
        }
    }

    public class con implements View.OnKeyListener {
        public con() {
        }

        @Override // android.view.View.OnKeyListener
        public boolean onKey(View view, int i2, KeyEvent keyEvent) {
            if (keyEvent.getAction() != 0) {
                return false;
            }
            SeekBarPreference seekBarPreference = SeekBarPreference.this;
            if ((!seekBarPreference.f2664c && (i2 == 21 || i2 == 22)) || i2 == 23 || i2 == 66) {
                return false;
            }
            SeekBar seekBar = seekBarPreference.f2661a;
            if (seekBar != null) {
                return seekBar.onKeyDown(i2, keyEvent);
            }
            Log.e("SeekBarPreference", "SeekBar view is null and hence cannot be adjusted.");
            return false;
        }
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f2660a = new aux();
        this.f2659a = new con();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f540m, i2, i3);
        this.f8467b = typedArrayObtainStyledAttributes.getInt(lpt7.x0, 0);
        a(typedArrayObtainStyledAttributes.getInt(lpt7.v0, 100));
        b(typedArrayObtainStyledAttributes.getInt(lpt7.y0, 0));
        this.f2664c = typedArrayObtainStyledAttributes.getBoolean(lpt7.w0, true);
        this.f2665d = typedArrayObtainStyledAttributes.getBoolean(lpt7.z0, false);
        this.f8470e = typedArrayObtainStyledAttributes.getBoolean(lpt7.A0, false);
        typedArrayObtainStyledAttributes.recycle();
    }

    public final void a(int i2) {
        int i3 = this.f8467b;
        if (i2 < i3) {
            i2 = i3;
        }
        if (i2 != this.f8468c) {
            this.f8468c = i2;
            notifyChanged();
        }
    }

    public final void b(int i2) {
        if (i2 != this.f8469d) {
            this.f8469d = Math.min(this.f8468c - this.f8467b, Math.abs(i2));
            notifyChanged();
        }
    }

    public void c(boolean z2) {
        this.f8470e = z2;
    }

    public void d(int i2) {
        e(i2, true);
    }

    public final void e(int i2, boolean z2) {
        int i3 = this.f8467b;
        if (i2 < i3) {
            i2 = i3;
        }
        int i4 = this.f8468c;
        if (i2 > i4) {
            i2 = i4;
        }
        if (i2 != this.f8466a) {
            this.f8466a = i2;
            g(i2);
            persistInt(i2);
            if (z2) {
                notifyChanged();
            }
        }
    }

    public void f(SeekBar seekBar) {
        int progress = this.f8467b + seekBar.getProgress();
        if (progress != this.f8466a) {
            if (callChangeListener(Integer.valueOf(progress))) {
                e(progress, false);
            } else {
                seekBar.setProgress(this.f8466a - this.f8467b);
                g(this.f8466a);
            }
        }
    }

    public void g(int i2) {
        TextView textView = this.f2662a;
        if (textView != null) {
            textView.setText(String.valueOf(i2));
        }
    }

    public int getValue() {
        return this.f8466a;
    }

    @Override // androidx.preference.Preference
    public void onBindViewHolder(com7 com7Var) {
        super.onBindViewHolder(com7Var);
        ((RecyclerView.h) com7Var).f2786a.setOnKeyListener(this.f2659a);
        this.f2661a = (SeekBar) com7Var.M(lpt2.f6187f);
        TextView textView = (TextView) com7Var.M(lpt2.f6188g);
        this.f2662a = textView;
        if (this.f2665d) {
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
            this.f2662a = null;
        }
        SeekBar seekBar = this.f2661a;
        if (seekBar == null) {
            Log.e("SeekBarPreference", "SeekBar view is null in onBindViewHolder.");
            return;
        }
        seekBar.setOnSeekBarChangeListener(this.f2660a);
        this.f2661a.setMax(this.f8468c - this.f8467b);
        int i2 = this.f8469d;
        if (i2 != 0) {
            this.f2661a.setKeyProgressIncrement(i2);
        } else {
            this.f8469d = this.f2661a.getKeyProgressIncrement();
        }
        this.f2661a.setProgress(this.f8466a - this.f8467b);
        g(this.f8466a);
        this.f2661a.setEnabled(isEnabled());
    }

    @Override // androidx.preference.Preference
    public Object onGetDefaultValue(TypedArray typedArray, int i2) {
        return Integer.valueOf(typedArray.getInt(i2, 0));
    }

    @Override // androidx.preference.Preference
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(nul.class)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        nul nulVar = (nul) parcelable;
        super.onRestoreInstanceState(nulVar.getSuperState());
        this.f8466a = nulVar.f8473a;
        this.f8467b = nulVar.f8474b;
        this.f8468c = nulVar.f8475c;
        notifyChanged();
    }

    @Override // androidx.preference.Preference
    public Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState = super.onSaveInstanceState();
        if (isPersistent()) {
            return parcelableOnSaveInstanceState;
        }
        nul nulVar = new nul(parcelableOnSaveInstanceState);
        nulVar.f8473a = this.f8466a;
        nulVar.f8474b = this.f8467b;
        nulVar.f8475c = this.f8468c;
        return nulVar;
    }

    @Override // androidx.preference.Preference
    public void onSetInitialValue(Object obj) {
        if (obj == null) {
            obj = 0;
        }
        d(getPersistedInt(((Integer) obj).intValue()));
    }

    public static class nul extends Preference.con {
        public static final Parcelable.Creator<nul> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8473a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8474b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8475c;

        public class aux implements Parcelable.Creator<nul> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public nul createFromParcel(Parcel parcel) {
                return new nul(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public nul[] newArray(int i2) {
                return new nul[i2];
            }
        }

        public nul(Parcel parcel) {
            super(parcel);
            this.f8473a = parcel.readInt();
            this.f8474b = parcel.readInt();
            this.f8475c = parcel.readInt();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f8473a);
            parcel.writeInt(this.f8474b);
            parcel.writeInt(this.f8475c);
        }

        public nul(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public SeekBarPreference(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com8.f6176j);
    }

    public SeekBarPreference(Context context) {
        this(context, null);
    }
}
