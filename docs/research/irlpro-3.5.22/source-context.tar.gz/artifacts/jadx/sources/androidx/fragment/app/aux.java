package androidx.fragment.app;

import android.util.Log;
import java.io.PrintWriter;
import java.util.ArrayList;
import p015CoM3.p;

/* JADX INFO: loaded from: classes.dex */
public final class aux extends lpt3 implements com6.com7, com6.lpt2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com6 f8233a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f8234d;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8235h;

    public aux(com6 com6Var) {
        super(com6Var.s0(), com6Var.v0() != null ? com6Var.v0().f().getClassLoader() : null);
        this.f8235h = -1;
        this.f8233a = com6Var;
    }

    public static boolean F(lpt3.aux auxVar) {
        Fragment fragment = auxVar.f2519a;
        return (fragment == null || !fragment.mAdded || fragment.mView == null || fragment.mDetached || fragment.mHidden || !fragment.isPostponed()) ? false : true;
    }

    public void A(boolean z2) {
        for (int size = ((lpt3) this).f2511a.size() - 1; size >= 0; size--) {
            lpt3.aux auxVar = ((lpt3) this).f2511a.get(size);
            Fragment fragment = auxVar.f2519a;
            if (fragment != null) {
                fragment.setPopDirection(true);
                fragment.setNextTransition(com6.k1(this.f8301e));
                fragment.setSharedElementNames(((lpt3) this).f2516c, ((lpt3) this).f2514b);
            }
            switch (auxVar.f8304a) {
                case 1:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.n1(fragment, true);
                    this.f8233a.f1(fragment);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + auxVar.f8304a);
                case 3:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.g(fragment);
                    break;
                case 4:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.r1(fragment);
                    break;
                case 5:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.n1(fragment, true);
                    this.f8233a.E0(fragment);
                    break;
                case 6:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.m(fragment);
                    break;
                case 7:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.n1(fragment, true);
                    this.f8233a.y(fragment);
                    break;
                case 8:
                    this.f8233a.p1(null);
                    break;
                case 9:
                    this.f8233a.p1(fragment);
                    break;
                case 10:
                    this.f8233a.o1(fragment, auxVar.f2520a);
                    break;
            }
            if (!((lpt3) this).f2517c && auxVar.f8304a != 3 && fragment != null && !com6.f8252h) {
                this.f8233a.R0(fragment);
            }
        }
        if (((lpt3) this).f2517c || !z2 || com6.f8252h) {
            return;
        }
        com6 com6Var = this.f8233a;
        com6Var.S0(com6Var.f8253a, true);
    }

    /* JADX WARN: Code duplicated, block: B:34:0x00b2  */
    public Fragment B(ArrayList<Fragment> arrayList, Fragment fragment) {
        Fragment fragment2 = fragment;
        int i2 = 0;
        while (i2 < ((lpt3) this).f2511a.size()) {
            lpt3.aux auxVar = ((lpt3) this).f2511a.get(i2);
            int i3 = auxVar.f8304a;
            if (i3 == 1) {
                arrayList.add(auxVar.f2519a);
            } else if (i3 == 2) {
                Fragment fragment3 = auxVar.f2519a;
                int i4 = fragment3.mContainerId;
                boolean z2 = false;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    Fragment fragment4 = arrayList.get(size);
                    if (fragment4.mContainerId == i4) {
                        if (fragment4 == fragment3) {
                            z2 = true;
                        } else {
                            if (fragment4 == fragment2) {
                                ((lpt3) this).f2511a.add(i2, new lpt3.aux(9, fragment4));
                                i2++;
                                fragment2 = null;
                            }
                            lpt3.aux auxVar2 = new lpt3.aux(3, fragment4);
                            auxVar2.f8305b = auxVar.f8305b;
                            auxVar2.f8307d = auxVar.f8307d;
                            auxVar2.f8306c = auxVar.f8306c;
                            auxVar2.f8308e = auxVar.f8308e;
                            ((lpt3) this).f2511a.add(i2, auxVar2);
                            arrayList.remove(fragment4);
                            i2++;
                        }
                    }
                }
                if (z2) {
                    ((lpt3) this).f2511a.remove(i2);
                    i2--;
                } else {
                    auxVar.f8304a = 1;
                    arrayList.add(fragment3);
                }
            } else if (i3 == 3 || i3 == 6) {
                arrayList.remove(auxVar.f2519a);
                Fragment fragment5 = auxVar.f2519a;
                if (fragment5 == fragment2) {
                    ((lpt3) this).f2511a.add(i2, new lpt3.aux(9, fragment5));
                    i2++;
                    fragment2 = null;
                }
            } else if (i3 == 7) {
                arrayList.add(auxVar.f2519a);
            } else if (i3 == 8) {
                ((lpt3) this).f2511a.add(i2, new lpt3.aux(9, fragment2));
                i2++;
                fragment2 = auxVar.f2519a;
            }
            i2++;
        }
        return fragment2;
    }

    public String C() {
        return ((lpt3) this).f2510a;
    }

    public boolean D(int i2) {
        int size = ((lpt3) this).f2511a.size();
        for (int i3 = 0; i3 < size; i3++) {
            Fragment fragment = ((lpt3) this).f2511a.get(i3).f2519a;
            int i4 = fragment != null ? fragment.mContainerId : 0;
            if (i4 != 0 && i4 == i2) {
                return true;
            }
        }
        return false;
    }

    public boolean E(ArrayList<aux> arrayList, int i2, int i3) {
        if (i3 == i2) {
            return false;
        }
        int size = ((lpt3) this).f2511a.size();
        int i4 = -1;
        for (int i5 = 0; i5 < size; i5++) {
            Fragment fragment = ((lpt3) this).f2511a.get(i5).f2519a;
            int i6 = fragment != null ? fragment.mContainerId : 0;
            if (i6 != 0 && i6 != i4) {
                for (int i7 = i2; i7 < i3; i7++) {
                    aux auxVar = arrayList.get(i7);
                    int size2 = ((lpt3) auxVar).f2511a.size();
                    for (int i8 = 0; i8 < size2; i8++) {
                        Fragment fragment2 = ((lpt3) auxVar).f2511a.get(i8).f2519a;
                        if ((fragment2 != null ? fragment2.mContainerId : 0) == i6) {
                            return true;
                        }
                    }
                }
                i4 = i6;
            }
        }
        return false;
    }

    public boolean G() {
        for (int i2 = 0; i2 < ((lpt3) this).f2511a.size(); i2++) {
            if (F(((lpt3) this).f2511a.get(i2))) {
                return true;
            }
        }
        return false;
    }

    public void H() {
        if (((lpt3) this).f2518d != null) {
            for (int i2 = 0; i2 < ((lpt3) this).f2518d.size(); i2++) {
                ((lpt3) this).f2518d.get(i2).run();
            }
            ((lpt3) this).f2518d = null;
        }
    }

    public void I(Fragment.com8 com8Var) {
        for (int i2 = 0; i2 < ((lpt3) this).f2511a.size(); i2++) {
            lpt3.aux auxVar = ((lpt3) this).f2511a.get(i2);
            if (F(auxVar)) {
                auxVar.f2519a.setOnStartEnterTransitionListener(com8Var);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0027  */
    /* JADX WARN: Code duplicated, block: B:14:0x002d  */
    public Fragment J(ArrayList<Fragment> arrayList, Fragment fragment) {
        for (int size = ((lpt3) this).f2511a.size() - 1; size >= 0; size--) {
            lpt3.aux auxVar = ((lpt3) this).f2511a.get(size);
            int i2 = auxVar.f8304a;
            if (i2 == 1) {
                arrayList.remove(auxVar.f2519a);
            } else if (i2 != 3) {
                switch (i2) {
                    case 6:
                        arrayList.add(auxVar.f2519a);
                        break;
                    case 7:
                        arrayList.remove(auxVar.f2519a);
                        break;
                    case 8:
                        fragment = null;
                        break;
                    case 9:
                        fragment = auxVar.f2519a;
                        break;
                    case 10:
                        auxVar.f2521b = auxVar.f2520a;
                        break;
                }
            } else {
                arrayList.add(auxVar.f2519a);
            }
        }
        return fragment;
    }

    @Override // androidx.fragment.app.com6.lpt2
    public boolean a(ArrayList<aux> arrayList, ArrayList<Boolean> arrayList2) {
        if (com6.H0(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!((lpt3) this).f2512a) {
            return true;
        }
        this.f8233a.e(this);
        return true;
    }

    @Override // androidx.fragment.app.com6.com7
    public int getId() {
        return this.f8235h;
    }

    @Override // androidx.fragment.app.lpt3
    public int i() {
        return w(false);
    }

    @Override // androidx.fragment.app.lpt3
    public int j() {
        return w(true);
    }

    @Override // androidx.fragment.app.lpt3
    public void k() {
        n();
        this.f8233a.c0(this, false);
    }

    @Override // androidx.fragment.app.lpt3
    public void l() {
        n();
        this.f8233a.c0(this, true);
    }

    @Override // androidx.fragment.app.lpt3
    public lpt3 m(Fragment fragment) {
        com6 com6Var = fragment.mFragmentManager;
        if (com6Var == null || com6Var == this.f8233a) {
            return super.m(fragment);
        }
        throw new IllegalStateException("Cannot detach Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    @Override // androidx.fragment.app.lpt3
    public void o(int i2, Fragment fragment, String str, int i3) {
        super.o(i2, fragment, str, i3);
        fragment.mFragmentManager = this.f8233a;
    }

    @Override // androidx.fragment.app.lpt3
    public lpt3 p(Fragment fragment) {
        com6 com6Var = fragment.mFragmentManager;
        if (com6Var == null || com6Var == this.f8233a) {
            return super.p(fragment);
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    @Override // androidx.fragment.app.lpt3
    public lpt3 s(Fragment fragment) {
        com6 com6Var;
        if (fragment == null || (com6Var = fragment.mFragmentManager) == null || com6Var == this.f8233a) {
            return super.s(fragment);
        }
        throw new IllegalStateException("Cannot setPrimaryNavigation for Fragment attached to a different FragmentManager. Fragment " + fragment.toString() + " is already attached to a FragmentManager.");
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f8235h >= 0) {
            sb.append(" #");
            sb.append(this.f8235h);
        }
        if (((lpt3) this).f2510a != null) {
            sb.append(" ");
            sb.append(((lpt3) this).f2510a);
        }
        sb.append("}");
        return sb.toString();
    }

    public void v(int i2) {
        if (((lpt3) this).f2512a) {
            if (com6.H0(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            int size = ((lpt3) this).f2511a.size();
            for (int i3 = 0; i3 < size; i3++) {
                lpt3.aux auxVar = ((lpt3) this).f2511a.get(i3);
                Fragment fragment = auxVar.f2519a;
                if (fragment != null) {
                    fragment.mBackStackNesting += i2;
                    if (com6.H0(2)) {
                        Log.v("FragmentManager", "Bump nesting of " + auxVar.f2519a + " to " + auxVar.f2519a.mBackStackNesting);
                    }
                }
            }
        }
    }

    public int w(boolean z2) {
        if (this.f8234d) {
            throw new IllegalStateException("commit already called");
        }
        if (com6.H0(2)) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new p("FragmentManager"));
            x("  ", printWriter);
            printWriter.close();
        }
        this.f8234d = true;
        if (((lpt3) this).f2512a) {
            this.f8235h = this.f8233a.k();
        } else {
            this.f8235h = -1;
        }
        this.f8233a.Z(this, z2);
        return this.f8235h;
    }

    public void x(String str, PrintWriter printWriter) {
        y(str, printWriter, true);
    }

    public void y(String str, PrintWriter printWriter, boolean z2) {
        String str2;
        if (z2) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(((lpt3) this).f2510a);
            printWriter.print(" mIndex=");
            printWriter.print(this.f8235h);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f8234d);
            if (this.f8301e != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f8301e));
            }
            if (((lpt3) this).f8297a != 0 || ((lpt3) this).f8298b != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(((lpt3) this).f8297a));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(((lpt3) this).f8298b));
            }
            if (((lpt3) this).f8299c != 0 || ((lpt3) this).f8300d != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(((lpt3) this).f8299c));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(((lpt3) this).f8300d));
            }
            if (this.f8302f != 0 || ((lpt3) this).f2508a != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f8302f));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(((lpt3) this).f2508a);
            }
            if (this.f8303g != 0 || ((lpt3) this).f2513b != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f8303g));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(((lpt3) this).f2513b);
            }
        }
        if (((lpt3) this).f2511a.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = ((lpt3) this).f2511a.size();
        for (int i2 = 0; i2 < size; i2++) {
            lpt3.aux auxVar = ((lpt3) this).f2511a.get(i2);
            switch (auxVar.f8304a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case 7:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + auxVar.f8304a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i2);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(auxVar.f2519a);
            if (z2) {
                if (auxVar.f8305b != 0 || auxVar.f8306c != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(auxVar.f8305b));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(auxVar.f8306c));
                }
                if (auxVar.f8307d != 0 || auxVar.f8308e != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(auxVar.f8307d));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(auxVar.f8308e));
                }
            }
        }
    }

    public void z() {
        int size = ((lpt3) this).f2511a.size();
        for (int i2 = 0; i2 < size; i2++) {
            lpt3.aux auxVar = ((lpt3) this).f2511a.get(i2);
            Fragment fragment = auxVar.f2519a;
            if (fragment != null) {
                fragment.setPopDirection(false);
                fragment.setNextTransition(this.f8301e);
                fragment.setSharedElementNames(((lpt3) this).f2514b, ((lpt3) this).f2516c);
            }
            switch (auxVar.f8304a) {
                case 1:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.n1(fragment, false);
                    this.f8233a.g(fragment);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + auxVar.f8304a);
                case 3:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.f1(fragment);
                    break;
                case 4:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.E0(fragment);
                    break;
                case 5:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.n1(fragment, false);
                    this.f8233a.r1(fragment);
                    break;
                case 6:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.y(fragment);
                    break;
                case 7:
                    fragment.setAnimations(auxVar.f8305b, auxVar.f8306c, auxVar.f8307d, auxVar.f8308e);
                    this.f8233a.n1(fragment, false);
                    this.f8233a.m(fragment);
                    break;
                case 8:
                    this.f8233a.p1(fragment);
                    break;
                case 9:
                    this.f8233a.p1(null);
                    break;
                case 10:
                    this.f8233a.o1(fragment, auxVar.f2521b);
                    break;
            }
            if (!((lpt3) this).f2517c && auxVar.f8304a != 1 && fragment != null && !com6.f8252h) {
                this.f8233a.R0(fragment);
            }
        }
        if (((lpt3) this).f2517c || com6.f8252h) {
            return;
        }
        com6 com6Var = this.f8233a;
        com6Var.S0(com6Var.f8253a, true);
    }
}
