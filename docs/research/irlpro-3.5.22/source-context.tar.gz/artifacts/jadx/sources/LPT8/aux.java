package LPT8;

/* JADX INFO: loaded from: classes.dex */
public class aux<S, T> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f6811a;
}
