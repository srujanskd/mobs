package COM6;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

/* JADX INFO: loaded from: classes.dex */
public class com5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f5711a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public long f66a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TimeInterpolator f67a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f5712b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public long f68b;

    public com5(long j2, long j3) {
        this.f67a = null;
        this.f5711a = 0;
        this.f5712b = 1;
        this.f66a = j2;
        this.f68b = j3;
    }

    public static com5 b(ValueAnimator valueAnimator) {
        com5 com5Var = new com5(valueAnimator.getStartDelay(), valueAnimator.getDuration(), f(valueAnimator));
        com5Var.f5711a = valueAnimator.getRepeatCount();
        com5Var.f5712b = valueAnimator.getRepeatMode();
        return com5Var;
    }

    public static TimeInterpolator f(ValueAnimator valueAnimator) {
        TimeInterpolator interpolator = valueAnimator.getInterpolator();
        if ((interpolator instanceof AccelerateDecelerateInterpolator) || interpolator == null) {
            return aux.f5701b;
        }
        if (interpolator instanceof AccelerateInterpolator) {
            return aux.f5702c;
        }
        return interpolator instanceof DecelerateInterpolator ? aux.f5703d : interpolator;
    }

    public void a(Animator animator) {
        animator.setStartDelay(c());
        animator.setDuration(d());
        animator.setInterpolator(e());
        if (animator instanceof ValueAnimator) {
            ValueAnimator valueAnimator = (ValueAnimator) animator;
            valueAnimator.setRepeatCount(g());
            valueAnimator.setRepeatMode(h());
        }
    }

    public long c() {
        return this.f66a;
    }

    public long d() {
        return this.f68b;
    }

    public TimeInterpolator e() {
        TimeInterpolator timeInterpolator = this.f67a;
        return timeInterpolator != null ? timeInterpolator : aux.f5701b;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof com5)) {
            return false;
        }
        com5 com5Var = (com5) obj;
        if (c() == com5Var.c() && d() == com5Var.d() && g() == com5Var.g() && h() == com5Var.h()) {
            return e().getClass().equals(com5Var.e().getClass());
        }
        return false;
    }

    public int g() {
        return this.f5711a;
    }

    public int h() {
        return this.f5712b;
    }

    public int hashCode() {
        return (((((((((int) (c() ^ (c() >>> 32))) * 31) + ((int) (d() ^ (d() >>> 32)))) * 31) + e().getClass().hashCode()) * 31) + g()) * 31) + h();
    }

    public String toString() {
        return '\n' + getClass().getName() + '{' + Integer.toHexString(System.identityHashCode(this)) + " delay: " + c() + " duration: " + d() + " interpolator: " + e().getClass() + " repeatCount: " + g() + " repeatMode: " + h() + "}\n";
    }

    public com5(long j2, long j3, TimeInterpolator timeInterpolator) {
        this.f5711a = 0;
        this.f5712b = 1;
        this.f66a = j2;
        this.f68b = j3;
        this.f67a = timeInterpolator;
    }
}
