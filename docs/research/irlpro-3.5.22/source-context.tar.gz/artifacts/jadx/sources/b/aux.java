package b;

import h.nul;

/* JADX INFO: loaded from: classes.dex */
public class aux extends a.aux {

    /* JADX INFO: renamed from: b.aux$aux, reason: collision with other inner class name */
    public static final class C0051aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final C0051aux f8786a = new C0051aux();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public static final Integer f2987a;

        static {
            Integer num;
            Integer num2 = null;
            try {
                Object obj = Class.forName("android.os.Build$VERSION").getField("SDK_INT").get(null);
                num = obj instanceof Integer ? (Integer) obj : null;
            } catch (Throwable unused) {
            }
            if (num != null) {
                if (num.intValue() > 0) {
                    num2 = num;
                }
            }
            f2987a = num2;
        }
    }

    private final boolean c(int i2) {
        Integer num = C0051aux.f2987a;
        return num == null || num.intValue() >= i2;
    }

    @Override // LPT9.aux
    public nul b() {
        return c(24) ? new i.aux() : super.b();
    }
}
