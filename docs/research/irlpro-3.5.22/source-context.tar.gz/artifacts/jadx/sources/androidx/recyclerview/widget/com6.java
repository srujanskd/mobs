package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import androidx.preference.Preference;

/* JADX INFO: loaded from: classes.dex */
public class com6 extends lpt1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public com5 f8670a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public com5 f8671b;

    public class aux extends com3 {
        public aux(Context context) {
            super(context);
        }

        @Override // androidx.recyclerview.widget.com3, androidx.recyclerview.widget.RecyclerView.d
        public void o(View view, RecyclerView.e eVar, RecyclerView.d.aux auxVar) {
            com6 com6Var = com6.this;
            int[] iArrC = com6Var.c(((lpt1) com6Var).f2879a.getLayoutManager(), view);
            int i2 = iArrC[0];
            int i3 = iArrC[1];
            int iW = w(Math.max(Math.abs(i2), Math.abs(i3)));
            if (iW > 0) {
                auxVar.d(i2, i3, iW, ((com3) this).f2869a);
            }
        }

        @Override // androidx.recyclerview.widget.com3
        public float v(DisplayMetrics displayMetrics) {
            return 100.0f / displayMetrics.densityDpi;
        }

        @Override // androidx.recyclerview.widget.com3
        public int x(int i2) {
            return Math.min(100, super.x(i2));
        }
    }

    @Override // androidx.recyclerview.widget.lpt1
    public int[] c(RecyclerView.lpt2 lpt2Var, View view) {
        int[] iArr = new int[2];
        if (lpt2Var.k()) {
            iArr[0] = l(lpt2Var, view, n(lpt2Var));
        } else {
            iArr[0] = 0;
        }
        if (lpt2Var.l()) {
            iArr[1] = l(lpt2Var, view, p(lpt2Var));
        } else {
            iArr[1] = 0;
        }
        return iArr;
    }

    @Override // androidx.recyclerview.widget.lpt1
    public com3 e(RecyclerView.lpt2 lpt2Var) {
        if (lpt2Var instanceof RecyclerView.d.con) {
            return new aux(((lpt1) this).f2879a.getContext());
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.lpt1
    public View g(RecyclerView.lpt2 lpt2Var) {
        if (lpt2Var.l()) {
            return m(lpt2Var, p(lpt2Var));
        }
        if (lpt2Var.k()) {
            return m(lpt2Var, n(lpt2Var));
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.lpt1
    public int h(RecyclerView.lpt2 lpt2Var, int i2, int i3) {
        com5 com5VarO;
        int iY = lpt2Var.Y();
        if (iY == 0 || (com5VarO = o(lpt2Var)) == null) {
            return -1;
        }
        int iJ = lpt2Var.J();
        View view = null;
        int i4 = Integer.MAX_VALUE;
        int i5 = Integer.MIN_VALUE;
        View view2 = null;
        for (int i6 = 0; i6 < iJ; i6++) {
            View viewI = lpt2Var.I(i6);
            if (viewI != null) {
                int iL = l(lpt2Var, viewI, com5VarO);
                if (iL <= 0 && iL > i5) {
                    view2 = viewI;
                    i5 = iL;
                }
                if (iL >= 0 && iL < i4) {
                    view = viewI;
                    i4 = iL;
                }
            }
        }
        boolean zQ = q(lpt2Var, i2, i3);
        if (zQ && view != null) {
            return lpt2Var.h0(view);
        }
        if (!zQ && view2 != null) {
            return lpt2Var.h0(view2);
        }
        if (zQ) {
            view = view2;
        }
        if (view == null) {
            return -1;
        }
        int iH0 = lpt2Var.h0(view) + (r(lpt2Var) == zQ ? -1 : 1);
        if (iH0 < 0 || iH0 >= iY) {
            return -1;
        }
        return iH0;
    }

    public final int l(RecyclerView.lpt2 lpt2Var, View view, com5 com5Var) {
        return (com5Var.g(view) + (com5Var.e(view) / 2)) - (com5Var.m() + (com5Var.n() / 2));
    }

    public final View m(RecyclerView.lpt2 lpt2Var, com5 com5Var) {
        int iJ = lpt2Var.J();
        View view = null;
        if (iJ == 0) {
            return null;
        }
        int iM = com5Var.m() + (com5Var.n() / 2);
        int i2 = Preference.DEFAULT_ORDER;
        for (int i3 = 0; i3 < iJ; i3++) {
            View viewI = lpt2Var.I(i3);
            int iAbs = Math.abs((com5Var.g(viewI) + (com5Var.e(viewI) / 2)) - iM);
            if (iAbs < i2) {
                view = viewI;
                i2 = iAbs;
            }
        }
        return view;
    }

    public final com5 n(RecyclerView.lpt2 lpt2Var) {
        com5 com5Var = this.f8671b;
        if (com5Var == null || com5Var.f2872a != lpt2Var) {
            this.f8671b = com5.a(lpt2Var);
        }
        return this.f8671b;
    }

    public final com5 o(RecyclerView.lpt2 lpt2Var) {
        if (lpt2Var.l()) {
            return p(lpt2Var);
        }
        if (lpt2Var.k()) {
            return n(lpt2Var);
        }
        return null;
    }

    public final com5 p(RecyclerView.lpt2 lpt2Var) {
        com5 com5Var = this.f8670a;
        if (com5Var == null || com5Var.f2872a != lpt2Var) {
            this.f8670a = com5.c(lpt2Var);
        }
        return this.f8670a;
    }

    public final boolean q(RecyclerView.lpt2 lpt2Var, int i2, int i3) {
        if (lpt2Var.k()) {
            return i2 > 0;
        }
        return i3 > 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final boolean r(RecyclerView.lpt2 lpt2Var) {
        PointF pointFA;
        int iY = lpt2Var.Y();
        if (!(lpt2Var instanceof RecyclerView.d.con) || (pointFA = ((RecyclerView.d.con) lpt2Var).a(iY - 1)) == null) {
            return false;
        }
        return pointFA.x < 0.0f || pointFA.y < 0.0f;
    }
}
