package LPT3;

/* JADX INFO: loaded from: classes.dex */
public final class com5 extends lpt3 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f6624d = {0, 11, 13, 14, 19, 25, 28, 21, 22, 26};
}
