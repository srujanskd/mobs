package androidx.savedstate;

import COM3.com7;
import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.nul;
import androidx.lifecycle.prn;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"RestrictedApi"})
public final class SavedStateRegistry {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Bundle f2923a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Recreator.aux f2924a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f2925a;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CON.con<String, con> f8740a = new CON.con<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f8741b = true;

    public interface aux {
        void a(COM4.con conVar);
    }

    public interface con {
        Bundle a();
    }

    public Bundle a(String str) {
        if (!this.f2925a) {
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
        }
        Bundle bundle = this.f2923a;
        if (bundle == null) {
            return null;
        }
        Bundle bundle2 = bundle.getBundle(str);
        this.f2923a.remove(str);
        if (this.f2923a.isEmpty()) {
            this.f2923a = null;
        }
        return bundle2;
    }

    public void b(nul nulVar, Bundle bundle) {
        if (this.f2925a) {
            throw new IllegalStateException("SavedStateRegistry was already restored.");
        }
        if (bundle != null) {
            this.f2923a = bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
        }
        nulVar.a(new prn() { // from class: androidx.savedstate.SavedStateRegistry.1
            @Override // androidx.lifecycle.prn
            public void f(com7 com7Var, nul.con conVar) {
                if (conVar == nul.con.ON_START) {
                    SavedStateRegistry.this.f8741b = true;
                } else if (conVar == nul.con.ON_STOP) {
                    SavedStateRegistry.this.f8741b = false;
                }
            }
        });
        this.f2925a = true;
    }

    public void c(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = this.f2923a;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        CON.con<String, con>.prn prnVarC = this.f8740a.c();
        while (prnVarC.hasNext()) {
            Map.Entry next = prnVarC.next();
            bundle2.putBundle((String) next.getKey(), ((con) next.getValue()).a());
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public void d(String str, con conVar) {
        if (this.f8740a.f(str, conVar) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
        }
    }

    public void e(Class<? extends aux> cls) {
        if (!this.f8741b) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.f2924a == null) {
            this.f2924a = new Recreator.aux(this);
        }
        try {
            cls.getDeclaredConstructor(new Class[0]);
            this.f2924a.b(cls.getName());
        } catch (NoSuchMethodException e2) {
            throw new IllegalArgumentException("Class" + cls.getSimpleName() + " must have default constructor in order to be automatically recreated", e2);
        }
    }
}
