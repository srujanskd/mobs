package androidx.preference;

import android.content.DialogInterface;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class MultiSelectListPreferenceDialogFragmentCompat extends PreferenceDialogFragmentCompat {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Set<String> f8442a = new HashSet();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence[] f2639a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f8443b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence[] f2640b;

    public class aux implements DialogInterface.OnMultiChoiceClickListener {
        public aux() {
        }

        @Override // android.content.DialogInterface.OnMultiChoiceClickListener
        public void onClick(DialogInterface dialogInterface, int i2, boolean z2) {
            if (z2) {
                MultiSelectListPreferenceDialogFragmentCompat multiSelectListPreferenceDialogFragmentCompat = MultiSelectListPreferenceDialogFragmentCompat.this;
                multiSelectListPreferenceDialogFragmentCompat.f8443b = multiSelectListPreferenceDialogFragmentCompat.f8442a.add(multiSelectListPreferenceDialogFragmentCompat.f2640b[i2].toString()) | multiSelectListPreferenceDialogFragmentCompat.f8443b;
            } else {
                MultiSelectListPreferenceDialogFragmentCompat multiSelectListPreferenceDialogFragmentCompat2 = MultiSelectListPreferenceDialogFragmentCompat.this;
                multiSelectListPreferenceDialogFragmentCompat2.f8443b = multiSelectListPreferenceDialogFragmentCompat2.f8442a.remove(multiSelectListPreferenceDialogFragmentCompat2.f2640b[i2].toString()) | multiSelectListPreferenceDialogFragmentCompat2.f8443b;
            }
        }
    }

    public static MultiSelectListPreferenceDialogFragmentCompat s(String str) {
        MultiSelectListPreferenceDialogFragmentCompat multiSelectListPreferenceDialogFragmentCompat = new MultiSelectListPreferenceDialogFragmentCompat();
        Bundle bundle = new Bundle(1);
        bundle.putString("key", str);
        multiSelectListPreferenceDialogFragmentCompat.setArguments(bundle);
        return multiSelectListPreferenceDialogFragmentCompat;
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void n(boolean z2) {
        if (z2 && this.f8443b) {
            MultiSelectListPreference multiSelectListPreferenceR = r();
            if (multiSelectListPreferenceR.callChangeListener(this.f8442a)) {
                multiSelectListPreferenceR.f(this.f8442a);
            }
        }
        this.f8443b = false;
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat
    public void o(androidx.appcompat.app.aux.C0023aux c0023aux) {
        super.o(c0023aux);
        int length = this.f2640b.length;
        boolean[] zArr = new boolean[length];
        for (int i2 = 0; i2 < length; i2++) {
            zArr[i2] = this.f8442a.contains(this.f2640b[i2].toString());
        }
        c0023aux.i(this.f2639a, zArr, new aux());
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle != null) {
            this.f8442a.clear();
            this.f8442a.addAll(bundle.getStringArrayList("MultiSelectListPreferenceDialogFragmentCompat.values"));
            this.f8443b = bundle.getBoolean("MultiSelectListPreferenceDialogFragmentCompat.changed", false);
            this.f2639a = bundle.getCharSequenceArray("MultiSelectListPreferenceDialogFragmentCompat.entries");
            this.f2640b = bundle.getCharSequenceArray("MultiSelectListPreferenceDialogFragmentCompat.entryValues");
            return;
        }
        MultiSelectListPreference multiSelectListPreferenceR = r();
        if (multiSelectListPreferenceR.a() == null || multiSelectListPreferenceR.b() == null) {
            throw new IllegalStateException("MultiSelectListPreference requires an entries array and an entryValues array.");
        }
        this.f8442a.clear();
        this.f8442a.addAll(multiSelectListPreferenceR.c());
        this.f8443b = false;
        this.f2639a = multiSelectListPreferenceR.a();
        this.f2640b = multiSelectListPreferenceR.b();
    }

    @Override // androidx.preference.PreferenceDialogFragmentCompat, androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putStringArrayList("MultiSelectListPreferenceDialogFragmentCompat.values", new ArrayList<>(this.f8442a));
        bundle.putBoolean("MultiSelectListPreferenceDialogFragmentCompat.changed", this.f8443b);
        bundle.putCharSequenceArray("MultiSelectListPreferenceDialogFragmentCompat.entries", this.f2639a);
        bundle.putCharSequenceArray("MultiSelectListPreferenceDialogFragmentCompat.entryValues", this.f2640b);
    }

    public final MultiSelectListPreference r() {
        return (MultiSelectListPreference) j();
    }
}
