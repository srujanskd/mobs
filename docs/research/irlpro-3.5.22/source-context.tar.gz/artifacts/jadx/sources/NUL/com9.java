package NUL;

import java.util.ArrayList;
import p146nUL.p;
import p146nUL.q;

/* JADX INFO: loaded from: classes.dex */
public class com9 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static int f7380d;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt3 f1365a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7382b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public lpt3 f1368b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7383c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7381a = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1367a = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<lpt3> f1366a = new ArrayList<>();

    public com9(lpt3 lpt3Var, int i2) {
        this.f1365a = null;
        this.f1368b = null;
        int i3 = f7380d;
        this.f7382b = i3;
        f7380d = i3 + 1;
        this.f1365a = lpt3Var;
        this.f1368b = lpt3Var;
        this.f7383c = i2;
    }

    public void a(lpt3 lpt3Var) {
        this.f1366a.add(lpt3Var);
        this.f1368b = lpt3Var;
    }

    public long b(q qVar, int i2) {
        long j2;
        int i3;
        lpt3 lpt3Var = this.f1365a;
        if (lpt3Var instanceof nul) {
            if (((lpt3) ((nul) lpt3Var)).f7408b != i2) {
                return 0L;
            }
        } else if (i2 == 0) {
            if (!(lpt3Var instanceof com8)) {
                return 0L;
            }
        } else if (!(lpt3Var instanceof lpt1)) {
            return 0L;
        }
        com2 com2Var = (i2 == 0 ? ((p) qVar).f4937a : ((p) qVar).f4938a).f1380a;
        com2 com2Var2 = (i2 == 0 ? ((p) qVar).f4937a : ((p) qVar).f4938a).f1387b;
        boolean zContains = lpt3Var.f1380a.f1360b.contains(com2Var);
        boolean zContains2 = this.f1365a.f1387b.f1360b.contains(com2Var2);
        long j3 = this.f1365a.j();
        if (zContains && zContains2) {
            long jD = d(this.f1365a.f1380a, 0L);
            long jC = c(this.f1365a.f1387b, 0L);
            long j4 = jD - j3;
            lpt3 lpt3Var2 = this.f1365a;
            int i4 = lpt3Var2.f1387b.f7364a;
            if (j4 >= (-i4)) {
                j4 += (long) i4;
            }
            int i5 = lpt3Var2.f1380a.f7364a;
            long j5 = ((-jC) - j3) - ((long) i5);
            if (j5 >= i5) {
                j5 -= (long) i5;
            }
            float fO = lpt3Var2.f1385a.o(i2);
            float f2 = fO > 0.0f ? (long) ((j5 / fO) + (j4 / (1.0f - fO))) : 0L;
            long j6 = ((long) ((f2 * fO) + 0.5f)) + j3 + ((long) ((f2 * (1.0f - fO)) + 0.5f));
            lpt3 lpt3Var3 = this.f1365a;
            j2 = ((long) lpt3Var3.f1380a.f7364a) + j6;
            i3 = lpt3Var3.f1387b.f7364a;
        } else {
            if (zContains) {
                com2 com2Var3 = this.f1365a.f1380a;
                return Math.max(d(com2Var3, com2Var3.f7364a), ((long) this.f1365a.f1380a.f7364a) + j3);
            }
            if (zContains2) {
                com2 com2Var4 = this.f1365a.f1387b;
                return Math.max(-c(com2Var4, com2Var4.f7364a), ((long) (-this.f1365a.f1387b.f7364a)) + j3);
            }
            lpt3 lpt3Var4 = this.f1365a;
            j2 = ((long) lpt3Var4.f1380a.f7364a) + lpt3Var4.j();
            i3 = this.f1365a.f1387b.f7364a;
        }
        return j2 - ((long) i3);
    }

    public final long c(com2 com2Var, long j2) {
        lpt3 lpt3Var = com2Var.f1356a;
        if (lpt3Var instanceof com7) {
            return j2;
        }
        int size = com2Var.f1358a.size();
        long jMin = j2;
        for (int i2 = 0; i2 < size; i2++) {
            prn prnVar = com2Var.f1358a.get(i2);
            if (prnVar instanceof com2) {
                com2 com2Var2 = (com2) prnVar;
                if (com2Var2.f1356a != lpt3Var) {
                    jMin = Math.min(jMin, c(com2Var2, ((long) com2Var2.f7364a) + j2));
                }
            }
        }
        if (com2Var != lpt3Var.f1387b) {
            return jMin;
        }
        long j3 = j2 - lpt3Var.j();
        return Math.min(Math.min(jMin, c(lpt3Var.f1380a, j3)), j3 - ((long) lpt3Var.f1380a.f7364a));
    }

    public final long d(com2 com2Var, long j2) {
        lpt3 lpt3Var = com2Var.f1356a;
        if (lpt3Var instanceof com7) {
            return j2;
        }
        int size = com2Var.f1358a.size();
        long jMax = j2;
        for (int i2 = 0; i2 < size; i2++) {
            prn prnVar = com2Var.f1358a.get(i2);
            if (prnVar instanceof com2) {
                com2 com2Var2 = (com2) prnVar;
                if (com2Var2.f1356a != lpt3Var) {
                    jMax = Math.max(jMax, d(com2Var2, ((long) com2Var2.f7364a) + j2));
                }
            }
        }
        if (com2Var != lpt3Var.f1380a) {
            return jMax;
        }
        long j3 = j2 + lpt3Var.j();
        return Math.max(Math.max(jMax, d(lpt3Var.f1387b, j3)), j3 - ((long) lpt3Var.f1387b.f7364a));
    }
}
