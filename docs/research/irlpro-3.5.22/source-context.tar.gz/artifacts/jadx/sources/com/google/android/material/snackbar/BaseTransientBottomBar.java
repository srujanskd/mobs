package com.google.android.material.snackbar;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityManager;
import android.widget.FrameLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.SwipeDismissBehavior;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import java.util.List;
import p024Com2.y;
import p075cOM6.h4;
import p075cOM6.x3;
import p075cOM6.z3;
import p098coM9.b;
import p128lpT1.u;
import p137lpt1.v;

/* JADX INFO: loaded from: classes.dex */
public abstract class BaseTransientBottomBar<B extends BaseTransientBottomBar<B>> {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3581a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ViewGroup f3582a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AccessibilityManager f3583a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Behavior f3584a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt2 f3585a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.snackbar.aux.con f3586a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f3587a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public List<com9<B>> f3588a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final v f3589a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f3590a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f9543b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3591b;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f3592c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f9544d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f9545e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final boolean f9542c = false;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f3580a = {x3.E};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final String f3579a = BaseTransientBottomBar.class.getSimpleName();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Handler f9541a = new Handler(Looper.getMainLooper(), new com4());

    public static class Behavior extends SwipeDismissBehavior<View> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final lpt1 f9546a = new lpt1(this);

        @Override // com.google.android.material.behavior.SwipeDismissBehavior
        public boolean E(View view) {
            return this.f9546a.a(view);
        }

        public final void P(BaseTransientBottomBar<?> baseTransientBottomBar) {
            this.f9546a.c(baseTransientBottomBar);
        }

        @Override // com.google.android.material.behavior.SwipeDismissBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public boolean k(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            this.f9546a.b(coordinatorLayout, view, motionEvent);
            return super.k(coordinatorLayout, view, motionEvent);
        }
    }

    public class aux extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9547a;

        public aux(int i2) {
            this.f9547a = i2;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BaseTransientBottomBar.this.u(this.f9547a);
        }
    }

    public class com1 implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9548a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f9549b;

        public com1(int i2) {
            this.f9549b = i2;
            this.f9548a = i2;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            int iIntValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            if (BaseTransientBottomBar.f9542c) {
                y.Z(BaseTransientBottomBar.this.f3585a, iIntValue - this.f9548a);
            } else {
                BaseTransientBottomBar.this.f3585a.setTranslationY(iIntValue);
            }
            this.f9548a = iIntValue;
        }
    }

    public class com2 extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9550a;

        public com2(int i2) {
            this.f9550a = i2;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BaseTransientBottomBar.this.u(this.f9550a);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BaseTransientBottomBar.this.f3589a.a(0, 180);
        }
    }

    public class com3 implements ValueAnimator.AnimatorUpdateListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9551a = 0;

        public com3() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            int iIntValue = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            if (BaseTransientBottomBar.f9542c) {
                y.Z(BaseTransientBottomBar.this.f3585a, iIntValue - this.f9551a);
            } else {
                BaseTransientBottomBar.this.f3585a.setTranslationY(iIntValue);
            }
            this.f9551a = iIntValue;
        }
    }

    public class com4 implements Handler.Callback {
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            int i2 = message.what;
            if (i2 == 0) {
                ((BaseTransientBottomBar) message.obj).A();
                return true;
            }
            if (i2 != 1) {
                return false;
            }
            ((BaseTransientBottomBar) message.obj).o(message.arg1);
            return true;
        }
    }

    public class com5 implements Runnable {
        public com5() {
        }

        @Override // java.lang.Runnable
        public void run() {
            BaseTransientBottomBar.this.u(3);
        }
    }

    public class com6 implements SwipeDismissBehavior.nul {
        public com6() {
        }

        @Override // com.google.android.material.behavior.SwipeDismissBehavior.nul
        public void a(View view) {
            if (view.getParent() != null) {
                view.setVisibility(8);
            }
            BaseTransientBottomBar.this.i(0);
        }

        @Override // com.google.android.material.behavior.SwipeDismissBehavior.nul
        public void b(int i2) {
            if (i2 == 0) {
                com.google.android.material.snackbar.aux.c().k(BaseTransientBottomBar.this.f3586a);
            } else if (i2 == 1 || i2 == 2) {
                com.google.android.material.snackbar.aux.c().j(BaseTransientBottomBar.this.f3586a);
            }
        }
    }

    public class com7 implements Runnable {
        public com7() {
        }

        @Override // java.lang.Runnable
        public void run() {
            lpt2 lpt2Var = BaseTransientBottomBar.this.f3585a;
            if (lpt2Var == null) {
                return;
            }
            if (lpt2Var.getParent() != null) {
                BaseTransientBottomBar.this.f3585a.setVisibility(0);
            }
            if (BaseTransientBottomBar.this.f3585a.getAnimationMode() == 1) {
                BaseTransientBottomBar.this.C();
            } else {
                BaseTransientBottomBar.this.E();
            }
        }
    }

    public class com8 extends AnimatorListenerAdapter {
        public com8() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BaseTransientBottomBar.this.v();
        }
    }

    public static abstract class com9<B> {
        public void a(B b2, int i2) {
        }

        public void b(B b2) {
        }
    }

    public class con implements ValueAnimator.AnimatorUpdateListener {
        public con() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            BaseTransientBottomBar.this.f3585a.setAlpha(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    public static class lpt1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public com.google.android.material.snackbar.aux.con f9557a;

        public lpt1(SwipeDismissBehavior<?> swipeDismissBehavior) {
            swipeDismissBehavior.L(0.1f);
            swipeDismissBehavior.J(0.6f);
            swipeDismissBehavior.M(0);
        }

        public boolean a(View view) {
            return view instanceof lpt2;
        }

        public void b(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked == 0) {
                if (coordinatorLayout.B(view, (int) motionEvent.getX(), (int) motionEvent.getY())) {
                    com.google.android.material.snackbar.aux.c().j(this.f9557a);
                }
            } else if (actionMasked == 1 || actionMasked == 3) {
                com.google.android.material.snackbar.aux.c().k(this.f9557a);
            }
        }

        public void c(BaseTransientBottomBar<?> baseTransientBottomBar) {
            this.f9557a = baseTransientBottomBar.f3586a;
        }
    }

    public static class lpt2 extends FrameLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final View.OnTouchListener f9558a = new aux();

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final float f3597a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f3598a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ColorStateList f3599a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public PorterDuff.Mode f3600a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Rect f3601a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public BaseTransientBottomBar<?> f3602a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final float f9559b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final int f3603b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f3604b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final int f9560c;

        public class aux implements View.OnTouchListener {
            @Override // android.view.View.OnTouchListener
            @SuppressLint({"ClickableViewAccessibility"})
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return true;
            }
        }

        public lpt2(Context context, AttributeSet attributeSet) {
            super(u.c(context, attributeSet, 0, 0), attributeSet);
            Context context2 = getContext();
            TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(attributeSet, h4.f3133i1);
            int i2 = h4.v2;
            if (typedArrayObtainStyledAttributes.hasValue(i2)) {
                y.w0(this, typedArrayObtainStyledAttributes.getDimensionPixelSize(i2, 0));
            }
            this.f3598a = typedArrayObtainStyledAttributes.getInt(h4.r2, 0);
            this.f3597a = typedArrayObtainStyledAttributes.getFloat(h4.s2, 1.0f);
            setBackgroundTintList(b.b(context2, typedArrayObtainStyledAttributes, h4.t2));
            setBackgroundTintMode(p108com9.v.f(typedArrayObtainStyledAttributes.getInt(h4.u2, -1), PorterDuff.Mode.SRC_IN));
            this.f9559b = typedArrayObtainStyledAttributes.getFloat(h4.q2, 1.0f);
            this.f3603b = typedArrayObtainStyledAttributes.getDimensionPixelSize(h4.p2, -1);
            this.f9560c = typedArrayObtainStyledAttributes.getDimensionPixelSize(h4.w2, -1);
            typedArrayObtainStyledAttributes.recycle();
            setOnTouchListener(f9558a);
            setFocusable(true);
            if (getBackground() == null) {
                y.s0(this, c());
            }
        }

        private void setBaseTransientBottomBar(BaseTransientBottomBar<?> baseTransientBottomBar) {
            this.f3602a = baseTransientBottomBar;
        }

        public void b(ViewGroup viewGroup) {
            this.f3604b = true;
            viewGroup.addView(this);
            this.f3604b = false;
        }

        public final Drawable c() {
            float dimension = getResources().getDimension(z3.V);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(0);
            gradientDrawable.setCornerRadius(dimension);
            gradientDrawable.setColor(p030Com8.prn.i(this, x3.f9038m, x3.f9035j, getBackgroundOverlayColorAlpha()));
            if (this.f3599a == null) {
                return p080cOm1.y.l(gradientDrawable);
            }
            Drawable drawableL = p080cOm1.y.l(gradientDrawable);
            p080cOm1.y.i(drawableL, this.f3599a);
            return drawableL;
        }

        public final void d(ViewGroup.MarginLayoutParams marginLayoutParams) {
            this.f3601a = new Rect(marginLayoutParams.leftMargin, marginLayoutParams.topMargin, marginLayoutParams.rightMargin, marginLayoutParams.bottomMargin);
        }

        public float getActionTextColorAlpha() {
            return this.f9559b;
        }

        public int getAnimationMode() {
            return this.f3598a;
        }

        public float getBackgroundOverlayColorAlpha() {
            return this.f3597a;
        }

        public int getMaxInlineActionWidth() {
            return this.f9560c;
        }

        public int getMaxWidth() {
            return this.f3603b;
        }

        @Override // android.view.ViewGroup, android.view.View
        public void onAttachedToWindow() {
            super.onAttachedToWindow();
            BaseTransientBottomBar<?> baseTransientBottomBar = this.f3602a;
            if (baseTransientBottomBar != null) {
                baseTransientBottomBar.r();
            }
            y.l0(this);
        }

        @Override // android.view.ViewGroup, android.view.View
        public void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            BaseTransientBottomBar<?> baseTransientBottomBar = this.f3602a;
            if (baseTransientBottomBar != null) {
                baseTransientBottomBar.s();
            }
        }

        @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
        public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
            super.onLayout(z2, i2, i3, i4, i5);
            BaseTransientBottomBar<?> baseTransientBottomBar = this.f3602a;
            if (baseTransientBottomBar != null) {
                baseTransientBottomBar.t();
            }
        }

        @Override // android.widget.FrameLayout, android.view.View
        public void onMeasure(int i2, int i3) {
            super.onMeasure(i2, i3);
            if (this.f3603b > 0) {
                int measuredWidth = getMeasuredWidth();
                int i4 = this.f3603b;
                if (measuredWidth > i4) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i4, 1073741824), i3);
                }
            }
        }

        public void setAnimationMode(int i2) {
            this.f3598a = i2;
        }

        @Override // android.view.View
        public void setBackground(Drawable drawable) {
            setBackgroundDrawable(drawable);
        }

        @Override // android.view.View
        public void setBackgroundDrawable(Drawable drawable) {
            if (drawable != null && this.f3599a != null) {
                drawable = p080cOm1.y.l(drawable.mutate());
                p080cOm1.y.i(drawable, this.f3599a);
                p080cOm1.y.j(drawable, this.f3600a);
            }
            super.setBackgroundDrawable(drawable);
        }

        @Override // android.view.View
        public void setBackgroundTintList(ColorStateList colorStateList) {
            this.f3599a = colorStateList;
            if (getBackground() != null) {
                Drawable drawableL = p080cOm1.y.l(getBackground().mutate());
                p080cOm1.y.i(drawableL, colorStateList);
                p080cOm1.y.j(drawableL, this.f3600a);
                if (drawableL != getBackground()) {
                    super.setBackgroundDrawable(drawableL);
                }
            }
        }

        @Override // android.view.View
        public void setBackgroundTintMode(PorterDuff.Mode mode) {
            this.f3600a = mode;
            if (getBackground() != null) {
                Drawable drawableL = p080cOm1.y.l(getBackground().mutate());
                p080cOm1.y.j(drawableL, mode);
                if (drawableL != getBackground()) {
                    super.setBackgroundDrawable(drawableL);
                }
            }
        }

        @Override // android.view.View
        public void setLayoutParams(ViewGroup.LayoutParams layoutParams) {
            super.setLayoutParams(layoutParams);
            if (this.f3604b || !(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
                return;
            }
            d((ViewGroup.MarginLayoutParams) layoutParams);
            BaseTransientBottomBar<?> baseTransientBottomBar = this.f3602a;
            if (baseTransientBottomBar != null) {
                baseTransientBottomBar.G();
            }
        }

        @Override // android.view.View
        public void setOnClickListener(View.OnClickListener onClickListener) {
            setOnTouchListener(onClickListener != null ? null : f9558a);
            super.setOnClickListener(onClickListener);
        }
    }

    public class nul implements ValueAnimator.AnimatorUpdateListener {
        public nul() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
            BaseTransientBottomBar.this.f3585a.setScaleX(fFloatValue);
            BaseTransientBottomBar.this.f3585a.setScaleY(fFloatValue);
        }
    }

    public class prn extends AnimatorListenerAdapter {
        public prn() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BaseTransientBottomBar.this.v();
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BaseTransientBottomBar.this.f3589a.b(70, 180);
        }
    }

    public final void A() {
        if (this.f3585a.getParent() == null) {
            ViewGroup.LayoutParams layoutParams = this.f3585a.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.com2) {
                x((CoordinatorLayout.com2) layoutParams);
            }
            this.f3585a.b(this.f3582a);
            w();
            this.f3585a.setVisibility(4);
        }
        if (y.S(this.f3585a)) {
            B();
        } else {
            this.f3591b = true;
        }
    }

    public final void B() {
        if (y()) {
            f();
            return;
        }
        if (this.f3585a.getParent() != null) {
            this.f3585a.setVisibility(0);
        }
        v();
    }

    public final void C() {
        ValueAnimator valueAnimatorJ = j(0.0f, 1.0f);
        ValueAnimator valueAnimatorM = m(0.8f, 1.0f);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(valueAnimatorJ, valueAnimatorM);
        animatorSet.setDuration(150L);
        animatorSet.addListener(new com8());
        animatorSet.start();
    }

    public final void D(int i2) {
        ValueAnimator valueAnimatorJ = j(1.0f, 0.0f);
        valueAnimatorJ.setDuration(75L);
        valueAnimatorJ.addListener(new aux(i2));
        valueAnimatorJ.start();
    }

    public final void E() {
        int iN = n();
        if (f9542c) {
            y.Z(this.f3585a, iN);
        } else {
            this.f3585a.setTranslationY(iN);
        }
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setIntValues(iN, 0);
        valueAnimator.setInterpolator(COM6.aux.f5701b);
        valueAnimator.setDuration(250L);
        valueAnimator.addListener(new prn());
        valueAnimator.addUpdateListener(new com1(iN));
        valueAnimator.start();
    }

    public final void F(int i2) {
        ValueAnimator valueAnimator = new ValueAnimator();
        valueAnimator.setIntValues(0, n());
        valueAnimator.setInterpolator(COM6.aux.f5701b);
        valueAnimator.setDuration(250L);
        valueAnimator.addListener(new com2(i2));
        valueAnimator.addUpdateListener(new com3());
        valueAnimator.start();
    }

    public final void G() {
        ViewGroup.LayoutParams layoutParams = this.f3585a.getLayoutParams();
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams) || this.f3585a.f3601a == null) {
            Log.w(f3579a, "Unable to update margins because layout params are not MarginLayoutParams");
            return;
        }
        if (this.f3585a.getParent() == null) {
            return;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        marginLayoutParams.bottomMargin = this.f3585a.f3601a.bottom + (k() != null ? this.f9545e : this.f3581a);
        marginLayoutParams.leftMargin = this.f3585a.f3601a.left + this.f9543b;
        marginLayoutParams.rightMargin = this.f3585a.f3601a.right + this.f3592c;
        marginLayoutParams.topMargin = this.f3585a.f3601a.top;
        this.f3585a.requestLayout();
        if (Build.VERSION.SDK_INT < 29 || !z()) {
            return;
        }
        this.f3585a.removeCallbacks(this.f3587a);
        this.f3585a.post(this.f3587a);
    }

    public void f() {
        this.f3585a.post(new com7());
    }

    public final void g(int i2) {
        if (this.f3585a.getAnimationMode() == 1) {
            D(i2);
        } else {
            F(i2);
        }
    }

    public final int h() {
        if (k() == null) {
            return 0;
        }
        int[] iArr = new int[2];
        k().getLocationOnScreen(iArr);
        int i2 = iArr[1];
        int[] iArr2 = new int[2];
        this.f3582a.getLocationOnScreen(iArr2);
        return (iArr2[1] + this.f3582a.getHeight()) - i2;
    }

    public void i(int i2) {
        com.google.android.material.snackbar.aux.c().b(this.f3586a, i2);
    }

    public final ValueAnimator j(float... fArr) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(fArr);
        valueAnimatorOfFloat.setInterpolator(COM6.aux.f5700a);
        valueAnimatorOfFloat.addUpdateListener(new con());
        return valueAnimatorOfFloat;
    }

    public View k() {
        return null;
    }

    public SwipeDismissBehavior<? extends View> l() {
        return new Behavior();
    }

    public final ValueAnimator m(float... fArr) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(fArr);
        valueAnimatorOfFloat.setInterpolator(COM6.aux.f5703d);
        valueAnimatorOfFloat.addUpdateListener(new nul());
        return valueAnimatorOfFloat;
    }

    public final int n() {
        int height = this.f3585a.getHeight();
        ViewGroup.LayoutParams layoutParams = this.f3585a.getLayoutParams();
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? height + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin : height;
    }

    public final void o(int i2) {
        if (y() && this.f3585a.getVisibility() == 0) {
            g(i2);
        } else {
            u(i2);
        }
    }

    public boolean p() {
        return com.google.android.material.snackbar.aux.c().e(this.f3586a);
    }

    public final boolean q() {
        ViewGroup.LayoutParams layoutParams = this.f3585a.getLayoutParams();
        return (layoutParams instanceof CoordinatorLayout.com2) && (((CoordinatorLayout.com2) layoutParams).f() instanceof SwipeDismissBehavior);
    }

    public void r() {
        WindowInsets rootWindowInsets;
        if (Build.VERSION.SDK_INT < 29 || (rootWindowInsets = this.f3585a.getRootWindowInsets()) == null) {
            return;
        }
        this.f9544d = rootWindowInsets.getMandatorySystemGestureInsets().bottom;
        G();
    }

    public void s() {
        if (p()) {
            f9541a.post(new com5());
        }
    }

    public void t() {
        if (this.f3591b) {
            B();
            this.f3591b = false;
        }
    }

    public void u(int i2) {
        com.google.android.material.snackbar.aux.c().h(this.f3586a);
        List<com9<B>> list = this.f3588a;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f3588a.get(size).a(this, i2);
            }
        }
        ViewParent parent = this.f3585a.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(this.f3585a);
        }
    }

    public void v() {
        com.google.android.material.snackbar.aux.c().i(this.f3586a);
        List<com9<B>> list = this.f3588a;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f3588a.get(size).b(this);
            }
        }
    }

    public final void w() {
        this.f9545e = h();
        G();
    }

    public final void x(CoordinatorLayout.com2 com2Var) {
        SwipeDismissBehavior<? extends View> swipeDismissBehaviorL = this.f3584a;
        if (swipeDismissBehaviorL == null) {
            swipeDismissBehaviorL = l();
        }
        if (swipeDismissBehaviorL instanceof Behavior) {
            ((Behavior) swipeDismissBehaviorL).P(this);
        }
        swipeDismissBehaviorL.K(new com6());
        com2Var.o(swipeDismissBehaviorL);
        if (k() == null) {
            com2Var.f8162e = 80;
        }
    }

    public boolean y() {
        AccessibilityManager accessibilityManager = this.f3583a;
        if (accessibilityManager == null) {
            return true;
        }
        List<AccessibilityServiceInfo> enabledAccessibilityServiceList = accessibilityManager.getEnabledAccessibilityServiceList(1);
        return enabledAccessibilityServiceList != null && enabledAccessibilityServiceList.isEmpty();
    }

    public final boolean z() {
        return this.f9544d > 0 && !this.f3590a && q();
    }
}
