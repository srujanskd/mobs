package NUL;

import p146nUL.o;
import p146nUL.p;
import p146nUL.s;

/* JADX INFO: loaded from: classes.dex */
public class com8 extends lpt3 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int[] f7378a = new int[2];

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f7379a;

        static {
            int[] iArr = new int[lpt3.con.values().length];
            f7379a = iArr;
            try {
                iArr[lpt3.con.START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f7379a[lpt3.con.END.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f7379a[lpt3.con.CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public com8(p pVar) {
        super(pVar);
        ((lpt3) this).f1380a.f1354a = com2.aux.LEFT;
        ((lpt3) this).f1387b.f1354a = com2.aux.RIGHT;
        ((lpt3) this).f7408b = 0;
    }

    /* JADX WARN: Code duplicated, block: B:125:0x02de  */
    /* JADX WARN: Code duplicated, block: B:127:0x02ed  */
    @Override // NUL.lpt3, NUL.prn
    public void a(prn prnVar) {
        int iG;
        int i2;
        int iG2;
        float f2;
        float fT;
        float fT2;
        int i3;
        int i4 = aux.f7379a[((lpt3) this).f1383a.ordinal()];
        if (i4 == 1) {
            p(prnVar);
        } else if (i4 == 2) {
            o(prnVar);
        } else if (i4 == 3) {
            p pVar = ((lpt3) this).f1385a;
            n(prnVar, pVar.f4944a, pVar.f4965c, 0);
            return;
        }
        if (!((com2) ((lpt3) this).f1381a).f1362c && ((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT) {
            p pVar2 = ((lpt3) this).f1385a;
            int i5 = pVar2.f4974f;
            if (i5 == 2) {
                p pVarI = pVar2.I();
                if (pVarI != null) {
                    com3 com3Var = ((lpt3) pVarI.f4937a).f1381a;
                    if (((com2) com3Var).f1362c) {
                        ((lpt3) this).f1381a.d((int) ((((com2) com3Var).f7365b * ((lpt3) this).f1385a.f11496a) + 0.5f));
                    }
                }
            } else if (i5 == 3) {
                int i6 = pVar2.f4977g;
                if (i6 == 0 || i6 == 3) {
                    lpt1 lpt1Var = pVar2.f4938a;
                    com2 com2Var = ((lpt3) lpt1Var).f1380a;
                    com2 com2Var2 = ((lpt3) lpt1Var).f1387b;
                    boolean z2 = pVar2.f4944a.f4932a != null;
                    boolean z3 = pVar2.f4957b.f4932a != null;
                    boolean z4 = pVar2.f4965c.f4932a != null;
                    boolean z5 = pVar2.f4969d.f4932a != null;
                    int iU = pVar2.u();
                    if (z2 && z3 && z4 && z5) {
                        float fT3 = ((lpt3) this).f1385a.t();
                        if (com2Var.f1362c && com2Var2.f1362c) {
                            com2 com2Var3 = ((lpt3) this).f1380a;
                            if (com2Var3.f1361b && ((lpt3) this).f1387b.f1361b) {
                                q(f7378a, com2Var3.f1360b.get(0).f7365b + ((lpt3) this).f1380a.f7364a, ((lpt3) this).f1387b.f1360b.get(0).f7365b - ((lpt3) this).f1387b.f7364a, com2Var.f7365b + com2Var.f7364a, com2Var2.f7365b - com2Var2.f7364a, fT3, iU);
                                ((lpt3) this).f1381a.d(f7378a[0]);
                                ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(f7378a[1]);
                                return;
                            }
                            return;
                        }
                        com2 com2Var4 = ((lpt3) this).f1380a;
                        if (com2Var4.f1362c) {
                            com2 com2Var5 = ((lpt3) this).f1387b;
                            if (com2Var5.f1362c) {
                                if (!com2Var.f1361b || !com2Var2.f1361b) {
                                    return;
                                }
                                q(f7378a, com2Var4.f7365b + com2Var4.f7364a, com2Var5.f7365b - com2Var5.f7364a, com2Var.f1360b.get(0).f7365b + com2Var.f7364a, com2Var2.f1360b.get(0).f7365b - com2Var2.f7364a, fT3, iU);
                                ((lpt3) this).f1381a.d(f7378a[0]);
                                ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(f7378a[1]);
                            }
                        }
                        com2 com2Var6 = ((lpt3) this).f1380a;
                        if (!com2Var6.f1361b || !((lpt3) this).f1387b.f1361b || !com2Var.f1361b || !com2Var2.f1361b) {
                            return;
                        }
                        q(f7378a, com2Var6.f1360b.get(0).f7365b + ((lpt3) this).f1380a.f7364a, ((lpt3) this).f1387b.f1360b.get(0).f7365b - ((lpt3) this).f1387b.f7364a, com2Var.f1360b.get(0).f7365b + com2Var.f7364a, com2Var2.f1360b.get(0).f7365b - com2Var2.f7364a, fT3, iU);
                        ((lpt3) this).f1381a.d(f7378a[0]);
                        ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(f7378a[1]);
                    } else if (z2 && z4) {
                        if (!((lpt3) this).f1380a.f1361b || !((lpt3) this).f1387b.f1361b) {
                            return;
                        }
                        float fT4 = ((lpt3) this).f1385a.t();
                        int i7 = ((lpt3) this).f1380a.f1360b.get(0).f7365b + ((lpt3) this).f1380a.f7364a;
                        int i8 = ((lpt3) this).f1387b.f1360b.get(0).f7365b - ((lpt3) this).f1387b.f7364a;
                        if (iU == -1 || iU == 0) {
                            int iG3 = g(i8 - i7, 0);
                            int i9 = (int) ((iG3 * fT4) + 0.5f);
                            int iG4 = g(i9, 1);
                            if (i9 != iG4) {
                                iG3 = (int) ((iG4 / fT4) + 0.5f);
                            }
                            ((lpt3) this).f1381a.d(iG3);
                            ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(iG4);
                        } else if (iU == 1) {
                            int iG5 = g(i8 - i7, 0);
                            int i10 = (int) ((iG5 / fT4) + 0.5f);
                            int iG6 = g(i10, 1);
                            if (i10 != iG6) {
                                iG5 = (int) ((iG6 * fT4) + 0.5f);
                            }
                            ((lpt3) this).f1381a.d(iG5);
                            ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(iG6);
                        }
                    } else if (z3 && z5) {
                        if (!com2Var.f1361b || !com2Var2.f1361b) {
                            return;
                        }
                        float fT5 = ((lpt3) this).f1385a.t();
                        int i11 = com2Var.f1360b.get(0).f7365b + com2Var.f7364a;
                        int i12 = com2Var2.f1360b.get(0).f7365b - com2Var2.f7364a;
                        if (iU == -1) {
                            iG = g(i12 - i11, 1);
                            i2 = (int) ((iG / fT5) + 0.5f);
                            iG2 = g(i2, 0);
                            if (i2 != iG2) {
                                iG = (int) ((iG2 * fT5) + 0.5f);
                            }
                            ((lpt3) this).f1381a.d(iG2);
                            ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(iG);
                        } else if (iU == 0) {
                            int iG7 = g(i12 - i11, 1);
                            int i13 = (int) ((iG7 * fT5) + 0.5f);
                            int iG8 = g(i13, 0);
                            if (i13 != iG8) {
                                iG7 = (int) ((iG8 / fT5) + 0.5f);
                            }
                            ((lpt3) this).f1381a.d(iG8);
                            ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(iG7);
                        } else if (iU == 1) {
                            iG = g(i12 - i11, 1);
                            i2 = (int) ((iG / fT5) + 0.5f);
                            iG2 = g(i2, 0);
                            if (i2 != iG2) {
                                iG = (int) ((iG2 * fT5) + 0.5f);
                            }
                            ((lpt3) this).f1381a.d(iG2);
                            ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a.d(iG);
                        }
                    }
                } else {
                    int iU2 = pVar2.u();
                    if (iU2 != -1) {
                        if (iU2 == 0) {
                            p pVar3 = ((lpt3) this).f1385a;
                            fT2 = ((com2) ((lpt3) pVar3.f4938a).f1381a).f7365b / pVar3.t();
                            i3 = (int) (fT2 + 0.5f);
                        } else if (iU2 != 1) {
                            i3 = 0;
                        } else {
                            p pVar4 = ((lpt3) this).f1385a;
                            f2 = ((com2) ((lpt3) pVar4.f4938a).f1381a).f7365b;
                            fT = pVar4.t();
                        }
                        ((lpt3) this).f1381a.d(i3);
                    } else {
                        p pVar5 = ((lpt3) this).f1385a;
                        f2 = ((com2) ((lpt3) pVar5.f4938a).f1381a).f7365b;
                        fT = pVar5.t();
                    }
                    fT2 = f2 * fT;
                    i3 = (int) (fT2 + 0.5f);
                    ((lpt3) this).f1381a.d(i3);
                }
            }
        }
        com2 com2Var7 = ((lpt3) this).f1380a;
        if (com2Var7.f1361b) {
            com2 com2Var8 = ((lpt3) this).f1387b;
            if (com2Var8.f1361b) {
                if (com2Var7.f1362c && com2Var8.f1362c && ((com2) ((lpt3) this).f1381a).f1362c) {
                    return;
                }
                if (!((com2) ((lpt3) this).f1381a).f1362c && ((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT) {
                    p pVar6 = ((lpt3) this).f1385a;
                    if (pVar6.f4974f == 0 && !pVar6.g0()) {
                        com2 com2Var9 = ((lpt3) this).f1380a.f1360b.get(0);
                        com2 com2Var10 = ((lpt3) this).f1387b.f1360b.get(0);
                        int i14 = com2Var9.f7365b;
                        com2 com2Var11 = ((lpt3) this).f1380a;
                        int i15 = i14 + com2Var11.f7364a;
                        int i16 = com2Var10.f7365b + ((lpt3) this).f1387b.f7364a;
                        com2Var11.d(i15);
                        ((lpt3) this).f1387b.d(i16);
                        ((lpt3) this).f1381a.d(i16 - i15);
                        return;
                    }
                }
                if (!((com2) ((lpt3) this).f1381a).f1362c && ((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT && ((lpt3) this).f7407a == 1 && ((lpt3) this).f1380a.f1360b.size() > 0 && ((lpt3) this).f1387b.f1360b.size() > 0) {
                    int iMin = Math.min((((lpt3) this).f1387b.f1360b.get(0).f7365b + ((lpt3) this).f1387b.f7364a) - (((lpt3) this).f1380a.f1360b.get(0).f7365b + ((lpt3) this).f1380a.f7364a), ((lpt3) this).f1381a.f7375d);
                    p pVar7 = ((lpt3) this).f1385a;
                    int i17 = pVar7.f11503i;
                    int iMax = Math.max(pVar7.f4980h, iMin);
                    if (i17 > 0) {
                        iMax = Math.min(i17, iMax);
                    }
                    ((lpt3) this).f1381a.d(iMax);
                }
                if (((com2) ((lpt3) this).f1381a).f1362c) {
                    com2 com2Var12 = ((lpt3) this).f1380a.f1360b.get(0);
                    com2 com2Var13 = ((lpt3) this).f1387b.f1360b.get(0);
                    int i18 = com2Var12.f7365b + ((lpt3) this).f1380a.f7364a;
                    int i19 = com2Var13.f7365b + ((lpt3) this).f1387b.f7364a;
                    float fW = ((lpt3) this).f1385a.w();
                    if (com2Var12 == com2Var13) {
                        i18 = com2Var12.f7365b;
                        i19 = com2Var13.f7365b;
                        fW = 0.5f;
                    }
                    ((lpt3) this).f1380a.d((int) (i18 + 0.5f + (((i19 - i18) - ((com2) ((lpt3) this).f1381a).f7365b) * fW)));
                    ((lpt3) this).f1387b.d(((lpt3) this).f1380a.f7365b + ((com2) ((lpt3) this).f1381a).f7365b);
                }
            }
        }
    }

    @Override // NUL.lpt3
    public void d() {
        p pVarI;
        p pVarI2;
        p pVar = ((lpt3) this).f1385a;
        if (pVar.f4946a) {
            ((lpt3) this).f1381a.d(pVar.U());
        }
        if (((com2) ((lpt3) this).f1381a).f1362c) {
            p.con conVar = ((lpt3) this).f1384a;
            p.con conVar2 = p.con.MATCH_PARENT;
            if (conVar == conVar2 && (pVarI = ((lpt3) this).f1385a.I()) != null && (pVarI.y() == p.con.FIXED || pVarI.y() == conVar2)) {
                b(((lpt3) this).f1380a, ((lpt3) pVarI.f4937a).f1380a, ((lpt3) this).f1385a.f4944a.e());
                b(((lpt3) this).f1387b, ((lpt3) pVarI.f4937a).f1387b, -((lpt3) this).f1385a.f4965c.e());
                return;
            }
        } else {
            p.con conVarY = ((lpt3) this).f1385a.y();
            ((lpt3) this).f1384a = conVarY;
            if (conVarY != p.con.MATCH_CONSTRAINT) {
                p.con conVar3 = p.con.MATCH_PARENT;
                if (conVarY == conVar3 && (pVarI2 = ((lpt3) this).f1385a.I()) != null && (pVarI2.y() == p.con.FIXED || pVarI2.y() == conVar3)) {
                    int iU = (pVarI2.U() - ((lpt3) this).f1385a.f4944a.e()) - ((lpt3) this).f1385a.f4965c.e();
                    b(((lpt3) this).f1380a, ((lpt3) pVarI2.f4937a).f1380a, ((lpt3) this).f1385a.f4944a.e());
                    b(((lpt3) this).f1387b, ((lpt3) pVarI2.f4937a).f1387b, -((lpt3) this).f1385a.f4965c.e());
                    ((lpt3) this).f1381a.d(iU);
                    return;
                }
                if (((lpt3) this).f1384a == p.con.FIXED) {
                    ((lpt3) this).f1381a.d(((lpt3) this).f1385a.U());
                }
            }
        }
        com3 com3Var = ((lpt3) this).f1381a;
        if (((com2) com3Var).f1362c) {
            p pVar2 = ((lpt3) this).f1385a;
            if (pVar2.f4946a) {
                o[] oVarArr = pVar2.f4950a;
                o oVar = oVarArr[0];
                o oVar2 = oVar.f4932a;
                if (oVar2 != null && oVarArr[1].f4932a != null) {
                    if (pVar2.g0()) {
                        ((lpt3) this).f1380a.f7364a = ((lpt3) this).f1385a.f4950a[0].e();
                        ((lpt3) this).f1387b.f7364a = -((lpt3) this).f1385a.f4950a[1].e();
                        return;
                    }
                    com2 com2VarH = h(((lpt3) this).f1385a.f4950a[0]);
                    if (com2VarH != null) {
                        b(((lpt3) this).f1380a, com2VarH, ((lpt3) this).f1385a.f4950a[0].e());
                    }
                    com2 com2VarH2 = h(((lpt3) this).f1385a.f4950a[1]);
                    if (com2VarH2 != null) {
                        b(((lpt3) this).f1387b, com2VarH2, -((lpt3) this).f1385a.f4950a[1].e());
                    }
                    ((lpt3) this).f1380a.f1359a = true;
                    ((lpt3) this).f1387b.f1359a = true;
                    return;
                }
                if (oVar2 != null) {
                    com2 com2VarH3 = h(oVar);
                    if (com2VarH3 != null) {
                        b(((lpt3) this).f1380a, com2VarH3, ((lpt3) this).f1385a.f4950a[0].e());
                        b(((lpt3) this).f1387b, ((lpt3) this).f1380a, ((com2) ((lpt3) this).f1381a).f7365b);
                        return;
                    }
                    return;
                }
                o oVar3 = oVarArr[1];
                if (oVar3.f4932a != null) {
                    com2 com2VarH4 = h(oVar3);
                    if (com2VarH4 != null) {
                        b(((lpt3) this).f1387b, com2VarH4, -((lpt3) this).f1385a.f4950a[1].e());
                        b(((lpt3) this).f1380a, ((lpt3) this).f1387b, -((com2) ((lpt3) this).f1381a).f7365b);
                        return;
                    }
                    return;
                }
                if ((pVar2 instanceof s) || pVar2.I() == null || ((lpt3) this).f1385a.m(o.con.CENTER).f4932a != null) {
                    return;
                }
                b(((lpt3) this).f1380a, ((lpt3) ((lpt3) this).f1385a.I().f4937a).f1380a, ((lpt3) this).f1385a.V());
                b(((lpt3) this).f1387b, ((lpt3) this).f1380a, ((com2) ((lpt3) this).f1381a).f7365b);
                return;
            }
        }
        if (((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT) {
            p pVar3 = ((lpt3) this).f1385a;
            int i2 = pVar3.f4974f;
            if (i2 == 2) {
                p pVarI3 = pVar3.I();
                if (pVarI3 != null) {
                    com3 com3Var2 = ((lpt3) pVarI3.f4938a).f1381a;
                    ((com2) ((lpt3) this).f1381a).f1360b.add(com3Var2);
                    ((com2) com3Var2).f1358a.add(((lpt3) this).f1381a);
                    com3 com3Var3 = ((lpt3) this).f1381a;
                    ((com2) com3Var3).f1359a = true;
                    ((com2) com3Var3).f1358a.add(((lpt3) this).f1380a);
                    ((com2) ((lpt3) this).f1381a).f1358a.add(((lpt3) this).f1387b);
                }
            } else if (i2 == 3) {
                if (pVar3.f4977g == 3) {
                    ((lpt3) this).f1380a.f1357a = this;
                    ((lpt3) this).f1387b.f1357a = this;
                    lpt1 lpt1Var = pVar3.f4938a;
                    ((lpt3) lpt1Var).f1380a.f1357a = this;
                    ((lpt3) lpt1Var).f1387b.f1357a = this;
                    ((com2) com3Var).f1357a = this;
                    if (pVar3.i0()) {
                        ((com2) ((lpt3) this).f1381a).f1360b.add(((lpt3) ((lpt3) this).f1385a.f4938a).f1381a);
                        ((com2) ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a).f1358a.add(((lpt3) this).f1381a);
                        lpt1 lpt1Var2 = ((lpt3) this).f1385a.f4938a;
                        ((com2) ((lpt3) lpt1Var2).f1381a).f1357a = this;
                        ((com2) ((lpt3) this).f1381a).f1360b.add(((lpt3) lpt1Var2).f1380a);
                        ((com2) ((lpt3) this).f1381a).f1360b.add(((lpt3) ((lpt3) this).f1385a.f4938a).f1387b);
                        ((lpt3) ((lpt3) this).f1385a.f4938a).f1380a.f1358a.add(((lpt3) this).f1381a);
                        ((lpt3) ((lpt3) this).f1385a.f4938a).f1387b.f1358a.add(((lpt3) this).f1381a);
                    } else if (((lpt3) this).f1385a.g0()) {
                        ((com2) ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a).f1360b.add(((lpt3) this).f1381a);
                        ((com2) ((lpt3) this).f1381a).f1358a.add(((lpt3) ((lpt3) this).f1385a.f4938a).f1381a);
                    } else {
                        ((com2) ((lpt3) ((lpt3) this).f1385a.f4938a).f1381a).f1360b.add(((lpt3) this).f1381a);
                    }
                } else {
                    com3 com3Var4 = ((lpt3) pVar3.f4938a).f1381a;
                    ((com2) com3Var).f1360b.add(com3Var4);
                    ((com2) com3Var4).f1358a.add(((lpt3) this).f1381a);
                    ((lpt3) ((lpt3) this).f1385a.f4938a).f1380a.f1358a.add(((lpt3) this).f1381a);
                    ((lpt3) ((lpt3) this).f1385a.f4938a).f1387b.f1358a.add(((lpt3) this).f1381a);
                    com3 com3Var5 = ((lpt3) this).f1381a;
                    ((com2) com3Var5).f1359a = true;
                    ((com2) com3Var5).f1358a.add(((lpt3) this).f1380a);
                    ((com2) ((lpt3) this).f1381a).f1358a.add(((lpt3) this).f1387b);
                    ((lpt3) this).f1380a.f1360b.add(((lpt3) this).f1381a);
                    ((lpt3) this).f1387b.f1360b.add(((lpt3) this).f1381a);
                }
            }
        }
        p pVar4 = ((lpt3) this).f1385a;
        o[] oVarArr2 = pVar4.f4950a;
        o oVar4 = oVarArr2[0];
        o oVar5 = oVar4.f4932a;
        if (oVar5 != null && oVarArr2[1].f4932a != null) {
            if (pVar4.g0()) {
                ((lpt3) this).f1380a.f7364a = ((lpt3) this).f1385a.f4950a[0].e();
                ((lpt3) this).f1387b.f7364a = -((lpt3) this).f1385a.f4950a[1].e();
                return;
            }
            com2 com2VarH5 = h(((lpt3) this).f1385a.f4950a[0]);
            com2 com2VarH6 = h(((lpt3) this).f1385a.f4950a[1]);
            if (com2VarH5 != null) {
                com2VarH5.b(this);
            }
            if (com2VarH6 != null) {
                com2VarH6.b(this);
            }
            ((lpt3) this).f1383a = lpt3.con.CENTER;
            return;
        }
        if (oVar5 != null) {
            com2 com2VarH7 = h(oVar4);
            if (com2VarH7 != null) {
                b(((lpt3) this).f1380a, com2VarH7, ((lpt3) this).f1385a.f4950a[0].e());
                c(((lpt3) this).f1387b, ((lpt3) this).f1380a, 1, ((lpt3) this).f1381a);
                return;
            }
            return;
        }
        o oVar6 = oVarArr2[1];
        if (oVar6.f4932a != null) {
            com2 com2VarH8 = h(oVar6);
            if (com2VarH8 != null) {
                b(((lpt3) this).f1387b, com2VarH8, -((lpt3) this).f1385a.f4950a[1].e());
                c(((lpt3) this).f1380a, ((lpt3) this).f1387b, -1, ((lpt3) this).f1381a);
                return;
            }
            return;
        }
        if ((pVar4 instanceof s) || pVar4.I() == null) {
            return;
        }
        b(((lpt3) this).f1380a, ((lpt3) ((lpt3) this).f1385a.I().f4937a).f1380a, ((lpt3) this).f1385a.V());
        c(((lpt3) this).f1387b, ((lpt3) this).f1380a, 1, ((lpt3) this).f1381a);
    }

    @Override // NUL.lpt3
    public void e() {
        com2 com2Var = ((lpt3) this).f1380a;
        if (com2Var.f1362c) {
            ((lpt3) this).f1385a.j1(com2Var.f7365b);
        }
    }

    @Override // NUL.lpt3
    public void f() {
        ((lpt3) this).f1382a = null;
        ((lpt3) this).f1380a.c();
        ((lpt3) this).f1387b.c();
        ((lpt3) this).f1381a.c();
        ((lpt3) this).f1386a = false;
    }

    @Override // NUL.lpt3
    public boolean m() {
        return ((lpt3) this).f1384a != p.con.MATCH_CONSTRAINT || ((lpt3) this).f1385a.f4974f == 0;
    }

    public final void q(int[] iArr, int i2, int i3, int i4, int i5, float f2, int i6) {
        int i7 = i3 - i2;
        int i8 = i5 - i4;
        if (i6 != -1) {
            if (i6 == 0) {
                iArr[0] = (int) ((i8 * f2) + 0.5f);
                iArr[1] = i8;
                return;
            } else {
                if (i6 != 1) {
                    return;
                }
                iArr[0] = i7;
                iArr[1] = (int) ((i7 * f2) + 0.5f);
                return;
            }
        }
        int i9 = (int) ((i8 * f2) + 0.5f);
        int i10 = (int) ((i7 / f2) + 0.5f);
        if (i9 <= i7) {
            iArr[0] = i9;
            iArr[1] = i8;
        } else if (i10 <= i8) {
            iArr[0] = i7;
            iArr[1] = i10;
        }
    }

    public void r() {
        ((lpt3) this).f1386a = false;
        ((lpt3) this).f1380a.c();
        ((lpt3) this).f1380a.f1362c = false;
        ((lpt3) this).f1387b.c();
        ((lpt3) this).f1387b.f1362c = false;
        ((com2) ((lpt3) this).f1381a).f1362c = false;
    }

    public String toString() {
        return "HorizontalRun " + ((lpt3) this).f1385a.r();
    }
}
