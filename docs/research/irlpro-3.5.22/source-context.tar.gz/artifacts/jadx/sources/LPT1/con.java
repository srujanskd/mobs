package LPT1;

import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
public final class con {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Field f6583a;

    public con(Field field) {
        p052Lpt2.com6.b(field);
        this.f6583a = field;
    }
}
