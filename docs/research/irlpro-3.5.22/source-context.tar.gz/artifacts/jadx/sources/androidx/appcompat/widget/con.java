package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import p001AuX.lpt3;
import p022CoN.q0;
import p022CoN.u0;
import p024Com2.f;
import p024Com2.y;

/* JADX INFO: loaded from: classes.dex */
public class con extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f7993a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2127a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2128a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int[] f2129a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f7994b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2130b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int[] f2131b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f7995c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2132c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7996d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7997e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7998f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7999g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8000h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8001i;

    public static class aux extends LinearLayout.LayoutParams {
        public aux(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public aux(int i2, int i3) {
            super(i2, i3);
        }

        public aux(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public con(Context context) {
        this(context, null);
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof aux;
    }

    public void e(Canvas canvas) {
        int right;
        int left;
        int i2;
        int virtualChildCount = getVirtualChildCount();
        boolean zB = u0.b(this);
        for (int i3 = 0; i3 < virtualChildCount; i3++) {
            View viewQ = q(i3);
            if (viewQ != null && viewQ.getVisibility() != 8 && r(i3)) {
                aux auxVar = (aux) viewQ.getLayoutParams();
                h(canvas, zB ? viewQ.getRight() + ((LinearLayout.LayoutParams) auxVar).rightMargin : (viewQ.getLeft() - ((LinearLayout.LayoutParams) auxVar).leftMargin) - this.f7998f);
            }
        }
        if (r(virtualChildCount)) {
            View viewQ2 = q(virtualChildCount - 1);
            if (viewQ2 != null) {
                aux auxVar2 = (aux) viewQ2.getLayoutParams();
                if (zB) {
                    left = viewQ2.getLeft() - ((LinearLayout.LayoutParams) auxVar2).leftMargin;
                    i2 = this.f7998f;
                    right = left - i2;
                } else {
                    right = viewQ2.getRight() + ((LinearLayout.LayoutParams) auxVar2).rightMargin;
                }
            } else if (zB) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i2 = this.f7998f;
                right = left - i2;
            }
            h(canvas, right);
        }
    }

    public void f(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        for (int i2 = 0; i2 < virtualChildCount; i2++) {
            View viewQ = q(i2);
            if (viewQ != null && viewQ.getVisibility() != 8 && r(i2)) {
                g(canvas, (viewQ.getTop() - ((LinearLayout.LayoutParams) ((aux) viewQ.getLayoutParams())).topMargin) - this.f7999g);
            }
        }
        if (r(virtualChildCount)) {
            View viewQ2 = q(virtualChildCount - 1);
            g(canvas, viewQ2 == null ? (getHeight() - getPaddingBottom()) - this.f7999g : viewQ2.getBottom() + ((LinearLayout.LayoutParams) ((aux) viewQ2.getLayoutParams())).bottomMargin);
        }
    }

    public void g(Canvas canvas, int i2) {
        this.f2128a.setBounds(getPaddingLeft() + this.f8001i, i2, (getWidth() - getPaddingRight()) - this.f8001i, this.f7999g + i2);
        this.f2128a.draw(canvas);
    }

    @Override // android.view.View
    public int getBaseline() {
        int i2;
        if (this.f2127a < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i3 = this.f2127a;
        if (childCount <= i3) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(i3);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.f2127a == 0) {
                return -1;
            }
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
        int bottom = this.f7994b;
        if (this.f7995c == 1 && (i2 = this.f7996d & 112) != 48) {
            if (i2 == 16) {
                bottom += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f7997e) / 2;
            } else if (i2 == 80) {
                bottom = ((getBottom() - getTop()) - getPaddingBottom()) - this.f7997e;
            }
        }
        return bottom + ((LinearLayout.LayoutParams) ((aux) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.f2127a;
    }

    public Drawable getDividerDrawable() {
        return this.f2128a;
    }

    public int getDividerPadding() {
        return this.f8001i;
    }

    public int getDividerWidth() {
        return this.f7998f;
    }

    public int getGravity() {
        return this.f7996d;
    }

    public int getOrientation() {
        return this.f7995c;
    }

    public int getShowDividers() {
        return this.f8000h;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f7993a;
    }

    public void h(Canvas canvas, int i2) {
        this.f2128a.setBounds(i2, getPaddingTop() + this.f8001i, this.f7998f + i2, (getHeight() - getPaddingBottom()) - this.f8001i);
        this.f2128a.draw(canvas);
    }

    public final void i(int i2, int i3) {
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i4 = 0; i4 < i2; i4++) {
            View viewQ = q(i4);
            if (viewQ.getVisibility() != 8) {
                aux auxVar = (aux) viewQ.getLayoutParams();
                if (((LinearLayout.LayoutParams) auxVar).height == -1) {
                    int i5 = ((LinearLayout.LayoutParams) auxVar).width;
                    ((LinearLayout.LayoutParams) auxVar).width = viewQ.getMeasuredWidth();
                    measureChildWithMargins(viewQ, i3, 0, iMakeMeasureSpec, 0);
                    ((LinearLayout.LayoutParams) auxVar).width = i5;
                }
            }
        }
    }

    public final void j(int i2, int i3) {
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i4 = 0; i4 < i2; i4++) {
            View viewQ = q(i4);
            if (viewQ.getVisibility() != 8) {
                aux auxVar = (aux) viewQ.getLayoutParams();
                if (((LinearLayout.LayoutParams) auxVar).width == -1) {
                    int i5 = ((LinearLayout.LayoutParams) auxVar).height;
                    ((LinearLayout.LayoutParams) auxVar).height = viewQ.getMeasuredHeight();
                    measureChildWithMargins(viewQ, iMakeMeasureSpec, 0, i3, 0);
                    ((LinearLayout.LayoutParams) auxVar).height = i5;
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] */
    public aux generateDefaultLayoutParams() {
        int i2 = this.f7995c;
        if (i2 == 0) {
            return new aux(-2, -2);
        }
        if (i2 == 1) {
            return new aux(-1, -2);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: l, reason: merged with bridge method [inline-methods] */
    public aux generateLayoutParams(AttributeSet attributeSet) {
        return new aux(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: m, reason: merged with bridge method [inline-methods] */
    public aux generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new aux(layoutParams);
    }

    public int n(View view, int i2) {
        return 0;
    }

    public int o(View view) {
        return 0;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        if (this.f2128a == null) {
            return;
        }
        if (this.f7995c == 1) {
            f(canvas);
        } else {
            e(canvas);
        }
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.con");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.con");
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        if (this.f7995c == 1) {
            t(i2, i3, i4, i5);
        } else {
            s(i2, i3, i4, i5);
        }
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        if (this.f7995c == 1) {
            x(i2, i3);
        } else {
            v(i2, i3);
        }
    }

    public int p(View view) {
        return 0;
    }

    public View q(int i2) {
        return getChildAt(i2);
    }

    public boolean r(int i2) {
        if (i2 == 0) {
            return (this.f8000h & 1) != 0;
        }
        if (i2 == getChildCount()) {
            return (this.f8000h & 4) != 0;
        }
        if ((this.f8000h & 2) == 0) {
            return false;
        }
        for (int i3 = i2 - 1; i3 >= 0; i3--) {
            if (getChildAt(i3).getVisibility() != 8) {
                return true;
            }
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x00af  */
    /* JADX WARN: Code duplicated, block: B:32:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:34:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:36:0x00c0  */
    /* JADX WARN: Code duplicated, block: B:37:0x00c3  */
    /* JADX WARN: Code duplicated, block: B:39:0x00cb  */
    /* JADX WARN: Code duplicated, block: B:40:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:42:0x00df  */
    /* JADX WARN: Code duplicated, block: B:44:0x00eb  */
    /* JADX WARN: Code duplicated, block: B:47:0x00ff  */
    public void s(int i2, int i3, int i4, int i5) {
        int paddingLeft;
        int i6;
        int i7;
        boolean z2;
        int baseline;
        int i8;
        int i9;
        int measuredHeight;
        boolean zB = u0.b(this);
        int paddingTop = getPaddingTop();
        int i10 = i5 - i3;
        int paddingBottom = i10 - getPaddingBottom();
        int paddingBottom2 = (i10 - paddingTop) - getPaddingBottom();
        int virtualChildCount = getVirtualChildCount();
        int i11 = this.f7996d;
        int i12 = i11 & 112;
        boolean z3 = this.f2130b;
        int[] iArr = this.f2129a;
        int[] iArr2 = this.f2131b;
        int iB = f.b(8388615 & i11, y.A(this));
        boolean z4 = true;
        if (iB != 1) {
            paddingLeft = iB != 5 ? getPaddingLeft() : ((getPaddingLeft() + i4) - i2) - this.f7997e;
        } else {
            paddingLeft = getPaddingLeft() + (((i4 - i2) - this.f7997e) / 2);
        }
        if (zB) {
            i6 = virtualChildCount - 1;
            i7 = -1;
        } else {
            i6 = 0;
            i7 = 1;
        }
        int iN = 0;
        while (iN < virtualChildCount) {
            int i13 = i6 + (i7 * iN);
            View viewQ = q(i13);
            if (viewQ == null) {
                paddingLeft += w(i13);
                z2 = z4;
            } else {
                if (viewQ.getVisibility() != 8) {
                    int measuredWidth = viewQ.getMeasuredWidth();
                    int measuredHeight2 = viewQ.getMeasuredHeight();
                    aux auxVar = (aux) viewQ.getLayoutParams();
                    int i14 = iN;
                    if (z3) {
                        virtualChildCount = virtualChildCount;
                        baseline = ((LinearLayout.LayoutParams) auxVar).height != -1 ? viewQ.getBaseline() : -1;
                        i8 = ((LinearLayout.LayoutParams) auxVar).gravity;
                        if (i8 < 0) {
                            i8 = i12;
                        }
                        i9 = i8 & 112;
                        i12 = i12;
                        if (i9 != 16) {
                            if (i9 != 48) {
                                measuredHeight = ((LinearLayout.LayoutParams) auxVar).topMargin + paddingTop;
                                if (baseline != -1) {
                                    z2 = true;
                                    measuredHeight += iArr[1] - baseline;
                                }
                            } else if (i9 != 80) {
                                measuredHeight = paddingTop;
                            } else {
                                measuredHeight = (paddingBottom - measuredHeight2) - ((LinearLayout.LayoutParams) auxVar).bottomMargin;
                                if (baseline != -1) {
                                    measuredHeight -= iArr2[2] - (viewQ.getMeasuredHeight() - baseline);
                                }
                            }
                            z2 = true;
                        } else {
                            z2 = true;
                            measuredHeight = ((((paddingBottom2 - measuredHeight2) / 2) + paddingTop) + ((LinearLayout.LayoutParams) auxVar).topMargin) - ((LinearLayout.LayoutParams) auxVar).bottomMargin;
                        }
                        if (r(i13)) {
                            paddingLeft += this.f7998f;
                        }
                        int i15 = ((LinearLayout.LayoutParams) auxVar).leftMargin + paddingLeft;
                        paddingTop = paddingTop;
                        y(viewQ, i15 + o(viewQ), measuredHeight, measuredWidth, measuredHeight2);
                        int iP = i15 + measuredWidth + ((LinearLayout.LayoutParams) auxVar).rightMargin + p(viewQ);
                        iN = i14 + n(viewQ, i13);
                        paddingLeft = iP;
                    } else {
                        virtualChildCount = virtualChildCount;
                    }
                    i8 = ((LinearLayout.LayoutParams) auxVar).gravity;
                    if (i8 < 0) {
                        i8 = i12;
                    }
                    i9 = i8 & 112;
                    i12 = i12;
                    if (i9 != 16) {
                        if (i9 != 48) {
                            measuredHeight = ((LinearLayout.LayoutParams) auxVar).topMargin + paddingTop;
                            if (baseline != -1) {
                                z2 = true;
                                measuredHeight += iArr[1] - baseline;
                            }
                        } else if (i9 != 80) {
                            measuredHeight = paddingTop;
                        } else {
                            measuredHeight = (paddingBottom - measuredHeight2) - ((LinearLayout.LayoutParams) auxVar).bottomMargin;
                            if (baseline != -1) {
                                measuredHeight -= iArr2[2] - (viewQ.getMeasuredHeight() - baseline);
                            }
                        }
                        z2 = true;
                    } else {
                        z2 = true;
                        measuredHeight = ((((paddingBottom2 - measuredHeight2) / 2) + paddingTop) + ((LinearLayout.LayoutParams) auxVar).topMargin) - ((LinearLayout.LayoutParams) auxVar).bottomMargin;
                    }
                    if (r(i13)) {
                        paddingLeft += this.f7998f;
                    }
                    int i16 = ((LinearLayout.LayoutParams) auxVar).leftMargin + paddingLeft;
                    paddingTop = paddingTop;
                    y(viewQ, i16 + o(viewQ), measuredHeight, measuredWidth, measuredHeight2);
                    int iP2 = i16 + measuredWidth + ((LinearLayout.LayoutParams) auxVar).rightMargin + p(viewQ);
                    iN = i14 + n(viewQ, i13);
                    paddingLeft = iP2;
                } else {
                    z2 = true;
                }
                iN++;
                virtualChildCount = virtualChildCount;
                i12 = i12;
                z4 = z2;
                paddingTop = paddingTop;
            }
            iN++;
            virtualChildCount = virtualChildCount;
            i12 = i12;
            z4 = z2;
            paddingTop = paddingTop;
        }
    }

    public void setBaselineAligned(boolean z2) {
        this.f2130b = z2;
    }

    public void setBaselineAlignedChildIndex(int i2) {
        if (i2 >= 0 && i2 < getChildCount()) {
            this.f2127a = i2;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.f2128a) {
            return;
        }
        this.f2128a = drawable;
        if (drawable != null) {
            this.f7998f = drawable.getIntrinsicWidth();
            this.f7999g = drawable.getIntrinsicHeight();
        } else {
            this.f7998f = 0;
            this.f7999g = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i2) {
        this.f8001i = i2;
    }

    public void setGravity(int i2) {
        if (this.f7996d != i2) {
            if ((8388615 & i2) == 0) {
                i2 |= 8388611;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.f7996d = i2;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i2) {
        int i3 = i2 & 8388615;
        int i4 = this.f7996d;
        if ((8388615 & i4) != i3) {
            this.f7996d = i3 | ((-8388616) & i4);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z2) {
        this.f2132c = z2;
    }

    public void setOrientation(int i2) {
        if (this.f7995c != i2) {
            this.f7995c = i2;
            requestLayout();
        }
    }

    public void setShowDividers(int i2) {
        if (i2 != this.f8000h) {
            requestLayout();
        }
        this.f8000h = i2;
    }

    public void setVerticalGravity(int i2) {
        int i3 = i2 & 112;
        int i4 = this.f7996d;
        if ((i4 & 112) != i3) {
            this.f7996d = i3 | (i4 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f2) {
        this.f7993a = Math.max(0.0f, f2);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x009f  */
    public void t(int i2, int i3, int i4, int i5) {
        int paddingTop;
        int i6;
        int i7;
        int i8;
        int i9;
        int paddingLeft = getPaddingLeft();
        int i10 = i4 - i2;
        int paddingRight = i10 - getPaddingRight();
        int paddingRight2 = (i10 - paddingLeft) - getPaddingRight();
        int virtualChildCount = getVirtualChildCount();
        int i11 = this.f7996d;
        int i12 = i11 & 112;
        int i13 = i11 & 8388615;
        if (i12 != 16) {
            paddingTop = i12 != 80 ? getPaddingTop() : ((getPaddingTop() + i5) - i3) - this.f7997e;
        } else {
            paddingTop = getPaddingTop() + (((i5 - i3) - this.f7997e) / 2);
        }
        int iN = 0;
        while (iN < virtualChildCount) {
            View viewQ = q(iN);
            if (viewQ == null) {
                paddingTop += w(iN);
            } else {
                if (viewQ.getVisibility() != 8) {
                    int measuredWidth = viewQ.getMeasuredWidth();
                    int measuredHeight = viewQ.getMeasuredHeight();
                    aux auxVar = (aux) viewQ.getLayoutParams();
                    int i14 = ((LinearLayout.LayoutParams) auxVar).gravity;
                    if (i14 < 0) {
                        i14 = i13;
                    }
                    int iB = f.b(i14, y.A(this)) & 7;
                    if (iB != 1) {
                        if (iB != 5) {
                            i8 = ((LinearLayout.LayoutParams) auxVar).leftMargin + paddingLeft;
                        } else {
                            i6 = paddingRight - measuredWidth;
                            i7 = ((LinearLayout.LayoutParams) auxVar).rightMargin;
                        }
                        int i15 = i8;
                        if (r(iN)) {
                            paddingTop += this.f7999g;
                        }
                        int i16 = paddingTop + ((LinearLayout.LayoutParams) auxVar).topMargin;
                        y(viewQ, i15, i16 + o(viewQ), measuredWidth, measuredHeight);
                        int iP = i16 + measuredHeight + ((LinearLayout.LayoutParams) auxVar).bottomMargin + p(viewQ);
                        iN += n(viewQ, iN);
                        paddingTop = iP;
                        i9 = 1;
                    } else {
                        i6 = ((paddingRight2 - measuredWidth) / 2) + paddingLeft + ((LinearLayout.LayoutParams) auxVar).leftMargin;
                        i7 = ((LinearLayout.LayoutParams) auxVar).rightMargin;
                    }
                    i8 = i6 - i7;
                    int i17 = i8;
                    if (r(iN)) {
                        paddingTop += this.f7999g;
                    }
                    int i18 = paddingTop + ((LinearLayout.LayoutParams) auxVar).topMargin;
                    y(viewQ, i17, i18 + o(viewQ), measuredWidth, measuredHeight);
                    int iP2 = i18 + measuredHeight + ((LinearLayout.LayoutParams) auxVar).bottomMargin + p(viewQ);
                    iN += n(viewQ, iN);
                    paddingTop = iP2;
                    i9 = 1;
                }
                iN += i9;
            }
            i9 = 1;
            iN += i9;
        }
    }

    public void u(View view, int i2, int i3, int i4, int i5, int i6) {
        measureChildWithMargins(view, i3, i4, i5, i6);
    }

    /* JADX WARN: Code duplicated, block: B:197:0x0452  */
    /* JADX WARN: Code duplicated, block: B:60:0x0177  */
    /* JADX WARN: Code duplicated, block: B:67:0x0199  */
    /* JADX WARN: Code duplicated, block: B:74:0x01c5  */
    /* JADX WARN: Code duplicated, block: B:77:0x01cd A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:79:0x01d0  */
    /* JADX WARN: Code duplicated, block: B:81:0x01d8  */
    /* JADX WARN: Code duplicated, block: B:84:0x01dd  */
    public void v(int i2, int i3) {
        int[] iArr;
        int i4;
        int iMax;
        int iMax2;
        int i5;
        int i6;
        int baseline;
        int i7;
        int i8;
        byte b2;
        int i9;
        int i10;
        boolean z2;
        boolean z3;
        View view;
        int i11;
        boolean z4;
        int i12;
        int measuredHeight;
        int iN;
        int baseline2;
        int i13;
        this.f7997e = 0;
        int virtualChildCount = getVirtualChildCount();
        int mode = View.MeasureSpec.getMode(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        if (this.f2129a == null || this.f2131b == null) {
            this.f2129a = new int[4];
            this.f2131b = new int[4];
        }
        int[] iArr2 = this.f2129a;
        int[] iArr3 = this.f2131b;
        iArr2[3] = -1;
        iArr2[2] = -1;
        iArr2[1] = -1;
        iArr2[0] = -1;
        iArr3[3] = -1;
        iArr3[2] = -1;
        iArr3[1] = -1;
        iArr3[0] = -1;
        boolean z5 = this.f2130b;
        boolean z6 = this.f2132c;
        int i14 = 1073741824;
        boolean z7 = mode == 1073741824;
        int iN2 = 0;
        int iMax3 = 0;
        int iMax4 = 0;
        int iMax5 = 0;
        int iMax6 = 0;
        boolean z8 = false;
        int iCombineMeasuredStates = 0;
        boolean z9 = false;
        boolean z10 = true;
        float f2 = 0.0f;
        while (true) {
            iArr = iArr3;
            if (iN2 >= virtualChildCount) {
                break;
            }
            View viewQ = q(iN2);
            if (viewQ == null) {
                this.f7997e += w(iN2);
            } else {
                if (viewQ.getVisibility() == 8) {
                    iN2 += n(viewQ, iN2);
                } else {
                    if (r(iN2)) {
                        this.f7997e += this.f7998f;
                    }
                    aux auxVar = (aux) viewQ.getLayoutParams();
                    float f3 = ((LinearLayout.LayoutParams) auxVar).weight;
                    float f4 = f2 + f3;
                    if (mode == i14 && ((LinearLayout.LayoutParams) auxVar).width == 0 && f3 > 0.0f) {
                        if (z7) {
                            this.f7997e += ((LinearLayout.LayoutParams) auxVar).leftMargin + ((LinearLayout.LayoutParams) auxVar).rightMargin;
                        } else {
                            int i15 = this.f7997e;
                            this.f7997e = Math.max(i15, ((LinearLayout.LayoutParams) auxVar).leftMargin + i15 + ((LinearLayout.LayoutParams) auxVar).rightMargin);
                        }
                        if (z5) {
                            int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                            viewQ.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                            i10 = iN2;
                            z2 = z6;
                            z3 = z5;
                            view = viewQ;
                        } else {
                            i10 = iN2;
                            z2 = z6;
                            z3 = z5;
                            view = viewQ;
                            z8 = true;
                            i11 = 1073741824;
                        }
                        if (mode2 == i11 && ((LinearLayout.LayoutParams) auxVar).height == -1) {
                            z4 = true;
                            z9 = true;
                        } else {
                            z4 = false;
                        }
                        i12 = ((LinearLayout.LayoutParams) auxVar).topMargin + ((LinearLayout.LayoutParams) auxVar).bottomMargin;
                        measuredHeight = view.getMeasuredHeight() + i12;
                        iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                        if (z3 && (baseline2 = view.getBaseline()) != -1) {
                            i13 = ((LinearLayout.LayoutParams) auxVar).gravity;
                            if (i13 < 0) {
                                i13 = this.f7996d;
                            }
                            int i16 = (((i13 & 112) >> 4) & (-2)) >> 1;
                            iArr2[i16] = Math.max(iArr2[i16], baseline2);
                            iArr[i16] = Math.max(iArr[i16], measuredHeight - baseline2);
                        }
                        iMax4 = Math.max(iMax4, measuredHeight);
                        if (z10 || ((LinearLayout.LayoutParams) auxVar).height != -1) {
                            z10 = false;
                        } else {
                            z10 = true;
                        }
                        if (((LinearLayout.LayoutParams) auxVar).weight > 0.0f) {
                            if (!z4) {
                                i12 = measuredHeight;
                            }
                            iMax6 = Math.max(iMax6, i12);
                        } else {
                            int i17 = iMax6;
                            if (!z4) {
                                i12 = measuredHeight;
                            }
                            iMax5 = Math.max(iMax5, i12);
                            iMax6 = i17;
                        }
                        int i18 = i10;
                        iN = n(view, i18) + i18;
                        f2 = f4;
                    } else {
                        if (((LinearLayout.LayoutParams) auxVar).width != 0 || f3 <= 0.0f) {
                            b2 = -2;
                            i9 = Integer.MIN_VALUE;
                        } else {
                            b2 = -2;
                            ((LinearLayout.LayoutParams) auxVar).width = -2;
                            i9 = 0;
                        }
                        i10 = iN2;
                        int i19 = i9;
                        z2 = z6;
                        z3 = z5;
                        u(viewQ, i10, i2, f4 == 0.0f ? this.f7997e : 0, i3, 0);
                        if (i19 != Integer.MIN_VALUE) {
                            ((LinearLayout.LayoutParams) auxVar).width = i19;
                        }
                        int measuredWidth = viewQ.getMeasuredWidth();
                        if (z7) {
                            view = viewQ;
                            this.f7997e += ((LinearLayout.LayoutParams) auxVar).leftMargin + measuredWidth + ((LinearLayout.LayoutParams) auxVar).rightMargin + p(view);
                        } else {
                            view = viewQ;
                            int i20 = this.f7997e;
                            this.f7997e = Math.max(i20, i20 + measuredWidth + ((LinearLayout.LayoutParams) auxVar).leftMargin + ((LinearLayout.LayoutParams) auxVar).rightMargin + p(view));
                        }
                        if (z2) {
                            iMax3 = Math.max(measuredWidth, iMax3);
                        }
                    }
                    i11 = 1073741824;
                    if (mode2 == i11) {
                        z4 = false;
                    } else {
                        z4 = false;
                    }
                    i12 = ((LinearLayout.LayoutParams) auxVar).topMargin + ((LinearLayout.LayoutParams) auxVar).bottomMargin;
                    measuredHeight = view.getMeasuredHeight() + i12;
                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                    if (z3) {
                        i13 = ((LinearLayout.LayoutParams) auxVar).gravity;
                        if (i13 < 0) {
                            i13 = this.f7996d;
                        }
                        int i110 = (((i13 & 112) >> 4) & (-2)) >> 1;
                        iArr2[i110] = Math.max(iArr2[i110], baseline2);
                        iArr[i110] = Math.max(iArr[i110], measuredHeight - baseline2);
                    }
                    iMax4 = Math.max(iMax4, measuredHeight);
                    if (z10) {
                        z10 = false;
                    } else {
                        z10 = false;
                    }
                    if (((LinearLayout.LayoutParams) auxVar).weight > 0.0f) {
                        if (!z4) {
                            i12 = measuredHeight;
                        }
                        iMax6 = Math.max(iMax6, i12);
                    } else {
                        int i111 = iMax6;
                        if (!z4) {
                            i12 = measuredHeight;
                        }
                        iMax5 = Math.max(iMax5, i12);
                        iMax6 = i111;
                    }
                    int i112 = i10;
                    iN = n(view, i112) + i112;
                    f2 = f4;
                }
                int i21 = iN + 1;
                iArr3 = iArr;
                z6 = z2;
                z5 = z3;
                i14 = i11;
                iN2 = i21;
            }
            z2 = z6;
            z3 = z5;
            int i22 = i14;
            iN = iN2;
            i11 = i22;
            int i23 = iN + 1;
            iArr3 = iArr;
            z6 = z2;
            z5 = z3;
            i14 = i11;
            iN2 = i23;
        }
        boolean z11 = z6;
        boolean z12 = z5;
        int i24 = iMax4;
        int i25 = iMax5;
        int i26 = iMax6;
        int i27 = iCombineMeasuredStates;
        if (this.f7997e > 0 && r(virtualChildCount)) {
            this.f7997e += this.f7998f;
        }
        int i28 = iArr2[1];
        int iMax7 = (i28 == -1 && iArr2[0] == -1 && iArr2[2] == -1 && iArr2[3] == -1) ? i24 : Math.max(i24, Math.max(iArr2[3], Math.max(iArr2[0], Math.max(i28, iArr2[2]))) + Math.max(iArr[3], Math.max(iArr[0], Math.max(iArr[1], iArr[2]))));
        if (z11 && (mode == Integer.MIN_VALUE || mode == 0)) {
            this.f7997e = 0;
            int iN3 = 0;
            while (iN3 < virtualChildCount) {
                View viewQ2 = q(iN3);
                if (viewQ2 == null) {
                    this.f7997e += w(iN3);
                } else if (viewQ2.getVisibility() == 8) {
                    iN3 += n(viewQ2, iN3);
                } else {
                    aux auxVar2 = (aux) viewQ2.getLayoutParams();
                    if (z7) {
                        this.f7997e += ((LinearLayout.LayoutParams) auxVar2).leftMargin + iMax3 + ((LinearLayout.LayoutParams) auxVar2).rightMargin + p(viewQ2);
                    } else {
                        int i29 = this.f7997e;
                        this.f7997e = Math.max(i29, i29 + iMax3 + ((LinearLayout.LayoutParams) auxVar2).leftMargin + ((LinearLayout.LayoutParams) auxVar2).rightMargin + p(viewQ2));
                    }
                    iN3++;
                    iMax7 = iMax7;
                }
                iN3++;
                iMax7 = iMax7;
            }
        }
        int i30 = iMax7;
        int paddingLeft = this.f7997e + getPaddingLeft() + getPaddingRight();
        this.f7997e = paddingLeft;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingLeft, getSuggestedMinimumWidth()), i2, 0);
        int i31 = (16777215 & iResolveSizeAndState) - this.f7997e;
        if (z8 || (i31 != 0 && f2 > 0.0f)) {
            float f5 = this.f7993a;
            if (f5 > 0.0f) {
                f2 = f5;
            }
            iArr2[3] = -1;
            iArr2[2] = -1;
            iArr2[1] = -1;
            iArr2[0] = -1;
            iArr[3] = -1;
            iArr[2] = -1;
            iArr[1] = -1;
            iArr[0] = -1;
            this.f7997e = 0;
            int i32 = i25;
            int iMax8 = -1;
            int iCombineMeasuredStates2 = i27;
            int i33 = 0;
            while (i33 < virtualChildCount) {
                View viewQ3 = q(i33);
                if (viewQ3 == null || viewQ3.getVisibility() == 8) {
                    i5 = i31;
                    virtualChildCount = virtualChildCount;
                } else {
                    aux auxVar3 = (aux) viewQ3.getLayoutParams();
                    float f6 = ((LinearLayout.LayoutParams) auxVar3).weight;
                    if (f6 > 0.0f) {
                        int i34 = (int) ((i31 * f6) / f2);
                        float f7 = f2 - f6;
                        int i35 = i31 - i34;
                        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i3, getPaddingTop() + getPaddingBottom() + ((LinearLayout.LayoutParams) auxVar3).topMargin + ((LinearLayout.LayoutParams) auxVar3).bottomMargin, ((LinearLayout.LayoutParams) auxVar3).height);
                        if (((LinearLayout.LayoutParams) auxVar3).width == 0) {
                            i8 = 1073741824;
                            if (mode == 1073741824) {
                                if (i34 <= 0) {
                                    i34 = 0;
                                }
                                viewQ3.measure(View.MeasureSpec.makeMeasureSpec(i34, 1073741824), childMeasureSpec);
                            }
                            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, viewQ3.getMeasuredState() & (-16777216));
                            f2 = f7;
                            i5 = i35;
                        } else {
                            i8 = 1073741824;
                        }
                        int measuredWidth2 = viewQ3.getMeasuredWidth() + i34;
                        if (measuredWidth2 < 0) {
                            measuredWidth2 = 0;
                        }
                        viewQ3.measure(View.MeasureSpec.makeMeasureSpec(measuredWidth2, i8), childMeasureSpec);
                        iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, viewQ3.getMeasuredState() & (-16777216));
                        f2 = f7;
                        i5 = i35;
                    } else {
                        i5 = i31;
                    }
                    if (z7) {
                        this.f7997e += viewQ3.getMeasuredWidth() + ((LinearLayout.LayoutParams) auxVar3).leftMargin + ((LinearLayout.LayoutParams) auxVar3).rightMargin + p(viewQ3);
                    } else {
                        int i36 = this.f7997e;
                        this.f7997e = Math.max(i36, viewQ3.getMeasuredWidth() + i36 + ((LinearLayout.LayoutParams) auxVar3).leftMargin + ((LinearLayout.LayoutParams) auxVar3).rightMargin + p(viewQ3));
                    }
                    boolean z13 = mode2 != 1073741824 && ((LinearLayout.LayoutParams) auxVar3).height == -1;
                    int i37 = ((LinearLayout.LayoutParams) auxVar3).topMargin + ((LinearLayout.LayoutParams) auxVar3).bottomMargin;
                    int measuredHeight2 = viewQ3.getMeasuredHeight() + i37;
                    iMax8 = Math.max(iMax8, measuredHeight2);
                    if (!z13) {
                        i37 = measuredHeight2;
                    }
                    int iMax9 = Math.max(i32, i37);
                    if (z10) {
                        i6 = -1;
                        boolean z14 = ((LinearLayout.LayoutParams) auxVar3).height == -1;
                        if (z12 && (baseline = viewQ3.getBaseline()) != i6) {
                            i7 = ((LinearLayout.LayoutParams) auxVar3).gravity;
                            if (i7 < 0) {
                                i7 = this.f7996d;
                            }
                            int i38 = (((i7 & 112) >> 4) & (-2)) >> 1;
                            iArr2[i38] = Math.max(iArr2[i38], baseline);
                            iArr[i38] = Math.max(iArr[i38], measuredHeight2 - baseline);
                        }
                        z10 = z14;
                        i32 = iMax9;
                        f2 = f2;
                    } else {
                        i6 = -1;
                    }
                    if (z12) {
                        i7 = ((LinearLayout.LayoutParams) auxVar3).gravity;
                        if (i7 < 0) {
                            i7 = this.f7996d;
                        }
                        int i39 = (((i7 & 112) >> 4) & (-2)) >> 1;
                        iArr2[i39] = Math.max(iArr2[i39], baseline);
                        iArr[i39] = Math.max(iArr[i39], measuredHeight2 - baseline);
                    }
                    z10 = z14;
                    i32 = iMax9;
                    f2 = f2;
                }
                i33++;
                i31 = i5;
                virtualChildCount = virtualChildCount;
            }
            i4 = virtualChildCount;
            this.f7997e += getPaddingLeft() + getPaddingRight();
            int i40 = iArr2[1];
            iMax = (i40 == -1 && iArr2[0] == -1 && iArr2[2] == -1 && iArr2[3] == -1) ? iMax8 : Math.max(iMax8, Math.max(iArr2[3], Math.max(iArr2[0], Math.max(i40, iArr2[2]))) + Math.max(iArr[3], Math.max(iArr[0], Math.max(iArr[1], iArr[2]))));
            iMax2 = i32;
            i27 = iCombineMeasuredStates2;
        } else {
            iMax2 = Math.max(i25, i26);
            if (z11 && mode != 1073741824) {
                for (int i41 = 0; i41 < virtualChildCount; i41++) {
                    View viewQ4 = q(i41);
                    if (viewQ4 != null && viewQ4.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((aux) viewQ4.getLayoutParams())).weight > 0.0f) {
                        viewQ4.measure(View.MeasureSpec.makeMeasureSpec(iMax3, 1073741824), View.MeasureSpec.makeMeasureSpec(viewQ4.getMeasuredHeight(), 1073741824));
                    }
                }
            }
            i4 = virtualChildCount;
            iMax = i30;
        }
        if (z10 || mode2 == 1073741824) {
            iMax2 = iMax;
        }
        setMeasuredDimension(iResolveSizeAndState | (i27 & (-16777216)), View.resolveSizeAndState(Math.max(iMax2 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i3, i27 << 16));
        if (z9) {
            i(i4, i2);
        }
    }

    public int w(int i2) {
        return 0;
    }

    /* JADX WARN: Code duplicated, block: B:150:0x0325  */
    /* JADX WARN: Code duplicated, block: B:156:0x0333  */
    public void x(int i2, int i3) {
        int i4;
        int iCombineMeasuredStates;
        int iMax;
        int i5;
        int i6;
        int i7;
        boolean z2;
        boolean z3;
        int i8;
        int i9;
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        View view;
        int iMax2;
        boolean z4;
        int iMax3;
        this.f7997e = 0;
        int virtualChildCount = getVirtualChildCount();
        int mode = View.MeasureSpec.getMode(i2);
        int mode2 = View.MeasureSpec.getMode(i3);
        int i17 = this.f2127a;
        boolean z5 = this.f2132c;
        int i18 = 0;
        int i19 = 0;
        int i20 = 0;
        int iMax4 = 0;
        int i21 = 0;
        int iN = 0;
        boolean z6 = false;
        boolean z7 = false;
        boolean z8 = true;
        float f2 = 0.0f;
        while (true) {
            int i22 = 8;
            int i23 = iMax4;
            if (iN >= virtualChildCount) {
                int i24 = i18;
                int i25 = i20;
                int i26 = i21;
                int i27 = virtualChildCount;
                int i28 = mode2;
                int iMax5 = i19;
                if (this.f7997e > 0) {
                    i4 = i27;
                    if (r(i4)) {
                        this.f7997e += this.f7999g;
                    }
                } else {
                    i4 = i27;
                }
                if (z5 && (i28 == Integer.MIN_VALUE || i28 == 0)) {
                    this.f7997e = 0;
                    int iN2 = 0;
                    while (iN2 < i4) {
                        View viewQ = q(iN2);
                        if (viewQ == null) {
                            this.f7997e += w(iN2);
                        } else if (viewQ.getVisibility() == i22) {
                            iN2 += n(viewQ, iN2);
                        } else {
                            aux auxVar = (aux) viewQ.getLayoutParams();
                            int i29 = this.f7997e;
                            this.f7997e = Math.max(i29, i29 + i25 + ((LinearLayout.LayoutParams) auxVar).topMargin + ((LinearLayout.LayoutParams) auxVar).bottomMargin + p(viewQ));
                        }
                        iN2++;
                        i22 = 8;
                    }
                }
                int paddingTop = this.f7997e + getPaddingTop() + getPaddingBottom();
                this.f7997e = paddingTop;
                int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingTop, getSuggestedMinimumHeight()), i3, 0);
                int i30 = (16777215 & iResolveSizeAndState) - this.f7997e;
                if (z6 || (i30 != 0 && f2 > 0.0f)) {
                    float f3 = this.f7993a;
                    if (f3 > 0.0f) {
                        f2 = f3;
                    }
                    this.f7997e = 0;
                    int i31 = i30;
                    int i32 = i26;
                    iCombineMeasuredStates = i24;
                    int i33 = 0;
                    while (i33 < i4) {
                        View viewQ2 = q(i33);
                        if (viewQ2.getVisibility() == 8) {
                            i5 = i31;
                        } else {
                            aux auxVar2 = (aux) viewQ2.getLayoutParams();
                            float f4 = ((LinearLayout.LayoutParams) auxVar2).weight;
                            if (f4 > 0.0f) {
                                int i34 = (int) ((i31 * f4) / f2);
                                float f5 = f2 - f4;
                                i5 = i31 - i34;
                                int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingLeft() + getPaddingRight() + ((LinearLayout.LayoutParams) auxVar2).leftMargin + ((LinearLayout.LayoutParams) auxVar2).rightMargin, ((LinearLayout.LayoutParams) auxVar2).width);
                                if (((LinearLayout.LayoutParams) auxVar2).height == 0) {
                                    i8 = 1073741824;
                                    if (i28 == 1073741824) {
                                        if (i34 <= 0) {
                                            i34 = 0;
                                        }
                                        viewQ2.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(i34, 1073741824));
                                    }
                                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, viewQ2.getMeasuredState() & (-256));
                                    f2 = f5;
                                } else {
                                    i8 = 1073741824;
                                }
                                int measuredHeight = viewQ2.getMeasuredHeight() + i34;
                                if (measuredHeight < 0) {
                                    measuredHeight = 0;
                                }
                                viewQ2.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(measuredHeight, i8));
                                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, viewQ2.getMeasuredState() & (-256));
                                f2 = f5;
                            } else {
                                i5 = i31;
                            }
                            int i35 = ((LinearLayout.LayoutParams) auxVar2).leftMargin + ((LinearLayout.LayoutParams) auxVar2).rightMargin;
                            int measuredWidth = viewQ2.getMeasuredWidth() + i35;
                            iMax5 = Math.max(iMax5, measuredWidth);
                            float f6 = f2;
                            if (mode != 1073741824) {
                                i6 = iCombineMeasuredStates;
                                i7 = -1;
                                z2 = ((LinearLayout.LayoutParams) auxVar2).width == -1;
                                if (!z2) {
                                    i35 = measuredWidth;
                                }
                                int iMax6 = Math.max(i32, i35);
                                if (z8 || ((LinearLayout.LayoutParams) auxVar2).width != i7) {
                                    z3 = false;
                                } else {
                                    z3 = true;
                                }
                                int i36 = this.f7997e;
                                this.f7997e = Math.max(i36, viewQ2.getMeasuredHeight() + i36 + ((LinearLayout.LayoutParams) auxVar2).topMargin + ((LinearLayout.LayoutParams) auxVar2).bottomMargin + p(viewQ2));
                                z8 = z3;
                                iCombineMeasuredStates = i6;
                                i32 = iMax6;
                                f2 = f6;
                            } else {
                                i6 = iCombineMeasuredStates;
                                i7 = -1;
                            }
                            if (!z2) {
                                i35 = measuredWidth;
                            }
                            int iMax7 = Math.max(i32, i35);
                            if (z8) {
                                z3 = false;
                            } else {
                                z3 = false;
                            }
                            int i37 = this.f7997e;
                            this.f7997e = Math.max(i37, viewQ2.getMeasuredHeight() + i37 + ((LinearLayout.LayoutParams) auxVar2).topMargin + ((LinearLayout.LayoutParams) auxVar2).bottomMargin + p(viewQ2));
                            z8 = z3;
                            iCombineMeasuredStates = i6;
                            i32 = iMax7;
                            f2 = f6;
                        }
                        i33++;
                        i31 = i5;
                    }
                    this.f7997e += getPaddingTop() + getPaddingBottom();
                    iMax = i32;
                } else {
                    iMax = Math.max(i26, i23);
                    if (z5 && i28 != 1073741824) {
                        for (int i38 = 0; i38 < i4; i38++) {
                            View viewQ3 = q(i38);
                            if (viewQ3 != null && viewQ3.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((aux) viewQ3.getLayoutParams())).weight > 0.0f) {
                                viewQ3.measure(View.MeasureSpec.makeMeasureSpec(viewQ3.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(i25, 1073741824));
                            }
                        }
                    }
                    iCombineMeasuredStates = i24;
                }
                if (z8 || mode == 1073741824) {
                    iMax = iMax5;
                }
                setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i2, iCombineMeasuredStates), iResolveSizeAndState);
                if (z7) {
                    j(i4, i3);
                    return;
                }
                return;
            }
            View viewQ4 = q(iN);
            if (viewQ4 == null) {
                this.f7997e += w(iN);
                i12 = virtualChildCount;
                i13 = mode2;
                iMax4 = i23;
            } else {
                int i39 = i18;
                if (viewQ4.getVisibility() == 8) {
                    iN += n(viewQ4, iN);
                    i12 = virtualChildCount;
                    iMax4 = i23;
                    i18 = i39;
                    i13 = mode2;
                } else {
                    if (r(iN)) {
                        this.f7997e += this.f7999g;
                    }
                    aux auxVar3 = (aux) viewQ4.getLayoutParams();
                    float f7 = ((LinearLayout.LayoutParams) auxVar3).weight;
                    float f8 = f2 + f7;
                    if (mode2 == 1073741824 && ((LinearLayout.LayoutParams) auxVar3).height == 0 && f7 > 0.0f) {
                        int i40 = this.f7997e;
                        this.f7997e = Math.max(i40, ((LinearLayout.LayoutParams) auxVar3).topMargin + i40 + ((LinearLayout.LayoutParams) auxVar3).bottomMargin);
                        iMax2 = i20;
                        view = viewQ4;
                        i15 = i21;
                        z6 = true;
                        i10 = i39;
                        i11 = i19;
                        i12 = virtualChildCount;
                        i13 = mode2;
                        i14 = i23;
                        i16 = iN;
                    } else {
                        int i41 = i19;
                        if (((LinearLayout.LayoutParams) auxVar3).height != 0 || f7 <= 0.0f) {
                            i9 = Integer.MIN_VALUE;
                        } else {
                            ((LinearLayout.LayoutParams) auxVar3).height = -2;
                            i9 = 0;
                        }
                        i10 = i39;
                        int i42 = i9;
                        i11 = i41;
                        int i43 = i20;
                        i12 = virtualChildCount;
                        i13 = mode2;
                        i14 = i23;
                        i15 = i21;
                        i16 = iN;
                        u(viewQ4, iN, i2, 0, i3, f8 == 0.0f ? this.f7997e : 0);
                        if (i42 != Integer.MIN_VALUE) {
                            ((LinearLayout.LayoutParams) auxVar3).height = i42;
                        }
                        int measuredHeight2 = viewQ4.getMeasuredHeight();
                        int i44 = this.f7997e;
                        view = viewQ4;
                        this.f7997e = Math.max(i44, i44 + measuredHeight2 + ((LinearLayout.LayoutParams) auxVar3).topMargin + ((LinearLayout.LayoutParams) auxVar3).bottomMargin + p(view));
                        iMax2 = z5 ? Math.max(measuredHeight2, i43) : i43;
                    }
                    if (i17 >= 0 && i17 == i16 + 1) {
                        this.f7994b = this.f7997e;
                    }
                    if (i16 < i17 && ((LinearLayout.LayoutParams) auxVar3).weight > 0.0f) {
                        throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                    }
                    if (mode == 1073741824 || ((LinearLayout.LayoutParams) auxVar3).width != -1) {
                        z4 = false;
                    } else {
                        z4 = true;
                        z7 = true;
                    }
                    int i45 = ((LinearLayout.LayoutParams) auxVar3).leftMargin + ((LinearLayout.LayoutParams) auxVar3).rightMargin;
                    int measuredWidth2 = view.getMeasuredWidth() + i45;
                    int iMax8 = Math.max(i11, measuredWidth2);
                    int iCombineMeasuredStates2 = View.combineMeasuredStates(i10, view.getMeasuredState());
                    z8 = z8 && ((LinearLayout.LayoutParams) auxVar3).width == -1;
                    if (((LinearLayout.LayoutParams) auxVar3).weight > 0.0f) {
                        if (!z4) {
                            i45 = measuredWidth2;
                        }
                        iMax4 = Math.max(i14, i45);
                        iMax3 = i15;
                    } else {
                        if (!z4) {
                            i45 = measuredWidth2;
                        }
                        iMax3 = Math.max(i15, i45);
                        iMax4 = i14;
                    }
                    int iN3 = n(view, i16) + i16;
                    i20 = iMax2;
                    f2 = f8;
                    i21 = iMax3;
                    i18 = iCombineMeasuredStates2;
                    iN = iN3;
                    i19 = iMax8;
                }
            }
            iN++;
            mode2 = i13;
            virtualChildCount = i12;
        }
    }

    public final void y(View view, int i2, int i3, int i4, int i5) {
        view.layout(i2, i3, i4 + i2, i5 + i3);
    }

    public con(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public con(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2130b = true;
        this.f2127a = -1;
        this.f7994b = 0;
        this.f7996d = 8388659;
        int[] iArr = lpt3.f30r;
        q0 q0VarV = q0.v(context, attributeSet, iArr, i2, 0);
        y.m0(this, context, iArr, attributeSet, q0VarV.r(), i2, 0);
        int iK = q0VarV.k(lpt3.K0, -1);
        if (iK >= 0) {
            setOrientation(iK);
        }
        int iK2 = q0VarV.k(lpt3.J0, -1);
        if (iK2 >= 0) {
            setGravity(iK2);
        }
        boolean zA = q0VarV.a(lpt3.L0, true);
        if (!zA) {
            setBaselineAligned(zA);
        }
        this.f7993a = q0VarV.i(lpt3.N0, -1.0f);
        this.f2127a = q0VarV.k(lpt3.M0, -1);
        this.f2132c = q0VarV.a(lpt3.Q0, false);
        setDividerDrawable(q0VarV.g(lpt3.O0));
        this.f8000h = q0VarV.k(lpt3.R0, 0);
        this.f8001i = q0VarV.f(lpt3.P0, 0);
        q0VarV.w();
    }
}
