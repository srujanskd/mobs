package com.google.android.material.internal;

import android.R;
import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;
import androidx.appcompat.widget.AppCompatImageButton;
import p001AuX.com3;
import p024Com2.lpt3;
import p024Com2.y;
import p081cOm2.e2;

/* JADX INFO: loaded from: classes.dex */
public class CheckableImageButton extends AppCompatImageButton implements Checkable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int[] f9528a = {R.attr.state_checked};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f9529c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f9530d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9531e;

    public class aux extends lpt3 {
        public aux() {
        }

        @Override // p024Com2.lpt3
        public void f(View view, AccessibilityEvent accessibilityEvent) {
            super.f(view, accessibilityEvent);
            accessibilityEvent.setChecked(CheckableImageButton.this.isChecked());
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.R(CheckableImageButton.this.a());
            e2Var.S(CheckableImageButton.this.isChecked());
        }
    }

    public static class con extends COM2.aux {
        public static final Parcelable.Creator<con> CREATOR = new aux();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9533b;

        public class aux implements Parcelable.ClassLoaderCreator<con> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public con createFromParcel(Parcel parcel) {
                return new con(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public con createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new con(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public con[] newArray(int i2) {
                return new con[i2];
            }
        }

        public con(Parcelable parcelable) {
            super(parcelable);
        }

        public final void m(Parcel parcel) {
            this.f9533b = parcel.readInt() == 1;
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f9533b ? 1 : 0);
        }

        public con(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            m(parcel);
        }
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.C);
    }

    public boolean a() {
        return this.f9530d;
    }

    @Override // android.widget.Checkable
    public boolean isChecked() {
        return this.f9529c;
    }

    @Override // android.widget.ImageView, android.view.View
    public int[] onCreateDrawableState(int i2) {
        if (!this.f9529c) {
            return super.onCreateDrawableState(i2);
        }
        int[] iArr = f9528a;
        return View.mergeDrawableStates(super.onCreateDrawableState(i2 + iArr.length), iArr);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof con)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        con conVar = (con) parcelable;
        super.onRestoreInstanceState(conVar.k());
        setChecked(conVar.f9533b);
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        con conVar = new con(super.onSaveInstanceState());
        conVar.f9533b = this.f9529c;
        return conVar;
    }

    public void setCheckable(boolean z2) {
        if (this.f9530d != z2) {
            this.f9530d = z2;
            sendAccessibilityEvent(0);
        }
    }

    @Override // android.widget.Checkable
    public void setChecked(boolean z2) {
        if (!this.f9530d || this.f9529c == z2) {
            return;
        }
        this.f9529c = z2;
        refreshDrawableState();
        sendAccessibilityEvent(2048);
    }

    public void setPressable(boolean z2) {
        this.f9531e = z2;
    }

    @Override // android.view.View
    public void setPressed(boolean z2) {
        if (this.f9531e) {
            super.setPressed(z2);
        }
    }

    @Override // android.widget.Checkable
    public void toggle() {
        setChecked(!this.f9529c);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f9530d = true;
        this.f9531e = true;
        y.o0(this, new aux());
    }
}
