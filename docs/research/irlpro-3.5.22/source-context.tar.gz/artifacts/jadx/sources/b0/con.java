package b0;

import com.newrelic.agent.android.instrumentation.Instrumented;
import com.newrelic.agent.android.instrumentation.okhttp3.OkHttp3Instrumentation;
import f.com8;
import java.io.IOException;
import java.net.ProtocolException;
import m.lpt1;
import v.a;
import v.e;
import v.f;
import v.g;
import v.h;

/* JADX INFO: loaded from: classes.dex */
@Instrumented
public final class con implements a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f8800a;

    public con(boolean z2) {
        this.f8800a = z2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // v.a
    public g a(a.aux auxVar) throws IOException {
        boolean z2;
        g.aux auxVarP;
        g gVarBuild;
        com8.e(auxVar, "chain");
        com3 com3Var = (com3) auxVar;
        a0.nul nulVarG = com3Var.g();
        com8.b(nulVarG);
        e eVarI = com3Var.i();
        f fVarA = eVarI.a();
        long jCurrentTimeMillis = System.currentTimeMillis();
        nulVarG.t(eVarI);
        if (!com2.a(eVarI.g()) || fVarA == null) {
            nulVarG.n();
            z2 = true;
            auxVarP = null;
        } else {
            if (lpt1.q("100-continue", eVarI.d("Expect"), true)) {
                nulVarG.f();
                auxVarP = nulVarG.p(true);
                nulVarG.r();
                z2 = false;
            } else {
                z2 = true;
                auxVarP = null;
            }
            if (auxVarP != null) {
                nulVarG.n();
                if (!nulVarG.h().v()) {
                    nulVarG.m();
                }
            } else if (fVarA.c()) {
                nulVarG.f();
                fVarA.e(i0.com7.a(nulVarG.c(eVarI, true)));
            } else {
                i0.nul nulVarA = i0.com7.a(nulVarG.c(eVarI, false));
                fVarA.e(nulVarA);
                nulVarA.close();
            }
        }
        if (fVarA == null || !fVarA.c()) {
            nulVarG.e();
        }
        if (auxVarP == null) {
            auxVarP = nulVarG.p(false);
            com8.b(auxVarP);
            if (z2) {
                nulVarG.r();
                z2 = false;
            }
        }
        g gVarBuild2 = auxVarP.request(eVarI).handshake(nulVarG.h().r()).sentRequestAtMillis(jCurrentTimeMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
        int iL = gVarBuild2.l();
        g gVar = gVarBuild2;
        if (iL == 100) {
            g.aux auxVarP2 = nulVarG.p(false);
            com8.b(auxVarP2);
            if (z2) {
                nulVarG.r();
            }
            g gVarBuild3 = auxVarP2.request(eVarI).handshake(nulVarG.h().r()).sentRequestAtMillis(jCurrentTimeMillis).receivedResponseAtMillis(System.currentTimeMillis()).build();
            iL = gVarBuild3.l();
            gVar = gVarBuild3;
        }
        nulVarG.q(gVar);
        if (this.f8800a && iL == 101) {
            g.aux auxVarH = !(gVar instanceof g.aux) ? gVar.H() : OkHttp3Instrumentation.newBuilder((g.aux) gVar);
            h hVar = w.com1.f5456a;
            gVarBuild = (!(auxVarH instanceof g.aux) ? auxVarH.body(hVar) : OkHttp3Instrumentation.body(auxVarH, hVar)).build();
        } else {
            g.aux auxVarH2 = !(gVar instanceof g.aux) ? gVar.H() : OkHttp3Instrumentation.newBuilder((g.aux) gVar);
            h hVarO = nulVarG.o(gVar);
            gVarBuild = (!(auxVarH2 instanceof g.aux) ? auxVarH2.body(hVarO) : OkHttp3Instrumentation.body(auxVarH2, hVarO)).build();
        }
        if (lpt1.q("close", gVarBuild.V().d("Connection"), true) || lpt1.q("close", g.y(gVarBuild, "Connection", null, 2, null), true)) {
            nulVarG.m();
        }
        if (iL == 204 || iL == 205) {
            h hVarA = gVarBuild.a();
            if ((hVarA == null ? -1L : hVarA.contentLength()) > 0) {
                StringBuilder sb = new StringBuilder();
                sb.append("HTTP ");
                sb.append(iL);
                sb.append(" had non-zero Content-Length: ");
                h hVarA2 = gVarBuild.a();
                sb.append(hVarA2 != null ? Long.valueOf(hVarA2.contentLength()) : null);
                throw new ProtocolException(sb.toString());
            }
        }
        return gVarBuild;
    }
}
