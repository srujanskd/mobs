package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.preference.Preference;
import java.util.ArrayList;
import java.util.HashMap;
import p113lPT4.lpt4;
import p146nUL.o;
import p146nUL.p;
import p146nUL.q;
import p146nUL.r;
import p146nUL.u;
import p146nUL.v;
import p151pRn.e0;
import p151pRn.f0;
import p151pRn.h0;
import p151pRn.i0;
import p151pRn.j0;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static i0 f8019a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2161a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public SparseArray<View> f2162a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f2163a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public androidx.constraintlayout.widget.nul f2164a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ArrayList<androidx.constraintlayout.widget.con> f2165a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public HashMap<String, Integer> f2166a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public q f2167a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public e0 f2168a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8020b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public SparseArray<p> f2169b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2170b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f8021c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f8022d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f8023e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f8024f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f8025g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f8026h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f8027i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f8028j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f8029k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f8030l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f8031m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f8032n;

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f8033a;

        static {
            int[] iArr = new int[p.con.values().length];
            f8033a = iArr;
            try {
                iArr[p.con.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f8033a[p.con.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f8033a[p.con.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f8033a[p.con.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    public class nul implements NUL.con.InterfaceC0018con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8061a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public ConstraintLayout f2198a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f8062b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f8063c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f8064d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f8065e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f8066f;

        public nul(ConstraintLayout constraintLayout) {
            this.f2198a = constraintLayout;
        }

        @Override // NUL.con.InterfaceC0018con
        public final void a() {
            int childCount = this.f2198a.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = this.f2198a.getChildAt(i2);
                if (childAt instanceof com1) {
                    ((com1) childAt).a(this.f2198a);
                }
            }
            int size = this.f2198a.f2165a.size();
            if (size > 0) {
                for (int i3 = 0; i3 < size; i3++) {
                    ((androidx.constraintlayout.widget.con) this.f2198a.f2165a.get(i3)).p(this.f2198a);
                }
            }
        }

        @Override // NUL.con.InterfaceC0018con
        @SuppressLint({"WrongCall"})
        public final void b(p pVar, NUL.con.aux auxVar) {
            int iMakeMeasureSpec;
            int iMakeMeasureSpec2;
            int baseline;
            int iMax;
            int iMax2;
            int iMakeMeasureSpec3;
            int i2;
            if (pVar == null) {
                return;
            }
            if (pVar.T() == 8 && !pVar.h0()) {
                auxVar.f7390c = 0;
                auxVar.f7391d = 0;
                auxVar.f7392e = 0;
                return;
            }
            if (pVar.I() == null) {
                return;
            }
            p.con conVar = auxVar.f1371a;
            p.con conVar2 = auxVar.f1373b;
            int i3 = auxVar.f7388a;
            int i4 = auxVar.f7389b;
            int i5 = this.f8061a + this.f8062b;
            int i6 = this.f8063c;
            View view = (View) pVar.q();
            int[] iArr = aux.f8033a;
            int i7 = iArr[conVar.ordinal()];
            if (i7 == 1) {
                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i3, 1073741824);
            } else if (i7 == 2) {
                iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f8065e, i6, -2);
            } else if (i7 == 3) {
                iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f8065e, i6 + pVar.z(), -1);
            } else if (i7 != 4) {
                iMakeMeasureSpec = 0;
            } else {
                iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f8065e, i6, -2);
                boolean z2 = pVar.f4974f == 1;
                int i8 = auxVar.f7393f;
                if (i8 == NUL.con.aux.f7386h || i8 == NUL.con.aux.f7387i) {
                    if (auxVar.f7393f == NUL.con.aux.f7387i || !z2 || (z2 && (view.getMeasuredHeight() == pVar.v())) || (view instanceof com1) || pVar.l0()) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(pVar.U(), 1073741824);
                    }
                }
            }
            int i9 = iArr[conVar2.ordinal()];
            if (i9 == 1) {
                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i4, 1073741824);
            } else if (i9 == 2) {
                iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f8066f, i5, -2);
            } else if (i9 == 3) {
                iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f8066f, i5 + pVar.S(), -1);
            } else if (i9 != 4) {
                iMakeMeasureSpec2 = 0;
            } else {
                iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f8066f, i5, -2);
                boolean z3 = pVar.f4977g == 1;
                int i10 = auxVar.f7393f;
                if (i10 == NUL.con.aux.f7386h || i10 == NUL.con.aux.f7387i) {
                    if (auxVar.f7393f == NUL.con.aux.f7387i || !z3 || (z3 && (view.getMeasuredWidth() == pVar.U())) || (view instanceof com1) || pVar.m0()) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(pVar.v(), 1073741824);
                    }
                }
            }
            q qVar = (q) pVar.I();
            if (qVar != null && u.b(ConstraintLayout.this.f8023e, 256) && view.getMeasuredWidth() == pVar.U() && view.getMeasuredWidth() < qVar.U() && view.getMeasuredHeight() == pVar.v() && view.getMeasuredHeight() < qVar.v() && view.getBaseline() == pVar.n() && !pVar.k0()) {
                if (d(pVar.A(), iMakeMeasureSpec, pVar.U()) && d(pVar.B(), iMakeMeasureSpec2, pVar.v())) {
                    auxVar.f7390c = pVar.U();
                    auxVar.f7391d = pVar.v();
                    auxVar.f7392e = pVar.n();
                    return;
                }
            }
            p.con conVar3 = p.con.MATCH_CONSTRAINT;
            boolean z4 = conVar == conVar3;
            boolean z5 = conVar2 == conVar3;
            p.con conVar4 = p.con.MATCH_PARENT;
            boolean z6 = conVar2 == conVar4 || conVar2 == p.con.FIXED;
            boolean z7 = conVar == conVar4 || conVar == p.con.FIXED;
            boolean z8 = z4 && pVar.f11500e > 0.0f;
            boolean z9 = z5 && pVar.f11500e > 0.0f;
            if (view == null) {
                return;
            }
            con conVar5 = (con) view.getLayoutParams();
            int i11 = auxVar.f7393f;
            if (i11 != NUL.con.aux.f7386h && i11 != NUL.con.aux.f7387i && z4 && pVar.f4974f == 0 && z5 && pVar.f4977g == 0) {
                i2 = -1;
                iMax2 = 0;
                baseline = 0;
                iMax = 0;
            } else {
                if ((view instanceof j0) && (pVar instanceof v)) {
                    ((j0) view).t((v) pVar, iMakeMeasureSpec, iMakeMeasureSpec2);
                } else {
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                }
                pVar.S0(iMakeMeasureSpec, iMakeMeasureSpec2);
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                baseline = view.getBaseline();
                int i12 = pVar.f4980h;
                iMax = i12 > 0 ? Math.max(i12, measuredWidth) : measuredWidth;
                int i13 = pVar.f11503i;
                if (i13 > 0) {
                    iMax = Math.min(i13, iMax);
                }
                int i14 = pVar.f11504j;
                iMax2 = i14 > 0 ? Math.max(i14, measuredHeight) : measuredHeight;
                int i15 = pVar.f11505k;
                if (i15 > 0) {
                    iMax2 = Math.min(i15, iMax2);
                }
                if (!u.b(ConstraintLayout.this.f8023e, 1)) {
                    if (z8 && z6) {
                        iMax = (int) ((iMax2 * pVar.f11500e) + 0.5f);
                    } else if (z9 && z7) {
                        iMax2 = (int) ((iMax / pVar.f11500e) + 0.5f);
                    }
                }
                if (measuredWidth != iMax || measuredHeight != iMax2) {
                    if (measuredWidth != iMax) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(iMax, 1073741824);
                    }
                    if (measuredHeight != iMax2) {
                        iMakeMeasureSpec3 = iMakeMeasureSpec;
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMax2, 1073741824);
                    }
                    iMakeMeasureSpec3 = iMakeMeasureSpec;
                    view.measure(iMakeMeasureSpec3, iMakeMeasureSpec2);
                    pVar.S0(iMakeMeasureSpec3, iMakeMeasureSpec2);
                    iMax = view.getMeasuredWidth();
                    iMax2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                }
                i2 = -1;
            }
            boolean z10 = baseline != i2;
            auxVar.f1374b = (iMax == auxVar.f7388a && iMax2 == auxVar.f7389b) ? false : true;
            if (conVar5.f2189h) {
                z10 = true;
            }
            if (z10 && baseline != -1 && pVar.n() != baseline) {
                auxVar.f1374b = true;
            }
            auxVar.f7390c = iMax;
            auxVar.f7391d = iMax2;
            auxVar.f1372a = z10;
            auxVar.f7392e = baseline;
        }

        public void c(int i2, int i3, int i4, int i5, int i6, int i7) {
            this.f8061a = i4;
            this.f8062b = i5;
            this.f8063c = i6;
            this.f8064d = i7;
            this.f8065e = i2;
            this.f8066f = i3;
        }

        public final boolean d(int i2, int i3, int i4) {
            if (i2 == i3) {
                return true;
            }
            int mode = View.MeasureSpec.getMode(i2);
            View.MeasureSpec.getSize(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            int size = View.MeasureSpec.getSize(i3);
            if (mode2 == 1073741824) {
                return (mode == Integer.MIN_VALUE || mode == 0) && i4 == size;
            }
            return false;
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f2162a = new SparseArray<>();
        this.f2165a = new ArrayList<>(4);
        this.f2167a = new q();
        this.f2161a = 0;
        this.f8020b = 0;
        this.f8021c = Preference.DEFAULT_ORDER;
        this.f8022d = Preference.DEFAULT_ORDER;
        this.f2170b = true;
        this.f8023e = 257;
        this.f2164a = null;
        this.f2168a = null;
        this.f8024f = -1;
        this.f2166a = new HashMap<>();
        this.f8025g = -1;
        this.f8026h = -1;
        this.f8027i = -1;
        this.f8028j = -1;
        this.f8029k = 0;
        this.f8030l = 0;
        this.f2169b = new SparseArray<>();
        this.f2163a = new nul(this);
        this.f8031m = 0;
        this.f8032n = 0;
        q(attributeSet, 0, 0);
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
        int iMax2 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static i0 getSharedValues() {
        if (f8019a == null) {
            f8019a = new i0();
        }
        return f8019a;
    }

    public final boolean A() {
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i2 = 0; i2 < childCount; i2++) {
            if (getChildAt(i2).isLayoutRequested()) {
                z2 = true;
                break;
            }
        }
        if (z2) {
            w();
        }
        return z2;
    }

    public void c(boolean z2, View view, p pVar, con conVar, SparseArray<p> sparseArray) {
        p pVar2;
        p pVar3;
        p pVar4;
        p pVar5;
        int i2;
        conVar.a();
        conVar.f2197m = false;
        pVar.g1(view.getVisibility());
        if (conVar.f2195k) {
            pVar.Q0(true);
            pVar.g1(8);
        }
        pVar.y0(view);
        if (view instanceof androidx.constraintlayout.widget.con) {
            ((androidx.constraintlayout.widget.con) view).n(pVar, this.f2167a.L1());
        }
        if (conVar.f2191i) {
            r rVar = (r) pVar;
            int i3 = conVar.U;
            int i4 = conVar.V;
            float f2 = conVar.f8044k;
            if (f2 != -1.0f) {
                rVar.w1(f2);
                return;
            } else if (i3 != -1) {
                rVar.u1(i3);
                return;
            } else {
                if (i4 != -1) {
                    rVar.v1(i4);
                    return;
                }
                return;
            }
        }
        int i5 = conVar.O;
        int i6 = conVar.P;
        int i7 = conVar.Q;
        int i8 = conVar.R;
        int i9 = conVar.S;
        int i10 = conVar.T;
        float f3 = conVar.f8043j;
        int i11 = conVar.f8047n;
        if (i11 != -1) {
            p pVar6 = sparseArray.get(i11);
            if (pVar6 != null) {
                pVar.j(pVar6, conVar.f8035b, conVar.f8048o);
            }
        } else {
            if (i5 != -1) {
                p pVar7 = sparseArray.get(i5);
                if (pVar7 != null) {
                    o.con conVar2 = o.con.LEFT;
                    pVar.c0(conVar2, pVar7, conVar2, ((ViewGroup.MarginLayoutParams) conVar).leftMargin, i9);
                }
            } else if (i6 != -1 && (pVar2 = sparseArray.get(i6)) != null) {
                pVar.c0(o.con.LEFT, pVar2, o.con.RIGHT, ((ViewGroup.MarginLayoutParams) conVar).leftMargin, i9);
            }
            if (i7 != -1) {
                p pVar8 = sparseArray.get(i7);
                if (pVar8 != null) {
                    pVar.c0(o.con.RIGHT, pVar8, o.con.LEFT, ((ViewGroup.MarginLayoutParams) conVar).rightMargin, i10);
                }
            } else if (i8 != -1 && (pVar3 = sparseArray.get(i8)) != null) {
                o.con conVar3 = o.con.RIGHT;
                pVar.c0(conVar3, pVar3, conVar3, ((ViewGroup.MarginLayoutParams) conVar).rightMargin, i10);
            }
            int i12 = conVar.f2186g;
            if (i12 != -1) {
                p pVar9 = sparseArray.get(i12);
                if (pVar9 != null) {
                    o.con conVar4 = o.con.TOP;
                    pVar.c0(conVar4, pVar9, conVar4, ((ViewGroup.MarginLayoutParams) conVar).topMargin, conVar.f8054u);
                }
            } else {
                int i13 = conVar.f2188h;
                if (i13 != -1 && (pVar4 = sparseArray.get(i13)) != null) {
                    pVar.c0(o.con.TOP, pVar4, o.con.BOTTOM, ((ViewGroup.MarginLayoutParams) conVar).topMargin, conVar.f8054u);
                }
            }
            int i14 = conVar.f2190i;
            if (i14 != -1) {
                p pVar10 = sparseArray.get(i14);
                if (pVar10 != null) {
                    pVar.c0(o.con.BOTTOM, pVar10, o.con.TOP, ((ViewGroup.MarginLayoutParams) conVar).bottomMargin, conVar.f8056w);
                }
            } else {
                int i15 = conVar.f2192j;
                if (i15 != -1 && (pVar5 = sparseArray.get(i15)) != null) {
                    o.con conVar5 = o.con.BOTTOM;
                    pVar.c0(conVar5, pVar5, conVar5, ((ViewGroup.MarginLayoutParams) conVar).bottomMargin, conVar.f8056w);
                }
            }
            int i16 = conVar.f2194k;
            if (i16 != -1) {
                z(pVar, conVar, sparseArray, i16, o.con.BASELINE);
            } else {
                int i17 = conVar.f8045l;
                if (i17 != -1) {
                    z(pVar, conVar, sparseArray, i17, o.con.TOP);
                } else {
                    int i18 = conVar.f8046m;
                    if (i18 != -1) {
                        z(pVar, conVar, sparseArray, i18, o.con.BOTTOM);
                    }
                }
            }
            if (f3 >= 0.0f) {
                pVar.J0(f3);
            }
            float f4 = conVar.f8037d;
            if (f4 >= 0.0f) {
                pVar.a1(f4);
            }
        }
        if (z2 && ((i2 = conVar.K) != -1 || conVar.L != -1)) {
            pVar.Y0(i2, conVar.L);
        }
        if (conVar.f2185f) {
            pVar.M0(p.con.FIXED);
            pVar.h1(((ViewGroup.MarginLayoutParams) conVar).width);
            if (((ViewGroup.MarginLayoutParams) conVar).width == -2) {
                pVar.M0(p.con.WRAP_CONTENT);
            }
        } else if (((ViewGroup.MarginLayoutParams) conVar).width == -1) {
            if (conVar.f2181d) {
                pVar.M0(p.con.MATCH_CONSTRAINT);
            } else {
                pVar.M0(p.con.MATCH_PARENT);
            }
            pVar.m(o.con.LEFT).f11483b = ((ViewGroup.MarginLayoutParams) conVar).leftMargin;
            pVar.m(o.con.RIGHT).f11483b = ((ViewGroup.MarginLayoutParams) conVar).rightMargin;
        } else {
            pVar.M0(p.con.MATCH_CONSTRAINT);
            pVar.h1(0);
        }
        if (conVar.f2187g) {
            pVar.d1(p.con.FIXED);
            pVar.I0(((ViewGroup.MarginLayoutParams) conVar).height);
            if (((ViewGroup.MarginLayoutParams) conVar).height == -2) {
                pVar.d1(p.con.WRAP_CONTENT);
            }
        } else if (((ViewGroup.MarginLayoutParams) conVar).height == -1) {
            if (conVar.f2183e) {
                pVar.d1(p.con.MATCH_CONSTRAINT);
            } else {
                pVar.d1(p.con.MATCH_PARENT);
            }
            pVar.m(o.con.TOP).f11483b = ((ViewGroup.MarginLayoutParams) conVar).topMargin;
            pVar.m(o.con.BOTTOM).f11483b = ((ViewGroup.MarginLayoutParams) conVar).bottomMargin;
        } else {
            pVar.d1(p.con.MATCH_CONSTRAINT);
            pVar.I0(0);
        }
        pVar.A0(conVar.f2172a);
        pVar.O0(conVar.f8039f);
        pVar.f1(conVar.f8040g);
        pVar.K0(conVar.C);
        pVar.b1(conVar.D);
        pVar.i1(conVar.N);
        pVar.N0(conVar.E, conVar.G, conVar.I, conVar.f8041h);
        pVar.e1(conVar.F, conVar.H, conVar.J, conVar.f8042i);
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof con;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<androidx.constraintlayout.widget.con> arrayList = this.f2165a;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i2 = 0; i2 < size; i2++) {
                this.f2165a.get(i2).q(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i4 = Integer.parseInt(strArrSplit[0]);
                        int i5 = Integer.parseInt(strArrSplit[1]);
                        int i6 = Integer.parseInt(strArrSplit[2]);
                        int i7 = (int) ((i4 / 1080.0f) * width);
                        int i8 = (int) ((i5 / 1920.0f) * height);
                        int i9 = (int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f2 = i7;
                        float f3 = i8;
                        float f4 = i7 + ((int) ((i6 / 1080.0f) * width));
                        canvas.drawLine(f2, f3, f4, f3, paint);
                        float f5 = i8 + i9;
                        canvas.drawLine(f4, f3, f4, f5, paint);
                        canvas.drawLine(f4, f5, f2, f5, paint);
                        canvas.drawLine(f2, f5, f2, f3, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f2, f3, f4, f5, paint);
                        canvas.drawLine(f2, f5, f4, f3, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
    public con generateDefaultLayoutParams() {
        return new con(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] */
    public con generateLayoutParams(AttributeSet attributeSet) {
        return new con(getContext(), attributeSet);
    }

    @Override // android.view.View
    public void forceLayout() {
        s();
        super.forceLayout();
    }

    public Object g(int i2, Object obj) {
        if (i2 != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> map = this.f2166a;
        if (map == null || !map.containsKey(str)) {
            return null;
        }
        return this.f2166a.get(str);
    }

    public int getMaxHeight() {
        return this.f8022d;
    }

    public int getMaxWidth() {
        return this.f8021c;
    }

    public int getMinHeight() {
        return this.f8020b;
    }

    public int getMinWidth() {
        return this.f2161a;
    }

    public int getOptimizationLevel() {
        return this.f2167a.G1();
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        if (((p) this.f2167a).f4942a == null) {
            int id2 = getId();
            if (id2 != -1) {
                ((p) this.f2167a).f4942a = getContext().getResources().getResourceEntryName(id2);
            } else {
                ((p) this.f2167a).f4942a = "parent";
            }
        }
        if (this.f2167a.r() == null) {
            q qVar = this.f2167a;
            qVar.z0(((p) qVar).f4942a);
            Log.v("ConstraintLayout", " setDebugName " + this.f2167a.r());
        }
        for (p pVar : this.f2167a.o1()) {
            View view = (View) pVar.q();
            if (view != null) {
                if (pVar.f4942a == null && (id = view.getId()) != -1) {
                    pVar.f4942a = getContext().getResources().getResourceEntryName(id);
                }
                if (pVar.r() == null) {
                    pVar.z0(pVar.f4942a);
                    Log.v("ConstraintLayout", " setDebugName " + pVar.r());
                }
            }
        }
        this.f2167a.M(sb);
        return sb.toString();
    }

    public final p h(int i2) {
        if (i2 == 0) {
            return this.f2167a;
        }
        View viewFindViewById = this.f2162a.get(i2);
        if (viewFindViewById == null && (viewFindViewById = findViewById(i2)) != null && viewFindViewById != this && viewFindViewById.getParent() == this) {
            onViewAdded(viewFindViewById);
        }
        if (viewFindViewById == this) {
            return this.f2167a;
        }
        if (viewFindViewById == null) {
            return null;
        }
        return ((con) viewFindViewById.getLayoutParams()).f2173a;
    }

    public View n(int i2) {
        return this.f2162a.get(i2);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        View content;
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            con conVar = (con) childAt.getLayoutParams();
            p pVar = conVar.f2173a;
            if ((childAt.getVisibility() != 8 || conVar.f2191i || conVar.f2193j || conVar.f2196l || zIsInEditMode) && !conVar.f2195k) {
                int iV = pVar.V();
                int iW = pVar.W();
                int iU = pVar.U() + iV;
                int iV2 = pVar.v() + iW;
                childAt.layout(iV, iW, iU, iV2);
                if ((childAt instanceof com1) && (content = ((com1) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(iV, iW, iU, iV2);
                }
            }
        }
        int size = this.f2165a.size();
        if (size > 0) {
            for (int i7 = 0; i7 < size; i7++) {
                this.f2165a.get(i7).o(this);
            }
        }
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        if (this.f8031m == i2) {
            int i4 = this.f8032n;
        }
        if (!this.f2170b) {
            int childCount = getChildCount();
            for (int i5 = 0; i5 < childCount; i5++) {
                if (getChildAt(i5).isLayoutRequested()) {
                    this.f2170b = true;
                    break;
                }
            }
        }
        boolean z2 = this.f2170b;
        this.f8031m = i2;
        this.f8032n = i3;
        this.f2167a.U1(r());
        if (this.f2170b) {
            this.f2170b = false;
            if (A()) {
                this.f2167a.W1();
            }
        }
        v(this.f2167a, this.f8023e, i2, i3);
        u(i2, i3, this.f2167a.U(), this.f2167a.v(), this.f2167a.M1(), this.f2167a.K1());
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        p pVarP = p(view);
        if ((view instanceof Guideline) && !(pVarP instanceof r)) {
            con conVar = (con) view.getLayoutParams();
            r rVar = new r();
            conVar.f2173a = rVar;
            conVar.f2191i = true;
            rVar.x1(conVar.M);
        }
        if (view instanceof androidx.constraintlayout.widget.con) {
            androidx.constraintlayout.widget.con conVar2 = (androidx.constraintlayout.widget.con) view;
            conVar2.s();
            ((con) view.getLayoutParams()).f2193j = true;
            if (!this.f2165a.contains(conVar2)) {
                this.f2165a.add(conVar2);
            }
        }
        this.f2162a.put(view.getId(), view);
        this.f2170b = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f2162a.remove(view.getId());
        this.f2167a.q1(p(view));
        this.f2165a.remove(view);
        this.f2170b = true;
    }

    public final p p(View view) {
        if (view == this) {
            return this.f2167a;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof con) {
            return ((con) view.getLayoutParams()).f2173a;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof con) {
            return ((con) view.getLayoutParams()).f2173a;
        }
        return null;
    }

    public final void q(AttributeSet attributeSet, int i2, int i3) {
        this.f2167a.y0(this);
        this.f2167a.R1(this.f2163a);
        this.f2162a.put(getId(), this);
        this.f2164a = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, h0.f5224u, i2, i3);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i4 = 0; i4 < indexCount; i4++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i4);
                if (index == h0.X0) {
                    this.f2161a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2161a);
                } else if (index == h0.Y0) {
                    this.f8020b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f8020b);
                } else if (index == h0.V0) {
                    this.f8021c = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f8021c);
                } else if (index == h0.W0) {
                    this.f8022d = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f8022d);
                } else if (index == h0.m2) {
                    this.f8023e = typedArrayObtainStyledAttributes.getInt(index, this.f8023e);
                } else if (index == h0.h1) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            t(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f2168a = null;
                        }
                    }
                } else if (index == h0.d1) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        androidx.constraintlayout.widget.nul nulVar = new androidx.constraintlayout.widget.nul();
                        this.f2164a = nulVar;
                        nulVar.n(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f2164a = null;
                    }
                    this.f8024f = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f2167a.S1(this.f8023e);
    }

    public boolean r() {
        return ((getContext().getApplicationInfo().flags & inet.ipaddr.format.validate.aux.KEY_INFERRED_UPPER_BOUNDARY) != 0) && 1 == getLayoutDirection();
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        s();
        super.requestLayout();
    }

    public final void s() {
        this.f2170b = true;
        this.f8025g = -1;
        this.f8026h = -1;
        this.f8027i = -1;
        this.f8028j = -1;
        this.f8029k = 0;
        this.f8030l = 0;
    }

    public void setConstraintSet(androidx.constraintlayout.widget.nul nulVar) {
        this.f2164a = nulVar;
    }

    @Override // android.view.View
    public void setId(int i2) {
        this.f2162a.remove(getId());
        super.setId(i2);
        this.f2162a.put(getId(), this);
    }

    public void setMaxHeight(int i2) {
        if (i2 == this.f8022d) {
            return;
        }
        this.f8022d = i2;
        requestLayout();
    }

    public void setMaxWidth(int i2) {
        if (i2 == this.f8021c) {
            return;
        }
        this.f8021c = i2;
        requestLayout();
    }

    public void setMinHeight(int i2) {
        if (i2 == this.f8020b) {
            return;
        }
        this.f8020b = i2;
        requestLayout();
    }

    public void setMinWidth(int i2) {
        if (i2 == this.f2161a) {
            return;
        }
        this.f2161a = i2;
        requestLayout();
    }

    public void setOnConstraintsChanged(f0 f0Var) {
        e0 e0Var = this.f2168a;
        if (e0Var != null) {
            e0Var.c(f0Var);
        }
    }

    public void setOptimizationLevel(int i2) {
        this.f8023e = i2;
        this.f2167a.S1(i2);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public void t(int i2) {
        this.f2168a = new e0(getContext(), this, i2);
    }

    public void u(int i2, int i3, int i4, int i5, boolean z2, boolean z3) {
        nul nulVar = this.f2163a;
        int i6 = nulVar.f8064d;
        int iResolveSizeAndState = View.resolveSizeAndState(i4 + nulVar.f8063c, i2, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(i5 + i6, i3, 0) & 16777215;
        int iMin = Math.min(this.f8021c, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(this.f8022d, iResolveSizeAndState2);
        if (z2) {
            iMin |= 16777216;
        }
        if (z3) {
            iMin2 |= 16777216;
        }
        setMeasuredDimension(iMin, iMin2);
        this.f8025g = iMin;
        this.f8026h = iMin2;
    }

    public void v(q qVar, int i2, int i3, int i4) {
        int iMax;
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i4);
        int size2 = View.MeasureSpec.getSize(i4);
        int iMax2 = Math.max(0, getPaddingTop());
        int iMax3 = Math.max(0, getPaddingBottom());
        int i5 = iMax2 + iMax3;
        int paddingWidth = getPaddingWidth();
        this.f2163a.c(i3, i4, iMax2, iMax3, paddingWidth, i5);
        int iMax4 = Math.max(0, getPaddingStart());
        int iMax5 = Math.max(0, getPaddingEnd());
        if (iMax4 > 0 || iMax5 > 0) {
            iMax = r() ? iMax5 : iMax4;
        } else {
            iMax = Math.max(0, getPaddingLeft());
        }
        int i6 = size - paddingWidth;
        int i7 = size2 - i5;
        y(qVar, mode, i6, mode2, i7);
        qVar.N1(i2, mode, i6, mode2, i7, this.f8025g, this.f8026h, iMax, iMax2);
    }

    public final void w() {
        boolean zIsInEditMode = isInEditMode();
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            p pVarP = p(getChildAt(i2));
            if (pVarP != null) {
                pVarP.r0();
            }
        }
        if (zIsInEditMode) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                try {
                    String resourceName = getResources().getResourceName(childAt.getId());
                    x(0, resourceName, Integer.valueOf(childAt.getId()));
                    int iIndexOf = resourceName.indexOf(47);
                    if (iIndexOf != -1) {
                        resourceName = resourceName.substring(iIndexOf + 1);
                    }
                    h(childAt.getId()).z0(resourceName);
                } catch (Resources.NotFoundException unused) {
                }
            }
        }
        if (this.f8024f != -1) {
            for (int i4 = 0; i4 < childCount; i4++) {
                View childAt2 = getChildAt(i4);
                if (childAt2.getId() == this.f8024f && (childAt2 instanceof prn)) {
                    this.f2164a = ((prn) childAt2).getConstraintSet();
                }
            }
        }
        androidx.constraintlayout.widget.nul nulVar = this.f2164a;
        if (nulVar != null) {
            nulVar.d(this, true);
        }
        this.f2167a.r1();
        int size = this.f2165a.size();
        if (size > 0) {
            for (int i5 = 0; i5 < size; i5++) {
                this.f2165a.get(i5).r(this);
            }
        }
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt3 = getChildAt(i6);
            if (childAt3 instanceof com1) {
                ((com1) childAt3).b(this);
            }
        }
        this.f2169b.clear();
        this.f2169b.put(0, this.f2167a);
        this.f2169b.put(getId(), this.f2167a);
        for (int i7 = 0; i7 < childCount; i7++) {
            View childAt4 = getChildAt(i7);
            this.f2169b.put(childAt4.getId(), p(childAt4));
        }
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt5 = getChildAt(i8);
            p pVarP2 = p(childAt5);
            if (pVarP2 != null) {
                con conVar = (con) childAt5.getLayoutParams();
                this.f2167a.c(pVarP2);
                c(zIsInEditMode, childAt5, pVarP2, conVar, this.f2169b);
            }
        }
    }

    public void x(int i2, Object obj, Object obj2) {
        if (i2 == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.f2166a == null) {
                this.f2166a = new HashMap<>();
            }
            String strSubstring = (String) obj;
            int iIndexOf = strSubstring.indexOf("/");
            if (iIndexOf != -1) {
                strSubstring = strSubstring.substring(iIndexOf + 1);
            }
            this.f2166a.put(strSubstring, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x003e A[PHI: r2
      0x003e: PHI (r2v4 nUL.p$con) = (r2v3 nUL.p$con), (r2v0 nUL.p$con) binds: [B:21:0x004a, B:17:0x003c] A[DONT_GENERATE, DONT_INLINE]] */
    public void y(q qVar, int i2, int i3, int i4, int i5) {
        p.con conVar;
        nul nulVar = this.f2163a;
        int i6 = nulVar.f8064d;
        int i7 = nulVar.f8063c;
        p.con conVar2 = p.con.FIXED;
        int childCount = getChildCount();
        if (i2 == Integer.MIN_VALUE) {
            conVar = p.con.WRAP_CONTENT;
            if (childCount == 0) {
                i3 = Math.max(0, this.f2161a);
            }
        } else if (i2 == 0) {
            conVar = p.con.WRAP_CONTENT;
            i3 = childCount == 0 ? Math.max(0, this.f2161a) : 0;
        } else if (i2 != 1073741824) {
            conVar = conVar2;
        } else {
            i3 = Math.min(this.f8021c - i7, i3);
            conVar = conVar2;
        }
        if (i4 == Integer.MIN_VALUE) {
            conVar2 = p.con.WRAP_CONTENT;
            if (childCount == 0) {
                i5 = Math.max(0, this.f8020b);
            }
        } else if (i4 == 0) {
            conVar2 = p.con.WRAP_CONTENT;
            if (childCount == 0) {
                i5 = Math.max(0, this.f8020b);
            } else {
                i5 = 0;
            }
        } else if (i4 != 1073741824) {
            i5 = 0;
        } else {
            i5 = Math.min(this.f8022d - i6, i5);
        }
        if (i3 != qVar.U() || i5 != qVar.v()) {
            qVar.J1();
        }
        qVar.j1(0);
        qVar.k1(0);
        qVar.U0(this.f8021c - i7);
        qVar.T0(this.f8022d - i6);
        qVar.X0(0);
        qVar.W0(0);
        qVar.M0(conVar);
        qVar.h1(i3);
        qVar.d1(conVar2);
        qVar.I0(i5);
        qVar.X0(this.f2161a - i7);
        qVar.W0(this.f8020b - i6);
    }

    public final void z(p pVar, con conVar, SparseArray<p> sparseArray, int i2, o.con conVar2) {
        View view = this.f2162a.get(i2);
        p pVar2 = sparseArray.get(i2);
        if (pVar2 == null || view == null || !(view.getLayoutParams() instanceof con)) {
            return;
        }
        conVar.f2189h = true;
        o.con conVar3 = o.con.BASELINE;
        if (conVar2 == conVar3) {
            con conVar4 = (con) view.getLayoutParams();
            conVar4.f2189h = true;
            conVar4.f2173a.H0(true);
        }
        pVar.m(conVar3).a(pVar2.m(conVar2), conVar.A, conVar.f8059z, true);
        pVar.H0(true);
        pVar.m(o.con.TOP).p();
        pVar.m(o.con.BOTTOM).p();
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new con(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2162a = new SparseArray<>();
        this.f2165a = new ArrayList<>(4);
        this.f2167a = new q();
        this.f2161a = 0;
        this.f8020b = 0;
        this.f8021c = Preference.DEFAULT_ORDER;
        this.f8022d = Preference.DEFAULT_ORDER;
        this.f2170b = true;
        this.f8023e = 257;
        this.f2164a = null;
        this.f2168a = null;
        this.f8024f = -1;
        this.f2166a = new HashMap<>();
        this.f8025g = -1;
        this.f8026h = -1;
        this.f8027i = -1;
        this.f8028j = -1;
        this.f8029k = 0;
        this.f8030l = 0;
        this.f2169b = new SparseArray<>();
        this.f2163a = new nul(this);
        this.f8031m = 0;
        this.f8032n = 0;
        q(attributeSet, i2, 0);
    }

    public static class con extends ViewGroup.MarginLayoutParams {
        public int A;
        public int B;
        public int C;
        public int D;
        public int E;
        public int F;
        public int G;
        public int H;
        public int I;
        public int J;
        public int K;
        public int L;
        public int M;
        public int N;
        public int O;
        public int P;
        public int Q;
        public int R;
        public int S;
        public int T;
        public int U;
        public int V;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f8034a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public int f2171a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public String f2172a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public p f2173a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2174a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f8035b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public int f2175b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public String f2176b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2177b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f8036c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public int f2178c;

        /* JADX INFO: renamed from: c, reason: collision with other field name */
        public boolean f2179c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f8037d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public int f2180d;

        /* JADX INFO: renamed from: d, reason: collision with other field name */
        public boolean f2181d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f8038e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public int f2182e;

        /* JADX INFO: renamed from: e, reason: collision with other field name */
        public boolean f2183e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f8039f;

        /* JADX INFO: renamed from: f, reason: collision with other field name */
        public int f2184f;

        /* JADX INFO: renamed from: f, reason: collision with other field name */
        public boolean f2185f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f8040g;

        /* JADX INFO: renamed from: g, reason: collision with other field name */
        public int f2186g;

        /* JADX INFO: renamed from: g, reason: collision with other field name */
        public boolean f2187g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public float f8041h;

        /* JADX INFO: renamed from: h, reason: collision with other field name */
        public int f2188h;

        /* JADX INFO: renamed from: h, reason: collision with other field name */
        public boolean f2189h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public float f8042i;

        /* JADX INFO: renamed from: i, reason: collision with other field name */
        public int f2190i;

        /* JADX INFO: renamed from: i, reason: collision with other field name */
        public boolean f2191i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public float f8043j;

        /* JADX INFO: renamed from: j, reason: collision with other field name */
        public int f2192j;

        /* JADX INFO: renamed from: j, reason: collision with other field name */
        public boolean f2193j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public float f8044k;

        /* JADX INFO: renamed from: k, reason: collision with other field name */
        public int f2194k;

        /* JADX INFO: renamed from: k, reason: collision with other field name */
        public boolean f2195k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public int f8045l;

        /* JADX INFO: renamed from: l, reason: collision with other field name */
        public boolean f2196l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public int f8046m;

        /* JADX INFO: renamed from: m, reason: collision with other field name */
        public boolean f2197m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public int f8047n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public int f8048o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public int f8049p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public int f8050q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public int f8051r;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public int f8052s;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public int f8053t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public int f8054u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public int f8055v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public int f8056w;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public int f8057x;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        public int f8058y;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        public int f8059z;

        public static class aux {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public static final SparseIntArray f8060a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f8060a = sparseIntArray;
                sparseIntArray.append(h0.X1, 64);
                sparseIntArray.append(h0.A1, 65);
                sparseIntArray.append(h0.J1, 8);
                sparseIntArray.append(h0.K1, 9);
                sparseIntArray.append(h0.M1, 10);
                sparseIntArray.append(h0.N1, 11);
                sparseIntArray.append(h0.T1, 12);
                sparseIntArray.append(h0.S1, 13);
                sparseIntArray.append(h0.q1, 14);
                sparseIntArray.append(h0.p1, 15);
                sparseIntArray.append(h0.l1, 16);
                sparseIntArray.append(h0.n1, 52);
                sparseIntArray.append(h0.m1, 53);
                sparseIntArray.append(h0.r1, 2);
                sparseIntArray.append(h0.t1, 3);
                sparseIntArray.append(h0.s1, 4);
                sparseIntArray.append(h0.c2, 49);
                sparseIntArray.append(h0.d2, 50);
                sparseIntArray.append(h0.x1, 5);
                sparseIntArray.append(h0.y1, 6);
                sparseIntArray.append(h0.z1, 7);
                sparseIntArray.append(h0.g1, 67);
                sparseIntArray.append(h0.T0, 1);
                sparseIntArray.append(h0.O1, 17);
                sparseIntArray.append(h0.P1, 18);
                sparseIntArray.append(h0.w1, 19);
                sparseIntArray.append(h0.v1, 20);
                sparseIntArray.append(h0.h2, 21);
                sparseIntArray.append(h0.k2, 22);
                sparseIntArray.append(h0.i2, 23);
                sparseIntArray.append(h0.f2, 24);
                sparseIntArray.append(h0.j2, 25);
                sparseIntArray.append(h0.g2, 26);
                sparseIntArray.append(h0.e2, 55);
                sparseIntArray.append(h0.l2, 54);
                sparseIntArray.append(h0.F1, 29);
                sparseIntArray.append(h0.U1, 30);
                sparseIntArray.append(h0.u1, 44);
                sparseIntArray.append(h0.H1, 45);
                sparseIntArray.append(h0.W1, 46);
                sparseIntArray.append(h0.G1, 47);
                sparseIntArray.append(h0.V1, 48);
                sparseIntArray.append(h0.j1, 27);
                sparseIntArray.append(h0.i1, 28);
                sparseIntArray.append(h0.Y1, 31);
                sparseIntArray.append(h0.B1, 32);
                sparseIntArray.append(h0.a2, 33);
                sparseIntArray.append(h0.Z1, 34);
                sparseIntArray.append(h0.b2, 35);
                sparseIntArray.append(h0.D1, 36);
                sparseIntArray.append(h0.C1, 37);
                sparseIntArray.append(h0.E1, 38);
                sparseIntArray.append(h0.I1, 39);
                sparseIntArray.append(h0.R1, 40);
                sparseIntArray.append(h0.L1, 41);
                sparseIntArray.append(h0.o1, 42);
                sparseIntArray.append(h0.k1, 43);
                sparseIntArray.append(h0.Q1, 51);
                sparseIntArray.append(h0.n2, 66);
            }
        }

        public con(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2171a = -1;
            this.f2175b = -1;
            this.f8034a = -1.0f;
            this.f2174a = true;
            this.f2178c = -1;
            this.f2180d = -1;
            this.f2182e = -1;
            this.f2184f = -1;
            this.f2186g = -1;
            this.f2188h = -1;
            this.f2190i = -1;
            this.f2192j = -1;
            this.f2194k = -1;
            this.f8045l = -1;
            this.f8046m = -1;
            this.f8047n = -1;
            this.f8048o = 0;
            this.f8035b = 0.0f;
            this.f8049p = -1;
            this.f8050q = -1;
            this.f8051r = -1;
            this.f8052s = -1;
            this.f8053t = Integer.MIN_VALUE;
            this.f8054u = Integer.MIN_VALUE;
            this.f8055v = Integer.MIN_VALUE;
            this.f8056w = Integer.MIN_VALUE;
            this.f8057x = Integer.MIN_VALUE;
            this.f8058y = Integer.MIN_VALUE;
            this.f8059z = Integer.MIN_VALUE;
            this.A = 0;
            this.f2177b = true;
            this.f2179c = true;
            this.f8036c = 0.5f;
            this.f8037d = 0.5f;
            this.f2172a = null;
            this.f8038e = 0.0f;
            this.B = 1;
            this.f8039f = -1.0f;
            this.f8040g = -1.0f;
            this.C = 0;
            this.D = 0;
            this.E = 0;
            this.F = 0;
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.J = 0;
            this.f8041h = 1.0f;
            this.f8042i = 1.0f;
            this.K = -1;
            this.L = -1;
            this.M = -1;
            this.f2181d = false;
            this.f2183e = false;
            this.f2176b = null;
            this.N = 0;
            this.f2185f = true;
            this.f2187g = true;
            this.f2189h = false;
            this.f2191i = false;
            this.f2193j = false;
            this.f2195k = false;
            this.f2196l = false;
            this.O = -1;
            this.P = -1;
            this.Q = -1;
            this.R = -1;
            this.S = Integer.MIN_VALUE;
            this.T = Integer.MIN_VALUE;
            this.f8043j = 0.5f;
            this.f2173a = new p();
            this.f2197m = false;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h0.f5224u);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i2 = 0; i2 < indexCount; i2++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i2);
                int i3 = aux.f8060a.get(index);
                switch (i3) {
                    case 1:
                        this.M = typedArrayObtainStyledAttributes.getInt(index, this.M);
                        break;
                    case 2:
                        int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, this.f8047n);
                        this.f8047n = resourceId;
                        if (resourceId == -1) {
                            this.f8047n = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 3:
                        this.f8048o = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8048o);
                        break;
                    case 4:
                        float f2 = typedArrayObtainStyledAttributes.getFloat(index, this.f8035b) % 360.0f;
                        this.f8035b = f2;
                        if (f2 < 0.0f) {
                            this.f8035b = (360.0f - f2) % 360.0f;
                        }
                        break;
                    case 5:
                        this.f2171a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2171a);
                        break;
                    case 6:
                        this.f2175b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2175b);
                        break;
                    case 7:
                        this.f8034a = typedArrayObtainStyledAttributes.getFloat(index, this.f8034a);
                        break;
                    case 8:
                        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2178c);
                        this.f2178c = resourceId2;
                        if (resourceId2 == -1) {
                            this.f2178c = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 9:
                        int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2180d);
                        this.f2180d = resourceId3;
                        if (resourceId3 == -1) {
                            this.f2180d = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 10:
                        int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2182e);
                        this.f2182e = resourceId4;
                        if (resourceId4 == -1) {
                            this.f2182e = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 11:
                        int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2184f);
                        this.f2184f = resourceId5;
                        if (resourceId5 == -1) {
                            this.f2184f = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 12:
                        int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2186g);
                        this.f2186g = resourceId6;
                        if (resourceId6 == -1) {
                            this.f2186g = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 13:
                        int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2188h);
                        this.f2188h = resourceId7;
                        if (resourceId7 == -1) {
                            this.f2188h = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 14:
                        int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2190i);
                        this.f2190i = resourceId8;
                        if (resourceId8 == -1) {
                            this.f2190i = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 15:
                        int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2192j);
                        this.f2192j = resourceId9;
                        if (resourceId9 == -1) {
                            this.f2192j = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 16:
                        int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, this.f2194k);
                        this.f2194k = resourceId10;
                        if (resourceId10 == -1) {
                            this.f2194k = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 17:
                        int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, this.f8049p);
                        this.f8049p = resourceId11;
                        if (resourceId11 == -1) {
                            this.f8049p = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 18:
                        int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, this.f8050q);
                        this.f8050q = resourceId12;
                        if (resourceId12 == -1) {
                            this.f8050q = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 19:
                        int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, this.f8051r);
                        this.f8051r = resourceId13;
                        if (resourceId13 == -1) {
                            this.f8051r = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 20:
                        int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, this.f8052s);
                        this.f8052s = resourceId14;
                        if (resourceId14 == -1) {
                            this.f8052s = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 21:
                        this.f8053t = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8053t);
                        break;
                    case 22:
                        this.f8054u = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8054u);
                        break;
                    case 23:
                        this.f8055v = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8055v);
                        break;
                    case 24:
                        this.f8056w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8056w);
                        break;
                    case 25:
                        this.f8057x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8057x);
                        break;
                    case 26:
                        this.f8058y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8058y);
                        break;
                    case 27:
                        this.f2181d = typedArrayObtainStyledAttributes.getBoolean(index, this.f2181d);
                        break;
                    case 28:
                        this.f2183e = typedArrayObtainStyledAttributes.getBoolean(index, this.f2183e);
                        break;
                    case 29:
                        this.f8036c = typedArrayObtainStyledAttributes.getFloat(index, this.f8036c);
                        break;
                    case 30:
                        this.f8037d = typedArrayObtainStyledAttributes.getFloat(index, this.f8037d);
                        break;
                    case 31:
                        int i4 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.E = i4;
                        if (i4 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        }
                        break;
                    case 32:
                        int i5 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.F = i5;
                        if (i5 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        }
                        break;
                    case 33:
                        try {
                            this.G = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.G);
                        } catch (Exception unused) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.G) == -2) {
                                this.G = -2;
                            }
                        }
                        break;
                    case 34:
                        try {
                            this.I = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.I);
                        } catch (Exception unused2) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.I) == -2) {
                                this.I = -2;
                            }
                        }
                        break;
                    case 35:
                        this.f8041h = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.f8041h));
                        this.E = 2;
                        break;
                    case 36:
                        try {
                            this.H = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.H);
                        } catch (Exception unused3) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.H) == -2) {
                                this.H = -2;
                            }
                        }
                        break;
                    case lpt4.AppCompatTheme_alertDialogStyle /* 37 */:
                        try {
                            this.J = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.J);
                        } catch (Exception unused4) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.J) == -2) {
                                this.J = -2;
                            }
                        }
                        break;
                    case lpt4.AppCompatTheme_alertDialogTheme /* 38 */:
                        this.f8042i = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.f8042i));
                        this.F = 2;
                        break;
                    default:
                        switch (i3) {
                            case lpt4.AppCompatTheme_buttonBarPositiveButtonStyle /* 44 */:
                                androidx.constraintlayout.widget.nul.s(this, typedArrayObtainStyledAttributes.getString(index));
                                break;
                            case lpt4.AppCompatTheme_buttonBarStyle /* 45 */:
                                this.f8039f = typedArrayObtainStyledAttributes.getFloat(index, this.f8039f);
                                break;
                            case lpt4.AppCompatTheme_buttonStyle /* 46 */:
                                this.f8040g = typedArrayObtainStyledAttributes.getFloat(index, this.f8040g);
                                break;
                            case lpt4.AppCompatTheme_buttonStyleSmall /* 47 */:
                                this.C = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 48:
                                this.D = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case lpt4.AppCompatTheme_checkedTextViewStyle /* 49 */:
                                this.K = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.K);
                                break;
                            case 50:
                                this.L = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.L);
                                break;
                            case lpt4.AppCompatTheme_colorBackgroundFloating /* 51 */:
                                this.f2176b = typedArrayObtainStyledAttributes.getString(index);
                                break;
                            case lpt4.AppCompatTheme_colorButtonNormal /* 52 */:
                                int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, this.f8045l);
                                this.f8045l = resourceId15;
                                if (resourceId15 == -1) {
                                    this.f8045l = typedArrayObtainStyledAttributes.getInt(index, -1);
                                }
                                break;
                            case lpt4.AppCompatTheme_colorControlActivated /* 53 */:
                                int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, this.f8046m);
                                this.f8046m = resourceId16;
                                if (resourceId16 == -1) {
                                    this.f8046m = typedArrayObtainStyledAttributes.getInt(index, -1);
                                }
                                break;
                            case lpt4.AppCompatTheme_colorControlHighlight /* 54 */:
                                this.A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.A);
                                break;
                            case lpt4.AppCompatTheme_colorControlNormal /* 55 */:
                                this.f8059z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f8059z);
                                break;
                            default:
                                switch (i3) {
                                    case 64:
                                        androidx.constraintlayout.widget.nul.q(this, typedArrayObtainStyledAttributes, index, 0);
                                        this.f2177b = true;
                                        break;
                                    case lpt4.AppCompatTheme_dividerVertical /* 65 */:
                                        androidx.constraintlayout.widget.nul.q(this, typedArrayObtainStyledAttributes, index, 1);
                                        this.f2179c = true;
                                        break;
                                    case lpt4.AppCompatTheme_dropDownListViewStyle /* 66 */:
                                        this.N = typedArrayObtainStyledAttributes.getInt(index, this.N);
                                        break;
                                    case lpt4.AppCompatTheme_dropdownListPreferredItemHeight /* 67 */:
                                        this.f2174a = typedArrayObtainStyledAttributes.getBoolean(index, this.f2174a);
                                        break;
                                }
                                break;
                        }
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            a();
        }

        public void a() {
            this.f2191i = false;
            this.f2185f = true;
            this.f2187g = true;
            int i2 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i2 == -2 && this.f2181d) {
                this.f2185f = false;
                if (this.E == 0) {
                    this.E = 1;
                }
            }
            int i3 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i3 == -2 && this.f2183e) {
                this.f2187g = false;
                if (this.F == 0) {
                    this.F = 1;
                }
            }
            if (i2 == 0 || i2 == -1) {
                this.f2185f = false;
                if (i2 == 0 && this.E == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.f2181d = true;
                }
            }
            if (i3 == 0 || i3 == -1) {
                this.f2187g = false;
                if (i3 == 0 && this.F == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.f2183e = true;
                }
            }
            if (this.f8034a == -1.0f && this.f2171a == -1 && this.f2175b == -1) {
                return;
            }
            this.f2191i = true;
            this.f2185f = true;
            this.f2187g = true;
            if (!(this.f2173a instanceof r)) {
                this.f2173a = new r();
            }
            ((r) this.f2173a).x1(this.M);
        }

        /* JADX WARN: Code duplicated, block: B:17:0x004a  */
        /* JADX WARN: Code duplicated, block: B:20:0x0051  */
        /* JADX WARN: Code duplicated, block: B:23:0x0058  */
        /* JADX WARN: Code duplicated, block: B:26:0x005e  */
        /* JADX WARN: Code duplicated, block: B:29:0x0064  */
        /* JADX WARN: Code duplicated, block: B:38:0x007a  */
        /* JADX WARN: Code duplicated, block: B:39:0x0082 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:40:0x0084  */
        /* JADX WARN: Code duplicated, block: B:41:0x008b A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:42:0x008d  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        @TargetApi(17)
        public void resolveLayoutDirection(int i2) {
            int i3;
            int i4;
            int i5;
            int i6;
            int i7 = ((ViewGroup.MarginLayoutParams) this).leftMargin;
            int i8 = ((ViewGroup.MarginLayoutParams) this).rightMargin;
            super.resolveLayoutDirection(i2);
            boolean z2 = false;
            boolean z3 = 1 == getLayoutDirection();
            this.Q = -1;
            this.R = -1;
            this.O = -1;
            this.P = -1;
            this.S = this.f8053t;
            this.T = this.f8055v;
            float f2 = this.f8036c;
            this.f8043j = f2;
            int i9 = this.f2171a;
            this.U = i9;
            int i10 = this.f2175b;
            this.V = i10;
            float f3 = this.f8034a;
            this.f8044k = f3;
            if (z3) {
                int i11 = this.f8049p;
                if (i11 != -1) {
                    this.Q = i11;
                } else {
                    int i12 = this.f8050q;
                    if (i12 != -1) {
                        this.R = i12;
                    } else {
                        i3 = this.f8051r;
                        if (i3 != -1) {
                            this.P = i3;
                            z2 = true;
                        }
                        i4 = this.f8052s;
                        if (i4 != -1) {
                            this.O = i4;
                            z2 = true;
                        }
                        i5 = this.f8057x;
                        if (i5 != Integer.MIN_VALUE) {
                            this.T = i5;
                        }
                        i6 = this.f8058y;
                        if (i6 != Integer.MIN_VALUE) {
                            this.S = i6;
                        }
                        if (z2) {
                            this.f8043j = 1.0f - f2;
                        }
                        if (this.f2191i && this.M == 1 && this.f2174a) {
                            if (f3 != -1.0f) {
                                this.f8044k = 1.0f - f3;
                                this.U = -1;
                                this.V = -1;
                            } else if (i9 != -1) {
                                this.V = i9;
                                this.U = -1;
                                this.f8044k = -1.0f;
                            } else if (i10 != -1) {
                                this.U = i10;
                                this.V = -1;
                                this.f8044k = -1.0f;
                            }
                        }
                    }
                }
                z2 = true;
                i3 = this.f8051r;
                if (i3 != -1) {
                    this.P = i3;
                    z2 = true;
                }
                i4 = this.f8052s;
                if (i4 != -1) {
                    this.O = i4;
                    z2 = true;
                }
                i5 = this.f8057x;
                if (i5 != Integer.MIN_VALUE) {
                    this.T = i5;
                }
                i6 = this.f8058y;
                if (i6 != Integer.MIN_VALUE) {
                    this.S = i6;
                }
                if (z2) {
                    this.f8043j = 1.0f - f2;
                }
                if (this.f2191i) {
                    if (f3 != -1.0f) {
                        this.f8044k = 1.0f - f3;
                        this.U = -1;
                        this.V = -1;
                    } else if (i9 != -1) {
                        this.V = i9;
                        this.U = -1;
                        this.f8044k = -1.0f;
                    } else if (i10 != -1) {
                        this.U = i10;
                        this.V = -1;
                        this.f8044k = -1.0f;
                    }
                }
            } else {
                int i13 = this.f8049p;
                if (i13 != -1) {
                    this.P = i13;
                }
                int i14 = this.f8050q;
                if (i14 != -1) {
                    this.O = i14;
                }
                int i15 = this.f8051r;
                if (i15 != -1) {
                    this.Q = i15;
                }
                int i16 = this.f8052s;
                if (i16 != -1) {
                    this.R = i16;
                }
                int i17 = this.f8057x;
                if (i17 != Integer.MIN_VALUE) {
                    this.S = i17;
                }
                int i18 = this.f8058y;
                if (i18 != Integer.MIN_VALUE) {
                    this.T = i18;
                }
            }
            if (this.f8051r == -1 && this.f8052s == -1 && this.f8050q == -1 && this.f8049p == -1) {
                int i19 = this.f2182e;
                if (i19 != -1) {
                    this.Q = i19;
                    if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i8 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).rightMargin = i8;
                    }
                } else {
                    int i20 = this.f2184f;
                    if (i20 != -1) {
                        this.R = i20;
                        if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i8 > 0) {
                            ((ViewGroup.MarginLayoutParams) this).rightMargin = i8;
                        }
                    }
                }
                int i21 = this.f2178c;
                if (i21 != -1) {
                    this.O = i21;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i7 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i7;
                    return;
                }
                int i22 = this.f2180d;
                if (i22 != -1) {
                    this.P = i22;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i7 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i7;
                }
            }
        }

        public con(int i2, int i3) {
            super(i2, i3);
            this.f2171a = -1;
            this.f2175b = -1;
            this.f8034a = -1.0f;
            this.f2174a = true;
            this.f2178c = -1;
            this.f2180d = -1;
            this.f2182e = -1;
            this.f2184f = -1;
            this.f2186g = -1;
            this.f2188h = -1;
            this.f2190i = -1;
            this.f2192j = -1;
            this.f2194k = -1;
            this.f8045l = -1;
            this.f8046m = -1;
            this.f8047n = -1;
            this.f8048o = 0;
            this.f8035b = 0.0f;
            this.f8049p = -1;
            this.f8050q = -1;
            this.f8051r = -1;
            this.f8052s = -1;
            this.f8053t = Integer.MIN_VALUE;
            this.f8054u = Integer.MIN_VALUE;
            this.f8055v = Integer.MIN_VALUE;
            this.f8056w = Integer.MIN_VALUE;
            this.f8057x = Integer.MIN_VALUE;
            this.f8058y = Integer.MIN_VALUE;
            this.f8059z = Integer.MIN_VALUE;
            this.A = 0;
            this.f2177b = true;
            this.f2179c = true;
            this.f8036c = 0.5f;
            this.f8037d = 0.5f;
            this.f2172a = null;
            this.f8038e = 0.0f;
            this.B = 1;
            this.f8039f = -1.0f;
            this.f8040g = -1.0f;
            this.C = 0;
            this.D = 0;
            this.E = 0;
            this.F = 0;
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.J = 0;
            this.f8041h = 1.0f;
            this.f8042i = 1.0f;
            this.K = -1;
            this.L = -1;
            this.M = -1;
            this.f2181d = false;
            this.f2183e = false;
            this.f2176b = null;
            this.N = 0;
            this.f2185f = true;
            this.f2187g = true;
            this.f2189h = false;
            this.f2191i = false;
            this.f2193j = false;
            this.f2195k = false;
            this.f2196l = false;
            this.O = -1;
            this.P = -1;
            this.Q = -1;
            this.R = -1;
            this.S = Integer.MIN_VALUE;
            this.T = Integer.MIN_VALUE;
            this.f8043j = 0.5f;
            this.f2173a = new p();
            this.f2197m = false;
        }

        public con(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2171a = -1;
            this.f2175b = -1;
            this.f8034a = -1.0f;
            this.f2174a = true;
            this.f2178c = -1;
            this.f2180d = -1;
            this.f2182e = -1;
            this.f2184f = -1;
            this.f2186g = -1;
            this.f2188h = -1;
            this.f2190i = -1;
            this.f2192j = -1;
            this.f2194k = -1;
            this.f8045l = -1;
            this.f8046m = -1;
            this.f8047n = -1;
            this.f8048o = 0;
            this.f8035b = 0.0f;
            this.f8049p = -1;
            this.f8050q = -1;
            this.f8051r = -1;
            this.f8052s = -1;
            this.f8053t = Integer.MIN_VALUE;
            this.f8054u = Integer.MIN_VALUE;
            this.f8055v = Integer.MIN_VALUE;
            this.f8056w = Integer.MIN_VALUE;
            this.f8057x = Integer.MIN_VALUE;
            this.f8058y = Integer.MIN_VALUE;
            this.f8059z = Integer.MIN_VALUE;
            this.A = 0;
            this.f2177b = true;
            this.f2179c = true;
            this.f8036c = 0.5f;
            this.f8037d = 0.5f;
            this.f2172a = null;
            this.f8038e = 0.0f;
            this.B = 1;
            this.f8039f = -1.0f;
            this.f8040g = -1.0f;
            this.C = 0;
            this.D = 0;
            this.E = 0;
            this.F = 0;
            this.G = 0;
            this.H = 0;
            this.I = 0;
            this.J = 0;
            this.f8041h = 1.0f;
            this.f8042i = 1.0f;
            this.K = -1;
            this.L = -1;
            this.M = -1;
            this.f2181d = false;
            this.f2183e = false;
            this.f2176b = null;
            this.N = 0;
            this.f2185f = true;
            this.f2187g = true;
            this.f2189h = false;
            this.f2191i = false;
            this.f2193j = false;
            this.f2195k = false;
            this.f2196l = false;
            this.O = -1;
            this.P = -1;
            this.Q = -1;
            this.R = -1;
            this.S = Integer.MIN_VALUE;
            this.T = Integer.MIN_VALUE;
            this.f8043j = 0.5f;
            this.f2173a = new p();
            this.f2197m = false;
        }
    }
}
