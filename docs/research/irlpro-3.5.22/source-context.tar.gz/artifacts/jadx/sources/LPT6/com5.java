package LPT6;

import inet.ipaddr.com8;
import java.math.BigInteger;
import p125lPt7.qa;

/* JADX INFO: loaded from: classes.dex */
public interface com5 extends com1, qa {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com1, LPT6.com3, java.lang.Comparable
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsPrefixBlock(int i2) {
        return super.containsPrefixBlock(i2);
    }

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsSinglePrefixBlock(int i2) {
        return super.containsSinglePrefixBlock(i2);
    }

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default int getBitCount() {
        return super.getBitCount();
    }

    @Override // LPT6.com1
    /* bridge */ /* synthetic */ default BigInteger getBlockCount(int i2) {
        return super.getBlockCount(i2);
    }

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default int getByteCount() {
        return super.getByteCount();
    }

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ byte[] getBytes();

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr);

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr, int i2);

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getCount() {
        return super.getCount();
    }

    @Override // LPT6.com1, p125lPt7.oa
    com6 getDivision(int i2);

    @Override // LPT6.com1, p125lPt7.oa
    /* synthetic */ int getDivisionCount();

    @Override // LPT6.com1
    /* synthetic */ String[] getDivisionStrings();

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default int getMinPrefixLengthForBlock() {
        return super.getMinPrefixLengthForBlock();
    }

    @Override // p125lPt7.qa
    /* JADX INFO: renamed from: getNetwork */
    /* synthetic */ com8<?, ?, ?, ?, ?> mo11getNetwork();

    Integer getNetworkPrefixLength();

    @Override // LPT6.com1
    /* bridge */ /* synthetic */ default BigInteger getPrefixCount() {
        return super.getPrefixCount();
    }

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getPrefixCount(int i2) {
        return super.getPrefixCount(i2);
    }

    @Override // LPT6.com1, p125lPt7.qa
    /* synthetic */ Integer getPrefixLength();

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default Integer getPrefixLengthForSingleBlock() {
        return super.getPrefixLengthForSingleBlock();
    }

    @Override // LPT6.com1
    /* bridge */ /* synthetic */ default int getSequentialBlockIndex() {
        return super.getSequentialBlockIndex();
    }

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ byte[] getUpperBytes();

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr);

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr, int i2);

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ BigInteger getUpperValue();

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ BigInteger getValue();

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ boolean includesMax();

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ boolean includesZero();

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default boolean isFullRange() {
        return super.isFullRange();
    }

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ boolean isMax();

    @Override // LPT6.com1
    /* bridge */ /* synthetic */ default int isMore(com1 com1Var) {
        return super.isMore(com1Var);
    }

    @Override // LPT6.com1, LPT6.com3
    /* bridge */ /* synthetic */ default boolean isMultiple() {
        return super.isMultiple();
    }

    @Override // LPT6.com1, p125lPt7.qa
    /* synthetic */ boolean isPrefixBlock();

    @Override // LPT6.com1, p125lPt7.qa
    /* synthetic */ boolean isPrefixed();

    @Override // LPT6.com1
    /* bridge */ /* synthetic */ default boolean isSequential() {
        return super.isSequential();
    }

    @Override // LPT6.com1
    /* synthetic */ boolean isSinglePrefixBlock();

    @Override // LPT6.com1, LPT6.com3
    /* synthetic */ boolean isZero();
}
