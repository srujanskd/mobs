package COM3;

/* JADX INFO: loaded from: classes.dex */
public interface com1 extends com6 {
    void a(com7 com7Var);

    void b(com7 com7Var);

    void c(com7 com7Var);

    void d(com7 com7Var);

    void e(com7 com7Var);

    void g(com7 com7Var);
}
