package com.google.android.material.floatingactionbutton;

import COM6.com4;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import java.util.Iterator;
import java.util.List;
import p024Com2.y;
import p075cOM6.g4;
import p075cOM6.h4;
import p108com9.j;

/* JADX INFO: loaded from: classes.dex */
public class ExtendedFloatingActionButton extends MaterialButton implements CoordinatorLayout.con {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CoordinatorLayout.nul<ExtendedFloatingActionButton> f3523a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f3524b;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f3525d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9481e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9482f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f9483g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f9484h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f9485i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f9486j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static final int f9480k = g4.f8975t;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Property<View, Float> f9476a = new con(Float.class, "width");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Property<View, Float> f9477b = new nul(Float.class, "height");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Property<View, Float> f9478c = new prn(Float.class, "paddingStart");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Property<View, Float> f9479d = new com1(Float.class, "paddingEnd");

    public class aux extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9490b;

        public aux(com.google.android.material.floatingactionbutton.con conVar, com2 com2Var) {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f9490b = true;
            throw null;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            throw null;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            throw null;
        }
    }

    public class com1 extends Property<View, Float> {
        public com1(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(y.E(view));
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f2) {
            y.C0(view, y.F(view), view.getPaddingTop(), f2.intValue(), view.getPaddingBottom());
        }
    }

    public static abstract class com2 {
    }

    public class con extends Property<View, Float> {
        public con(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(view.getLayoutParams().width);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f2) {
            view.getLayoutParams().width = f2.intValue();
            view.requestLayout();
        }
    }

    public class nul extends Property<View, Float> {
        public nul(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(view.getLayoutParams().height);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f2) {
            view.getLayoutParams().height = f2.intValue();
            view.requestLayout();
        }
    }

    public class prn extends Property<View, Float> {
        public prn(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(View view) {
            return Float.valueOf(y.F(view));
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(View view, Float f2) {
            y.C0(view, f2.intValue(), view.getPaddingTop(), y.E(view), view.getPaddingBottom());
        }
    }

    public static /* synthetic */ com.google.android.material.floatingactionbutton.con j(ExtendedFloatingActionButton extendedFloatingActionButton) {
        extendedFloatingActionButton.getClass();
        return null;
    }

    public static /* synthetic */ com.google.android.material.floatingactionbutton.con k(ExtendedFloatingActionButton extendedFloatingActionButton) {
        extendedFloatingActionButton.getClass();
        return null;
    }

    public static /* synthetic */ com.google.android.material.floatingactionbutton.con m(ExtendedFloatingActionButton extendedFloatingActionButton) {
        extendedFloatingActionButton.getClass();
        return null;
    }

    public static /* synthetic */ com.google.android.material.floatingactionbutton.con n(ExtendedFloatingActionButton extendedFloatingActionButton) {
        extendedFloatingActionButton.getClass();
        return null;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.con
    public CoordinatorLayout.nul<ExtendedFloatingActionButton> getBehavior() {
        return this.f3523a;
    }

    public int getCollapsedPadding() {
        return (getCollapsedSize() - getIconSize()) / 2;
    }

    public int getCollapsedSize() {
        int i2 = this.f9484h;
        return i2 < 0 ? (Math.min(y.F(this), y.E(this)) * 2) + getIconSize() : i2;
    }

    public com4 getExtendMotionSpec() {
        throw null;
    }

    public com4 getHideMotionSpec() {
        throw null;
    }

    public com4 getShowMotionSpec() {
        throw null;
    }

    public com4 getShrinkMotionSpec() {
        throw null;
    }

    public final boolean o() {
        if (getVisibility() != 0) {
            return this.f9483g == 2;
        }
        return this.f9483g != 1;
    }

    @Override // com.google.android.material.button.MaterialButton, android.widget.TextView, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f3525d && TextUtils.isEmpty(getText()) && getIcon() != null) {
            this.f3525d = false;
            throw null;
        }
    }

    public final void p(com.google.android.material.floatingactionbutton.con conVar, com2 com2Var) {
        if (conVar.b()) {
            return;
        }
        if (!r()) {
            conVar.d();
            conVar.e(com2Var);
            return;
        }
        measure(0, 0);
        AnimatorSet animatorSetC = conVar.c();
        animatorSetC.addListener(new aux(conVar, com2Var));
        Iterator<Animator.AnimatorListener> it = conVar.a().iterator();
        while (it.hasNext()) {
            animatorSetC.addListener(it.next());
        }
        animatorSetC.start();
    }

    public final void q() {
        this.f3524b = getTextColors();
    }

    public final boolean r() {
        return (y.S(this) || (!o() && this.f9482f)) && !isInEditMode();
    }

    public void setAnimateShowBeforeLayout(boolean z2) {
        this.f9482f = z2;
    }

    public void setExtendMotionSpec(com4 com4Var) {
        throw null;
    }

    public void setExtendMotionSpecResource(int i2) {
        setExtendMotionSpec(com4.c(getContext(), i2));
    }

    public void setExtended(boolean z2) {
        if (this.f3525d != z2) {
            throw null;
        }
    }

    public void setHideMotionSpec(com4 com4Var) {
        throw null;
    }

    public void setHideMotionSpecResource(int i2) {
        setHideMotionSpec(com4.c(getContext(), i2));
    }

    @Override // android.widget.TextView, android.view.View
    public void setPadding(int i2, int i3, int i4, int i5) {
        super.setPadding(i2, i3, i4, i5);
        if (!this.f3525d || this.f9481e) {
            return;
        }
        this.f9485i = y.F(this);
        this.f9486j = y.E(this);
    }

    @Override // android.widget.TextView, android.view.View
    public void setPaddingRelative(int i2, int i3, int i4, int i5) {
        super.setPaddingRelative(i2, i3, i4, i5);
        if (!this.f3525d || this.f9481e) {
            return;
        }
        this.f9485i = i2;
        this.f9486j = i4;
    }

    public void setShowMotionSpec(com4 com4Var) {
        throw null;
    }

    public void setShowMotionSpecResource(int i2) {
        setShowMotionSpec(com4.c(getContext(), i2));
    }

    public void setShrinkMotionSpec(com4 com4Var) {
        throw null;
    }

    public void setShrinkMotionSpecResource(int i2) {
        setShrinkMotionSpec(com4.c(getContext(), i2));
    }

    @Override // android.widget.TextView
    public void setTextColor(int i2) {
        super.setTextColor(i2);
        q();
    }

    public static class ExtendedFloatingActionButtonBehavior<T extends ExtendedFloatingActionButton> extends CoordinatorLayout.nul<T> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public Rect f9487a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f3526a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9488b;

        public ExtendedFloatingActionButtonBehavior() {
            this.f3526a = false;
            this.f9488b = true;
        }

        public static boolean G(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.com2) {
                return ((CoordinatorLayout.com2) layoutParams).f() instanceof BottomSheetBehavior;
            }
            return false;
        }

        public void E(ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (this.f9488b) {
                ExtendedFloatingActionButton.m(extendedFloatingActionButton);
            } else {
                ExtendedFloatingActionButton.n(extendedFloatingActionButton);
            }
            extendedFloatingActionButton.p(null, null);
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: F, reason: merged with bridge method [inline-methods] */
        public boolean b(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, Rect rect) {
            return super.b(coordinatorLayout, extendedFloatingActionButton, rect);
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: H, reason: merged with bridge method [inline-methods] */
        public boolean h(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                L(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton);
                return false;
            }
            if (!G(view)) {
                return false;
            }
            M(view, extendedFloatingActionButton);
            return false;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: I, reason: merged with bridge method [inline-methods] */
        public boolean l(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, int i2) {
            List<View> listR = coordinatorLayout.r(extendedFloatingActionButton);
            int size = listR.size();
            for (int i3 = 0; i3 < size; i3++) {
                View view = listR.get(i3);
                if (!(view instanceof AppBarLayout)) {
                    if (G(view) && M(view, extendedFloatingActionButton)) {
                        break;
                    }
                } else {
                    if (L(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton)) {
                        break;
                    }
                }
            }
            coordinatorLayout.I(extendedFloatingActionButton, i2);
            return true;
        }

        public final boolean J(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            return (this.f3526a || this.f9488b) && ((CoordinatorLayout.com2) extendedFloatingActionButton.getLayoutParams()).e() == view.getId();
        }

        public void K(ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (this.f9488b) {
                ExtendedFloatingActionButton.j(extendedFloatingActionButton);
            } else {
                ExtendedFloatingActionButton.k(extendedFloatingActionButton);
            }
            extendedFloatingActionButton.p(null, null);
        }

        public final boolean L(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!J(appBarLayout, extendedFloatingActionButton)) {
                return false;
            }
            if (this.f9487a == null) {
                this.f9487a = new Rect();
            }
            Rect rect = this.f9487a;
            j.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                K(extendedFloatingActionButton);
                return true;
            }
            E(extendedFloatingActionButton);
            return true;
        }

        public final boolean M(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!J(view, extendedFloatingActionButton)) {
                return false;
            }
            if (view.getTop() < (extendedFloatingActionButton.getHeight() / 2) + ((ViewGroup.MarginLayoutParams) ((CoordinatorLayout.com2) extendedFloatingActionButton.getLayoutParams())).topMargin) {
                K(extendedFloatingActionButton);
                return true;
            }
            E(extendedFloatingActionButton);
            return true;
        }

        @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        public void g(CoordinatorLayout.com2 com2Var) {
            if (com2Var.f8163f == 0) {
                com2Var.f8163f = 80;
            }
        }

        public ExtendedFloatingActionButtonBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, h4.f3091S);
            this.f3526a = typedArrayObtainStyledAttributes.getBoolean(h4.K0, false);
            this.f9488b = typedArrayObtainStyledAttributes.getBoolean(h4.L0, true);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // android.widget.TextView
    public void setTextColor(ColorStateList colorStateList) {
        super.setTextColor(colorStateList);
        q();
    }
}
