package NUL;

import java.util.ArrayList;
import p060NUl.lpt7;
import p146nUL.l;
import p146nUL.o;
import p146nUL.p;
import p146nUL.q;
import p146nUL.r;
import p146nUL.s;
import p146nUL.u;
import p146nUL.v;
import p146nUL.w;

/* JADX INFO: loaded from: classes.dex */
public class con {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public q f1370a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ArrayList<p> f1369a = new ArrayList<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public aux f7384a = new aux();

    public static class aux {

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public static int f7385g = 0;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public static int f7386h = 1;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public static int f7387i = 2;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f7388a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public p.con f1371a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f1372a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f7389b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public p.con f1373b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f1374b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f7390c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f7391d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f7392e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f7393f;
    }

    /* JADX INFO: renamed from: NUL.con$con, reason: collision with other inner class name */
    public interface InterfaceC0018con {
        void a();

        void b(p pVar, aux auxVar);
    }

    public con(q qVar) {
        this.f1370a = qVar;
    }

    public final boolean a(InterfaceC0018con interfaceC0018con, p pVar, int i2) {
        this.f7384a.f1371a = pVar.y();
        this.f7384a.f1373b = pVar.R();
        this.f7384a.f7388a = pVar.U();
        this.f7384a.f7389b = pVar.v();
        aux auxVar = this.f7384a;
        auxVar.f1374b = false;
        auxVar.f7393f = i2;
        p.con conVar = auxVar.f1371a;
        p.con conVar2 = p.con.MATCH_CONSTRAINT;
        boolean z2 = conVar == conVar2;
        boolean z3 = auxVar.f1373b == conVar2;
        boolean z4 = z2 && pVar.f11500e > 0.0f;
        boolean z5 = z3 && pVar.f11500e > 0.0f;
        if (z4 && pVar.f4948a[0] == 4) {
            auxVar.f1371a = p.con.FIXED;
        }
        if (z5 && pVar.f4948a[1] == 4) {
            auxVar.f1373b = p.con.FIXED;
        }
        interfaceC0018con.b(pVar, auxVar);
        pVar.h1(this.f7384a.f7390c);
        pVar.I0(this.f7384a.f7391d);
        pVar.H0(this.f7384a.f1372a);
        pVar.x0(this.f7384a.f7392e);
        aux auxVar2 = this.f7384a;
        auxVar2.f7393f = aux.f7385g;
        return auxVar2.f1374b;
    }

    /* JADX WARN: Code duplicated, block: B:56:0x0097 A[PHI: r10
      0x0097: PHI (r10v2 boolean) = (r10v1 boolean), (r10v1 boolean), (r10v1 boolean), (r10v4 boolean), (r10v4 boolean) binds: [B:32:0x0061, B:34:0x0067, B:36:0x006b, B:54:0x0094, B:52:0x008d] A[DONT_GENERATE, DONT_INLINE]] */
    public final void b(q qVar) {
        boolean z2;
        com8 com8Var;
        lpt1 lpt1Var;
        int size = ((w) qVar).f11546b.size();
        boolean zP1 = qVar.P1(64);
        InterfaceC0018con interfaceC0018conF1 = qVar.F1();
        for (int i2 = 0; i2 < size; i2++) {
            p pVar = ((w) qVar).f11546b.get(i2);
            if (!(pVar instanceof r) && !(pVar instanceof l) && !pVar.j0() && (!zP1 || (com8Var = pVar.f4937a) == null || (lpt1Var = pVar.f4938a) == null || !((com2) ((lpt3) com8Var).f1381a).f1362c || !((com2) ((lpt3) lpt1Var).f1381a).f1362c)) {
                p.con conVarS = pVar.s(0);
                p.con conVarS2 = pVar.s(1);
                p.con conVar = p.con.MATCH_CONSTRAINT;
                boolean z3 = conVarS == conVar && pVar.f4974f != 1 && conVarS2 == conVar && pVar.f4977g != 1;
                if (!z3 && qVar.P1(1) && !(pVar instanceof v)) {
                    if (conVarS == conVar && pVar.f4974f == 0 && conVarS2 != conVar && !pVar.g0()) {
                        z3 = true;
                    }
                    if (conVarS2 == conVar && pVar.f4977g == 0 && conVarS != conVar && !pVar.g0()) {
                        z3 = true;
                    }
                    z2 = (!(conVarS == conVar || conVarS2 == conVar) || pVar.f11500e <= 0.0f) ? z3 : true;
                }
                if (!z2) {
                    a(interfaceC0018conF1, pVar, aux.f7385g);
                }
            }
        }
        interfaceC0018conF1.a();
    }

    public final void c(q qVar, String str, int i2, int i3, int i4) {
        int iG = qVar.G();
        int iF = qVar.F();
        qVar.X0(0);
        qVar.W0(0);
        qVar.h1(i3);
        qVar.I0(i4);
        qVar.X0(iG);
        qVar.W0(iF);
        this.f1370a.T1(i2);
        this.f1370a.p1();
    }

    public long d(q qVar, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10) {
        boolean zE1;
        int i11;
        int i12;
        boolean z2;
        int i13;
        boolean z3;
        con conVar = this;
        InterfaceC0018con interfaceC0018conF1 = qVar.F1();
        int size = ((w) qVar).f11546b.size();
        int iU = qVar.U();
        int iV = qVar.v();
        boolean zB = u.b(i2, 128);
        boolean z4 = zB || u.b(i2, 64);
        if (z4) {
            for (int i14 = 0; i14 < size; i14++) {
                p pVar = ((w) qVar).f11546b.get(i14);
                p.con conVarY = pVar.y();
                p.con conVar2 = p.con.MATCH_CONSTRAINT;
                boolean z5 = (conVarY == conVar2) && (pVar.R() == conVar2) && pVar.t() > 0.0f;
                if ((pVar.g0() && z5) || ((pVar.i0() && z5) || (pVar instanceof v) || pVar.g0() || pVar.i0())) {
                    z4 = false;
                    break;
                }
            }
        }
        if (z4) {
            boolean z6 = lpt7.f7450d;
        }
        boolean z7 = z4 & ((i5 == 1073741824 && i7 == 1073741824) || zB);
        int i15 = 2;
        if (z7) {
            int iMin = Math.min(qVar.E(), i6);
            int iMin2 = Math.min(qVar.D(), i8);
            if (i5 == 1073741824 && qVar.U() != iMin) {
                qVar.h1(iMin);
                qVar.I1();
            }
            if (i7 == 1073741824 && qVar.v() != iMin2) {
                qVar.I0(iMin2);
                qVar.I1();
            }
            if (i5 == 1073741824 && i7 == 1073741824) {
                zE1 = qVar.C1(zB);
                i11 = 2;
            } else {
                boolean zD1 = qVar.D1(zB);
                if (i5 == 1073741824) {
                    zD1 &= qVar.E1(zB, 0);
                    i11 = 1;
                } else {
                    i11 = 0;
                }
                if (i7 == 1073741824) {
                    zE1 = qVar.E1(zB, 1) & zD1;
                    i11++;
                } else {
                    zE1 = zD1;
                }
            }
            if (zE1) {
                qVar.m1(i5 == 1073741824, i7 == 1073741824);
            }
        } else {
            zE1 = false;
            i11 = 0;
        }
        if (zE1 && i11 == 2) {
            return 0L;
        }
        int iG1 = qVar.G1();
        if (size > 0) {
            b(qVar);
        }
        e(qVar);
        int size2 = conVar.f1369a.size();
        if (size > 0) {
            c(qVar, "First pass", 0, iU, iV);
        }
        if (size2 > 0) {
            p.con conVarY2 = qVar.y();
            p.con conVar3 = p.con.WRAP_CONTENT;
            boolean z8 = conVarY2 == conVar3;
            boolean z9 = qVar.R() == conVar3;
            int iMax = Math.max(qVar.U(), conVar.f1370a.G());
            int iMax2 = Math.max(qVar.v(), conVar.f1370a.F());
            int i16 = 0;
            boolean zS1 = false;
            while (i16 < size2) {
                p pVar2 = conVar.f1369a.get(i16);
                if (pVar2 instanceof v) {
                    int iU2 = pVar2.U();
                    int iV2 = pVar2.v();
                    boolean zA = conVar.a(interfaceC0018conF1, pVar2, aux.f7386h) | zS1;
                    int iU3 = pVar2.U();
                    int iV3 = pVar2.v();
                    if (iU3 != iU2) {
                        pVar2.h1(iU3);
                        if (z8 && pVar2.K() > iMax) {
                            iMax = Math.max(iMax, pVar2.K() + pVar2.m(o.con.RIGHT).e());
                        }
                        z3 = true;
                    } else {
                        z3 = zA;
                    }
                    if (iV3 != iV2) {
                        pVar2.I0(iV3);
                        if (z9 && pVar2.p() > iMax2) {
                            iMax2 = Math.max(iMax2, pVar2.p() + pVar2.m(o.con.BOTTOM).e());
                        }
                        z3 = true;
                    }
                    zS1 = z3 | ((v) pVar2).s1();
                }
                i16++;
                iG1 = iG1;
                i15 = 2;
            }
            int i17 = iG1;
            int i18 = i15;
            int i19 = 0;
            while (i19 < i18) {
                int i20 = 0;
                while (i20 < size2) {
                    p pVar3 = conVar.f1369a.get(i20);
                    if (((pVar3 instanceof s) && !(pVar3 instanceof v)) || (pVar3 instanceof r) || pVar3.T() == 8 || ((z7 && ((com2) ((lpt3) pVar3.f4937a).f1381a).f1362c && ((com2) ((lpt3) pVar3.f4938a).f1381a).f1362c) || (pVar3 instanceof v))) {
                        z2 = z7;
                        i13 = size2;
                    } else {
                        int iU4 = pVar3.U();
                        int iV4 = pVar3.v();
                        z2 = z7;
                        int iN = pVar3.n();
                        int i21 = aux.f7386h;
                        i13 = size2;
                        if (i19 == 1) {
                            i21 = aux.f7387i;
                        }
                        boolean zA2 = conVar.a(interfaceC0018conF1, pVar3, i21) | zS1;
                        int iU5 = pVar3.U();
                        int iV5 = pVar3.v();
                        if (iU5 != iU4) {
                            pVar3.h1(iU5);
                            if (z8 && pVar3.K() > iMax) {
                                iMax = Math.max(iMax, pVar3.K() + pVar3.m(o.con.RIGHT).e());
                            }
                            zA2 = true;
                        }
                        if (iV5 != iV4) {
                            pVar3.I0(iV5);
                            if (z9 && pVar3.p() > iMax2) {
                                iMax2 = Math.max(iMax2, pVar3.p() + pVar3.m(o.con.BOTTOM).e());
                            }
                            zA2 = true;
                        }
                        zS1 = (!pVar3.X() || iN == pVar3.n()) ? zA2 : true;
                    }
                    i20++;
                    conVar = this;
                    z7 = z2;
                    size2 = i13;
                }
                boolean z10 = z7;
                int i22 = size2;
                if (!zS1) {
                    break;
                }
                i19++;
                c(qVar, "intermediate pass", i19, iU, iV);
                conVar = this;
                z7 = z10;
                size2 = i22;
                i18 = 2;
                zS1 = false;
            }
            i12 = i17;
        } else {
            i12 = iG1;
        }
        qVar.S1(i12);
        return 0L;
    }

    public void e(q qVar) {
        this.f1369a.clear();
        int size = ((w) qVar).f11546b.size();
        for (int i2 = 0; i2 < size; i2++) {
            p pVar = ((w) qVar).f11546b.get(i2);
            p.con conVarY = pVar.y();
            p.con conVar = p.con.MATCH_CONSTRAINT;
            if (conVarY == conVar || pVar.R() == conVar) {
                this.f1369a.add(pVar);
            }
        }
        qVar.I1();
    }
}
