package com.google.android.material.datepicker;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListAdapter;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.Calendar;
import java.util.Iterator;
import p024Com2.y;
import p075cOM6.b4;
import p075cOM6.c4;
import p075cOM6.d4;
import p075cOM6.f4;
import p075cOM6.z3;
import p081cOm2.e2;
import p087cOm8.com9;
import p087cOm8.lpt1;
import p087cOm8.lpt3;
import p101com2.q2;

/* JADX INFO: loaded from: classes.dex */
public final class MaterialCalendar<S> extends PickerFragment {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f9426a = "MONTHS_VIEW_GROUP_TAG";

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final Object f9427b = "NAVIGATION_PREV_TAG";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Object f9428c = "NAVIGATION_NEXT_TAG";

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Object f9429d = "SELECTOR_TOGGLE_TAG";

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f3464a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f3465a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public RecyclerView f3466a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p087cOm8.com3 f3467a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p087cOm8.com4<S> f3468a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public p087cOm8.com8 f3469a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com7 f3470a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.datepicker.aux f3471a;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public View f3472b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public RecyclerView f3473b;

    public class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9430a;

        public aux(int i2) {
            this.f9430a = i2;
        }

        @Override // java.lang.Runnable
        public void run() {
            MaterialCalendar.this.f3473b.q1(this.f9430a);
        }
    }

    public class com1 extends RecyclerView.lpt1 {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final Calendar f3475a = lpt3.i();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final Calendar f9432b = lpt3.i();

        public com1() {
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt1
        public void g(Canvas canvas, RecyclerView recyclerView, RecyclerView.e eVar) {
            if ((recyclerView.getAdapter() instanceof com.google.android.material.datepicker.com1) && (recyclerView.getLayoutManager() instanceof GridLayoutManager)) {
                com.google.android.material.datepicker.com1 com1Var = (com.google.android.material.datepicker.com1) recyclerView.getAdapter();
                GridLayoutManager gridLayoutManager = (GridLayoutManager) recyclerView.getLayoutManager();
                for (q2<Long, Long> q2Var : MaterialCalendar.this.f3468a.f()) {
                    Long l2 = q2Var.f10451a;
                    if (l2 != null && q2Var.f10452b != null) {
                        this.f3475a.setTimeInMillis(l2.longValue());
                        this.f9432b.setTimeInMillis(q2Var.f10452b.longValue());
                        int iA = com1Var.A(this.f3475a.get(1));
                        int iA2 = com1Var.A(this.f9432b.get(1));
                        View viewC = gridLayoutManager.C(iA);
                        View viewC2 = gridLayoutManager.C(iA2);
                        int iX2 = iA / gridLayoutManager.X2();
                        int iX3 = iA2 / gridLayoutManager.X2();
                        int i2 = iX2;
                        while (i2 <= iX3) {
                            View viewC3 = gridLayoutManager.C(gridLayoutManager.X2() * i2);
                            if (viewC3 != null) {
                                canvas.drawRect(i2 == iX2 ? viewC.getLeft() + (viewC.getWidth() / 2) : 0, viewC3.getTop() + MaterialCalendar.this.f3467a.f9173d.c(), i2 == iX3 ? viewC2.getLeft() + (viewC2.getWidth() / 2) : recyclerView.getWidth(), viewC3.getBottom() - MaterialCalendar.this.f3467a.f9173d.b(), MaterialCalendar.this.f3467a.f9170a);
                            }
                            i2++;
                        }
                    }
                }
            }
        }
    }

    public class com2 extends p024Com2.lpt3 {
        public com2() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.e0(MaterialCalendar.this.f3472b.getVisibility() == 0 ? MaterialCalendar.this.getString(f4.A) : MaterialCalendar.this.getString(f4.f8954y));
        }
    }

    public class com3 extends RecyclerView.lpt7 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ MaterialButton f9434a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com.google.android.material.datepicker.prn f3477a;

        public com3(com.google.android.material.datepicker.prn prnVar, MaterialButton materialButton) {
            this.f3477a = prnVar;
            this.f9434a = materialButton;
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt7
        public void a(RecyclerView recyclerView, int i2) {
            if (i2 == 0) {
                recyclerView.announceForAccessibility(this.f9434a.getText());
            }
        }

        @Override // androidx.recyclerview.widget.RecyclerView.lpt7
        public void b(RecyclerView recyclerView, int i2, int i3) {
            int iZ1 = i2 < 0 ? MaterialCalendar.this.B().Z1() : MaterialCalendar.this.B().c2();
            MaterialCalendar.this.f3469a = this.f3477a.z(iZ1);
            this.f9434a.setText(this.f3477a.A(iZ1));
        }
    }

    public class com4 implements View.OnClickListener {
        public com4() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            MaterialCalendar.this.H();
        }
    }

    public class com5 implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com.google.android.material.datepicker.prn f3478a;

        public com5(com.google.android.material.datepicker.prn prnVar) {
            this.f3478a = prnVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int iZ1 = MaterialCalendar.this.B().Z1() + 1;
            if (iZ1 < MaterialCalendar.this.f3473b.getAdapter().f()) {
                MaterialCalendar.this.E(this.f3478a.z(iZ1));
            }
        }
    }

    public class com6 implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com.google.android.material.datepicker.prn f3479a;

        public com6(com.google.android.material.datepicker.prn prnVar) {
            this.f3479a = prnVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            int iC2 = MaterialCalendar.this.B().c2() - 1;
            if (iC2 >= 0) {
                MaterialCalendar.this.E(this.f3479a.z(iC2));
            }
        }
    }

    public enum com7 {
        DAY,
        YEAR
    }

    public interface com8 {
        void a(long j2);
    }

    public class con extends p024Com2.lpt3 {
        public con() {
        }

        @Override // p024Com2.lpt3
        public void g(View view, e2 e2Var) {
            super.g(view, e2Var);
            e2Var.V(null);
        }
    }

    public class nul extends lpt1 {

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public final /* synthetic */ int f9442j;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public nul(Context context, int i2, boolean z2, int i3) {
            super(context, i2, z2);
            this.f9442j = i3;
        }

        @Override // androidx.recyclerview.widget.LinearLayoutManager
        public void M1(RecyclerView.e eVar, int[] iArr) {
            if (this.f9442j == 0) {
                iArr[0] = MaterialCalendar.this.f3473b.getWidth();
                iArr[1] = MaterialCalendar.this.f3473b.getWidth();
            } else {
                iArr[0] = MaterialCalendar.this.f3473b.getHeight();
                iArr[1] = MaterialCalendar.this.f3473b.getHeight();
            }
        }
    }

    public class prn implements com8 {
        public prn() {
        }

        @Override // com.google.android.material.datepicker.MaterialCalendar.com8
        public void a(long j2) {
            if (MaterialCalendar.this.f3471a.q().d(j2)) {
                MaterialCalendar.this.f3468a.e(j2);
                Iterator<com9<Object>> it = ((PickerFragment) MaterialCalendar.this).f3506a.iterator();
                while (it.hasNext()) {
                    it.next().a(MaterialCalendar.this.f3468a.b());
                }
                MaterialCalendar.this.f3473b.getAdapter().k();
                if (MaterialCalendar.this.f3466a != null) {
                    MaterialCalendar.this.f3466a.getAdapter().k();
                }
            }
        }
    }

    public static int A(Context context) {
        Resources resources = context.getResources();
        int dimensionPixelSize = resources.getDimensionPixelSize(z3.P) + resources.getDimensionPixelOffset(z3.Q) + resources.getDimensionPixelOffset(z3.O);
        int dimensionPixelSize2 = resources.getDimensionPixelSize(z3.K);
        int i2 = com.google.android.material.datepicker.nul.f9472a;
        return dimensionPixelSize + dimensionPixelSize2 + (resources.getDimensionPixelSize(z3.I) * i2) + ((i2 - 1) * resources.getDimensionPixelOffset(z3.N)) + resources.getDimensionPixelOffset(z3.G);
    }

    public static <T> MaterialCalendar<T> C(p087cOm8.com4<T> com4Var, int i2, com.google.android.material.datepicker.aux auxVar) {
        MaterialCalendar<T> materialCalendar = new MaterialCalendar<>();
        Bundle bundle = new Bundle();
        bundle.putInt("THEME_RES_ID_KEY", i2);
        bundle.putParcelable("GRID_SELECTOR_KEY", com4Var);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", auxVar);
        bundle.putParcelable("CURRENT_MONTH_KEY", auxVar.t());
        materialCalendar.setArguments(bundle);
        return materialCalendar;
    }

    public static int z(Context context) {
        return context.getResources().getDimensionPixelSize(z3.I);
    }

    public LinearLayoutManager B() {
        return (LinearLayoutManager) this.f3473b.getLayoutManager();
    }

    public final void D(int i2) {
        this.f3473b.post(new aux(i2));
    }

    public void E(p087cOm8.com8 com8Var) {
        com.google.android.material.datepicker.prn prnVar = (com.google.android.material.datepicker.prn) this.f3473b.getAdapter();
        int iB = prnVar.B(com8Var);
        int iB2 = iB - prnVar.B(this.f3469a);
        boolean z2 = Math.abs(iB2) > 3;
        boolean z3 = iB2 > 0;
        this.f3469a = com8Var;
        if (z2 && z3) {
            this.f3473b.i1(iB - 3);
            D(iB);
        } else if (!z2) {
            D(iB);
        } else {
            this.f3473b.i1(iB + 3);
            D(iB);
        }
    }

    public void F(com7 com7Var) {
        this.f3470a = com7Var;
        if (com7Var == com7.YEAR) {
            this.f3466a.getLayoutManager().x1(((com.google.android.material.datepicker.com1) this.f3466a.getAdapter()).A(this.f3469a.f9181b));
            this.f3465a.setVisibility(0);
            this.f3472b.setVisibility(8);
        } else if (com7Var == com7.DAY) {
            this.f3465a.setVisibility(8);
            this.f3472b.setVisibility(0);
            E(this.f3469a);
        }
    }

    public void H() {
        com7 com7Var = this.f3470a;
        com7 com7Var2 = com7.YEAR;
        if (com7Var == com7Var2) {
            F(com7.DAY);
        } else if (com7Var == com7.DAY) {
            F(com7Var2);
        }
    }

    @Override // com.google.android.material.datepicker.PickerFragment
    public boolean j(com9<S> com9Var) {
        return super.j(com9Var);
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle == null) {
            bundle = getArguments();
        }
        this.f3464a = bundle.getInt("THEME_RES_ID_KEY");
        this.f3468a = (p087cOm8.com4) bundle.getParcelable("GRID_SELECTOR_KEY");
        this.f3471a = (com.google.android.material.datepicker.aux) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
        this.f3469a = (p087cOm8.com8) bundle.getParcelable("CURRENT_MONTH_KEY");
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i2;
        int i3;
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(getContext(), this.f3464a);
        this.f3467a = new p087cOm8.com3(contextThemeWrapper);
        LayoutInflater layoutInflaterCloneInContext = layoutInflater.cloneInContext(contextThemeWrapper);
        p087cOm8.com8 com8VarU = this.f3471a.u();
        if (MaterialDatePicker.A(contextThemeWrapper)) {
            i2 = d4.f8925s;
            i3 = 1;
        } else {
            i2 = d4.f8923q;
            i3 = 0;
        }
        View viewInflate = layoutInflaterCloneInContext.inflate(i2, viewGroup, false);
        viewInflate.setMinimumHeight(A(requireContext()));
        GridView gridView = (GridView) viewInflate.findViewById(b4.H);
        y.o0(gridView, new con());
        gridView.setAdapter((ListAdapter) new p087cOm8.com6());
        gridView.setNumColumns(com8VarU.f9182c);
        gridView.setEnabled(false);
        this.f3473b = (RecyclerView) viewInflate.findViewById(b4.K);
        this.f3473b.setLayoutManager(new nul(getContext(), i3, false, i3));
        this.f3473b.setTag(f9426a);
        com.google.android.material.datepicker.prn prnVar = new com.google.android.material.datepicker.prn(contextThemeWrapper, this.f3468a, this.f3471a, new prn());
        this.f3473b.setAdapter(prnVar);
        int integer = contextThemeWrapper.getResources().getInteger(c4.f8906c);
        RecyclerView recyclerView = (RecyclerView) viewInflate.findViewById(b4.L);
        this.f3466a = recyclerView;
        if (recyclerView != null) {
            recyclerView.setHasFixedSize(true);
            this.f3466a.setLayoutManager(new GridLayoutManager((Context) contextThemeWrapper, integer, 1, false));
            this.f3466a.setAdapter(new com.google.android.material.datepicker.com1(this));
            this.f3466a.h(t());
        }
        if (viewInflate.findViewById(b4.B) != null) {
            s(viewInflate, prnVar);
        }
        if (!MaterialDatePicker.A(contextThemeWrapper)) {
            new androidx.recyclerview.widget.com6().b(this.f3473b);
        }
        this.f3473b.i1(prnVar.B(this.f3469a));
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("THEME_RES_ID_KEY", this.f3464a);
        bundle.putParcelable("GRID_SELECTOR_KEY", this.f3468a);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", this.f3471a);
        bundle.putParcelable("CURRENT_MONTH_KEY", this.f3469a);
    }

    public final void s(View view, com.google.android.material.datepicker.prn prnVar) {
        MaterialButton materialButton = (MaterialButton) view.findViewById(b4.B);
        materialButton.setTag(f9429d);
        y.o0(materialButton, new com2());
        MaterialButton materialButton2 = (MaterialButton) view.findViewById(b4.D);
        materialButton2.setTag(f9427b);
        MaterialButton materialButton3 = (MaterialButton) view.findViewById(b4.C);
        materialButton3.setTag(f9428c);
        this.f3465a = view.findViewById(b4.L);
        this.f3472b = view.findViewById(b4.G);
        F(com7.DAY);
        materialButton.setText(this.f3469a.t());
        this.f3473b.k(new com3(prnVar, materialButton));
        materialButton.setOnClickListener(new com4());
        materialButton3.setOnClickListener(new com5(prnVar));
        materialButton2.setOnClickListener(new com6(prnVar));
    }

    public final RecyclerView.lpt1 t() {
        return new com1();
    }

    public com.google.android.material.datepicker.aux v() {
        return this.f3471a;
    }

    public p087cOm8.com3 w() {
        return this.f3467a;
    }

    public p087cOm8.com8 x() {
        return this.f3469a;
    }

    public p087cOm8.com4<S> y() {
        return this.f3468a;
    }
}
