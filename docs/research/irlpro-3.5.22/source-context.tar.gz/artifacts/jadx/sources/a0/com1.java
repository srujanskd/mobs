package a0;

import f.com8;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import p059Lpt9.a;
import p127lPt9.a0;
import v.c;
import v.e;
import v.g;
import v.lpt3;
import v.lpt5;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
public final class com1 implements v.com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final nul f7593a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com2 f1549a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com3 f1550a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public a0.nul f1551a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public prn f1552a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Object f1553a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AtomicBoolean f1554a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final c f1555a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final e f1556a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final lpt5 f1557a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public volatile com2 f7594b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public volatile a0.nul f1558b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final boolean f1559b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f7595c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f7596d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f7597e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f7598f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public volatile boolean f7599g;

    public final class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ com1 f7600a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public volatile AtomicInteger f1560a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final v.com2 f1561a;

        public aux(com1 com1Var, v.com2 com2Var) {
            com8.e(com1Var, "this$0");
            com8.e(com2Var, "responseCallback");
            this.f7600a = com1Var;
            this.f1561a = com2Var;
            this.f1560a = new AtomicInteger(0);
        }

        public final void a(ExecutorService executorService) {
            com8.e(executorService, "executorService");
            lpt3 lpt3VarK = this.f7600a.j().k();
            if (w.com1.f5458a && Thread.holdsLock(lpt3VarK)) {
                throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST NOT hold lock on " + lpt3VarK);
            }
            try {
                try {
                    executorService.execute(this);
                } catch (RejectedExecutionException e2) {
                    InterruptedIOException interruptedIOException = new InterruptedIOException("executor rejected");
                    interruptedIOException.initCause(e2);
                    this.f7600a.s(interruptedIOException);
                    this.f1561a.onFailure(this.f7600a, interruptedIOException);
                    this.f7600a.j().k().f(this);
                }
            } catch (Throwable th) {
                this.f7600a.j().k().f(this);
                throw th;
            }
        }

        public final com1 b() {
            return this.f7600a;
        }

        public final AtomicInteger c() {
            return this.f1560a;
        }

        public final String d() {
            return this.f7600a.o().i().h();
        }

        public final void e(aux auxVar) {
            com8.e(auxVar, "other");
            this.f1560a = auxVar.f1560a;
        }

        @Override // java.lang.Runnable
        public void run() {
            boolean z2;
            Throwable th;
            IOException e2;
            lpt3 lpt3VarK;
            String strK = com8.k("OkHttp ", this.f7600a.t());
            com1 com1Var = this.f7600a;
            Thread threadCurrentThread = Thread.currentThread();
            String name = threadCurrentThread.getName();
            threadCurrentThread.setName(strK);
            try {
                com1Var.f7593a.t();
                try {
                    try {
                        z2 = true;
                        try {
                            this.f1561a.onResponse(com1Var, com1Var.p());
                            lpt3VarK = com1Var.j().k();
                        } catch (IOException e3) {
                            e2 = e3;
                            if (z2) {
                                e0.com6.f10703a.g().j(com8.k("Callback failure for ", com1Var.A()), 4, e2);
                            } else {
                                this.f1561a.onFailure(com1Var, e2);
                            }
                            lpt3VarK = com1Var.j().k();
                        } catch (Throwable th2) {
                            th = th2;
                            com1Var.cancel();
                            if (!z2) {
                                IOException iOException = new IOException(com8.k("canceled due to ", th));
                                p059Lpt9.com6.a(iOException, th);
                                this.f1561a.onFailure(com1Var, iOException);
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        com1Var.j().k().f(this);
                        throw th3;
                    }
                } catch (IOException e4) {
                    z2 = false;
                    e2 = e4;
                } catch (Throwable th4) {
                    z2 = false;
                    th = th4;
                }
                lpt3VarK.f(this);
                threadCurrentThread.setName(name);
            } catch (Throwable th5) {
                threadCurrentThread.setName(name);
                throw th5;
            }
        }
    }

    public static final class con extends WeakReference<com1> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Object f7601a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public con(com1 com1Var, Object obj) {
            super(com1Var);
            com8.e(com1Var, "referent");
            this.f7601a = obj;
        }

        public final Object a() {
            return this.f7601a;
        }
    }

    public static final class nul extends i0.aux {
        public nul() {
        }

        @Override // i0.aux
        public void z() {
            com1.this.cancel();
        }
    }

    public com1(c cVar, e eVar, boolean z2) {
        com8.e(cVar, "client");
        com8.e(eVar, "originalRequest");
        this.f1555a = cVar;
        this.f1556a = eVar;
        this.f1559b = z2;
        this.f1550a = cVar.h().a();
        this.f1557a = cVar.m().a(this);
        nul nulVar = new nul();
        nulVar.g(j().e(), TimeUnit.MILLISECONDS);
        this.f7593a = nulVar;
        this.f1554a = new AtomicBoolean();
        this.f7598f = true;
    }

    public final String A() {
        StringBuilder sb = new StringBuilder();
        sb.append(isCanceled() ? "canceled " : "");
        sb.append(this.f1559b ? "web socket" : "call");
        sb.append(" to ");
        sb.append(t());
        return sb.toString();
    }

    public final void c(com2 com2Var) {
        com8.e(com2Var, "connection");
        if (!w.com1.f5458a || Thread.holdsLock(com2Var)) {
            if (!(this.f1549a == null)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            this.f1549a = com2Var;
            com2Var.n().add(new con(this, this.f1553a));
            return;
        }
        throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + com2Var);
    }

    @Override // v.com1
    public void cancel() {
        if (this.f7599g) {
            return;
        }
        this.f7599g = true;
        a0.nul nulVar = this.f1558b;
        if (nulVar != null) {
            nulVar.b();
        }
        com2 com2Var = this.f7594b;
        if (com2Var != null) {
            com2Var.d();
        }
        this.f1557a.f(this);
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final <E extends IOException> E d(E e2) {
        Socket socketU;
        boolean z2 = w.com1.f5458a;
        if (z2 && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST NOT hold lock on " + this);
        }
        com2 com2Var = this.f1549a;
        if (com2Var != null) {
            if (z2 && Thread.holdsLock(com2Var)) {
                throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST NOT hold lock on " + com2Var);
            }
            synchronized (com2Var) {
                socketU = u();
            }
            if (this.f1549a == null) {
                if (socketU != null) {
                    w.com1.n(socketU);
                }
                this.f1557a.k(this, com2Var);
            } else {
                if (!(socketU == null)) {
                    throw new IllegalStateException("Check failed.".toString());
                }
            }
        }
        E e3 = (E) z(e2);
        if (e2 != null) {
            lpt5 lpt5Var = this.f1557a;
            com8.b(e3);
            lpt5Var.d(this, e3);
        } else {
            this.f1557a.c(this);
        }
        return e3;
    }

    public final void e() {
        this.f1553a = e0.com6.f10703a.g().h("response.body().close()");
        this.f1557a.e(this);
    }

    @Override // v.com1
    public void enqueue(v.com2 com2Var) {
        com8.e(com2Var, "responseCallback");
        if (!this.f1554a.compareAndSet(false, true)) {
            throw new IllegalStateException("Already Executed".toString());
        }
        e();
        this.f1555a.k().a(new aux(this, com2Var));
    }

    @Override // v.com1
    public g execute() {
        if (!this.f1554a.compareAndSet(false, true)) {
            throw new IllegalStateException("Already Executed".toString());
        }
        this.f7593a.t();
        e();
        try {
            this.f1555a.k().b(this);
            return p();
        } finally {
            this.f1555a.k().g(this);
        }
    }

    @Override // v.com1
    /* JADX INFO: renamed from: f, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public com1 mo1clone() {
        return new com1(this.f1555a, this.f1556a, this.f1559b);
    }

    public final v.aux g(lpt9 lpt9Var) {
        SSLSocketFactory sSLSocketFactoryC;
        HostnameVerifier hostnameVerifierQ;
        v.com3 com3VarF;
        if (lpt9Var.i()) {
            sSLSocketFactoryC = this.f1555a.C();
            hostnameVerifierQ = this.f1555a.q();
            com3VarF = this.f1555a.f();
        } else {
            sSLSocketFactoryC = null;
            hostnameVerifierQ = null;
            com3VarF = null;
        }
        return new v.aux(lpt9Var.h(), lpt9Var.m(), this.f1555a.l(), this.f1555a.B(), sSLSocketFactoryC, hostnameVerifierQ, com3VarF, this.f1555a.x(), this.f1555a.w(), this.f1555a.v(), this.f1555a.i(), this.f1555a.y());
    }

    public final void h(e eVar, boolean z2) {
        com8.e(eVar, "request");
        if (!(this.f1551a == null)) {
            throw new IllegalStateException("Check failed.".toString());
        }
        synchronized (this) {
            if (!(!this.f7597e)) {
                throw new IllegalStateException("cannot make a new request because the previous response is still open: please call response.close()".toString());
            }
            if (!(!this.f7596d)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            a aVar = a.f7353a;
        }
        if (z2) {
            this.f1552a = new prn(this.f1550a, g(eVar.i()), this, this.f1557a);
        }
    }

    public final void i(boolean z2) {
        a0.nul nulVar;
        synchronized (this) {
            if (!this.f7598f) {
                throw new IllegalStateException("released".toString());
            }
            a aVar = a.f7353a;
        }
        if (z2 && (nulVar = this.f1558b) != null) {
            nulVar.d();
        }
        this.f1551a = null;
    }

    @Override // v.com1
    public boolean isCanceled() {
        return this.f7599g;
    }

    public final c j() {
        return this.f1555a;
    }

    public final com2 k() {
        return this.f1549a;
    }

    public final lpt5 l() {
        return this.f1557a;
    }

    public final boolean m() {
        return this.f1559b;
    }

    public final a0.nul n() {
        return this.f1551a;
    }

    public final e o() {
        return this.f1556a;
    }

    /* JADX WARN: Code duplicated, block: B:24:0x00a2  */
    public final g p() throws Throwable {
        ArrayList arrayList = new ArrayList();
        a0.p(arrayList, this.f1555a.r());
        arrayList.add(new b0.com6(this.f1555a));
        arrayList.add(new b0.aux(this.f1555a.j()));
        this.f1555a.d();
        arrayList.add(new y.aux(null));
        arrayList.add(a0.aux.f7592a);
        if (!this.f1559b) {
            a0.p(arrayList, this.f1555a.s());
        }
        arrayList.add(new b0.con(this.f1559b));
        boolean z2 = false;
        try {
            g gVarB = new b0.com3(this, arrayList, 0, null, this.f1556a, this.f1555a.g(), this.f1555a.z(), this.f1555a.E()).b(this.f1556a);
            if (isCanceled()) {
                w.com1.m(gVarB);
                throw new IOException("Canceled");
            }
            s(null);
            return gVarB;
        } catch (IOException e2) {
            try {
                IOException iOExceptionS = s(e2);
                if (iOExceptionS == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Throwable");
                }
                throw iOExceptionS;
            } catch (Throwable th) {
                th = th;
                z2 = true;
                if (!z2) {
                    s(null);
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
            if (!z2) {
                s(null);
            }
            throw th;
        }
    }

    public final a0.nul q(b0.com3 com3Var) throws IOException {
        com8.e(com3Var, "chain");
        synchronized (this) {
            if (!this.f7598f) {
                throw new IllegalStateException("released".toString());
            }
            if (!(!this.f7597e)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            if (!(!this.f7596d)) {
                throw new IllegalStateException("Check failed.".toString());
            }
            a aVar = a.f7353a;
        }
        prn prnVar = this.f1552a;
        com8.b(prnVar);
        a0.nul nulVar = new a0.nul(this, this.f1557a, prnVar, prnVar.a(this.f1555a, com3Var));
        this.f1551a = nulVar;
        this.f1558b = nulVar;
        synchronized (this) {
            this.f7596d = true;
            this.f7597e = true;
        }
        if (this.f7599g) {
            throw new IOException("Canceled");
        }
        return nulVar;
    }

    /* JADX WARN: Code duplicated, block: B:16:0x001f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:17:0x0021 A[Catch: all -> 0x0017, TryCatch #0 {all -> 0x0017, blocks: (B:8:0x0012, B:17:0x0021, B:19:0x0025, B:20:0x0027, B:22:0x002c, B:27:0x0035, B:29:0x0039, B:34:0x0042, B:14:0x001b), top: B:47:0x0012 }] */
    /* JADX WARN: Code duplicated, block: B:19:0x0025 A[Catch: all -> 0x0017, TryCatch #0 {all -> 0x0017, blocks: (B:8:0x0012, B:17:0x0021, B:19:0x0025, B:20:0x0027, B:22:0x002c, B:27:0x0035, B:29:0x0039, B:34:0x0042, B:14:0x001b), top: B:47:0x0012 }] */
    /* JADX WARN: Code duplicated, block: B:25:0x0032  */
    public final <E extends IOException> E r(a0.nul nulVar, boolean z2, boolean z3, E e2) {
        boolean z4;
        boolean z5;
        boolean z6;
        boolean z7;
        com8.e(nulVar, "exchange");
        if (!com8.a(nulVar, this.f1558b)) {
            return e2;
        }
        synchronized (this) {
            z4 = false;
            if (z2) {
                try {
                    if (this.f7596d) {
                        if (z2) {
                            this.f7596d = false;
                        }
                        if (z3) {
                            this.f7597e = false;
                        }
                        z6 = this.f7596d;
                        if (z6) {
                            z7 = false;
                        } else {
                            z7 = false;
                        }
                        if (!z6) {
                            z4 = true;
                        }
                        z5 = z4;
                        z4 = z7;
                    } else if (z3 || !this.f7597e) {
                        z5 = false;
                    } else {
                        if (z2) {
                            this.f7596d = false;
                        }
                        if (z3) {
                            this.f7597e = false;
                        }
                        z6 = this.f7596d;
                        if (z6 || this.f7597e) {
                            z7 = false;
                        } else {
                            z7 = true;
                        }
                        if (!z6 && !this.f7597e && !this.f7598f) {
                            z4 = true;
                        }
                        z5 = z4;
                        z4 = z7;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            } else {
                if (z3) {
                }
                z5 = false;
            }
            a aVar = a.f7353a;
        }
        if (z4) {
            this.f1558b = null;
            com2 com2Var = this.f1549a;
            if (com2Var != null) {
                com2Var.s();
            }
        }
        return z5 ? (E) d(e2) : e2;
    }

    @Override // v.com1
    public e request() {
        return this.f1556a;
    }

    public final IOException s(IOException iOException) {
        boolean z2;
        synchronized (this) {
            z2 = false;
            if (this.f7598f) {
                this.f7598f = false;
                if (!this.f7596d && !this.f7597e) {
                    z2 = true;
                }
            }
            a aVar = a.f7353a;
        }
        return z2 ? d(iOException) : iOException;
    }

    public final String t() {
        return this.f1556a.i().o();
    }

    public final Socket u() {
        com2 com2Var = this.f1549a;
        com8.b(com2Var);
        if (w.com1.f5458a && !Thread.holdsLock(com2Var)) {
            throw new AssertionError("Thread " + ((Object) Thread.currentThread().getName()) + " MUST hold lock on " + com2Var);
        }
        List<Reference<com1>> listN = com2Var.n();
        Iterator<Reference<com1>> it = listN.iterator();
        int i2 = 0;
        while (true) {
            if (!it.hasNext()) {
                i2 = -1;
                break;
            }
            if (com8.a(it.next().get(), this)) {
                break;
            }
            i2++;
        }
        if (!(i2 != -1)) {
            throw new IllegalStateException("Check failed.".toString());
        }
        listN.remove(i2);
        this.f1549a = null;
        if (listN.isEmpty()) {
            com2Var.B(System.nanoTime());
            if (this.f1550a.c(com2Var)) {
                return com2Var.D();
            }
        }
        return null;
    }

    public final boolean v() {
        prn prnVar = this.f1552a;
        com8.b(prnVar);
        return prnVar.e();
    }

    public final void w(com2 com2Var) {
        this.f7594b = com2Var;
    }

    @Override // v.com1
    /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
    public i0.aux timeout() {
        return this.f7593a;
    }

    public final void y() {
        if (!(!this.f7595c)) {
            throw new IllegalStateException("Check failed.".toString());
        }
        this.f7595c = true;
        this.f7593a.u();
    }

    public final <E extends IOException> E z(E e2) {
        if (this.f7595c || !this.f7593a.u()) {
            return e2;
        }
        InterruptedIOException interruptedIOException = new InterruptedIOException("timeout");
        if (e2 != null) {
            interruptedIOException.initCause(e2);
        }
        return interruptedIOException;
    }
}
