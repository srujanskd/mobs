package androidx.preference;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import p016CoM4.lpt7;
import p100com1.l0;
import p147nUl.d0;

/* JADX INFO: loaded from: classes.dex */
public abstract class PreferenceGroup extends Preference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f8457a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Handler f2654a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Runnable f2655a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final List<Preference> f2656a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final d0<String, Long> f2657a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f8458b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2658b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f8459c;

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            synchronized (this) {
                PreferenceGroup.this.f2657a.clear();
            }
        }
    }

    public interface con {
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.f2657a = new d0<>();
        this.f2654a = new Handler(Looper.getMainLooper());
        this.f2658b = true;
        this.f8457a = 0;
        this.f8459c = false;
        this.f8458b = Preference.DEFAULT_ORDER;
        this.f2655a = new aux();
        this.f2656a = new ArrayList();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, lpt7.f537j, i2, i3);
        int i4 = lpt7.s0;
        this.f2658b = l0.b(typedArrayObtainStyledAttributes, i4, i4, true);
        int i5 = lpt7.r0;
        if (typedArrayObtainStyledAttributes.hasValue(i5)) {
            m(l0.d(typedArrayObtainStyledAttributes, i5, i5, Preference.DEFAULT_ORDER));
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public void a(Preference preference) {
        b(preference);
    }

    public boolean b(Preference preference) {
        long jG;
        if (this.f2656a.contains(preference)) {
            return true;
        }
        if (preference.getKey() != null) {
            PreferenceGroup parent = this;
            while (parent.getParent() != null) {
                parent = parent.getParent();
            }
            String key = preference.getKey();
            if (parent.c(key) != null) {
                Log.e("PreferenceGroup", "Found duplicated key: \"" + key + "\". This can cause unintended behaviour, please use unique keys for every preference.");
            }
        }
        if (preference.getOrder() == Integer.MAX_VALUE) {
            if (this.f2658b) {
                int i2 = this.f8457a;
                this.f8457a = i2 + 1;
                preference.setOrder(i2);
            }
            if (preference instanceof PreferenceGroup) {
                ((PreferenceGroup) preference).n(this.f2658b);
            }
        }
        int iBinarySearch = Collections.binarySearch(this.f2656a, preference);
        if (iBinarySearch < 0) {
            iBinarySearch = (iBinarySearch * (-1)) - 1;
        }
        if (!i(preference)) {
            return false;
        }
        synchronized (this) {
            this.f2656a.add(iBinarySearch, preference);
        }
        androidx.preference.nul preferenceManager = getPreferenceManager();
        String key2 = preference.getKey();
        if (key2 == null || !this.f2657a.containsKey(key2)) {
            jG = preferenceManager.g();
        } else {
            jG = this.f2657a.get(key2).longValue();
            this.f2657a.remove(key2);
        }
        preference.onAttachedToHierarchy(preferenceManager, jG);
        preference.assignParent(this);
        if (this.f8459c) {
            preference.onAttached();
        }
        notifyHierarchyChanged();
        return true;
    }

    public <T extends Preference> T c(CharSequence charSequence) {
        T t2;
        if (charSequence == null) {
            throw new IllegalArgumentException("Key cannot be null");
        }
        if (TextUtils.equals(getKey(), charSequence)) {
            return this;
        }
        int iG = g();
        for (int i2 = 0; i2 < iG; i2++) {
            PreferenceGroup preferenceGroup = (T) f(i2);
            if (TextUtils.equals(preferenceGroup.getKey(), charSequence)) {
                return preferenceGroup;
            }
            if ((preferenceGroup instanceof PreferenceGroup) && (t2 = (T) preferenceGroup.c(charSequence)) != null) {
                return t2;
            }
        }
        return null;
    }

    public int d() {
        return this.f8458b;
    }

    @Override // androidx.preference.Preference
    public void dispatchRestoreInstanceState(Bundle bundle) {
        super.dispatchRestoreInstanceState(bundle);
        int iG = g();
        for (int i2 = 0; i2 < iG; i2++) {
            f(i2).dispatchRestoreInstanceState(bundle);
        }
    }

    @Override // androidx.preference.Preference
    public void dispatchSaveInstanceState(Bundle bundle) {
        super.dispatchSaveInstanceState(bundle);
        int iG = g();
        for (int i2 = 0; i2 < iG; i2++) {
            f(i2).dispatchSaveInstanceState(bundle);
        }
    }

    public con e() {
        return null;
    }

    public Preference f(int i2) {
        return this.f2656a.get(i2);
    }

    public int g() {
        return this.f2656a.size();
    }

    public boolean h() {
        return true;
    }

    public boolean i(Preference preference) {
        preference.onParentChanged(this, shouldDisableDependents());
        return true;
    }

    public void j() {
        synchronized (this) {
            List<Preference> list = this.f2656a;
            for (int size = list.size() - 1; size >= 0; size--) {
                l(list.get(0));
            }
        }
        notifyHierarchyChanged();
    }

    public final boolean l(Preference preference) {
        boolean zRemove;
        synchronized (this) {
            preference.onPrepareForRemoval();
            if (preference.getParent() == this) {
                preference.assignParent(null);
            }
            zRemove = this.f2656a.remove(preference);
            if (zRemove) {
                String key = preference.getKey();
                if (key != null) {
                    this.f2657a.put(key, Long.valueOf(preference.getId()));
                    this.f2654a.removeCallbacks(this.f2655a);
                    this.f2654a.post(this.f2655a);
                }
                if (this.f8459c) {
                    preference.onDetached();
                }
            }
        }
        return zRemove;
    }

    public void m(int i2) {
        if (i2 != Integer.MAX_VALUE && !hasKey()) {
            Log.e("PreferenceGroup", getClass().getSimpleName() + " should have a key defined if it contains an expandable preference");
        }
        this.f8458b = i2;
    }

    public void n(boolean z2) {
        this.f2658b = z2;
    }

    @Override // androidx.preference.Preference
    public void notifyDependencyChange(boolean z2) {
        super.notifyDependencyChange(z2);
        int iG = g();
        for (int i2 = 0; i2 < iG; i2++) {
            f(i2).onParentChanged(this, z2);
        }
    }

    public void o() {
        synchronized (this) {
            Collections.sort(this.f2656a);
        }
    }

    @Override // androidx.preference.Preference
    public void onAttached() {
        super.onAttached();
        this.f8459c = true;
        int iG = g();
        for (int i2 = 0; i2 < iG; i2++) {
            f(i2).onAttached();
        }
    }

    @Override // androidx.preference.Preference
    public void onDetached() {
        super.onDetached();
        this.f8459c = false;
        int iG = g();
        for (int i2 = 0; i2 < iG; i2++) {
            f(i2).onDetached();
        }
    }

    @Override // androidx.preference.Preference
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable == null || !parcelable.getClass().equals(nul.class)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        nul nulVar = (nul) parcelable;
        this.f8458b = nulVar.f8461a;
        super.onRestoreInstanceState(nulVar.getSuperState());
    }

    @Override // androidx.preference.Preference
    public Parcelable onSaveInstanceState() {
        return new nul(super.onSaveInstanceState(), this.f8458b);
    }

    public static class nul extends Preference.con {
        public static final Parcelable.Creator<nul> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f8461a;

        public class aux implements Parcelable.Creator<nul> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public nul createFromParcel(Parcel parcel) {
                return new nul(parcel);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public nul[] newArray(int i2) {
                return new nul[i2];
            }
        }

        public nul(Parcel parcel) {
            super(parcel);
            this.f8461a = parcel.readInt();
        }

        @Override // android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f8461a);
        }

        public nul(Parcelable parcelable, int i2) {
            super(parcelable);
            this.f8461a = i2;
        }
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet, int i2) {
        this(context, attributeSet, i2, 0);
    }

    public PreferenceGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }
}
