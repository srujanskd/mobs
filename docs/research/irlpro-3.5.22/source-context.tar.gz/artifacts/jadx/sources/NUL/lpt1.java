package NUL;

import p146nUL.o;
import p146nUL.p;
import p146nUL.s;

/* JADX INFO: loaded from: classes.dex */
public class lpt1 extends lpt3 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public com3 f7394b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public com2 f7395c;

    public static /* synthetic */ class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final /* synthetic */ int[] f7396a;

        static {
            int[] iArr = new int[lpt3.con.values().length];
            f7396a = iArr;
            try {
                iArr[lpt3.con.START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f7396a[lpt3.con.END.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f7396a[lpt3.con.CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public lpt1(p pVar) {
        super(pVar);
        com2 com2Var = new com2(this);
        this.f7395c = com2Var;
        this.f7394b = null;
        ((lpt3) this).f1380a.f1354a = com2.aux.TOP;
        ((lpt3) this).f1387b.f1354a = com2.aux.BOTTOM;
        com2Var.f1354a = com2.aux.BASELINE;
        ((lpt3) this).f7408b = 1;
    }

    @Override // NUL.lpt3, NUL.prn
    public void a(prn prnVar) {
        float f2;
        float fT;
        float fT2;
        int i2;
        int i3 = aux.f7396a[((lpt3) this).f1383a.ordinal()];
        if (i3 == 1) {
            p(prnVar);
        } else if (i3 == 2) {
            o(prnVar);
        } else if (i3 == 3) {
            p pVar = ((lpt3) this).f1385a;
            n(prnVar, pVar.f4957b, pVar.f4969d, 1);
            return;
        }
        com3 com3Var = ((lpt3) this).f1381a;
        if (((com2) com3Var).f1361b && !((com2) com3Var).f1362c && ((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT) {
            p pVar2 = ((lpt3) this).f1385a;
            int i4 = pVar2.f4977g;
            if (i4 == 2) {
                p pVarI = pVar2.I();
                if (pVarI != null) {
                    com3 com3Var2 = ((lpt3) pVarI.f4938a).f1381a;
                    if (((com2) com3Var2).f1362c) {
                        ((lpt3) this).f1381a.d((int) ((((com2) com3Var2).f7365b * ((lpt3) this).f1385a.f11497b) + 0.5f));
                    }
                }
            } else if (i4 == 3 && ((com2) ((lpt3) pVar2.f4937a).f1381a).f1362c) {
                int iU = pVar2.u();
                if (iU != -1) {
                    if (iU == 0) {
                        p pVar3 = ((lpt3) this).f1385a;
                        fT2 = ((com2) ((lpt3) pVar3.f4937a).f1381a).f7365b * pVar3.t();
                        i2 = (int) (fT2 + 0.5f);
                    } else if (iU != 1) {
                        i2 = 0;
                    } else {
                        p pVar4 = ((lpt3) this).f1385a;
                        f2 = ((com2) ((lpt3) pVar4.f4937a).f1381a).f7365b;
                        fT = pVar4.t();
                    }
                    ((lpt3) this).f1381a.d(i2);
                } else {
                    p pVar5 = ((lpt3) this).f1385a;
                    f2 = ((com2) ((lpt3) pVar5.f4937a).f1381a).f7365b;
                    fT = pVar5.t();
                }
                fT2 = f2 / fT;
                i2 = (int) (fT2 + 0.5f);
                ((lpt3) this).f1381a.d(i2);
            }
        }
        com2 com2Var = ((lpt3) this).f1380a;
        if (com2Var.f1361b) {
            com2 com2Var2 = ((lpt3) this).f1387b;
            if (com2Var2.f1361b) {
                if (com2Var.f1362c && com2Var2.f1362c && ((com2) ((lpt3) this).f1381a).f1362c) {
                    return;
                }
                if (!((com2) ((lpt3) this).f1381a).f1362c && ((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT) {
                    p pVar6 = ((lpt3) this).f1385a;
                    if (pVar6.f4974f == 0 && !pVar6.i0()) {
                        com2 com2Var3 = ((lpt3) this).f1380a.f1360b.get(0);
                        com2 com2Var4 = ((lpt3) this).f1387b.f1360b.get(0);
                        int i5 = com2Var3.f7365b;
                        com2 com2Var5 = ((lpt3) this).f1380a;
                        int i6 = i5 + com2Var5.f7364a;
                        int i7 = com2Var4.f7365b + ((lpt3) this).f1387b.f7364a;
                        com2Var5.d(i6);
                        ((lpt3) this).f1387b.d(i7);
                        ((lpt3) this).f1381a.d(i7 - i6);
                        return;
                    }
                }
                if (!((com2) ((lpt3) this).f1381a).f1362c && ((lpt3) this).f1384a == p.con.MATCH_CONSTRAINT && ((lpt3) this).f7407a == 1 && ((lpt3) this).f1380a.f1360b.size() > 0 && ((lpt3) this).f1387b.f1360b.size() > 0) {
                    com2 com2Var6 = ((lpt3) this).f1380a.f1360b.get(0);
                    int i8 = (((lpt3) this).f1387b.f1360b.get(0).f7365b + ((lpt3) this).f1387b.f7364a) - (com2Var6.f7365b + ((lpt3) this).f1380a.f7364a);
                    com3 com3Var3 = ((lpt3) this).f1381a;
                    int i9 = com3Var3.f7375d;
                    if (i8 < i9) {
                        com3Var3.d(i8);
                    } else {
                        com3Var3.d(i9);
                    }
                }
                if (((com2) ((lpt3) this).f1381a).f1362c && ((lpt3) this).f1380a.f1360b.size() > 0 && ((lpt3) this).f1387b.f1360b.size() > 0) {
                    com2 com2Var7 = ((lpt3) this).f1380a.f1360b.get(0);
                    com2 com2Var8 = ((lpt3) this).f1387b.f1360b.get(0);
                    int i10 = com2Var7.f7365b + ((lpt3) this).f1380a.f7364a;
                    int i11 = com2Var8.f7365b + ((lpt3) this).f1387b.f7364a;
                    float fP = ((lpt3) this).f1385a.P();
                    if (com2Var7 == com2Var8) {
                        i10 = com2Var7.f7365b;
                        i11 = com2Var8.f7365b;
                        fP = 0.5f;
                    }
                    ((lpt3) this).f1380a.d((int) (i10 + 0.5f + (((i11 - i10) - ((com2) ((lpt3) this).f1381a).f7365b) * fP)));
                    ((lpt3) this).f1387b.d(((lpt3) this).f1380a.f7365b + ((com2) ((lpt3) this).f1381a).f7365b);
                }
            }
        }
    }

    @Override // NUL.lpt3
    public void d() {
        p pVarI;
        p pVarI2;
        p pVar = ((lpt3) this).f1385a;
        if (pVar.f4946a) {
            ((lpt3) this).f1381a.d(pVar.v());
        }
        if (!((com2) ((lpt3) this).f1381a).f1362c) {
            ((lpt3) this).f1384a = ((lpt3) this).f1385a.R();
            if (((lpt3) this).f1385a.X()) {
                this.f7394b = new NUL.aux(this);
            }
            p.con conVar = ((lpt3) this).f1384a;
            if (conVar != p.con.MATCH_CONSTRAINT) {
                if (conVar == p.con.MATCH_PARENT && (pVarI2 = ((lpt3) this).f1385a.I()) != null && pVarI2.R() == p.con.FIXED) {
                    int iV = (pVarI2.v() - ((lpt3) this).f1385a.f4957b.e()) - ((lpt3) this).f1385a.f4969d.e();
                    b(((lpt3) this).f1380a, ((lpt3) pVarI2.f4938a).f1380a, ((lpt3) this).f1385a.f4957b.e());
                    b(((lpt3) this).f1387b, ((lpt3) pVarI2.f4938a).f1387b, -((lpt3) this).f1385a.f4969d.e());
                    ((lpt3) this).f1381a.d(iV);
                    return;
                }
                if (((lpt3) this).f1384a == p.con.FIXED) {
                    ((lpt3) this).f1381a.d(((lpt3) this).f1385a.v());
                }
            }
        } else if (((lpt3) this).f1384a == p.con.MATCH_PARENT && (pVarI = ((lpt3) this).f1385a.I()) != null && pVarI.R() == p.con.FIXED) {
            b(((lpt3) this).f1380a, ((lpt3) pVarI.f4938a).f1380a, ((lpt3) this).f1385a.f4957b.e());
            b(((lpt3) this).f1387b, ((lpt3) pVarI.f4938a).f1387b, -((lpt3) this).f1385a.f4969d.e());
            return;
        }
        com3 com3Var = ((lpt3) this).f1381a;
        boolean z2 = ((com2) com3Var).f1362c;
        if (z2) {
            p pVar2 = ((lpt3) this).f1385a;
            if (pVar2.f4946a) {
                o[] oVarArr = pVar2.f4950a;
                o oVar = oVarArr[2];
                o oVar2 = oVar.f4932a;
                if (oVar2 != null && oVarArr[3].f4932a != null) {
                    if (pVar2.i0()) {
                        ((lpt3) this).f1380a.f7364a = ((lpt3) this).f1385a.f4950a[2].e();
                        ((lpt3) this).f1387b.f7364a = -((lpt3) this).f1385a.f4950a[3].e();
                    } else {
                        com2 com2VarH = h(((lpt3) this).f1385a.f4950a[2]);
                        if (com2VarH != null) {
                            b(((lpt3) this).f1380a, com2VarH, ((lpt3) this).f1385a.f4950a[2].e());
                        }
                        com2 com2VarH2 = h(((lpt3) this).f1385a.f4950a[3]);
                        if (com2VarH2 != null) {
                            b(((lpt3) this).f1387b, com2VarH2, -((lpt3) this).f1385a.f4950a[3].e());
                        }
                        ((lpt3) this).f1380a.f1359a = true;
                        ((lpt3) this).f1387b.f1359a = true;
                    }
                    if (((lpt3) this).f1385a.X()) {
                        b(this.f7395c, ((lpt3) this).f1380a, ((lpt3) this).f1385a.n());
                        return;
                    }
                    return;
                }
                if (oVar2 != null) {
                    com2 com2VarH3 = h(oVar);
                    if (com2VarH3 != null) {
                        b(((lpt3) this).f1380a, com2VarH3, ((lpt3) this).f1385a.f4950a[2].e());
                        b(((lpt3) this).f1387b, ((lpt3) this).f1380a, ((com2) ((lpt3) this).f1381a).f7365b);
                        if (((lpt3) this).f1385a.X()) {
                            b(this.f7395c, ((lpt3) this).f1380a, ((lpt3) this).f1385a.n());
                            return;
                        }
                        return;
                    }
                    return;
                }
                o oVar3 = oVarArr[3];
                if (oVar3.f4932a != null) {
                    com2 com2VarH4 = h(oVar3);
                    if (com2VarH4 != null) {
                        b(((lpt3) this).f1387b, com2VarH4, -((lpt3) this).f1385a.f4950a[3].e());
                        b(((lpt3) this).f1380a, ((lpt3) this).f1387b, -((com2) ((lpt3) this).f1381a).f7365b);
                    }
                    if (((lpt3) this).f1385a.X()) {
                        b(this.f7395c, ((lpt3) this).f1380a, ((lpt3) this).f1385a.n());
                        return;
                    }
                    return;
                }
                o oVar4 = oVarArr[4];
                if (oVar4.f4932a != null) {
                    com2 com2VarH5 = h(oVar4);
                    if (com2VarH5 != null) {
                        b(this.f7395c, com2VarH5, 0);
                        b(((lpt3) this).f1380a, this.f7395c, -((lpt3) this).f1385a.n());
                        b(((lpt3) this).f1387b, ((lpt3) this).f1380a, ((com2) ((lpt3) this).f1381a).f7365b);
                        return;
                    }
                    return;
                }
                if ((pVar2 instanceof s) || pVar2.I() == null || ((lpt3) this).f1385a.m(o.con.CENTER).f4932a != null) {
                    return;
                }
                b(((lpt3) this).f1380a, ((lpt3) ((lpt3) this).f1385a.I().f4938a).f1380a, ((lpt3) this).f1385a.W());
                b(((lpt3) this).f1387b, ((lpt3) this).f1380a, ((com2) ((lpt3) this).f1381a).f7365b);
                if (((lpt3) this).f1385a.X()) {
                    b(this.f7395c, ((lpt3) this).f1380a, ((lpt3) this).f1385a.n());
                    return;
                }
                return;
            }
        }
        if (z2 || ((lpt3) this).f1384a != p.con.MATCH_CONSTRAINT) {
            com3Var.b(this);
        } else {
            p pVar3 = ((lpt3) this).f1385a;
            int i2 = pVar3.f4977g;
            if (i2 == 2) {
                p pVarI3 = pVar3.I();
                if (pVarI3 != null) {
                    com3 com3Var2 = ((lpt3) pVarI3.f4938a).f1381a;
                    ((com2) ((lpt3) this).f1381a).f1360b.add(com3Var2);
                    ((com2) com3Var2).f1358a.add(((lpt3) this).f1381a);
                    com3 com3Var3 = ((lpt3) this).f1381a;
                    ((com2) com3Var3).f1359a = true;
                    ((com2) com3Var3).f1358a.add(((lpt3) this).f1380a);
                    ((com2) ((lpt3) this).f1381a).f1358a.add(((lpt3) this).f1387b);
                }
            } else if (i2 == 3 && !pVar3.i0()) {
                p pVar4 = ((lpt3) this).f1385a;
                if (pVar4.f4974f != 3) {
                    com3 com3Var4 = ((lpt3) pVar4.f4937a).f1381a;
                    ((com2) ((lpt3) this).f1381a).f1360b.add(com3Var4);
                    ((com2) com3Var4).f1358a.add(((lpt3) this).f1381a);
                    com3 com3Var5 = ((lpt3) this).f1381a;
                    ((com2) com3Var5).f1359a = true;
                    ((com2) com3Var5).f1358a.add(((lpt3) this).f1380a);
                    ((com2) ((lpt3) this).f1381a).f1358a.add(((lpt3) this).f1387b);
                }
            }
        }
        p pVar5 = ((lpt3) this).f1385a;
        o[] oVarArr2 = pVar5.f4950a;
        o oVar5 = oVarArr2[2];
        o oVar6 = oVar5.f4932a;
        if (oVar6 != null && oVarArr2[3].f4932a != null) {
            if (pVar5.i0()) {
                ((lpt3) this).f1380a.f7364a = ((lpt3) this).f1385a.f4950a[2].e();
                ((lpt3) this).f1387b.f7364a = -((lpt3) this).f1385a.f4950a[3].e();
            } else {
                com2 com2VarH6 = h(((lpt3) this).f1385a.f4950a[2]);
                com2 com2VarH7 = h(((lpt3) this).f1385a.f4950a[3]);
                if (com2VarH6 != null) {
                    com2VarH6.b(this);
                }
                if (com2VarH7 != null) {
                    com2VarH7.b(this);
                }
                ((lpt3) this).f1383a = lpt3.con.CENTER;
            }
            if (((lpt3) this).f1385a.X()) {
                c(this.f7395c, ((lpt3) this).f1380a, 1, this.f7394b);
            }
        } else if (oVar6 != null) {
            com2 com2VarH8 = h(oVar5);
            if (com2VarH8 != null) {
                b(((lpt3) this).f1380a, com2VarH8, ((lpt3) this).f1385a.f4950a[2].e());
                c(((lpt3) this).f1387b, ((lpt3) this).f1380a, 1, ((lpt3) this).f1381a);
                if (((lpt3) this).f1385a.X()) {
                    c(this.f7395c, ((lpt3) this).f1380a, 1, this.f7394b);
                }
                p.con conVar2 = ((lpt3) this).f1384a;
                p.con conVar3 = p.con.MATCH_CONSTRAINT;
                if (conVar2 == conVar3 && ((lpt3) this).f1385a.t() > 0.0f) {
                    com8 com8Var = ((lpt3) this).f1385a.f4937a;
                    if (((lpt3) com8Var).f1384a == conVar3) {
                        ((com2) ((lpt3) com8Var).f1381a).f1358a.add(((lpt3) this).f1381a);
                        ((com2) ((lpt3) this).f1381a).f1360b.add(((lpt3) ((lpt3) this).f1385a.f4937a).f1381a);
                        ((com2) ((lpt3) this).f1381a).f1357a = this;
                    }
                }
            }
        } else {
            o oVar7 = oVarArr2[3];
            if (oVar7.f4932a != null) {
                com2 com2VarH9 = h(oVar7);
                if (com2VarH9 != null) {
                    b(((lpt3) this).f1387b, com2VarH9, -((lpt3) this).f1385a.f4950a[3].e());
                    c(((lpt3) this).f1380a, ((lpt3) this).f1387b, -1, ((lpt3) this).f1381a);
                    if (((lpt3) this).f1385a.X()) {
                        c(this.f7395c, ((lpt3) this).f1380a, 1, this.f7394b);
                    }
                }
            } else {
                o oVar8 = oVarArr2[4];
                if (oVar8.f4932a != null) {
                    com2 com2VarH10 = h(oVar8);
                    if (com2VarH10 != null) {
                        b(this.f7395c, com2VarH10, 0);
                        c(((lpt3) this).f1380a, this.f7395c, -1, this.f7394b);
                        c(((lpt3) this).f1387b, ((lpt3) this).f1380a, 1, ((lpt3) this).f1381a);
                    }
                } else if (!(pVar5 instanceof s) && pVar5.I() != null) {
                    b(((lpt3) this).f1380a, ((lpt3) ((lpt3) this).f1385a.I().f4938a).f1380a, ((lpt3) this).f1385a.W());
                    c(((lpt3) this).f1387b, ((lpt3) this).f1380a, 1, ((lpt3) this).f1381a);
                    if (((lpt3) this).f1385a.X()) {
                        c(this.f7395c, ((lpt3) this).f1380a, 1, this.f7394b);
                    }
                    p.con conVar4 = ((lpt3) this).f1384a;
                    p.con conVar5 = p.con.MATCH_CONSTRAINT;
                    if (conVar4 == conVar5 && ((lpt3) this).f1385a.t() > 0.0f) {
                        com8 com8Var2 = ((lpt3) this).f1385a.f4937a;
                        if (((lpt3) com8Var2).f1384a == conVar5) {
                            ((com2) ((lpt3) com8Var2).f1381a).f1358a.add(((lpt3) this).f1381a);
                            ((com2) ((lpt3) this).f1381a).f1360b.add(((lpt3) ((lpt3) this).f1385a.f4937a).f1381a);
                            ((com2) ((lpt3) this).f1381a).f1357a = this;
                        }
                    }
                }
            }
        }
        if (((com2) ((lpt3) this).f1381a).f1360b.size() == 0) {
            ((com2) ((lpt3) this).f1381a).f1361b = true;
        }
    }

    @Override // NUL.lpt3
    public void e() {
        com2 com2Var = ((lpt3) this).f1380a;
        if (com2Var.f1362c) {
            ((lpt3) this).f1385a.k1(com2Var.f7365b);
        }
    }

    @Override // NUL.lpt3
    public void f() {
        ((lpt3) this).f1382a = null;
        ((lpt3) this).f1380a.c();
        ((lpt3) this).f1387b.c();
        this.f7395c.c();
        ((lpt3) this).f1381a.c();
        ((lpt3) this).f1386a = false;
    }

    @Override // NUL.lpt3
    public boolean m() {
        return ((lpt3) this).f1384a != p.con.MATCH_CONSTRAINT || ((lpt3) this).f1385a.f4977g == 0;
    }

    public void q() {
        ((lpt3) this).f1386a = false;
        ((lpt3) this).f1380a.c();
        ((lpt3) this).f1380a.f1362c = false;
        ((lpt3) this).f1387b.c();
        ((lpt3) this).f1387b.f1362c = false;
        this.f7395c.c();
        this.f7395c.f1362c = false;
        ((com2) ((lpt3) this).f1381a).f1362c = false;
    }

    public String toString() {
        return "VerticalRun " + ((lpt3) this).f1385a.r();
    }
}
