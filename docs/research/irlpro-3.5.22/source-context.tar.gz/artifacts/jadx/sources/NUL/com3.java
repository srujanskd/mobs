package NUL;

/* JADX INFO: loaded from: classes.dex */
public class com3 extends com2 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7375d;

    public com3(lpt3 lpt3Var) {
        super(lpt3Var);
        if (lpt3Var instanceof com8) {
            ((com2) this).f1354a = com2.aux.HORIZONTAL_DIMENSION;
        } else {
            ((com2) this).f1354a = com2.aux.VERTICAL_DIMENSION;
        }
    }

    @Override // NUL.com2
    public void d(int i2) {
        if (((com2) this).f1362c) {
            return;
        }
        ((com2) this).f1362c = true;
        ((com2) this).f7365b = i2;
        for (prn prnVar : ((com2) this).f1358a) {
            prnVar.a(prnVar);
        }
    }
}
