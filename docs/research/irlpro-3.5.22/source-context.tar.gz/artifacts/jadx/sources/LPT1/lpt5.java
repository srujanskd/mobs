package LPT1;

/* JADX INFO: loaded from: classes.dex */
public final class lpt5 extends lpt1 {
    public lpt5(String str) {
        super(str);
    }

    public lpt5(String str, Throwable th) {
        super(str, th);
    }

    public lpt5(Throwable th) {
        super(th);
    }
}
