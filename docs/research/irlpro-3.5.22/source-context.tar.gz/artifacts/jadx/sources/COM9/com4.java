package COM9;

import android.graphics.drawable.Drawable;
import android.view.View;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
public class com4 {
    public static prn a(int i2) {
        if (i2 != 0) {
            return i2 != 1 ? b() : new com1();
        }
        return new com6();
    }

    public static prn b() {
        return new com6();
    }

    public static com2 c() {
        return new com2();
    }

    public static void d(View view, float f2) {
        Drawable background = view.getBackground();
        if (background instanceof com3) {
            ((com3) background).X(f2);
        }
    }

    public static void e(View view) {
        Drawable background = view.getBackground();
        if (background instanceof com3) {
            f(view, (com3) background);
        }
    }

    public static void f(View view, com3 com3Var) {
        if (com3Var.P()) {
            com3Var.b0(v.d(view));
        }
    }
}
