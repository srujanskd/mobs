package LPT6;

import java.math.BigInteger;
import p039LPt7.l4;
import p125lPt7.na;

/* JADX INFO: loaded from: classes.dex */
public interface com2 extends na, com3 {
    /* JADX WARN: Can't rename method to resolve collision */
    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com3, java.lang.Comparable
    /* bridge */ /* synthetic */ default int compareTo(com3 com3Var) {
        return super.compareTo(com3Var);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsPrefixBlock(int i2) {
        return super.containsPrefixBlock(i2);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean containsSinglePrefixBlock(int i2) {
        return super.containsSinglePrefixBlock(i2);
    }

    @Override // LPT6.com3
    /* synthetic */ int getBitCount();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int getByteCount() {
        return super.getByteCount();
    }

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes();

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr);

    @Override // LPT6.com3
    /* synthetic */ byte[] getBytes(byte[] bArr, int i2);

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getCount() {
        return super.getCount();
    }

    @Override // p125lPt7.na
    /* synthetic */ int getDigitCount(int i2);

    @Override // p125lPt7.na
    /* synthetic */ int getLowerStandardString(int i2, l4 l4Var, StringBuilder sb);

    @Override // p125lPt7.na
    /* synthetic */ int getMaxDigitCount(int i2);

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default int getMinPrefixLengthForBlock() {
        return super.getMinPrefixLengthForBlock();
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default BigInteger getPrefixCount(int i2) {
        return super.getPrefixCount(i2);
    }

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default Integer getPrefixLengthForSingleBlock() {
        return super.getPrefixLengthForSingleBlock();
    }

    @Override // p125lPt7.na
    /* synthetic */ int getStandardString(int i2, l4 l4Var, StringBuilder sb);

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes();

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr);

    @Override // LPT6.com3
    /* synthetic */ byte[] getUpperBytes(byte[] bArr, int i2);

    @Override // LPT6.com3
    /* synthetic */ BigInteger getUpperValue();

    @Override // LPT6.com3
    /* synthetic */ BigInteger getValue();

    @Override // LPT6.com3
    /* synthetic */ boolean includesMax();

    @Override // LPT6.com3
    /* synthetic */ boolean includesZero();

    @Override // p125lPt7.na
    /* synthetic */ boolean isBoundedBy(int i2);

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean isFullRange() {
        return super.isFullRange();
    }

    @Override // LPT6.com3
    /* synthetic */ boolean isMax();

    @Override // LPT6.com3
    /* bridge */ /* synthetic */ default boolean isMultiple() {
        return super.isMultiple();
    }

    @Override // LPT6.com3
    /* synthetic */ boolean isZero();
}
