package androidx.fragment.app;

import android.content.Context;
import android.graphics.Rect;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import p015CoM3.i;
import p015CoM3.m;
import p015CoM3.n;
import p024Com2.v;
import p024Com2.y;
import p147nUl.x;

/* JADX INFO: loaded from: classes.dex */
public class lpt4 {

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f2522a = {0, 3, 0, 1, 5, 4, 7, 6, 9, 8, 10};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final n f8309a = new m();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final n f8310b = w();

    public class aux implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p013CoM1.com7 f8311a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2523a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com3 f2524a;

        public aux(com3 com3Var, Fragment fragment, p013CoM1.com7 com7Var) {
            this.f2524a = com3Var;
            this.f2523a = fragment;
            this.f8311a = com7Var;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f2524a.b(this.f2523a, this.f8311a);
        }
    }

    public class com1 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ n f8312a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Rect f2525a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f2526a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2527a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ x f2528a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Fragment f8313b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ boolean f2529b;

        public com1(Fragment fragment, Fragment fragment2, boolean z2, x xVar, View view, n nVar, Rect rect) {
            this.f2527a = fragment;
            this.f8313b = fragment2;
            this.f2529b = z2;
            this.f2528a = xVar;
            this.f2526a = view;
            this.f8312a = nVar;
            this.f2525a = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            lpt4.f(this.f2527a, this.f8313b, this.f2529b, this.f2528a, false);
            View view = this.f2526a;
            if (view != null) {
                this.f8312a.k(view, this.f2525a);
            }
        }
    }

    public class com2 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ n f8314a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Rect f2530a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f2531a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2532a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com4 f2533a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Object f2534a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2535a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ x f2536a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Fragment f8315b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ Object f2537b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2538b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ boolean f2539b;

        public com2(n nVar, x xVar, Object obj, com4 com4Var, ArrayList arrayList, View view, Fragment fragment, Fragment fragment2, boolean z2, ArrayList arrayList2, Object obj2, Rect rect) {
            this.f8314a = nVar;
            this.f2536a = xVar;
            this.f2534a = obj;
            this.f2533a = com4Var;
            this.f2535a = arrayList;
            this.f2531a = view;
            this.f2532a = fragment;
            this.f8315b = fragment2;
            this.f2539b = z2;
            this.f2538b = arrayList2;
            this.f2537b = obj2;
            this.f2530a = rect;
        }

        @Override // java.lang.Runnable
        public void run() {
            x<String, View> xVarH = lpt4.h(this.f8314a, this.f2536a, this.f2534a, this.f2533a);
            if (xVarH != null) {
                this.f2535a.addAll(xVarH.values());
                this.f2535a.add(this.f2531a);
            }
            lpt4.f(this.f2532a, this.f8315b, this.f2539b, xVarH, false);
            Object obj = this.f2534a;
            if (obj != null) {
                this.f8314a.A(obj, this.f2538b, this.f2535a);
                View viewS = lpt4.s(xVarH, this.f2533a, this.f2537b, this.f2539b);
                if (viewS != null) {
                    this.f8314a.k(viewS, this.f2530a);
                }
            }
        }
    }

    public interface com3 {
        void a(Fragment fragment, p013CoM1.com7 com7Var);

        void b(Fragment fragment, p013CoM1.com7 com7Var);
    }

    public static class com4 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public Fragment f8316a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public androidx.fragment.app.aux f2540a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public boolean f2541a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public Fragment f8317b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public androidx.fragment.app.aux f2542b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public boolean f2543b;
    }

    public class con implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ ArrayList f8318a;

        public con(ArrayList arrayList) {
            this.f8318a = arrayList;
        }

        @Override // java.lang.Runnable
        public void run() {
            lpt4.A(this.f8318a, 4);
        }
    }

    public class nul implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ p013CoM1.com7 f8319a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2544a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ com3 f2545a;

        public nul(com3 com3Var, Fragment fragment, p013CoM1.com7 com7Var) {
            this.f2545a = com3Var;
            this.f2544a = fragment;
            this.f8319a = com7Var;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f2545a.b(this.f2544a, this.f8319a);
        }
    }

    public class prn implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ n f8320a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ View f2546a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Fragment f2547a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ Object f2548a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2549a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Object f8321b;

        /* JADX INFO: renamed from: b, reason: collision with other field name */
        public final /* synthetic */ ArrayList f2550b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final /* synthetic */ ArrayList f8322c;

        public prn(Object obj, n nVar, View view, Fragment fragment, ArrayList arrayList, ArrayList arrayList2, ArrayList arrayList3, Object obj2) {
            this.f2548a = obj;
            this.f8320a = nVar;
            this.f2546a = view;
            this.f2547a = fragment;
            this.f2549a = arrayList;
            this.f2550b = arrayList2;
            this.f8322c = arrayList3;
            this.f8321b = obj2;
        }

        @Override // java.lang.Runnable
        public void run() {
            Object obj = this.f2548a;
            if (obj != null) {
                this.f8320a.p(obj, this.f2546a);
                this.f2550b.addAll(lpt4.k(this.f8320a, this.f2548a, this.f2547a, this.f2549a, this.f2546a));
            }
            if (this.f8322c != null) {
                if (this.f8321b != null) {
                    ArrayList<View> arrayList = new ArrayList<>();
                    arrayList.add(this.f2546a);
                    this.f8320a.q(this.f8321b, this.f8322c, arrayList);
                }
                this.f8322c.clear();
                this.f8322c.add(this.f2546a);
            }
        }
    }

    public static void A(ArrayList<View> arrayList, int i2) {
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            arrayList.get(size).setVisibility(i2);
        }
    }

    public static void B(Context context, i iVar, ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2, int i2, int i3, boolean z2, com3 com3Var) {
        ViewGroup viewGroup;
        SparseArray sparseArray = new SparseArray();
        for (int i4 = i2; i4 < i3; i4++) {
            androidx.fragment.app.aux auxVar = arrayList.get(i4);
            if (arrayList2.get(i4).booleanValue()) {
                e(auxVar, sparseArray, z2);
            } else {
                c(auxVar, sparseArray, z2);
            }
        }
        if (sparseArray.size() != 0) {
            View view = new View(context);
            int size = sparseArray.size();
            for (int i5 = 0; i5 < size; i5++) {
                int iKeyAt = sparseArray.keyAt(i5);
                x<String, String> xVarD = d(iKeyAt, arrayList, arrayList2, i2, i3);
                com4 com4Var = (com4) sparseArray.valueAt(i5);
                if (iVar.d() && (viewGroup = (ViewGroup) iVar.c(iKeyAt)) != null) {
                    if (z2) {
                        o(viewGroup, com4Var, view, xVarD, com3Var);
                    } else {
                        n(viewGroup, com4Var, view, xVarD, com3Var);
                    }
                }
            }
        }
    }

    public static void a(ArrayList<View> arrayList, x<String, View> xVar, Collection<String> collection) {
        for (int size = xVar.size() - 1; size >= 0; size--) {
            View viewM = xVar.m(size);
            if (collection.contains(y.J(viewM))) {
                arrayList.add(viewM);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:46:0x0058  */
    /* JADX WARN: Code duplicated, block: B:55:0x006f  */
    /* JADX WARN: Code duplicated, block: B:56:0x0071  */
    /* JADX WARN: Code duplicated, block: B:63:0x0080 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:64:0x0082  */
    /* JADX WARN: Code duplicated, block: B:65:0x0085  */
    /* JADX WARN: Code duplicated, block: B:69:0x008d  */
    /* JADX WARN: Code duplicated, block: B:70:0x008f  */
    public static void b(androidx.fragment.app.aux auxVar, lpt3.aux auxVar2, SparseArray<com4> sparseArray, boolean z2, boolean z3) {
        int i2;
        boolean z4;
        boolean z5;
        boolean z6;
        View view;
        boolean z7;
        Fragment fragment = auxVar2.f2519a;
        if (fragment == null || (i2 = fragment.mContainerId) == 0) {
            return;
        }
        int i3 = z2 ? f2522a[auxVar2.f8304a] : auxVar2.f8304a;
        boolean z8 = false;
        boolean z9 = true;
        if (i3 == 1) {
            if (z3) {
                z4 = fragment.mIsNewlyAdded;
            } else if (!fragment.mAdded || fragment.mHidden) {
                z4 = false;
            } else {
                z4 = true;
            }
            z5 = false;
            z8 = z4;
            z6 = false;
        } else if (i3 == 3) {
            if (z3 ? !fragment.mAdded || fragment.mHidden : fragment.mAdded || (view = fragment.mView) == null || view.getVisibility() != 0 || fragment.mPostponedAlpha < 0.0f) {
                z7 = false;
            } else {
                z7 = true;
            }
            z5 = z7;
            z6 = true;
            z9 = false;
        } else if (i3 == 4) {
            if (!z3 ? !(!fragment.mAdded || fragment.mHidden) : fragment.mHiddenChanged && fragment.mAdded && fragment.mHidden) {
                z7 = false;
            } else {
                z7 = true;
            }
            z5 = z7;
            z6 = true;
            z9 = false;
        } else if (i3 == 5) {
            if (!z3) {
                z4 = fragment.mHidden;
            } else if (fragment.mHiddenChanged && !fragment.mHidden && fragment.mAdded) {
                z4 = true;
            } else {
                z4 = false;
            }
            z5 = false;
            z8 = z4;
            z6 = false;
        } else if (i3 == 6) {
            if (z3) {
                z7 = false;
            } else {
                z7 = false;
            }
            z5 = z7;
            z6 = true;
            z9 = false;
        } else if (i3 != 7) {
            z6 = false;
            z9 = false;
            z5 = false;
        } else {
            if (z3) {
                z4 = fragment.mIsNewlyAdded;
            } else {
                if (fragment.mAdded) {
                }
                z4 = false;
            }
            z5 = false;
            z8 = z4;
            z6 = false;
        }
        com4 com4VarP = sparseArray.get(i2);
        if (z8) {
            com4VarP = p(com4VarP, sparseArray, i2);
            com4VarP.f8316a = fragment;
            com4VarP.f2541a = z2;
            com4VarP.f2540a = auxVar;
        }
        if (!z3 && z9) {
            if (com4VarP != null && com4VarP.f8317b == fragment) {
                com4VarP.f8317b = null;
            }
            if (!((lpt3) auxVar).f2517c) {
                com6 com6Var = auxVar.f8233a;
                com6Var.t0().p(com6Var.w(fragment));
                com6Var.T0(fragment);
            }
        }
        if (z5 && (com4VarP == null || com4VarP.f8317b == null)) {
            com4VarP = p(com4VarP, sparseArray, i2);
            com4VarP.f8317b = fragment;
            com4VarP.f2543b = z2;
            com4VarP.f2542b = auxVar;
        }
        if (z3 || !z6 || com4VarP == null || com4VarP.f8316a != fragment) {
            return;
        }
        com4VarP.f8316a = null;
    }

    public static void c(androidx.fragment.app.aux auxVar, SparseArray<com4> sparseArray, boolean z2) {
        int size = ((lpt3) auxVar).f2511a.size();
        for (int i2 = 0; i2 < size; i2++) {
            b(auxVar, ((lpt3) auxVar).f2511a.get(i2), sparseArray, false, z2);
        }
    }

    public static x<String, String> d(int i2, ArrayList<androidx.fragment.app.aux> arrayList, ArrayList<Boolean> arrayList2, int i3, int i4) {
        ArrayList<String> arrayList3;
        ArrayList<String> arrayList4;
        x<String, String> xVar = new x<>();
        for (int i5 = i4 - 1; i5 >= i3; i5--) {
            androidx.fragment.app.aux auxVar = arrayList.get(i5);
            if (auxVar.D(i2)) {
                boolean zBooleanValue = arrayList2.get(i5).booleanValue();
                ArrayList<String> arrayList5 = ((lpt3) auxVar).f2514b;
                if (arrayList5 != null) {
                    int size = arrayList5.size();
                    if (zBooleanValue) {
                        arrayList3 = ((lpt3) auxVar).f2514b;
                        arrayList4 = ((lpt3) auxVar).f2516c;
                    } else {
                        ArrayList<String> arrayList6 = ((lpt3) auxVar).f2514b;
                        arrayList3 = ((lpt3) auxVar).f2516c;
                        arrayList4 = arrayList6;
                    }
                    for (int i6 = 0; i6 < size; i6++) {
                        String str = arrayList4.get(i6);
                        String str2 = arrayList3.get(i6);
                        String strRemove = xVar.remove(str2);
                        if (strRemove != null) {
                            xVar.put(str, strRemove);
                        } else {
                            xVar.put(str, str2);
                        }
                    }
                }
            }
        }
        return xVar;
    }

    public static void e(androidx.fragment.app.aux auxVar, SparseArray<com4> sparseArray, boolean z2) {
        if (auxVar.f8233a.q0().d()) {
            for (int size = ((lpt3) auxVar).f2511a.size() - 1; size >= 0; size--) {
                b(auxVar, ((lpt3) auxVar).f2511a.get(size), sparseArray, true, z2);
            }
        }
    }

    public static void f(Fragment fragment, Fragment fragment2, boolean z2, x<String, View> xVar, boolean z3) {
        if (z2) {
            fragment2.getEnterTransitionCallback();
        } else {
            fragment.getEnterTransitionCallback();
        }
    }

    public static boolean g(n nVar, List<Object> list) {
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (!nVar.e(list.get(i2))) {
                return false;
            }
        }
        return true;
    }

    public static x<String, View> h(n nVar, x<String, String> xVar, Object obj, com4 com4Var) {
        ArrayList<String> arrayList;
        Fragment fragment = com4Var.f8316a;
        View view = fragment.getView();
        if (xVar.isEmpty() || obj == null || view == null) {
            xVar.clear();
            return null;
        }
        x<String, View> xVar2 = new x<>();
        nVar.j(xVar2, view);
        androidx.fragment.app.aux auxVar = com4Var.f2540a;
        if (com4Var.f2541a) {
            fragment.getExitTransitionCallback();
            arrayList = ((lpt3) auxVar).f2514b;
        } else {
            fragment.getEnterTransitionCallback();
            arrayList = ((lpt3) auxVar).f2516c;
        }
        if (arrayList != null) {
            xVar2.o(arrayList);
            xVar2.o(xVar.values());
        }
        x(xVar, xVar2);
        return xVar2;
    }

    public static x<String, View> i(n nVar, x<String, String> xVar, Object obj, com4 com4Var) {
        ArrayList<String> arrayList;
        if (xVar.isEmpty() || obj == null) {
            xVar.clear();
            return null;
        }
        Fragment fragment = com4Var.f8317b;
        x<String, View> xVar2 = new x<>();
        nVar.j(xVar2, fragment.requireView());
        androidx.fragment.app.aux auxVar = com4Var.f2542b;
        if (com4Var.f2543b) {
            fragment.getEnterTransitionCallback();
            arrayList = ((lpt3) auxVar).f2516c;
        } else {
            fragment.getExitTransitionCallback();
            arrayList = ((lpt3) auxVar).f2514b;
        }
        if (arrayList != null) {
            xVar2.o(arrayList);
        }
        xVar.o(xVar2.keySet());
        return xVar2;
    }

    public static n j(Fragment fragment, Fragment fragment2) {
        ArrayList arrayList = new ArrayList();
        if (fragment != null) {
            Object exitTransition = fragment.getExitTransition();
            if (exitTransition != null) {
                arrayList.add(exitTransition);
            }
            Object returnTransition = fragment.getReturnTransition();
            if (returnTransition != null) {
                arrayList.add(returnTransition);
            }
            Object sharedElementReturnTransition = fragment.getSharedElementReturnTransition();
            if (sharedElementReturnTransition != null) {
                arrayList.add(sharedElementReturnTransition);
            }
        }
        if (fragment2 != null) {
            Object enterTransition = fragment2.getEnterTransition();
            if (enterTransition != null) {
                arrayList.add(enterTransition);
            }
            Object reenterTransition = fragment2.getReenterTransition();
            if (reenterTransition != null) {
                arrayList.add(reenterTransition);
            }
            Object sharedElementEnterTransition = fragment2.getSharedElementEnterTransition();
            if (sharedElementEnterTransition != null) {
                arrayList.add(sharedElementEnterTransition);
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        n nVar = f8309a;
        if (nVar != null && g(nVar, arrayList)) {
            return nVar;
        }
        n nVar2 = f8310b;
        if (nVar2 != null && g(nVar2, arrayList)) {
            return nVar2;
        }
        if (nVar == null && nVar2 == null) {
            return null;
        }
        throw new IllegalArgumentException("Invalid Transition types");
    }

    public static ArrayList<View> k(n nVar, Object obj, Fragment fragment, ArrayList<View> arrayList, View view) {
        if (obj == null) {
            return null;
        }
        ArrayList<View> arrayList2 = new ArrayList<>();
        View view2 = fragment.getView();
        if (view2 != null) {
            nVar.f(arrayList2, view2);
        }
        if (arrayList != null) {
            arrayList2.removeAll(arrayList);
        }
        if (arrayList2.isEmpty()) {
            return arrayList2;
        }
        arrayList2.add(view);
        nVar.b(obj, arrayList2);
        return arrayList2;
    }

    public static Object l(n nVar, ViewGroup viewGroup, View view, x<String, String> xVar, com4 com4Var, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        Rect rect;
        Fragment fragment = com4Var.f8316a;
        Fragment fragment2 = com4Var.f8317b;
        if (fragment == null || fragment2 == null) {
            return null;
        }
        boolean z2 = com4Var.f2541a;
        Object objT = xVar.isEmpty() ? null : t(nVar, fragment, fragment2, z2);
        x<String, View> xVarI = i(nVar, xVar, objT, com4Var);
        if (xVar.isEmpty()) {
            obj3 = null;
        } else {
            arrayList.addAll(xVarI.values());
            obj3 = objT;
        }
        if (obj == null && obj2 == null && obj3 == null) {
            return null;
        }
        f(fragment, fragment2, z2, xVarI, true);
        if (obj3 != null) {
            rect = new Rect();
            nVar.z(obj3, view, arrayList);
            z(nVar, obj3, obj2, xVarI, com4Var.f2543b, com4Var.f2542b);
            if (obj != null) {
                nVar.u(obj, rect);
            }
        } else {
            rect = null;
        }
        v.a(viewGroup, new com2(nVar, xVar, obj3, com4Var, arrayList2, view, fragment, fragment2, z2, arrayList, obj, rect));
        return obj3;
    }

    public static Object m(n nVar, ViewGroup viewGroup, View view, x<String, String> xVar, com4 com4Var, ArrayList<View> arrayList, ArrayList<View> arrayList2, Object obj, Object obj2) {
        Object obj3;
        View view2;
        Rect rect;
        Fragment fragment = com4Var.f8316a;
        Fragment fragment2 = com4Var.f8317b;
        if (fragment != null) {
            fragment.requireView().setVisibility(0);
        }
        if (fragment == null || fragment2 == null) {
            return null;
        }
        boolean z2 = com4Var.f2541a;
        Object objT = xVar.isEmpty() ? null : t(nVar, fragment, fragment2, z2);
        x<String, View> xVarI = i(nVar, xVar, objT, com4Var);
        x<String, View> xVarH = h(nVar, xVar, objT, com4Var);
        if (xVar.isEmpty()) {
            if (xVarI != null) {
                xVarI.clear();
            }
            if (xVarH != null) {
                xVarH.clear();
            }
            obj3 = null;
        } else {
            a(arrayList, xVarI, xVar.keySet());
            a(arrayList2, xVarH, xVar.values());
            obj3 = objT;
        }
        if (obj == null && obj2 == null && obj3 == null) {
            return null;
        }
        f(fragment, fragment2, z2, xVarI, true);
        if (obj3 != null) {
            arrayList2.add(view);
            nVar.z(obj3, view, arrayList);
            z(nVar, obj3, obj2, xVarI, com4Var.f2543b, com4Var.f2542b);
            Rect rect2 = new Rect();
            View viewS = s(xVarH, com4Var, obj, z2);
            if (viewS != null) {
                nVar.u(obj, rect2);
            }
            rect = rect2;
            view2 = viewS;
        } else {
            view2 = null;
            rect = null;
        }
        v.a(viewGroup, new com1(fragment, fragment2, z2, xVarH, view2, nVar, rect));
        return obj3;
    }

    public static void n(ViewGroup viewGroup, com4 com4Var, View view, x<String, String> xVar, com3 com3Var) {
        Object obj;
        Fragment fragment = com4Var.f8316a;
        Fragment fragment2 = com4Var.f8317b;
        n nVarJ = j(fragment2, fragment);
        if (nVarJ == null) {
            return;
        }
        boolean z2 = com4Var.f2541a;
        boolean z3 = com4Var.f2543b;
        Object objQ = q(nVarJ, fragment, z2);
        Object objR = r(nVarJ, fragment2, z3);
        ArrayList arrayList = new ArrayList();
        ArrayList<View> arrayList2 = new ArrayList<>();
        Object objL = l(nVarJ, viewGroup, view, xVar, com4Var, arrayList, arrayList2, objQ, objR);
        if (objQ == null && objL == null) {
            obj = objR;
            if (obj == null) {
                return;
            }
        } else {
            obj = objR;
        }
        ArrayList<View> arrayListK = k(nVarJ, obj, fragment2, arrayList, view);
        if (arrayListK == null || arrayListK.isEmpty()) {
            obj = null;
        }
        Object obj2 = obj;
        nVarJ.a(objQ, view);
        Object objU = u(nVarJ, objQ, obj2, objL, fragment, com4Var.f2541a);
        if (fragment2 != null && arrayListK != null && (arrayListK.size() > 0 || arrayList.size() > 0)) {
            p013CoM1.com7 com7Var = new p013CoM1.com7();
            com3Var.a(fragment2, com7Var);
            nVarJ.w(fragment2, objU, com7Var, new nul(com3Var, fragment2, com7Var));
        }
        if (objU != null) {
            ArrayList<View> arrayList3 = new ArrayList<>();
            nVarJ.t(objU, objQ, arrayList3, obj2, arrayListK, objL, arrayList2);
            y(nVarJ, viewGroup, fragment, view, arrayList2, objQ, arrayList3, obj2, arrayListK);
            nVarJ.x(viewGroup, arrayList2, xVar);
            nVarJ.c(viewGroup, objU);
            nVarJ.s(viewGroup, arrayList2, xVar);
        }
    }

    public static void o(ViewGroup viewGroup, com4 com4Var, View view, x<String, String> xVar, com3 com3Var) {
        Object obj;
        Fragment fragment = com4Var.f8316a;
        Fragment fragment2 = com4Var.f8317b;
        n nVarJ = j(fragment2, fragment);
        if (nVarJ == null) {
            return;
        }
        boolean z2 = com4Var.f2541a;
        boolean z3 = com4Var.f2543b;
        ArrayList<View> arrayList = new ArrayList<>();
        ArrayList<View> arrayList2 = new ArrayList<>();
        Object objQ = q(nVarJ, fragment, z2);
        Object objR = r(nVarJ, fragment2, z3);
        Object objM = m(nVarJ, viewGroup, view, xVar, com4Var, arrayList2, arrayList, objQ, objR);
        if (objQ == null && objM == null) {
            obj = objR;
            if (obj == null) {
                return;
            }
        } else {
            obj = objR;
        }
        ArrayList<View> arrayListK = k(nVarJ, obj, fragment2, arrayList2, view);
        ArrayList<View> arrayListK2 = k(nVarJ, objQ, fragment, arrayList, view);
        A(arrayListK2, 4);
        Object objU = u(nVarJ, objQ, obj, objM, fragment, z2);
        if (fragment2 != null && arrayListK != null && (arrayListK.size() > 0 || arrayList2.size() > 0)) {
            p013CoM1.com7 com7Var = new p013CoM1.com7();
            com3Var.a(fragment2, com7Var);
            nVarJ.w(fragment2, objU, com7Var, new aux(com3Var, fragment2, com7Var));
        }
        if (objU != null) {
            v(nVarJ, obj, fragment2, arrayListK);
            ArrayList<String> arrayListO = nVarJ.o(arrayList);
            nVarJ.t(objU, objQ, arrayListK2, obj, arrayListK, objM, arrayList);
            nVarJ.c(viewGroup, objU);
            nVarJ.y(viewGroup, arrayList2, arrayList, arrayListO, xVar);
            A(arrayListK2, 0);
            nVarJ.A(objM, arrayList2, arrayList);
        }
    }

    public static com4 p(com4 com4Var, SparseArray<com4> sparseArray, int i2) {
        if (com4Var != null) {
            return com4Var;
        }
        com4 com4Var2 = new com4();
        sparseArray.put(i2, com4Var2);
        return com4Var2;
    }

    public static Object q(n nVar, Fragment fragment, boolean z2) {
        if (fragment == null) {
            return null;
        }
        return nVar.g(z2 ? fragment.getReenterTransition() : fragment.getEnterTransition());
    }

    public static Object r(n nVar, Fragment fragment, boolean z2) {
        if (fragment == null) {
            return null;
        }
        return nVar.g(z2 ? fragment.getReturnTransition() : fragment.getExitTransition());
    }

    public static View s(x<String, View> xVar, com4 com4Var, Object obj, boolean z2) {
        ArrayList<String> arrayList;
        androidx.fragment.app.aux auxVar = com4Var.f2540a;
        if (obj == null || xVar == null || (arrayList = ((lpt3) auxVar).f2514b) == null || arrayList.isEmpty()) {
            return null;
        }
        return xVar.get(z2 ? ((lpt3) auxVar).f2514b.get(0) : ((lpt3) auxVar).f2516c.get(0));
    }

    public static Object t(n nVar, Fragment fragment, Fragment fragment2, boolean z2) {
        if (fragment == null || fragment2 == null) {
            return null;
        }
        return nVar.B(nVar.g(z2 ? fragment2.getSharedElementReturnTransition() : fragment.getSharedElementEnterTransition()));
    }

    public static Object u(n nVar, Object obj, Object obj2, Object obj3, Fragment fragment, boolean z2) {
        boolean allowReturnTransitionOverlap;
        if (obj == null || obj2 == null || fragment == null) {
            allowReturnTransitionOverlap = true;
        } else {
            allowReturnTransitionOverlap = z2 ? fragment.getAllowReturnTransitionOverlap() : fragment.getAllowEnterTransitionOverlap();
        }
        return allowReturnTransitionOverlap ? nVar.n(obj2, obj, obj3) : nVar.m(obj2, obj, obj3);
    }

    public static void v(n nVar, Object obj, Fragment fragment, ArrayList<View> arrayList) {
        if (fragment != null && obj != null && fragment.mAdded && fragment.mHidden && fragment.mHiddenChanged) {
            fragment.setHideReplaced(true);
            nVar.r(obj, fragment.getView(), arrayList);
            v.a(fragment.mContainer, new con(arrayList));
        }
    }

    public static n w() {
        try {
            return (n) p007COm5.com2.class.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Exception unused) {
            return null;
        }
    }

    public static void x(x<String, String> xVar, x<String, View> xVar2) {
        for (int size = xVar.size() - 1; size >= 0; size--) {
            if (!xVar2.containsKey(xVar.m(size))) {
                xVar.k(size);
            }
        }
    }

    public static void y(n nVar, ViewGroup viewGroup, Fragment fragment, View view, ArrayList<View> arrayList, Object obj, ArrayList<View> arrayList2, Object obj2, ArrayList<View> arrayList3) {
        v.a(viewGroup, new prn(obj, nVar, view, fragment, arrayList, arrayList2, arrayList3, obj2));
    }

    public static void z(n nVar, Object obj, Object obj2, x<String, View> xVar, boolean z2, androidx.fragment.app.aux auxVar) {
        ArrayList<String> arrayList = ((lpt3) auxVar).f2514b;
        if (arrayList == null || arrayList.isEmpty()) {
            return;
        }
        View view = xVar.get(z2 ? ((lpt3) auxVar).f2516c.get(0) : ((lpt3) auxVar).f2514b.get(0));
        nVar.v(obj, view);
        if (obj2 != null) {
            nVar.v(obj2, view);
        }
    }
}
