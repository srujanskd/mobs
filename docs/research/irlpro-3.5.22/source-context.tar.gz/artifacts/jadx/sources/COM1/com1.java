package COM1;

import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final COM1.prn f5674a = new C0001com1(null, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final COM1.prn f5675b = new C0001com1(null, true);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final COM1.prn f5676c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final COM1.prn f5677d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final COM1.prn f5678e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final COM1.prn f5679f;

    public static class aux implements nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final aux f5680a = new aux(true);

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final boolean f52a;

        public aux(boolean z2) {
            this.f52a = z2;
        }

        @Override // COM1.com1.nul
        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            boolean z2 = false;
            while (i2 < i4) {
                int iA = com1.a(Character.getDirectionality(charSequence.charAt(i2)));
                if (iA != 0) {
                    if (iA != 1) {
                        continue;
                    } else if (!this.f52a) {
                        return 1;
                    }
                    i2++;
                    z2 = z2;
                } else if (this.f52a) {
                    return 0;
                }
                z2 = true;
                i2++;
                z2 = z2;
            }
            if (z2) {
                return this.f52a ? 1 : 0;
            }
            return 2;
        }
    }

    /* JADX INFO: renamed from: COM1.com1$com1, reason: collision with other inner class name */
    public static class C0001com1 extends prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final boolean f5681a;

        public C0001com1(nul nulVar, boolean z2) {
            super(nulVar);
            this.f5681a = z2;
        }

        @Override // COM1.com1.prn
        public boolean a() {
            return this.f5681a;
        }
    }

    public static class com2 extends prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final com2 f5682a = new com2();

        public com2() {
            super(null);
        }

        @Override // COM1.com1.prn
        public boolean a() {
            return COM1.com2.a(Locale.getDefault()) == 1;
        }
    }

    public static class con implements nul {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final con f5683a = new con();

        @Override // COM1.com1.nul
        public int a(CharSequence charSequence, int i2, int i3) {
            int i4 = i3 + i2;
            int iB = 2;
            while (i2 < i4 && iB == 2) {
                iB = com1.b(Character.getDirectionality(charSequence.charAt(i2)));
                i2++;
            }
            return iB;
        }
    }

    public interface nul {
        int a(CharSequence charSequence, int i2, int i3);
    }

    public static abstract class prn implements COM1.prn {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final nul f5684a;

        public prn(nul nulVar) {
            this.f5684a = nulVar;
        }

        public abstract boolean a();

        public final boolean b(CharSequence charSequence, int i2, int i3) {
            int iA = this.f5684a.a(charSequence, i2, i3);
            if (iA == 0) {
                return true;
            }
            if (iA != 1) {
                return a();
            }
            return false;
        }

        @Override // COM1.prn
        public boolean isRtl(CharSequence charSequence, int i2, int i3) {
            if (charSequence == null || i2 < 0 || i3 < 0 || charSequence.length() - i3 < i2) {
                throw new IllegalArgumentException();
            }
            return this.f5684a == null ? a() : b(charSequence, i2, i3);
        }
    }

    static {
        con conVar = con.f5683a;
        f5676c = new C0001com1(conVar, false);
        f5677d = new C0001com1(conVar, true);
        f5678e = new C0001com1(aux.f5680a, false);
        f5679f = com2.f5682a;
    }

    public static int a(int i2) {
        if (i2 != 0) {
            return (i2 == 1 || i2 == 2) ? 0 : 2;
        }
        return 1;
    }

    public static int b(int i2) {
        if (i2 != 0) {
            if (i2 == 1 || i2 == 2) {
                return 0;
            }
            switch (i2) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
