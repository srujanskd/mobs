package COM3;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
public class com5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static AtomicBoolean f5690a = new AtomicBoolean(false);

    public static class aux extends prn {
        @Override // COM3.prn, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            androidx.lifecycle.com5.g(activity);
        }

        @Override // COM3.prn, android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        }

        @Override // COM3.prn, android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
        }
    }

    public static void a(Context context) {
        if (f5690a.getAndSet(true)) {
            return;
        }
        ((Application) context.getApplicationContext()).registerActivityLifecycleCallbacks(new aux());
    }
}
