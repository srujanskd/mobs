package androidx.lifecycle;

import f.com8;
import n.v0;
import p136lpT9.u0;

/* JADX INFO: loaded from: classes.dex */
public final class LifecycleCoroutineScopeImpl extends COM3.com3 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final nul f8369a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final u0 f2589a;

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        com8.e(com7Var, "source");
        com8.e(conVar, "event");
        if (i().b().compareTo(nul.EnumC0039nul.DESTROYED) <= 0) {
            i().c(this);
            v0.d(h(), null, 1, null);
        }
    }

    @Override // n.l
    public u0 h() {
        return this.f2589a;
    }

    public nul i() {
        return this.f8369a;
    }
}
