package androidx.preference;

import android.content.Context;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;
import p016CoM4.com7;
import p016CoM4.lpt1;
import p016CoM4.lpt4;
import p016CoM4.lpt5;

/* JADX INFO: loaded from: classes.dex */
public final class aux extends Preference {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f8489a;

    public aux(Context context, List<Preference> list, long j2) {
        super(context);
        a();
        b(list);
        this.f8489a = j2 + 1000000;
    }

    public final void a() {
        setLayoutResource(lpt4.f6193a);
        setIcon(lpt1.f6181a);
        setTitle(lpt5.f6198b);
        setOrder(999);
    }

    public final void b(List<Preference> list) {
        ArrayList arrayList = new ArrayList();
        CharSequence string = null;
        for (Preference preference : list) {
            CharSequence title = preference.getTitle();
            boolean z2 = preference instanceof PreferenceGroup;
            if (z2 && !TextUtils.isEmpty(title)) {
                arrayList.add((PreferenceGroup) preference);
            }
            if (arrayList.contains(preference.getParent())) {
                if (z2) {
                    arrayList.add((PreferenceGroup) preference);
                }
            } else if (!TextUtils.isEmpty(title)) {
                string = string == null ? title : getContext().getString(lpt5.f6201e, string, title);
            }
        }
        setSummary(string);
    }

    @Override // androidx.preference.Preference
    public long getId() {
        return this.f8489a;
    }

    @Override // androidx.preference.Preference
    public void onBindViewHolder(com7 com7Var) {
        super.onBindViewHolder(com7Var);
        com7Var.Q(false);
    }
}
