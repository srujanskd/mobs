package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import p001AuX.com3;
import p001AuX.lpt3;
import p014CoM2.lpt1;
import p022CoN.l0;
import p022CoN.lpt9;
import p022CoN.m;
import p022CoN.q0;
import p022CoN.u0;
import p022CoN.w;
import p080cOm1.y;
import p089cOn.b1;

/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Property<SwitchCompat, Float> f7943a = new aux(Float.class, "thumbPos");

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final int[] f2047a = {R.attr.state_checked};

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public float f2048a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public int f2049a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt9 f2050a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final m f2051a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ObjectAnimator f2052a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f2053a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f2054a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final Rect f2055a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f2056a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Layout f2057a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final TextPaint f2058a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public TransformationMethod f2059a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public VelocityTracker f2060a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public con f2061a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f2062a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f7944b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public int f2063b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public ColorStateList f2064b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public PorterDuff.Mode f2065b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Drawable f2066b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public Layout f2067b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f2068b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f2069b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f7945c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public int f2070c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public ColorStateList f2071c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f2072c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f2073c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f7946d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public CharSequence f2074d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f2075d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7947e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public boolean f2076e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7948f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public boolean f2077f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7949g;

    /* JADX INFO: renamed from: g, reason: collision with other field name */
    public boolean f2078g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f7950h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f7951i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f7952j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f7953k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f7954l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f7955m;

    public class aux extends Property<SwitchCompat, Float> {
        public aux(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(SwitchCompat switchCompat) {
            return Float.valueOf(switchCompat.f7945c);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(SwitchCompat switchCompat, Float f2) {
            switchCompat.setThumbPosition(f2.floatValue());
        }
    }

    public static class con extends androidx.emoji2.text.con.com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Reference<SwitchCompat> f7956a;

        public con(SwitchCompat switchCompat) {
            this.f7956a = new WeakReference(switchCompat);
        }

        @Override // androidx.emoji2.text.con.com1
        public void a(Throwable th) {
            SwitchCompat switchCompat = this.f7956a.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }

        @Override // androidx.emoji2.text.con.com1
        public void b() {
            SwitchCompat switchCompat = this.f7956a.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }
    }

    public SwitchCompat(Context context) {
        this(context, null);
    }

    public static float f(float f2, float f3, float f4) {
        if (f2 < f3) {
            return f3;
        }
        return f2 > f4 ? f4 : f2;
    }

    private lpt9 getEmojiTextViewHelper() {
        if (this.f2050a == null) {
            this.f2050a = new lpt9(this);
        }
        return this.f2050a;
    }

    private boolean getTargetCheckedState() {
        return this.f7945c > 0.5f;
    }

    private int getThumbOffset() {
        return (int) (((u0.b(this) ? 1.0f - this.f7945c : this.f7945c) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f2066b;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.f2055a;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f2056a;
        Rect rectD = drawable2 != null ? w.d(drawable2) : w.f6400a;
        return ((((this.f7949g - this.f7951i) - rect.left) - rect.right) - rectD.left) - rectD.right;
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f2072c = charSequence;
        this.f2074d = g(charSequence);
        this.f2067b = null;
        if (this.f2078g) {
            p();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f2062a = charSequence;
        this.f2068b = g(charSequence);
        this.f2057a = null;
        if (this.f2078g) {
            p();
        }
    }

    public final void a(boolean z2) {
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, f7943a, z2 ? 1.0f : 0.0f);
        this.f2052a = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.f2052a.setAutoCancel(true);
        this.f2052a.start();
    }

    public final void b() {
        Drawable drawable = this.f2056a;
        if (drawable != null) {
            if (this.f2069b || this.f2073c) {
                Drawable drawableMutate = y.l(drawable).mutate();
                this.f2056a = drawableMutate;
                if (this.f2069b) {
                    y.i(drawableMutate, this.f2053a);
                }
                if (this.f2073c) {
                    y.j(this.f2056a, this.f2054a);
                }
                if (this.f2056a.isStateful()) {
                    this.f2056a.setState(getDrawableState());
                }
            }
        }
    }

    public final void c() {
        Drawable drawable = this.f2066b;
        if (drawable != null) {
            if (this.f2075d || this.f2076e) {
                Drawable drawableMutate = y.l(drawable).mutate();
                this.f2066b = drawableMutate;
                if (this.f2075d) {
                    y.i(drawableMutate, this.f2064b);
                }
                if (this.f2076e) {
                    y.j(this.f2066b, this.f2065b);
                }
                if (this.f2066b.isStateful()) {
                    this.f2066b.setState(getDrawableState());
                }
            }
        }
    }

    public final void d() {
        ObjectAnimator objectAnimator = this.f2052a;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int i2;
        int i3;
        Rect rect = this.f2055a;
        int i4 = this.f7952j;
        int i5 = this.f7953k;
        int i6 = this.f7954l;
        int i7 = this.f7955m;
        int thumbOffset = getThumbOffset() + i4;
        Drawable drawable = this.f2056a;
        Rect rectD = drawable != null ? w.d(drawable) : w.f6400a;
        Drawable drawable2 = this.f2066b;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i8 = rect.left;
            thumbOffset += i8;
            if (rectD != null) {
                int i9 = rectD.left;
                if (i9 > i8) {
                    i4 += i9 - i8;
                }
                int i10 = rectD.top;
                int i11 = rect.top;
                i2 = i10 > i11 ? (i10 - i11) + i5 : i5;
                int i12 = rectD.right;
                int i13 = rect.right;
                if (i12 > i13) {
                    i6 -= i12 - i13;
                }
                int i14 = rectD.bottom;
                int i15 = rect.bottom;
                if (i14 > i15) {
                    i3 = i7 - (i14 - i15);
                }
                this.f2066b.setBounds(i4, i2, i6, i3);
            } else {
                i2 = i5;
            }
            i3 = i7;
            this.f2066b.setBounds(i4, i2, i6, i3);
        }
        Drawable drawable3 = this.f2056a;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i16 = thumbOffset - rect.left;
            int i17 = thumbOffset + this.f7951i + rect.right;
            this.f2056a.setBounds(i16, i5, i17, i7);
            Drawable background = getBackground();
            if (background != null) {
                y.f(background, i16, i5, i17, i7);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableHotspotChanged(float f2, float f3) {
        super.drawableHotspotChanged(f2, f3);
        Drawable drawable = this.f2056a;
        if (drawable != null) {
            y.e(drawable, f2, f3);
        }
        Drawable drawable2 = this.f2066b;
        if (drawable2 != null) {
            y.e(drawable2, f2, f3);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2056a;
        boolean state = false;
        if (drawable != null && drawable.isStateful()) {
            state = false | drawable.setState(drawableState);
        }
        Drawable drawable2 = this.f2066b;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    public final void e(MotionEvent motionEvent) {
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.setAction(3);
        super.onTouchEvent(motionEventObtain);
        motionEventObtain.recycle();
    }

    public final CharSequence g(CharSequence charSequence) {
        TransformationMethod transformationMethodF = getEmojiTextViewHelper().f(this.f2059a);
        return transformationMethodF != null ? transformationMethodF.getTransformation(charSequence, this) : charSequence;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        if (!u0.b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.f7949g;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f2070c : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        if (u0.b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.f7949g;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f2070c : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return lpt1.p(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f2078g;
    }

    public boolean getSplitTrack() {
        return this.f2077f;
    }

    public int getSwitchMinWidth() {
        return this.f2063b;
    }

    public int getSwitchPadding() {
        return this.f2070c;
    }

    public CharSequence getTextOff() {
        return this.f2072c;
    }

    public CharSequence getTextOn() {
        return this.f2062a;
    }

    public Drawable getThumbDrawable() {
        return this.f2056a;
    }

    public int getThumbTextPadding() {
        return this.f2049a;
    }

    public ColorStateList getThumbTintList() {
        return this.f2053a;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.f2054a;
    }

    public Drawable getTrackDrawable() {
        return this.f2066b;
    }

    public ColorStateList getTrackTintList() {
        return this.f2064b;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.f2065b;
    }

    public final boolean h(float f2, float f3) {
        if (this.f2056a == null) {
            return false;
        }
        int thumbOffset = getThumbOffset();
        this.f2056a.getPadding(this.f2055a);
        int i2 = this.f7953k;
        int i3 = this.f7947e;
        int i4 = i2 - i3;
        int i5 = (this.f7952j + thumbOffset) - i3;
        int i6 = this.f7951i + i5;
        Rect rect = this.f2055a;
        return f2 > ((float) i5) && f2 < ((float) (((i6 + rect.left) + rect.right) + i3)) && f3 > ((float) i4) && f3 < ((float) (this.f7955m + i3));
    }

    public final Layout i(CharSequence charSequence) {
        TextPaint textPaint = this.f2058a;
        return new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    public void j() {
        setTextOnInternal(this.f2062a);
        setTextOffInternal(this.f2072c);
        requestLayout();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f2056a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f2066b;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.f2052a;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.f2052a.end();
        this.f2052a = null;
    }

    public final void k() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence string = this.f2072c;
            if (string == null) {
                string = getResources().getString(p001AuX.lpt1.f5611b);
            }
            p024Com2.y.G0(this, string);
        }
    }

    public final void l() {
        if (Build.VERSION.SDK_INT >= 30) {
            CharSequence string = this.f2062a;
            if (string == null) {
                string = getResources().getString(p001AuX.lpt1.f5612c);
            }
            p024Com2.y.G0(this, string);
        }
    }

    public void m(Context context, int i2) {
        q0 q0VarT = q0.t(context, i2, lpt3.f8D);
        ColorStateList colorStateListC = q0VarT.c(lpt3.s2);
        if (colorStateListC != null) {
            this.f2071c = colorStateListC;
        } else {
            this.f2071c = getTextColors();
        }
        int iF = q0VarT.f(lpt3.p2, 0);
        if (iF != 0) {
            float f2 = iF;
            if (f2 != this.f2058a.getTextSize()) {
                this.f2058a.setTextSize(f2);
                requestLayout();
            }
        }
        o(q0VarT.k(lpt3.q2, -1), q0VarT.k(lpt3.r2, -1));
        if (q0VarT.a(lpt3.x2, false)) {
            this.f2059a = new b1(getContext());
        } else {
            this.f2059a = null;
        }
        setTextOnInternal(this.f2062a);
        setTextOffInternal(this.f2072c);
        q0VarT.w();
    }

    public void n(Typeface typeface, int i2) {
        if (i2 <= 0) {
            this.f2058a.setFakeBoldText(false);
            this.f2058a.setTextSkewX(0.0f);
            setSwitchTypeface(typeface);
        } else {
            Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i2) : Typeface.create(typeface, i2);
            setSwitchTypeface(typefaceDefaultFromStyle);
            int i3 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i2;
            this.f2058a.setFakeBoldText((i3 & 1) != 0);
            this.f2058a.setTextSkewX((i3 & 2) != 0 ? -0.25f : 0.0f);
        }
    }

    public final void o(int i2, int i3) {
        Typeface typeface;
        if (i2 == 1) {
            typeface = Typeface.SANS_SERIF;
        } else if (i2 != 2) {
            typeface = i2 != 3 ? null : Typeface.MONOSPACE;
        } else {
            typeface = Typeface.SERIF;
        }
        n(typeface, i3);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i2) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i2 + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f2047a);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Rect rect = this.f2055a;
        Drawable drawable = this.f2066b;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i2 = this.f7953k;
        int i3 = this.f7955m;
        int i4 = i2 + rect.top;
        int i5 = i3 - rect.bottom;
        Drawable drawable2 = this.f2056a;
        if (drawable != null) {
            if (!this.f2077f || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectD = w.d(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectD.left;
                rect.right -= rectD.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = getTargetCheckedState() ? this.f2057a : this.f2067b;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.f2071c;
            if (colorStateList != null) {
                this.f2058a.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.f2058a.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (layout.getWidth() / 2), ((i4 + i5) / 2) - (layout.getHeight() / 2));
            layout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.f2062a : this.f2072c;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(text);
            sb.append(' ');
            sb.append(charSequence);
            accessibilityNodeInfo.setText(sb);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int iMax;
        int width;
        int paddingLeft;
        int i6;
        int paddingTop;
        int height;
        super.onLayout(z2, i2, i3, i4, i5);
        int iMax2 = 0;
        if (this.f2056a != null) {
            Rect rect = this.f2055a;
            Drawable drawable = this.f2066b;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectD = w.d(this.f2056a);
            iMax = Math.max(0, rectD.left - rect.left);
            iMax2 = Math.max(0, rectD.right - rect.right);
        } else {
            iMax = 0;
        }
        if (u0.b(this)) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.f7949g + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.f7949g) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity != 16) {
            if (gravity != 80) {
                paddingTop = getPaddingTop();
                i6 = this.f7950h;
            } else {
                height = getHeight() - getPaddingBottom();
                paddingTop = height - this.f7950h;
            }
            this.f7952j = paddingLeft;
            this.f7953k = paddingTop;
            this.f7955m = height;
            this.f7954l = width;
        }
        int paddingTop2 = ((getPaddingTop() + getHeight()) - getPaddingBottom()) / 2;
        i6 = this.f7950h;
        paddingTop = paddingTop2 - (i6 / 2);
        height = i6 + paddingTop;
        this.f7952j = paddingLeft;
        this.f7953k = paddingTop;
        this.f7955m = height;
        this.f7954l = width;
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i2, int i3) {
        int intrinsicWidth;
        int intrinsicHeight;
        if (this.f2078g) {
            if (this.f2057a == null) {
                this.f2057a = i(this.f2068b);
            }
            if (this.f2067b == null) {
                this.f2067b = i(this.f2074d);
            }
        }
        Rect rect = this.f2055a;
        Drawable drawable = this.f2056a;
        int intrinsicHeight2 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.f2056a.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.f2056a.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        this.f7951i = Math.max(this.f2078g ? Math.max(this.f2057a.getWidth(), this.f2067b.getWidth()) + (this.f2049a * 2) : 0, intrinsicWidth);
        Drawable drawable2 = this.f2066b;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.f2066b.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax = rect.left;
        int iMax2 = rect.right;
        Drawable drawable3 = this.f2056a;
        if (drawable3 != null) {
            Rect rectD = w.d(drawable3);
            iMax = Math.max(iMax, rectD.left);
            iMax2 = Math.max(iMax2, rectD.right);
        }
        int iMax3 = Math.max(this.f2063b, (this.f7951i * 2) + iMax + iMax2);
        int iMax4 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.f7949g = iMax3;
        this.f7950h = iMax4;
        super.onMeasure(i2, i3);
        if (getMeasuredHeight() < iMax4) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax4);
        }
    }

    @Override // android.view.View
    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f2062a : this.f2072c;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0089  */
    /* JADX WARN: Code duplicated, block: B:36:0x008d  */
    /* JADX WARN: Code duplicated, block: B:38:0x0094  */
    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float f2;
        this.f2060a.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            float x2 = motionEvent.getX();
            float y2 = motionEvent.getY();
            if (isEnabled() && h(x2, y2)) {
                this.f7946d = 1;
                this.f2048a = x2;
                this.f7944b = y2;
            }
        } else if (actionMasked == 1) {
            if (this.f7946d == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.f7946d = 0;
            this.f2060a.clear();
        } else if (actionMasked == 2) {
            int i2 = this.f7946d;
            if (i2 == 1) {
                float x3 = motionEvent.getX();
                float y3 = motionEvent.getY();
                if (Math.abs(x3 - this.f2048a) > this.f7947e || Math.abs(y3 - this.f7944b) > this.f7947e) {
                    this.f7946d = 2;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    this.f2048a = x3;
                    this.f7944b = y3;
                    return true;
                }
            } else if (i2 == 2) {
                float x4 = motionEvent.getX();
                int thumbScrollRange = getThumbScrollRange();
                float f3 = x4 - this.f2048a;
                if (thumbScrollRange != 0) {
                    f2 = f3 / thumbScrollRange;
                } else {
                    f2 = f3 > 0.0f ? 1.0f : -1.0f;
                }
                if (u0.b(this)) {
                    f2 = -f2;
                }
                float f4 = f(this.f7945c + f2, 0.0f, 1.0f);
                if (f4 != this.f7945c) {
                    this.f2048a = x4;
                    setThumbPosition(f4);
                }
                return true;
            }
        } else if (actionMasked == 3) {
            if (this.f7946d == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.f7946d = 0;
            this.f2060a.clear();
        }
        return super.onTouchEvent(motionEvent);
    }

    public final void p() {
        if (this.f2061a == null && this.f2050a.b() && androidx.emoji2.text.con.h()) {
            androidx.emoji2.text.con conVarB = androidx.emoji2.text.con.b();
            int iD = conVarB.d();
            if (iD == 3 || iD == 0) {
                con conVar = new con(this);
                this.f2061a = conVar;
                conVarB.s(conVar);
            }
        }
    }

    public final void q(MotionEvent motionEvent) {
        this.f7946d = 0;
        boolean targetCheckedState = true;
        boolean z2 = motionEvent.getAction() == 1 && isEnabled();
        boolean zIsChecked = isChecked();
        if (z2) {
            this.f2060a.computeCurrentVelocity(1000);
            float xVelocity = this.f2060a.getXVelocity();
            if (Math.abs(xVelocity) <= this.f7948f) {
                targetCheckedState = getTargetCheckedState();
            } else if (!u0.b(this) ? xVelocity <= 0.0f : xVelocity >= 0.0f) {
                targetCheckedState = false;
            }
        } else {
            targetCheckedState = zIsChecked;
        }
        if (targetCheckedState != zIsChecked) {
            playSoundEffect(0);
        }
        setChecked(targetCheckedState);
        e(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z2) {
        super.setChecked(z2);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            l();
        } else {
            k();
        }
        if (getWindowToken() != null && p024Com2.y.S(this)) {
            a(zIsChecked);
        } else {
            d();
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(lpt1.q(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().e(z2);
        setTextOnInternal(this.f2062a);
        setTextOffInternal(this.f2072c);
        requestLayout();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z2) {
        if (this.f2078g != z2) {
            this.f2078g = z2;
            requestLayout();
            if (z2) {
                p();
            }
        }
    }

    public void setSplitTrack(boolean z2) {
        this.f2077f = z2;
        invalidate();
    }

    public void setSwitchMinWidth(int i2) {
        this.f2063b = i2;
        requestLayout();
    }

    public void setSwitchPadding(int i2) {
        this.f2070c = i2;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        if ((this.f2058a.getTypeface() == null || this.f2058a.getTypeface().equals(typeface)) && (this.f2058a.getTypeface() != null || typeface == null)) {
            return;
        }
        this.f2058a.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            return;
        }
        k();
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            l();
        }
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f2056a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f2056a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f2) {
        this.f7945c = f2;
        invalidate();
    }

    public void setThumbResource(int i2) {
        setThumbDrawable(AUX.aux.b(getContext(), i2));
    }

    public void setThumbTextPadding(int i2) {
        this.f2049a = i2;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.f2053a = colorStateList;
        this.f2069b = true;
        b();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.f2054a = mode;
        this.f2073c = true;
        b();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f2066b;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f2066b = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i2) {
        setTrackDrawable(AUX.aux.b(getContext(), i2));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.f2064b = colorStateList;
        this.f2075d = true;
        c();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.f2065b = mode;
        this.f2076e = true;
        c();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2056a || drawable == this.f2066b;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.L);
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.f2053a = null;
        this.f2054a = null;
        this.f2069b = false;
        this.f2073c = false;
        this.f2064b = null;
        this.f2065b = null;
        this.f2075d = false;
        this.f2076e = false;
        this.f2060a = VelocityTracker.obtain();
        this.f2055a = new Rect();
        l0.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.f2058a = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = lpt3.f7C;
        q0 q0VarV = q0.v(context, attributeSet, iArr, i2, 0);
        p024Com2.y.m0(this, context, iArr, attributeSet, q0VarV.r(), i2, 0);
        Drawable drawableG = q0VarV.g(lpt3.d2);
        this.f2056a = drawableG;
        if (drawableG != null) {
            drawableG.setCallback(this);
        }
        Drawable drawableG2 = q0VarV.g(lpt3.m2);
        this.f2066b = drawableG2;
        if (drawableG2 != null) {
            drawableG2.setCallback(this);
        }
        setTextOnInternal(q0VarV.p(lpt3.b2));
        setTextOffInternal(q0VarV.p(lpt3.c2));
        this.f2078g = q0VarV.a(lpt3.e2, true);
        this.f2049a = q0VarV.f(lpt3.j2, 0);
        this.f2063b = q0VarV.f(lpt3.g2, 0);
        this.f2070c = q0VarV.f(lpt3.h2, 0);
        this.f2077f = q0VarV.a(lpt3.f2, false);
        ColorStateList colorStateListC = q0VarV.c(lpt3.k2);
        if (colorStateListC != null) {
            this.f2053a = colorStateListC;
            this.f2069b = true;
        }
        PorterDuff.Mode modeE = w.e(q0VarV.k(lpt3.l2, -1), null);
        if (this.f2054a != modeE) {
            this.f2054a = modeE;
            this.f2073c = true;
        }
        if (this.f2069b || this.f2073c) {
            b();
        }
        ColorStateList colorStateListC2 = q0VarV.c(lpt3.n2);
        if (colorStateListC2 != null) {
            this.f2064b = colorStateListC2;
            this.f2075d = true;
        }
        PorterDuff.Mode modeE2 = w.e(q0VarV.k(lpt3.o2, -1), null);
        if (this.f2065b != modeE2) {
            this.f2065b = modeE2;
            this.f2076e = true;
        }
        if (this.f2075d || this.f2076e) {
            c();
        }
        int iN = q0VarV.n(lpt3.i2, 0);
        if (iN != 0) {
            m(context, iN);
        }
        m mVar = new m(this);
        this.f2051a = mVar;
        mVar.m(attributeSet, i2);
        q0VarV.w();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f7947e = viewConfiguration.getScaledTouchSlop();
        this.f7948f = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().c(attributeSet, i2);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
