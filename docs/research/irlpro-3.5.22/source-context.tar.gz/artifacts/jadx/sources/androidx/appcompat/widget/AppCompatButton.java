package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import p001AuX.com3;
import p014CoM2.lpt1;
import p022CoN.l0;
import p022CoN.lpt2;
import p022CoN.lpt9;
import p022CoN.m;
import p022CoN.n0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatButton extends Button implements p014CoM2.prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final lpt2 f7878a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt9 f1977a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final m f1978a;

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com3.f5509q);
    }

    private lpt9 getEmojiTextViewHelper() {
        if (this.f1977a == null) {
            this.f1977a = new lpt9(this);
        }
        return this.f1977a;
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            lpt2Var.b();
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeMaxTextSize();
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            return mVar.e();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeMinTextSize();
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            return mVar.f();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeStepGranularity();
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            return mVar.g();
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        m mVar = this.f1978a;
        return mVar != null ? mVar.h() : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (p014CoM2.prn.f6142a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            return mVar.i();
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return lpt1.p(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            return lpt2Var.c();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            return lpt2Var.d();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1978a.j();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1978a.k();
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.o(z2, i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        m mVar = this.f1978a;
        if (mVar == null || p014CoM2.prn.f6142a || !mVar.l()) {
            return;
        }
        this.f1978a.c();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().d(z2);
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) throws IllegalArgumentException {
        if (p014CoM2.prn.f6142a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.t(i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) throws IllegalArgumentException {
        if (p014CoM2.prn.f6142a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.u(iArr, i2);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (p014CoM2.prn.f6142a) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.v(i2);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            lpt2Var.f(drawable);
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            lpt2Var.g(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(lpt1.q(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().e(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.s(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            lpt2Var.i(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        lpt2 lpt2Var = this.f7878a;
        if (lpt2Var != null) {
            lpt2Var.j(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f1978a.w(colorStateList);
        this.f1978a.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f1978a.x(mode);
        this.f1978a.b();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.q(context, i2);
        }
    }

    @Override // android.widget.TextView
    public void setTextSize(int i2, float f2) {
        if (p014CoM2.prn.f6142a) {
            super.setTextSize(i2, f2);
            return;
        }
        m mVar = this.f1978a;
        if (mVar != null) {
            mVar.A(i2, f2);
        }
    }

    public AppCompatButton(Context context, AttributeSet attributeSet, int i2) {
        super(n0.b(context), attributeSet, i2);
        l0.a(this, getContext());
        lpt2 lpt2Var = new lpt2(this);
        this.f7878a = lpt2Var;
        lpt2Var.e(attributeSet, i2);
        m mVar = new m(this);
        this.f1978a = mVar;
        mVar.m(attributeSet, i2);
        mVar.b();
        getEmojiTextViewHelper().c(attributeSet, i2);
    }
}
