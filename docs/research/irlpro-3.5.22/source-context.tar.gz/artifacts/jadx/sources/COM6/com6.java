package COM6;

/* JADX INFO: loaded from: classes.dex */
public class com6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f5713a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f69a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f5714b;

    public com6(int i2, float f2, float f3) {
        this.f69a = i2;
        this.f5713a = f2;
        this.f5714b = f3;
    }
}
