package a0;

import f.com8;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public final class com5 extends RuntimeException {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final IOException f7613a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public IOException f7614b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public com5(IOException iOException) {
        super(iOException);
        com8.e(iOException, "firstConnectException");
        this.f7613a = iOException;
        this.f7614b = iOException;
    }

    public final void a(IOException iOException) throws IllegalAccessException, InvocationTargetException {
        com8.e(iOException, "e");
        p059Lpt9.com6.a(this.f7613a, iOException);
        this.f7614b = iOException;
    }

    public final IOException c() {
        return this.f7613a;
    }

    public final IOException d() {
        return this.f7614b;
    }
}
