package LPT5;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f6642a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f6643b;

    public aux(long j2, long j3) {
        this.f6642a = j2;
        this.f6643b = j3;
    }
}
