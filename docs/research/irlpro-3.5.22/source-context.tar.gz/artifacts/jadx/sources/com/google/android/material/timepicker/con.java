package com.google.android.material.timepicker;

import android.text.Editable;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputLayout;
import p042LpT1.m;

/* JADX INFO: loaded from: classes.dex */
public class con implements TextView.OnEditorActionListener, View.OnKeyListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final m f9712a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ChipTextInputComboView f3798a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ChipTextInputComboView f9713b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f3799b = false;

    public con(ChipTextInputComboView chipTextInputComboView, ChipTextInputComboView chipTextInputComboView2, m mVar) {
        this.f3798a = chipTextInputComboView;
        this.f9713b = chipTextInputComboView2;
        this.f9712a = mVar;
    }

    public void a() {
        TextInputLayout textInputLayoutE = this.f3798a.e();
        TextInputLayout textInputLayoutE2 = this.f9713b.e();
        EditText editText = textInputLayoutE.getEditText();
        EditText editText2 = textInputLayoutE2.getEditText();
        editText.setImeOptions(268435461);
        editText2.setImeOptions(268435462);
        editText.setOnEditorActionListener(this);
        editText.setOnKeyListener(this);
        editText2.setOnKeyListener(this);
    }

    public final void b(int i2) {
        this.f9713b.setChecked(i2 == 12);
        this.f3798a.setChecked(i2 == 10);
        this.f9712a.f7040d = i2;
    }

    public final boolean c(int i2, KeyEvent keyEvent, EditText editText) {
        Editable text = editText.getText();
        if (text == null) {
            return false;
        }
        if (!(i2 >= 7 && i2 <= 16 && keyEvent.getAction() == 1 && editText.getSelectionStart() == 2 && text.length() == 2)) {
            return false;
        }
        b(12);
        return true;
    }

    public final boolean d(int i2, KeyEvent keyEvent, EditText editText) {
        if (!(i2 == 67 && keyEvent.getAction() == 0 && TextUtils.isEmpty(editText.getText()))) {
            return false;
        }
        b(10);
        return true;
    }

    @Override // android.widget.TextView.OnEditorActionListener
    public boolean onEditorAction(TextView textView, int i2, KeyEvent keyEvent) {
        boolean z2 = i2 == 5;
        if (z2) {
            b(12);
        }
        return z2;
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (this.f3799b) {
            return false;
        }
        this.f3799b = true;
        EditText editText = (EditText) view;
        boolean zD = this.f9712a.f7040d == 12 ? d(i2, keyEvent, editText) : c(i2, keyEvent, editText);
        this.f3799b = false;
        return zD;
    }
}
