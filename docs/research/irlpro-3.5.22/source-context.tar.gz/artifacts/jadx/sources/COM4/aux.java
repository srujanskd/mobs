package COM4;

/* JADX INFO: loaded from: classes.dex */
public final class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final int f5698a = 2131296947;
}
