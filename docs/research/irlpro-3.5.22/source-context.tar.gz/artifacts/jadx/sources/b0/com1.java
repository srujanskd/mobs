package b0;

import f.com8;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import m.lpt1;
import p127lPt9.l0;
import v.com9;
import v.g;
import v.lpt8;
import v.lpt9;

/* JADX INFO: loaded from: classes.dex */
public final class com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final i0.prn f8788a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final i0.prn f8789b;

    static {
        i0.prn.aux auxVar = i0.prn.f10789a;
        f8788a = auxVar.c("\"\\");
        f8789b = auxVar.c("\t ,=");
    }

    public static final List<v.com4> a(lpt8 lpt8Var, String str) {
        com8.e(lpt8Var, "<this>");
        com8.e(str, "headerName");
        ArrayList arrayList = new ArrayList();
        int size = lpt8Var.size();
        int i2 = 0;
        while (i2 < size) {
            int i3 = i2 + 1;
            if (lpt1.q(str, lpt8Var.b(i2), true)) {
                try {
                    c(new i0.con().g(lpt8Var.d(i2)), arrayList);
                } catch (EOFException e2) {
                    e0.com6.f10703a.g().j("Unable to parse challenge", 5, e2);
                }
            }
            i2 = i3;
        }
        return arrayList;
    }

    public static final boolean b(g gVar) {
        com8.e(gVar, "<this>");
        if (com8.a(gVar.V().g(), "HEAD")) {
            return false;
        }
        int iL = gVar.l();
        return (((iL >= 100 && iL < 200) || iL == 204 || iL == 304) && w.com1.v(gVar) == -1 && !lpt1.q("chunked", g.y(gVar, "Transfer-Encoding", null, 2, null), true)) ? false : true;
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0084  */
    /* JADX WARN: Code duplicated, block: B:37:0x0097  */
    /* JADX WARN: Code duplicated, block: B:38:0x009c  */
    /* JADX WARN: Code duplicated, block: B:59:0x0079 A[EDGE_INSN: B:59:0x0079->B:28:0x0079 BREAK  A[LOOP:2: B:22:0x0066->B:49:0x00b9], SYNTHETIC] */
    public static final void c(i0.con conVar, List<v.com4> list) throws EOFException {
        String strE;
        while (true) {
            String strE2 = null;
            while (true) {
                if (strE2 == null) {
                    g(conVar);
                    strE2 = e(conVar);
                    if (strE2 == null) {
                        return;
                    }
                }
                boolean zG = g(conVar);
                String strE3 = e(conVar);
                if (strE3 == null) {
                    if (conVar.K()) {
                        list.add(new v.com4(strE2, l0.d()));
                        return;
                    }
                    return;
                }
                int iK = w.com1.K(conVar, (byte) 61);
                boolean zG2 = g(conVar);
                if (zG || !(zG2 || conVar.K())) {
                    LinkedHashMap linkedHashMap = new LinkedHashMap();
                    int iK2 = iK + w.com1.K(conVar, (byte) 61);
                    while (true) {
                        if (strE3 == null) {
                            strE3 = e(conVar);
                            if (g(conVar)) {
                                break;
                            }
                            iK2 = w.com1.K(conVar, (byte) 61);
                            if (iK2 == 0) {
                                break;
                            }
                            if (iK2 <= 1 || g(conVar)) {
                                return;
                            }
                            if (h(conVar, (byte) 34)) {
                                strE = d(conVar);
                            } else {
                                strE = e(conVar);
                            }
                            if (strE != null || ((String) linkedHashMap.put(strE3, strE)) != null) {
                                return;
                            }
                            if (g(conVar) && !conVar.K()) {
                                return;
                            } else {
                                strE3 = null;
                            }
                        } else {
                            if (iK2 == 0) {
                                break;
                                break;
                            }
                            if (iK2 <= 1) {
                                return;
                            }
                            if (h(conVar, (byte) 34)) {
                                strE = d(conVar);
                            } else {
                                strE = e(conVar);
                            }
                            if (strE != null) {
                                return;
                            }
                            if (g(conVar)) {
                            }
                            strE3 = null;
                        }
                    }
                    list.add(new v.com4(strE2, linkedHashMap));
                    strE2 = strE3;
                } else {
                    Map mapSingletonMap = Collections.singletonMap(null, com8.k(strE3, lpt1.u("=", iK)));
                    com8.d(mapSingletonMap, "singletonMap<String, Str…ek + \"=\".repeat(eqCount))");
                    list.add(new v.com4(strE2, mapSingletonMap));
                }
            }
        }
    }

    public static final String d(i0.con conVar) throws EOFException {
        if (!(conVar.readByte() == 34)) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        i0.con conVar2 = new i0.con();
        while (true) {
            long jP = conVar.p(f8788a);
            if (jP == -1) {
                return null;
            }
            if (conVar.n(jP) == 34) {
                conVar2.e(conVar, jP);
                conVar.readByte();
                return conVar2.G();
            }
            if (conVar.size() == jP + 1) {
                return null;
            }
            conVar2.e(conVar, jP);
            conVar.readByte();
            conVar2.e(conVar, 1L);
        }
    }

    public static final String e(i0.con conVar) {
        long jP = conVar.p(f8789b);
        if (jP == -1) {
            jP = conVar.size();
        }
        if (jP != 0) {
            return conVar.H(jP);
        }
        return null;
    }

    public static final void f(v.lpt1 lpt1Var, lpt9 lpt9Var, lpt8 lpt8Var) {
        com8.e(lpt1Var, "<this>");
        com8.e(lpt9Var, "url");
        com8.e(lpt8Var, "headers");
        if (lpt1Var == v.lpt1.f5416a) {
            return;
        }
        List<com9> listE = com9.f5371a.e(lpt9Var, lpt8Var);
        if (listE.isEmpty()) {
            return;
        }
        lpt1Var.b(lpt9Var, listE);
    }

    public static final boolean g(i0.con conVar) throws EOFException {
        boolean z2 = false;
        while (!conVar.K()) {
            byte bN = conVar.n(0L);
            boolean z3 = true;
            if (bN != 44) {
                if (bN != 32 && bN != 9) {
                    z3 = false;
                }
                if (!z3) {
                    break;
                }
                conVar.readByte();
            } else {
                conVar.readByte();
                z2 = true;
            }
        }
        return z2;
    }

    public static final boolean h(i0.con conVar, byte b2) {
        return !conVar.K() && conVar.n(0L) == b2;
    }
}
