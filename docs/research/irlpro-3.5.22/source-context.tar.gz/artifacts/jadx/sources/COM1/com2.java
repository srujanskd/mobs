package COM1;

import android.text.TextUtils;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public final class com2 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Locale f5685a = new Locale("", "");

    public static class aux {
        public static int a(Locale locale) {
            return TextUtils.getLayoutDirectionFromLocale(locale);
        }
    }

    public static int a(Locale locale) {
        return aux.a(locale);
    }
}
