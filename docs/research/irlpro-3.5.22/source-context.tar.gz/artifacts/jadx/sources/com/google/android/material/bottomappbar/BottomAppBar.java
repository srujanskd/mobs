package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p075cOM6.g4;
import p075cOM6.w3;
import p075cOM6.z3;
import p080cOm1.y;
import p086cOm7.com7;
import p108com9.v;

/* JADX INFO: loaded from: classes.dex */
public class BottomAppBar extends Toolbar implements CoordinatorLayout.con {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final int f9296u = g4.f8968m;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final COM9.com3 f9297a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Animator f3317a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public AnimatorListenerAdapter f3318a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Behavior f3319a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Integer f3320a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Animator f9298b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList<com3> f9299d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f9300e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f9301f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f9302g;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f9303m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f9304n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f9305o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f9306p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f9307q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f9308r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f9309s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f9310t;

    public class aux extends AnimatorListenerAdapter {
        public aux() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BottomAppBar.this.m0();
            BottomAppBar.this.f3317a = null;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.n0();
        }
    }

    public class com1 implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9315a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ActionMenuView f3323a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final /* synthetic */ boolean f9316b;

        public com1(ActionMenuView actionMenuView, int i2, boolean z2) {
            this.f3323a = actionMenuView;
            this.f9315a = i2;
            this.f9316b = z2;
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionMenuView actionMenuView = this.f3323a;
            actionMenuView.setTranslationX(BottomAppBar.this.q0(actionMenuView, this.f9315a, this.f9316b));
        }
    }

    public class com2 extends AnimatorListenerAdapter {
        public com2() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.f3318a.onAnimationStart(animator);
            FloatingActionButton floatingActionButtonO0 = BottomAppBar.this.o0();
            if (floatingActionButtonO0 != null) {
                floatingActionButtonO0.setTranslationX(BottomAppBar.this.getFabTranslationX());
            }
        }
    }

    public interface com3 {
        void a(BottomAppBar bottomAppBar);

        void b(BottomAppBar bottomAppBar);
    }

    public static class com4 extends COM2.aux {
        public static final Parcelable.Creator<com4> CREATOR = new aux();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f9318a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9319b;

        public class aux implements Parcelable.ClassLoaderCreator<com4> {
            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public com4 createFromParcel(Parcel parcel) {
                return new com4(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public com4 createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new com4(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public com4[] newArray(int i2) {
                return new com4[i2];
            }
        }

        public com4(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // COM2.aux, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i2) {
            super.writeToParcel(parcel, i2);
            parcel.writeInt(this.f9318a);
            parcel.writeInt(this.f9319b ? 1 : 0);
        }

        public com4(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f9318a = parcel.readInt();
            this.f9319b = parcel.readInt() != 0;
        }
    }

    public class con extends FloatingActionButton.con {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9320a;

        public class aux extends FloatingActionButton.con {
            public aux() {
            }

            @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.con
            public void b(FloatingActionButton floatingActionButton) {
                BottomAppBar.this.m0();
            }
        }

        public con(int i2) {
            this.f9320a = i2;
        }

        @Override // com.google.android.material.floatingactionbutton.FloatingActionButton.con
        public void a(FloatingActionButton floatingActionButton) {
            floatingActionButton.setTranslationX(BottomAppBar.this.r0(this.f9320a));
            floatingActionButton.s(new aux());
        }
    }

    public class nul extends AnimatorListenerAdapter {
        public nul() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            BottomAppBar.this.m0();
            BottomAppBar.this.f9301f = false;
            BottomAppBar.this.f9298b = null;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            BottomAppBar.this.n0();
        }
    }

    public class prn extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f9323a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final /* synthetic */ ActionMenuView f3326a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f9324b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final /* synthetic */ boolean f9325c;

        public prn(ActionMenuView actionMenuView, int i2, boolean z2) {
            this.f3326a = actionMenuView;
            this.f9323a = i2;
            this.f9325c = z2;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f9324b = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f9324b) {
                return;
            }
            boolean z2 = BottomAppBar.this.f9307q != 0;
            BottomAppBar bottomAppBar = BottomAppBar.this;
            bottomAppBar.w0(bottomAppBar.f9307q);
            BottomAppBar.this.C0(this.f3326a, this.f9323a, this.f9325c, z2);
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getBottomInset() {
        return this.f9308r;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public float getFabTranslationX() {
        return r0(this.f9304n);
    }

    private float getFabTranslationY() {
        return -getTopEdgeTreatment().c();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getLeftInset() {
        return this.f9310t;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int getRightInset() {
        return this.f9309s;
    }

    private com7 getTopEdgeTreatment() {
        return (com7) this.f9297a.D().p();
    }

    public boolean A0(int i2) {
        float f2 = i2;
        if (f2 == getTopEdgeTreatment().g()) {
            return false;
        }
        getTopEdgeTreatment().l(f2);
        this.f9297a.invalidateSelf();
        return true;
    }

    public final void B0(ActionMenuView actionMenuView, int i2, boolean z2) {
        C0(actionMenuView, i2, z2, false);
    }

    public final void C0(ActionMenuView actionMenuView, int i2, boolean z2, boolean z3) {
        com1 com1Var = new com1(actionMenuView, i2, z2);
        if (z3) {
            actionMenuView.post(com1Var);
        } else {
            com1Var.run();
        }
    }

    public ColorStateList getBackgroundTint() {
        return this.f9297a.F();
    }

    public float getCradleVerticalOffset() {
        return getTopEdgeTreatment().c();
    }

    public int getFabAlignmentMode() {
        return this.f9304n;
    }

    public int getFabAnimationMode() {
        return this.f9305o;
    }

    public float getFabCradleMargin() {
        return getTopEdgeTreatment().e();
    }

    public float getFabCradleRoundedCornerRadius() {
        return getTopEdgeTreatment().f();
    }

    public boolean getHideOnScroll() {
        return this.f9300e;
    }

    public final void h0(FloatingActionButton floatingActionButton) {
        floatingActionButton.e(this.f3318a);
        floatingActionButton.f(new com2());
        floatingActionButton.g(null);
    }

    public final void i0() {
        Animator animator = this.f9298b;
        if (animator != null) {
            animator.cancel();
        }
        Animator animator2 = this.f3317a;
        if (animator2 != null) {
            animator2.cancel();
        }
    }

    public void j0(int i2, List<Animator> list) {
        FloatingActionButton floatingActionButtonO0 = o0();
        if (floatingActionButtonO0 == null || floatingActionButtonO0.n()) {
            return;
        }
        n0();
        floatingActionButtonO0.l(new con(i2));
    }

    public final void k0(int i2, List<Animator> list) {
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(o0(), "translationX", r0(i2));
        objectAnimatorOfFloat.setDuration(300L);
        list.add(objectAnimatorOfFloat);
    }

    public final void l0(int i2, boolean z2, List<Animator> list) {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView == null) {
            return;
        }
        Animator animatorOfFloat = ObjectAnimator.ofFloat(actionMenuView, "alpha", 1.0f);
        if (Math.abs(actionMenuView.getTranslationX() - q0(actionMenuView, i2, z2)) <= 1.0f) {
            if (actionMenuView.getAlpha() < 1.0f) {
                list.add(animatorOfFloat);
            }
        } else {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(actionMenuView, "alpha", 0.0f);
            objectAnimatorOfFloat.addListener(new prn(actionMenuView, i2, z2));
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.setDuration(150L);
            animatorSet.playSequentially(objectAnimatorOfFloat, animatorOfFloat);
            list.add(animatorSet);
        }
    }

    public final void m0() {
        ArrayList<com3> arrayList;
        int i2 = this.f9306p - 1;
        this.f9306p = i2;
        if (i2 != 0 || (arrayList = this.f9299d) == null) {
            return;
        }
        Iterator<com3> it = arrayList.iterator();
        while (it.hasNext()) {
            it.next().b(this);
        }
    }

    public final void n0() {
        ArrayList<com3> arrayList;
        int i2 = this.f9306p;
        this.f9306p = i2 + 1;
        if (i2 != 0 || (arrayList = this.f9299d) == null) {
            return;
        }
        Iterator<com3> it = arrayList.iterator();
        while (it.hasNext()) {
            it.next().a(this);
        }
    }

    public final FloatingActionButton o0() {
        View viewP0 = p0();
        if (viewP0 instanceof FloatingActionButton) {
            return (FloatingActionButton) viewP0;
        }
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        COM9.com4.f(this, this.f9297a);
        if (getParent() instanceof ViewGroup) {
            ((ViewGroup) getParent()).setClipChildren(false);
        }
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        if (z2) {
            i0();
            y0();
        }
        x0();
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof com4)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        com4 com4Var = (com4) parcelable;
        super.onRestoreInstanceState(com4Var.k());
        this.f9304n = com4Var.f9318a;
        this.f9302g = com4Var.f9319b;
    }

    @Override // androidx.appcompat.widget.Toolbar, android.view.View
    public Parcelable onSaveInstanceState() {
        com4 com4Var = new com4(super.onSaveInstanceState());
        com4Var.f9318a = this.f9304n;
        com4Var.f9319b = this.f9302g;
        return com4Var;
    }

    public final View p0() {
        if (!(getParent() instanceof CoordinatorLayout)) {
            return null;
        }
        for (View view : ((CoordinatorLayout) getParent()).s(this)) {
            if ((view instanceof FloatingActionButton) || (view instanceof ExtendedFloatingActionButton)) {
                return view;
            }
        }
        return null;
    }

    public int q0(ActionMenuView actionMenuView, int i2, boolean z2) {
        if (i2 != 1 || !z2) {
            return 0;
        }
        boolean zE = v.e(this);
        int measuredWidth = zE ? getMeasuredWidth() : 0;
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            View childAt = getChildAt(i3);
            if ((childAt.getLayoutParams() instanceof Toolbar.com1) && (((Toolbar.com1) childAt.getLayoutParams()).f7709a & 8388615) == 8388611) {
                measuredWidth = zE ? Math.min(measuredWidth, childAt.getLeft()) : Math.max(measuredWidth, childAt.getRight());
            }
        }
        return measuredWidth - ((zE ? actionMenuView.getRight() : actionMenuView.getLeft()) + (zE ? this.f9309s : -this.f9310t));
    }

    public final float r0(int i2) {
        boolean zE = v.e(this);
        if (i2 == 1) {
            return ((getMeasuredWidth() / 2) - (this.f9303m + (zE ? this.f9310t : this.f9309s))) * (zE ? -1 : 1);
        }
        return 0.0f;
    }

    public final boolean s0() {
        FloatingActionButton floatingActionButtonO0 = o0();
        return floatingActionButtonO0 != null && floatingActionButtonO0.o();
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        y.i(this.f9297a, colorStateList);
    }

    public void setCradleVerticalOffset(float f2) {
        if (f2 != getCradleVerticalOffset()) {
            getTopEdgeTreatment().h(f2);
            this.f9297a.invalidateSelf();
            y0();
        }
    }

    @Override // android.view.View
    public void setElevation(float f2) {
        this.f9297a.X(f2);
        getBehavior().I(this, this.f9297a.C() - this.f9297a.B());
    }

    public void setFabAlignmentMode(int i2) {
        z0(i2, 0);
    }

    public void setFabAnimationMode(int i2) {
        this.f9305o = i2;
    }

    public void setFabCornerSize(float f2) {
        if (f2 != getTopEdgeTreatment().d()) {
            getTopEdgeTreatment().i(f2);
            this.f9297a.invalidateSelf();
        }
    }

    public void setFabCradleMargin(float f2) {
        if (f2 != getFabCradleMargin()) {
            getTopEdgeTreatment().j(f2);
            this.f9297a.invalidateSelf();
        }
    }

    public void setFabCradleRoundedCornerRadius(float f2) {
        if (f2 != getFabCradleRoundedCornerRadius()) {
            getTopEdgeTreatment().k(f2);
            this.f9297a.invalidateSelf();
        }
    }

    public void setHideOnScroll(boolean z2) {
        this.f9300e = z2;
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setNavigationIcon(Drawable drawable) {
        super.setNavigationIcon(v0(drawable));
    }

    public void setNavigationIconTint(int i2) {
        this.f3320a = Integer.valueOf(i2);
        Drawable navigationIcon = getNavigationIcon();
        if (navigationIcon != null) {
            setNavigationIcon(navigationIcon);
        }
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setSubtitle(CharSequence charSequence) {
    }

    @Override // androidx.appcompat.widget.Toolbar
    public void setTitle(CharSequence charSequence) {
    }

    public final void t0(int i2, boolean z2) {
        if (!p024Com2.y.S(this)) {
            this.f9301f = false;
            w0(this.f9307q);
            return;
        }
        Animator animator = this.f9298b;
        if (animator != null) {
            animator.cancel();
        }
        ArrayList arrayList = new ArrayList();
        if (!s0()) {
            i2 = 0;
            z2 = false;
        }
        l0(i2, z2, arrayList);
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(arrayList);
        this.f9298b = animatorSet;
        animatorSet.addListener(new nul());
        this.f9298b.start();
    }

    public final void u0(int i2) {
        if (this.f9304n == i2 || !p024Com2.y.S(this)) {
            return;
        }
        Animator animator = this.f3317a;
        if (animator != null) {
            animator.cancel();
        }
        ArrayList arrayList = new ArrayList();
        if (this.f9305o == 1) {
            k0(i2, arrayList);
        } else {
            j0(i2, arrayList);
        }
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playTogether(arrayList);
        this.f3317a = animatorSet;
        animatorSet.addListener(new aux());
        this.f3317a.start();
    }

    public final Drawable v0(Drawable drawable) {
        if (drawable == null || this.f3320a == null) {
            return drawable;
        }
        Drawable drawableL = y.l(drawable.mutate());
        y.h(drawableL, this.f3320a.intValue());
        return drawableL;
    }

    public void w0(int i2) {
        if (i2 != 0) {
            this.f9307q = 0;
            getMenu().clear();
            x(i2);
        }
    }

    public final void x0() {
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView == null || this.f9298b != null) {
            return;
        }
        actionMenuView.setAlpha(1.0f);
        if (s0()) {
            B0(actionMenuView, this.f9304n, this.f9302g);
        } else {
            B0(actionMenuView, 0, false);
        }
    }

    public final void y0() {
        getTopEdgeTreatment().m(getFabTranslationX());
        View viewP0 = p0();
        this.f9297a.Z((this.f9302g && s0()) ? 1.0f : 0.0f);
        if (viewP0 != null) {
            viewP0.setTranslationY(getFabTranslationY());
            viewP0.setTranslationX(getFabTranslationX());
        }
    }

    public void z0(int i2, int i3) {
        this.f9307q = i3;
        this.f9301f = true;
        t0(i2, this.f9302g);
        u0(i2);
        this.f9304n = i2;
    }

    @Override // androidx.coordinatorlayout.widget.CoordinatorLayout.con
    public Behavior getBehavior() {
        if (this.f3319a == null) {
            this.f3319a = new Behavior();
        }
        return this.f3319a;
    }

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Rect f9311a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public final View.OnLayoutChangeListener f3321a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public WeakReference<BottomAppBar> f3322a;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f9312d;

        public class aux implements View.OnLayoutChangeListener {
            public aux() {
            }

            @Override // android.view.View.OnLayoutChangeListener
            public void onLayoutChange(View view, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
                BottomAppBar bottomAppBar = (BottomAppBar) Behavior.this.f3322a.get();
                if (bottomAppBar == null || !(view instanceof FloatingActionButton)) {
                    view.removeOnLayoutChangeListener(this);
                    return;
                }
                FloatingActionButton floatingActionButton = (FloatingActionButton) view;
                floatingActionButton.j(Behavior.this.f9311a);
                int iHeight = Behavior.this.f9311a.height();
                bottomAppBar.A0(iHeight);
                bottomAppBar.setFabCornerSize(floatingActionButton.getShapeAppearanceModel().r().a(new RectF(Behavior.this.f9311a)));
                CoordinatorLayout.com2 com2Var = (CoordinatorLayout.com2) view.getLayoutParams();
                if (Behavior.this.f9312d == 0) {
                    ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin = bottomAppBar.getBottomInset() + (bottomAppBar.getResources().getDimensionPixelOffset(z3.F) - ((floatingActionButton.getMeasuredHeight() - iHeight) / 2));
                    ((ViewGroup.MarginLayoutParams) com2Var).leftMargin = bottomAppBar.getLeftInset();
                    ((ViewGroup.MarginLayoutParams) com2Var).rightMargin = bottomAppBar.getRightInset();
                    if (v.e(floatingActionButton)) {
                        ((ViewGroup.MarginLayoutParams) com2Var).leftMargin += bottomAppBar.f9303m;
                    } else {
                        ((ViewGroup.MarginLayoutParams) com2Var).rightMargin += bottomAppBar.f9303m;
                    }
                }
            }
        }

        public Behavior() {
            this.f3321a = new aux();
            this.f9311a = new Rect();
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: Q, reason: merged with bridge method [inline-methods] */
        public boolean l(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, int i2) {
            this.f3322a = new WeakReference<>(bottomAppBar);
            View viewP0 = bottomAppBar.p0();
            if (viewP0 != null && !p024Com2.y.S(viewP0)) {
                CoordinatorLayout.com2 com2Var = (CoordinatorLayout.com2) viewP0.getLayoutParams();
                com2Var.f8159b = 49;
                this.f9312d = ((ViewGroup.MarginLayoutParams) com2Var).bottomMargin;
                if (viewP0 instanceof FloatingActionButton) {
                    FloatingActionButton floatingActionButton = (FloatingActionButton) viewP0;
                    if (floatingActionButton.getShowMotionSpec() == null) {
                        floatingActionButton.setShowMotionSpecResource(w3.f9023b);
                    }
                    if (floatingActionButton.getHideMotionSpec() == null) {
                        floatingActionButton.setHideMotionSpecResource(w3.f9022a);
                    }
                    floatingActionButton.addOnLayoutChangeListener(this.f3321a);
                    bottomAppBar.h0(floatingActionButton);
                }
                bottomAppBar.y0();
            }
            coordinatorLayout.I(bottomAppBar, i2);
            return super.l(coordinatorLayout, bottomAppBar, i2);
        }

        @Override // com.google.android.material.behavior.HideBottomViewOnScrollBehavior, androidx.coordinatorlayout.widget.CoordinatorLayout.nul
        /* JADX INFO: renamed from: R, reason: merged with bridge method [inline-methods] */
        public boolean A(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, View view, View view2, int i2, int i3) {
            return bottomAppBar.getHideOnScroll() && super.A(coordinatorLayout, bottomAppBar, view, view2, i2, i3);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f3321a = new aux();
            this.f9311a = new Rect();
        }
    }
}
