package androidx.appcompat.view.menu;

/* JADX INFO: loaded from: classes.dex */
public interface com6 {

    public interface aux {
        void b(com3 com3Var, int i2);

        boolean d();

        com3 getItemData();
    }

    void c(com1 com1Var);
}
