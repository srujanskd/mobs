package androidx.activity;

import COM3.com7;
import COM3.lpt7;
import COM3.lpt8;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.com5;
import androidx.savedstate.SavedStateRegistry;
import java.util.concurrent.atomic.AtomicInteger;
import p000AUx.com2;
import p002Aux.lpt6;
import p067aUx.i;
import p067aUx.j;
import p068auX.k;
import p084cOm5.d0;
import p150pRN.a;
import p150pRN.d;
import p150pRN.lpt9;

/* JADX INFO: loaded from: classes.dex */
public class ComponentActivity extends d implements lpt7, COM4.con, lpt6, p000AUx.com1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f7714a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public COM3.lpt6 f1700a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final i f1701a = new i();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final androidx.lifecycle.com1 f7715b = new androidx.lifecycle.com1(this);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final androidx.savedstate.aux f1704a = androidx.savedstate.aux.a(this);

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final OnBackPressedDispatcher f1702a = new OnBackPressedDispatcher(new aux());

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final AtomicInteger f1705a = new AtomicInteger();

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final ActivityResultRegistry f1703a = new con();

    public class aux implements Runnable {
        public aux() {
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                ComponentActivity.super.onBackPressed();
            } catch (IllegalStateException e2) {
                if (!TextUtils.equals(e2.getMessage(), "Can not perform this action after onSaveInstanceState")) {
                    throw e2;
                }
            }
        }
    }

    public static final class com1 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public COM3.lpt6 f7720a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Object f1706a;
    }

    public class con extends ActivityResultRegistry {

        public class aux implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ int f7722a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ k.aux f1708a;

            public aux(int i2, k.aux auxVar) {
                this.f7722a = i2;
                this.f1708a = auxVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                con.this.c(this.f7722a, this.f1708a.a());
            }
        }

        /* JADX INFO: renamed from: androidx.activity.ComponentActivity$con$con, reason: collision with other inner class name */
        public class RunnableC0021con implements Runnable {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public final /* synthetic */ int f7723a;

            /* JADX INFO: renamed from: a, reason: collision with other field name */
            public final /* synthetic */ IntentSender.SendIntentException f1709a;

            public RunnableC0021con(int i2, IntentSender.SendIntentException sendIntentException) {
                this.f7723a = i2;
                this.f1709a = sendIntentException;
            }

            @Override // java.lang.Runnable
            public void run() {
                con.this.b(this.f7723a, 0, new Intent().setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", this.f1709a));
            }
        }

        public con() {
        }

        @Override // androidx.activity.result.ActivityResultRegistry
        public <I, O> void f(int i2, k<I, O> kVar, I i3, a aVar) {
            Bundle bundle;
            ComponentActivity componentActivity = ComponentActivity.this;
            k.aux<O> auxVarB = kVar.b(componentActivity, i3);
            if (auxVarB != null) {
                new Handler(Looper.getMainLooper()).post(new aux(i2, auxVarB));
                return;
            }
            Intent intentA = kVar.a(componentActivity, i3);
            if (intentA.getExtras() != null && intentA.getExtras().getClassLoader() == null) {
                intentA.setExtrasClassLoader(componentActivity.getClassLoader());
            }
            if (intentA.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
                Bundle bundleExtra = intentA.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                intentA.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                bundle = bundleExtra;
            } else {
                bundle = null;
            }
            if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intentA.getAction())) {
                String[] stringArrayExtra = intentA.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                if (stringArrayExtra == null) {
                    stringArrayExtra = new String[0];
                }
                lpt9.l(componentActivity, stringArrayExtra, i2);
                return;
            }
            if (!"androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(intentA.getAction())) {
                lpt9.n(componentActivity, intentA, i2, bundle);
                return;
            }
            com2 com2Var = (com2) intentA.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
            try {
                lpt9.o(componentActivity, com2Var.o(), i2, com2Var.k(), com2Var.m(), com2Var.n(), 0, bundle);
            } catch (IntentSender.SendIntentException e2) {
                new Handler(Looper.getMainLooper()).post(new RunnableC0021con(i2, e2));
            }
        }
    }

    public class nul implements SavedStateRegistry.con {
        public nul() {
        }

        @Override // androidx.savedstate.SavedStateRegistry.con
        @SuppressLint({"SyntheticAccessor"})
        public Bundle a() {
            Bundle bundle = new Bundle();
            ComponentActivity.this.f1703a.h(bundle);
            return bundle;
        }
    }

    public class prn implements j {
        public prn() {
        }

        @Override // p067aUx.j
        @SuppressLint({"SyntheticAccessor"})
        public void a(Context context) {
            Bundle bundleA = ComponentActivity.this.getSavedStateRegistry().a("android:support:activity-result");
            if (bundleA != null) {
                ComponentActivity.this.f1703a.g(bundleA);
            }
        }
    }

    public ComponentActivity() {
        if (getLifecycle() == null) {
            throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
        }
        getLifecycle().a(new androidx.lifecycle.prn() { // from class: androidx.activity.ComponentActivity.3
            @Override // androidx.lifecycle.prn
            public void f(com7 com7Var, androidx.lifecycle.nul.con conVar) {
                if (conVar == androidx.lifecycle.nul.con.ON_STOP) {
                    Window window = ComponentActivity.this.getWindow();
                    View viewPeekDecorView = window != null ? window.peekDecorView() : null;
                    if (viewPeekDecorView != null) {
                        viewPeekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        getLifecycle().a(new androidx.lifecycle.prn() { // from class: androidx.activity.ComponentActivity.4
            @Override // androidx.lifecycle.prn
            public void f(com7 com7Var, androidx.lifecycle.nul.con conVar) {
                if (conVar == androidx.lifecycle.nul.con.ON_DESTROY) {
                    ComponentActivity.this.f1701a.b();
                    if (ComponentActivity.this.isChangingConfigurations()) {
                        return;
                    }
                    ComponentActivity.this.getViewModelStore().a();
                }
            }
        });
        getLifecycle().a(new androidx.lifecycle.prn() { // from class: androidx.activity.ComponentActivity.5
            @Override // androidx.lifecycle.prn
            public void f(com7 com7Var, androidx.lifecycle.nul.con conVar) {
                ComponentActivity.this.K();
                ComponentActivity.this.getLifecycle().c(this);
            }
        });
        getSavedStateRegistry().d("android:support:activity-result", new nul());
        J(new prn());
    }

    @Override // p000AUx.com1
    public final ActivityResultRegistry E() {
        return this.f1703a;
    }

    @Override // p002Aux.lpt6
    public final OnBackPressedDispatcher G() {
        return this.f1702a;
    }

    public final void J(j jVar) {
        this.f1701a.a(jVar);
    }

    public void K() {
        if (this.f1700a == null) {
            com1 com1Var = (com1) getLastNonConfigurationInstance();
            if (com1Var != null) {
                this.f1700a = com1Var.f7720a;
            }
            if (this.f1700a == null) {
                this.f1700a = new COM3.lpt6();
            }
        }
    }

    public final void L() {
        lpt8.a(getWindow().getDecorView(), this);
        COM3.lpt9.a(getWindow().getDecorView(), this);
        COM4.nul.a(getWindow().getDecorView(), this);
    }

    @Deprecated
    public Object M() {
        return null;
    }

    public final <I, O> p000AUx.prn<I> N(k<I, O> kVar, p000AUx.nul<O> nulVar) {
        return O(kVar, this.f1703a, nulVar);
    }

    public final <I, O> p000AUx.prn<I> O(k<I, O> kVar, ActivityResultRegistry activityResultRegistry, p000AUx.nul<O> nulVar) {
        return activityResultRegistry.i("activity_rq#" + this.f1705a.getAndIncrement(), this, kVar, nulVar);
    }

    @Override // android.app.Activity
    public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams layoutParams) {
        L();
        super.addContentView(view, layoutParams);
    }

    @Override // p150pRN.d, COM3.com7
    public androidx.lifecycle.nul getLifecycle() {
        return this.f7715b;
    }

    @Override // COM4.con
    public final SavedStateRegistry getSavedStateRegistry() {
        return this.f1704a.b();
    }

    @Override // COM3.lpt7
    public COM3.lpt6 getViewModelStore() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        K();
        return this.f1700a;
    }

    @Override // android.app.Activity
    @Deprecated
    public void onActivityResult(int i2, int i3, Intent intent) {
        if (this.f1703a.b(i2, i3, intent)) {
            return;
        }
        super.onActivityResult(i2, i3, intent);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        this.f1702a.c();
    }

    @Override // p150pRN.d, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.f1704a.c(bundle);
        this.f1701a.c(this);
        super.onCreate(bundle);
        com5.g(this);
        int i2 = this.f7714a;
        if (i2 != 0) {
            setContentView(i2);
        }
    }

    @Override // android.app.Activity
    @Deprecated
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (this.f1703a.b(i2, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        com1 com1Var;
        Object objM = M();
        COM3.lpt6 lpt6Var = this.f1700a;
        if (lpt6Var == null && (com1Var = (com1) getLastNonConfigurationInstance()) != null) {
            lpt6Var = com1Var.f7720a;
        }
        if (lpt6Var == null && objM == null) {
            return null;
        }
        com1 com1Var2 = new com1();
        com1Var2.f1706a = objM;
        com1Var2.f7720a = lpt6Var;
        return com1Var2;
    }

    @Override // p150pRN.d, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        androidx.lifecycle.nul lifecycle = getLifecycle();
        if (lifecycle instanceof androidx.lifecycle.com1) {
            ((androidx.lifecycle.com1) lifecycle).o(androidx.lifecycle.nul.EnumC0039nul.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f1704a.d(bundle);
    }

    @Override // android.app.Activity
    public void reportFullyDrawn() {
        try {
            if (d0.d()) {
                d0.a("reportFullyDrawn() for " + getComponentName());
            }
            super.reportFullyDrawn();
        } finally {
            d0.b();
        }
    }

    @Override // android.app.Activity
    public void setContentView(int i2) {
        L();
        super.setContentView(i2);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2) {
        super.startActivityForResult(intent, i2);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5) throws IntentSender.SendIntentException {
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i2, Bundle bundle) {
        super.startActivityForResult(intent, i2, bundle);
    }

    @Override // android.app.Activity
    @Deprecated
    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i2, Intent intent, int i3, int i4, int i5, Bundle bundle) throws IntentSender.SendIntentException {
        super.startIntentSenderForResult(intentSender, i2, intent, i3, i4, i5, bundle);
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view) {
        L();
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View view, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams layoutParams) {
        L();
        super.setContentView(view, layoutParams);
    }
}
