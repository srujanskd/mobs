package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import p001AuX.com9;

/* JADX INFO: loaded from: classes.dex */
public class com2 implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, com5.aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public androidx.appcompat.app.aux f7800a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1848a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com5.aux f1849a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public nul f1850a;

    public com2(com1 com1Var) {
        this.f1848a = com1Var;
    }

    public void a() {
        androidx.appcompat.app.aux auxVar = this.f7800a;
        if (auxVar != null) {
            auxVar.dismiss();
        }
    }

    public void b(IBinder iBinder) {
        com1 com1Var = this.f1848a;
        androidx.appcompat.app.aux.C0023aux c0023aux = new androidx.appcompat.app.aux.C0023aux(com1Var.u());
        nul nulVar = new nul(c0023aux.b(), com9.f5600j);
        this.f1850a = nulVar;
        nulVar.g(this);
        this.f1848a.b(this.f1850a);
        c0023aux.c(this.f1850a.a(), this);
        View viewY = com1Var.y();
        if (viewY != null) {
            c0023aux.e(viewY);
        } else {
            c0023aux.f(com1Var.w()).s(com1Var.x());
        }
        c0023aux.m(this);
        androidx.appcompat.app.aux auxVarA = c0023aux.a();
        this.f7800a = auxVarA;
        auxVarA.setOnDismissListener(this);
        WindowManager.LayoutParams attributes = this.f7800a.getWindow().getAttributes();
        attributes.type = 1003;
        if (iBinder != null) {
            attributes.token = iBinder;
        }
        attributes.flags |= inet.ipaddr.format.validate.aux.KEY_SINGLE_WILDCARD;
        this.f7800a.show();
    }

    @Override // androidx.appcompat.view.menu.com5.aux
    public void c(com1 com1Var, boolean z2) {
        if (z2 || com1Var == this.f1848a) {
            a();
        }
        com5.aux auxVar = this.f1849a;
        if (auxVar != null) {
            auxVar.c(com1Var, z2);
        }
    }

    @Override // androidx.appcompat.view.menu.com5.aux
    public boolean d(com1 com1Var) {
        com5.aux auxVar = this.f1849a;
        if (auxVar != null) {
            return auxVar.d(com1Var);
        }
        return false;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i2) {
        this.f1848a.L((com3) this.f1850a.a().getItem(i2), 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        this.f1850a.c(this.f1848a, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        if (i2 == 82 || i2 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.f7800a.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.f7800a.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                this.f1848a.e(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return this.f1848a.performShortcut(i2, keyEvent, 0);
    }
}
