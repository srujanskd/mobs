package COM6;

import android.animation.TimeInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import p072cOM3.b0;
import p072cOM3.c0;
import p072cOM3.d0;

/* JADX INFO: loaded from: classes.dex */
public class aux {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final TimeInterpolator f5700a = new LinearInterpolator();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final TimeInterpolator f5701b = new c0();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final TimeInterpolator f5702c = new b0();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final TimeInterpolator f5703d = new d0();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final TimeInterpolator f5704e = new DecelerateInterpolator();

    public static float a(float f2, float f3, float f4) {
        return f2 + (f4 * (f3 - f2));
    }

    public static float b(float f2, float f3, float f4, float f5, float f6) {
        if (f6 < f4) {
            return f2;
        }
        return f6 > f5 ? f3 : a(f2, f3, (f6 - f4) / (f5 - f4));
    }

    public static int c(int i2, int i3, float f2) {
        return i2 + Math.round(f2 * (i3 - i2));
    }
}
