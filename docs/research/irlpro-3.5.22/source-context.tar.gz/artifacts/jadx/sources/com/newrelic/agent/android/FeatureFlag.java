package com.newrelic.agent.android;

import com.newrelic.agent.android.stats.StatsEngine;
import java.util.HashSet;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public enum FeatureFlag {
    HttpResponseBodyCapture,
    CrashReporting,
    AnalyticsEvents,
    InteractionTracing,
    DefaultInteractions,
    NetworkRequests,
    NetworkErrorRequests,
    HandledExceptions,
    DistributedTracing,
    NativeReporting;

    private static final Set<FeatureFlag> enabledFeatures = new HashSet();
    private static boolean instrumentFeature = false;

    static {
        resetFeatures();
    }

    public static void disableFeature(FeatureFlag featureFlag) {
        enabledFeatures.remove(featureFlag);
        if (instrumentFeature) {
            StatsEngine.get().inc("Supportability/AgentHealth/Feature/Disable/" + featureFlag.name());
        }
    }

    public static void enableFeature(FeatureFlag featureFlag) {
        enabledFeatures.add(featureFlag);
        StatsEngine.get().inc("Supportability/AgentHealth/Feature/Enable/" + featureFlag.name());
    }

    public static boolean featureEnabled(FeatureFlag featureFlag) {
        return enabledFeatures.contains(featureFlag);
    }

    public static void resetFeatures() {
        enabledFeatures.clear();
        instrumentFeature = false;
        enableFeature(HttpResponseBodyCapture);
        enableFeature(CrashReporting);
        enableFeature(AnalyticsEvents);
        enableFeature(InteractionTracing);
        enableFeature(DefaultInteractions);
        enableFeature(NetworkRequests);
        enableFeature(NetworkErrorRequests);
        enableFeature(HandledExceptions);
        enableFeature(DistributedTracing);
        instrumentFeature = true;
    }
}
