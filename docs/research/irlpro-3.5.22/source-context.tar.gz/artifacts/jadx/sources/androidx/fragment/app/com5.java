package androidx.fragment.app;

import android.os.Bundle;
import android.view.View;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
public class com5 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final com6 f8249a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final CopyOnWriteArrayList<aux> f2433a = new CopyOnWriteArrayList<>();

    public static final class aux {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final boolean f8250a;
    }

    public com5(com6 com6Var) {
        this.f8249a = com6Var;
    }

    public void a(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().a(fragment, bundle, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void b(Fragment fragment, boolean z2) {
        this.f8249a.v0().f();
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().b(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void c(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().c(fragment, bundle, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void d(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().d(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void e(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().e(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void f(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().f(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void g(Fragment fragment, boolean z2) {
        this.f8249a.v0().f();
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().g(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void h(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().h(fragment, bundle, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void i(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().i(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void j(Fragment fragment, Bundle bundle, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().j(fragment, bundle, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void k(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().k(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void l(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().l(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void m(Fragment fragment, View view, Bundle bundle, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().m(fragment, view, bundle, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }

    public void n(Fragment fragment, boolean z2) {
        Fragment fragmentY0 = this.f8249a.y0();
        if (fragmentY0 != null) {
            fragmentY0.getParentFragmentManager().x0().n(fragment, true);
        }
        for (aux auxVar : this.f2433a) {
            if (!z2 || auxVar.f8250a) {
                auxVar.getClass();
                throw null;
            }
        }
    }
}
