package COM9;

import android.graphics.RectF;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class con implements nul {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f5776a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final nul f144a;

    public con(float f2, nul nulVar) {
        while (nulVar instanceof con) {
            nulVar = ((con) nulVar).f144a;
            f2 += ((con) nulVar).f5776a;
        }
        this.f144a = nulVar;
        this.f5776a = f2;
    }

    @Override // COM9.nul
    public float a(RectF rectF) {
        return Math.max(0.0f, this.f144a.a(rectF) + this.f5776a);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof con)) {
            return false;
        }
        con conVar = (con) obj;
        return this.f144a.equals(conVar.f144a) && this.f5776a == conVar.f5776a;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f144a, Float.valueOf(this.f5776a)});
    }
}
