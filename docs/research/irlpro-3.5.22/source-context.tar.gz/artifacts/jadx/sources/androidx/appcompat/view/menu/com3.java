package androidx.appcompat.view.menu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import com.newrelic.agent.android.analytics.AnalyticsAttribute;
import p001AuX.lpt1;
import p024Com2.lpt4;
import p080cOm1.y;

/* JADX INFO: loaded from: classes.dex */
public final class com3 implements p003COm1.com4 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public char f7801a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final int f1851a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public lpt4 f1852a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Intent f1853a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Drawable f1856a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ContextMenu.ContextMenuInfo f1857a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public MenuItem.OnActionExpandListener f1858a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public MenuItem.OnMenuItemClickListener f1859a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public View f1860a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com1 f1861a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com8 f1862a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public CharSequence f1863a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public Runnable f1864a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public char f7802b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final int f1866b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public CharSequence f1867b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f7803c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public CharSequence f1869c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f7804d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public CharSequence f1871d;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f7809i;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f7805e = AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f7806f = AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f7807g = 0;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public ColorStateList f1854a = null;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public PorterDuff.Mode f1855a = null;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public boolean f1865a = false;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public boolean f1868b = false;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public boolean f1870c = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f7808h = 16;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public boolean f1872d = false;

    public class aux implements lpt4.con {
        public aux() {
        }

        @Override // Com2.lpt4.con
        public void onActionProviderVisibilityChanged(boolean z2) {
            com3 com3Var = com3.this;
            com3Var.f1861a.J(com3Var);
        }
    }

    public com3(com1 com1Var, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f1861a = com1Var;
        this.f1851a = i3;
        this.f1866b = i2;
        this.f7803c = i4;
        this.f7804d = i5;
        this.f1863a = charSequence;
        this.f7809i = i6;
    }

    public static void f(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    public boolean A(boolean z2) {
        int i2 = this.f7808h;
        int i3 = (z2 ? 0 : 8) | (i2 & (-9));
        this.f7808h = i3;
        return i2 != i3;
    }

    public boolean B() {
        return this.f1861a.A();
    }

    public boolean C() {
        return this.f1861a.H() && i() != 0;
    }

    public boolean D() {
        return (this.f7809i & 4) == 4;
    }

    @Override // p003COm1.com4
    public p003COm1.com4 a(lpt4 lpt4Var) {
        lpt4 lpt4Var2 = this.f1852a;
        if (lpt4Var2 != null) {
            lpt4Var2.h();
        }
        this.f1860a = null;
        this.f1852a = lpt4Var;
        this.f1861a.K(true);
        lpt4 lpt4Var3 = this.f1852a;
        if (lpt4Var3 != null) {
            lpt4Var3.j(new aux());
        }
        return this;
    }

    @Override // android.view.MenuItem
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public p003COm1.com4 setTooltipText(CharSequence charSequence) {
        this.f1871d = charSequence;
        this.f1861a.K(false);
        return this;
    }

    @Override // p003COm1.com4
    public lpt4 c() {
        return this.f1852a;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public boolean collapseActionView() {
        if ((this.f7809i & 8) == 0) {
            return false;
        }
        if (this.f1860a == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1858a;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f1861a.f(this);
        }
        return false;
    }

    @Override // android.view.MenuItem
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public p003COm1.com4 setContentDescription(CharSequence charSequence) {
        this.f1869c = charSequence;
        this.f1861a.K(false);
        return this;
    }

    public void e() {
        this.f1861a.I(this);
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public boolean expandActionView() {
        if (!l()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1858a;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f1861a.k(this);
        }
        return false;
    }

    public final Drawable g(Drawable drawable) {
        if (drawable != null && this.f1870c && (this.f1865a || this.f1868b)) {
            drawable = y.l(drawable).mutate();
            if (this.f1865a) {
                y.i(drawable, this.f1854a);
            }
            if (this.f1868b) {
                y.j(drawable, this.f1855a);
            }
            this.f1870c = false;
        }
        return drawable;
    }

    @Override // android.view.MenuItem
    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public View getActionView() {
        View view = this.f1860a;
        if (view != null) {
            return view;
        }
        lpt4 lpt4Var = this.f1852a;
        if (lpt4Var == null) {
            return null;
        }
        View viewD = lpt4Var.d(this);
        this.f1860a = viewD;
        return viewD;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public int getAlphabeticModifiers() {
        return this.f7806f;
    }

    @Override // android.view.MenuItem
    public char getAlphabeticShortcut() {
        return this.f7802b;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public CharSequence getContentDescription() {
        return this.f1869c;
    }

    @Override // android.view.MenuItem
    public int getGroupId() {
        return this.f1866b;
    }

    @Override // android.view.MenuItem
    public Drawable getIcon() {
        Drawable drawable = this.f1856a;
        if (drawable != null) {
            return g(drawable);
        }
        if (this.f7807g == 0) {
            return null;
        }
        Drawable drawableB = AUX.aux.b(this.f1861a.u(), this.f7807g);
        this.f7807g = 0;
        this.f1856a = drawableB;
        return g(drawableB);
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public ColorStateList getIconTintList() {
        return this.f1854a;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public PorterDuff.Mode getIconTintMode() {
        return this.f1855a;
    }

    @Override // android.view.MenuItem
    public Intent getIntent() {
        return this.f1853a;
    }

    @Override // android.view.MenuItem
    @ViewDebug.CapturedViewProperty
    public int getItemId() {
        return this.f1851a;
    }

    @Override // android.view.MenuItem
    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return this.f1857a;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public int getNumericModifiers() {
        return this.f7805e;
    }

    @Override // android.view.MenuItem
    public char getNumericShortcut() {
        return this.f7801a;
    }

    @Override // android.view.MenuItem
    public int getOrder() {
        return this.f7803c;
    }

    @Override // android.view.MenuItem
    public SubMenu getSubMenu() {
        return this.f1862a;
    }

    @Override // android.view.MenuItem
    @ViewDebug.CapturedViewProperty
    public CharSequence getTitle() {
        return this.f1863a;
    }

    @Override // android.view.MenuItem
    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f1867b;
        return charSequence != null ? charSequence : this.f1863a;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public CharSequence getTooltipText() {
        return this.f1871d;
    }

    public int h() {
        return this.f7804d;
    }

    @Override // android.view.MenuItem
    public boolean hasSubMenu() {
        return this.f1862a != null;
    }

    public char i() {
        return this.f1861a.G() ? this.f7802b : this.f7801a;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public boolean isActionViewExpanded() {
        return this.f1872d;
    }

    @Override // android.view.MenuItem
    public boolean isCheckable() {
        return (this.f7808h & 1) == 1;
    }

    @Override // android.view.MenuItem
    public boolean isChecked() {
        return (this.f7808h & 2) == 2;
    }

    @Override // android.view.MenuItem
    public boolean isEnabled() {
        return (this.f7808h & 16) != 0;
    }

    @Override // android.view.MenuItem
    public boolean isVisible() {
        lpt4 lpt4Var = this.f1852a;
        if (lpt4Var == null || !lpt4Var.g()) {
            return (this.f7808h & 8) == 0;
        }
        return (this.f7808h & 8) == 0 && this.f1852a.b();
    }

    public String j() {
        char cI = i();
        if (cI == 0) {
            return "";
        }
        Resources resources = this.f1861a.u().getResources();
        StringBuilder sb = new StringBuilder();
        if (ViewConfiguration.get(this.f1861a.u()).hasPermanentMenuKey()) {
            sb.append(resources.getString(lpt1.f5622m));
        }
        int i2 = this.f1861a.G() ? this.f7806f : this.f7805e;
        f(sb, i2, 65536, resources.getString(lpt1.f5618i));
        f(sb, i2, AnalyticsAttribute.ATTRIBUTE_VALUE_MAX_LENGTH, resources.getString(lpt1.f5614e));
        f(sb, i2, 2, resources.getString(lpt1.f5613d));
        f(sb, i2, 1, resources.getString(lpt1.f5619j));
        f(sb, i2, 4, resources.getString(lpt1.f5621l));
        f(sb, i2, 8, resources.getString(lpt1.f5617h));
        if (cI == '\b') {
            sb.append(resources.getString(lpt1.f5615f));
        } else if (cI == '\n') {
            sb.append(resources.getString(lpt1.f5616g));
        } else if (cI != ' ') {
            sb.append(cI);
        } else {
            sb.append(resources.getString(lpt1.f5620k));
        }
        return sb.toString();
    }

    public CharSequence k(com6.aux auxVar) {
        return (auxVar == null || !auxVar.d()) ? getTitle() : getTitleCondensed();
    }

    public boolean l() {
        lpt4 lpt4Var;
        if ((this.f7809i & 8) == 0) {
            return false;
        }
        if (this.f1860a == null && (lpt4Var = this.f1852a) != null) {
            this.f1860a = lpt4Var.d(this);
        }
        return this.f1860a != null;
    }

    public boolean m() {
        MenuItem.OnMenuItemClickListener onMenuItemClickListener = this.f1859a;
        if (onMenuItemClickListener != null && onMenuItemClickListener.onMenuItemClick(this)) {
            return true;
        }
        com1 com1Var = this.f1861a;
        if (com1Var.h(com1Var, this)) {
            return true;
        }
        Runnable runnable = this.f1864a;
        if (runnable != null) {
            runnable.run();
            return true;
        }
        if (this.f1853a != null) {
            try {
                this.f1861a.u().startActivity(this.f1853a);
                return true;
            } catch (ActivityNotFoundException e2) {
                Log.e("MenuItemImpl", "Can't find activity to handle intent; ignoring", e2);
            }
        }
        lpt4 lpt4Var = this.f1852a;
        return lpt4Var != null && lpt4Var.e();
    }

    public boolean n() {
        return (this.f7808h & 32) == 32;
    }

    public boolean o() {
        return (this.f7808h & 4) != 0;
    }

    public boolean p() {
        return (this.f7809i & 1) == 1;
    }

    public boolean q() {
        return (this.f7809i & 2) == 2;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    /* JADX INFO: renamed from: r, reason: merged with bridge method [inline-methods] */
    public p003COm1.com4 setActionView(int i2) {
        Context contextU = this.f1861a.u();
        setActionView(LayoutInflater.from(contextU).inflate(i2, (ViewGroup) new LinearLayout(contextU), false));
        return this;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
    public p003COm1.com4 setActionView(View view) {
        int i2;
        this.f1860a = view;
        this.f1852a = null;
        if (view != null && view.getId() == -1 && (i2 = this.f1851a) > 0) {
            view.setId(i2);
        }
        this.f1861a.I(this);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    @Override // android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2) {
        if (this.f7802b == c2) {
            return this;
        }
        this.f7802b = Character.toLowerCase(c2);
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setCheckable(boolean z2) {
        int i2 = this.f7808h;
        int i3 = (z2 ? 1 : 0) | (i2 & (-2));
        this.f7808h = i3;
        if (i2 != i3) {
            this.f1861a.K(false);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setChecked(boolean z2) {
        if ((this.f7808h & 4) != 0) {
            this.f1861a.T(this);
        } else {
            u(z2);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setEnabled(boolean z2) {
        if (z2) {
            this.f7808h |= 16;
        } else {
            this.f7808h &= -17;
        }
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(Drawable drawable) {
        this.f7807g = 0;
        this.f1856a = drawable;
        this.f1870c = true;
        this.f1861a.K(false);
        return this;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1854a = colorStateList;
        this.f1865a = true;
        this.f1870c = true;
        this.f1861a.K(false);
        return this;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1855a = mode;
        this.f1868b = true;
        this.f1870c = true;
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIntent(Intent intent) {
        this.f1853a = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setNumericShortcut(char c2) {
        if (this.f7801a == c2) {
            return this;
        }
        this.f7801a = c2;
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f1858a = onActionExpandListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f1859a = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3) {
        this.f7801a = c2;
        this.f7802b = Character.toLowerCase(c3);
        this.f1861a.K(false);
        return this;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 != 0 && i3 != 1 && i3 != 2) {
            throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
        }
        this.f7809i = i2;
        this.f1861a.I(this);
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(CharSequence charSequence) {
        this.f1863a = charSequence;
        this.f1861a.K(false);
        com8 com8Var = this.f1862a;
        if (com8Var != null) {
            com8Var.setHeaderTitle(charSequence);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f1867b = charSequence;
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setVisible(boolean z2) {
        if (A(z2)) {
            this.f1861a.J(this);
        }
        return this;
    }

    public void t(boolean z2) {
        this.f1872d = z2;
        this.f1861a.K(false);
    }

    public String toString() {
        CharSequence charSequence = this.f1863a;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    public void u(boolean z2) {
        int i2 = this.f7808h;
        int i3 = (z2 ? 2 : 0) | (i2 & (-3));
        this.f7808h = i3;
        if (i2 != i3) {
            this.f1861a.K(false);
        }
    }

    public void v(boolean z2) {
        this.f7808h = (z2 ? 4 : 0) | (this.f7808h & (-5));
    }

    public void w(boolean z2) {
        if (z2) {
            this.f7808h |= 32;
        } else {
            this.f7808h &= -33;
        }
    }

    public void x(ContextMenu.ContextMenuInfo contextMenuInfo) {
        this.f1857a = contextMenuInfo;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
    public p003COm1.com4 setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    public void z(com8 com8Var) {
        this.f1862a = com8Var;
        com8Var.setHeaderTitle(getTitle());
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.f7802b == c2 && this.f7806f == i2) {
            return this;
        }
        this.f7802b = Character.toLowerCase(c2);
        this.f7806f = KeyEvent.normalizeMetaState(i2);
        this.f1861a.K(false);
        return this;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public MenuItem setNumericShortcut(char c2, int i2) {
        if (this.f7801a == c2 && this.f7805e == i2) {
            return this;
        }
        this.f7801a = c2;
        this.f7805e = KeyEvent.normalizeMetaState(i2);
        this.f1861a.K(false);
        return this;
    }

    @Override // p003COm1.com4, android.view.MenuItem
    public MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f7801a = c2;
        this.f7805e = KeyEvent.normalizeMetaState(i2);
        this.f7802b = Character.toLowerCase(c3);
        this.f7806f = KeyEvent.normalizeMetaState(i3);
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setIcon(int i2) {
        this.f1856a = null;
        this.f7807g = i2;
        this.f1870c = true;
        this.f1861a.K(false);
        return this;
    }

    @Override // android.view.MenuItem
    public MenuItem setTitle(int i2) {
        return setTitle(this.f1861a.u().getString(i2));
    }
}
