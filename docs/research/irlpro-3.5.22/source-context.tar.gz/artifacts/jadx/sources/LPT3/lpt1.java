package LPT3;

import java.util.Collection;
import java.util.Map;
import java.util.regex.Pattern;
import p035LPt3.lpt8;
import p139lpt3.a0;
import p139lpt3.c0;
import p139lpt3.g0;

/* JADX INFO: loaded from: classes.dex */
public abstract class lpt1 implements g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Pattern f6630a = Pattern.compile("[0-9]+");

    public static int b(boolean[] zArr, int i2, int[] iArr, boolean z2) {
        int i3 = 0;
        for (int i4 : iArr) {
            int i5 = 0;
            while (i5 < i4) {
                zArr[i2] = z2;
                i5++;
                i2++;
            }
            i3 += i4;
            z2 = !z2;
        }
        return i3;
    }

    public static void c(String str) {
        if (!f6630a.matcher(str).matches()) {
            throw new IllegalArgumentException("Input should only contain digits 0-9");
        }
    }

    public static lpt8 g(boolean[] zArr, int i2, int i3, int i4) {
        int length = zArr.length;
        int i5 = i4 + length;
        int iMax = Math.max(i2, i5);
        int iMax2 = Math.max(1, i3);
        int i6 = iMax / i5;
        int i7 = (iMax - (length * i6)) / 2;
        lpt8 lpt8Var = new lpt8(iMax, iMax2);
        int i8 = 0;
        while (i8 < length) {
            if (zArr[i8]) {
                lpt8Var.h(i7, 0, i6, iMax2);
            }
            i8++;
            i7 += i6;
        }
        return lpt8Var;
    }

    @Override // p139lpt3.g0
    public lpt8 a(String str, a0 a0Var, int i2, int i3, Map<c0, ?> map) {
        if (str.isEmpty()) {
            throw new IllegalArgumentException("Found empty contents");
        }
        if (i2 < 0 || i3 < 0) {
            throw new IllegalArgumentException("Negative size is not allowed. Input: " + i2 + 'x' + i3);
        }
        Collection<a0> collectionF = f();
        if (collectionF != null && !collectionF.contains(a0Var)) {
            throw new IllegalArgumentException("Can only encode " + collectionF + ", but got " + a0Var);
        }
        int iE = e();
        if (map != null) {
            c0 c0Var = c0.MARGIN;
            if (map.containsKey(c0Var)) {
                iE = Integer.parseInt(map.get(c0Var).toString());
            }
        }
        return g(d(str), i2, i3, iE);
    }

    public abstract boolean[] d(String str);

    public int e() {
        return 10;
    }

    public abstract Collection<a0> f();
}
