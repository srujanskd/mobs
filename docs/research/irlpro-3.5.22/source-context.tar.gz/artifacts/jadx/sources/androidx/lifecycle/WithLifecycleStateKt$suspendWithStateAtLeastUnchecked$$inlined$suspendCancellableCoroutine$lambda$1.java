package androidx.lifecycle;

import f.com8;
import p059Lpt9.lpt4;
import p059Lpt9.lpt5;

/* JADX INFO: loaded from: classes.dex */
public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$$inlined$suspendCancellableCoroutine$lambda$1 implements prn {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ nul.EnumC0039nul f8386a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final /* synthetic */ nul f2602a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final /* synthetic */ e.aux f2603a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final /* synthetic */ n.com7 f2604a;

    @Override // androidx.lifecycle.prn
    public void f(COM3.com7 com7Var, nul.con conVar) {
        Object objA;
        com8.e(com7Var, "source");
        com8.e(conVar, "event");
        if (conVar != nul.con.e(this.f8386a)) {
            if (conVar == nul.con.ON_DESTROY) {
                this.f2602a.c(this);
                n.com7 com7Var2 = this.f2604a;
                COM3.com4 com4Var = new COM3.com4();
                lpt4.aux auxVar = lpt4.f7356a;
                com7Var2.A(lpt4.a(lpt5.a(com4Var)));
                return;
            }
            return;
        }
        this.f2602a.c(this);
        n.com7 com7Var3 = this.f2604a;
        e.aux auxVar2 = this.f2603a;
        try {
            lpt4.aux auxVar3 = lpt4.f7356a;
            objA = lpt4.a(auxVar2.f());
        } catch (Throwable th) {
            lpt4.aux auxVar4 = lpt4.f7356a;
            objA = lpt4.a(lpt5.a(th));
        }
        com7Var3.A(objA);
    }
}
