package androidx.versionedparcelable;

import p017CoM5.w;

/* JADX INFO: loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements w {
}
