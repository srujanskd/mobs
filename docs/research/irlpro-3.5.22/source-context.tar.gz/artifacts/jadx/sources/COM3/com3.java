package COM3;

import n.l;

/* JADX INFO: loaded from: classes.dex */
public abstract class com3 implements l {
}
