package LPT1;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public abstract class lpt6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final lpt6 f6585a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final /* synthetic */ lpt6[] f835a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final lpt6 f6586b;

    public final enum aux extends lpt6 {
        public aux(String str, int i2) {
            super(str, i2, null);
        }
    }

    static {
        aux auxVar = new aux("DEFAULT", 0);
        f6585a = auxVar;
        lpt6 lpt6Var = new lpt6("STRING", 1) { // from class: LPT1.lpt6.con
            {
                aux auxVar2 = null;
            }
        };
        f6586b = lpt6Var;
        f835a = new lpt6[]{auxVar, lpt6Var};
    }

    public lpt6(String str, int i2) {
        super(str, i2);
    }

    public static lpt6 valueOf(String str) {
        return (lpt6) Enum.valueOf(lpt6.class, str);
    }

    public static lpt6[] values() {
        return (lpt6[]) f835a.clone();
    }

    public /* synthetic */ lpt6(String str, int i2, aux auxVar) {
        this(str, i2);
    }
}
