package com.google.android.material.datepicker;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import p087cOm8.com8;
import p087cOm8.lpt3;
import p101com2.p2;

/* JADX INFO: loaded from: classes.dex */
public final class aux implements Parcelable {
    public static final Parcelable.Creator<aux> CREATOR = new C0057aux();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f9461a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final com8 f3507a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public final nul f3508a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f9462b;

    /* JADX INFO: renamed from: b, reason: collision with other field name */
    public final com8 f3509b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public com8 f9463c;

    /* JADX INFO: renamed from: com.google.android.material.datepicker.aux$aux, reason: collision with other inner class name */
    public class C0057aux implements Parcelable.Creator<aux> {
        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public aux createFromParcel(Parcel parcel) {
            return new aux((com8) parcel.readParcelable(com8.class.getClassLoader()), (com8) parcel.readParcelable(com8.class.getClassLoader()), (nul) parcel.readParcelable(nul.class.getClassLoader()), (com8) parcel.readParcelable(com8.class.getClassLoader()), null);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public aux[] newArray(int i2) {
            return new aux[i2];
        }
    }

    public static final class con {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public static final long f9464c = lpt3.a(com8.n(1900, 0).f3219a);

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public static final long f9465d = lpt3.a(com8.n(2100, 11).f3219a);

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public long f9466a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public nul f3510a;

        /* JADX INFO: renamed from: a, reason: collision with other field name */
        public Long f3511a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public long f9467b;

        public con(aux auxVar) {
            this.f9466a = f9464c;
            this.f9467b = f9465d;
            this.f3510a = com.google.android.material.datepicker.con.k(Long.MIN_VALUE);
            this.f9466a = auxVar.f3507a.f3219a;
            this.f9467b = auxVar.f3509b.f3219a;
            this.f3511a = Long.valueOf(auxVar.f9463c.f3219a);
            this.f3510a = auxVar.f3508a;
        }

        public aux a() {
            Bundle bundle = new Bundle();
            bundle.putParcelable("DEEP_COPY_VALIDATOR_KEY", this.f3510a);
            com8 com8VarO = com8.o(this.f9466a);
            com8 com8VarO2 = com8.o(this.f9467b);
            nul nulVar = (nul) bundle.getParcelable("DEEP_COPY_VALIDATOR_KEY");
            Long l2 = this.f3511a;
            return new aux(com8VarO, com8VarO2, nulVar, l2 == null ? null : com8.o(l2.longValue()), null);
        }

        public con b(long j2) {
            this.f3511a = Long.valueOf(j2);
            return this;
        }
    }

    public interface nul extends Parcelable {
        boolean d(long j2);
    }

    public /* synthetic */ aux(com8 com8Var, com8 com8Var2, nul nulVar, com8 com8Var3, C0057aux c0057aux) {
        this(com8Var, com8Var2, nulVar, com8Var3);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof aux)) {
            return false;
        }
        aux auxVar = (aux) obj;
        return this.f3507a.equals(auxVar.f3507a) && this.f3509b.equals(auxVar.f3509b) && p2.a(this.f9463c, auxVar.f9463c) && this.f3508a.equals(auxVar.f3508a);
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{this.f3507a, this.f3509b, this.f9463c, this.f3508a});
    }

    public com8 p(com8 com8Var) {
        if (com8Var.compareTo(this.f3507a) < 0) {
            return this.f3507a;
        }
        return com8Var.compareTo(this.f3509b) > 0 ? this.f3509b : com8Var;
    }

    public nul q() {
        return this.f3508a;
    }

    public com8 r() {
        return this.f3509b;
    }

    public int s() {
        return this.f9462b;
    }

    public com8 t() {
        return this.f9463c;
    }

    public com8 u() {
        return this.f3507a;
    }

    public int v() {
        return this.f9461a;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeParcelable(this.f3507a, 0);
        parcel.writeParcelable(this.f3509b, 0);
        parcel.writeParcelable(this.f9463c, 0);
        parcel.writeParcelable(this.f3508a, 0);
    }

    public aux(com8 com8Var, com8 com8Var2, nul nulVar, com8 com8Var3) {
        this.f3507a = com8Var;
        this.f3509b = com8Var2;
        this.f9463c = com8Var3;
        this.f3508a = nulVar;
        if (com8Var3 != null && com8Var.compareTo(com8Var3) > 0) {
            throw new IllegalArgumentException("start Month cannot be after current Month");
        }
        if (com8Var3 != null && com8Var3.compareTo(com8Var2) > 0) {
            throw new IllegalArgumentException("current Month cannot be after end Month");
        }
        this.f9462b = com8Var.x(com8Var2) + 1;
        this.f9461a = (com8Var2.f9181b - com8Var.f9181b) + 1;
    }
}
