package com.google.android.material.datepicker;

import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.Iterator;
import p087cOm8.com4;
import p087cOm8.com9;

/* JADX INFO: loaded from: classes.dex */
public final class MaterialTextInputPicker extends PickerFragment {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f9458a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com4<Object> f3504a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public com.google.android.material.datepicker.aux f3505a;

    public class aux extends com9<Object> {
        public aux() {
        }

        @Override // p087cOm8.com9
        public void a(Object obj) {
            Iterator<com9<Object>> it = ((PickerFragment) MaterialTextInputPicker.this).f3506a.iterator();
            while (it.hasNext()) {
                it.next().a(obj);
            }
        }
    }

    public static MaterialTextInputPicker l(com4 com4Var, int i2, com.google.android.material.datepicker.aux auxVar) {
        MaterialTextInputPicker materialTextInputPicker = new MaterialTextInputPicker();
        Bundle bundle = new Bundle();
        bundle.putInt("THEME_RES_ID_KEY", i2);
        bundle.putParcelable("DATE_SELECTOR_KEY", com4Var);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", auxVar);
        materialTextInputPicker.setArguments(bundle);
        return materialTextInputPicker;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (bundle == null) {
            bundle = getArguments();
        }
        this.f9458a = bundle.getInt("THEME_RES_ID_KEY");
        this.f3504a = (com4) bundle.getParcelable("DATE_SELECTOR_KEY");
        this.f3505a = (com.google.android.material.datepicker.aux) bundle.getParcelable("CALENDAR_CONSTRAINTS_KEY");
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return this.f3504a.j(layoutInflater.cloneInContext(new ContextThemeWrapper(getContext(), this.f9458a)), viewGroup, bundle, this.f3505a, new aux());
    }

    @Override // androidx.fragment.app.Fragment
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt("THEME_RES_ID_KEY", this.f9458a);
        bundle.putParcelable("DATE_SELECTOR_KEY", this.f3504a);
        bundle.putParcelable("CALENDAR_CONSTRAINTS_KEY", this.f3505a);
    }
}
