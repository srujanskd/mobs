package com.newrelic.agent.android.api.common;

import com.newrelic.agent.android.FeatureFlag;
import com.newrelic.agent.android.distributedtracing.TraceContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class TransactionData {
    private final String appData;
    private final long bytesReceived;
    private final long bytesSent;
    private final String carrier;
    private int errorCode;
    private final Object errorCodeLock = new Object();
    private final String httpMethod;
    private Map<String, String> params;
    private String responseBody;
    private final int statusCode;
    private final float time;
    private final long timestamp;
    private final TraceContext traceContext;
    private final String url;
    private final String wanType;

    public TransactionData(String str, String str2, String str3, float f2, int i2, int i3, long j2, long j3, String str4, String str5, TraceContext traceContext) {
        this.errorCode = 0;
        this.responseBody = null;
        this.params = null;
        int iIndexOf = str.indexOf(63);
        if (iIndexOf < 0 && (iIndexOf = str.indexOf(59)) < 0) {
            iIndexOf = str.length();
        }
        this.url = str.substring(0, iIndexOf);
        this.httpMethod = str2;
        this.carrier = str3;
        this.time = f2;
        this.statusCode = i2;
        this.errorCode = i3;
        this.bytesSent = j2;
        this.bytesReceived = j3;
        this.appData = str4;
        this.wanType = str5;
        this.timestamp = System.currentTimeMillis();
        this.responseBody = null;
        this.params = null;
        this.traceContext = traceContext;
    }

    public List<Object> asList() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(this.url);
        arrayList.add(this.carrier);
        arrayList.add(Float.valueOf(this.time));
        arrayList.add(Integer.valueOf(this.statusCode));
        arrayList.add(Integer.valueOf(this.errorCode));
        arrayList.add(Long.valueOf(this.bytesSent));
        arrayList.add(Long.valueOf(this.bytesReceived));
        arrayList.add(this.appData);
        return arrayList;
    }

    public String getAppData() {
        return this.appData;
    }

    public long getBytesReceived() {
        return this.bytesReceived;
    }

    public long getBytesSent() {
        return this.bytesSent;
    }

    public String getCarrier() {
        return this.carrier;
    }

    public int getErrorCode() {
        int i2;
        synchronized (this.errorCodeLock) {
            i2 = this.errorCode;
        }
        return i2;
    }

    public String getHttpMethod() {
        return this.httpMethod;
    }

    public Map<String, String> getParams() {
        return this.params;
    }

    public String getResponseBody() {
        return this.responseBody;
    }

    public int getStatusCode() {
        return this.statusCode;
    }

    public float getTime() {
        return this.time;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public TraceContext getTraceContext() {
        return this.traceContext;
    }

    public String getUrl() {
        return this.url;
    }

    public String getWanType() {
        return this.wanType;
    }

    public void setErrorCode(int i2) {
        synchronized (this.errorCodeLock) {
            this.errorCode = i2;
        }
    }

    public void setParams(Map<String, String> map) {
        this.params = map;
    }

    public void setResponseBody(String str) {
        if (FeatureFlag.featureEnabled(FeatureFlag.HttpResponseBodyCapture)) {
            if (str == null || str.isEmpty()) {
                this.responseBody = null;
            } else {
                this.responseBody = str;
            }
        }
    }

    public String toString() {
        return "TransactionData{timestamp=" + this.timestamp + ", url='" + this.url + "', httpMethod='" + this.httpMethod + "', carrier='" + this.carrier + "', time=" + this.time + ", statusCode=" + this.statusCode + ", errorCode=" + this.errorCode + ", errorCodeLock=" + this.errorCodeLock + ", bytesSent=" + this.bytesSent + ", bytesReceived=" + this.bytesReceived + ", appData='" + this.appData + "', wanType='" + this.wanType + "'}";
    }
}
