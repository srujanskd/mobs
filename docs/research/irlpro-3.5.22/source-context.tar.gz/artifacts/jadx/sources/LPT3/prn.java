package LPT3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import p139lpt3.a0;

/* JADX INFO: loaded from: classes.dex */
public final class prn extends lpt1 {

    public enum aux {
        UNCODABLE,
        ONE_DIGIT,
        TWO_DIGITS,
        FNC_1
    }

    public static int h(CharSequence charSequence, int i2, int i3) {
        aux auxVarI;
        aux auxVarI2;
        char cCharAt;
        aux auxVarI3 = i(charSequence, i2);
        aux auxVar = aux.ONE_DIGIT;
        if (auxVarI3 == auxVar) {
            if (i3 == 101) {
                return p113lPT4.lpt4.AppCompatTheme_switchStyle;
            }
            return 100;
        }
        aux auxVar2 = aux.UNCODABLE;
        if (auxVarI3 == auxVar2) {
            if (i2 >= charSequence.length() || ((cCharAt = charSequence.charAt(i2)) >= ' ' && (i3 != 101 || (cCharAt >= '`' && (cCharAt < 241 || cCharAt > 244))))) {
                return 100;
            }
            return p113lPT4.lpt4.AppCompatTheme_switchStyle;
        }
        if (i3 == 101 && auxVarI3 == aux.FNC_1) {
            return p113lPT4.lpt4.AppCompatTheme_switchStyle;
        }
        if (i3 == 99) {
            return 99;
        }
        if (i3 != 100) {
            if (auxVarI3 == aux.FNC_1) {
                auxVarI3 = i(charSequence, i2 + 1);
            }
            return auxVarI3 == aux.TWO_DIGITS ? 99 : 100;
        }
        aux auxVar3 = aux.FNC_1;
        if (auxVarI3 == auxVar3 || (auxVarI = i(charSequence, i2 + 2)) == auxVar2 || auxVarI == auxVar) {
            return 100;
        }
        if (auxVarI == auxVar3) {
            return i(charSequence, i2 + 3) == aux.TWO_DIGITS ? 99 : 100;
        }
        int i4 = i2 + 4;
        while (true) {
            auxVarI2 = i(charSequence, i4);
            if (auxVarI2 != aux.TWO_DIGITS) {
                break;
            }
            i4 += 2;
        }
        return auxVarI2 == aux.ONE_DIGIT ? 100 : 99;
    }

    public static aux i(CharSequence charSequence, int i2) {
        int length = charSequence.length();
        if (i2 >= length) {
            return aux.UNCODABLE;
        }
        char cCharAt = charSequence.charAt(i2);
        if (cCharAt == 241) {
            return aux.FNC_1;
        }
        if (cCharAt < '0' || cCharAt > '9') {
            return aux.UNCODABLE;
        }
        int i3 = i2 + 1;
        if (i3 >= length) {
            return aux.ONE_DIGIT;
        }
        char cCharAt2 = charSequence.charAt(i3);
        return (cCharAt2 < '0' || cCharAt2 > '9') ? aux.ONE_DIGIT : aux.TWO_DIGITS;
    }

    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int length = str.length();
        if (length <= 0 || length > 80) {
            throw new IllegalArgumentException("Contents length should be between 1 and 80 characters, but got ".concat(String.valueOf(length)));
        }
        int iB = 0;
        for (int i2 = 0; i2 < length; i2++) {
            char cCharAt = str.charAt(i2);
            switch (cCharAt) {
                case 241:
                case 242:
                case 243:
                case 244:
                    break;
                default:
                    if (cCharAt > 127) {
                        throw new IllegalArgumentException("Bad character in input: ".concat(String.valueOf(cCharAt)));
                    }
                    break;
                    break;
            }
        }
        ArrayList<int[]> arrayList = new ArrayList();
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 1;
        while (true) {
            int i7 = p113lPT4.lpt4.AppCompatTheme_textAppearanceListItem;
            if (i3 >= length) {
                int i8 = i4 % p113lPT4.lpt4.AppCompatTheme_textAppearanceListItem;
                int[][] iArr = nul.f6637a;
                arrayList.add(iArr[i8]);
                arrayList.add(iArr[106]);
                int i9 = 0;
                for (int[] iArr2 : arrayList) {
                    for (int i10 : iArr2) {
                        i9 += i10;
                    }
                }
                boolean[] zArr = new boolean[i9];
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    iB += lpt1.b(zArr, iB, (int[]) it.next(), true);
                }
                return zArr;
            }
            int iH = h(str, i3, i5);
            int iCharAt = 100;
            if (iH == i5) {
                switch (str.charAt(i3)) {
                    case 241:
                        iCharAt = p113lPT4.lpt4.AppCompatTheme_textAppearanceLargePopupMenu;
                        break;
                    case 242:
                        iCharAt = 97;
                        break;
                    case 243:
                        iCharAt = 96;
                        break;
                    case 244:
                        if (i5 == 101) {
                            iCharAt = 101;
                        }
                        break;
                    default:
                        if (i5 == 100) {
                            iCharAt = str.charAt(i3) - ' ';
                        } else if (i5 != 101) {
                            iCharAt = Integer.parseInt(str.substring(i3, i3 + 2));
                            i3++;
                        } else {
                            iCharAt = str.charAt(i3) - ' ';
                            if (iCharAt < 0) {
                                iCharAt += 96;
                            }
                        }
                        break;
                }
                i3++;
            } else {
                if (i5 != 0) {
                    i7 = iH;
                } else if (iH == 100) {
                    i7 = p113lPT4.lpt4.AppCompatTheme_textAppearanceListItemSecondary;
                } else if (iH != 101) {
                    i7 = p113lPT4.lpt4.AppCompatTheme_textAppearanceListItemSmall;
                }
                iCharAt = i7;
                i5 = iH;
            }
            arrayList.add(nul.f6637a[iCharAt]);
            i4 += iCharAt * i6;
            if (i3 != 0) {
                i6++;
            }
        }
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.CODE_128);
    }
}
