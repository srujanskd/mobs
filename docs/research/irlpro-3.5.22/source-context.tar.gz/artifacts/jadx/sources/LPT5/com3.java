package LPT5;

import android.content.Context;
import android.util.Log;
import app.irlpro.android.R;
import com.newrelic.agent.android.payload.PayloadController;
import com.wmspanel.libstream.lpt5;
import com.wmspanel.streamer.Connection;
import java.util.Map;
import p037LPt5.lpt7;
import p055Lpt5.i2;

/* JADX INFO: loaded from: classes.dex */
public class com3 extends prn {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f6654b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public double f6655c;

    /* JADX INFO: renamed from: c, reason: collision with other field name */
    public long f867c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public double f6656d;

    /* JADX INFO: renamed from: d, reason: collision with other field name */
    public int f868d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public double f6657e;

    /* JADX INFO: renamed from: e, reason: collision with other field name */
    public int f869e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public double f6658f;

    /* JADX INFO: renamed from: f, reason: collision with other field name */
    public int f870f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public double f6659g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public double f6660h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public double f6661i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public double f6662j;

    public com3(Context context) {
        super(context);
    }

    @Override // LPT5.prn
    public void B(long j2) {
        i2 i2Var = ((prn) this).f878a;
        if (i2Var == null || i2Var.fpsRanges.size() == 0) {
            return;
        }
        double d2 = (j2 * 1.0d) / ((double) ((prn) this).f6676c);
        double dMax = ((prn) this).f6675b;
        if (d2 < 0.5d && j2 < 1100000) {
            dMax = Math.max(15.0d, Math.floor(((dMax * d2) * 2.0d) / 5.0d) * 5.0d);
        }
        if (Math.abs(dMax - ((prn) this).f6674a) < 1.0d) {
            return;
        }
        ((prn) this).f6674a = dMax;
        lpt5.com3 com3VarFindNearestFpsRange = ((prn) this).f878a.findNearestFpsRange(Math.round(dMax), false);
        if (com3VarFindNearestFpsRange == null) {
            com3VarFindNearestFpsRange = new lpt5.com3(0, 0);
        }
        int i2 = com3VarFindNearestFpsRange.fpsMax;
        lpt5.com3 com3Var = ((prn) this).f881a;
        if (i2 == com3Var.fpsMax && com3VarFindNearestFpsRange.fpsMin == com3Var.fpsMin) {
            return;
        }
        ((prn) this).f882a.changeFpsRange(com3VarFindNearestFpsRange);
        ((prn) this).f881a = com3VarFindNearestFpsRange;
    }

    @Override // LPT5.prn
    public void g(long j2, long j3) {
        lpt7 lpt7VarA;
        int i2;
        double d2;
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (((prn) this).f877a + PayloadController.PAYLOAD_COLLECTOR_TIMEOUT > jCurrentTimeMillis) {
            return;
        }
        for (Map.Entry<Integer, Connection> entry : ((prn) this).f890b.entrySet()) {
            Integer key = entry.getKey();
            int i3 = entry.getValue().latency;
            com7 com7Var = ((prn) this).f885a.get(key);
            if (com7Var != null && (lpt7VarA = com7Var.a()) != null && (i2 = lpt7VarA.pktSndBuf) >= 1) {
                this.f6656d = (this.f6656d * 0.99d) + (((double) i2) * 0.01d);
                double d3 = this.f6657e * 0.99d;
                this.f6657e = d3;
                double d4 = i2 - this.f868d;
                if (d4 > d3) {
                    this.f6657e = d4;
                }
                this.f868d = i2;
                int i4 = ((int) lpt7VarA.msRTT) + 49;
                double d5 = this.f6658f;
                if (d5 == 0.0d) {
                    this.f6658f = i4;
                } else {
                    this.f6658f = (d5 * 0.99d) + (((double) i4) * 0.01d);
                }
                double d6 = i4 - this.f869e;
                double d7 = (this.f6660h * 0.8d) + (0.2d * d6);
                this.f6660h = d7;
                this.f869e = i4;
                double d8 = this.f6659g * 1.001d;
                this.f6659g = d8;
                if (i4 != 100) {
                    double d9 = i4;
                    if (d9 < d8 && d7 < 1.0d && i4 > 0) {
                        this.f6659g = d9;
                    }
                }
                double d10 = this.f6661i * 0.99d;
                this.f6661i = d10;
                if (d6 > d10) {
                    d2 = d6;
                    this.f6661i = d2;
                } else {
                    d2 = d6;
                }
                this.f6662j = (this.f6662j * 0.97d) + ((((lpt7VarA.mbpsSendRate * 1000.0d) * 1000.0d) / 1024.0d) * 0.03d);
                if (this.f870f % 100 == 0) {
                    Log.d("StreamConditioner", String.format("bs: %d bs_avg: %f, bs_jitter %f, bitrate %d through %.0f rtt %d, delta rtt %.0f, avg delta %.1f, avg rtt %.1f, rtt_jitter %.2f, rtt_min %.1f, latency %d", Integer.valueOf(i2), Double.valueOf(this.f6656d), Double.valueOf(this.f6657e), Integer.valueOf(((prn) this).f888b), Double.valueOf(this.f6662j), Integer.valueOf(i4), Double.valueOf(d2), Double.valueOf(this.f6660h), Double.valueOf(this.f6658f), Double.valueOf(this.f6661i), Double.valueOf(this.f6659g), Integer.valueOf(i3)));
                    this.f870f = 0;
                }
                this.f870f++;
                int i5 = ((prn) this).f888b;
                double d11 = this.f6656d;
                double d12 = this.f6657e;
                int i6 = (int) ((d11 + d12) * 4.0d);
                int iMin = (int) Math.min((int) Math.max(50.0d, d11 + Math.max(d12 * 3.0d, d11)), ((this.f6662j / 8.0d) * (((double) i3) / 2.5d)) / 1316.0d);
                int iMax = (int) Math.max(50.0d, this.f6656d + (this.f6657e * 2.5d));
                double d13 = this.f6658f;
                int iMax2 = (int) (d13 + Math.max(this.f6661i * 4.0d, (15.0d * d13) / 100.0d));
                int iMax3 = (int) (this.f6659g + Math.max(1.0d, this.f6661i * 2.0d));
                double d14 = i5;
                double d15 = this.f6655c;
                if (d14 <= d15 || (i4 < i3 / 3 && i2 <= i6)) {
                    long j4 = this.f867c;
                    if (jCurrentTimeMillis > j4 && (i4 > i3 / 5 || i2 > iMin)) {
                        i5 -= (i5 / 10) + 150000;
                        this.f867c = jCurrentTimeMillis + 250;
                        Log.i("StreamConditioner", String.format("AUTO: bs_th2 set bitrate to %d", Integer.valueOf(i5)));
                    } else if (jCurrentTimeMillis > j4 && (i4 > iMax2 || i2 > iMax)) {
                        i5 -= 150000;
                        this.f867c = jCurrentTimeMillis + 200;
                        Log.i("StreamConditioner", String.format("AUTO: bs_th1 set bitrate to %d", Integer.valueOf(i5)));
                    } else if (jCurrentTimeMillis > this.f6654b && i4 < iMax3 && this.f6660h < 0.1d) {
                        i5 += (i5 / 30) + 30000;
                        this.f6654b = jCurrentTimeMillis + 400;
                    }
                } else {
                    i5 = (int) d15;
                    this.f867c = jCurrentTimeMillis + 200;
                    Log.i("StreamConditioner", String.format("AUTO: bs_th3 set bitrate to %d", Integer.valueOf(i5)));
                }
                int iMax4 = (((int) Math.max(Math.min(i5, ((prn) this).f6676c), this.f6655c)) / 20000) * 20000;
                if (iMax4 != ((prn) this).f888b) {
                    e(iMax4);
                    return;
                }
                return;
            }
        }
    }

    @Override // LPT5.prn
    public long i() {
        return 30L;
    }

    @Override // LPT5.prn
    public String j() {
        return ((prn) this).f879a.getString(R.string.adaptive_bitrate_hybrid3);
    }

    @Override // LPT5.prn
    public void s() {
        if (((prn) this).f882a != null) {
            if (((prn) this).f877a + PayloadController.PAYLOAD_COLLECTOR_TIMEOUT < System.currentTimeMillis()) {
                e((long) (((double) ((prn) this).f888b) / 1.5d));
            }
        }
        super.s();
    }

    @Override // LPT5.prn
    public void x(int i2) {
        ((prn) this).f6676c = i2;
        this.f6655c = ((double) i2) * 0.04d;
    }

    @Override // LPT5.prn
    public void z(lpt5 lpt5Var, int i2) {
        this.f6655c = ((double) i2) * 0.05d;
        this.f6656d = 0.0d;
        this.f6657e = 0.0d;
        this.f6658f = 0.0d;
        this.f6659g = 200.0d;
        this.f6660h = 0.0d;
        this.f6661i = 0.0d;
        this.f6662j = 0.0d;
        this.f868d = 0;
        this.f869e = 300;
        this.f870f = 0;
        this.f6654b = 0L;
        this.f867c = 0L;
        super.z(lpt5Var, i2);
    }
}
