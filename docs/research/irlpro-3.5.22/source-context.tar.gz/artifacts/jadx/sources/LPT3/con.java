package LPT3;

import java.util.Collection;
import java.util.Collections;
import p139lpt3.a0;

/* JADX INFO: loaded from: classes.dex */
public final class con extends lpt1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final char f6627a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final char[] f859a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final char[] f6628b = {'T', 'N', inet.ipaddr.aux.SEGMENT_WILDCARD, 'E'};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final char[] f6629c = {inet.ipaddr.com6.PREFIX_LEN_SEPARATOR, ':', '+', '.'};

    static {
        char[] cArr = {'A', 'B', 'C', 'D'};
        f859a = cArr;
        f6627a = cArr[0];
    }

    @Override // LPT3.lpt1
    public boolean[] d(String str) {
        int i2;
        if (str.length() < 2) {
            StringBuilder sb = new StringBuilder();
            char c2 = f6627a;
            sb.append(c2);
            sb.append(str);
            sb.append(c2);
            str = sb.toString();
        } else {
            char upperCase = Character.toUpperCase(str.charAt(0));
            char upperCase2 = Character.toUpperCase(str.charAt(str.length() - 1));
            char[] cArr = f859a;
            boolean zA = aux.a(cArr, upperCase);
            boolean zA2 = aux.a(cArr, upperCase2);
            char[] cArr2 = f6628b;
            boolean zA3 = aux.a(cArr2, upperCase);
            boolean zA4 = aux.a(cArr2, upperCase2);
            if (zA) {
                if (!zA2) {
                    throw new IllegalArgumentException("Invalid start/end guards: ".concat(str));
                }
            } else if (!zA3) {
                if (zA2 || zA4) {
                    throw new IllegalArgumentException("Invalid start/end guards: ".concat(str));
                }
                StringBuilder sb2 = new StringBuilder();
                char c3 = f6627a;
                sb2.append(c3);
                sb2.append(str);
                sb2.append(c3);
                str = sb2.toString();
            } else if (!zA4) {
                throw new IllegalArgumentException("Invalid start/end guards: ".concat(str));
            }
        }
        int i3 = 20;
        for (int i4 = 1; i4 < str.length() - 1; i4++) {
            if (Character.isDigit(str.charAt(i4)) || str.charAt(i4) == '-' || str.charAt(i4) == '$') {
                i3 += 9;
            } else {
                if (!aux.a(f6629c, str.charAt(i4))) {
                    throw new IllegalArgumentException("Cannot encode : '" + str.charAt(i4) + '\'');
                }
                i3 += 10;
            }
        }
        boolean[] zArr = new boolean[i3 + (str.length() - 1)];
        int i5 = 0;
        for (int i6 = 0; i6 < str.length(); i6++) {
            char upperCase3 = Character.toUpperCase(str.charAt(i6));
            if (i6 == 0 || i6 == str.length() - 1) {
                if (upperCase3 == '*') {
                    upperCase3 = 'C';
                } else if (upperCase3 == 'E') {
                    upperCase3 = 'D';
                } else if (upperCase3 == 'N') {
                    upperCase3 = 'B';
                } else if (upperCase3 == 'T') {
                    upperCase3 = 'A';
                }
            }
            int i7 = 0;
            while (true) {
                char[] cArr3 = aux.f6620a;
                if (i7 >= cArr3.length) {
                    i2 = 0;
                    break;
                }
                if (upperCase3 == cArr3[i7]) {
                    i2 = aux.f855a[i7];
                    break;
                }
                i7++;
            }
            int i8 = 0;
            int i9 = 0;
            boolean z2 = true;
            while (i8 < 7) {
                zArr[i5] = z2;
                i5++;
                if (((i2 >> (6 - i8)) & 1) == 0 || i9 == 1) {
                    z2 = !z2;
                    i8++;
                    i9 = 0;
                } else {
                    i9++;
                }
            }
            if (i6 < str.length() - 1) {
                zArr[i5] = false;
                i5++;
            }
        }
        return zArr;
    }

    @Override // LPT3.lpt1
    public Collection<a0> f() {
        return Collections.singleton(a0.CODABAR);
    }
}
