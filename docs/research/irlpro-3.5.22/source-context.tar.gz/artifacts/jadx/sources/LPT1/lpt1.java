package LPT1;

/* JADX INFO: loaded from: classes.dex */
public class lpt1 extends RuntimeException {
    public lpt1(String str) {
        super(str);
    }

    public lpt1(String str, Throwable th) {
        super(str, th);
    }

    public lpt1(Throwable th) {
        super(th);
    }
}
