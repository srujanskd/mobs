package LPT1;

import java.io.IOException;
import java.math.BigDecimal;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes.dex */
public abstract class lpt7 implements lpt8 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final lpt7 f6587a;

    /* JADX INFO: renamed from: a, reason: collision with other field name */
    public static final /* synthetic */ lpt7[] f836a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final lpt7 f6588b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final lpt7 f6589c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final lpt7 f6590d;

    public final enum aux extends lpt7 {
        public aux(String str, int i2) {
            super(str, i2, null);
        }

        @Override // LPT1.lpt8
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public Double a(LPT2.aux auxVar) throws IOException {
            return Double.valueOf(auxVar.M());
        }
    }

    static {
        aux auxVar = new aux("DOUBLE", 0);
        f6587a = auxVar;
        lpt7 lpt7Var = new lpt7("LAZILY_PARSED_NUMBER", 1) { // from class: LPT1.lpt7.con
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.lpt8
            public Number a(LPT2.aux auxVar2) throws IOException {
                return new p052Lpt2.lpt3(auxVar2.Z());
            }
        };
        f6588b = lpt7Var;
        lpt7 lpt7Var2 = new lpt7("LONG_OR_DOUBLE", 2) { // from class: LPT1.lpt7.nul
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.lpt8
            public Number a(LPT2.aux auxVar2) throws IOException, lpt1 {
                String strZ = auxVar2.Z();
                try {
                    try {
                        return Long.valueOf(Long.parseLong(strZ));
                    } catch (NumberFormatException e2) {
                        throw new lpt1("Cannot parse " + strZ + "; at path " + auxVar2.C(), e2);
                    }
                } catch (NumberFormatException unused) {
                    Double dValueOf = Double.valueOf(strZ);
                    if ((!dValueOf.isInfinite() && !dValueOf.isNaN()) || auxVar2.F()) {
                        return dValueOf;
                    }
                    throw new LPT2.prn("JSON forbids NaN and infinities: " + dValueOf + "; at path " + auxVar2.C());
                }
            }
        };
        f6589c = lpt7Var2;
        lpt7 lpt7Var3 = new lpt7("BIG_DECIMAL", 3) { // from class: LPT1.lpt7.prn
            {
                aux auxVar2 = null;
            }

            @Override // LPT1.lpt8
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public BigDecimal a(LPT2.aux auxVar2) throws IOException {
                String strZ = auxVar2.Z();
                try {
                    return new BigDecimal(strZ);
                } catch (NumberFormatException e2) {
                    throw new lpt1("Cannot parse " + strZ + "; at path " + auxVar2.C(), e2);
                }
            }
        };
        f6590d = lpt7Var3;
        f836a = new lpt7[]{auxVar, lpt7Var, lpt7Var2, lpt7Var3};
    }

    public lpt7(String str, int i2) {
        super(str, i2);
    }

    public static lpt7 valueOf(String str) {
        return (lpt7) Enum.valueOf(lpt7.class, str);
    }

    public static lpt7[] values() {
        return (lpt7[]) f836a.clone();
    }

    public /* synthetic */ lpt7(String str, int i2, aux auxVar) {
        this(str, i2);
    }
}
