package COM3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public class lpt6 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap<String, lpt5> f5697a = new HashMap<>();

    public final void a() {
        Iterator<lpt5> it = this.f5697a.values().iterator();
        while (it.hasNext()) {
            it.next().a();
        }
        this.f5697a.clear();
    }

    public final lpt5 b(String str) {
        return this.f5697a.get(str);
    }

    public Set<String> c() {
        return new HashSet(this.f5697a.keySet());
    }

    public final void d(String str, lpt5 lpt5Var) {
        lpt5 lpt5VarPut = this.f5697a.put(str, lpt5Var);
        if (lpt5VarPut != null) {
            lpt5VarPut.d();
        }
    }
}
